/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Time History
/// @n Filename: TimeHistory.cpp
/// @n Description: Time history table
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 13	Stability Project 1.8.1.3	7/2/2011 5:02:06 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.8.1.2	7/1/2011 4:39:01 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	Stability Project 1.8.1.1	3/17/2011 3:20:50 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 10	Stability Project 1.8.1.0	2/15/2011 3:04:04 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "CStorage.h"
#include "StoragePaths.h"
#include "V6globals.h"
#include "TimeHistory.h"
QMutex CTimeHistory::m_CritSection;
CTimeHistory *CTimeHistory::m_pTimeHistory = NULL;
//****************************************************************************
/// 
///	Clients call this function to get a pointer to the CTimeHistory Singleton
///	(there is only one CTimeHistory instance and all clients use it)
///
/// @param none
///
/// @return pointer to CTimeHistory instance
/// 
//****************************************************************************
CTimeHistory* CTimeHistory::GetHandle() {
	if (!m_pTimeHistory)
		m_pTimeHistory = new CTimeHistory();
	return m_pTimeHistory;
}
//****************************************************************************
/// 
///	Tidy up and call destructor
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CTimeHistory::CleanUp() {
	if (m_pTimeHistory)
		delete m_pTimeHistory;
	m_pTimeHistory = NULL;
}
//****************************************************************************
/// 
///	Constructor
///
/// @param none
/// 
//****************************************************************************
CTimeHistory::CTimeHistory() {
	m_NumTableEntries = 0;
	m_NumFileEntries = 0;
	m_TopOfTableEntry = 0;
	QMutex * m_CritSection;
	m_TimeDetailsTable = new DetailedTimeEntry[ MAX_FILE_ENTRIES];
	memset(m_Table, 0, sizeof(m_Table)); // blank table to start
	// blank latest and startup entries
	m_LatestEntry = m_Table[0];
	m_StartupEntry = m_Table[0];
	// initial read of the file into the table - if present
	InitTable();
	// initialise the detailed time table too
	InitTimeDetailsTable();
}
//****************************************************************************
/// CTimeHistory Destructor
///
/// @param none
/// 
//****************************************************************************
CTimeHistory::~CTimeHistory() {
	//PSR - The pointer allocation in the constructor seems to be an array hence coorected the deallocation
	delete[] m_TimeDetailsTable;
	m_TimeDetailsTable = NULL;
}
//****************************************************************************
/// 
///	Initialise table from file, and set up members
///
/// @param none
///
/// @return TRUE - read ok, FALSE if not
/// 
//****************************************************************************
BOOL CTimeHistory::InitTable() {
	BOOL bRetVal = FALSE;
	// check the file exists and is the correct version/format
	if (ValidateTableEntryFile()) {
		m_Storage.setFileName(m_filePathAndFileName);
		DWORD dwFileSize = m_Storage.size();
		// the file exists, determine the number of table entries
		// we can read in first time in order to populate the
		// 'windowing' table
		m_NumFileEntries = dwFileSize / sizeof(TableEntry);
		// there are too many enteries to fit in our table to truncate
		if (m_NumFileEntries > TABLE_SIZE) {
			// limit the top table entry to the last entries in the file
			// whilst not exceeding the table limit
			m_TopOfTableEntry = m_NumFileEntries - TABLE_SIZE;
			// limit the number of table entries
			m_NumTableEntries = TABLE_SIZE;
		} else {
			// the file has less enteries than our table so load them all
			m_TopOfTableEntry = 0;
			m_NumTableEntries = m_NumFileEntries;
		}
		ReadTableWindow();
		// set up latest and last startup entries assuming we have actually loaded some...
		if (m_NumTableEntries) {
			// point the latest entry and the last complete entry in the table
			m_LatestEntry = m_Table[m_NumTableEntries - 1];
			// find last startup entry (has the flag set)
			BOOL found = FALSE;
			do {
				// first look in the table.
				for (int index = m_NumTableEntries - 1; index >= 0; index--) {
					if (m_Table[index].Flags & FLAG_STARTUP) {
						m_StartupEntry = m_Table[index];
						found = TRUE;
						break;
					}
				}
				// no startup entry was found, so we need to go back further
				if ((!found) && (m_TopOfTableEntry > 0)) {
					// ok, we need to look in the file.
					// move the file window back, and re-read it.
					m_TopOfTableEntry -= TABLE_SIZE;
					ReadTableWindow();
				} else
					break;
			} while (!found);
		}
		//Dump();
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// 
///	Check the table entry file is valid, creating it should it be too old, not exist
/// or have been affected by an unexpected reboot
///
/// @return TRUE - the file is valid, FALSE if not
/// 
//****************************************************************************
const BOOL CTimeHistory::ValidateTableEntryFile() {
	// ensure the DATA directory exists.
	m_filePathAndFileName[0] = 0;
	QString str = "";
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, str, m_filePathAndFileName, MAX_PATH);
	int length = m_filePathAndFileName.length();			//cast to int to remove unwanted warnings
	if (length) {
		m_filePathAndFileName[length - 1] = 0; // remove trailing backslah
	}
	/// TODO : Find solution for create directory
	CreateDirectory(m_filePathAndFileName, nullptr);
	// now build the filename proper.
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, TIME_HISTORY_FILENAME, m_filePathAndFileName, MAX_PATH);
	m_Storage.setFileName(m_filePathAndFileName);
	DWORD dwFileSize = m_Storage.size();
	if (dwFileSize == 0) {
		// appears to not be present.
		// check to see if we were part way through deleting some old entries, and there was a 'problem'..
		// see if the 'old' file exists
		QString oldPathAndFileName;
		pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, TIME_HISTORY_FILENAME_OLD, oldPathAndFileName, MAX_PATH);
		// does the old file exist?
		if (m_Storage.exists(oldPathAndFileName)) {
			// yes - so rename it and use it.
			// rename current file
			m_Storage.Rename(oldPathAndFileName, m_filePathAndFileName);
		} else
			return FALSE;
	}
	return TRUE;
}
//****************************************************************************
/// 
///	Initialise the time details table from file, and set up members
///
/// @param none
///
/// @return TRUE - read ok, FALSE if not
/// 
//****************************************************************************
const BOOL CTimeHistory::InitTimeDetailsTable() {
	BOOL bRetVal = FALSE;
	// reset the detailed time table
	memset(m_TimeDetailsTable, 0, sizeof(DetailedTimeEntry) * MAX_FILE_ENTRIES);
	// by this point the file should already have been validated and exist so no need to perform
	// those checks again - simply seek to the start of the file and read the data in until we
	// reach the end
	// create a temporary local array for storing the data
	const int TempTableLength = 128;
	TableEntry tempTableEntries[TempTableLength];
	// loop through reading the data
	int noOfTableEntriesCopied = 0;
	while (noOfTableEntriesCopied < m_NumFileEntries) {
		const int bytesRead = ReadTableFile(tempTableEntries,
		TABLE_SIZE, noOfTableEntriesCopied * sizeof(TableEntry), TempTableLength * sizeof(TableEntry), m_Storage,
				m_filePathAndFileName);
		// translate the bytes read into a number of complete table entries read
		const int numberOfTableEntriesRead = (bytesRead / sizeof(TableEntry));
		// now populate the relevant table position and increment the number of entries read/copied so far
		for (int tempTablePos = 0; tempTablePos < numberOfTableEntriesRead; tempTablePos++) {
			CopyTimeEntryToDetailed(m_TimeDetailsTable[noOfTableEntriesCopied], tempTableEntries[tempTablePos]);
			noOfTableEntriesCopied++;
			// update the span for the previous record (if there is one)
			if (noOfTableEntriesCopied > 1) {
				m_TimeDetailsTable[noOfTableEntriesCopied - 2].EndTick100 = m_TimeDetailsTable[noOfTableEntriesCopied
						- 1].StartTick100 - 1;
			}
		}
	}
	// set the latest time index (although this is a curcular buffer this index will be the last
	// entry added when the system is starting up
	if (noOfTableEntriesCopied > 0) {
		m_LatestDetailedTimeEntryIndex = noOfTableEntriesCopied - 1;
	} else {
		// now time entries, could possibly happen, simply set the index to 0
		m_LatestDetailedTimeEntryIndex = 0;
	}
	return bRetVal;
}
//****************************************************************************
/// Delete a block of old entried from the history file
///
/// @param none
///							
/// @return new number of file entries
/// 
//****************************************************************************
int CTimeHistory::DeleteOldEntries() {
	// need to create a temporary file, write to that, then rename and delete the old one.
	QString tempPathAndFileName = "";
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, QString::fromLocal8Bit(TIME_HISTORY_FILENAME_TEMP),
			tempPathAndFileName, MAX_PATH);
	// delete a block of these, leaving a multiple of table size entries to copy.
	int deleteEntries = DELETE_ENTRIES_AMOUNT + (m_NumFileEntries - DELETE_ENTRIES_AMOUNT) % TABLE_SIZE;
	int seekpos = deleteEntries * sizeof(TableEntry);
	int readamount = TABLE_SIZE * sizeof(TableEntry);
	// create the temp file
	CStorage tempStorage;
	tempStorage.Open(tempPathAndFileName.toLocal8Bit().data(), QFile::WriteOnly | QFile::Append); // here will truncate if it exits.
	// open the history file
	m_Storage.Open(m_filePathAndFileName.toLocal8Bit().data(), QFile::ReadOnly);
	m_Storage.Seek(seekpos, 0);	// move to start pos
	while (m_Storage.Read(m_Table, readamount) == readamount)
		tempStorage.Write(m_Table, readamount);
	m_Storage.Close();
	tempStorage.Close();
	// ok, here we have the temp file containing the shortened history file
	// rename history file to old
	QString oldPathAndFileName = "";
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, TIME_HISTORY_FILENAME_OLD, oldPathAndFileName, MAX_PATH);
	// ensure old file does not already exist!
	if (tempStorage.exists(oldPathAndFileName))
		tempStorage.remove(oldPathAndFileName);
	// rename current file
	tempStorage.Rename(m_filePathAndFileName, oldPathAndFileName);
	// now rename new file
	tempStorage.Rename(QString ::fromWCharArray(tempPathAndFileName, m_filePathAndFileName);
	// now delete the old...
			tempStorage.remove(oldPathAndFileName);
			return m_NumFileEntries - deleteEntries; // return the new number of entries in the file
		}
//****************************************************************************
/// Reset the history file after NV cleared or CF data deleted etc.
///
/// @param none
///							
/// @return none
/// 
//****************************************************************************
		void CTimeHistory::ResetHistory() {
			m_CritSection.lock();
			// delete the history file.
			if (m_Storage.exists(m_filePathAndFileName))
				m_Storage.remove(m_filePathAndFileName);
			// see if the 'old' file exists
			QString oldPathAndFileName = "";
			pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, TIME_HISTORY_FILENAME_OLD, oldPathAndFileName, MAX_PATH);
			// does the old file exist?
			if (m_Storage.exists(oldPathAndFileName)) {
				// yes - so delete it too
				m_Storage.remove(oldPathAndFileName);
			}
			// reset member vars
			m_NumTableEntries = 0;
			m_NumFileEntries = 0;
			m_TopOfTableEntry = 0;
			memset(m_Table, 0, sizeof(m_Table)); // blank table 
			// blank latest and startup entries
			m_LatestEntry = m_Table[0];
			m_StartupEntry = m_Table[0];
			// reset the detailed time entries too
			memset(m_TimeDetailsTable, 0, sizeof(DetailedTimeEntry) * MAX_FILE_ENTRIES);
			m_LatestDetailedTimeEntryIndex = 0;
			m_CritSection.lock();
		}
//****************************************************************************
/// Add an entry into the history file and table
///
/// @param[in] OnGoingTick100 - 100ths sec counter
/// @param[in] ActualTime	- Actual real-world time it represents
/// @param[in] IsStartup	- Flag true for Startup false for time updates.
///							
/// @return none
/// 
//****************************************************************************
		void CTimeHistory::AddEntry(LONGLONG OnGoingTick100, CTVtime ActualTime, BOOL IsStartup) //=FALSE
				{
			qDebug("### Adding Time Entry at tick = %I64d ###\n", OnGoingTick100);
			m_CritSection.lock();
			// update our latest entry member
			m_LatestEntry.Tick100 = OnGoingTick100;
			m_LatestEntry.ActualTime = ActualTime;
			m_LatestEntry.Flags = (FLAG_STARTUP & IsStartup);
			// update the detailed time history too
			AddEntryToDetailedTime(m_LatestEntry);
			if (IsStartup)
				m_StartupEntry = m_LatestEntry; // keep a copy 
			// CR3120-Shifted m_NumFileentries++ to perform calculation for DeleteOldEntries() before incrementing.
			if (m_NumFileEntries >= MAX_FILE_ENTRIES)
				m_NumFileEntries = DeleteOldEntries();
			// now write it to the file
			if (m_Storage.Open(m_filePathAndFileName.toLocal8Bit().data(), QFile::Append) == TRUE) {
				m_Storage.Seek(0, m_Storage.size() - 1); // seek to the end of the file.
				m_Storage.Write(&m_LatestEntry, sizeof(TableEntry)); // add the new entry
				// now, if the table is all contained in memory, then simply update the latest 
				// CR3120-Shifted m_NumFileentries++ to perform calculation for DeleteOldEntries() before incrementing.
				m_NumFileEntries++;
				if (m_NumTableEntries < TABLE_SIZE) {
					// we can simply update the table here.
					m_Table[m_NumTableEntries] = m_LatestEntry;
					m_NumTableEntries++;
				} else {
					// here we need to re-read the table back in from file.
					m_TopOfTableEntry = m_NumFileEntries - TABLE_SIZE;
					int seekpos = m_TopOfTableEntry * sizeof(TableEntry);
					int readamount = m_NumTableEntries * sizeof(TableEntry); // will be the full table amount
					m_Storage.Seek(seekpos, 0); // seek to the position from which to load the latest data from the table
					m_Storage.Read(m_Table, readamount);
				}
				m_Storage.Close();
			} else {
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, "Error opening/creating time history file");
			}
			//Dump();
			m_CritSection.lock();
		}
//****************************************************************************
/// Adds a time entry to the detailed time table
///
/// @param[in] latestEntry - The latest time entry information that we must copy
///							to the detailed time table
/// 
//****************************************************************************
		void CTimeHistory::AddEntryToDetailedTime(const TableEntry &latestTimeEntry) {
			// get the next free time slot
			int nextFreeTimeEntryIndex = GetNextFreeTimeDetailsEntryIndex();
			// now copy the passed in time details to this entry
			CopyTimeEntryToDetailed(m_TimeDetailsTable[nextFreeTimeEntryIndex], latestTimeEntry);
			// update the end tick of the previous latest entry (if there is one - this could be the first record)
			if ((m_NumFileEntries > 1) || (nextFreeTimeEntryIndex == 1)) {
				m_TimeDetailsTable[m_LatestDetailedTimeEntryIndex].EndTick100 =
						m_TimeDetailsTable[nextFreeTimeEntryIndex].StartTick100 - 1;
			}
			// finally, move the latest index onto this new record
			m_LatestDetailedTimeEntryIndex = nextFreeTimeEntryIndex;
		}
//****************************************************************************
/// Reads a section of the file (the 'window') into the table
///
/// @return none
/// 
//****************************************************************************
		BOOL CTimeHistory::ReadTableWindow() {
			// limit the window within the limits of the file
			if (m_TopOfTableEntry + TABLE_SIZE > m_NumFileEntries) {
				m_TopOfTableEntry = m_NumFileEntries - TABLE_SIZE; // maintain a full window on the file
			}
			if (m_TopOfTableEntry < 0) {
				m_TopOfTableEntry = 0; // can't go back before start of file!
			}
			m_NumTableEntries = (m_NumFileEntries - m_TopOfTableEntry); // how many entries to read (max)
			if (m_NumTableEntries > TABLE_SIZE) {
				m_NumTableEntries = TABLE_SIZE;
			}
			return ReadTableFile(m_Table,
			TABLE_SIZE, m_TopOfTableEntry * sizeof(TableEntry), m_NumTableEntries * sizeof(TableEntry), m_Storage,
					m_filePathAndFileName);
		}
//****************************************************************************
/// Reads a section of the file into the passed in buffer/table
///
/// @param[in] tableToPopulate - a pointer to the table we wish to populate
/// @param[in] maxNoOfTableEntries - the maximum number of table entries
/// @param[in] seekPosition - the position to seek to
/// @param[in] readBytes - the number of bytes to read
/// @param[in] tableFile - the file we are reading
/// @param[in] tableFilename - the table file name
///
/// @return the number of bytes actually read
/// 
//****************************************************************************
		const int CTimeHistory::ReadTableFile(TableEntry *tableToPopulate, const int maxNoOfTableEntries,
				const int seekPosition, const int readBytes, CStorage &tableFile, const QString &tableFilename) {
			BOOL bRetVal = FALSE;
			// open the file andd seek to the relevant position
			tableFile.Open(tableFilename.toLocal8Bit().data(), QFile::ReadOnly);
			if (seekPosition) {
				tableFile.Seek(seekPosition, 0);
			}
			int bytesActuallyRead = tableFile.Read(tableToPopulate, readBytes);
			tableFile.Close();
			return bytesActuallyRead;
		}
//****************************************************************************
/// Get an entry from history table/file
///
/// @param[in] OnGoingTick100 - 100ths sec counter for the time required
///							
/// @return pointer to TableEntry struct (temporary ONLY)
/// 
//****************************************************************************
		TableEntry* CTimeHistory::GetEntry(LONGLONG OnGoingTick100) {
			m_CritSection.lock();
			if (OnGoingTick100 >= m_LatestEntry.Tick100) {
				m_CritSection.lock();
				return &m_LatestEntry; // requres the latest in the table
			}
			// here need to see where our table 'window' is in the file
			BOOL found = FALSE;
			while (!found) {
				// do we need to read an earlier/later section of file (if there is one)
				if (OnGoingTick100 < m_Table[0].Tick100) {
					// need to read an earlier section of file into the table
					// and we don't require the 'top row' - so read the full table size (if possible)
					if (m_TopOfTableEntry == 0) {
						// can't go back any more 
						m_CritSection.lock();
						return &m_Table[0]; // return first in table.(oldest)
					}
					m_TopOfTableEntry -= TABLE_SIZE;
					ReadTableWindow();
				} else if (OnGoingTick100 > m_Table[m_NumTableEntries - 1].Tick100) {
					// need to read a later section of file into the table
					// However, we need to keep the 'last row' since it could be this entry we actually want 
					m_TopOfTableEntry += TABLE_SIZE - 1;
					ReadTableWindow();
				} else {
					// ok, it should be currently in the table, start at the end and work backwards
					for (int index = m_NumTableEntries - 1; index >= 0; index--) {
						if (OnGoingTick100 >= m_Table[index].Tick100) {
							// found it.
							m_CritSection.lock();
							return &m_Table[index];
						}
					}
					// should never get here!
					m_CritSection.lock();
					return NULL;
				}
			}
			m_CritSection.lock();
			return NULL;
		}
//****************************************************************************
/// Get the last startup entry from history table/file
///
/// @param none
///							
/// @return pointer to TableEntry struct (temporary ONLY)
/// 
//****************************************************************************
		TableEntry* CTimeHistory::GetStartupEntry() {
			// no need to search for this - we find the last one at startup 
			// and then update it when new one added (just after startup)
			if (m_StartupEntry.Flags == 0)
				return NULL;
			return &m_StartupEntry;
		}
//****************************************************************************
/// Dump Table contents
///
/// @param none
///							
/// @return none
/// 
//****************************************************************************
		void CTimeHistory::Dump() {
			qDebug("\n================TIME HISTORY==============\n");
			qDebug("file Entries %d\n", m_NumFileEntries);
			qDebug("table Entries %d\n", m_NumTableEntries);
			for (int index = 0; index < m_NumTableEntries; index++) {
				CTVtime displaytime(m_Table[index].ActualTime);
				CHAR buff[50];
				displaytime.TimeToStringShort(buff);
				if (m_Table[index].Flags)
					qDebug("%d) OnGoingTick100 %I64d Time=%s	startup\n", index, m_Table[index].Tick100, buff);
				else
					qDebug("%d) OnGoingTick100 %I64d Time=%s\n", index, m_Table[index].Tick100, buff);
			}
			qDebug("==========================================\n\n");
			qDebug("\n================DETAILED TIME HISTORY==============\n");
			qDebug("File Entries %d\n", m_NumFileEntries);
			for (int index = 0; index < m_NumFileEntries; index++) {
				CTVtime displaytime(m_TimeDetailsTable[index].ActualTime);
				CHAR buff[50];
				displaytime.TimeToStringShort(buff);
				qDebug("%d) OnGoingTick100 %I64d, EndTick %I64d, Time=%s\n", index,
						m_TimeDetailsTable[index].StartTick100, m_TimeDetailsTable[index].EndTick100, buff);
			}
			qDebug("==========================================\n\n");
		}
//****************************************************************************
/// Get an entry from history table/file based on time/date
///
/// @param[in] targetTime - the actual time required
///							
/// @return A copy of the relevant TEntryDetails struct
/// 
//****************************************************************************
		const DetailedTimeEntry CTimeHistory::GetDetailedTimeEntry(CTVtime targetTime) {
			m_CritSection.lock();
			DetailedTimeEntry detailedTimeEntry;
			BOOL done = FALSE;
			// Unlike ticks which are always increasing to find the closest relavant time we 
			// need track backwards to avoid conplications with mutiple resets in time so 
			// always start our search from the latest time
			int currentIndex = m_LatestDetailedTimeEntryIndex;
			int lastIndexRetrieved = 0;
			// Run through all entries in reverse order until we find one whch meets
			// our time requirement - also drop out if we reach the end of circular 
			// the buffer which is indicated by the current index not changing
			do {
				if (targetTime >= m_TimeDetailsTable[currentIndex].ActualTime) {
					// the target time is within this time entry implying current
					// index is correct so we can exit the loop now
					done = true;
				} else {
					// move onto the next index
					lastIndexRetrieved = currentIndex;
					currentIndex = GetNextOldestTimeDetailsEntryIndex(currentIndex);
				}
			} while (!done && (currentIndex != lastIndexRetrieved));
			// regardless of whether an entry was found that meets our target time test, 
			// current index will be pointing to the only record we can use so set to this
			// value always
			CopyTimeEntryDetails(detailedTimeEntry, m_TimeDetailsTable[currentIndex]);
			m_CritSection.lock();
			return detailedTimeEntry;
		}
//****************************************************************************
/// Method used to copy common table entry information into a detailed table entry
///
/// @param[out] detailedTimeEntryToPopulate - the table entry information we wish to copy to
/// @param[in] timeEntryToCopy - the table entry information we wish to copy from
/// 
//****************************************************************************
		void CTimeHistory::CopyTimeEntryToDetailed(DetailedTimeEntry &detailedTimeEntryToPopulate,
				const TableEntry &timeEntryToCopy) {
			// copy the common information
			detailedTimeEntryToPopulate.StartTick100 = timeEntryToCopy.Tick100;
			detailedTimeEntryToPopulate.ActualTime = timeEntryToCopy.ActualTime;
			// default the end time
			detailedTimeEntryToPopulate.EndTick100 = 0;
		}
//****************************************************************************
/// Method used to copy detailed table entry information from one struct to another
///
/// @param[out] timeEntryToPopulate - the table entry information we wish to copy to
/// @param[in] timeEntryToCopy - the table entry information we wish to copy from
///							
//****************************************************************************
		void CTimeHistory::CopyTimeEntryDetails(DetailedTimeEntry &timeEntryToPopulate,
				const DetailedTimeEntry &timeEntryToCopy) {
			// copy all information
			timeEntryToPopulate.StartTick100 = timeEntryToCopy.StartTick100;
			timeEntryToPopulate.ActualTime = timeEntryToCopy.ActualTime;
			timeEntryToPopulate.EndTick100 = timeEntryToCopy.EndTick100;
		}
//****************************************************************************
/// Helper method used to get the next oldest time details entry
///							
/// @param[in[ currentIndex - the current index
///
/// @return The next oldest time details index or the same index if this is already
///			the oldest
/// 
//****************************************************************************
		const int CTimeHistory::GetNextOldestTimeDetailsEntryIndex(const int currentIndex) const {
			// as the details entry table is a circular buffer this time could loop back to
			// the top of the buffer, hence why we use this method to calculate the index
			int nextOldestEntryIndex = currentIndex - 1;
			if (nextOldestEntryIndex < 0) {
				// check if there are any older entries first
				if (m_NumFileEntries >= MAX_FILE_ENTRIES) {
					// the buffer is full so there are older entries. Go to the top of the buffer
					nextOldestEntryIndex = MAX_FILE_ENTRIES - 1;
				} else {
					// the buffer is not full so we are already on the oldest entry so return 0 or 
					// basically current index
					nextOldestEntryIndex = 0;
				}
			}
			// check the index is not the same as our current latest index in which case we were already at the
			// oldest time index
			if (nextOldestEntryIndex == m_LatestDetailedTimeEntryIndex) {
				// current index was already the oldest index so return it instead - the calling
				// process will need to detect this
				nextOldestEntryIndex = currentIndex;
			}
			return nextOldestEntryIndex;
		}
//****************************************************************************
/// Helper method used to get the next avaiable time details entry index - this would usually be 
/// so we can recycle the index and basically overwrite it with the latest time entry
///							
/// @return The next free time details entry index 
/// 
//****************************************************************************
		const int CTimeHistory::GetNextFreeTimeDetailsEntryIndex() {
			// time detail slots will be allocated in ascending order i.e. the time details go back
			// in time so we need to go forward from the existing latest time entry but check
			// for overflow situations
			int nextFreeEntryIndex = m_LatestDetailedTimeEntryIndex + 1;
			if (nextFreeEntryIndex >= MAX_FILE_ENTRIES) {
				nextFreeEntryIndex = 0;
			}
			// check this isn't the first entry either
			if (m_NumFileEntries == 0) {
				// this is the first entry so return the first block in the array
				nextFreeEntryIndex = 0;
			}
			return nextFreeEntryIndex;
		}

/// @file
/// **************************************************************************
/// © Honeywell Trendview - Inspired by codeproject.com article written by Shrishail Rana
/// **************************************************************************
/// @n Module: 		Utilities
/// @n Filename:  Crypto.cpp
/// @n Description: Implementation of the Crypto class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.1.1.3 7/2/2011 4:56:25 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.1.1.2 7/1/2011 4:38:11 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.1.1.1 3/17/2011 3:20:19 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  3 Stability Project 1.1.1.0 2/15/2011 3:02:46 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "Crypto.h"
/// Static initialisation
const QString CCrypto::ms_strDEFAULT_KEY = "BUNNY";
//****************************************************************************
// CCrypto( )
///
/// Constructor
/// 
//****************************************************************************
CCrypto::CCrypto() : m_strKEY(ms_strDEFAULT_KEY) {
}
//****************************************************************************
// CCrypto( const QString  &rstrKEY )
///
/// Constructor where the calling process specifies a key
/// 
/// @param[in]		const QString  &rstrKEY - A user specified encryption key
///
//****************************************************************************
CCrypto::CCrypto(const QString &rstrKEY) : m_strKEY(rstrKEY) {
}
//****************************************************************************
// ~CCrypto( )
///
/// Destructor
/// 
//****************************************************************************
CCrypto::~CCrypto() {
}
//****************************************************************************
// const QString  Decrypt( const QString  &rstrENCRYPTED_DATA, const USHORT usDATA_LEN )
///
/// Method that decrypts the passed in string
/// 
/// @param[in]		const QString  &rstrENCRYPTED_DATA - The encrypted data
/// @param[in]		const USHORT usDATA_LEN - The length of the encrypted data buffer
///
/// @return		The decrypted data
///
//****************************************************************************
const QString CCrypto::Decrypt(const QString pwcENCRYPTED_DATA, const USHORT usDATA_LEN) {
	WCHAR *pwcDecryptedData = new WCHAR[usDATA_LEN];
	WCHAR *pStr = NULL;
	pwcENCRYPTED_DATA.toWCharArray(pStr);
	memcpy(pwcDecryptedData, pStr, usDATA_LEN * sizeof(WCHAR));
	QString strDecryptedData("");
	// determine the data length to pass to this item - use the last character as the identifier unless it
	// is zero in which case we must do a string length check
	USHORT usEncryptedDataLen = pwcDecryptedData[usDATA_LEN - 1];
	if (usEncryptedDataLen == 0) {
		// the data is zero so the chances are this has never been set - do a string length check instead - be
		// aware that this could go wrong if we have null characters embedded within the encrypted string - if
		// the user opens the password dialog and re-enters the data then things will go back to normal
		usEncryptedDataLen = static_cast<USHORT>(wcslen(pwcDecryptedData));
	}
	Crypt(pwcDecryptedData, usEncryptedDataLen);
	// copy the data to a string as it should be safe now (i.e. no invalid characters like NULL's) - invalidate
	// the last character though as that will be our string length
	pwcDecryptedData[usDATA_LEN - 1] = 0;
	strDecryptedData = QString::fromWCharArray(pwcDecryptedData);
	// release the memory
	delete[] pwcDecryptedData;
	return strDecryptedData;
}
//****************************************************************************
// const QString  Encrypt(	QString pwcDataToEncrypt, 
//							const USHORT usDATA_LEN,
//							const USHORT usBUFF_LEN )
///
/// Method that encrypts the passed in string
/// 
/// @param[in/out]		QString pwcDataToEncrypt - The unencrypted data
/// @param[in]			const USHORT usDATA_LEN - The length of the encrypted data
///	@param[in]			const USHORT usBUFF_LEN - The length of the data buffer
///
//****************************************************************************
void CCrypto::Encrypt(WCHAR *pwcDataToEncrypt, const USHORT usDATA_LEN, const USHORT usBUFF_LEN) {
	// encrypt the data
	Crypt(pwcDataToEncrypt, usDATA_LEN);
	// set the last character in the string array to the string length
	pwcDataToEncrypt[usBUFF_LEN - 1] = usDATA_LEN;
}
//****************************************************************************
// void Crypt( QString pwcData, const USHORT usDATA_LEN )
///
/// Method that actually performs the actual encrypting/decrypting
/// 
/// @param[in/out]		QString pwcData - The encrypted/decrypted data
/// @param[in]			const USHORT usDATA_LEN - The length of the data buffer
///
//****************************************************************************
void CCrypto::Crypt(WCHAR *pwcData, const USHORT usDATA_LEN) {
	WCHAR Sbox[257], Sbox2[257];
	unsigned long i, j, t, x;
	QString strKey(m_strKEY);
	const ULONG ulKEY_LENGTH(m_strKEY.length());
	WCHAR temp, k;
	k = '\0';
	i = j = t = x = 0;
	temp = 0;
	//always initialize the arrays with zero
	ZeroMemory(Sbox, sizeof(Sbox));
	ZeroMemory(Sbox2, sizeof(Sbox2));
	//initialize sbox i
	for (i = 0; i < 256U; i++) {
		Sbox[i] = (WCHAR) i;
	}
	j = 0;
	//whether user has sent any inpur key
	if (ulKEY_LENGTH) {
		//initialize the sbox2 with user key
		for (i = 0; i < 256U; i++) {
			if (j == ulKEY_LENGTH) {
				j = 0;
			}
			Sbox2[i] = strKey.at(j++).unicode();
		}
	}
	j = 0; //Initialize j
	//scramble sbox1 with sbox2
	for (i = 0; i < 256; i++) {
		j = (j + (unsigned long) Sbox[i] + (unsigned long) Sbox2[i]) % 256U;
		temp = Sbox[i];
		Sbox[i] = Sbox[j];
		Sbox[j] = temp;
	}
	i = j = 0;
	for (x = 0; x < static_cast<ULONG>(usDATA_LEN); x++) {
		//increment i
		i = (i + 1U) % 256U;
		//increment j
		j = (j + (unsigned long) Sbox[i]) % 256U;
		//Scramble SBox #1 further so encryption routine will
		//will repeat itself at great interval
		temp = Sbox[i];
		Sbox[i] = Sbox[j];
		Sbox[j] = temp;
		//Get ready to create pseudo random  byte for encryption key
		t = ((unsigned long) Sbox[i] + (unsigned long) Sbox[j]) % 256U;
		//get the random byte
		k = Sbox[t];
		//xor with the data and done
		//strData.SetAt( x, (strData.GetAt( x ) ^ k) );
		WCHAR wcNewChar = pwcData[x] ^ k;
		pwcData[x] = wcNewChar;
	}
}

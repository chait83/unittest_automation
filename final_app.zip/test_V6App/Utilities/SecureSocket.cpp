//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		RTDataServer
/// @n Filename:  CSecureSocket.cpp
/// @n Description: Implementation of the CSecureSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
//-----------------------------------------------------------------------------
// This is a server-side SSPI Windows Sockets program.
#include "SecureSocket.h"
#include "DataItemBase.h"
/// TODO : Code rewrite
#define SEC_SUCCESS(Status) ((Status) >= 0)
QMutex CSecureSocket::m_readLock;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
CDebugFileLogger CSecureSocket::m_debugFileLogger("\\SDMemory\\TvSecureSockDbgLogFile.txt", FALSE, (10 * 1024 * 1024));
#endif
//****************************************************************************
// CSecureSocket::CSecureSocket()
///
/// ---Detailed Description-------- 
/// Constructor
///
/// @return ---N/A
/// 
/// @todo --- Add any todo's into the modules ---
///
//****************************************************************************
CSecureSocket::CSecureSocket() {
	m_socketState = NONE;
	m_acceptThread = NULL;
	QMutex * m_csClosedown;
	QMutex * m_csSocket;
	if (!m_bWSAStarted) {
		int errorCode = WSAStartup(MAKEWORD(2, 2), &wsaData);
		if (errorCode == 0) {
			m_bWSAStarted = TRUE;
		} else {
			errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )
			qDebug("Could not initialize winsock Error Code %d\n",m_errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			QString strDbgMsg;
			strDbgMsg = QString::asprintf("::CSS Could not initialize winsock Error Code %d", errorCode);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		}
	}
//		//-----------------------------------------------------------------  
//		// Make an authenticated connection with client.
//
//		if (!AcceptAuthSocket ())
//		{
//#if defined ( TRACE_ALLOW )
//			qDebug("Could not authenticate the socket \n");
//#endif
//		}
} // end main
//****************************************************************************
// CSecureSocket::Disconnect()
///
/// ---Detailed Description of the member function-------- 
/// Disconnects the socket connection
///
/// @return ---N/A
/// 
/// @todo --- Add any todo's into the modules ---
///
//****************************************************************************
void CSecureSocket::Disconnect(QAbstractSocket s, int clientId) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::DISCON BEGIN s %lu client id %d"), s, clientId);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	if (!m_bWSAStarted || s == INVALID_SOCKET) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::DISCON Could not dicsconnect winsock not inited"));
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return;
	}
	//Check if the socket is an invalid socket
	//If not then delete the security context and free 
	//the credential handle
	if (s != INVALID_SOCKET) {
		//Clear the data buffer
		ClearBuffer(clientId);
		ClearClientInfo(s, clientId);
		shutdown(s, SD_BOTH);
		closesocket(s);
		s = INVALID_SOCKET;
	}
	//deletion of mutex not required
	//deletion of mutex not required
	m_socketState = NONE;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::DISCON END s %lu client id %d"), s, clientId);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
}	//end Disconnect()
//****************************************************************************
// CSecureSocket::DoAuthentication(QAbstractSocket AuthSocket)
///
/// ---Detailed Description of the member function-------- 
/// @param[in] AuthSocket Instance of socket
///  
/// @return -- BOOL - Returns TRUE if authentication is successful
/// 
/// @todo --- Add any todo's into the modules ---
///
//****************************************************************************
BOOL CSecureSocket::DoAuthentication(QAbstractSocket AuthSocket, CredHandle &hCred, struct _SecHandle &hCtxt) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::DoAuthentication BEGIN s %lu AuthSocket %lu"), s, AuthSocket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	DWORD cbIn, cbOut;
	BOOL done = FALSE;
	BOOL fNewConversation;
	PSecPkgInfo pkgInfo;
	fNewConversation = TRUE;
	LPSTR pszUser = "XS-999213";
	PTCHAR lpPackageName = UNISP_NAME;
	// Initialize the security package
	SECURITY_STATUS ss = QuerySecurityPackageInfo(lpPackageName, &pkgInfo);
	if (!SEC_SUCCESS(ss)) {
#if defined ( TRACE_ALLOW )
		qDebug("Could not query package info for %s,Error Code %08x \n",lpPackageName,ss);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::DoAuth Could not query package info for %s,Error Code %08x "), lpPackageName,
				ss);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	}
	DWORD cbMaxMessage = pkgInfo->cbMaxToken;
	//Free the Context Buffer
	FreeContextBuffer(pkgInfo);
	//Create the server credentials
	CreateCredentials(pszUser, hCred, hCtxt);
	PBYTE pInBuf = new BYTE[cbMaxMessage];
	PBYTE pOutBuf = new BYTE[cbMaxMessage];
	if (NULL == pInBuf || NULL == pOutBuf) {
#if defined ( TRACE_ALLOW )
		qDebug("Memory allocation error\n");
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::DoAuth Memory allocation error"));
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::DoAuth Handshake begin AuthSocket %lu"), AuthSocket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	while (!done) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::DoAuth Handshake ReceiveMsg AuthSocket %lu"), AuthSocket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		if (!ReceiveMsg(pInBuf, cbMaxMessage, &cbIn, AuthSocket)) {
			if (pInBuf != NULL) {
				delete[] pInBuf;
				pInBuf = NULL;
			}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			strDbgMsg = QString::asprintf(("::DoAuth Handshake begin AuthSocket %lu"), AuthSocket);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
			return (FALSE);
		}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::DoAuth Handshake ReceiveMsg Done (cbIn-%d) AuthSocket %lu"), cbIn,
				AuthSocket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		cbOut = cbMaxMessage;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::DoAuth Handshake GenServerContext begin AuthSocket %lu"), AuthSocket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		if (!GenServerContext(pInBuf, cbIn, &cbOut, &done, fNewConversation, hCred, hCtxt, pOutBuf)) {
#if defined ( TRACE_ALLOW )	
			qDebug("GenServerContext failed \n");
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			strDbgMsg = QString::asprintf(("::DoAuth GenServerContext failed done %d"), done);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
			if (pInBuf != NULL) {
				delete[] pInBuf;
				pInBuf = NULL;
			}
			if (pOutBuf != NULL) {
				delete[] pOutBuf;
				pOutBuf = NULL;
			}
			return (FALSE);
		}
		fNewConversation = FALSE;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(
				("::DoAuth Handshake GenServerContext (done %d) cbOut %ld END SendMsg Begin AuthSocket %lu"), done,
				cbOut, AuthSocket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		if (!SendMsg(pOutBuf, cbOut, AuthSocket)) {
			DWORD errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )	
			qDebug("Sending message failed \n", errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			strDbgMsg = QString::asprintf(("::DoAuth Sending message failed err %d"), errorCode);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
			if (pInBuf != NULL) {
				delete[] pInBuf;
				pInBuf = NULL;
			}
			if (pOutBuf != NULL) {
				delete[] pOutBuf;
				pOutBuf = NULL;
			}
			return (FALSE);
		}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::DoAuth Handshake SendMsg END AuthSocket %lu"), AuthSocket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	}
	if (pInBuf != NULL) {
		delete[] pInBuf;
		pInBuf = NULL;
	}
	if (pOutBuf != NULL) {
		delete[] pOutBuf;
		pOutBuf = NULL;
	}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::DoAuthentication END s %lu AuthSocket %lu"), s, AuthSocket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	//The authentication has been successfully completed
	return (TRUE);
} // end DoAuthentication()
//****************************************************************************
// CSecureSocket::AcceptAuthSocket()
///
/// @return -- BOOL - Returns TRUE if authentication is accepted
/// 
/// @todo --- Add any todo's into the modules ---
///
//****************************************************************************
BOOL CSecureSocket::AcceptAuthSocket(UINT uiLocalPort, int nMaxConn) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::AcceptAuthSocket BEGIN s %lu uiLocalPort %lu nMaxConn %d "), s, uiLocalPort,
			nMaxConn);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	SOCKADDR_IN sockIn;
	int errorCode = 0;
	if (!m_bWSAStarted) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::AAS WSA NOT Started "));
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return FALSE;
	}
	//Make sure the socket was created
	if (s == INVALID_SOCKET) {
		errorCode = WSAENOTSOCK;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::AAS INVALID_SOCKET WSAENOTSOCK"));
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return FALSE;
	}
	//We cannot connect if the socket is already connected or accepting
	if (m_socketState > CREATED) {
		errorCode = WSAEISCONN;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::AAS QAbstractSocket was already created WSAEISCONN"));
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return FALSE;
	}
	//Check port values
	if (uiLocalPort > 65535) {
		errorCode = WSAEINVAL;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::AAS Invalid Port WSAEINVAL"));
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return FALSE;
	}
	//-----------------------------------------------------------------  
	// Create listening socket.
	s = socket(AF_INET, SOCK_STREAM, 0);
	if (INVALID_SOCKET == s) {
		errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )	
		qDebug("Failed to create socket, Error Code %08x \n",m_errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::AAS Failed to create socket, Error Code %08x"), errorCode);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
	//-----------------------------------------------------------------  
	// Bind to local port.
	sockIn.sin_family = AF_INET;
	sockIn.sin_addr.s_addr = 0;
	sockIn.sin_port = htons(uiLocalPort);
	if (QAbstractSocket_ERROR == bind(s, (LPSOCKADDR) & sockIn, sizeof(sockIn))) {
		errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )	
		qDebug("Bind failed:, Error Code %08x \n",errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::AAS Bind failed:, Error Code %08x"), errorCode);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
	//-----------------------------------------------------------------  
	// Listen for client.
	int maxConnections = nMaxConn;
	if (nMaxConn > 5) {
		maxConnections = 5;	//At any cost restrict max connections to 5
	}
	if (QAbstractSocket_ERROR == listen(s, maxConnections)) {
		errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )	
		qDebug("Listen failed:, Error Code %08x \n", errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::AAS Listen failed:, Error Code %08x"), errorCode);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
	m_socketState = ACCEPTING;
	m_acceptThread = CreateThread(NULL, 0, StartThread, this, FALSE, NULL);
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::AcceptAuthSocket END - ACCEPTING m_acceptThreadv %08x"), m_acceptThread);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	return TRUE;
} // end AcceptAuthSocket() 
//*******************************************************************************
// CSecureSocket::GenServerContext(BYTE *pIn,DWORD cbIn,BYTE *pOut,DWORD *pcbOut,
// BOOL *pfDone,BOOL fNewConversation)
///
/// ---Detailed Description of the member function--------																																			 
/// @param[in] pIn Pointer to input buffer
/// @param[in] cbIn Size of input buffer
/// @param[out]pOut Pointer to output buffer
/// @param[out]pfDone 
/// @param[out]fNewConversation
///  
/// @return -- BOOL - Returns TRUE if server context is successfully generated
/// 
/// @todo --- Add any todo's into the modules ---
///
//********************************************************************************
BOOL CSecureSocket::GenServerContext(BYTE *pIn, DWORD cbIn, DWORD *pcbOut, BOOL *pfDone, BOOL fNewConversation,
		CredHandle &hCred, struct _SecHandle &hCtxt, BYTE *pOut) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::GenServerContext BEGIN "));
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	SECURITY_STATUS ss;
	TimeStamp Lifetime;
	SecBufferDesc OutBuffDesc;
	SecBuffer OutSecBuff;
	SecBufferDesc InBuffDesc;
	SecBuffer InSecBuff;
	ULONG Attribs = 0;
	int errorCode = 0;
	//----------------------------------------------------------------
	// Prepare output buffers.
	OutBuffDesc.ulVersion = 0;
	OutBuffDesc.cBuffers = 1;
	OutBuffDesc.pBuffers = &OutSecBuff;
	OutSecBuff.cbBuffer = *pcbOut;
	OutSecBuff.BufferType = SECBUFFER_TOKEN;
	OutSecBuff.pvBuffer = (PBYTE) pOut;
	//----------------------------------------------------------------
	// Prepare input buffers.
	InBuffDesc.ulVersion = 0;
	InBuffDesc.cBuffers = 1;
	InBuffDesc.pBuffers = &InSecBuff;
	InSecBuff.cbBuffer = cbIn;
	InSecBuff.BufferType = SECBUFFER_TOKEN;
	InSecBuff.pvBuffer = pIn;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::GSC AcceptSecurityContext begin"));
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	//Accept the security context
	ss = AcceptSecurityContext(&hCred, fNewConversation ? NULL : &hCtxt, &InBuffDesc, Attribs, SECURITY_NATIVE_DREP,
			&hCtxt, &OutBuffDesc, &Attribs, &Lifetime);
	if (!SEC_SUCCESS(ss)) {
		errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )		
		qDebug("AcceptSecurityContext failed, Error Code %08x \n",errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::GSC AcceptSecurityContext failed, Error Code %08x"), errorCode);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return FALSE;
	}
	//----------------------------------------------------------------
	// Complete token if applicable.
	if ((SEC_I_COMPLETE_NEEDED == ss) || (SEC_I_COMPLETE_AND_CONTINUE == ss)) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::GSC CompleteAuthToken begin"));
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		ss = CompleteAuthToken(&hCtxt, &OutBuffDesc);
		if (!SEC_SUCCESS(ss)) {
			fprintf(stderr, "complete failed: 0x%08x\n", ss);
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			strDbgMsg = QString::asprintf(("::GSC CompleteAuthToken end failed: 0x%08x"), ss);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
			return FALSE;
		}
	}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::GSC CompleteAuthToken begin end ss 0x%08x"), ss);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	*pcbOut = OutSecBuff.cbBuffer;
	// fNewConversation equals FALSE.
	*pfDone = !((SEC_I_CONTINUE_NEEDED == ss) || (SEC_I_COMPLETE_AND_CONTINUE == ss));
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::GenServerContext END done %d"), *pfDone);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	return TRUE;
} // end GenServerContext()
//*******************************************************************************
// BOOL CSecureSocket::SendMsg(QAbstractSocket s,PBYTE pBuf,DWORD cbBuf)
///
/// ---Detailed Description of the member function-------- 
/// @param[in] s  Instance of socket
/// @param[in] pBuf Pointer to the message buffer to be sent
/// @param[in] cbBuf Number of bytes to be sent
///  
/// @return -- BOOL - Returns TRUE if message is successfully sent
/// 
/// @todo --- Add any todo's into the modules ---
///
//********************************************************************************
BOOL CSecureSocket::SendMsg(PBYTE pBuf, DWORD cbBuf, QAbstractSocket socket) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::SendMsg BEGIN cbBuf %ld socket %lu"), cbBuf, socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	if (0 == cbBuf) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::SendMsg END ZERO buf cbBuf %ld socket %lu"), cbBuf, socket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (TRUE);
	}
	//----------------------------------------------------------------
	// Send the size of the message.
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::SendMsg start SendBytes Sizeof Msg socket %lu"), socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	if (!SendBytes((PBYTE) &cbBuf, sizeof(cbBuf), socket)) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::SendMsg END SendBytes size of msg FAILED socket %lu"), socket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::SendMsg start SendBytes Body Of Msg Begin cbBuf %ld socket %lu"), cbBuf, socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	//----------------------------------------------------------------  
	// Send the body of the message.
	if (!SendBytes(pBuf, cbBuf, socket)) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::SendMsg END SendBytes Body Of msg FAILED socket %lu"), socket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::SendMsg END Successfully cbBuf %ld socket %lu"), cbBuf, socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	return (TRUE);
} // end SendMsg() 
//*********************************************************************************
// BOOL CSecureSocket::ReceiveMsg(PBYTE pBuf, DWORD cbBuf, DWORD *pcbRead)
///
/// ---Detailed Description of the member function-------- 
/// @param[in] pBuf Pointer to the message buffer to be read
/// @param[in] cbBuf Number of bytes to be read
/// @param[out]pcbRead Pointer to message buffer to be read
///  
/// @return -- BOOL - Returns TRUE if message is successfully sent
/// 
/// @todo --- Add any todo's into the modules ---
///
//**********************************************************************************
BOOL CSecureSocket::ReceiveMsg(PBYTE pBuf, DWORD cbBuf, DWORD *pcbRead, QAbstractSocket socket) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::ReceiveMsg BEGIN cbBuf %ld socket %lu"), cbBuf, socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	DWORD cbRead;
	DWORD cbData;
	//-----------------------------------------------------------------
	// Retrieve the number of bytes in the message.
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::ReceiveMsg number of bytes in the message socket %lu"), socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	if (!ReceiveBytes((PBYTE) &cbData, sizeof(cbData), &cbRead, socket)) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::ReceiveMsg number of bytes in the message FAILED socket %lu"), socket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::ReceiveMsg number of read %ld in the message socket %lu"), cbRead, socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	if (sizeof(cbData) != cbRead) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(
				("::ReceiveMsg FAILED to read expected number of bytes in the message socket %lu"), socket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
	//----------------------------------------------------------------
	// Read the full message.
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::ReceiveMsg Read the full message from socket %lu"), socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	cbData = cbBuf;
	if (!ReceiveBytes(pBuf, cbData, &cbRead, socket)) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::ReceiveMsg Read the full message FAILED from socket %lu"), socket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::ReceiveMsg Read the full message bytes %ld read %ld from socket %lu"), cbData,
			cbRead, socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	if (cbRead != cbData) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::ReceiveMsg FAILED to read all bytes in full message socket %lu"), socket);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return (FALSE);
	}
	*pcbRead = cbRead;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::ReceiveMsg END Successfully cbRead %ld socket %lu"), cbRead, socket);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	return (TRUE);
} // end ReceiveMsg()  
//*******************************************************************************
// BOOL CSecureSocket::SendBytes(PBYTE pBuf,DWORD cbBuf)
///
/// ---Detailed Description of the member function-------- 
/// @param[in] pBuf Pointer to the message buffer to be sent
/// @param[in] cbBuf Number of bytes to be sent
///  
/// @return -- BOOL - Returns TRUE if message is successfully sent
/// 
/// @todo --- Add any todo's into the modules ---
///
//********************************************************************************
BOOL CSecureSocket::SendBytes(PBYTE pBuf, DWORD cbBuf, QAbstractSocket socket) {
	PBYTE pTemp = pBuf;
	int cbSent, cbRemaining = cbBuf;
	int errorCode = 0;
	if (0 == cbBuf) {
		return (TRUE);
	}
	while (cbRemaining) {
		cbSent = send(socket, (const char*) pTemp, cbRemaining, 0);
		if (QAbstractSocket_ERROR == cbSent) {
			errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )
			qDebug("Send failed, Error Code %08x \n",errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			QString strDbgMsg;
			strDbgMsg = QString::asprintf(("::SendBytes Send failed, Error Code %08x socket %lu"), errorCode, socket);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
			return FALSE;
		}
		pTemp += cbSent;
		cbRemaining -= cbSent;
	}
	return TRUE;
} // end SendBytes()
//*******************************************************************************
// CSecureSocket::ReceiveBytes(PBYTE pBuf, DWORD cbBuf,DWORD *pcbRead)
///
/// ---Detailed Description -------- 
/// Description  
/// @param[in] pBuf  Pointer to inout buffer
/// @param[in] cbBuf Number of bytes to be read
/// @param[out] pcbRead Pointer to the buffer read
/// @return -- BOOL -- Returns TRUE if the bytes are read successfully
/// 
/// @todo --- Add any todo's into the modules ---
///
//********************************************************************************
BOOL CSecureSocket::ReceiveBytes(PBYTE pBuf, DWORD cbBuf, DWORD *pcbRead, QAbstractSocket socket) {
	PBYTE pTemp = pBuf;
	int cbRead, cbRemaining = cbBuf;
	int errorCode = 0;
	/*int nResult = -1;
	 if((nResult= recv(socket,(LPSTR)pBuf,cbBuf,0))==QAbstractSocket_ERROR)
	 {
	 errorCode = WSAGetLastError();
	 #if defined ( TRACE_ALLOW )
	 qDebug("Recv failed, Error Code %08x \n",errorCode);
	 #endif
	 #ifdef DFL_SECURE_SOCK_DBG_ENABLE
	 QString  strDbgMsg;
	 strDbgMsg = QString::asprintf(("::ReceiveBytes recv failed, Error Code %08x socket %lu"), errorCode, socket);
	 CSecureSocket::LogDebugMessage(strDbgMsg);
	 #endif
	 return FALSE;
	 }
	 *pcbRead =nResult;
	 return TRUE;*/
	while (cbRemaining) {
		cbRead = recv(socket, (char*) pTemp, cbRemaining, 0);
		if (0 == cbRead) {
			break;
		}
		if (QAbstractSocket_ERROR == cbRead) {
			errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )
			qDebug("Recv failed, Error Code %08x \n",errorCode);
#endif
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			QString strDbgMsg;
			strDbgMsg = QString::asprintf(("::ReceiveBytes recv failed, Error Code %08x socket %lu"), errorCode,
					socket);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
			return FALSE;
		}
		cbRemaining -= cbRead;
		pTemp += cbRead;
	}
	*pcbRead = cbBuf - cbRemaining;
	return TRUE;
} // end ReceivesBytes()
//*******************************************************************************
// CSecureSocket::~CSecureSocket()
///
/// ---Detailed Description -------- 
/// Description  
/// @return -- N/A
/// 
/// @todo --- Add any todo's into the modules ---
///
//********************************************************************************
CSecureSocket::~CSecureSocket() {
	//Clear the client info map
	if (m_clientInfoMap.size() > 0) {
		m_clientInfoMap.clear();
	}
	WSACleanup();
} //end ~CSecureSocket()
//*******************************************************************************
// CSecureSocket::CreateCredentials()
///
/// ---Detailed Description -------- 
/// @param[in] LPSTR  Pointer containing the user name
/// Description  
/// @return -- SECURITY_STATUS: Returns 0 is successful
/// 
/// @todo --- Add any todo's into the modules ---
///
//********************************************************************************
SECURITY_STATUS CSecureSocket::CreateCredentials(LPSTR pszUser, CredHandle &hCred, struct _SecHandle &hCtxt) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::CreateCredentials BEGIN "));
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	//  in out
	TimeStamp tsExpiry;
	SECURITY_STATUS Status;
	DWORD cSupportedAlgs = 0;
	ALG_ID rgbSupportedAlgs[16];
	PCCERT_CONTEXT pCertContext = NULL;
	// Open the "MY" certificate store, where IE stores client certificates.
	// Windows maintains 4 stores -- MY, CA, ROOT, SPC. 
	HCERTSTORE hMyCertStore = CertOpenSystemStore(0, L"MY");
	if (!hMyCertStore) {
		DWORD errCode = GetLastError();
		printf("**** Error 0x%x returned by CertOpenSystemStore\n", errCode);
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::CreateCred Error 0x%x returned by CertOpenSystemStore"), errCode);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
		return SEC_E_NO_CREDENTIALS;
	}
	// If a user name is specified, then attempt to find a client
	// certificate. Otherwise, just create a NULL credential.
	if (pszUser) {
		// indexOf client certificate. Note that this sample just searches for a 
		// certificate that contains the user name somewhere in the subject name.
		// A real application should be a bit less casual.
		pCertContext = CertindexOfCertificateInStore(hMyCertStore,								 // hCertStore
				X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,  // dwCertEncodingType
				0, // dwindexOfFlags
				CERT_FIND_SUBJECT_STR_A,						 // dwindexOfType
				pszUser,										 // *pvindexOfPara
				NULL);										 // pPrevCertContext
		if (pCertContext == NULL) {
			DWORD errCode = GetLastError();
			printf("**** Error 0x%x returned by CertindexOfCertificateInStore\n", errCode);
			if (GetLastError() == CRYPT_E_NOT_FOUND)
				printf("CRYPT_E_NOT_FOUND - property doesn't exist\n");
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
			strDbgMsg = QString::asprintf(("::CreateCred Error 0x%x returned by CertindexOfCertificateInStore"),
					errCode);
			CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
			return SEC_E_NO_CREDENTIALS;
		}
	}
	SCHANNEL_CRED sChannelCred;
	// Build Schannel credential structure. Currently, this sample only
	// specifies the protocol to be used (and optionally the certificate, 
	// of course). Real applications may wish to specify other parameters as well.
	ZeroMemory(&sChannelCred, sizeof(sChannelCred));
	sChannelCred.dwVersion = SCHANNEL_CRED_VERSION;
	if (pCertContext) {
		sChannelCred.cCreds = 1;
		sChannelCred.paCred = &pCertContext;
	}
	sChannelCred.grbitEnabledProtocols = SP_PROT_TLS1_2_SERVER;
	ALG_ID aiKeyExch = 0;
	if (aiKeyExch)
		rgbSupportedAlgs[cSupportedAlgs++] = aiKeyExch;
	if (cSupportedAlgs) {
		sChannelCred.cSupportedAlgs = cSupportedAlgs;
		sChannelCred.palgSupportedAlgs = rgbSupportedAlgs;
	}
	sChannelCred.dwFlags |= SCH_CRED_NO_DEFAULT_CREDS;
	// The SCH_CRED_MANUAL_CRED_VALIDATION flag is specified because
	// this sample verifies the server certificate manually. 
	// Applications that expect to run on WinNT, Win9x, or WinME 
	// should specify this flag and also manually verify the server
	// certificate. Applications running on newer versions of Windows can
	// leave off this flag, in which case the InitializeSecurityContext
	// function will validate the server certificate automatically.	 
	//sChannelCred.dwFlags |= SCH_CRED_MANUAL_CRED_VALIDATION;
	// Create an SSPI credential.
	Status = AcquireCredentialsHandle(NULL, // Name of principal  
			UNISP_NAME, // Name of package
			SECPKG_CRED_INBOUND, // Flags indicating use
			NULL, // Pointer to logon ID
			//&m_SchannelCred,  // Package specific data
			&sChannelCred,  // Package specific data
			NULL, // Pointer to GetKey() func
			NULL, // Value to pass to GetKey()
			// &m_hcred, // (out) Cred Handle
			&hCred, &tsExpiry); // (out) Lifetime (optional)
	if (Status != SEC_E_OK) {
		printf("**** Error 0x%x returned by AcquireCredentialsHandle\n", Status);
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
		strDbgMsg = QString::asprintf(("::CreateCred Error 0x%x returned by AcquireCredentialsHandle"), Status);
		CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	}
	// cleanup: Free the certificate context. Schannel has already made its own copy.
	if (pCertContext)
		CertFreeCertificateContext(pCertContext);
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	strDbgMsg = QString::asprintf(("::CreateCredentials END "));
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	return Status;
} //end CreateCredentials()
//***********************************************************************************************
// BOOL CSecureSocket::SendEncrypt(PBYTE pbIoBuffer)
///
/// ---Detailed Description of the member function-------- 
/// @param[in] pbIoBuffer Pointer to the buffer
///  
/// @return -- DWORD - Returns number of encrypted bytes successfully sent
/// 
/// @todo --- Add any todo's into the modules ---
///
//*************************************************************************************************
// The encrypted message is encrypted in place, overwriting the original contents of its buffer
DWORD CSecureSocket::SendEncrypt(PBYTE pbIoBuffer, int len, QAbstractSocket socket, struct _SecHandle hCtxt) {
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf(("::SendEncrypt BEGIN socket = %lu len %d "), socket, len);
	CSecureSocket::LogDebugMessage(strDbgMsg);
#endif
	SECURITY_STATUS scRet; // unsigned long cb

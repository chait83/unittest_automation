/// @file
/// **************************************************************************
/// Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  V6AppInterface 
/// @n Filename:  V6AppInterface.cpp
/// @n Description: Implementation of CV6AppInterface
///
//  **************************************************************************
//  Revision History
//  **************************************************************************
//  $Log[4]:
// 55  Aristos  1.48.1.4.1.0 9/19/2011 4:51:08 PM  Hemant(HAIL) 
//    Stability recorder source code (JI Release) updated for WatchDog
//    Timer functionality.
// 54  Stability Project 1.48.1.4   8/12/2011 11:19:01 AM Hemant(HAIL) 
//    Priority of the thread was lowered to resolve the OPC hang issue.
//    But is was observed that the issue is not getting resolved. Hence
//    Thread Priority is set back to Normal.
// 53  Stability Project 1.48.1.3   7/2/2011 5:02:37 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 52  Stability Project 1.48.1.2   7/1/2011 4:39:14 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
//  $
//
//   Vellaidurai V   2/07/2013   Fixed PAR: 1-3ENNURL - There are some possible mis-uses of the CONFIG_MODIFIABLE configuration data
///***************************************************************************
#include "V6AppInterface.h"
#include "PenManager.h"
#include "MediaManager.h"
#include "BrdInfo.h"
#include "V6globals.h"
#include "CertSubjectsStore.h"
#include "Registry.h"
#include "ThreadInfo.h"
#include "PPL.h"
#include "PMMglobal.h"
//*************************Static Declarations********************************
QMutex CRequestObject::ms_csCriticalSection;
QMutex CRequestObject::ms_csOPCGroupConfigStatus;
std::deque<T_MSGLISTSER_MESSAGE> CRequestObject::ms_dqMessageList;
bool CRequestObject::ms_bInitialised = false;
bool CRequestObject::ms_bOPCGroupConfigStatus = false;
// OPC Server Info
QMutex CRequestObject::ms_csOPCServerInfo; // Critical Section to protect the OPCServer Info Structure.
HANDLE CRequestObject::m_hOPCInfo; // Event to notify to get the OPCInformation.
HANDLE CRequestObject::m_hOPCInfoReqComplete; // Event to notify that OPCInformation updated.
T_OPC_DETAILS CRequestObject::m_sOPCDetails; //Structure to fill the OPCServer Details.
bool CRequestObject::m_bStopOPCInfoThread = true;
//*************************Static Declarations********************************
///****************************************************************************
/// CV6AppInterface : Test main V6App semaphore to determine appplication state
/// 
/// 
/// @return	 	return the state of the application
///				APPACCESS_OK = proceed with call						
///				APPACCESS_LOCKED = Application locked and has not timed out unsafe to proceed with call
///				APPACCESS_SHUTDOWN = Application in shutdown mode, V6AppIntercae should terminate
///
//****************************************************************************
T_APPINTERFACE_SEMAPHORE TestApplicationSema() {
	int lockTimeOut = 100;		/// ten second timeout
	while (GlbAppStateSema == APPACCESS_LOCKED) {
		if (lockTimeOut-- <= 0)
			break;					// The application has been locked for a long time, return this to the calling app
		sleep(100);				// retry in 1/10th of a second
	}
	return GlbAppStateSema;
}
///****************************************************************************
/// CV6AppInterface : GetAddressSpace Function
/// 
///	Return the Address Space Information for OPCA&E Server.
///
/// @param[IN]  USHORT  usGroupNumber - Specify the Group Number.
/// @param[OUT] VARIANT *pvAddressSpace - To fill the Address Space Information
/// 
/// @return	 S_OK -  For successfull operation
///
//****************************************************************************
HRESULT CV6AppInterface::GetAddressSpace( /*[IN]*/USHORT usGroupNumber,
/*[OUT]*/VARIANT *pvAreaSrcList) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_ACCESSDENIED;
	// Variables Declaration
	HRESULT hResult = S_OK;
	// Check for the OUT parameter. 
	if (pvAreaSrcList == NULL)
		return E_POINTER;
	// Get the Pen Manager Handle.
	CPenManager *pPenManager = CPenManager::GetHandle();
	// Fails to get the Pen Manager Handle. 
	if (pPenManager == NULL)
		return E_FAIL;
	// Initialize the SafeArray Bounds.
    pvAreaSrcList->vt = VT_ARRAY | VT_VARIANT;
	SAFEARRAYBOUND aDataItemBounds[1];
	aDataItemBounds[0].lLbound = 0;
	aDataItemBounds[0].cElements = pPenManager->GetGroupList((T_PEN_GROUPS) usGroupNumber)->GetNumberOfPens() + 1;
	// Create the one dimensional Safe Array of type VARIANTS.
	pvAreaSrcList->parray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);
	// If the array could not be created.
	if (pvAreaSrcList->parray == NULL) {
		pvAreaSrcList = NULL;
		return E_OUTOFMEMORY;
	}
	// Initialize the temporary Variant variable.
	VARIANT vAreaSrcItem;
	VariantInit(&vAreaSrcItem);
	// Intialize the Index value to Put the element into the array.
	long lIndex = aDataItemBounds[0].lLbound;
	// Insert the Area in the SafeArray.
	vAreaSrcItem.vt = VT_BSTR;
    QString tempAreaBstr(" ");
	if (pPenManager->GetGroupName((T_PEN_GROUPS) usGroupNumber) != NULL)
        tempAreaBstr = QString::fromWCharArray(pPenManager->GetGroupName((T_PEN_GROUPS) usGroupNumber));
	else
        tempAreaBstr = ("Group 0");
	vAreaSrcItem.bstrVal = tempAreaBstr;
	SafeArrayPutElement(pvAreaSrcList->parray, &lIndex, &vAreaSrcItem);
	lIndex++;
	if ((aDataItemBounds[0].cElements) > 1) {
		for (; lIndex < (static_cast<long>(aDataItemBounds[0].cElements)); lIndex++) {
			// Initialize the Area Source Variant.
			VariantInit(&vAreaSrcItem);
            vAreaSrcItem.vt =  VT_BSTR;
            QString tempSrcBstr = QString::fromWCharArray(
					pPenManager->GetGroupList((T_PEN_GROUPS) usGroupNumber)->GetEntry((USHORT) (lIndex - 1))->GetPenConfigPtr()->Tag);
			vAreaSrcItem.bstrVal = tempSrcBstr;
			// Insert the source items in the SafeArray.
			if (hResult = SafeArrayPutElement(pvAreaSrcList->parray, &lIndex, &vAreaSrcItem)) {
				VariantClear(&vAreaSrcItem);
				SafeArrayDestroy(pvAreaSrcList->parray);
				pvAreaSrcList = NULL;
				return hResult;
			}
		}
	}
	// Address Space Updated for the OPCA&E Server so update the Status as false
	if (m_ReqObj->ms_bInitialised) {
		m_ReqObj->ms_csOPCGroupConfigStatus.lock();
		m_ReqObj->ms_bOPCGroupConfigStatus = false;
		m_ReqObj->ms_csOPCGroupConfigStatus.unlock();
	}
	return hResult;
}
//*****************************IV6MsgListInterface****************************
//****************************************************************************
/// CV6AppInterface : ISAddressSpaceChanged Function
/// 
/// Returns True if there is any change in the Group Configuration.	
///
/// @param[in] None
/// 
/// @return	 S_FALSE -  Group Configuration not changed.
///    S_OK  -  Group Configuration Changed.
///
//****************************************************************************
HRESULT CV6AppInterface::ISAddressSpaceChanged() {
	// Variables Declaration.
	HRESULT hStatus = S_FALSE;
	// Check for the Group Configuration status.
	if (m_ReqObj->ms_bInitialised) {
		m_ReqObj->ms_csOPCGroupConfigStatus.lock();
		if (m_ReqObj->ms_bOPCGroupConfigStatus)
			hStatus = S_OK;
		m_ReqObj->ms_csOPCGroupConfigStatus.unlock();
	}
	return hStatus;
}
//****************************************************************************
/// CV6AppInterface : AckAlm Function
/// 
///	Acknowledge the specified Pen Alarm.
///
/// @param[in] usPenNumber  - Defines the Pen Number.
/// @param[in] usAlmNumber  - Defines the Alarm Number.  
/// 
/// @return	 E_INVALIDARG -  Fails to get the Pen Manager Handle.
///    E_FAIL		  -  Fails to Acknowledge the alarm.
///    S_OK   -  For successfull operation
///
//****************************************************************************
HRESULT CV6AppInterface::AckAlm( /*[IN]*/USHORT usPenNumber,
/*[IN]*/USHORT usAlmNumber) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// TODO: Add your implementation code here
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_ACCESSDENIED;
	// Variables Declaration
	HRESULT hResult = S_OK;
	// Get the Pen Manager Handle.
	CPenManager *pPenManager = CPenManager::GetHandle();
	// Fails to get the Pen Manager Handle. 
	if (pPenManager == NULL)
		return E_FAIL;
	// Acknowledge the Alarm.
	if (pPenManager->AcknowledgeAlarm(NO_GROUP_SINGLE_PEN, (usPenNumber - 1), (usAlmNumber - 1)))
		return E_FAIL;
	return hResult;
}
//****************************************************************************
/// CV6AppInterface :  UpdateMsgs Function
/// 
///	Starts the thread for the Message call back.
///
/// @param[in]	None
/// 
/// @return	 S_OK	-  For successfull operation.
///
//****************************************************************************
HRESULT CV6AppInterface::UpdateMsgs() {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Variables Declaration
	HRESULT hResult = S_OK;
	// If Thread is not running.
	if (m_hlMsgSubHdl == NULL) {
		// Create the Thread.
		SECURITY_ATTRIBUTES sSecAttr;
		sSecAttr.nLength = sizeof(sSecAttr);
		sSecAttr.lpSecurityDescriptor = NULL;
		DWORD dwThreadId = 0;
		m_hlMsgSubHdl = CreateThread(&sSecAttr, 0, (LPTHREAD_START_ROUTINE) & SendMsgs, this, 0, &dwThreadId);
		//
		// Stability Project Fix:
		// 
		// Priority of the thread was lowered to resolve the OPC hang issue
		// But is was observed that the issue is not getting resolved.
		// Hence Thread Priority is set back to Normal.
		//
		//SetThreadPriority( m_hlMsgSubHdl, THREAD_PRIORITY_LOWEST );
	}
	return hResult;
}
//****************************************************************************
/// CV6AppInterface : SendMsgs
/// 
/// Static functiom to call the thread procedure. 
///
/// @param[in] pThreadFunc - Void pointer.
/// 
/// @return	 UINT 
///			 Zero  - For the unreported errors.  
///    One - For SuccessFull Operation.
///    
///
//****************************************************************************
UINT __cdecl CV6AppInterface::SendMsgs( /*[IN] */void *pThreadFunc) {
	// Call thread procedure.
	return ((CV6AppInterface*) pThreadFunc)->SendMsgsFunc();
}
//****************************************************************************
/// CV6AppInterface : SendMsgsFunc
/// 
/// Thread Function Implementation.
/// 
/// @param[in] None
/// 
/// @return	  Zero  - For the unreported errors.  
///     One - For SuccessFull Operation.
//****************************************************************************
UINT CV6AppInterface::SendMsgsFunc() {
	// Variables Declarations
	HRESULT hResult = S_OK;
	DWORD dwStartTickCount = 0;
	T_MSGLISTSER_MESSAGE rtMsg;
	// Initialize COM for use by the current thread. 
	hResult = CoInitializeEx( NULL, COINIT_MULTITHREADED);
	if (FAILED(hResult))
		return 0;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for OPC Send Msg Thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the OPC SendMsg thread has 
		//started
        pThreadInfo->UpdateThreadInfo(AM_OPC_SEND_MSG_THREAD, true);
	}
	try {
		while (true) {
			// Check the V6App Shutdown Status.
			if (GlbAppStateSema == APPACCESS_SHUTDOWN) {
				// Uninitialize the COM Library.
				CoUninitialize();
				if (pThreadInfo != NULL) {
					//Update the info that the OPCSend Msg thread is exiting
					//Hence this thread need not be considered to kick the 
					//watchdog
                    pThreadInfo->UpdateThreadInfo(AM_OPC_SEND_MSG_THREAD, false);
				}
				return 1;
			}
			// Get the tick count.
			dwStartTickCount = GetTickCount();
			// Extract the message and send to the OPCA&E Server.
			if (m_ReqObj->PopMsg(rtMsg))
				SendMessage(rtMsg);
			// Get the current tick count to find the elapsed time.
			DWORD dwEndTickCount = GetTickCount();
			DWORD dwElapsedTime = dwEndTickCount - dwStartTickCount;
			// Set to zero when the system runs continuously for 49.7 days 
			if (dwEndTickCount < dwStartTickCount)
				dwElapsedTime = 0;
			// Check for the Elapsed time.
			if (dwElapsedTime < m_dwMessSubsRate)
				sleep(m_dwMessSubsRate - dwElapsedTime);
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the OPC SendMsg 		
				//thread after each iteration
                pThreadInfo->UpdateThreadCounter(AM_OPC_SEND_MSG_THREAD);
			}
		}
	}
	catch (...) {
		// Uninitialize the COM Library.
		CoUninitialize();
		if (pThreadInfo != NULL) {
			//Update the info that the OPCSend Msg thread is exiting
			//Hence this thread need not be considered to kick the 
			//watchdog
            pThreadInfo->UpdateThreadInfo(AM_OPC_SEND_MSG_THREAD, false);
		}
		return 0;
	}
	CoUninitialize();
	if (pThreadInfo != NULL) {
		//Update the info that the OPCSend Msg thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
        pThreadInfo->UpdateThreadInfo(AM_OPC_SEND_MSG_THREAD, false);
	}
	return 1;
}
//****************************************************************************
/// CV6AppInterface : SendMessage
/// 
/// Send Messages to OPC Link Layer for A&E Server.
/// 
/// @param[in] T_MESSAGE_FILTER - Filter Type
/// 
/// @return	 HRESULT
///
///			S_OK - Successful operation
///			
//****************************************************************************
void CV6AppInterface::SendMessage(T_MSGLISTSER_MESSAGE rtMsg) {
	// Variables Declaration.
	HRESULT hResult = S_OK;
    QString bstrMsg("");	  // BSTR to hold the Message Text.
    QString bstrPenName("");	// BSTR to hold the Pen Tag Name.
    QString bstrGrpName("");	// BSTR to hold the Group Name.
	T_MESSAGE_FILTER eMsgFilter;
	USHORT usMsgType = 0, usPenNumber = 0, usAlmNumber = 0, usAlmType = 0;
	CDataItemAlarm *pAlarmDataItem = NULL;
	CDataItemPen *pPenDataItem = NULL;
	BOOL bLatch = false;
	float fAlmLevel = 0.0f;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return;
	// Select the Type of Filter.
	switch (rtMsg.messageType) {
	case MSGLISTSER_ALARM_INTO:
	case MSGLISTSER_ALARM_OUTOF:
	case MSGLISTSER_ALARM_OUTOF_NOT_ACK:
	case MSGLISTSER_ALARM_ACK_WHILE_IN:
	case MSGLISTSER_ALARM_ACK_WHILE_OUT:
		eMsgFilter = mfAlarm;
		break;
	case MSGLISTSER_SYSTEM_INFORMATION:
	case MSGLISTSER_SYSTEM_WARNING:
	case MSGLISTSER_SYSTEM_ERROR:
		eMsgFilter = mfSystem;
		break;
	case MSGLISTSER_DIAGNOSTIC_INFO:
	case MSGLISTSER_DIAGNOSTIC_WARNING:
	case MSGLISTSER_DIAGNOSTIC_ERROR:
		eMsgFilter = mfDiagnostic;
		break;
	case MSGLISTSER_SECURITY_LOG_ON:
	case MSGLISTSER_SECURITY_LOG_OFF:
	case MSGLISTSER_SECURITY_PASSWORD_FAILURE:
	case MSGLISTSER_SECURITY_USERNAME_FAILURE:
	case MSGLISTSER_SECURITY_DAYMASK_FAILURE:
	case MSGLISTSER_SECURITY_LOGINTIME_FAILURE:
	case MSGLISTSER_SECURITY_USERLEVEL_FAILURE:
	case MSGLISTSER_SECURITY_PASSWORD_EXPIRED:
	case MSGLISTSER_SECURITY_PASSWORD_LOCKED:
	case MSGLISTSER_SECURITY_INVALID_USER_ID:
	case MSGLISTSER_SECURITY_VALID_AREA:
	case MSGLISTSER_SECURITY_INVALID_USER_AREA:
		eMsgFilter = mfSecurity;
		break;
	case MSGLISTSER_USER_BATCH_GENERIC:
	case MSGLISTSER_USER_GROUP_MARK_ON_CHART:
	case MSGLISTSER_USER_MODBUS_MESSAGE:
    case MSGLISTSER_USER_GROUPOTALS_STARTED:
    case MSGLISTSER_USER_GROUP_TOTALS_PAUSED:
    case MSGLISTSER_USER_GROUP_TOTALS_RESUMED:
    case MSGLISTSER_USER_GROUP_TOTALS_RESET:
	case MSGLISTSER_USER_GROUP_MAX_MIN_RESET:
	case MSGLISTSER_USER_GROUP_ALARM_CHANGE:
	case MSGLISTSER_DIGITAL_ACTIVATE:
	case MSGLISTSER_DIGITAL_DEACTIVATE:
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_PAUSE:
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_STOP:
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_RESUME:
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_CLEAR:
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_PREFILL:
	case MSGLISTSER_USER_GROUP_CLEAR_MESSAGE_LIST:
	case MSGLISTSER_USER_GROUP_START_LOGGING_CHART:
	case MSGLISTSER_USER_GROUP_STOP_LOGGING_CHART:
	default:
		eMsgFilter = mfUser;
		break;
	}
	// Messages Other than Alarm.
	if (eMsgFilter != mfAlarm) {
		// Get the Message Text.
        bstrMsg = QString::fromWCharArray(rtMsg.messageText);
		// Call Back the Event Message to OPCA&E Server.
		Fire_OnEvtMsg(eMsgFilter, rtMsg.messageId, rtMsg.logTime, bstrMsg);
	}
	else {
		// Get the Message Text.
        bstrMsg = QString::fromWCharArray(rtMsg.messageText);
		// Get the Message Type.
		usMsgType = rtMsg.messageType;
		// Get the Pen and Alarm Number.
		usPenNumber = rtMsg.messageData.uCharParam[MSGLISTSER_ALARM_PEN_NUMBER_UCHAR_ELEMENT];
		usAlmNumber = rtMsg.messageData.uCharParam[MSGLISTSER_ALARM_NUMBER_UCHAR_ELEMENT];
		fAlmLevel = rtMsg.messageData.floatParam[MSGLISTSER_ALARM_LEVEL_FLOAT_ELEMENT];
		// Get the Alarm Type.
        usAlmType = rtMsg.messageData.uCharParam[MSGLISTSER_ALARM_TYPE_UCHAR_ELEMENT];
		// Get the Latch Information for the AckRequired Parameter.
		pAlarmDataItem = (CDataItemAlarm*) pGlbDIT->GetDataItemPtr(DI_ALARM, (usAlmNumber - 1), (usPenNumber));
		if (pAlarmDataItem->GetAlarmConfig()->Latched == TRUE)
			bLatch = true;
		// Get the Pen tag.
		pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, usPenNumber);
        bstrPenName = QString::fromWCharArray(pPenDataItem->GetPenConfig()->Tag);
		// Get the Group Name.
		CPenManager *pPenManager = CPenManager::GetHandle();
		if (pPenManager->GetGroupName((T_PEN_GROUPS) pPenDataItem->GetPenConfig()->GroupNumber) != NULL) {
            bstrGrpName = QString::fromWCharArray(pPenManager->GetGroupName((T_PEN_GROUPS) pPenDataItem->GetPenConfig()->GroupNumber));
		} else {
            bstrGrpName = ("Group 0");
		}
		// Call Back the Alarm Message to OPCA&E Server.
		hResult = Fire_OnAlmMsg(usMsgType, rtMsg.messageId, rtMsg.logTime, bstrMsg, bstrPenName, (usPenNumber + 1),
				usAlmNumber, bstrGrpName, usAlmType, fAlmLevel, bLatch);
	}
	// Release the Memory allocated to BSTRs.

}
//************************ IV6AppInterface*************************************
//****************************************************************************
/// CV6AppInterface : TestCall Function
/// 
///
/// @param[in] value - Input Value
/// @param[out] result - Returns the double value of the input parameter.
/// 
/// @return	 S_OK  - For successfull operation
//****************************************************************************
HRESULT CV6AppInterface::TestCall( /*[IN]*/SHORT value, /*[OUT]*/SHORT *result) {
    // AFX_MANAGE_STATE(AfxGetStaticModuleState())
	// TODO: Add your implementation code here
			* result = value * 2;
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : SetProductionInformation Function
/// 
///	Set the production information.
///
/// @param[in]  -  VARIANT  vProductionInfo - Variant conating the Production Info.
/// 
/// @return	 S_OK  - For successfull operation
///			 E_FAIL	 - Fails to get the global System Info Pointer.
//****************************************************************************
HRESULT CV6AppInterface::SetProductionInformation( /*[IN]*/VARIANT vProdInfoVarVal) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_ACCESSDENIED;
	HRESULT hResult = S_OK;
	// If the global System Info pointer is not available
	if ( pSYSTEM_INFO == NULL || pDALGLB == NULL)
		return E_FAIL;
	VARIANT *pvProdInfoValues = NULL;
	// vProdInfoVarVal type must be VT_ARRAY|VT_VARINAT.
	if (!((vProdInfoVarVal.vt & VT_ARRAY) && (vProdInfoVarVal.vt & VT_VARIANT)))
		return E_INVALIDARG;
	// If the safeArray Pointer is NULL.
	if (vProdInfoVarVal.parray == NULL)
		return E_INVALIDARG;
	// Extract the safe array
	if (hResult = SafeArrayAccessData((vProdInfoVarVal.parray), (void**) &pvProdInfoValues))
		return hResult;
	hResult = SafeArrayUnlock((vProdInfoVarVal.parray));
	try {
		// Structure to fill the production information.
		T_RECPROD sProdInfo;
		// Fill the production information.
        pvProdInfoValues->bstrVal.toWCharArray( sProdInfo.ModelNoDisplay);	 ///< Display version of model number
        (pvProdInfoValues + 1)->bstrVal.toWCharArray(sProdInfo.mfrsSerialNo);	   ///< Manufacturing serial number
        (pvProdInfoValues + 2)->bstrVal.toWCharArray(sProdInfo.SalesOrder);///< Sales Order Number
		// Born Date 
		QString szBirthDate = ((pvProdInfoValues + 3)->bstrVal);
		// indexOf the Time Value
		ltime_2 sTime;
        QStringList lst = szBirthDate.split("/");
        QString szMonth = "";
        QString szDay = "";
        QString szYear = "";
        if(lst.length() ==3){
            szMonth = lst[0];
            szDay = lst[1];
            szYear = lst[2];
        }
		// indexOf the year of the Born Date.
        unsigned int year = szYear.toInt();
		year = year - 1994;
		// Fill the structure.
        sTime.day = szDay.toUShort();
		sTime.hour = 0;
		sTime.istime = 1;
		sTime.min = 0;
        sTime.month =szMonth.toUShort();
		sTime.sec = 0;
		sTime.year = year;
		// Get the bithdate. 
        CTVtime tvTime(&sTime);
		sProdInfo.BirthDate = tvTime.GetMicroSecs();	   ///< Birth Date
        (pvProdInfoValues + 4)->bstrVal.toWCharArray(sProdInfo.KeyNumber); ///< MSG Key Number
        (pvProdInfoValues + 5)->bstrVal.toWCharArray(sProdInfo.Table1_IOTop);   ///< Table 1 top slot IO
        (pvProdInfoValues + 6)->bstrVal.toWCharArray(sProdInfo.Table2_IOBot);   ///< Table 2 top slot IO
        (pvProdInfoValues + 7)->bstrVal.toWCharArray(sProdInfo.Table3_Power);   ///< Table 3 Power
        (pvProdInfoValues + 8)->bstrVal.toWCharArray(sProdInfo.Table4_memory);   ///< Table 4 internal memory expansion
        (pvProdInfoValues + 9)->bstrVal.toWCharArray(sProdInfo.Table5_Credits);   ///< Table 5 credits
        (pvProdInfoValues + 10)->bstrVal.toWCharArray(sProdInfo.Table6_Options);  ///< Table 6 Options
        (pvProdInfoValues + 11)->bstrVal.toWCharArray(sProdInfo.Table7_OEM); ///< Table 7 OEM or private label.

		sProdInfo.Warranty = (pvProdInfoValues + 12)->uiVal;   ///< Number of warranty changes
		sProdInfo.Repaired = (pvProdInfoValues + 13)->uiVal;   ///< Number of times repaired
		sProdInfo.Upgrade1 = (pvProdInfoValues + 14)->uiVal;   ///< Number of upgrades 1
		sProdInfo.Upgrade2 = (pvProdInfoValues + 15)->uiVal;   ///< Number of upgrades 2
		sProdInfo.Upgrade3 = (pvProdInfoValues + 16)->uiVal;   ///< Number of upgrades 3
		pSYSTEM_INFO->SetProductionInfo(&sProdInfo);
		// Set the serial number.
		pSYSTEM_INFO->SetSerialNumber((pvProdInfoValues + 17)->ulVal);
		QString szOctet = (pvProdInfoValues + 18)->bstrVal;
        bool res = false;
        USHORT nFourthOctetVal = szOctet.toUShort(&res, 16);
		szOctet = (pvProdInfoValues + 19)->bstrVal;
        USHORT nFifthOctetVal = szOctet.toUShort(&res, 16);
		szOctet = (pvProdInfoValues + 20)->bstrVal;
        USHORT nSixthOctetVal = szOctet.toUShort(&res, 16);
		// Set the MACAddress.
		if (!(pDALGLB->SetMACAddress(static_cast<UCHAR>(nFourthOctetVal), static_cast<UCHAR>(nFifthOctetVal),
				static_cast<UCHAR>(nSixthOctetVal)))) {
			return E_INVALIDARG;
		}
		// Set firmware options code.
        if (!(pSYSTEM_INFO->ValidateOptionsCode(QString::fromWCharArray(sProdInfo.Table6_Options)))) {
			return E_INVALIDARG;
		}
	}
	catch (...) {
		return E_INVALIDARG;
	}
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : GetModelNumber Function
/// 
///	Returns the Model Number of the Recorder.
///
/// @param[out]  - VARIANT* pvProdModelNumber
/// 
/// @return	 S_OK  - For successfull operation
///			 E_FAIL	 - Fails to get the global System Info Pointer.
///			 E_POINTER - OUT parameter is NULL.
//****************************************************************************
HRESULT CV6AppInterface::GetModelNumber( /*[OUT]*/VARIANT *pvProdModelNumber) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_ACCESSDENIED;
	// If the global System Info pointer is not available
	if ( pSYSTEM_INFO == NULL)
		return E_FAIL;
	// If the OUT parameter is NULL.
	if (pvProdModelNumber == NULL)
		return E_POINTER;
	// Only build the product information whan it's requested by the configuration tool
	pSYSTEM_INFO->BuildProductionInfo();
	// Get the Production Information.
	T_RECPROD sProdInfo = pSYSTEM_INFO->GetProductionInfo();
	// Fill the out parameter for the Model Number.
	pvProdModelNumber->vt = VT_BSTR;
    QString bstrModNum= QString::fromWCharArray(sProdInfo.ModelNoDisplay);
	//PSR - Coverity issue fix --COM object use after free #770895
    pvProdModelNumber->bstrVal ="";
    return (HRESULT)S_OK;
}
//****************************************************************************
/// CV6AppInterface : SetRecorderInTestMode Function
/// 
///	Set the Recorder into the test mode.
///
/// @param[in] - None
/// 
/// @return	 S_OK  -  For successfull operation
///			 E_FAIL	 -  Fails to get the global System Info Pointer.
///			 E_FAIL	 -  Fails to save the flash.
//****************************************************************************
HRESULT CV6AppInterface::SetRecorderInTestMode() {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_ACCESSDENIED;
	// If the global System Info pointer is not available
	if ( pSYSTEM_INFO == NULL)
		return E_FAIL;
	// Set the recorder inton the test mode.
	pSYSTEM_INFO->SetUnitIntoTestMode();
	// Call save to the flash.
	if (!(pSYSTEM_INFO->NVSaveToFlash()))
		return E_FAIL;
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : SetTimeDate Function
/// 
///	Set (production) time and date.
///
/// @param[in]  -  VARIANT  vTimeDateVarVal - Variant conating the time and date.
/// 
/// @return	 S_OK  - For successfull operation
///			 E_FAIL	 - Fails to get the global System Info Pointer.
//****************************************************************************
HRESULT CV6AppInterface::SetTimeDate( /*[IN]*/VARIANT vCurrentTime) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_ACCESSDENIED;
	HRESULT hResult = S_OK;
	// If the global System Info pointer is not available
	if ( pSYSTEM_INFO == NULL || pDALGLB == NULL)
		return E_FAIL;
	VARIANT *pvTimeDateValues = NULL;
	//  type must be VT_ARRAY|VT_VARIANT.
	if (!((vCurrentTime.vt & VT_ARRAY) && (vCurrentTime.vt & VT_VARIANT)))
		return E_INVALIDARG;
	// If the safeArray Pointer is NULL.
	if (vCurrentTime.parray == NULL)
		return E_INVALIDARG;
	// Extract the safe array
	if (hResult = SafeArrayAccessData((vCurrentTime.parray), (void**) &pvTimeDateValues))
		return hResult;
	hResult = SafeArrayUnlock((vCurrentTime.parray));
	try {
        SYSTEMTIME stOld;
		GetV6LocalTime(&stOld);
		QString szTime = (pvTimeDateValues + 0)->bstrVal;
		QString szDate = (pvTimeDateValues + 1)->bstrVal;
		// indexOf the time values

        QStringList lst = szDate.split("/");
        QString szMonth = "";
        QString szDay = "";
        QString szYear = "";
        if(lst.length() ==3){
            szMonth = lst[0];
            szDay = lst[1];
            szYear = lst[2];
        }

        lst = szTime.split(":");
        QString szHours = "";
        QString szMinutes = "";
        QString szSeconds = "";
        if(lst.length() ==3){
            szHours = lst[0];
            szMinutes = lst[1];
            szSeconds = lst[2];
        }
		// indexOf the date values
      // Fill the structure.
        stOld.wDay = szDay.toUShort();
        stOld.wMonth = szMonth.toUShort();
        stOld.wYear = szYear.toUShort();
        stOld.wHour = szHours.toUShort();
        stOld.wMinute = szMinutes.toUShort();
        stOld.wSecond = szSeconds.toUShort();
        qDebug()<<"Time "<< szTime<<"\n";
        qDebug()<<"Date "<< szDate<<"\n";
        SetV6LocalTime(&stOld);
	}
	catch (...) {
		return E_INVALIDARG;
	}
	return S_OK;
}
//************************ IV6DITInterface*************************************
//****************************************************************************
/// CV6AppInterface : GetDataItem Function
/// 
/// This function returns the Data Item Values for specified type, reference 
/// and instance. This function is written to provide data access to OPC
/// Server and WebSerevr. 
///
/// @param[in] type - Defines the type of the DataItemContainer.
/// @param[in] ref  - Defines the SubType of the DataItem.  
/// @param[in] instance - Defines the instance of the DataItem.   
/// @param[in] dwCount - Defines Number of atrributes that are required.
/// @param[in] vIndexValues - Defines Index Values for the Required Attributes
/// @param[out] pvDataItemValues - Variant Pointer to return the Data Item Values.
/// 
/// @return	 E_POINTER  -  If the OUT Parameter have NULL Value.
///    E_INVALIDARG -  If the input parameters are Invalid. 	
///    E_FAILURE  -  Fails to get the Global DataItem Pointer.
///    S_OK   -  For successfull operation
///
//****************************************************************************
HRESULT CV6AppInterface::GetDataItem( /*[IN]*/unsigned short type,
/*[IN]*/unsigned short ref,
/*[IN]*/unsigned short instance,
/*[IN]*/DWORD dwCount,
/*[IN]*/VARIANT vIndexValues,
/*[OUT]*/VARIANT *pvDataItemValues) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	// Variables Declaration
	HRESULT hResult = S_OK;
	// If the global DIT pointer is not available
	if (pGlbDIT == NULL) {
		pvDataItemValues = NULL;
		return E_FAIL;
	}
	// Check for the OUT parameter. 
	if (pvDataItemValues == NULL)
		return E_POINTER;
	// Check for the type of the container.
    if (type < 0 || type > DI_MAX_DATA_ITEM_TYPES) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Check for the Counts of Attributes.
	if (dwCount < 0 || dwCount > DI_VAL_MAX) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// indexOf the DataItem Pointer for the specified type, subtype and instance.
    CDataItem *pDataItem = (CDataItem*) pGlbDIT->GetDataItemPtr((T_DATA_ITEM_TYPE) type, ref, instance);
	// If fails to get the DataItem Pointer.
	if (pDataItem == NULL) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Get the DataItem values in the OUT parameter.
	hResult = GetData(pDataItem, dwCount, vIndexValues, pvDataItemValues);
	return hResult;
}
//****************************************************************************
/// CV6AppInterface : GetDataItemFromVarName Function
/// 
/// This function returns the Data Item Values for  specified Variable Name.
/// This function is written to provide data access to OPC Server and WebSerevr. 
///
/// @param[in] vItemVarName - Variant that specifies the Variable Name.
/// @param[in] dwCount - Defines Number of atrributes that are required.
/// @param[in] vIndexValues - Defines Index Values for the Required Attributes
/// @param[out] pvDataItemValues - Pointer to the Variant to fill the Data Item Values.
/// 
/// @return	 E_POINTER   - If the OUT Parameter have NULL Value.
///    E_INVALIDARG  - If the variable name is not valid. 	
///    E_INVALIDARG  - Fails to get the DataItem Pointer for the specified DataItem.
///    E_FAIL    - Fails to get the Global DataItem Pointer.
///    S_OK    - For successfull operation.
///
//****************************************************************************
HRESULT CV6AppInterface::GetDataItemFromVarName( /*[IN]*/VARIANT vItemVarName,
/*[IN]*/DWORD dwCount,
/*[IN]*/VARIANT vIndexValues,
/*[OUT]*/VARIANT *pvDataItemValues) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	HRESULT hr;
	int nLookUpRef;
	// If the Global DIT Pointer is NULL.
	if (pGlbDIT == NULL) {
		pvDataItemValues = NULL;
		return E_FAIL;
	}
	// Check for OUT parameter. 
	if (pvDataItemValues == NULL)
		return E_POINTER;
	// Check for the Counts of Attributes.
	if (dwCount < 0 || dwCount > DI_VAL_MAX) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Chacek the type of variant that conatins the variable name.
	if (!((vItemVarName.vt & VT_VARIANT) && (vItemVarName.vt & VT_BYREF))) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	//  If pointer to SafeArray Variant is NULL.
	if (vItemVarName.pvarVal == NULL) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Variant to Collect the Variable Name.
	VARIANT vVarName;
	VariantInit(&vVarName);
    QString sVarNameBstr;
	// pvarVal points to VARIANT of type VT_BSTR.
	VariantCopyInd(&vVarName, vItemVarName.pvarVal);
	// Get the Data Item variable Name.
	sVarNameBstr = vVarName.bstrVal;
	// Get the Variable Name Look Up Ref Number.
	nLookUpRef = pGlbDIT->LookUp(sVarNameBstr);
	// If the Invalid Variable Name 
	if (nLookUpRef == -1) {
		VariantClear(&vVarName);
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// indexOf the DataItem Pointer for the specified type, subtype and instance.
	CDataItem *pDataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(nLookUpRef);
	// If fails to get the DataItem Pointer.
	if (pDataItem == NULL) {
		pvDataItemValues = NULL;
		VariantClear(&vVarName);
		return E_INVALIDARG;
	}
	// Get the Data Item Values in the OUT parameter.
	hr = GetData(pDataItem, dwCount, vIndexValues, pvDataItemValues);
	//Clear the Variant (CR 3097)

	sVarNameBstr = "";
	VariantClear(&vVarName);
	return hr;
}
//****************************************************************************
/// CV6AppInterface : SetDataItem Function
/// 
/// This function will set values for the Data Items specified by type,reference 
/// and instance.This function is written to provide data access to OPC
/// Server and WebSerevr. 
///
/// @param[in] type - Defines the type of the DataItemContainer.
/// @param[in] ref  - Defines the SubType of the DataItem  
/// @param[in] instance - Defines the instance of the DataItem.   
/// @param[in] dwIndex - Specifies the Index for the DataItem Value to be written.
/// @param[in] pDataItemValues - Pointer to the Variant that specifies the item value
///          to be written
/// 
/// @return	 E_POINTER   -  If the IN Parameter have NULL Value.
///    E_INVALIDARG  -  If the type is not valid. 	
///    E_INVALIDARG  -  Fails to get the DataItem Pointer for the specified DataItem.
///    E_FAIL    -  Fails to get the Global DataItem Pointer.
///    S_OK    -  For successfull operation
///
//****************************************************************************
HRESULT CV6AppInterface::SetDataItem( /*[IN]*/unsigned short type,
/*[IN]*/unsigned short ref,
/*[IN]*/unsigned short instance,
/*[IN]*/DWORD dwIndex,
/*[IN]*/VARIANT vDataItemValues) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	HRESULT hr;
	// Fails to get the Global DIT pointer.
	if (pGlbDIT == NULL)
		return E_FAIL;
	// Check for the inedx of the data item value.
	if ((((DI_VALUES) dwIndex) >= DI_VAL_MAX) || ((DI_VALUES) dwIndex) < 0)
		return E_INVALIDARG;
	// Check for the type of the container.
    if (type < 0 || type > DI_MAX_DATA_ITEM_TYPES)
		return E_INVALIDARG;
	// indexOf the DataItem Pointer for the specified type, subtype and instance.
    CDataItem *pDataItem = (CDataItem*) pGlbDIT->GetDataItemPtr((T_DATA_ITEM_TYPE) type, ref, instance);
	// If fails to get the DataItem Pointer.
	if (pDataItem == NULL) {
		return E_INVALIDARG;
	}
	// Set the values for the Data Item specified by the Index.
	hr = SetData(pDataItem, dwIndex, vDataItemValues);
	return hr;
}
//****************************************************************************
/// CV6AppInterface : SetDataItemFromVarName Function
/// 
/// This function will set the Data Item Values for  specified Variable Name.
/// This function is written to provide data access to OPC Server and WebSerevr. 
///
/// @param[in] pvItemVarName - Pointer to Variant that specifies the Variable Name.
/// @param[in] dwIndex - Specifies the Index for the DataItem Value to be written.
/// @param[in] pDataItemValues - Pointer to the Variant that specifies the 
///          DataItemValues
/// 
/// @return	 E_POINTER  - If the IN Parameters have NULL Values.
///    E_INVALIDARG - If the variable name is not valid. 	
///    E_FAIL   - Fails to get the global DataItem Pointer.
///    S_OK   - For successfull operation
///
//****************************************************************************
HRESULT CV6AppInterface::SetDataItemFromVarName(/*[IN]*/VARIANT vItemVarName,
/*[IN]*/DWORD dwIndex,
/*[IN]*/VARIANT vDataItemValues) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	// TODO: Add your implementation code here
	HRESULT hr;
	int nLookUpRef;
	// Fails to Get the Global DIT Pointer.
	if (pGlbDIT == NULL)
		return E_FAIL;
	// Chacek the type of variant that conatins the variable name.
	if (!(vItemVarName.vt & VT_BYREF) && (vItemVarName.vt & VT_VARIANT))
		return E_INVALIDARG;
	if (vItemVarName.pvarVal == NULL)
		return E_INVALIDARG;
	// Variant to Collect the Variable Name.
	VARIANT vVarName;
	VariantInit(&vVarName);
    QString sVarNameBstr;
	// pvarVal points to VARIANT of type VT_BSTR.
	VariantCopyInd(&vVarName, vItemVarName.pvarVal);
	// Get the Data Item variable Name.
	sVarNameBstr = vVarName.bstrVal;
	// Get the Variable Name Look Up Ref Number.
	nLookUpRef = pGlbDIT->LookUp(sVarNameBstr);
	// If the Invalid Variable Name 
	if (nLookUpRef == -1) {
		sVarNameBstr = "";
		VariantClear(&vVarName);
		return E_INVALIDARG;
	}
	// indexOf the DataItem Pointer for the specified type, subtype and instance.
	CDataItem *pDataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(nLookUpRef);
	// If fails to get the DataItem Pointer.
	if (pDataItem == NULL) {
		sVarNameBstr = "";
		VariantClear(&vVarName);
		return E_INVALIDARG;
	}
	// Set the DataItem Value for the Specified Index.
	hr = SetData(pDataItem, dwIndex, vDataItemValues);
	//Clear the Variant 
	
	sVarNameBstr = "";
	VariantClear(&vVarName);
	return hr;
}
//****************************************************************************
/// CV6AppInterface : GetData
/// 
/// This function retrieve the Data Item Values. 
/// This function is called by GetDataItem and GetDataItemValues. 
///
/// @param[in] pDataItem - Data Item Pointer. 
/// @param[in] dwCount - No. Of attributes for which values to be returned.
/// @param[in] vIndexValues - Variant to SafeArray that contains the Index Values.
/// @param[out] pvDataItemValues - OUT parameter to return the data item values.
/// 
/// @return	 E_OUTOFMEMORY - Unable to create the safe array
///    S_OK    - For successfull operation
///
//****************************************************************************
HRESULT CV6AppInterface::GetData( /*[IN]*/CDataItem *pDataItem,
/*[IN]*/DWORD dwCount,
/*[IN]*/VARIANT vIndexValues,
/*[OUT]*/VARIANT *pvDataItemValues) {
	// Variables Declaration
	HRESULT hResult;
    CTVtime tempTime;
	double dTime;
    QString psTempUnits = NULL;
    const QString psTempTagName = "";
	ULONG *plColor = NULL;
	QString psTempVarName = NULL;
    QString sTempUnits, sTempTag, sTempBstr("");
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	// IndexValues type must be VT_BYREF|VT_VARINAT.
	if (!((vIndexValues.vt & VT_BYREF) && (vIndexValues.vt & VT_VARIANT))) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// If the pointer to safeArray Pointer is NULL
	if (vIndexValues.pvarVal == NULL) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Variants to collect the Index Values
	VARIANT vIndexVarVal;
	VariantInit(&vIndexVarVal);
	VARIANT *pvIndex = NULL;
	// Extract the variant that points to the safearray.
	VariantCopyInd(&vIndexVarVal, vIndexValues.pvarVal);
	// IndexValues type must be VT_BYREF|VT_VARINAT.
	if (!((vIndexVarVal.vt & VT_ARRAY) && (vIndexVarVal.vt & VT_VARIANT))) {
		VariantClear(&vIndexVarVal);
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// If the safeArray Pointer is NULL.
	if (vIndexVarVal.parray == NULL) {
		VariantClear(&vIndexVarVal);
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	long lLBound, lUBound;
	// Get the Lower bound of the SafeArray.
    if ((hResult = SafeArrayGetLBound(vIndexVarVal.parray, 1, &lLBound))) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Get the Upper bound of the SafeArray.
	if (hResult = SafeArrayGetUBound(vIndexVarVal.parray, 1, &lUBound)) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Get the count of elements.
	long cElements = lUBound - lLBound + 1;
	// If the Mismatch between the No of items and SafeArray Elements.
	if (cElements != dwCount) {
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Extract the safe array
	if (hResult = SafeArrayAccessData((vIndexVarVal.parray), (void**) &pvIndex)) {
		pvDataItemValues = NULL;
		return hResult;
	}
	SafeArrayUnlock(vIndexVarVal.parray);
	// Initialize the Safe Array and Defines the Lower Bound and Total Number of Elements.
	// Assign the SafeArray to OUT parameter	
	pvDataItemValues->vt = VT_ARRAY | VT_VARIANT;
	SAFEARRAYBOUND aDataItemBounds[1];
	aDataItemBounds[0].lLbound = 0;
	aDataItemBounds[0].cElements = dwCount;
	// Create the one dimensional Safe Array of type VARIANTS.
	pvDataItemValues->parray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);
	// If the array could not be created.
	if (pvDataItemValues->parray == NULL) {
		SafeArrayDestroy(vIndexVarVal.parray);
		pvDataItemValues = NULL;
		return E_OUTOFMEMORY;
	}
	// Initialize the temporary Variant variable.
	VARIANT vDataItem;
	VariantInit(&vDataItem);
	// Intialize the Index value to Put the element into the array.
	long lIndex = aDataItemBounds[0].lLbound;
	//E528446
	CPenManager *pkPenManager = NULL;
	USHORT usPENS_WAITING_FOR_ALIGNMENT = 0;
	USHORT usPENS_LOGGING = 0;
    QString strRecording = "Stopped";
	QString strDesc;
	USHORT PenInstance = 0;
	CPenControl *pPenCtl = NULL;
	T_PPEN pPenConfig = NULL;
	QString strLoggingUnit;
	unsigned int uLoggingRate = 0;
    WCHAR *pwStr = NULL;
	//
	try {
		for (; lIndex < static_cast<long>(dwCount); lIndex++) {
			//Get the value of the index.
			if (vDataItem.vt != VT_EMPTY) {
				VariantClear(&vDataItem);
				VariantInit(&vDataItem);
			}
			switch ((DI_VALUES) ((pvIndex + lIndex)->iVal)) {
			case DI_FLOAT_VALUE:	// Index 0 - Data Item Float Value.
				vDataItem.vt = VT_R4;
				vDataItem.fltVal = pDataItem->GetFPValue();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray);
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_ENABLE:			// Index 1 - Data Item Enable Property.
				vDataItem.vt = VT_BOOL;
				vDataItem.boolVal = pDataItem->IsEnabled();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
            case DI_DATA_TYPE:		// Index 2 - Data Item Data Type
				vDataItem.vt = VT_I2;
                vDataItem.iVal = (T_DATAITEM_VARIABLE_TYPE) pDataItem->GetDataType();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_RATE:			// Index 3 - Data Item Rate
				vDataItem.vt = VT_I4;
				vDataItem.ulVal = pDataItem->GetRate();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_SPAN:		// Index 4 - Data Item Span Value
				vDataItem.vt = VT_R4;
				vDataItem.fltVal = pDataItem->GetSpan();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
            case DI_TIME:		// Index 5 - Data Item Time Of Change
				vDataItem.vt = VT_R8;
				tempTime = pDataItem->GetTime();
				dTime = static_cast<double>(tempTime.GetMicroSecs());
				vDataItem.dblVal = dTime;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_STATUS:		// Index 6 - Data Item Status 
				vDataItem.vt = VT_I2;
				vDataItem.iVal = (T_DATAITEM_STATUS) pDataItem->GetStatus();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_ZERO:		// Index 7 - Data Item Zero Value
				vDataItem.vt = VT_R4;
				vDataItem.fltVal = pDataItem->GetZero();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_VAR_NAME:	// Index 8 - Data Item Variable Name
				vDataItem.vt = VT_BSTR;
				psTempVarName = pDataItem->GetVariableName();
				sTempBstr = psTempVarName;
				vDataItem.bstrVal = sTempBstr;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				//SysFreeString( sTempBstr );
				break;
			case DI_UNITS:	// Index 9 - Data Item Units
				vDataItem.vt = VT_BSTR;
                psTempUnits = QString::fromWCharArray(pDataItem->GetUnits());
				sTempUnits = psTempUnits;
				vDataItem.bstrVal = sTempUnits;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				//SysFreeString( sTempUnits );
				break;
            case DI_TAG:	// Index 10 - Data Item Tag Name
				vDataItem.vt = VT_BSTR;
                psTempUnits = QString::fromWCharArray(pDataItem->GetTag());
                sTempTag = psTempTagName;
				vDataItem.bstrVal = sTempTag;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				//SysFreeString( sTempTag );
				break;
			case DI_COLOR:	// Index 11 - Data Item Color
				vDataItem.vt = VT_UI4;
				plColor = pDataItem->GetColour();
				vDataItem.ulVal = (*plColor);
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_ALARM_STATUS:	// Index 12 - Data Item Alarm Status
				vDataItem.vt = VT_UI2;
				vDataItem.uiVal = pDataItem->GetAlarmStatus();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
            case DI_ALARM_TYPE:		// Index 13 - Data Item Alarm Type
				vDataItem.vt = VT_UI2;
				vDataItem.uiVal = pDataItem->GetAlarmType();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_REFERENCE:		// Index 14 - Data Item Refernec
				vDataItem.vt = VT_UI2;
				vDataItem.uiVal = pDataItem->GetReference();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			case DI_INSTANCE:		// Index 15 - Data Item Instance
				vDataItem.vt = VT_UI2;
				vDataItem.uiVal = pDataItem->GetInstance();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
            case DI_TYPE:		// Index 16 - Data Item Type
				vDataItem.vt = VT_UI2;
				vDataItem.iVal = pDataItem->GetType();
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
				//E528446
			case DI_RECORDING_STATUS: {
				vDataItem.vt = VT_BSTR;	//dwCount				
				pkPenManager = CPenManager::GetHandle();
				if (!pkPenManager)
					return S_FALSE;
                strRecording = "Stopped";
				// now get the number of pens waiting for alignment
				usPENS_WAITING_FOR_ALIGNMENT = pkPenManager->NoOfPensWaitingForAlignment();
				usPENS_LOGGING = pkPenManager->NumberOfPensLogging() - usPENS_WAITING_FOR_ALIGNMENT;
				USHORT uInst = pDataItem->GetInstance();
				BOOL bIsLogging = pkPenManager->IsPenLogging(uInst);
				//if(usPENS_LOGGING > 0)
				if (bIsLogging) {
                    strRecording = "ON";
				}
                vDataItem.bstrVal = strRecording;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
			} //
			case DI_DESC:
				vDataItem.vt = VT_BSTR;
                strDesc = QString::fromWCharArray(pDataItem->GetDesc());
                vDataItem.bstrVal = strDesc;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break; //
			case DI_LOG_UNITS:
				vDataItem.vt = VT_BSTR;
				pkPenManager = CPenManager::GetHandle();
				if (!pkPenManager)
					return S_FALSE;
				//
				PenInstance = pDataItem->GetInstance();
				pPenCtl = pkPenManager->GetPenControl(PenInstance, ZERO_BASED);
				// If pen control is valid, get ptr to the pen configuration
				pPenConfig = pPenCtl->GetPenConfigPtr();
				if (pPenConfig != NULL) {
					if (pPenConfig->PenLog.Enabled == TRUE) {
						uLoggingRate = pPenConfig->PenLog.RateUnits;
						switch (uLoggingRate) {
						case 0:
                            strLoggingUnit = "MS";
							break;
						case 1:
                            strLoggingUnit = "Secs";
							break;
						case 2:
                            strLoggingUnit = "Mins";
							break;
						case 3:
                            strLoggingUnit = "Hours";
							break;
						}
					}
				}
                vDataItem.bstrVal = strLoggingUnit;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
				break;
				//
				//E528446[
			case DI_LOG_RATE: {
				// Start
				vDataItem.vt = VT_UI4;
				CPenControl *pPenCtl = NULL;
				PenInstance = pDataItem->GetInstance();
				//ULONG usLogRate = pkPenManager->PenLogRate( PenInstance );
				CPenList *pPenList = NULL;
				pPenList = pkPenManager->GetAvailableList();
				if (!pPenList)
					return S_FALSE;
				pPenCtl = pPenList->GetEntry(PenInstance);
				if (!pPenCtl)
					return S_FALSE;
				pPenConfig = pPenCtl->GetPenConfigPtr();
				ULONG uLRate = pPenConfig->PenLog.Rate;
				//if(uLoggingRate == 1)
				//{
                //	uLRate = usLogRate /RATE_SO_MS_MULTIPLIER;
				//}
				//else if(uLoggingRate == 2)
				//{
                //	uLRate = usLogRate / RATE_MO_MS_MULTIPLIER;
				//}
				//else if(uLoggingRate == 3)
				//{
                //	uLRate = uLRate;//usLogRate / RATE_HO_MS_MULTIPLIER;
				//}						
				/*else*/
				if (uLoggingRate == 0) {
					switch (pPenConfig->PenLog.RateMS) {
					case lmr2Hertz:
						uLRate = RATE_2HZ_IN_MS;
						break;
					case lmr5Hertz:
						uLRate = RATE_5HZ_IN_MS;
						break;
					case lmr10Hertz:
						uLRate = RATE_10HZ_IN_MS;
						break;
					case lmr50Hertz:
						if (pSYSTEM_INFO->FWOptionFastScanAvailable())
							uLRate = RATE_50HZ_IN_MS;
						else
							uLRate = RATE_10HZ_IN_MS;
						break;
					default:
						uLRate = RATE_2HZ_IN_MS;
					}
					uLRate = uLRate / 10;
                    //	strLogRate = QString::asprintf( "%u", static_cast< ULONG >( ( 1 / fLogRate ) + 0.5 )  );
				}
				vDataItem.lVal = uLRate;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
			}
				break;
            case DI_LOG_TYPE: {
				// Start
				QString strLogType;
				PenInstance = pDataItem->GetInstance();
				vDataItem.vt = VT_BSTR;
				CPenControl *pPenCtl = NULL;
				CPenList *pPenList = NULL;
				//[
				CPenSetupConfig *pkPenSetupCfg = pSETUP->GetPenSetupConfig();
				if (!pkPenSetupCfg)
					break;
				T_PPEN ptPenData = NULL;
				ptPenData = pkPenSetupCfg->GetPen(PenInstance, ZERO_BASED, CONFIG_COMMITTED);
				if (!ptPenData)
					break;
				if (ptPenData->PenLog.Enabled) {
					if (ptPenData->PenLog.LogType == 0)
                        strLogType = "Continuous";
					else
                        strLogType = "Fuzzy";
				}
				//]
				/*pPenList = pkPenManager->GetAvailableList();
				 if(pPenList)
				 pPenCtl = pPenList->GetEntry(PenInstance);
				 
				 if( pPenCtl != NULL && pPenCtl->m_logChannel.IsLogging())
				 {
				 if(pPenCtl->m_logChannel.IsContinuous())
                 strLogType = "Continuous";
				 if(pPenCtl->m_logChannel.IsFuzzy())
                 strLogType = "Fuzzy";
				 }*///old
                vDataItem.bstrVal = strLogType;
				if (hResult = SafeArrayPutElement(pvDataItemValues->parray, &lIndex, &vDataItem)) {
					VariantClear(&vDataItem);
					SafeArrayDestroy(pvDataItemValues->parray); // does a deep destroy
					pvDataItemValues = NULL;
					return hResult;
				}
			}
				break;
			default:
				SafeArrayDestroy(pvDataItemValues->parray);
				pvDataItemValues = NULL;
				return E_INVALIDARG;
			}
		}
	}
	catch (...) {
		// Destroy the SafeArray.
		SafeArrayDestroy(pvDataItemValues->parray);
		// OUT Parameter as NULL.
		pvDataItemValues = NULL;
		return E_INVALIDARG;
	}
	// Unlock the Safe Array - Decrease the Lock Count 
	//if ( hResult = SafeArrayUnlock( vIndexVarVal.parray ))
	//{
	//	// Destroy the SafeArray.
	//	SafeArrayDestroy ( pvDataItemValues->parray );
	//	return hResult;
	//}
	// Clear the Variants
	VariantClear(&vDataItem);
	VariantClear(&vIndexVarVal);
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : SetData
/// 
/// This function will set the Data Item Values.
/// This function is called by SetDataItem and SetDataItemFromVarName. 
///
/// @param[in] pDataItem - Pointer to DataItem
/// @param[in] dwIndex - Specifies the Index for the DataItem Value to be written.
/// @param[in] pDataItemValues - Pointer to the Variant that specifies the 
///          DataItemValues
/// 
/// @return	 E_INVALIDARG  - If the input value is not valid. 	
///    S_OK    - For successfull operation
///
//****************************************************************************
HRESULT CV6AppInterface::SetData( /*[IN]*/CDataItem *pDataItem,
/*[IN]*/DWORD dwIndex,
/*[IN]*/VARIANT vDataItemValues)
{
	// Check the Varaiant Types of the Index Parameter.
	if (!((vDataItemValues.vt & VT_BYREF) && (vDataItemValues.vt & VT_VARIANT)))
		return E_FAIL;
	// If the Pointer to the SafeArray Variant is NULL.
	if (vDataItemValues.pvarVal == NULL)
		return E_INVALIDARG;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_ACCESSDENIED;
	// Variant for DataItem.
	VARIANT vDataItem;
	VariantInit(&vDataItem);
	// Collect Variant to data item value.
	VariantCopyInd(&vDataItem, vDataItemValues.pvarVal);
	// Check for the Data Item Value Index
	switch ((DI_VALUES) dwIndex) {
	// Data Item Float Value.
	case DI_FLOAT_VALUE:			// Index - 0
		if (vDataItem.vt == VT_R4 || vDataItem.vt == VT_R8 || vDataItem.vt == VT_I2) {
			pDataItem->SetValue(vDataItem.fltVal);
			break;
		} else {
			VariantClear(&vDataItem);
			return E_INVALIDARG;
		}
		// Data Item Enable property.		// Index - 1
	case DI_ENABLE:
		if (vDataItem.vt == VT_BOOL) {
			pDataItem->SetEnabled(vDataItem.boolVal);
			break;
		} else {
			VariantClear(&vDataItem);
			return E_INVALIDARG;
		}
		// Data Item Data Type.
    case DI_DATA_TYPE:				// Index - 2
		if (vDataItem.vt == VT_I2) {
            pDataItem->SetDataType((T_DATAITEM_VARIABLE_TYPE) vDataItem.iVal);
			break;
		} else {
			VariantClear(&vDataItem);
			return E_INVALIDARG;
		}
		// Data Item Time Stamp.
    case DI_TIME:				// Index - 5
		if (vDataItem.vt == VT_R8) {
			pDataItem->SetTime(static_cast<LONGLONG>(vDataItem.dblVal));
			break;
		} else {
			VariantClear(&vDataItem);
			return E_INVALIDARG;
		}
		// Data Item Status.
	case DI_STATUS:			// Index - 
		if (vDataItem.vt == VT_I2) {
			pDataItem->SetStatus((T_DATAITEM_STATUS) vDataItem.iVal);
			break;
		} else {
			VariantClear(&vDataItem);
			return E_INVALIDARG;
		}
		// Data Item Variable Name.
	case DI_VAR_NAME:			// Index - 8
		if (vDataItem.vt == VT_BSTR) {
			pDataItem->SetVarName(vDataItem.bstrVal);
			break;
		} else {
			VariantClear(&vDataItem);
			return E_INVALIDARG;
		}
		// Data Item Alarm Status.
	case DI_ALARM_STATUS:			// Index - 12
		if (vDataItem.vt == VT_UI2 || vDataItem.vt == VT_I2) {
			pDataItem->SetAlarmStatus(vDataItem.uiVal);
			break;
		} else {
			VariantClear(&vDataItem);
			return E_INVALIDARG;
		}
		// Invalid Argument.
	default:
		VariantClear(&vDataItem);
		return E_INVALIDARG;
	}
	// Clear the Variant
	VariantClear(&vDataItem);
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : UpdateDataItems Function
/// 
/// This function will add the specified data items into the UpdateMap.
/// and it will create the thread for the call back if it is not running already.
///
/// @param[in] vTypeArray - Variant of SafeArray that specifies the types.
/// @param[in] vRefArray  - Variant of SafeArray that specifies the referneces.
/// @param[in] vInstanceArray  - Variant of SafeArray that specifies the instances
/// @param[in] dwNumItems - Defines total number of items for that upadate is required.
/// @param[in] vAddOrRemove  - Variant of type BOOL that specifies to add or remove the
///          data items from the Update Map List.
/// 
/// @return	 E_INVALIDARG  - For Invalid Input Parameter.
///    E_OUTOFMEMORY - Unable to create the thread.
///    S_OK    - For successfull operation.
///
//****************************************************************************
HRESULT CV6AppInterface::UpdateDataItems( /*[IN]*/VARIANT vTypeArray,
/*[IN]*/VARIANT vRefArray,
/*[IN]*/VARIANT vInstanceArray,
/*[IN]*/DWORD dwNumItems,
/*[IN]*/DWORD dwUpdateRate,
/*[IN]*/VARIANT vAddOrRemove) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	// Variables Declaration
	HRESULT hResult;
	BOOL bAvailable;
	// Check the Variant Types for Input Parameter 
	if (!((vTypeArray.vt & VT_VARIANT) && (vTypeArray.vt & VT_BYREF)))
		return E_INVALIDARG;
	if (!((vRefArray.vt & VT_VARIANT) && (vRefArray.vt & VT_BYREF)))
		return E_INVALIDARG;
	if (!((vInstanceArray.vt & VT_VARIANT) && (vInstanceArray.vt & VT_BYREF)))
		return E_INVALIDARG;
	// if the Pointer to SafeArray Variant is NULL.
	if (vTypeArray.pvarVal == NULL || vRefArray.pvarVal == NULL || vInstanceArray.pvarVal == NULL)
		return E_INVALIDARG;
	// Check the Input Parameter Types
	if (!(vAddOrRemove.vt == VT_BOOL))
		return E_INVALIDARG;
	// Update the value of the update rate
	if (dwUpdateRate > MIN_DI_UPDATE_RATE)
		m_ReqObj->m_dwUpdateRate = dwUpdateRate;
	// Variants to collect the types, Ref and instances.
	VARIANT *pvItemType = NULL;
	VARIANT *pvItemRef = NULL;
	VARIANT *pvItemInstance = NULL;
	VARIANT vVarValType;
	VARIANT vVarValRef;
	VARIANT vVarValInst;
	VariantInit(&vVarValType);
	VariantInit(&vVarValRef);
	VariantInit(&vVarValInst);
	// Extract the safe array of Types.
	VariantCopyInd(&vVarValType, vTypeArray.pvarVal);
	// If the SafeArray Pointer is NULL.
	if (vVarValType.parray == NULL) {
		// Clear the Variant.
		VariantClear(&vVarValType);
		VariantClear(&vVarValRef);
		VariantClear(&vVarValInst);
		return E_INVALIDARG;
	}
	// Get the Lower and Upper Bounds of the SafeArray.
	long lLBound, lUBound;
	SafeArrayGetLBound(vVarValType.parray, 1, &lLBound);
	SafeArrayGetUBound(vVarValType.parray, 1, &lUBound);
	// Get the count of elements.
	long cElements = lUBound - lLBound + 1;
	// If the mismatch between the SafeArray elements and Elements Count.
	if (cElements != dwNumItems) {
		SafeArrayDestroy(vVarValType.parray);
		VariantClear(&vVarValRef);
		VariantClear(&vVarValInst);
		return E_INVALIDARG;
	}
	// Extract the SafeArray.
	if (hResult = SafeArrayAccessData(vVarValType.parray, (void**) &pvItemType)) {
		// Clear the Variant.
		SafeArrayDestroy(vVarValType.parray);
		VariantClear(&vVarValRef);
		VariantClear(&vVarValInst);
		return E_INVALIDARG;
	}
	// Unlock the  safe Array.
	SafeArrayUnlock(vVarValType.parray);
	// Extract the safe array of Refs.
	VariantCopyInd(&vVarValRef, vRefArray.pvarVal);
	// If the SafeArray Pointer is NULL.
	if (vVarValRef.parray == NULL) {
		// Clear the Variant.
		SafeArrayDestroy(vVarValType.parray);
		VariantClear(&vVarValRef);
		VariantClear(&vVarValInst);
		return E_INVALIDARG;
	}
	// Get the Lower and Upper Bouns of the SafeArray.
	SafeArrayGetLBound(vVarValRef.parray, 1, &lLBound);
	SafeArrayGetUBound(vVarValRef.parray, 1, &lUBound);
	// Get the count of elements.
	cElements = lUBound - lLBound + 1;
	// If the mismatch between the SafeArray elements and Elements Count.
	if (cElements != dwNumItems) {
		SafeArrayDestroy(vVarValType.parray);
		SafeArrayDestroy(vVarValRef.parray);
		VariantClear(&vVarValInst);
		return E_INVALIDARG;
	}
	// Extract the SafeArray.
	if (hResult = SafeArrayAccessData(vVarValRef.parray, (void**) &pvItemRef)) {
		// Clear the Variant.
		SafeArrayDestroy(vVarValType.parray);
		SafeArrayDestroy(vVarValRef.parray);
		VariantClear(&vVarValInst);
		return E_INVALIDARG;
	}
	// Unlock the  safe Array.
	SafeArrayUnlock(vVarValRef.parray);
	// Extract the safe array of Instances.
	VariantCopyInd(&vVarValInst, vInstanceArray.pvarVal);
	// If the SafeArray Pointer is NULL.
	if (vVarValInst.parray == NULL) {
		// Clear the Variant.
		SafeArrayDestroy(vVarValType.parray);
		SafeArrayDestroy(vVarValRef.parray);
		VariantClear(&vVarValInst);
		return E_INVALIDARG;
	}
	// Get the Lower and Upper Bouns of the SafeArray.
	SafeArrayGetLBound(vVarValInst.parray, 1, &lLBound);
	SafeArrayGetUBound(vVarValInst.parray, 1, &lUBound);
	// Get the count of elements.
	cElements = lUBound - lLBound + 1;
	// If the mismatch between the SafeArray elements and Elements Count.
	if (cElements != dwNumItems) {
		SafeArrayDestroy(vVarValType.parray);
		SafeArrayDestroy(vVarValRef.parray);
		SafeArrayDestroy(vVarValInst.parray);
		return E_INVALIDARG;
	}
	// Extract the SafeArray.
	if (hResult = SafeArrayAccessData((vVarValInst.parray), (void**) &pvItemInstance)) {
		// Clear the Variant.
		SafeArrayDestroy(vVarValType.parray);
		SafeArrayDestroy(vVarValRef.parray);
		SafeArrayDestroy(vVarValInst.parray);
		return E_INVALIDARG;
	}
	// Unlock the  safe Array.
	SafeArrayUnlock(vVarValInst.parray);
	for (DWORD dwItemsCount = 0; dwItemsCount < dwNumItems; dwItemsCount++) {
		// Check the Availability of the Data Item in the Update Map List.
		bAvailable = m_ReqObj->IsDataItemAvailable((pvItemType + dwItemsCount)->iVal, (pvItemRef + dwItemsCount)->iVal,
				(pvItemInstance + dwItemsCount)->iVal);
		// If the Data Item is not available
		if (vAddOrRemove.boolVal == TRUE) {
			// Add the Data Item into the Update Map List.
			if (bAvailable == false) {
				m_ReqObj->AddRemoveDataItem((pvItemType + dwItemsCount)->iVal, (pvItemRef + dwItemsCount)->iVal,
						(pvItemInstance + dwItemsCount)->iVal, true);
			}
		}
		// Remove the Data Item from the Update Map List.
		else {
			// Add the Data Item into the Update Map List.
			if (bAvailable == TRUE) {
				m_ReqObj->AddRemoveDataItem((pvItemType + dwItemsCount)->iVal, (pvItemRef + dwItemsCount)->iVal,
						(pvItemInstance + dwItemsCount)->iVal, false);
			}
		}
	}
	if (m_ReqObj->m_hlThreadHdl == INVALID_HANDLE_VALUE) {
		// Create the Thread and call Update for the Data Items in the Update Map.
		SECURITY_ATTRIBUTES sSecAttr;
		sSecAttr.nLength = sizeof(sSecAttr);
		sSecAttr.lpSecurityDescriptor = NULL;
		DWORD dwThreadId = 0;
		m_ReqObj->m_hlThreadHdl = CreateThread(&sSecAttr, 0, (LPTHREAD_START_ROUTINE) & UpdateThread, this, 0,
				&dwThreadId);
		qDebug("V6 App Interface Thread ID: %u\n", dwThreadId);
		//
		// Stability Project Fix:
		// 
		// Priority of the thread was lowered to resolve the OPC hang issue
		// But is was observed that the issue is not getting resolved.
		// Hence Thread Priority is set back to Normal.
		//
		//SetThreadPriority(m_ReqObj->m_hlThreadHdl,THREAD_PRIORITY_LOWEST);
		if (m_ReqObj->m_hlThreadHdl == NULL) {
			SafeArrayDestroy(vVarValType.parray);
			SafeArrayDestroy(vVarValRef.parray);
			SafeArrayDestroy(vVarValInst.parray);
			return E_OUTOFMEMORY;
		}
	}
	// Destroy the SafeArray.
	hResult = SafeArrayDestroy(vVarValRef.parray);
	hResult = SafeArrayDestroy(vVarValType.parray);
	hResult = SafeArrayDestroy(vVarValInst.parray);
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : UpdateThreadFunc
/// 
/// Static functiom to call the thread procedure. 
///
/// @param[in] pThreadFunc - Void pointer.
/// 
/// @return	 UINT 
///			 Zero  - For the unreported errors.  
///    One - For SuccessFull Operation.
///    
///
//****************************************************************************
UINT __cdecl CV6AppInterface::UpdateThread( /*[IN] */void *pThreadFunc) {
	// Call thread procedure.
	return ((CV6AppInterface*) pThreadFunc)->UpdateThreadFunc();
}
//****************************************************************************
/// CV6AppInterface : UpdateThreadFunc
/// 
/// Thread Function Implementation.
/// 
/// @param[in] None
/// 
/// @return	  Zero  - For the unreported errors.  
///     One - For SuccessFull Operation.
//****************************************************************************
UINT CV6AppInterface::UpdateThreadFunc() {
	// Variables Declarations
	HRESULT hResult = S_OK;
	unsigned short nType = 0;
	unsigned short nRef = 0;
	unsigned short nInstance = 0;
	int iFirstComma = 0;
	int iSecondComma = 0;
	POSITION sPos;
	DWORD dwStartTickCount = 0;
	CDataItem *pDataItemPtr = NULL;
	QString sDataItem;
	// Initialize COM for use by the current thread. 
	hResult = CoInitializeEx( NULL, COINIT_MULTITHREADED);
	// 3137 - Declared Variable to Indicate whether thread is inside CS.
	BOOL bIsEnteredCS = FALSE;
	// If fails to inialize the COM Library.
	if FAILED( hResult )
	{
		CoUninitialize();
		return 0;
	}
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the OPC Update thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the OPC Update thread has 
		//started
        pThreadInfo->UpdateThreadInfo(AM_OPC_UPDATE_THREAD, true);
	}
	try {
		// If Items exist in the Update Map then scan the item 
		// otherwise end the thread.	
		while (m_ReqObj->m_DIUpdateMap.size() > 0) {
			// Get the tick count.
			dwStartTickCount = GetTickCount();
			// Iterate the item map list and fetch for each item from gloabl list
			// 3137 - Enter to CS before starting iterating for m_DIUpdateMap.
			m_ReqObj->ms_csOPCServerADDREmoveInfo.lock();
			bIsEnteredCS = TRUE;
			sPos = m_ReqObj->m_DIUpdateMap.GetStartPosition();
			while (sPos)
			{
				if (GlbAppStateSema == APPACCESS_SHUTDOWN) {
					// Remove All the Items for the Update.
					m_ReqObj->m_DIUpdateMap.clear();
					// Close the Thread Handle.
					CloseHandle(m_ReqObj->m_hlThreadHdl);
					m_ReqObj->m_hlThreadHdl = NULL;
					m_ReqObj->m_hlThreadHdl = INVALID_HANDLE_VALUE;
					// Uninitialize the COM Library.
					CoUninitialize();
					m_ReqObj->ms_csOPCServerADDREmoveInfo.unlock();
					bIsEnteredCS = FALSE;
					return 1;
				}
				// Get the Next Association in the UpdateMap
				m_ReqObj->m_DIUpdateMap.GetNextAssoc(sPos, sDataItem, pDataItemPtr);
				// Extract the type of the data item. 
                QStringList lst = sDataItem.split(',');
                if (lst.length() > 1){
                    /// TODO : Validate this
                    nType = lst[0].toUShort();
                    // Extract the Ref of the data item.
                    nRef = lst[1].toUInt();
                    // Extract the instance of the data item.
                    nInstance = lst[1].toUInt();;
                }
				// Initialize the Safe Array and Defines the Lower Bound and Total Number of Elements.
				SAFEARRAY *psaDataItemArray;
				SAFEARRAYBOUND aDataItemBounds[1];
				aDataItemBounds[0].lLbound = 0;
				aDataItemBounds[0].cElements = DI_VAL_MAX;
				// Create the one dimensional Safe Array of type VARIANTS.
				psaDataItemArray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);
				if (psaDataItemArray == NULL) {
					CoUninitialize();
					// 3137 - Leave critical section.
					m_ReqObj->ms_csOPCServerADDREmoveInfo.unlock();
					bIsEnteredCS = FALSE;
					return 0;
				}
				// Variant to Put the IndexValue.
				VARIANT vIndexValue;
				VariantInit(&vIndexValue);
				// Set the Index Values from 0-17.
				for (long lIndex = 0; lIndex < DI_VAL_MAX; lIndex++) {
					vIndexValue.vt = VT_I2;
					vIndexValue.iVal = static_cast<unsigned short>(lIndex);
					if (hResult = SafeArrayPutElement(psaDataItemArray, &lIndex, &vIndexValue)) {
						SafeArrayDestroy(psaDataItemArray);
						CoUninitialize();
						// 3137 - Leave critical section.
						m_ReqObj->ms_csOPCServerADDREmoveInfo.unlock();
						bIsEnteredCS = FALSE;
						return 0;
					}
					if (pThreadInfo != NULL) {
						//Update the Thread Counter for the OPC Update
						//thread after each iteration
                        pThreadInfo->UpdateThreadCounter(AM_OPC_UPDATE_THREAD);
					}
				}
				// Varinat to specify the Index Value Variant.
				VARIANT vIndex;
				VariantInit(&vIndex);
				vIndex.vt = VT_ARRAY | VT_VARIANT;
				// Index Input Pararmetr for the OnDataItemChange.
				VARIANT vIndexVar;
				VariantInit(&vIndexVar);
				vIndexVar.vt = VT_BYREF | VT_VARIANT;
				// Update the Values of Variants.				
				vIndex.parray = psaDataItemArray;
				vIndexVar.pvarVal = &vIndex;
				// Variant To collect the data item values.
				VARIANT vDIValues;
				VariantInit(&vDIValues);
				// Call Get Data Function to get the Values for the dataitem.
				if (hResult = GetData(pDataItemPtr, (DI_VAL_MAX), vIndexVar, &vDIValues)) {
					SafeArrayDestroy(psaDataItemArray);
					VariantClear(&vDIValues);
					CoUninitialize();
					// 3137 - Leave critical section.
					m_ReqObj->ms_csOPCServerADDREmoveInfo.unlock();
					bIsEnteredCS = FALSE;
					return 0;
				}
				// Call Back to the connected clients.
				Fire_OnDataItemChange(nType, nRef, nInstance, &vDIValues);
				// Deep destroy the SafeArray
				SafeArrayDestroy(psaDataItemArray);
				SafeArrayDestroy(vDIValues.parray);
			}
			// 3137 - Leave critical section.
			m_ReqObj->ms_csOPCServerADDREmoveInfo.unlock();
			bIsEnteredCS = FALSE;
			// Get the current tick count to find the elapsed time.
			DWORD dwEndTickCount = GetTickCount();
			DWORD dwElapsedTime = dwEndTickCount - dwStartTickCount;
			// Set to zero when the system runs continuously for 49.7 days 
			if (dwEndTickCount < dwStartTickCount)
				dwElapsedTime = 0;
			if (dwElapsedTime < m_ReqObj->m_dwUpdateRate) {
				sleep(m_ReqObj->m_dwUpdateRate - dwElapsedTime);
			}
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the OPC Update thread
			//after each iteration
            pThreadInfo->UpdateThreadCounter(AM_OPC_UPDATE_THREAD);
		}
	}
	// Abnormal Unreported Errors
	catch (...) {
		CloseHandle(m_ReqObj->m_hlThreadHdl);
		m_ReqObj->m_hlThreadHdl = INVALID_HANDLE_VALUE;
		CoUninitialize();
		if (bIsEnteredCS) {
			// 3137 - Leave critical section.
			m_ReqObj->ms_csOPCServerADDREmoveInfo.unlock();
			bIsEnteredCS = FALSE;
		}
		if (pThreadInfo != NULL) {
			//Update the info that the OPCUpdate thread is exiting
			//Hence this thread need not be considered to kick the 
			//watchdog
            pThreadInfo->UpdateThreadInfo(AM_OPC_UPDATE_THREAD, false);
		}
		return 0;
	}
	CloseHandle(m_ReqObj->m_hlThreadHdl);
	m_ReqObj->m_hlThreadHdl = INVALID_HANDLE_VALUE;
	// Uninitialize the COM Library.
	CoUninitialize();
	if (pThreadInfo != NULL) {
		//Update the info that the OPCUpdate thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
        pThreadInfo->UpdateThreadInfo(AM_OPC_UPDATE_THREAD, false);
	}
	return 1;
}
//************************ CRequestObject*************************************
//****************************************************************************
//  CRequestObject : UpdateOPCPenConfig(USHORT usPenNumber)
///
/// This function would be called whenever there is change in the Pen's Tag Name.
/// In Response this function would Inform the OPCA&EServer to update the queue for
/// this Tag Name.
///
/// @param[in]		USHORT usPenNumber - Pen Number for which the Pen Tag Has been
///              Changed.
///
//****************************************************************************
void CRequestObject::UpdateOPCPenConfig( USHORT usPenNumber) {
	return;
}
//****************************************************************************
//  CRequestObject : UpdateOPCGroupConfig( )
///
/// This function would be called whenever there is change in the Pen's Group Config.
/// In Response this function would Inform the OPCA&EServer to update the address space.
///
/// @param[in]		None
///
//****************************************************************************
void CRequestObject::UpdateOPCGroupConfig() {
	// If the CRequestObject Intialized.
	if (ms_bInitialised) {
		// Update the Group Configuration status as true as there is change in group 
		// Configuration.
		ms_csOPCGroupConfigStatus.lock();
		ms_bOPCGroupConfigStatus = true;
		ms_csOPCGroupConfigStatus.unlock();
	}
	return;
}
//****************************************************************************
//  CRequestObject : PushMsg( const T_MSGLISTSER_MESSAGE &rtMSG )
///
/// Push a message onto the queue
///
/// @param[in]			const T_MSGLISTSER_MESSAGE &rtMSG - message list structure 
///						passed in by reference
///
//****************************************************************************
void CRequestObject::PushMsg(const T_MSGLISTSER_MESSAGE &rtMSG) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// TODO: Add your implementation code here
	// Variables Declaration
	HRESULT hResult = S_OK;
	// Check if the critical section has been intialised.
	if (ms_bInitialised) {
		ms_csCriticalSection.lock();
		// Check the limitation of the deque.
		if (ms_dqMessageList.size() >= MIN_MSG_LIM)
			ms_dqMessageList.pop_front();
		// Add to queue
		ms_dqMessageList.push_back(rtMSG);
		ms_csCriticalSection.unlock();
	}
}
//****************************************************************************
//  CRequestObject	::PopMsg( T_MSGLISTSER_MESSAGE &rtMsg )
///
/// Pop a message from the front of the queue
///
/// @param[out]	T_MSGLISTSER_MESSAGE &rtMsg - message list structure passed in by reference
///
/// @return		True if some data was found
///
//****************************************************************************
const bool CRequestObject::PopMsg(T_MSGLISTSER_MESSAGE &rtMsg) {
	bool bDataPresent = false;
	ms_csCriticalSection.lock();
	if (ms_dqMessageList.size() > 0) {
		// Get the front data item
		rtMsg = ms_dqMessageList.front();
		// Now remove from our queue
		ms_dqMessageList.pop_front();
		bDataPresent = true;
	}
	ms_csCriticalSection.unlock();
	return bDataPresent;
}
//****************************************************************************
/// CRequestObject : AddRemoveDataItem Function
/// 
/// This function add or Remove the specified data item in the update Map 
/// depending upon the value of bool variable bAddData
///
/// @param[in] nType   - Defines the type of the DataItemContainer.
/// @param[in] nRef  - Defines the SubType of the DataItem.  
/// @param[in] nInstance - Defines the instance of the DataItem.   
/// @param[in] nAddData  - True  (To Add the data item in update map)
///						 False (To Remove the data item from update map)
///
/// @return	 None
//****************************************************************************
void CRequestObject::AddRemoveDataItem( /*[IN]*/unsigned short nType,
/*[IN]*/unsigned short nRef,
/*[IN]*/unsigned short nInst,
/*[IN]*/BOOL bAddData) {
	// Variable Declaration.
	QString strItemName;
	CDataItem *pDataItemPtr = NULL;
    WCHAR buffer[65];
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return;
	// Date Item Name = "Type,Ref,Instance"
	_itot_s(nType, buffer, 65, 10);
    strItemName = strItemName + QString::fromWCharArray(buffer) + ',';
	_itot_s(nRef, buffer, 65, 10);
    strItemName = strItemName + QString::fromWCharArray(buffer) + ",";
	_itot_s(nInst, buffer, 65, 10);
    strItemName = strItemName + QString::fromWCharArray(buffer);
	// Add the Dataitem to Update Map
	if (bAddData == TRUE) {
        pDataItemPtr = (CDataItem*) pGlbDIT->GetDataItemPtr((T_DATA_ITEM_TYPE) nType, nRef, nInst);
		if (pDataItemPtr != NULL) {
			//3137
			ms_csOPCServerADDREmoveInfo.lock();
			m_DIUpdateMap.SetAt(strItemName, pDataItemPtr);
			ms_csOPCServerADDREmoveInfo.unlock();
		}
	}
	// Remove the Dataitem from Update Map
	else {
		if (!m_DIUpdateMap.isEmpty()) {
			//3137
			ms_csOPCServerADDREmoveInfo.lock();
			m_DIUpdateMap.removeKey(strItemName);
			ms_csOPCServerADDREmoveInfo.unlock();
		}
	}
}
//****************************************************************************
/// CRequestObject : IsDataItemAvailable 
/// 
/// This function checks the availabilty of the data item in the Update Map List.
///
/// @param[in] nType - Defines the type of the DataItemContainer.
/// @param[in] nRef  - Defines the SubType of the DataItem.  
/// @param[in] nInstance - Defines the instance of the DataItem.   
/// 
/// @return	 True  - If Dataitem is available in the UpdateMap
///    False - If Dataitem is not available in the UpdateMap
//****************************************************************************
BOOL CRequestObject::IsDataItemAvailable( /*[IN]*/unsigned short nType,
/*[IN]*/unsigned short nRef,
/*[IN]*/unsigned short nInst) {
	// Variable Declaration.
	QString strItemName;
	CDataItem *pDataItemPtr = NULL;
    WCHAR buffer[65];
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return false;
	// Date Item Name = "Type,Ref,Instance"
	_itot_s(nType, buffer, 65, 10);
    strItemName = strItemName + QString::fromWCharArray(buffer) + ",";
	_itot_s(nRef, buffer, 65, 10);
    strItemName = strItemName + QString::fromWCharArray(buffer)+ ",";
	_itot_s(nInst, buffer, 65, 10);
    strItemName = strItemName + QString::fromWCharArray(buffer);
	// Check the Availability of the Data Item Name in the Update Map.
	if ((m_DIUpdateMap.Lookup(strItemName, pDataItemPtr)))
		return true;
	else
		return false;
}
//****************************************************************************
/// CV6AppInterface::IsPasswordEnabled 
/// 
/// Wrapper to access CPWI through Web.
///
/// @param[out] pswdResult		- PMM status code.
/// 
/// @return	 respective error code if not successful in IsPasswordEnabled, else returns CSTATUS_OK.
//****************************************************************************
HRESULT CV6AppInterface::IsPasswordEnabled(/*[out]*/DWORD *pswdResult) {
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK) {
		*pswdResult = (DWORD) ePmmSts;
		return E_FAIL;
	}
	if (pSYSTEM_INFO->IsInManufacturingMode()) // not enabled in manufacturing mode
		ePmmSts = CSTATUS_PASSWORD_NOT_ENABLED;
	else
		ePmmSts = CPasswordInterface.IsPasswordEnabled();
#ifdef TEST_NOPASSWORD
	*pswdResult = (DWORD)CSTATUS_PASSWORD_NOT_ENABLED;	//temporary change, always returns 
			//not enabled on the device.this code to removed when PMM is fully
			//integrated to V6App. -Amar
#else
	*pswdResult = (DWORD) ePmmSts;
#endif
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface::Login 
/// 
/// Wrapper to access CPWI through Web.
///
/// @param[in] UserName		- User to be validated
/// @param[in] Password		- Password to be validated
/// @param[out] UserId		- UserId is user is valid and successful in login.
/// 
/// @return	 respective error codes if not successful in login, else returns CSTATUS_OK.
//****************************************************************************
HRESULT CV6AppInterface::Login( /*[in]*/QString UserName,
/*[in]*/QString Password,
/*[out]*/VARIANT *pVarResult) {
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	// Initialize the Safe Array and Defines the Lower Bound and Total Number of Elements.
	SAFEARRAY *psaLoginResult = NULL;
	SAFEARRAYBOUND aResultBounds[1];
	aResultBounds[0].lLbound = 0;
	aResultBounds[0].cElements = 1;
	HRESULT hResult;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	ePmmSts = CPasswordInterface.InitCPWI(CPWI_WEB);
	if (ePmmSts == CSTATUS_FAIL)
		return E_FAIL;
	if (ePmmSts == CSTATUS_PASSWORD_NOT_ENABLED) {
		pVarResult->vt = VT_I2;
		pVarResult->iVal = static_cast<PMMSTATUS>(ePmmSts);
		return S_FALSE;
	}
	TV_BOOL bResult = 0;
	ePmmSts = CPasswordInterface.IsWEBEnabled(&bResult);
    if (CSTATUS_OK != ePmmSts) {
		pVarResult->vt = VT_I2;
		pVarResult->iVal = static_cast<PMMSTATUS>(ePmmSts);
		return S_FALSE;
	}
	SHORT UserId = -1;
	ePmmSts = CPasswordInterface.Login(UserName, Password, &UserId);
	// ePmmSts == pass error status to upper layer
	// Variant to Put the IndexValue.
	VARIANT vIndexValue;
	VariantInit(&vIndexValue);
	//set to 2 to send 2 values if login success
	aResultBounds[0].cElements = 2;
	psaLoginResult = SafeArrayCreate(VT_VARIANT, 1, aResultBounds);
	if (psaLoginResult == NULL) {
		return E_OUTOFMEMORY;
	}
	long lIndex = 0;
	vIndexValue.vt = VT_I2;
	vIndexValue.iVal = static_cast<PMMSTATUS>(ePmmSts);
	if (hResult = SafeArrayPutElement(psaLoginResult, &lIndex, &vIndexValue)) {
		SafeArrayDestroy(psaLoginResult);
		return hResult;
	}
	lIndex = 1;
	vIndexValue.vt = VT_I2;
	vIndexValue.iVal = static_cast<unsigned short>(UserId);
	if (hResult = SafeArrayPutElement(psaLoginResult, &lIndex, &vIndexValue)) {
		SafeArrayDestroy(psaLoginResult);
		return hResult;
	}
	pVarResult->vt = VT_ARRAY | VT_VARIANT;
	pVarResult->parray = psaLoginResult;
	return hResult;
}
//****************************************************************************
/// CV6AppInterface::Logoff 
/// 
/// Wrapper to access CPWI through Web.
///
/// @param[in] UserId		- UserId is user returned when user successfully login.
/// 
/// @return	 respective error codes if not successful in login, else returns CSTATUS_OK.
//****************************************************************************
HRESULT CV6AppInterface::Logoff(/*[in]*/SHORT UserId, DWORD *peSts) {
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK) {
		*peSts = (PMMSTATUS) ePmmSts;
		return E_FAIL;
	}
	ePmmSts = CPasswordInterface.Logoff(UserId);
	*peSts = (PMMSTATUS) ePmmSts;
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface::ValidateArea 
/// 
/// Wrapper to access CPWI through Web.
///
/// @param[in] UserId		- UserId is user returned when user successfully login.
/// @param[in] AreaNumber	- Area number from the permission mask of 128 bits.
/// @param[out] Result		- TRUE is user is allowed and FALSE if access is denied to paticular area.
/// 
/// @return	 respective error codes if not successful in login, else returns CSTATUS_OK.
//****************************************************************************
HRESULT CV6AppInterface::ValidateArea( /*[in]*/SHORT AreaNumber,
/*[in]*/SHORT UserId,
/*[in]*/QString szMsgBuffer,
/*[out,retval]*/VARIANT *pVarResult) {
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	USHORT Result;
	HRESULT hResult = S_OK;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	ePmmSts = CPasswordInterface.ValidateAreaNumber(AreaNumber, UserId, &Result, szMsgBuffer);
	SAFEARRAY *psaLoginResult;
	SAFEARRAYBOUND aResultBounds[1];
	aResultBounds[0].lLbound = 0;
	aResultBounds[0].cElements = 2;
	// Create the one dimensional Safe Array of type VARIANTS.
	psaLoginResult = SafeArrayCreate(VT_VARIANT, 1, aResultBounds);
	if (psaLoginResult == NULL) {
		return E_OUTOFMEMORY;
	}
	// Variant to Put the IndexValue.
	VARIANT vIndexValue;
	VariantInit(&vIndexValue);
	long lIndex = 0;
	vIndexValue.vt = VT_I2;
	vIndexValue.iVal = static_cast<PMMSTATUS>(ePmmSts);
	if (hResult = SafeArrayPutElement(psaLoginResult, &lIndex, &vIndexValue)) {
		SafeArrayDestroy(psaLoginResult);
		return hResult;
	}
	lIndex = 1;
	vIndexValue.vt = VT_I2;
	vIndexValue.iVal = static_cast<unsigned short>(Result);
	if (hResult = SafeArrayPutElement(psaLoginResult, &lIndex, &vIndexValue)) {
		SafeArrayDestroy(psaLoginResult);
		return hResult;
	}
	pVarResult->vt = VT_ARRAY | VT_VARIANT;
	pVarResult->parray = psaLoginResult;
	return hResult;
}
//****************************************************************************
/// CV6AppInterface : GetSystemInfo 
/// 
/// This method wraps the system information to be called by web server.
///
/// @param[OUT] VARIANT * 
/// 
/// @return	 S_OK - Successful operation.
//****************************************************************************
HRESULT CV6AppInterface::GetSystemInfo(VARIANT *pSysInfo) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	///> the no of data that will be passed back is set here
	// E528446
	//#define SYSTEM_ELEMENTS 4 //old
#define SYSTEM_ELEMENTS 15
	QString strNetworkname;
	CCommsSetupConfig *pkCommsConfig = NULL;
	T_PCOMMUNICATIONS ptCommsData = NULL;
	QString strVariant;
	//
	if (pSysInfo == NULL)
		return E_INVALIDARG;
//	*dwSize = (DWORD)ELEMENTS;
	// Variables Declaration.
	HRESULT hResult = S_OK;
	CPenManager *pkPenManager = NULL;
	ULONG exportTime = 0;
	CNVBasicVar *pNvVar = NULL;
	USHORT usPENS_LOGGING = 0;
	USHORT usPENS_WAITING_FOR_ALIGNMENT = 0;
    QString strRecording = "OFF";
	long lIndex = 0;
	pSysInfo->vt = VT_ARRAY | VT_VARIANT;
	// SafeArray Bounds Declaration.
	SAFEARRAYBOUND aDataItemBounds[1];
	aDataItemBounds[0].lLbound = 0;
	aDataItemBounds[0].cElements = SYSTEM_ELEMENTS;
	// Create the one dimensional Safe Array of type VARIANTS.
	pSysInfo->parray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);
	// If the array could not be created.
	if (pSysInfo->parray == NULL) {
		return E_OUTOFMEMORY;
	}
	VARIANT tempvar;
	VariantInit(&tempvar);
    QString bstrVals;
	//1. OEM Device Name 
	tempvar.vt = VT_BSTR;
    bstrVals = QString::fromWCharArray(pSYSTEM_INFO->GetOEMDeviceName());
	tempvar.bstrVal = bstrVals;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//2. OEM Product Range Name 
	lIndex++;
	tempvar.vt = VT_BSTR;
    bstrVals = QString::fromWCharArray(pSYSTEM_INFO->GetOEMProductRangeName());
	tempvar.bstrVal = bstrVals;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//3. Device Serial Number
	lIndex++;
	tempvar.vt = VT_UI4; //ULONG
	tempvar.ulVal = pSYSTEM_INFO->GetSerialNumber();
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//4. Device Type
	lIndex++;
	tempvar.vt = VT_BSTR;
    bstrVals = QString::fromWCharArray(pSYSTEM_INFO->GetOEMDeviceName());
	tempvar.bstrVal = bstrVals;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	// E528446
	// Requirement No. Reference - R12_FN5
	// Required to show the following information in General information tab
	//5. Recorder Name	
	lIndex++;
	tempvar.vt = VT_BSTR;
    bstrVals = QString::fromWCharArray(pSYSTEM_INFO->GetGeneralConfig()->Name);
	tempvar.bstrVal = bstrVals;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//6. Recorder ID
	lIndex++;
	tempvar.vt = VT_UI4;
	tempvar.ulVal = pSYSTEM_INFO->GetGeneralConfig()->ID;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//7. Options code
	lIndex++;
	tempvar.vt = VT_BSTR;
    bstrVals = QString::fromWCharArray(pSYSTEM_INFO->GetFactoryConfig()->OptionsCode);
	tempvar.bstrVal = bstrVals;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//8. Firmware version
	lIndex++;
	tempvar.vt = VT_BSTR;
	bstrVals = pDEVICE_INFO->GetFirmwareVersion();
	tempvar.bstrVal = bstrVals;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//9. Total credits
	lIndex++;
	tempvar.vt = VT_UI4;
	tempvar.ulVal = pSYSTEM_INFO->GetFactoryConfig()->Credits;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//10. Affected Credits
	lIndex++;
	tempvar.vt = VT_UI4;
	pSYSTEM_INFO->ValidateFWOptions(CSysInfo::fwoNoneRequired, tempvar.uiVal);
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//11. IP Address
	// get the IP address of this recorder
	pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
		if (ptCommsData->Ethernet.UseStaticIP) {
            bstrVals = CStringUtils::PackedIPv4ULongToStr(ptCommsData->Ethernet.IPAddress.L);// Get static IP address
		} else {
			QString strIPAddress = CRegistryKey::GetDHCPIPAddress();
            bstrVals = strIPAddress;
		}
		lIndex++;
		tempvar.vt = VT_BSTR;
		tempvar.bstrVal = bstrVals;
		if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
			goto CLEAN;
		}
	}
	//12. Network name
	lIndex++;
	tempvar.vt = VT_BSTR;
    strNetworkname = QString::asprintf("XS-%06.6d", pGlbSysInfo->GetSerialNumber());
    tempvar.bstrVal = strNetworkname;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	// 13.Set Recording On/Off depens on numbers of Pen started for logging
	pkPenManager = CPenManager::GetHandle();
	// now get the number of pens waiting for alignment
	usPENS_WAITING_FOR_ALIGNMENT = pkPenManager->NoOfPensWaitingForAlignment();
	usPENS_LOGGING = pkPenManager->NumberOfPensLogging() - usPENS_WAITING_FOR_ALIGNMENT;
	if (usPENS_LOGGING > 0) {
		//ULONG exportTime = pNVparam->GetFromNV()->value.ul;
        pNvVar = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_RECORDING_TIME/*NVV_FTP_RECORDING_TIME*/));
		exportTime = pNvVar->GetFromNV()->value.ul;
		if (exportTime <= 0)
            strRecording = "ON-Recycling";
		else
            strRecording = "ON";
	}
	lIndex++;
	tempvar.vt = VT_BSTR;
    tempvar.bstrVal = strRecording;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	// 14.
	// Requirement Refrence no. R12_FN1.
	// Variant information (Honeywell, Siemens , Generic)
	lIndex++;
	tempvar.vt = VT_BSTR;
    strVariant = QString::fromWCharArray( pSYSTEM_INFO->GetOEMCompanyName());
    tempvar.bstrVal = strVariant;
	if (FAILED(hResult = SafeArrayPutElement(pSysInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//
	CLEAN: {

		VariantClear(&tempvar);
		return hResult;
	}
	return S_OK;
}
//
// Function to calculate External memory info like SD,USB
//
BOOL WINAPI GetExMemoryInfo(long &lIndex, VARIANT *pDeviceInfo) {
	// Variables Declaration.
	HRESULT hResult = S_OK;
	VARIANT tempvar;
	VariantInit(&tempvar);
	QString strItem("");
	USHORT startDevice = IDS_EXTERNAL_SD;
	CMediaManager *pkMediaMgr = CMediaManager::GetHandle();
    QString strCF, strUSB1, strUSB2, strUSB3 = "EMPTY";
	USHORT usDevCount = 0;
	// Only show front SD information if credits permit it (EzTrend only)
	if ( pDALGLB->IsFrontCFSlotAvailable() == FALSE) {
        strItem = "EMPTY";
		lIndex++;
		tempvar.vt = VT_BSTR;
        tempvar.bstrVal = strItem;
		if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
			goto CLEAN;
		}
		startDevice = IDS_FIRST_USB;
	}
	// update the various media device states
	for (usDevCount = startDevice; usDevCount < IDS_ANY_DEVICE; usDevCount++) {
		const bool bDEVICE_PRESENT = (pkMediaMgr->IsDeviceInserted(static_cast<T_STORAGE_DEVICE>(usDevCount)) == TRUE);
		const ULONG ulFREE_SPACE_IN_KB = pkMediaMgr->GetFreeSpaceK(static_cast<T_STORAGE_DEVICE>(usDevCount));
		const ULONG ulTOTAL_SPACE_IN_KB = pkMediaMgr->GetTotalSizeK(static_cast<T_STORAGE_DEVICE>(usDevCount));
		// format the device state string
		if (bDEVICE_PRESENT) {
            strItem = QString::asprintf("%0.1fMB/%0.1fMB", KB_TO_MB(static_cast<float>(ulFREE_SPACE_IN_KB)),
                    KB_TO_MB(static_cast<float>(ulTOTAL_SPACE_IN_KB)));
		} else {
			// no device present
            strItem = "EMPTY";
			lIndex++;
			tempvar.vt = VT_BSTR;
            tempvar.bstrVal = strItem;
			if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
				goto CLEAN;
			}
			continue;
			//strItem = tr("Empty");
		}
		switch (usDevCount) {
		case IDS_EXTERNAL_SD:
			strCF = strItem;
			lIndex++;
			tempvar.vt = VT_BSTR;
            tempvar.bstrVal = strCF;
			break;
		case IDS_FIRST_USB:
			strUSB1 = strItem;
			lIndex++;
			tempvar.vt = VT_BSTR;
            tempvar.bstrVal = strUSB1;
			break;
		case IDS_SECOND_USB:
			strUSB2 = strItem;
			lIndex++;
			tempvar.vt = VT_BSTR;
            tempvar.bstrVal = strUSB2;
			break;
		}
		if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
			goto CLEAN;
		}
	}
	CLEAN: {
		//
		//bstrVals = "";
		VariantClear(&tempvar);
		return TRUE;
	}
	return TRUE;
}
//
//****************************************************************************
/// CV6AppInterface : GetDeviceInfo 
/// 
/// Wraps the Hardware information.
///
/// @param[OUT] VARIANT * 
/// 
/// @return	 S_OK - Successful operation.
//****************************************************************************
HRESULT CV6AppInterface::GetDeviceInfo(VARIANT *pDeviceInfo) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
///> the no of data that will be passed back is set here
//#define DEVICE_ELEMENTS 11 //old
#define DEVICE_ELEMENTS 16
	if (pDeviceInfo == NULL)
		return E_INVALIDARG;
//	*dwSize = (DWORD)ELEMENTS;
	// Variables Declaration.
	HRESULT hResult = S_OK;
	//
	USHORT startDevice = IDS_EXTERNAL_SD;
	CMediaManager *pkMediaMgr = CMediaManager::GetHandle();
    QString strCF, strUSB1, strUSB2, strUSB3 = "EMPTY";
	QString strItem("");
	USHORT usDevCount = 0;
	bool bDEVICE_PRESENT = false;
	ULONG ulFREE_SPACE_IN_KB = 0;
	ULONG ulTOTAL_SPACE_IN_KB = 0;
	QString strDeviceNameWithVariant, strCommBrd;
	long lIndex = 0;
	pDeviceInfo->vt = VT_ARRAY | VT_VARIANT;
	// SafeArray Bounds Declaration.
	SAFEARRAYBOUND aDataItemBounds[1];
	aDataItemBounds[0].lLbound = 0;
	aDataItemBounds[0].cElements = DEVICE_ELEMENTS;
	// Create the one dimensional Safe Array of type VARIANTS.
	pDeviceInfo->parray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);
	// If the array could not be created.
	if (pDeviceInfo->parray == NULL) {
		return E_OUTOFMEMORY;
	}
	VARIANT tempvar;
	VariantInit(&tempvar);
    //QString bstrVals;
	T_VERSIONNUM ver;
	QString sztemp;
	//1. Board Build Number 
	tempvar.vt = VT_UI2; //SHORT
	tempvar.uiVal = pDEVICE_INFO->GetBoardBuildNo();
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//2. Board revision Number
	lIndex++;
	tempvar.vt = VT_UI2;
	tempvar.uiVal = pDEVICE_INFO->GetBoardRev();
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//3. Boot loader Version
	lIndex++;
	tempvar.vt = VT_BSTR;
	ver = pDEVICE_INFO->GetBootVer();
    sztemp = QString::asprintf(("%u.%u"), ver.MajorRev, ver.MinorRev);
    tempvar.bstrVal = sztemp; //coverity fix 780315
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//4. Board Support Package Version
	lIndex++;
	tempvar.vt = VT_BSTR;
	ver = pDEVICE_INFO->GetBSPVer();
    sztemp = QString::asprintf(("%u.%u"), ver.MajorRev, ver.MinorRev);
    tempvar.bstrVal = sztemp; //coverity fix 780315
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//5. Device Available Memory status in Bytes
	lIndex++;
	tempvar.vt = VT_UI4; //ULONG
	tempvar.ulVal = pDEVICE_INFO->GetAvailableMemory();
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//6. Device RAM size in Bytes
	lIndex++;
	tempvar.vt = VT_UI4; //ULONG
	tempvar.ulVal = pDEVICE_INFO->GetRamSize();
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//7. Device Flash size in Bytes
	lIndex++;
	tempvar.vt = VT_UI4; //ULONG
	tempvar.ulVal = pDEVICE_INFO->GetFlashSize();
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//8. Device SRAM size in Bytes
	lIndex++;
	tempvar.vt = VT_UI4; //ULONG
	tempvar.ulVal = pDEVICE_INFO->GetSRAMSize();
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//9. Device Internal Compact Flash size in kBytes
	lIndex++;
	tempvar.vt = VT_UI4; //ULONG
	tempvar.ulVal = (pDEVICE_INFO->GetInternalCFSize() / 1024);
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//10. Device Screen type
	lIndex++;
	tempvar.vt = VT_UI2; //ULONG
	tempvar.uiVal = pDEVICE_INFO->GetScreenType(); //0 - 5.5, 1 - 12.1', 2 - 5'	
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	// 11. Number of Slot available
	lIndex++;
	tempvar.vt = VT_UI1; //UCHAR/BYTE
	tempvar.bVal = pDEVICE_INFO->GetIOCardInfo();
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//E528446
	if (!GetExMemoryInfo(lIndex, pDeviceInfo))
		goto CLEAN;
	// Device Name with Variant information (Honeywell, Siemens , Generic)
	lIndex++;
	tempvar.vt = VT_BSTR;
    //strDeviceNameWithVariant = QString::asprintf("%s (%s)",pSYSTEM_INFO->GetOEMDeviceName(),pSYSTEM_INFO->GetOEMCompanyName());
    strDeviceNameWithVariant = QString::asprintf("%s", pSYSTEM_INFO->GetOEMDeviceName());
    tempvar.bstrVal = strDeviceNameWithVariant;
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//4. Check communication board Fitted or NOT
	lIndex++;
	tempvar.vt = VT_BSTR;
    strCommBrd = "No";
	if (pDEVICE_INFO->IsRecorderEzTrend()) //ARISTOS QXe Device Type updates
	{
		if (pDALGLB->IsCommsBoardFitted())
            strCommBrd = "yes";
	}
    tempvar.bstrVal = strCommBrd;
	if (FAILED(hResult = SafeArrayPutElement(pDeviceInfo->parray, &lIndex, &tempvar))) {
		goto CLEAN;
	}
	//
	CLEAN: {
		//
		//bstrVals = "";
		VariantClear(&tempvar);
		return hResult;
	}
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : GetSlotInfo 
/// 
/// Wrapper function for getting the Slot info.
///	slotnum is 0 based index
///
/// @param[IN]  USHORT* 
/// @param[OUT] VARIANT * 
/// 
/// @return	 S_OK - Successful operation.
//****************************************************************************
HRESULT CV6AppInterface::GetSlotInfo(USHORT slotNum, VARIANT *pSlotInfo) {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	if (pSlotInfo == NULL)
		return E_INVALIDARG;
	HRESULT hResult = E_FAIL;
	long lIndex = 0;
	// SafeArray Bounds Declaration.
	SAFEARRAYBOUND aDataItemBounds[1];
	aDataItemBounds[0].lLbound = 0;
	//aDataItemBounds[0].cElements	= 1; //old
	aDataItemBounds[0].cElements = 3; //new
	USHORT slottype = 0;
	USHORT slotchannel = 0;
    QString szBstrval;
	pSlotInfo->vt = VT_ARRAY | VT_VARIANT;
	// Create the one dimensional Safe Array of type VARIANTS.
	pSlotInfo->parray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);
	// If the array could not be created.
	if (pSlotInfo->parray == NULL) {
		return E_OUTOFMEMORY;
	}
	VARIANT tempvar;
	VariantInit(&tempvar);
	tempvar.vt = VT_BSTR;
	// GetPhysicalSlotType returns a demo card as being invalid.
//	slottype		= pDEVICE_INFO->GetPhysicalSlotType(slotNum); 
	slottype = pDEVICE_INFO->GetSlotType(slotNum);
	// GetSlotType returns a demo card as an AI card, so need to override.
	if ( pDEVICE_INFO->IsDemoBoard(slotNum)) {
		slottype = AI_DEMO_BOARD;
	}
	switch (slottype) {
	case BOARD_AI:
	case BOARD_EZ_AI:
        szBstrval = ("Analogue Input board");
		break;
	case BOARD_AR:
        szBstrval = ("Alarm and Relay board");
		break;
	case BOARD_DIO:
        szBstrval = ("Digital Input/Output board");
		break;
	case BOARD_AO:
        szBstrval = ("Analogue Output board");
		break;
	case BOARD_PI:
        szBstrval = ("Pulse Input board");
		break;
	case BOARD_POWER_RELAY:
        szBstrval = ("Power relay board");
		break;
	case AI_DEMO_BOARD:
        szBstrval = ("AI demo board");
		break;
	case DIGITAL_DEMO_BOARD:
        szBstrval = ("Digital demo board");
		break;
	case BOARD_NOT_FITTED:
        szBstrval = ("Board Not Fitted");
		break;
	case BOARD_INVALID:
	case BOARD_NOT_YET5:
	case BOARD_NOT_YET6:
	case BOARD_NOT_YET7:
	case BOARD_NOT_YET9:
	case BOARD_NOT_YET10:
	case BOARD_NOT_YET11:
	case BOARD_NOT_YET12:
	case BOARD_NOT_YET13:
	case BOARD_NOT_YET14:
	case BOARD_NOT_YET15:
    case BOARD_POS_NOT_TESTED:
        szBstrval = ("Invalid Board");
		break;
	} //Switch
	tempvar.bstrVal = szBstrval;
	if (hResult = SafeArrayPutElement(pSlotInfo->parray, &lIndex, &tempvar)) {
		VariantClear(&tempvar);
		return hResult;
	}
	// E528446
	// Requirement No. Reference - R12_FN8
	// 2. Get channels for given slot number
	USHORT startChanNo = 0;
	CSlotMap *pSlotMap = NULL;
	CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	QString strSlotChannel;
	if (!pBrdInfo || !pSlotMap) {
		VariantClear(&tempvar);
		return S_FALSE;
	}
	switch (pBrdInfo->WhatBoardType(slotNum)) {
	case BOARD_AI:
	case BOARD_EZ_AI:
		startChanNo = pSlotMap->GetSysChannelFromAnaInChannel(slotNum, 0, ONE_BASED);
		break;
	case BOARD_AO:
		startChanNo = pSlotMap->GetSysChannelFromAnaOutChannel(slotNum, 0, ONE_BASED);
		break;
	case BOARD_DIO:
		startChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNum, 0, ONE_BASED);
		break;
	case BOARD_AR:
		startChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNum, 0, ONE_BASED);
		break;
	case BOARD_PI:
		startChanNo = pSlotMap->GetSysChannelFromDedicatedPulseChannel(slotNum, 0, ONE_BASED);
		break;
	default:
		startChanNo = pSlotMap->GetSysChannelFromAnaInChannel(slotNum, 0, ONE_BASED);
		break;
	};
	lIndex++;
	tempvar.vt = VT_BSTR;
    strSlotChannel = QString::asprintf("%d-%d", startChanNo, startChanNo + pBrdInfo->GetNoOfChannels(slotNum) - 1);
    tempvar.bstrVal = strSlotChannel;
	if (hResult = SafeArrayPutElement(pSlotInfo->parray, &lIndex, &tempvar)) {
		VariantClear(&tempvar);
		return hResult;
	}
	//3. Get Firmaware version for given slot number
	lIndex++;
	tempvar.vt = VT_BSTR;
	UCHAR version[BOARD_REVISION_STR_LEN + 1];
	QString strFWVersion;
	if (TRUE == pBrdInfo->GetBoardFirmwareRevision(slotNum, version, sizeof(version)))
        strFWVersion = QString::asprintf("%S-%03d", version, pBrdInfo->GetFirmwareBuildNo(slotNum));
	else
        strFWVersion = "--";
    tempvar.bstrVal = strFWVersion;
	if (hResult = SafeArrayPutElement(pSlotInfo->parray, &lIndex, &tempvar)) {
		VariantClear(&tempvar);
		return hResult;
	}
	//
	VariantClear(&tempvar);
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : GetRemoteViewerOptInfo 
/// 
/// Remote viewer option code information
///
/// @param[OUT] SHORT* -  To fill the option code info.
/// 
/// @return	 S_OK - Successful operation.
//****************************************************************************
HRESULT CV6AppInterface::GetRemoteViewerOptInfo(SHORT *pRemoteViewer) {
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	BOOL result = FALSE;
	if (pSYSTEM_INFO->IsInManufacturingMode()) // allow remote view in manufacturing mode
	{
		result = TRUE;
	} else {
		T_PCOMMUNICATIONS pCommsBlock = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
		if ((pSYSTEM_INFO->FWOptionRemoteViewerAvailable() == TRUE) && (pCommsBlock->SecurityOptions.RDT == TRUE)) {
			result = TRUE;
		} else {
			result = FALSE;
		}
	}
	*pRemoteViewer = (SHORT) result;
	return S_OK;
}
/***************************************************************************/
//****************************************************************************
/// CV6AppInterface : SetOPCGeneralInfo
/// 
/// Set the OPC General Info for the V6App.
///
/// @param[in] VARIANT vOPCGeneralInfo - Defines General Info.
/// 
/// @return	 S_OK - Successfull Operation.
///
//****************************************************************************
HRESULT CV6AppInterface::SetOPCGeneralInfo( /*[IN]*/VARIANT vOPCGeneralInfo) {
	// Variables Declaration.
	HRESULT hStatus = S_OK;
	VARIANT *pvOPCDetails = NULL;
	// Check the Input parameter.
	if (vOPCGeneralInfo.parray == NULL)
		return E_INVALIDARG;
	// Extract the SafeArray
	if (hStatus = SafeArrayAccessData((vOPCGeneralInfo.parray), (void**) &pvOPCDetails))
		return hStatus;
	// Check the Returned SafeArray Pointer.
	if (pvOPCDetails == NULL)
		return E_INVALIDARG;
	// Unlock the SafeArray.
	if (hStatus = SafeArrayUnlock(vOPCGeneralInfo.parray))
		return hStatus;
	// Extract the OPCServer Deatils and fill the structure.
	long lOPCInfoItemIndex = 0;
	try {
		// Protect the OPCServer Info Structure.
		m_ReqObj->ms_csOPCServerInfo.lock();
		// Server Status
		m_ReqObj->m_sOPCDetails.bServerStatus = true;
		// 1.Recommended OPCDAServer connections. 
		m_ReqObj->m_sOPCDetails.usOPCDARecomConnections = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 2.Recommended OPCA&EServer connections. 
		m_ReqObj->m_sOPCDetails.usOPCAERecomConnections = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 3.Number of OPCDAClients Connected.
		m_ReqObj->m_sOPCDetails.usOPCDAClients = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 4.Number of OPCAEClients Connected.
		m_ReqObj->m_sOPCDetails.usOPCAEClients = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 5.Minimum Update Rate Supported for the OPCDAServer.
		m_ReqObj->m_sOPCDetails.usMinUpdateRateSupported = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 6.Maximum Number of Groups Supported for the OPCDAServer.
		m_ReqObj->m_sOPCDetails.usMaxGroupSupported = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 7.Maximum Number of Unique Items Supported for the OPCDAServer.
		m_ReqObj->m_sOPCDetails.usMaxUniqueItemsSupported = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 8.Number of Groups Requested to OPCDAServer.
		m_ReqObj->m_sOPCDetails.usGroupsRequested = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 9.Number of Items Requested to OPCDAServer.
		m_ReqObj->m_sOPCDetails.usItemsRequested = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 10. Number of Acive Alarms Supported in OPCA&EServer.
		m_ReqObj->m_sOPCDetails.usMaxActiveAlarmsSupported = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		lOPCInfoItemIndex++;
		// 11. Number of Acive Alarms Available in OPCA&EServer.
		m_ReqObj->m_sOPCDetails.usActiveAlarmsAvailable = (pvOPCDetails + lOPCInfoItemIndex)->iVal;
		// Protect the OPCServer Info Structure.
		m_ReqObj->ms_csOPCServerInfo.unlock();
	}
	catch (...)
	{
		hStatus = E_INVALIDARG;
	}
	// Inform that OPCServer Info is updated.
	SetEvent(m_ReqObj->m_hOPCInfoReqComplete);
	return hStatus;
}
//****************************************************************************
/// CV6AppInterface :  StartOPCServerInfoThread Function
/// 
///	Starts the thread that would be used to get the OPCServer Information.
///
/// @param[in]	None
/// 
/// @return	 S_OK	-  For successfull operation.
///
//****************************************************************************
HRESULT CV6AppInterface::StartOPCServerInfoThread() {
    // AFX_MANAGE_STATE (AfxGetStaticModuleState())
	// TODO: Add your implementation code here
	// Variables Declaration
	HRESULT hResult = S_OK;
	// Protect the OPCServer Info Structure.
	m_ReqObj->ms_csOPCServerInfo.lock();
	// Intialize the structure.
	m_ReqObj->m_sOPCDetails.bServerStatus = false;
	m_ReqObj->m_sOPCDetails.usActiveAlarmsAvailable = 0;
	m_ReqObj->m_sOPCDetails.usGroupsRequested = 0;
	m_ReqObj->m_sOPCDetails.usItemsRequested = 0;
	m_ReqObj->m_sOPCDetails.usMaxActiveAlarmsSupported = 0;
	m_ReqObj->m_sOPCDetails.usMaxGroupSupported = 0;
	m_ReqObj->m_sOPCDetails.usMaxUniqueItemsSupported = 0;
	m_ReqObj->m_sOPCDetails.usMinUpdateRateSupported = 0;
	m_ReqObj->m_sOPCDetails.usOPCAEClients = 0;
	m_ReqObj->m_sOPCDetails.usOPCAERecomConnections = 0;
	m_ReqObj->m_sOPCDetails.usOPCDAClients = 0;
	m_ReqObj->m_sOPCDetails.usOPCDARecomConnections = 0;
	// Protect the OPCServer Info Structure.
	m_ReqObj->ms_csOPCServerInfo.unlock();
	// If Thread is not running.
	if (m_hlOPCServerInfo == INVALID_HANDLE_VALUE) {
		DWORD dwThreadId = 0;
		m_hlOPCServerInfo = CreateThread( NULL, 0, (LPTHREAD_START_ROUTINE) & OPCInfoThread, this, 0, &dwThreadId);
	}
	//
	// Stability Project Fix:
	// 
	// Priority of the thread was lowered to resolve the OPC hang issue
	// But is was observed that the issue is not getting resolved.
	// Hence Thread Priority is set back to Normal.
	//
	//SetThreadPriority( m_hlOPCServerInfo, THREAD_PRIORITY_LOWEST );
	return hResult;
}
//****************************************************************************
/// CV6AppInterface : OPCInfoThread
/// 
/// Static functiom to call the thread procedure. 
///
/// @param[in] pThreadFunc - Void pointer.
/// 
/// @return	 UINT 
///			 Zero  - For the unreported errors.  
///    One - For SuccessFull Operation.
///    
///
//****************************************************************************
UINT __cdecl CV6AppInterface::OPCInfoThread( /*[IN] */void *pThreadFunc) {
	// Call thread procedure.
	return ((CV6AppInterface*) pThreadFunc)->OPCInfoThreadFunc();
}
//****************************************************************************
/// CV6AppInterface : OPCInfoThreadFunc
/// 
/// Thread Function Implementation.
/// 
/// @param[in] None
/// 
/// @return	  Zero  - For the unreported errors.  
///     One - For SuccessFull Operation.
//****************************************************************************
UINT CV6AppInterface::OPCInfoThreadFunc() {
	// Variables Declarations
	HRESULT hResult = S_OK;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for OPC Info thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the OPCInfo thread has 
		//started
        pThreadInfo->UpdateThreadInfo(AM_OPC_INFO_THREAD, true);
	}
#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
        swprintf( szDbgMsg, "CV6AppInterface::OPCInfoThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
  #endif
	// Check the Status for the OPCInfo Thread.
	while (m_ReqObj->m_bStopOPCInfoThread) {
		if (pThreadInfo != NULL) {
			//Ignore the OPCThreadInfo for the WatchDog
			//till the thread waits infinitely
            pThreadInfo->UpdateThreadInfo(AM_OPC_INFO_THREAD, false);
		}
		// Wait for the Event.
		WaitForSingleObject(m_ReqObj->m_hOPCInfo, INFINITE);
		if (pThreadInfo != NULL) {
			//Consider the OPCThreadInfo for the WatchDog
			//as the thread has completed it's wait
            pThreadInfo->UpdateThreadInfo(AM_OPC_INFO_THREAD, true);
		}
		// Check the flag to stop the OPC Info thread.
		if (m_ReqObj->m_bStopOPCInfoThread) {
			// Call the OPCServer to return back the OPCServer Info.
			Fire_OnGetOPCInfo();
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the OPC InfoThread
			//thread after each iteration
            pThreadInfo->UpdateThreadCounter(AM_OPC_INFO_THREAD);
		}
		if (pThreadInfo != NULL) {
			//Update the info that the OPCInfo thread is exiting
			//Hence this thread need not be considered to kick the 
			//watchdog
            pThreadInfo->UpdateThreadInfo(AM_OPC_INFO_THREAD, false);
		}
	}
	return 1;
}
//************************ CRequestObject*************************************
//****************************************************************************
//  CRequestObject : GetOPCDetails
///
/// Return the Refernce for the structure T_OPC_DETAILS having the OPCServerInfo.
///
/// @param[in]	None
///
//****************************************************************************
T_OPC_DETAILS& CRequestObject::GetOPCDetails() {
	// Return the reference to the OPC Details Structure.
	return m_sOPCDetails;
}
//****************************************************************************
//  CRequestObject : CallOPCServerForInfo
///
/// Set the Event to inform the OPCInfoThread to get the OPCServerInformation.
///
/// @param[in]	None
///
//****************************************************************************
void CRequestObject::CallOPCServerForInfo() {
	// Check for the OPC Option Code.
	// Thread would be running only the option code is enabled.
	if ( pSYSTEM_INFO->FWOptionOPCUAAvailable() == TRUE) {
		// Make Call to OPCServer to get the OPCServer Information.
		SetEvent(m_hOPCInfo);
		// Wait Untill OPCServer fills the Information.
        if (WaitForSingleObject(m_hOPCInfoReqComplete, g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS) != WAIT_OBJECT_0) {
			// timeout therefore assume the server is down
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
					"OPC Error - failed to retrieve OPC server information");
		}
	}
	// Stop OPCInfo thread if it is running.
	else if (m_bStopOPCInfoThread) {
		// Set the flag as false.
		m_bStopOPCInfoThread = false;
		// Intimate to stop the OPCInfo thread.
		SetEvent(m_hOPCInfo);
	}
	return;
}
//****************************************************************************
/// CV6AppInterface : GetWebLogOffTime
/// 
/// Returns the Web Log Off Time.
///
/// @param[OUT] SHORT* -  To fill the Web Log Off Time.
/// 
/// @return	 S_OK - Successful operation.
//****************************************************************************
HRESULT CV6AppInterface::GetWebIdleTimeOut(SHORT *pWebLogOffTime) {
	// Variable Declaration.
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	short sLogoffTime = 0;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	// Get the Web Log Off Time.
	ePmmSts = CPasswordInterface.GetWebLogOffTime(&sLogoffTime);
	if (CSTATUS_OK != ePmmSts)
		return ePmmSts;
	// Set the OUT parameter.
	*pWebLogOffTime = (sLogoffTime);
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : UpdateWebLastAccessTime
/// 
/// Updates the Last Access Time for the Specified Web User ID
///
/// @param[IN] SHORT -  Web User ID.
/// 
/// @return	 S_OK - Successful operation.
//****************************************************************************
HRESULT CV6AppInterface::UpdateWebLastAccessTime(SHORT nWebUserID) {
	// Variable Declaration.
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	// Test if application is available for access
	if (TestApplicationSema() != APPACCESS_OK)
		return E_FAIL;
	// Update the Last Access Time For the Specified Web User.
	ePmmSts = CPasswordInterface.UpdateLastAccessTime(nWebUserID);
	if (CSTATUS_OK != ePmmSts)
		return ePmmSts;
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : SetRealTimeData
/// 
/// Sets the real time data
///
/// @param[IN] USHORT -   clientId
/// @param[IN] VARIANT* -  pvConfigList
/// 
/// @return	 S_OK - Successful operation.
//****************************************************************************
HRESULT CV6AppInterface::SetRealTimeData(USHORT clientId, VARIANT *pvConfigList) {
	HRESULT hr = S_OK;
	SAFEARRAY *arrayDescriptor;
	arrayDescriptor = pvConfigList->parray;
	BYTE *safeArrayData;
	// Access the array data and copy the string to the array
	SafeArrayAccessData(arrayDescriptor, (void**) &safeArrayData);
	int elementCnt = pvConfigList->parray->rgsabound[0].cElements;
	SafeArrayUnaccessData(pvConfigList->parray);
	RLOGCONFIGSTRUCT *logConfigStruct = new RLOGCONFIGSTRUCT();
	memcpy(logConfigStruct, safeArrayData, elementCnt);
	CPenManager *pHandle = CPenManager::GetHandle();
	if (pHandle != NULL) {
		//Set the realtime configuration with the PenManager
		pHandle->SetRealTimeData(TRUE, clientId, logConfigStruct);
	}
	return hr;
}	//end SetRealTimeData()
//***********************************************************************************
/// CV6AppInterface : GetRealTimeData
/// 
/// Returns the realtime data to the client
/// @param[IN] USHORT -  clientId 
/// @param[IN] VARIANT* -  varRealTimeData
/// 
/// @return	 S_OK - Successful operation.
//************************************************************************************
HRESULT CV6AppInterface::GetRealTimeData(USHORT clientId, VARIANT *varRealTimeData) {
	HRESULT hResult = S_OK;
	//Get the handle for the pen manager
	CPenManager *pPenManager = CPenManager::GetHandle();
	RTDATASTRUCTMAP rtDataStructMap;
	do {
		switch (WaitForSingleObject(pPenManager->GetRTDataEventHandle(clientId), 5000)) {
		case WAIT_OBJECT_0:
			//Get the real time data
			rtDataStructMap = pPenManager->GetRealTimeData();
			ResetEvent(pPenManager->GetRTDataEventHandle(clientId));
			qDebug("Real Time Data is available\n");
			break;
		case WAIT_ABANDONED:
			SetLastError (ERROR_INVALID_FUNCTION);
			qDebug("Wait abandoned\n");
			return (E_FAIL);
			break;
		}
	} while (rtDataStructMap.size() == 0 && pPenManager->IsConnectionAlive(clientId) == TRUE);
	//We have the RTDataStruct Copy hence we can clear the entry from
	//the map maintained by penmanager
	pPenManager->SetFreeRTDataStruct(clientId);
	RTDATASTRUCTMAP::iterator rtDataStructMapItr = rtDataStructMap.find(clientId);
	if (rtDataStructMapItr != rtDataStructMap.end()) {
		SAFEARRAY *safeArray;
		BYTE *safeArrayData;
		int vecSize = rtDataStructMapItr->second.size();
		int structSize = sizeof(RTDATASTRUCT);
		int size = vecSize * structSize;
		// Create a one-dimensional array using the length (excluding the null character)
		safeArray = SafeArrayCreateVector(VT_I1, 0, size);
		int offset = 0;
		RTDATASTRUCTLIST structList = rtDataStructMapItr->second;
		for (LONG lIndex = 0; lIndex < vecSize; lIndex++) {
			RTDATASTRUCT datastruct = structList.at(lIndex);
			// Access the array data and copy the string to the array
			SafeArrayAccessData(safeArray, (void**) &safeArrayData);
			CopyMemory(safeArrayData + offset, &datastruct, sizeof(RTDATASTRUCT));
			offset = offset + sizeof(RTDATASTRUCT);
            SafeArrayUnaccessData(safeArray);
		}
		VariantInit(varRealTimeData);
		varRealTimeData->vt = VT_ARRAY | VT_I1;
		varRealTimeData->parray = safeArray;
	}
	return hResult;
}		//end GetRealTimeData()
//**********************************************************************************************
/// CV6AppInterface : SetSocketConnected
/// 
/// Set the flag indicating the socket is connected to TRUE
/// @param[IN] USHORT   -  clientId 
/// @param[IN] VARIANT_BOOL -  bIsSocketConnected
/// 
/// @return	 S_OK - Successful operation.
//***********************************************************************************************
HRESULT CV6AppInterface::SetSocketConnected(USHORT clientId, VARIANT_BOOL bIsSocketConnected) {
	CPenManager *pPenManager = CPenManager::GetHandle();
	if (pPenManager != NULL) {
		pPenManager->SetSocketConnected(clientId, bIsSocketConnected);
	}
	return S_OK;
}		//end SetSocketConnected()
//****************************************************************************
/// CV6AppInterface : GetSecureZoneInfo 
/// 
/// Secure Zone information
///
//****************************************************************************
HRESULT CV6AppInterface::GetSecureZoneInfo(UINT *pSecureZone) {
	if ((NULL != pGlbSysInfo) && (NULL != pSecureZone)) {
		*pSecureZone = pGlbSysInfo->GetRecSecurityZone();
	}
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : IsRecorderInSafeZone 
/// 
/// Secure Zone information
///
//****************************************************************************
HRESULT CV6AppInterface::IsRecorderInSafeZone(DWORD *pdwIsInSafeZone) {
	if ((NULL != pGlbSysInfo) && ( NULL != pdwIsInSafeZone)) {
		*pdwIsInSafeZone = pGlbSysInfo->IsRecorderInSafeZone();
	}
	return S_OK;
}
//****************************************************************************
/// CV6AppInterface : GetCertificateDetails
/// 
/// Recorder Serial number
///
//****************************************************************************
HRESULT CV6AppInterface::GetCertificateDetails(QString *bstrCertSub) {
	QString strCertSub;
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
	BOOL bGlobalCAEnabled = ptCommsData->SecurityOptions.CACertificate;
	if (bGlobalCAEnabled) {
		CCertSubjectsStore cCertSubjStore;
		strCertSub = cCertSubjStore.GetServerSubjectKey();
	} else {
        strCertSub = QString::asprintf(("XS-%06.6d"), pGlbSysInfo->GetSerialNumber());
	}
    *bstrCertSub = strCertSub;
	return S_OK;
}

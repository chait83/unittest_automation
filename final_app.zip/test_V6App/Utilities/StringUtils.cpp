/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Utilities
/// @n Filename:	StringUtils.cpp
/// @n Description: Implementation of general utility class providing string functions
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 46	Stability Project 1.41.1.3	7/2/2011 5:01:57 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 45	Stability Project 1.41.1.2	7/1/2011 4:38:59 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 44	Stability Project 1.41.1.1	3/17/2011 3:20:48 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 43	Stability Project 1.41.1.0	2/15/2011 3:04:00 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "StringUtils.h"
#include "V6defines.h"
#include "V6Config.h"
#include <wchar.h>
#include <math.h>
#include "V6globals.h"
#include "EUDCDefs.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
/// Static Initialisation
const QString CStringUtils::ms_strDELIMITTER = "|";
const QString CStringUtils::ms_strREPORTS_FILE_EXT = "*.rtf";
//****************************************************************************
// CStringUtils( )
///
/// Constructor
///
//****************************************************************************
CStringUtils::CStringUtils(void) {
}
//****************************************************************************
// ~CStringUtils( )
///
/// Destructor
///
//****************************************************************************
CStringUtils::~CStringUtils(void) {
}
//****************************************************************************
// ULONG IPv4StrToPackedIPv4( const QString  &rstrIPAddress )
///
/// Converts string ip address to a ULONG
///
/// @param[in]		const QString  &rstrIPAddress - THe IP address to convert
///
/// @return			The converted IP address as a ULONG - 0 if a problem
///
//**************************************************************************** 
const ULONG CStringUtils::IPv4StrToPackedIPv4(const QString &rstrIPAddress) {
	//	ip routine
	//	convert stored string ip address from n1.n2.n3.n4 to
	//	stored DWORD n4.n3.n2.n1
	//	test for validity
	const int iMAX_CHARS = 24;
    char *caIPAddr;
#if _MSC_VER < 1400 
    QString pstr;
    caIPAddr = pstr.toLocal8Bit().data();
#else
	size_t pNoOfChars;
	wcstombs_s( &pNoOfChars, caIPAddr, iMAX_CHARS, rstrIPAddress, iMAX_CHARS );
#endif
	ULONG ulIPAddr = inet_addr(caIPAddr);
	return ulIPAddr;
}
//****************************************************************************
// const ULONG PackedIPv4ULongToStr( const QString  &rstrIPAddress )
///
/// Converts ULONG ip address to a string
///
/// @param[in]		const ULONG ulIPADDR - The IP Address as a ULONG
///
/// @return			The converted IP address as a string
///
//**************************************************************************** 
const QString CStringUtils::PackedIPv4ULongToStr(const ULONG ulIPADDR) {
	QString strIPAddr("");
	T_IPADDRESS tIPAddr;
	tIPAddr.L = ulIPADDR;
	strIPAddr = QString::asprintf("%u.%u.%u.%u", tIPAddr.B[0], tIPAddr.B[1], tIPAddr.B[2], tIPAddr.B[3]);
	return strIPAddr;
}
//****************************************************************************
/// Converts a span in seconds to HH:MM:SS span in format nnH:nnM:nnS
///
/// @param[in]		number of seconds as a long long
///
/// @return			The string in the format nnh:nnm:nns
///
//**************************************************************************** 
const QString CStringUtils::GetHHMMSSspanFromSeconds(LONGLONG timeInSeconds) {
	ULONG Seconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_A_MINUTE);
	timeInSeconds -= Seconds;
	ULONG MinutesInSeconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_AN_HOUR);
	timeInSeconds -= MinutesInSeconds;
	QString strHHMMSS("");
	strHHMMSS = QString::asprintf("%dh:%02dm:%02ds", static_cast<ULONG>(timeInSeconds / SECONDS_IN_AN_HOUR),
			MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);
	return strHHMMSS;
}
//****************************************************************************
/// Converts a span in seconds to an autoformatted value showing the highest relevant
/// value in nnd:nnh:nnm:nns, if there are no full days then will return nnh:nnm:nns
/// and if there are no full hours then will return nnm:nns
///
/// @param[in]		number of seconds as a long long
///	@param[in]		const bool bTRIM_ZERO_FIELDS - Indicates that any leasding or trailing times that
///					are zero should be trimmed out e.g. 0h:23m:00s would become 23m
///
/// @return			The string in the format nnd:nnh:nnm:nns	(inc days)
///											nnh:nnm:nns		(days = 0)
///											nnm:nns			(days and hours = 0)
///
//**************************************************************************** 
const QString CStringUtils::GetAutoDDHHMMSSspanFromSeconds(LONGLONG timeInSeconds,
		const bool bTRIM_ZERO_FIELDS /* = false */) {
	ULONG Seconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_A_MINUTE);
	timeInSeconds -= Seconds;
	ULONG MinutesInSeconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_AN_HOUR);
	timeInSeconds -= MinutesInSeconds;
	ULONG DaysInSeconds = 0;
	ULONG HoursInSeconds = 0;
	if (timeInSeconds >= SECONDS_IN_A_DAY) {
		// At least 1 day span
		HoursInSeconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_A_DAY);
		timeInSeconds -= HoursInSeconds;
		DaysInSeconds = static_cast<ULONG>(timeInSeconds);
	} else {
		// less then a day
		HoursInSeconds = +static_cast<ULONG>(timeInSeconds);
	}
	// asprintf string depending on actual time span.
	QString strDDHHMMSS("");
	const bool bINCLUDE_DAYS = (DaysInSeconds > 0);
	bool bIncludeHours = (HoursInSeconds > 0);
	bool bIncludeMinutes = (MinutesInSeconds > 0);
	const bool bINCLUDE_SECONDS = (Seconds > 0);
	if (bTRIM_ZERO_FIELDS) {
		const CHAR *strasprintf;
		QString strAddString("");
		// check if days present
		if (bINCLUDE_DAYS) {
			strDDHHMMSS = QString::asprintf("%dd", DaysInSeconds / SECONDS_IN_A_DAY);
		}
		// check if hours present or days present and minutes present
		if (bIncludeHours || (bINCLUDE_DAYS && bIncludeMinutes)) {
			strasprintf = bINCLUDE_DAYS ? ":%02dh" : "%dh";
			strAddString = QString::asprintf(strasprintf, (HoursInSeconds / SECONDS_IN_AN_HOUR));
			strDDHHMMSS += strAddString;
			bIncludeHours = true;
		}
		// check if minutes present or hours present and seconds
		if (bIncludeMinutes || (bIncludeHours && bINCLUDE_SECONDS)) {
			strasprintf = bIncludeHours ? ":%02dm" : "%dm";
			strAddString = QString::asprintf(strasprintf, (MinutesInSeconds / SECONDS_IN_A_MINUTE));
			strDDHHMMSS += strAddString;
			bIncludeMinutes = true;
		}
		if (bINCLUDE_SECONDS) {
			strasprintf = bIncludeMinutes ? ":%02ds" : "%ds";
			strAddString = QString::asprintf(strasprintf, Seconds);
			strDDHHMMSS += strAddString;
		}
	} else {
		if (bINCLUDE_DAYS) {
			// There are days, so fully formatted
			strDDHHMMSS = QString::asprintf("%dd:%dh:%02dm:%02ds", DaysInSeconds / SECONDS_IN_A_DAY,
					HoursInSeconds / SECONDS_IN_AN_HOUR, MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);
		} else if (bIncludeHours) {
			// No days but hours
			strDDHHMMSS = QString::asprintf("%dh:%02dm:%02ds", HoursInSeconds / SECONDS_IN_AN_HOUR,
					MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);
		} else {
			// No hours so just minutes and seconds 
			strDDHHMMSS = QString::asprintf("%dm:%02ds", MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);
		}
	}
	return strDDHHMMSS;
}
//****************************************************************************
/// Returns a formatted date/time string
///
/// @param[in]		const ULONG timeSinceEpochInSeconds - number of seconds since epoch
/// @param[in]		const bool timeFirst - indicates if the time should be displayed first
///
/// @return			The date/time as a string 
///
//**************************************************************************** 
const QString CStringUtils::GetDateTime(const ULONG timeSinceEpochInSeconds, const bool timeFirst) {
	QString strDateTime;
	quint64 ullDateTime = timeSinceEpochInSeconds;
	ullDateTime *= 1000000;
	CTVtime kTime(ullDateTime);
	kTime.ShortTimeAsString(strDateTime);
	// now add the date
	QString strDate("");
	kTime.DateAsString(strDate);
	if (timeFirst) {
		strDateTime += " " + strDate;
	} else {
		strDateTime = strDate + " " + strDateTime;
	}
	return strDateTime;
}
//****************************************************************************
/// Returns a formatted date string
///
/// @param[in]		number of seconds since epoch
///
/// @return			The date as a string 
///
//**************************************************************************** 
const QString CStringUtils::GetDate(ULONG timeSinceEpochInSeconds) {
	QString date;
	quint64 ullDateTime = timeSinceEpochInSeconds;
	ullDateTime *= 1000000;
	CTVtime kTime(ullDateTime);
	kTime.DateAsString(date);
	return date;
}
//****************************************************************************
//	const QString  GetItemAtPos(	const QString  &rstrITEM,
//								const USHORT usITEM_POS ) const
///
/// Method that gets the item at a particlar position within a item list delimited by a '|'
///
/// @param[in] 		const QString  &rstrITEM - The item list to look within
/// @param[in] 		const USHORT usITEM_POS - The item item we want, zero based
///
/// @return			Returns the item at a particular position or an empty string if the item pos is
///					higher than the number of items within the list
///
//****************************************************************************
const QString CStringUtils::GetItemAtPos(const QString &rstrITEM_LIST, const USHORT usITEM_POS,
		const QString &rstrDELIMITTER /* = "|" */) {
	QString strIndividualItem("");
	int iDelimPos = 0;
	USHORT usCurrItemPos = 0;
	// loop through the item list until we get to the item we want
	while ((usITEM_POS != usCurrItemPos) && (iDelimPos >= 0)) {
		iDelimPos = rstrITEM_LIST.indexOf(rstrDELIMITTER, iDelimPos + 1);
		++usCurrItemPos;
	}
	// check the delimiter was found and it is not in position 0
	if (iDelimPos >= 0) {
		int iPrevDelimPos = iDelimPos;
		iDelimPos = rstrITEM_LIST.indexOf(rstrDELIMITTER, iPrevDelimPos + 1);
		if (iDelimPos == -1) {
			iDelimPos = rstrITEM_LIST.size();
		}
		if (iPrevDelimPos != 0) {
			iPrevDelimPos += rstrDELIMITTER.size();
		}
		strIndividualItem = rstrITEM_LIST.mid(iPrevDelimPos, iDelimPos - iPrevDelimPos);
	}
	return strIndividualItem;
}
//****************************************************************************
///
/// Method that gets the item at a particlar non-sequential position within a item list delimited by a '|'
///
/// @param[in] 		const QString  &rstrITEM - The item list to look within
/// @param[in] 		const USHORT usITEM_POS - The item item we want, zero based
///
/// @return			Returns the item at a particular non-sequential position or an empty string if the item pos is
///					higher than the number of items within the list - it also strips out any embedded information
///
//****************************************************************************
const QString CStringUtils::GetItemAtNonSequentialPos(const QString &rstrITEM_LIST, const USHORT usITEM_POS,
		const QString &rstrDELIMITTER /* = "|" */) {
	QString strIndividualItem("");
	// check if this is a non-sequential list by looking for embedded control characters
	QString strNonSeqDelimiter("");
	strNonSeqDelimiter = g_wcEMBEDDED_INFO_DELIM;
	USHORT usCurrSearchItemNo = usITEM_POS;
	if (CStringUtils::InstanceOfStr(rstrITEM_LIST, strNonSeqDelimiter) >= 2) {
		// non-sequential list so we need to test all the strings in the list to see if
		// they contain the value indicated within the CMM data
		QString strStringToindexOf("");
		QString strStringToTest("");
		strStringToindexOf = QString::asprintf("%c%u%c", g_wcEMBEDDED_INFO_DELIM, usCurrSearchItemNo,
				g_wcEMBEDDED_INFO_DELIM);
		usCurrSearchItemNo = 0;
		while ((strStringToTest = CStringUtils::GetItemAtPos(rstrITEM_LIST, usCurrSearchItemNo)) != "") {
			// see if this string occurs in the list
			if (strStringToTest.indexOf(strStringToindexOf, 0) != -1) {
				// found our match - drop out of the loop
				strIndividualItem = strStringToTest;
				break;
			}
			// move onto the next item
			++usCurrSearchItemNo;
		}
	} else {
		// no embedded characters so use the conventional method for getting the string item
		strIndividualItem = GetItemAtPos(rstrITEM_LIST, usITEM_POS, rstrDELIMITTER);
	}
	// strip out the control characters
	int iStartPos = 0;
	// check for an embedded control characters
	if ((iStartPos = strIndividualItem.indexOf(g_wcEMBEDDED_INFO_DELIM, 0)) != -1) {
		int iEndPos = strIndividualItem.indexOf(g_wcEMBEDDED_INFO_DELIM, iStartPos + 1);
		// check an end character was found
		if (iEndPos != -1) {
			/// TODO: indexOf alternative to delete
			// start and end found - strip the information out of the string
			strIndividualItem.remove(iStartPos, (iEndPos - iStartPos) + 1);
		} else {
			// should never happen unless there has been a coding error or the user has somehow
			// embedded a control character into the string names
#ifdef _DEBUG
			DebugBreak();
#endif
		}
	}
	return strIndividualItem;
}
//****************************************************************************
//	const QString  FormatFloat(	T_NUMFORMAT tNumberasprintf, 
//								const float fVALUE,
//								const float fRANGE /* = FLT_MAX */,
//								const bool bLOG_SCALE /* = false */,
//								const bool bAlarm_Email /*= false*/) const
///
/// Method that creates an appropriately formatted scale string
///
/// @param[in] 			T_NUMFORMAT tNumberasprintf - The number format structure
/// @param[in] 			const float fVALUE - The value to be converted to a string
/// @param[in]			const float fRANGE - The range the value is associated with
/// @param[in]			const bool bLOG_SCALE - Flag indicating if this item is part
///						of a logscale
/// @param[in]			const int iLimitDecimalsOnAuto - limits the decimals
/// 
/// @return				A string containing the formatted floating point value
///
//****************************************************************************
const QString CStringUtils::FormatFloat(T_NUMFORMAT tNumberasprintf, const float fVALUE,
		const float fRANGE /* = FLT_MAX */, const bool bLOG_SCALE /* = false */,
		const int iLimitDecimalsOnAuto /* = -1 */, const bool bAlarm_Email /*= false*/) {
	QString strasprintftedValue("");
	QString strFormatString("");
	//MarkD: if set to FLT_MAX or -FLT_MAX, replace value with EUDC arrows
	if (fVALUE == FLT_MAX) {
		if (bAlarm_Email) {
			strasprintftedValue = QString::asprintf("Outside Range High ");
		} else {
			strasprintftedValue = QString::asprintf(" %c%c%c%c", g_wcOVER_RANGE, g_wcOVER_RANGE, g_wcOVER_RANGE,
					g_wcOVER_RANGE);
		}
	} else if (fVALUE == -FLT_MAX) {
		if (bAlarm_Email) {
			strasprintftedValue = QString::asprintf("Outside Range Low ");
		} else {
			strasprintftedValue = QString::asprintf(" %c%c%c%c", g_wcUNDER_RANGE, g_wcUNDER_RANGE, g_wcUNDER_RANGE,
					g_wcUNDER_RANGE);
		}
	} else {
		UINT uiErrorTest = *(reinterpret_cast<const UINT*>(&fVALUE)); // cast float to UINT.
		// Test the exponent to see if code is NAN
		if ((uiErrorTest & g_ulNAN_TEST_VALUE) == g_ulNAN_TEST_VALUE) {
			if (bAlarm_Email) {
				strasprintftedValue = QString::asprintf("Invalid Reading ");
			} else {
				strasprintftedValue = QString::asprintf(" %c%c%c%c", g_wcINVALID, g_wcINVALID, g_wcINVALID,
						g_wcINVALID);
			}
		} else {
			float fConvertedValue = fVALUE;
			// if logscale, use 10^(value)
			if (bLOG_SCALE) {
				if (fVALUE < MAX_POWER_OF_10)	// trap for error 
						{
					fConvertedValue = pow((float) 10.0, fVALUE);
				} else {
					fConvertedValue = FLT_MAX;	// display max possible value
				}
			}
			if (tNumberasprintf.Auto) {
				//MarkD: if in scientific notation, Auto to 1 decimal place so the number can be read in DPMs
				if (tNumberasprintf.Scientific) {
					tNumberasprintf.Bd = 1;
					tNumberasprintf.Ad = 1;
				} else {
					// test for large value first, to set scientific if required, regardless of range setting
					const float fABS_VALUE = fabs(fConvertedValue);
					if (fABS_VALUE > 9999999.0) {
						tNumberasprintf.Scientific = TRUE;
						tNumberasprintf.Bd = 1;
						tNumberasprintf.Ad = 1;
					} else	// set decimal places to use
					{
						// base it on the scale details if they are provided
						if (fRANGE != FLT_MAX) {
							const float fABS_RANGE = fabs(fRANGE);
							if (fABS_RANGE < 1.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 5;
							} else if (fABS_RANGE < 10.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 4;
							} else if (fABS_RANGE < 100.0) {
								tNumberasprintf.Bd = 2;
								tNumberasprintf.Ad = 3;
							} else if (fABS_RANGE < 1000.0) {
								tNumberasprintf.Bd = 3;
								tNumberasprintf.Ad = 2;
							} else if (fABS_RANGE < 10000.0) {
								tNumberasprintf.Bd = 4;
								tNumberasprintf.Ad = 2;
							} else if (fABS_RANGE < 100000.0) {
								tNumberasprintf.Bd = 5;
								tNumberasprintf.Ad = 0;
							}
						} else {
							// just format to a reasonable length based on the size				
							if (fABS_VALUE < 1.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 5;
							} else if (fABS_VALUE < 10.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 4;
							} else if (fABS_VALUE < 100.0) {
								tNumberasprintf.Bd = 2;
								tNumberasprintf.Ad = 3;
							} else if (fABS_VALUE < 1000.0) {
								tNumberasprintf.Bd = 3;
								tNumberasprintf.Ad = 2;
							} else if (fABS_VALUE < 10000.0) {
								tNumberasprintf.Bd = 4;
								tNumberasprintf.Ad = 1;
							} else if (fABS_VALUE < 100000.0) {
								tNumberasprintf.Bd = 5;
								tNumberasprintf.Ad = 0;
							}
							//MarkD: ensure no decimal places on very large numbers also
							else if (fABS_VALUE >= 100000.0)	//Coverity- 2343027
									{
								tNumberasprintf.Ad = 0;
							}
						}
						if ((iLimitDecimalsOnAuto != -1) && (tNumberasprintf.Ad > iLimitDecimalsOnAuto)) {
							// override the maximum number of decimals
							tNumberasprintf.Ad = iLimitDecimalsOnAuto;
						}
					}
				}
			}
			if (tNumberasprintf.Base) // Hex?
			{
				strFormatString = "%%0x%X"; // treat the value as hex rather than float.
			} else {
				// only makes sense to set .Bd if you have .Zpad set to 1 since you will always get the
				// value displayed before the decimal point anyway (never truncated)
				if (tNumberasprintf.Zpad) {
					// for zero padding, we want to have at least Numberasprintf.Bd before the Decimal point
					// since the '.' counts as 1 char we need to add 1 to the minimum width specifier here.
					strFormatString = QString::asprintf("%%0%d.%df", 1 + tNumberasprintf.Bd + tNumberasprintf.Ad,
							tNumberasprintf.Ad);
				} else {
					if (tNumberasprintf.Scientific) {
						strFormatString = QString::asprintf("%%.%de", tNumberasprintf.Ad); // scientific notation here	(.bd always 1 anyway and no zpad)
					} else {
						strFormatString = QString::asprintf("%%.%df", tNumberasprintf.Ad); // normal floating point
					}
				}
			}
			strasprintftedValue = QString::asprintf(strFormatString.toLocal8Bit().data(), fConvertedValue);
			// now remove any extra zero's after the decimal place (except the last one)
			if ((tNumberasprintf.Scientific == FALSE) && (tNumberasprintf.Auto == TRUE) && (tNumberasprintf.Ad > 1)) {
				int iDecimalPos = strasprintftedValue.indexOf(".", 0);
				if (iDecimalPos != -1) {
					bool bContinue = true;
					while (bContinue) {
						// get the last character in the entire string and check it is a zero
						int iZeroPos = strasprintftedValue.indexOf("0", strasprintftedValue.size() - 1);
						if ((iZeroPos != -1) && (iZeroPos > (iDecimalPos + 1))) {
							strasprintftedValue.remove(strasprintftedValue.size() - 1, 1);
						} else {
							// either not a zero or it is a zero adjacent to the decimal point so drop out of
							// the loop
							bContinue = false;
						}
					}
				}
			} else if (tNumberasprintf.Scientific) {
				strasprintftedValue.remove((strasprintftedValue.size() - 3), 1);// MarkD: delete the third from last char
			}
		}
	}
	return strasprintftedValue;
}
//****************************************************************************
//	const bool LoadLangDLL( const T_LANGUAGES eLANG, QString  &rstrErrorMsg )
///
/// Method that loads the correct resource DLL based on the passed in language
///
/// @param[in] 			const T_LANGUAGES eLANG - The enum of the required language
/// @param[out] 		QString  &rstrErrorMsg - An error message if necessary
/// 
/// @return				True if there was no need to load a DLL or the DLL was loaded 
///						successfully
///
//****************************************************************************
const bool CStringUtils::LoadLangDLL(const T_LANGUAGES eLANG, QString &rstrErrorMsg) {
	QString strLanguageDLLName("");
	bool bSuccess = true;
	// get the language DLL name
	strLanguageDLLName = GetLangDLLName(eLANG);
	// check we need to load a DLL
	if (strLanguageDLLName != "") {
		HINSTANCE hRes = NULL;
		// add the CE firmware PATH if this an actual recorder
		const T_DEV_TYPE eDEV_TYPE = pDEVICE_INFO->GetDeviceType();
		if (eDEV_TYPE == DEV_ARISTOS_MINITREND || eDEV_TYPE == DEV_ARISTOS_MULTIPLUS || eDEV_TYPE == DEV_PC_TTR6SETUP
				|| eDEV_TYPE == DEV_SCR_MINITREND) {
			// add the firmware path
			int iPathLen = 260;
			QString pwcStoragePathName;
			QString pwcFirmwarePathName;
			pDALGLB->GetPath((T_STORAGE_PATH) IDS_INTERNAL_SD, &pwcStoragePathName, iPathLen, &iPathLen);
			pDALGLB->GetPath(IDS_PRIMARY, &pwcFirmwarePathName, iPathLen, &iPathLen);
			QString strPath("");
			strPath = pwcStoragePathName + pwcFirmwarePathName;
			strLanguageDLLName = strPath + strLanguageDLLName;
		}
		/// TODO:
		//	hRes = LoadLibrary( strLanguageDLLName ); This Fails on CE 7 Use Following....
//		hRes = LoadLibraryEx(strLanguageDLLName, NULL, LOAD_LIBRARY_AS_DATAFILE);
		if (hRes != NULL) {
//			AfxSetResourceHandle(hRes);
		} else {
			// there has been an error - return an error message - no point in translating
			DWORD dw = GetLastError();
			dw++;
			rstrErrorMsg = "Failed to load the selected lanaguage DL";
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
//	const QString  GetLangDLLName( const T_LANGUAGES eLANG )
///
/// Method that gets the resource DLL name based on the passed in enum
///
/// @param[in] 			const T_LANGUAGES eLANG - The enum of the required language
/// 
/// @return				The name of the DLL or QString ::fromWCharArray("") if none (e.g. English)
///
//****************************************************************************
const QString CStringUtils::GetLangDLLName(const T_LANGUAGES eLANG) {
	return "";
}
//****************************************************************************
//	const USHORT InstanceOfStr( const QString  &rstrSTRING_TO_TEST, 
//								const QString  &rstrSTRING_TO_FIND );
///
/// Method that counts the instances of the passed in string within the test string
///
/// @param[in] 			const QString  &rstrSTRING_TO_TEST - The string to look in
/// @param[in] 			const QString  &rstrSTRING_TO_FIND - The string to llok for
/// 
/// @return				The number of occurances of the string we are looking for
///
//****************************************************************************
const USHORT CStringUtils::InstanceOfStr(const QString &rstrSTRING_TO_TEST, const QString &rstrSTRING_TO_FIND) {
	USHORT usOccurances = 0;
	short sStartPos = -1;
	while ((sStartPos = rstrSTRING_TO_TEST.indexOf(rstrSTRING_TO_FIND, sStartPos + 1)) != -1) {
		// increment the number of occurances
		++usOccurances;
	}
	return usOccurances;
}
//****************************************************************************
//	void SafeWcsCpy(	QString  pwcDest, 
//						const QString  pwcORIG, 
//						const USHORT usDEST_BUFF_LEN,
//						const bool bNULL_TERMINATE_BUFF_END /* = true */ )
///
/// Method that performs safe string copies - to replace calls to wcsncpy and wcscpy. This method
///	will copy the original over the destination upto the length specified by usDEST_BUFF_LEN. The
///	last character in the buffer will be set to NULL if the final flag is set (this is to overcome 
///	problems with wcsncpy)
///
/// @param[in] 			const QString  &rstrSTRING_TO_TEST - The string to look in
/// @param[in] 			const QString  &rstrSTRING_TO_FIND - The string to llok for
/// @param[in] 			const USHORT usDEST_BUFF_LEN - The length of the destination buffer including any
///						space for the null terminator
/// @param[in]			const bool bNULL_TERMINATE_BUFF_END - Flag indicating if the string must be
///						null terminated
///
//****************************************************************************
void CStringUtils::SafeWcsCpy(WCHAR *pwcDest, const WCHAR *pwcORIG, const USHORT usDEST_BUFF_LEN,
		const bool bNULL_TERMINATE_BUFF_END /* = true */) {
	// copy the strings
#if _MSC_VER < 1400 
	wcsncpy(pwcDest, pwcORIG, usDEST_BUFF_LEN);
#else
	int len = wcslen(pwcORIG);
	wcsncpy_s( pwcDest, usDEST_BUFF_LEN,pwcORIG, len<usDEST_BUFF_LEN?len:usDEST_BUFF_LEN-1 );
#endif
	// always set the last char to NULL
	if (bNULL_TERMINATE_BUFF_END) {
		pwcDest[usDEST_BUFF_LEN - 1] = 0;
	}
}
//****************************************************************************
//	const QString  StripColourInfo( const QString  &rstrUNICODE_SOURCE )
///
// Strip out any colour information that may be present
///
/// @param[in] 			const QString  &rstrTEXT_SOURCE - The original source string
/// 
/// @return				The string with all the colour information removed
///
//****************************************************************************
const QString CStringUtils::StripColourInfo(const QString &rstrTEXT_SOURCE) {
	int iModColourPos = 0;
	QString strNewValue(rstrTEXT_SOURCE);
	if ((iModColourPos = strNewValue.indexOf(g_wcMOD_COLOUR)) != -1) {
		// there are some special characters which we must extract first
		int iModColourEndPos = strNewValue.indexOf(g_wcMOD_COLOUR, iModColourPos + 1);
		int iColourLen = (iModColourEndPos - iModColourPos);
		// delete the colour information and character from the string
		strNewValue.remove(iModColourPos, iColourLen + 1);
	}
	return strNewValue;
}
//****************************************************************************
//	const QString  EncodeToUTF8( const QString  &rstrUNICODE_SOURCE )
///
/// Method used to convert unicode text into a UTF-8 representation (note: this will still need to
/// be converted using wcstombs
///
/// @param[in] 			const QString  &rstrUNICODE_SOURCE - The original unicode source string
/// 
/// @return				The string with all unicode characters converted to ascii/UTF-8 equivalents (note: this
///						string is still returned as WCHAR's although they will all be ascii values - call wcstombs
///						if you want ot convert this string in a normal character array)
///
//****************************************************************************
const QString CStringUtils::EncodeToUTF8(const QString &rstrUNICODE_SOURCE) {
	return QString::fromLocal8Bit(rstrUNICODE_SOURCE.toUtf8());
}
//****************************************************************************
//	const QString DecodeFromUTF8( const QString &rstrUTF8_SOURCE )
///
/// Method that decodes UTF-8 strings into UNICODE
///
/// @param[in] 			const QString &rstrUTF8_SOURCE - The original UTF-8 source string
///
/// @return				The string with all UTF-8 character streams converted to UNICODE equivalents (note: the passed
///						in string must be in WCHAR format)
///
/// @note	THIS METHOD HAS NOT BEEN TESTED
///
//****************************************************************************
const QString CStringUtils::DecodeFromUTF8(const QString &rstrUTF8_SOURCE) {
	int n, nMax = rstrUTF8_SOURCE.size();
	WORD ch;
	QString strFinal, strTemp;
	BYTE z, y, x, w, v, u;
	for (n = 0; n < nMax; ++n) {
		ch = (WORD) rstrUTF8_SOURCE.at(n).toLatin1();
		if (ch != ('=')) {
			strFinal += (TCHAR) ch;
			continue;
		}
		if (n >= nMax - 2) {
			break; // something is wrong
		}
		z = MakeByte(rstrUTF8_SOURCE.at(n + 1).toLatin1(), rstrUTF8_SOURCE.at(n + 2).toLatin1());
		if (z < 127) {
			strFinal += (TCHAR) z;
			n = n + 2;
		} else if (z >= 192 && z <= 223) {
			// character is two bytes
			if (n >= nMax - 5)
				break; // something is wrong
			y = MakeByte(rstrUTF8_SOURCE.at(n + 4).toLatin1(), rstrUTF8_SOURCE.at(n + 5).toLatin1());
			strFinal += (TCHAR) ((z - 192) * 64 + (y - 128));
			n = n + 5;
		} else if (z >= 224 && z <= 239) {
			// character is three bytes
			if (n >= nMax - 8)
				break; // something is wrong
			y = MakeByte(rstrUTF8_SOURCE.at(n + 4).toLatin1(), rstrUTF8_SOURCE.at(n + 5).toLatin1());
			x = MakeByte(rstrUTF8_SOURCE.at(n + 7).toLatin1(), rstrUTF8_SOURCE.at(n + 8).toLatin1());
			strFinal += (TCHAR) ((z - 224) * 4096 + (y - 128) * 64 + (x - 128));
			n = n + 8;
		} else if (z >= 240 && z <= 247) {
			// character is four bytes
			if (n >= nMax - 11)
				break; // something is wrong
			y = MakeByte(rstrUTF8_SOURCE.at(n + 4).toLatin1(), rstrUTF8_SOURCE.at(n + 5).toLatin1());
			x = MakeByte(rstrUTF8_SOURCE.at(n + 7).toLatin1(), rstrUTF8_SOURCE.at(n + 8).toLatin1());
			w = MakeByte(rstrUTF8_SOURCE.at(n + 10).toLatin1(), rstrUTF8_SOURCE.at(n + 11).toLatin1());
			strFinal += (TCHAR) ((z - 240) * 262144 + (y - 128) * 4096 + (x - 128) * 64 + (w - 128));
			n = n + 11;
		} else if (z >= 248 && z <= 251) {
			// character is four bytes
			if (n >= nMax - 14)
				break; // something is wrong
			y = MakeByte(rstrUTF8_SOURCE.at(n + 4).toLatin1(), rstrUTF8_SOURCE.at(n + 5).toLatin1());
			x = MakeByte(rstrUTF8_SOURCE.at(n + 7).toLatin1(), rstrUTF8_SOURCE.at(n + 8).toLatin1());
			w = MakeByte(rstrUTF8_SOURCE.at(n + 10).toLatin1(), rstrUTF8_SOURCE.at(n + 11).toLatin1());
			v = MakeByte(rstrUTF8_SOURCE.at(n + 13).toLatin1(), rstrUTF8_SOURCE.at(n + 14).toLatin1());
			strFinal += (TCHAR) ((z - 248) * 16777216 + (y - 128) * 262144 + (x - 128) * 4096 + (w - 128) * 64
					+ (v - 128));
			n = n + 14;
		} else if (z >= 252 && z <= 253) {
			// character is four bytes
			if (n >= nMax - 17)
				break; // something is wrong
			y = MakeByte(rstrUTF8_SOURCE.at(n + 4).toLatin1(), rstrUTF8_SOURCE.at(n + 5).toLatin1());
			x = MakeByte(rstrUTF8_SOURCE.at(n + 7).toLatin1(), rstrUTF8_SOURCE.at(n + 8).toLatin1());
			w = MakeByte(rstrUTF8_SOURCE.at(n + 10).toLatin1(), rstrUTF8_SOURCE.at(n + 11).toLatin1());
			v = MakeByte(rstrUTF8_SOURCE.at(n + 13).toLatin1(), rstrUTF8_SOURCE.at(n + 14).toLatin1());
			u = MakeByte(rstrUTF8_SOURCE.at(n + 16).toLatin1(), rstrUTF8_SOURCE.at(n + 17).toLatin1());
			strFinal += (TCHAR) ((z - 252) * 1073741824 + (y - 128) * 16777216 + (x - 128) * 262144 + (w - 128) * 4096
					+ (v - 128) * 64 + (u - 128));
			n = n + 17;
		}
	}
	return strFinal;
}
//****************************************************************************
//	BYTE MakeByte(TCHAR ch1, TCHAR ch2)
///
/// Helper Method used to decode UTF-8 strings into UNICODE
///
/// @param[in] 			TCHAR ch1
/// @param[in] 			TCHAR ch2
///
/// @return
///
/// @note	THIS METHOD HAS NOT BEEN TESTED
///
//****************************************************************************
BYTE CStringUtils::MakeByte(TCHAR ch1, TCHAR ch2) {
	BYTE bt1 = 0, bt2 = 0;
	switch (ch2) {
	case ('0'):
		bt2 = 0x00;
		break;
	case ('1'):
		bt2 = 0x01;
		break;
	case ('2'):
		bt2 = 0x02;
		break;
	case ('3'):
		bt2 = 0x03;
		break;
	case ('4'):
		bt2 = 0x04;
		break;
	case ('5'):
		bt2 = 0x05;
		break;
	case ('6'):
		bt2 = 0x06;
		break;
	case ('7'):
		bt2 = 0x07;
		break;
	case ('8'):
		bt2 = 0x08;
		break;
	case ('9'):
		bt2 = 0x09;
		break;
	case ('A'):
		bt2 = 0x0A;
		break;
	case ('B'):
		bt2 = 0x0B;
		break;
	case ('C'):
		bt2 = 0x0C;
		break;
	case ('D'):
		bt2 = 0x0D;
		break;
	case ('E'):
		bt2 = 0x0E;
		break;
	case ('F'):
		bt2 = 0x0F;
		break;
	}
	switch (ch1) {
	case ('0'):
		bt1 = 0x00;
		break;
	case ('1'):
		bt1 = 0x10;
		break;
	case ('2'):
		bt1 = 0x20;
		break;
	case ('3'):
		bt1 = 0x30;
		break;
	case ('4'):
		bt1 = 0x40;
		break;
	case ('5'):
		bt1 = 0x50;
		break;
	case ('6'):
		bt1 = 0x60;
		break;
	case ('7'):
		bt1 = 0x70;
		break;
	case ('8'):
		bt1 = 0x80;
		break;
	case ('9'):
		bt1 = 0x90;
		break;
	case ('A'):
		bt1 = 0xA0;
		break;
	case ('B'):
		bt1 = 0xB0;
		break;
	case ('C'):
		bt1 = 0xC0;
		break;
	case ('D'):
		bt1 = 0xD0;
		break;
	case ('E'):
		bt1 = 0xE0;
		break;
	case ('F'):
		bt1 = 0xF0;
		break;
	}
	BYTE btFinal = bt2 | bt1;
	return btFinal;
}
//****************************************************************************
//	void StripFullPathName(	const QString &rstrFULL_PATH_NAME,
//							QString &rstrPath,
//							QString &rstrFilename,
//							QString &rstrExtension )
///
/// Method that breaks a full path/file name down into its path component and
/// filename
///
/// @param[in] 			const QString &rstrFULL_PATH_NAME - The full path and file name
/// @param[out] 		QString &rstrPATH - The path, no filename and not terminated with a '\\'
/// @param[out] 		QString &rstrFILENAME - The filename not including extension
/// @param[out] 		QString &rstrEXTENSION - The file extension
///
//****************************************************************************
void CStringUtils::StripFullPathName(const QString &rstrFULL_PATH_NAME, QString &rstrPath, QString &rstrFilename,
		QString &rstrExtension) {
	// strip out the extension first
	QString strTempPath(rstrFULL_PATH_NAME);
	// check the string contains some data
	if (strTempPath != "") {
		int iCurrPos = strTempPath.size();
		while ((strTempPath.at(--iCurrPos) != L'.') && (iCurrPos != 0));
		if (iCurrPos > 0) {
			// the pointer must be looking at the dot therefore extract the extension from here
			rstrExtension = strTempPath.right(strTempPath.size() - (iCurrPos + 1));
			strTempPath.remove(iCurrPos, (strTempPath.size() - iCurrPos));
		}
		// now strip out the filename
		iCurrPos = strTempPath.size();
		while ((strTempPath.at(--iCurrPos) != L'\\') && (iCurrPos != 0));
		if (iCurrPos > 0) {
			// the pointer must be looking at the backslashes therefore extract the filename from here
			rstrFilename = strTempPath.right(strTempPath.size() - (iCurrPos + 1));
			strTempPath.remove(iCurrPos, (strTempPath.size() - iCurrPos));
			// also strip the end backslashes and set the path name variable
			rstrPath = strTempPath.left(strTempPath.size() - 1);
		}
	}
}

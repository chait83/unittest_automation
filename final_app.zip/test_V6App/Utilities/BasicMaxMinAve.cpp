/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Utilities
/// @n Filename: BasicMaxMinAve.h
/// @n Desc:	Manage a basic max and min and average for a reading
///				
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 9	Stability Project 1.4.1.3	7/2/2011 4:55:37 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.4.1.2	7/1/2011 4:37:59 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 7	Stability Project 1.4.1.1	3/17/2011 3:20:11 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 6	Stability Project 1.4.1.0	2/15/2011 3:02:16 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************
#include "BasicMaxMinAve.h"
#include <float.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//=============================================================================
// CBasicMaxMin Class
//=============================================================================
//****************************************************************************
/// CBasicMaxMin Constructor
//****************************************************************************
CBasicMaxMin::CBasicMaxMin() {
	ResetMaxMin();		// Reset the Max & Mins
}
//****************************************************************************
/// Reset the max and mins, sets to opposing float limits
///
/// @return - nothing
///
//****************************************************************************
void CBasicMaxMin::ResetMaxMin() {
	m_maxValue = -FLT_MAX;	// Set max value to minimum floating point value
	m_minValue = FLT_MAX;	// Set min value to maximum floating point value
}
//****************************************************************************
/// Reset the max and mins, sets to the current reading
///
/// @param[in] - reading, current reading to reset max and min
///
/// @return - nothing
///
//****************************************************************************
void CBasicMaxMin::ResetMaxMin(float reading) {
	// Set Max and Min to a current reading.
	m_maxValue = reading;
	m_minValue = reading;
}
//****************************************************************************
/// Max and min a reading 
///
/// @param[in] - reading, current reading to max and min
///
/// @return - nothing
//****************************************************************************
void CBasicMaxMin::DoMaxMinForReading(float reading) {
	// Comapre new reading with current max, if it does not exceed
	// then test reading with current min. Updating max and min as appropriate
	if (reading > m_maxValue) {
		m_maxValue = reading;
	}
	if (reading < m_minValue) {
		m_minValue = reading;
	}
}
//=============================================================================
// CBasicAverage Class
//=============================================================================
//****************************************************************************
/// CBasicAverage Constructor
//****************************************************************************
CBasicAverage::CBasicAverage() {
	ResetAverage();		// Reset the average
}
//****************************************************************************
/// Reset the Average, sets it to 0 with no accumulated readings
///
/// @return - nothing
//****************************************************************************
void CBasicAverage::ResetAverage() {
	m_runningAverageTotal = 0;
	m_numberOfReadingInAverage = 0;
}
//****************************************************************************
/// Reset the Average, sets it a base reading
///
/// @param[in] - reading, current reading to reset average
///
/// @return - nothing
//****************************************************************************
void CBasicAverage::ResetAverage(float reading) {
	ResetAverage();
	DoAverageForReading(reading);
}
//****************************************************************************
/// Update the average for a new reading passed
///
/// @param[in] - reading, current reading to update average
///
/// @return - nothing
//****************************************************************************
void CBasicAverage::DoAverageForReading(float reading) {
	// If the reading has hit the limits log the limit
	if ( FLT_MAX == reading || -FLT_MAX == reading) {
		m_runningAverageTotal = reading;
	} else		// Add new reading to running total, increment number of readings in total
	{
		m_runningAverageTotal += reading;
	}
	m_numberOfReadingInAverage++;
}
//****************************************************************************
/// Get the average value
///
/// @return - Average value as floating point number
//****************************************************************************
float CBasicAverage::GetAverage() {
	float actualAverage = 0;	// return value of calculated average reading
	// If the value has hit the limits, return the limit not the average
	if ( FLT_MAX == m_runningAverageTotal || -FLT_MAX == m_runningAverageTotal) {
		actualAverage = m_runningAverageTotal;
	}
	// Check to make sure an average value have been added before calculating to avoid div by 0
	else if (m_numberOfReadingInAverage > 0) {
		// Calculate Average value, divide total of all reading 
		actualAverage = (float) (m_runningAverageTotal / m_numberOfReadingInAverage);
	}
	return actualAverage;
}

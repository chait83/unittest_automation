/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Data Transfer utilities
/// @n ActivityLog.cpp
/// @n Data transfer and queue monitor activity log.
/// @author MM
/// @date 30/11/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log:
//  8 Stability Project 1.3.1.3 7/2/2011 4:55:12 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:37:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:07 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:02:00 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  4 V6 Firmware 1.3 4/4/2007 2:58:50 PM Roger Dawson  
//  Added missing VS code for finding memory leaks
//  3 V6 Firmware 1.2 4/20/2006 7:49:41 PM  Jason Parker  
//  changed ::MessageBox to V6WarningMessageBox or V6CriticalMessageBox
//  2 V6 Firmware 1.1 3/10/2006 6:13:01 PM  Roger Dawson  
//  Replaced INFINITE timeouts with globally defined timeout value.
//  1 V6 Firmware 1.0 12/20/2005 1:18:48 PM  Martin Miller  
// $
//
//////////////////////////////////////////////////////////////////////
#include "ActivityLog.h"
#include "V6defines.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CActivityLog *CActivityLog::pInstance = NULL;
QMutex CActivityLog::hCreationMutex;
QMutex CActivityLog::m_hCritical;
//****************************************************************************
/// DataTransfer activity log: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CActivityLog::CActivityLog() {
	m_Initialised = FALSE;
	return;
}
//****************************************************************************
/// DataTransfer activity log: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CActivityLog::~CActivityLog() {
	return;
}
//****************************************************************************
/// DataTransfer activity log: singleton get/create instance
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
CActivityLog* CActivityLog::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == pInstance) {
		waitSingleObjectResult = hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == pInstance) {
				pInstance = new CActivityLog;
			}
			hCreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
            V6WarningMessageBox(NULL, "ActivityLog WaitForSingleObject Error", "Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return pInstance;
}
//****************************************************************************
/// DataTransfer activity log: class cleanup
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CActivityLog::CleanUp() {
	BOOL bResult = TRUE;
	if (m_Initialised) {
		//deletion of mutex not required
		m_Initialised = FALSE;
	}
	return bResult;
}
//****************************************************************************
/// DataTransfer activity log: class initialisation
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::Initialise() {
	if (!m_Initialised) {
        m_InternalLogIsOpen = FALSE;
		m_ExternalLogIsOpen = FALSE;
		m_Initialised = TRUE;
	}
}
//****************************************************************************
/// DataTransfer activity log: open the internal activity log
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::OpenInternalLog(QString Name) {
	if (m_InternalLog.Open(Name.toLocal8Bit().data(), QFile::Append | QFile::WriteOnly, NULL))
		m_InternalLogIsOpen = TRUE;
}
//****************************************************************************
/// DataTransfer activity log: open the external activity log
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::OpenExternalLog(QString Name) {
    if (m_ExternalLog.Open(Name.toLocal8Bit().data(), QFile::Append | QFile::WriteOnly, NULL))
		m_ExternalLogIsOpen = TRUE;
}
//****************************************************************************
/// DataTransfer activity log: close the internal activity log
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::CloseInternalLog() {
	if (m_InternalLogIsOpen) {
		m_InternalLog.Close();
		m_InternalLogIsOpen = FALSE;
	}
}
//****************************************************************************
/// DataTransfer activity log: close the external activity log
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::CloseExternalLog() {
	if (m_ExternalLogIsOpen) {
		m_ExternalLog.Close();
		m_ExternalLogIsOpen = FALSE;
	}
}
//****************************************************************************
/// DataTransfer activity log: log internal activity message
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::LogInternalMessage(char *Message) {
	m_hCritical.lock();
	if (m_InternalLogIsOpen) {
		m_InternalLog.Write(Message, strlen(Message));
	}
	m_hCritical.lock();
}
//****************************************************************************
/// DataTransfer activity log: log external activity message
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::LogExternalMessage(char *Message) {
	m_hCritical.lock();
	if (m_ExternalLogIsOpen) {
		m_ExternalLog.Write(Message, strlen(Message));
	}
	m_hCritical.lock();
}
//****************************************************************************
/// DataTransfer activity log: copy the internal activity log to another file (append to external log)
///
/// @return	
///
/// @note Target file name can not be the same as the external log
//****************************************************************************
void CActivityLog::CopyInternalLog(QString Source, QString Target) {
	m_hCritical.lock();
	CloseInternalLog();
	QFile::copy(Source,Target);
	DeleteInternalLog(Source);
	OpenInternalLog(Source);
	m_hCritical.unlock();
}
//****************************************************************************
/// DataTransfer activity log: delete the internal activity log
///
/// @return	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CActivityLog::DeleteInternalLog(QString Name) {
	QFile::remove(Name);
}

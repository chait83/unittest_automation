/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Utilities
/// @n Filename: LinearTable.cpp
/// @n Desc:	Provide a table lookup linearisation facility
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 10	Stability Project 1.7.1.1	7/2/2011 4:58:21 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 9	Stability Project 1.7.1.0	7/1/2011 4:27:17 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 8	V6 Firmware 1.7		9/23/2008 3:09:28 PM	Build Machine 
//		AMS2750 Merge
// 7	V6 Firmware 1.6		7/31/2006 1:42:33 PM	Graham Waterfield
//		Added ezTrend mods and input GCA damping. Some work done on
//		linearisation tables (but parked until setup UI done)
// $
//
// ****************************************************************
#ifndef __LINTABLE_H__
#define __LINTABLE_H__
#include "V6defines.h"
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
	#include "CStorage.h" //PSR - DebugFile Logger integration
#endif
// return values for Linearisation table routines
typedef enum {
	TABLE_OK = 1,						///< return table generated okay
	TERR_TWO_ENTRIES_AT_SAME_POINT,		///< Two table entries of same value
	TERR_DONKEY_LEG_DETECTED,		///< Donkey leg, +ve going table goes down at one point, or -ve goes up
	TERR_MEMORY_ALLOC_FAILED,			///< allocation of memory tabels failed
} T_TABLE_RETURN;
typedef enum {
	NORMAL_TABLE,				///< Generate normal table for a forward lookup
	REVERSE_TABLE	///< Generate reverse table from source, for reverse lookups
} T_TABLE_TYPE;
const int TABLE_POS = 1;				///< +ve going table
const int TABLE_NEG = -1;				///< -ve going table
const int TABLE_MAX_ELEMENTS = 5000;	///< Max table size
// Single table element
typedef struct {
	float in;				///< Input table point
	float out;				///< Output table point
	float ipfac;				///< Interpolation factor, relationship between in slope and out slope
	float intercept;				///< Y Intercept value, (where the line crosses the Y axis)
} T_TABLE_ELEMENT, *T_PTABLE_ELEMENT;
// Single table element
typedef struct {
	float in;				///< Input table point
	float out;				///< Output table point
} T_IP_TABLE_ELEMENT, *T_PIP_TABLE_ELEMENT;
// A single linerisation device table header
typedef struct _devicetablehdr {
	float IPRangeLow;					// Minimum table I/P value
	float IPRangeHigh;				// Maximum table I/P value
	float OPRangeLow;					// Minimum table O/P value
	float OPRangeHigh;				// Maximum table O/P value
	USHORT DeviceID;					///< The unique device identity ID
	USHORT DeviceNameTextID;			///< The device name
	USHORT TableReadings;			///< Number of readings to follow (0 if device is linear)
	BOOL CJLookup;	///< TRUE if this device table can be used as a CJ lookup
	BOOL Referenced;			///< TRUE if this table is referenced by the CMM
	UCHAR DeviceType;			///< Identifies what type of device and where it can be used
	UCHAR IPRangeType;				///< I/P channel type (ohms, volts etc.)
	IO_MEASURE_UNITS IPRangeUnits;				///< What units the I/P table units in (m, u, n, p)
	UCHAR IPSubUnits;				///< I/P range subtype (if applicable) i.e. degrees C, F etc.
	UCHAR OPRangeType;				///< O/P channel type (ohms, volts etc.)
	IO_MEASURE_UNITS OPRangeUnits;				///< What units the O/P table units in (m, u, n, p)
	UCHAR OPSubUnits;				///< O/P range subtype (if applicable) i.e. degrees C, F etc.
} T_DEVICETABLEHDR, *T_PDEVICETABLEHDR;
//**Class*********************************************************************
///
/// @brief Linearisation table generation and lookup
/// 
/// This class will provide linearisation lookup using tables. The tables are generated
/// from an input linearisation table which can contain the relationship bteween
/// input and output.
///
//****************************************************************************
class CLinearTable {
public:
	CLinearTable(void);
	~CLinearTable(void);
	T_TABLE_RETURN GenerateUserTableHdr(T_PDEVICETABLEHDR pSensorHdr, T_PIP_TABLE_ELEMENT inTable,
			const USHORT DeviceID, const USHORT noEntries);
	T_TABLE_RETURN GenerateTable(T_PIP_TABLE_ELEMENT inTable, const USHORT noEntries, const USHORT suggElements,
			const T_TABLE_TYPE direction, const BOOL ignorePointChecks = FALSE);
	float LookUpValue(const float inVal) const;
	// Performs a reverse lookup to get us back to an original pre-conditioned reading
	const float ReverseLookUpValue(const float conditionedReading) const;
	void FreeTables(void);				///< Free the allocated tables
private:
#if defined (DBG_FILE_LOG_LNR_TBL_DBG_ENABLE)
	static void LogDbgMessageToFile(QString  strLogMessage);
	#endif
private:
	T_PTABLE_ELEMENT m_pSourceTable;				///< Pointer to define linearisation table (source)
	T_PTABLE_ELEMENT *m_pReferenceTable;				///< Pointer to index list (reference)
	float m_smallestGap;	///< Smallest difference in source table readings in
	int m_tableDirection;	///< +1 for +ve and -1 for -Ve going source table
	int m_refElements;						///< Number of elements in ref table
	int m_sourceElemets;				///< Number of elements in source table
	float m_srcElementStep;				///< Step value of the source element
	float m_sourceRange;				///< Source input range (span - zero)
	float m_sourceZero;						///< Source input Zero
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
	static CDebugFileLogger m_debugFileLogger; //PSR - DebugFile Logger integration
	#endif
};
#endif //__LINTABLE_H__

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Utilities
/// @n Filename:	StringUtils.h
/// @n Description: Definition of general utility class providing string functions
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 24	Stability Project 1.21.1.1	7/2/2011 5:01:57 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 23	Stability Project 1.21.1.0	7/1/2011 4:27:32 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 22	V6 Firmware 1.21		12/12/2007 8:46:26 PM Roger Dawson 
//		Provided the user with the an increased number of selectable chart
//		speeds.
// 21	V6 Firmware 1.20		4/27/2007 2:11:53 PM	Roger Dawson	The
//		load button has now been changed to display the text 'View' when
//		showing the reports archive.
// $
//
// **************************************************************************
#ifndef _STRINGUTILS_H
#define _STRINGUTILS_H
#include "CMMDefines.h"
#include "V6Config.h"
#include <float.h>
#include "V6types.h"
#include <QString>
//**Class*********************************************************************
///
/// @brief General utility class containing static string helper functions
/// 
/// General utility class containing static string helper functions
///
//****************************************************************************
class CStringUtils {
public:
	// Constructor
	CStringUtils(void);
	// Destructor
	~CStringUtils(void);
	/// The standard delimitter used across the system
	static const QString ms_strDELIMITTER;
	/// Identifier for the reports file extension
	static const QString ms_strREPORTS_FILE_EXT;
	// Converts string ip address to a ULONG
	static const ULONG IPv4StrToPackedIPv4(const QString &rstrIPAddress);
	static const QString PackedIPv4ULongToStr(const ULONG ulIPADDR);
	// Method that gets the item at a particular position within a item list
	static const QString GetItemAtPos(const QString &rstrITEM_LIST, const USHORT usITEM_POS,
			const QString &rstrDELIMITTER = QString::fromWCharArray(L"|"));
	// Method that gets the item at a particular non-sequential position within a item list
	static const QString GetItemAtNonSequentialPos(const QString &rstrITEM_LIST, const USHORT usITEM_POS,
			const QString &rstrDELIMITTER = QString::fromWCharArray(L"|"));
	// Method that creates an appropriately formatted scale string
    static const QString FormatFloat(T_NUMFORMAT tNumberasprintf, const float fVALUE, const float fRANGE = FLT_MAX,
			const bool bLOG_SCALE = false, const int iLimitDecimalsOnAuto = -1, const bool bAlarm_Email = false);
	// Method returns a span of hours minutes and seconds for seconds
	static const QString GetHHMMSSspanFromSeconds(LONGLONG timeInSeconds);
	// Method returns a span of days hours minutes and seconds for seconds, autoformatted to best fit
	static const QString GetAutoDDHHMMSSspanFromSeconds(LONGLONG timeInSeconds, const bool bTRIM_ZERO_FIELDS = false);
	// Returns a formatted date/time string
	static const QString GetDateTime(const ULONG timeSinceEpochInSeconds, const bool timeFirst);
	// Returns a formatted date string
	static const QString GetDate(ULONG timeSinceEpochInSeconds);
	// Method that loads the correct resource DLL based on the passed in language
	static const bool LoadLangDLL(const T_LANGUAGES eLANG, QString &rstrErrorMsg);
	// Method that gets the resource DLL name based on the passed in enum
	static const QString GetLangDLLName(const T_LANGUAGES eLANG);
	// Method that counts the instances of the passed in string within the test string
	static const USHORT InstanceOfStr(const QString &rstrSTRING_TO_TEST, const QString &rstrSTRING_TO_FIND);
	// Method that performs safe string copies - to replace calls to wcsncpy and wcscpy
	static void SafeWcsCpy(WCHAR *pwcDest, const WCHAR *pwcORIG, const USHORT usDEST_BUFF_LEN,
			const bool bNULL_TERMINATE_BUFF_END = true);
	// Method usedto convert unicode text into a UTF-8 representation (note: this will still need to
	// be converted using wcstombs
	static const QString EncodeToUTF8(const QString &rstrUNICODE_SOURCE);
	static const QString StripColourInfo(const QString &rstrTEXT_SOURCE);
	// Method that decodes UTF-8 strings into UNICODE
	static const QString DecodeFromUTF8(const QString &rstrUTF8_SOURCE);
	// Helper Method used to decode UTF-8 strings into UNICODE
	static BYTE MakeByte(TCHAR ch1, TCHAR ch2);
	// Method that breaks a full path/file name down into its path component and
	// filename
	static void StripFullPathName(const QString &rstrFULL_PATH_NAME, QString &rstrPath, QString &rstrFilename,
			QString &rstrExtension);
};
#endif

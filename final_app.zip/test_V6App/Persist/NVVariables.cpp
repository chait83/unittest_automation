/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: SRAM.cpp
/// @n Desc:	Manages access to the SRAM for a function related region	
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 37	Aristos	1.31.1.3.1.0 9/19/2011 4:51:10 PM	Hemant(HAIL) 
//		Stability recorder source code (JI Release) updated for WatchDog
//		Timer functionality.
// 36	Stability Project 1.31.1.3	7/2/2011 4:59:08 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 35	Stability Project 1.31.1.2	7/1/2011 4:38:32 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 34	Stability Project 1.31.1.1	3/17/2011 3:20:31 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// $
//
// ****************************************************************
#include "NVVariables.h"
#include "TraceDefines.h"
#include "V6globals.h"
// Singleton instance
CNVVariableBlockManager *CNVVariableBlockManager::m_pInstance = NULL;
QMutex CNVVariableBlockManager::m_CreationMutex;
//======================================================================//
// CNVVariableBlockManager class
//======================================================================
//**********************************************************************
/// CNVVariableBlockManager Constructor
/// Set-up and instanciate an array of CSRAMRegion objects to be used 
///
///
//**********************************************************************
CNVVariableBlockManager::CNVVariableBlockManager() {
	m_Initilaised = FALSE;
	m_pNVBaseAddress = NULL;
	m_NVByteCount = 0;
	m_VarsIntegrityOKCount = 0;
	m_VarsIntegrityFailedCount = 0;
	// Cleardown the ptr array to the NV Variable run time classes
	int arraySize = sizeof(CNVVarBlockBase*) * NVV_TOTAL_VARS;
	memset(m_pBlocks, 0, arraySize);
}
//**********************************************************************
/// Location to add all NV variables
/// ** Make sure you have defined a NVVAR_IDENT enum for you variable in NVVariables.h
/// ** and that you choose an appropriate NV Varibale class for purpose
///
//**********************************************************************
void CNVVariableBlockManager::AddNVVariables() {
	int varIdent = 0;
	// CNVBasicVar contains one 4 byte data value
	// CNVBasicTimeVar contains one 4 byte data value and an 8 LONGLONG for time
	// CNVBasic8TimeVar contains one 8 byte data value and an 8 LONGLONG for time
	// CNVTotaliser contains data for totaliser use only 
	// CNVAlarmStat contains data for alarm status per pen only 
	// *** Session and sequence numbers
	AddNV(NVV_SESSION, new CNVBasicVar());			// Session number
	AddNV(NVV_MESSAGE_SEQ, new CNVBasicVar());		// Message Sequence Number
	for (varIdent = NVV_PEN_SEQ_FIRST; varIdent < NVV_PEN_SEQ_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	// *** Toatalisers ***
	for (varIdent = NVV_PEN_TOTAL_FIRST; varIdent < NVV_PEN_TOTAL_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVTotaliser());
	}
	// *** Timers and timings ***
	AddNV(NVV_OGREALTIME, new CNVBasic8TimeVar());	///< Ongoing realtime value
	AddNV(NVV_TOTAL_TIME_ON, new CNVBasicVar());		///< Time on in seconds
	AddNV(NVV_TOTAL_TIME_OFF, new CNVBasicVar());		///< Time off in seconds
	AddNV(NVV_TOTAL_TIME_OFF_LITHIUM, new CNVBasicVar());	///< Time off in seconds resettable for lithium life		
	AddNV(NVV_MAX_TIME_OFF, new CNVBasicVar());	///< Maximum time period switched off	
	AddNV(NVV_BACKLIGHT_LIFE, new CNVBasicVar());	///< Backlight life count in seconds	
	AddNV(NVV_LITHIUM_LIFE, new CNVBasicVar());	///< lithium life count	in seconds
	// *** System stats ***
	AddNV(NVV_CJC_TEMP_MAX, new CNVBasicVar());	///< Maximum CJC temperature recorded inc time/date
	AddNV(NVV_CJC_TEMP_MIN, new CNVBasicVar());	///< Minimum CJC temperature recorded inc time/date
	AddNV(NVV_TOTAL_POWER_CYCLES, new CNVBasicVar());	///< Maximum Power cycles (include resets via reset button
	/// Number of relay actuations
	for (varIdent = NVV_RELAY_OPS_FIRST; varIdent < NVV_RELAY_OPS_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	AddNV(NVV_RELAY_OPS_POWER, new CNVBasicVar());	///< Number of Relay ops
	AddNV(NVV_FRONTCF_INSERTS, new CNVBasicVar());	///< Total number of front SD insertions
	// *** Maxs ***
	for (varIdent = NVV_PEN_MAX_FIRST; varIdent < NVV_PEN_MAX_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicTimeVar());
	}
	// *** Mins ***
	for (varIdent = NVV_PEN_MIN_FIRST; varIdent < NVV_PEN_MIN_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicTimeVar());
	}
	AddNV(NVV_EXPORT_DEVICE, new CNVBasicVar());	///< Scheduled export device ID
	AddNV(NVV_EXPORT_INTERVAL, new CNVBasicVar());	///< Scheduled export interval
	// ** Pen log enable **
	for (varIdent = NVV_PEN_LOGGING_FIRST; varIdent < NVV_PEN_LOGGING_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicTimeVar());
	}
	AddNV(NVV_CURRENT_SCREEN, new CNVBasicVar());	///< Current screen number
	AddNV(NVV_EXPORT_TIMER, new CNVBasicVar());	///< Scheduled export time progress
	AddNV(NVV_RECORDING_TIME, new CNVBasicVar());	///< Last calculated recording time available
	AddNV(NVV_BLOCKS_WAITING, new CNVBasicVar());	///< Last calculated blocks waiting to be transferred
	AddNV(NVV_LOG_QUEUE_BLOCKS, new CNVBasicVar());	///< Last calculated total log queue blocks
	AddNV(NVV_BATCH_STATUS, new CNVBasicTimeVar());	///< *** Now invalid - new batch status per group ***
	AddNV(NVV_MANUAL_TX_DEVICE, new CNVBasicVar());	///< Last manual data transfer device
	AddNV(NVV_RELAY_STATE_BOARD1, new CNVBasicVar());	///< Persisted state of relay out for board 1
	AddNV(NVV_RELAY_STATE_BOARD2, new CNVBasicVar());	///< Persisted state of relay out for board 2
	AddNV(NVV_RELAY_STATE_BOARD3, new CNVBasicVar());	///< Persisted state of relay out for board 3
	AddNV(NVV_RELAY_STATE_POWER, new CNVBasicVar());	///< Persisted state of relay out for power board
	// *** Message list oldest times ***
	for (varIdent = NVV_MESSAGE_LIST_OLDEST_TIME_FIRST; varIdent < NVV_MESSAGE_LIST_OLDEST_TIME_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicTimeVar());
	}
	// Event general information NV
	for (varIdent = NVV_EVENTS_FIRST; varIdent < NVV_EVENTS_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasic8TimeVar());
	}
	// Event counter NV
	for (varIdent = NVV_EVENTCOUNT_FIRST; varIdent < NVV_EVENTCOUNT_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	// User counter NV
	for (varIdent = NVV_USERCOUNT_FIRST; varIdent < NVV_USERCOUNT_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	// Low res pulse counter NV (digital cards)
	for (varIdent = NVV_LHWCOUNT_FIRST; varIdent < NVV_LHWCOUNT_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	// High res pulse counter NV (pulse cards)
	for (varIdent = NVV_HHWCOUNT_FIRST; varIdent < NVV_HHWCOUNT_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	// Descrete IO, dig inputs and relay outs
	for (varIdent = NVV_IOCOUNT_FIRST; varIdent < NVV_IOCOUNT_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	AddNV(NVV_FTP_RECORDING_TIME, new CNVBasicVar());	///< Last calculated FTP recording time available
	// Store for the current volume level
	AddNV(NVV_VOLUME_LEVEL, new CNVBasicVar());
	// User variables
	for (varIdent = NVV_USER_VARS_FIRST; varIdent < NVV_USER_VARS_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicTimeVar());
	}
	// Batch Mode - group based
	for (varIdent = NVV_BATCH_VARS_FIRST; varIdent < NVV_BATCH_VARS_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicTimeVar());
	}
	// Batch Count - group based
	for (varIdent = NVV_BATCH_COUNT_FIRST; varIdent < NVV_BATCH_COUNT_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	// Add an NV Variable for pre-trigger status
	AddNV(NVV_PRETRIGGER_STATUS, new CNVBasicVar());
	// Add an NV Variable for the TC Calibration Adjust exclude
	AddNV(NVV_TCCALEXCLUDE, new CNVBasicVar());
	// Add an NV Variable for WatchDog status
	AddNV(NVV_WATCHDOG_STATUS, new CNVBasicVar());
	// Add an NV Variable for Max WatchDog Kick Time
	AddNV(NVV_WATCHDOG_KICK_TIME, new CNVBasicVar());
	// An array for Thread Count of WatchDogTimer
	for (varIdent = NVV_THREAD_COUNT_FIRST; varIdent < NVV_THREAD_COUNT_MAX; varIdent++) {
		AddNV(static_cast<NVVAR_IDENT>(varIdent), new CNVBasicVar());
	}
	// Add an NV Variable for Low Virtual Memory
	AddNV(NVV_LOW_MEMORY, new CNVBasicVar());
}
//**********************************************************************
/// Add NV Variable to Manager 
///
/// @param[in] - nvID, NVVAR_IDENT identifier of the NV variable to be created
/// @param[in] - pNVInst, pointer to CNVVarBlockBase derived object
///
//**********************************************************************
void CNVVariableBlockManager::AddNV(NVVAR_IDENT nvID, CNVVarBlockBase *pNVInst) {
	// Has the block previously been set?
	if (m_pBlocks[nvID] == NULL) {
		// No, Assign New NV Variable object to list and setup it's addresses into the SRAM
		m_pBlocks[nvID] = pNVInst;
		// Setup address for Header and move running pointer past
		pNVInst->SetHeaderAddress(m_pNVRunning);
		m_pNVRunning += sizeof(T_NVVAR_HEADER);	// Move to location of first data block
		// Setup address for block zero and move running pointer past
		pNVInst->SetBlockAddress(NV_BANK_ZERO, m_pNVRunning);
		m_pNVRunning += pNVInst->BankSize();	// Move to location of second data block
		// Set address for Bank one and move running pointer past
		pNVInst->SetBlockAddress(NV_BANK_ONE, m_pNVRunning);
		m_pNVRunning += pNVInst->BankSize();	// Move to location of next NV Variable Block
		// Check integrity of NV Variable and increment Integrity counters on result.
		if (pNVInst->checkIntegrityOK(nvID) == TRUE) {
			m_VarsIntegrityOKCount++;	// NV Variable integrity okay				
		} else {
			m_VarsIntegrityFailedCount++;	// NV Variable integrity failed (could be a newly added variable)			
		}
	} else {
		// Yes, m_pBlocks[nvID] already being used, this is a failure
		LOG_CRTL(TRACE_PERSIST, "NV Vars: Block being set twice check NVVAR_IDENT number %d\n", nvID);
	}
}
//**********************************************************************
///
/// Instance creation of CSRAMManager singleton
///
/// @return		pointer to single instance of CSRAMManager
/// 
//**********************************************************************
CNVVariableBlockManager* CNVVariableBlockManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CNVVariableBlockManager;
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, "NVVarManager WaitForSingleObject Error", "NVVarManager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		nothing
/// 
//**********************************************************************
void CNVVariableBlockManager::CleanUp() {
	// Run though all NVVariables that have been allocated and release allocated memory
	for (int nvVarCount = 0; nvVarCount < NVV_TOTAL_VARS; nvVarCount++) {
		if (m_pBlocks[nvVarCount] != NULL) {
			delete m_pBlocks[nvVarCount];
		}
	}
	delete m_pInstance;
	m_pInstance = NULL;
}
//**********************************************************************
/// Initialise the SRAM manager
/// 
/// @return		TRUE if okay, otherwise FALSE indicating a failure
/// 
//**********************************************************************
BOOL CNVVariableBlockManager::Initialise() {
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	int iPathLen = 256;
	BOOLEAN isFileCreated = FALSE;
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"InitNVVar.txt", (256 - wcslen( InitLogFileName )) );
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Initialisation started-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// See if the manager has been initialised before
	if (m_Initilaised == TRUE) {
		LOG_INFO(TRACE_PERSIST, "NV Variable Manager, Already initialised \n");
#ifdef STARTUP_LOGGING
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			wcscpy(InitLogString,L"NV Variable Manager, Already initialised\n");
			wcscpy(InitLogString,L"--------Initialisation END-------\n");
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		return m_Initilaised;
	}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"m_pSRAMManager->Initialise\n");
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Get handle on the Static RAM manager
	m_pSRAMManager = CSRAMManager::GetHandle();
	m_pSRAMManager->Initialise();
	CSRAMManager::regionError requestReturn = m_pSRAMManager->RequestRegion(REGION_NVVARS, &m_pNVArea);
	if (m_pNVArea == NULL) {
		LOG_CRTL(TRACE_PERSIST, "NV Vars: Cannot access REGION_NV_VARIABLES region");
	} else {
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"m_pNVArea->SetAutoStateToNormal\n");
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		// Set to normal state, no checks required on region as each Nv Variable has own state checks, 
		// need to do one NV Var ata a time to avoid unnecessary NV Var resets over software upgrades
		m_pNVArea->SetAutoStateToNormal();
		// Get NV variable base address and setup runnign address
		m_pNVBaseAddress = reinterpret_cast<BYTE*>(m_pNVArea->GetAddress());
		m_pNVRunning = m_pNVBaseAddress;
		// First location of NV Variables SRAM contains the number of NV variable currently in the block
		// check if this is different, if so firmware update has occured or SRAM has been corrupted
		ULONG numberOfNVVariables = *reinterpret_cast<ULONG*>(m_pNVRunning);
		if (numberOfNVVariables != NVV_TOTAL_VARS) {
			LOG_INFO( TRACE_PERSIST, "NVVars current total number=(%d) new number =(%d) \n", numberOfNVVariables, NVV_TOTAL_VARS);
			*reinterpret_cast<ULONG*>(m_pNVRunning) = static_cast<ULONG>(NVV_TOTAL_VARS);
		}
		m_pNVRunning += sizeof(ULONG);
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"AddNVVariables()\n");
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		// Add the NV variables to the manager and Map in their SRAM address, performing an integrity check
		AddNVVariables();
		// Get total number of bytes that NV variable occupy
		m_NVByteCount = static_cast<ULONG>(m_pNVRunning - m_pNVBaseAddress);
		if (m_NVByteCount > static_cast<ULONG>(m_pNVArea->GetAvailableBytes())) {
			LOG_CRTL(TRACE_PERSIST, "NV Vars: REGION_NV_VARIABLES not big enough region=%d bytes variable require %d ", m_pNVArea->GetAvailableBytes(), m_NVByteCount);
		}
		qDebug("NVVars Configured Integrity OK(%d) failed(%d) total bytes %d \n", m_VarsIntegrityOKCount,
				m_VarsIntegrityFailedCount, m_NVByteCount);
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"pDALGLB->UpdateSRAM()\n");
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		pDALGLB->UpdateSRAM();	// request update to SRAM if it is file based.
	}
	m_Initilaised = TRUE;		// NV Variables can now be used
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"--------END of Initialisation-------\n");
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return m_Initilaised;
}
//======================================================================
// CNVVarBlockBase class
//======================================================================
CNVVarBlockBase::CNVVarBlockBase(USHORT size) {
	{
		m_structSize = size;
	};
}
//**********************************************************************
/// Update bank header to reflect changes made, expected that this is called
/// after an update and will change to point to other bank for next update
///
/// @return		Nothing
///
//**********************************************************************
void CNVVarBlockBase::BankUpdated() {
	// Is the current update block 0?
	if (m_pHeader->bankToUpdate == NV_BANK_ZERO) {
		// yes so Next time update block 1
		m_pHeader->bankToUpdate = NV_BANK_ONE;
	} else {
		//No, so next time update block zero
		m_pHeader->bankToUpdate = NV_BANK_ZERO;
	}
}
//**********************************************************************
/// Cleardown an NV Variable memeory area
///
/// @return		Nothing
///
//**********************************************************************
void CNVVarBlockBase::CleardownNVVar(USHORT id) {
	// Set bank to zero and init id
	m_pHeader->bankToUpdate = NV_BANK_ZERO;
	m_pHeader->id = id;
	// Set both data banks to zero
	memset(m_pDataBank[NV_BANK_ZERO], 0, m_structSize);
	memset(m_pDataBank[NV_BANK_ONE], 0, m_structSize);
}
//**********************************************************************
/// Check integrity of an NV Variable
///
/// @return		TRUE if okay, FALSE if integrity failed (or variable didn't exist)
///				the variable will be intialised.
///
//**********************************************************************
BOOL CNVVarBlockBase::checkIntegrityOK(USHORT id) {
	BOOL IntergrityOK = TRUE;
	// First check the contents of the header, it should be either NV_BANK_ZERO or NV_BANK_ONE
	if (m_pHeader->bankToUpdate != NV_BANK_ZERO && m_pHeader->bankToUpdate != NV_BANK_ONE) {
		IntergrityOK = FALSE;
		LOG_INFO(TRACE_PERSIST, "Initialising NV Variable block incorrect id(%d) block(%d) \n", m_pHeader->id, m_pHeader->bankToUpdate);
	}
	// Next check if the ID in the header is the same as the ID we thin we are checking
	if (IntergrityOK && m_pHeader->id != id) {
		IntergrityOK = FALSE;
		LOG_INFO(TRACE_PERSIST, "Initialising NV Variable id incorrect id(%d) should be %d \n", m_pHeader->id, id);
	}
	if (IntergrityOK == FALSE) {
		// An integirty check has failed - initialise the NV variable space
		CleardownNVVar(id);
	}
	return IntergrityOK;
}
//======================================================================
// CNVBasicVar class
//======================================================================
//**********************************************************************
/// Set Basic NV data
///
/// @param[in] - value, COMBO_VAR4 of variable
///
//**********************************************************************
void CNVBasicVar::SetToNV(COMBO_VAR4 value) {
	T_BASIC_VALUE *pBasicVar = reinterpret_cast<T_BASIC_VALUE*>(GetBankToUpdate());
	pBasicVar->value = value;
	BankUpdated();
}
//======================================================================
// CNVBasicTimeVar class
//======================================================================
//**********************************************************************
/// Set Basic NV data (4 Bytes) with time
///
/// @param[in] - value, COMBO_VAR4 of variable
/// @param[in] - time, TvTime in Microseconds
///
//**********************************************************************
void CNVBasicTimeVar::SetToNV(COMBO_VAR4 value, LONGLONG time) {
	T_BASIC_WITH_TIME *pBasicWithTime = reinterpret_cast<T_BASIC_WITH_TIME*>(GetBankToUpdate());
	pBasicWithTime->value = value;
	pBasicWithTime->time = time;
	BankUpdated();
}
//======================================================================
// CNVBasicTimeVar class
//======================================================================
//**********************************************************************
/// Set Basic NV data (8 Bytes) with time
///
/// @param[in] - value, COMBO_VAR8 of variable
/// @param[in] - time, TvTime in Microseconds
///
//**********************************************************************
void CNVBasic8TimeVar::SetToNV(COMBO_VAR8 value, LONGLONG time) {
	T_BASIC8_WITH_TIME *pBasic8WithTime = reinterpret_cast<T_BASIC8_WITH_TIME*>(GetBankToUpdate());
	pBasic8WithTime->value = value;
	pBasic8WithTime->time = time;
	BankUpdated();
}
//======================================================================
// CNVTotaliser class
//======================================================================	
//**********************************************************************
/// Set totlaiser structuire into both of the banks, this is done when start time
/// or status of total changes, this is a very low usgae so is split out and we must
/// make sure these low usage fields are ther same in both banks in one update
///
/// @param[in] - totalInfo, T_NV_TOTALISER structure containing all data to write to NV
///
//**********************************************************************
void CNVTotaliser::SetAllNV(T_NV_TOTALISER &totalInfo) {
	// Get bank to upadte and set all information
	T_NV_TOTALISER *ptotaliser = reinterpret_cast<T_NV_TOTALISER*>(GetBankToUpdate());
	*ptotaliser = totalInfo;
	BankUpdated();
	// Get other bank and set all information
	ptotaliser = reinterpret_cast<T_NV_TOTALISER*>(GetBankToUpdate());
	*ptotaliser = totalInfo;
	BankUpdated();
}
//**********************************************************************
/// Set the totlaise bank with the fast moving data, thius being an optimised
/// to add only timeInSeconds and the totlaiser value as the most rapidly changing info
///
/// @param[in] - totalInfo, T_NV_TOTALISER structure containing all data to write to NV
///
//**********************************************************************
void CNVTotaliser::SetOptimumNV(float value, ULONG timeInSeconds) {
	T_NV_TOTALISER *ptotaliser = reinterpret_cast<T_NV_TOTALISER*>(GetBankToUpdate());
	ptotaliser->totalValue = value;
	ptotaliser->runTimeInSeconds = timeInSeconds;
	BankUpdated();
}

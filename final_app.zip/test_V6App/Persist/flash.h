/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: SRAM.h
/// @n Desc:	Manages access to the SRAM for a function related region	
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 20-10-14	Rajanbabu M			Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
// 13	Stability Project 1.10.1.1	7/2/2011 4:57:19 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.10.1.0	7/1/2011 4:27:09 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	V6 Firmware 1.10		9/23/2008 3:09:24 PM	Build Machine 
//		AMS2750 Merge
// 10	V6 Firmware 1.9		1/3/2006 9:57:35 PM	Alistair Brugsch
//		modified ClearFlashBlock to allow all block types to be cleared
// $
//
// ****************************************************************
#ifndef __FLASHUSER_H__
#define __FLASHUSER_H__
#include <QMutex>
#include "DAL.h"							// System abstraction layer
#include "TV6Timer.h"						// Timer class
const USHORT FLASH_SIGNATURE = 0x8291; ///< Flash signature, never change from 0x8291
typedef struct FlashHeader {
	USHORT Signature;						///< Signature of flash block
	USHORT CRC;								///< CRC of flash block data section
	ULONG Size;							///< Size of data section last written 
	ULONG NumWrites;				///< Number of times this has been written
} T_FLASH_HEADER;
typedef enum flashstatus {
	FLASH_STATUS_OKAY,				///< Flash block okay, operation succesful
	FLASH_STATUS_FIRSTUSE,				///< Flash block first time used, no valid Signature (CRC not checked)
	FLASH_STATUS_CRCFAIL,			///< Flash block used before but CRC failed
	FLASH_STATUS_DALFAIL,	///< The DAL level flash block read/write failed.
	FLASH_STATUS_TOOBIG,					///< Flash size request is too big
} T_FLASH_STATUS;
//
///// List of flash blovks currently in use
//typedef enum flashIdent
//{
//	FLASH_BLK_TEST=0,					///< test region
//	FLASH_BLK_PASSWORDS2=8,					///< Addtional password area for password block overspill
//	FLASH_BLK_IOCALS=9,					///< IO cals, single & dual point + CJC
//	FLASH_BLK_BOOTLACE=10,					///< Bootlace information
//	FLASH_BLK_SYSTEM=11,					///< System details, serial number etc..
//	FLASH_BLK_PASSWORDS=12,					///< Passwords
//	FLASH_BLK_SPECIALBLOCKS=13,				///< Indicator for special blocks onwards i.e. 13,14 and 15.
//	FLASH_BLK_SPLASH_LO=13,					///< Splash screen Low 64K of 128K bitmap
//	FLASH_BLK_SPLASH_HI=14,					///< Splash screen High 64K of 128K bitmap
//	FLASH_BLK_IEL_PARAM=15,					///< IEL General Parameter block (MAC address, USB Host device etc..)
//	FLASH_BLK_AMS2750_SENSORS=7,			///< AMS2750 Additional Sensor Information for the analogue inputs
//	FLASH_BLK_MULTI_POINT_CAL=6				///< Multi point calibration Information for the analogue inputs
//} T_FLASH_BLOCK;
///// List of flash blovks currently in use
typedef enum flashIdent {
	FLASH_BLK_SPLASH_BLK_0 = 0,				///< Splash Screen Block 0
	FLASH_BLK_SPLASH_BLK_1 = 1,				///< Splash Screen Block 1
	FLASH_BLK_SPLASH_BLK_2 = 2,				///< Splash Screen Block 2
	FLASH_BLK_SPLASH_BLK_3 = 3,				///< Splash Screen Block 3
	FLASH_BLK_SPLASH_BLK_4 = 4,				///< Splash Screen Block 4
	FLASH_BLK_SPLASH_BLK_5 = 5,				///< Splash Screen Block 5
	FLASH_BLK_SPLASH_BLK_6 = 6,				///< Splash Screen Block 6
	FLASH_BLK_SPLASH_BLK_7 = 7,				///< Splash Screen Block 7
	FLASH_BLK_SPLASH_BLK_8 = 8,				///< Splash Screen Block 8
	FLASH_BLK_SPLASH_BLK_9 = 9,				///< Splash Screen Block 9
	FLASH_BLK_SPLASH_BLK_10 = 10,			///< Splash Screen Block 10
	FLASH_BLK_SPLASH_BLK_11 = 11,			///< Splash Screen Block 11
	FLASH_BLK_WSDCERTIFICATE_1 = 12,			///< ~2KB is used to store Certificates.cer in this Block
	FLASH_BLK_DEVICECACERTIFICATE_3 = 13,
	FLASH_BLK_ROOTCACERTIFICATE_2 = 14,					///< Spare Block 2
	///< Spare Block 3
	FLASH_BLK_EMAILROOTCERTIFICATE = 15,	///< used to store secure email root certificate
	FLASH_BLK_TEST = 16,					///< test region
	FLASH_BLK_ADDITIONAL_SPARE_1 = 17,					///< Spare block for additional fields(if any)
	FLASH_BLK_SRAM_FILE_Q_BACKUP = 18,		///< SRAM file queues backup 
	FLASH_BLK_ADDITIONAL_SPARE_3 = 19,		///< Spare block for additional fields(if any)
	FLASH_BLK_ADDITIONAL_SPARE_4 = 20,		///< Spare block for additional fields(if any)
	FLASH_BLK_ADDITIONAL_SPARE_5 = 21,		///< Spare block for additional fields(if any)
	FLASH_BLK_ADDITIONAL_SPARE_6 = 22,		///< Spare block for additional fields(if any)
	FLASH_BLK_ADDITIONAL_SPARE_7 = 23,		///< Spare block for additional fields(if any)
	FLASH_BLK_MULTI_POINT_CAL = 24,	///< Multi point calibration Information for the analogue inputs
	FLASH_BLK_AMS2750_SENSORS = 25,	///< AMS2750 Additional Sensor Information for the analogue inputs
	FLASH_BLK_PASSWORDS = 26,				///< Passwords
	FLASH_BLK_PASSWORDS2 = 27,				///< Addtional password area for password block overspill
	FLASH_BLK_IOCALS = 28,				///< IO cals, single & dual point + CJC
	FLASH_BLK_BOOTLACE = 29,				///< Bootlace information
	FLASH_BLK_SYSTEM = 30,				///< System details, serial number etc..
	FLASH_BLK_IEL_PARAM = 31				///< IEL General Parameter block (MAC address, USB Host device etc..)
} T_FLASH_BLOCK;
//**Class*********************************************************************
///
/// @brief Manage access to Flash blocks within the 2MB boot flash area
/// 
/// This class will manage access to FLASH blocks within the boot flash
/// blocks will be managed with signatures and CRC's apart from IEL param blocks
///	and the Splash screen.
///
/// This class is implemented as a singleton
///
//****************************************************************************
class CFlashManager: public CPassiveModule {
public:
	static CFlashManager* GetHandle();
	void CleanUp();
private:
	CFlashManager();
	CFlashManager(const CFlashManager&);
	CFlashManager& operator=(const CFlashManager&) {
		return *this;
	}
	;
	~CFlashManager() {
	}
	;
	static CFlashManager *m_pInstance;
	static QMutex m_CreationMutex;
	T_FLASH_STATUS ReadWriteBlock(T_FLASH_BLOCK blockNum, void *pData, ULONG size, UCHAR readOrWrite, BOOL bClear =
	FALSE);
public:
	BOOL Initialise();				///< initialise the Flash manager							
	T_FLASH_STATUS ReadBlock(T_FLASH_BLOCK blockNum, void *pData, ULONG size) {
		return ReadWriteBlock(blockNum, pData, size, BF_READ);
	}
	;
	T_FLASH_STATUS WriteBlock(T_FLASH_BLOCK blockNum, void *pData, ULONG size, BOOL bClear = FALSE) {
		return ReadWriteBlock(blockNum, pData, size, BF_WRITE, bClear);
	}
	;
	ULONG GetDataBlockSize(T_FLASH_BLOCK blockNum);
	BOOL CheckIntegrityAndRepair();
	BOOL SplashScreenCheckLoadAndProgram();
	void ClearFlashBlock(T_FLASH_BLOCK blockNum);
private:
	BOOL m_Initilaised;				///< Status of the CFlashManager instance.
	QMutex m_CritSection;			///< Critical section
	CTV6Timer m_timerWrite;					///< Write timer
	CDeviceAbstraction *m_pDAL;				///< Device abstraction layer ptr
};
void FlashtestCaddy();						// Flash Test caddy
#endif // __FLASHUSER_H__

//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Utilities
/// @n Registry.h
/// @n interface for the registry key wrapper class CRegistryKey.
/// @author MM
/// @date 25/05/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 03-Sep-15	Rajanbabu M		Updated Registry Entry AutoUpdate for SNTP
// 20	Stability Project 1.17.1.1	7/2/2011 5:00:20 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 19	Stability Project 1.17.1.0	7/1/2011 4:27:30 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 18	V6 Firmware 1.17		10/18/2007 6:45:56 PM Roger Dawson 
//		Modified the code so that is now updates the
//		HKLM\Services\HTTPD\Accept	CP-80\Sockaddr registry setting in order
//		to alter the web server's port number.
// 17	V6 Firmware 1.16		2/7/2007 3:48:06 PM	Roger Dawson 
//		Made various parameters const. 
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(_REGISTRY_H_)
#define _REGISTRY_H_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DAL.h"
#ifdef UNDER_CE
#define BASE_KEY	HKEY_LOCAL_MACHINE
#else
#define BASE_KEY	HKEY_CURRENT_USER
#endif
////////////////////////////////////////////////////
// Identifies the data type of a registry key
//
// Done as an enum to enforce checking on values used
typedef enum {
	VALUE_DWORD = 0x00000004, VALUE_STRING = 0x00000001, VALUE_BINARY = 0x00000003
} T_REG_VALUE_TYPE;
///////////////////////////////////////////////////////////////////////////
// Identifies the configuration data item to be written to a registry value
typedef enum {
	ITEM_IDENT_NAME = 0,			// Recorder name (as used by a name server)
	ITEM_IDENT_DESC,				// Recorder description
	ITEM_IP_ADDRESS,				// Static IP address
	ITEM_SUBNET_MASK,				// Sub-net mask
	ITEM_DEFAULT_GATEWAY,			// Default gateway
	ITEM_PRIMARY_DNS,				// Primary DNS server
	ITEM_SECONDARY_DNS,				// Secondaty DNS server
	ITEM_PRIMARY_WINS,				// Primary WINS server
	ITEM_SECONDARY_WINS,			// Secondart WINS server
	ITEM_DHCP_ENABLE,				// DHCP enable flag 
	ITEM_AUTO_CONFIG,				// Network auto-config flag
	ITEM_DNS_ORDER,					// DNS server look-up order
	ITEM_ENABLE_MDNS,				// Enable multi-cast DNS server look-up
	ITEM_ENABLE_DNS,				// Enable DNS server look-up
	ITEM_ENABLE_WINS,				// Enable WINS server look-up
	ITEM_HTTP_PORT_1,				// Web browser port - probably obselete to the setting below
	ITEM_HTTP_PORT_2,				// Web browser port
	ITEM_FTP_PORT,					// FTP port (not yet supported by CE)
	ITEM_HTTP_ENABLE,				// Web Browser Enable/Disable
	ITEM_FTP_ENABLE,				// FTP Enable/Disable
	ITEM_SNTP_CLIENT,				// NTP/SNTP client enable
	ITEM_SNTP_KEEP,					// NTP/SNTP server enable
	ITEM_SNTP_SERVER,				// NTP/SNTP server name
	ITEM_SNTP_REFRESH,				// NTP/SNTP refresh time
	ITEM_SNTP_RECOVERY,				// NTP/SNTP recovery after failure time
	ITEM_SNTP_THRESHOLD,				// NTP/SNTP threshold (currently works the wrong way round)
	ITEM_SNTP_TRUST_LOCAL_CLK,		// NTP/SNTP trust local clock
//PSR - SNTP fix begin
#ifdef UNDER_CE
	ITEM_SNTP_FLAGS,				// NTP/SNTP flags to load/unload the service etc 
	ITEM_SNTP_AUTOUPDATE,
#endif
//PSR - SNTP fix end
	NUM_REG_ITEMS		// Must be the last entry, used as iteration loop count
} T_REG_DATA_ITEM;
typedef struct {
	QString KeyName;					// Registry key name
	QString ValueName;				// Registry value name
	T_REG_VALUE_TYPE Type;			// Registry value type
	T_REG_DATA_ITEM Item;			// Registry value data item
	BOOL RebootRequired;			// Reboot required if value is changed
} T_REG_TABLE_ENTRY;
class CRegistryKey {
public:
	CRegistryKey();
	~CRegistryKey();
	BOOL CreateKey(const QString Name);
	BOOL DeleteKey(QString KeyName);
	BOOL DeleteValue(QString ValueName);
	BOOL OpenKey(const QString Key);
	BOOL Close();
	BOOL ReadValue(const QString ValueName, LPDWORD Type, BYTE *pData, LPDWORD Size);
	BOOL ReadValue(const QString ValueName, QString &rstrValue, LPDWORD Size, DWORD dwType);
	BOOL Compare(QString ValueName, QString Value);
	BOOL Compare(QString ValueName, DWORD Value);
	BOOL Compare(QString ValueName, BYTE *Value, DWORD Size, const USHORT usSTART_INDEX);
	BOOL WriteValue(const QString ValueName, DWORD Type, const BYTE *pData, DWORD Size);
	BOOL WriteValue(QString ValueName, DWORD Value);
	BOOL WriteValue(const QString ValueName, const QString Value);
	BOOL WriteValue(const QString ValueName, const BYTE *Value, DWORD Size);
	BOOL WriteEnumeratedValue(QString ValueName, DWORD Index, DWORD Type, BYTE *pData, DWORD Size);
	BOOL Flush();
	BOOL Update(T_REG_TABLE_ENTRY *Table);
	// Method that gets the DHCP IP address
	static const QString GetDHCPIPAddress();
	// Method that gets the WINS IP Address
	static const QString GetDHCPWINSIPAddress();
	// Method that gets the DNS IP Address
	static const QString GetDHCPDNSIPAddress();
	// Method that checks if this is a new registry by the fact a key generated by
	// the app is not present
	static const bool IsNewRegistry(const bool bRESET = false);
	// Method that resets the flag indicating this is a new registry
	static void ResetNewRegistryFlag();
private:
	void Initialise();
	BOOL InterpretTableEntry(T_REG_TABLE_ENTRY tableEntry, BOOL &bIsFlushRequired);
	void AddresstoWchar(in_addr address, QString wszValue);
//	CDeviceAbstraction *m_pDAL;
protected:
	HKEY m_Key;
};
#endif // !defined(_REGISTRY_H_)

#ifndef __TXSCHEDULER_H_INCLUDED__
#define __TXSCHEDULER_H_INCLUDED__
#include "v6ActiveModule.h"
#include "InternalMessageQueue.h"
#include "LogDeviceStatus.h"
#include "QueueMonitor.h"
#include "DataTransfer.h"
#include "MediaManager.h"
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
#include "CStorage.h"
#endif
#define ONE_SECOND 1000
// Scheduler thread control state
typedef enum {
	TX_INITIALISE,				// Thread initialisation
	TX_IDLE,					// Thread idle (waiting)
	TX_CONFIGURE,				// Thread configure/re-configure
	TX_CONFIG_PREPARE,			// Prepare for config change
	TX_RUNNING,					// Thread running
	TX_FTP_IN_PROGRESS,			// FTP download in progress
	TX_STOPPED_CURR_EXPORT,		// Stopped current export
	TX_SUSPEND,					// Thread suspend
	TX_SHUTDOWN_PREPARE,		// Shutdown preparation
	TX_SHUTDOWN					// Thread shut-down
} TRANSFER_THREAD_STATE;
// Scheduler shared data structure
typedef struct {
	TRANSFER_THREAD_STATE State;
	CInternalMessageQueue *pMessageQueue;
	BOOL RequestStop;
	USHORT Seconds;
} T_SCHEDULER_SHARED;
// Scheduler requests
typedef enum {
	RQ_START, RQ_STOP, RQ_NEW_CONFIG, RQ_TRANSFER_NEW, RQ_TRANSFER_ALL, RQ_UPDATE,
} T_REQUEST;
// Scheduler control message
typedef struct {
	T_REQUEST Request;
	T_LOG_DEVICE Device;
} T_SCHEDULER_MESSAGE;
//**Class*********************************************************************
///
/// @brief Data transfer scheduler
///
///		Performs real-time scheduling for the data transfer module.
///
//****************************************************************************
class CTxSchedule: public CV6ActiveModule {
public: // Methods
	void CheckAndCleanLCF();
	BOOL DoTransfer(T_TRANSFER_TYPE type, T_LOG_DEVICE device, bool resetPreTriggerTransferList = true);
	static CTxSchedule* GetHandle();
	static USHORT ProgressPercentage();
	static BOOL TransferComplete();
	BOOL IsExportAborted();
	// Critical section to prevent a commit and an export occuring at the same time.
	static QMutex m_ExportCS;
	// Method that stops any exports that may currently be in progress
	const T_V6ACTMOD_RETURN_VALUE RequestStop(const BOOL bSTOP, const TRANSFER_THREAD_STATE eRESTORE_STATE);
	HANDLE GetThreadHandle() {
		return m_ScheduleThread->m_hThread;
	}
	;
	// Module message handlers
	CTxSchedule(T_MODULE_ID moduleId);
	// Destructor
	~CTxSchedule();
	BOOL ClearAllNewData();
	T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	T_V6ACTMOD_RETURN_VALUE Shutdown(void);
	// Carries out the desired function when a message is received
	virtual T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler(const CMsgQueueMessage *pMsg);
	// Method that sends a finished export request back to the auto ops thread
	const T_V6ACTMOD_RETURN_VALUE PostFinishedFTPMessage(const USHORT usREPLY_MSG);
	// Method that sends a message back to the auto ops thread informing it data is ready 
	//	for downloading and there will be more to come
	const T_V6ACTMOD_RETURN_VALUE PostCollectFTPFilesMessage();
	// Module thread state control
	TRANSFER_THREAD_STATE GetState() {
		return m_SharedData.State;
	}
	;
	void SetState(TRANSFER_THREAD_STATE NewState) {
		m_SharedData.State = NewState;
	}
	;
	/// Timeout varaible used to stop/shutdown the thread - this is the worst case time for stopping
	/// an export on the pen currently being exported
	static const DWORD ms_dwTIMEOUT_IN_MS;
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		void LogDebugMessage(QString  & strDbgMsg);
	#endif
private: // Data
	BOOL m_Initialised;									///> Initialisation state
	T_SCHEDULER_SHARED m_SharedData;					///> Module/thread shared data
	static CTxSchedule *pInstance;
private: // Objects
	CDataTransfer *pm_DataTransfer;						///> Main data transfer class
	QThread *m_ScheduleThread;						///> Time scheduler thread
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	static CDebugFileLogger m_debugFileLogger;
#endif
};
////////////////////////////////////////
// Transfer scheduler control/communication class:
//	
class CTxThread: public QThread {
protected:
	CTxThread();  // protected constructor used by dynamic creation
	virtual ~CTxThread();
public:
	static UINT ThreadFunc(LPVOID lpParam);
};
//**Class*********************************************************************
///
/// @brief Data transfer scheduler thread
/// 
///
//****************************************************************************
class CTScheduleThread: public QThread {
public:
	static UINT ThreadFunc(LPVOID lpParam);
	static bool WaitForActionToComplete();
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	static void LogDebugMessage(QString  & strDbgMsg);
	static void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif
private:
	static void ShowScheduleError(bool &bDiskFull, CDataTransfer::T_TRANSFER_ERRORS eRetVal);
	static void ProcessRequestMessage(ULONG &Minutes, T_SCHEDULER_SHARED &SharedData);
	static void CheckConfigChange(ULONG &ulInterval);
	static void SetTransferDeviceToNV();
	static void ErrorReportMsg(CDataTransfer::T_TRANSFER_ERRORS eRetVal);
protected:
	CTScheduleThread();  // protected constructor used by dynamic creation
	virtual ~CTScheduleThread();
	static BOOL GotMedia(T_LOG_DEVICE device);
private:
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	static CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif // __TXSCHEDULER_H_INCLUDED__

/// @file 
/// ****************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	Gneneral
/// @n Filename: v6versions.h
/// @n Desc:	Version numbers for V6 software
///				
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 316 Aristos	1.297.1.13.1.2 10/24/2016 3:20:26 PM	Build Machine 
//		Fileformat coorected from mac to windows format
// 315 Aristos	1.297.1.13.1.2 9/21/2011 3:20:26 PM	Build Machine 
//		UpIssue to JK - BETA Release
// 314 Aristos	1.297.1.13.1.1 9/20/2011 5:53:22 PM	Build Machine 
//		UpIssue to JJ - BETA Release
// 313 Aristos	1.297.1.13.1.0 9/20/2011 3:27:42 PM	Build Machine 
//		UpIssue to JI - BETA Release
// 312 Stability Project 1.297.1.13 8/22/2011 4:44:05 PM	Build Machine
//		UpIssue to JJ - ALPHA Release
// $
//
// ****************************************************************
#ifndef __V6VERSIONS_H__
#define __V6VERSIONS_H__
#include <QString>
typedef enum _releaseType {
	RELEASE_INVALID,			///< No release type, not an official version
	RELEASE_TESTING,			///< Testing release, will not labelled in starteam, used for isolated test purposes
	RELEASE_ALPHA,			///< Alpha release, internal engineering release.
	RELEASE_BETA,			///< Beta release, release to send out for testing/demonstrations etc..
	RELEASE_PRODUCTION,///< Production/customer ready release. Promoted beta when satifactory for release to production
} T_RELEASE_TYPE;
///********************************************************************
const int V6VERSION_LENGTH = 14;
const QString V6_VERSION = "220.3.02.R";
const T_RELEASE_TYPE V6_RELEASE = RELEASE_PRODUCTION;			/// Release Type
///********************************************************************
#endif //__V6VERSIONS_H__

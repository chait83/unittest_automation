/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 General
/// @n Filename: Scripts.h
/// @n Desc:	 Constains a manager to provide control over script services
///				 and an Instance manager to handle eachs cript instance
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  11  Stability Project 1.8.1.1 7/2/2011 5:01:03 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  10  Stability Project 1.8.1.0 7/1/2011 4:27:33 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  9 V6 Firmware 1.8 5/5/2006 8:12:00 PM Andy Kassell  Set
//  script state variables SETUPCHANGED and TIMECHANGED correctly
//  8 V6 Firmware 1.7 2/2/2006 4:55:55 PM Andy Kassell  
//  Modify script reporting, put in message list if error when loading or
//  starting up
// $
//
// ****************************************************************
#include <QMutex>
#include "V6globals.h"
#include "ScriptServices.h"
#include "FunctionPack.h"
#include "ErrorServices.h"
#ifndef __SCRIPTS_H__
#define __SCRIPTS_H__
// Identifiers for auotmatically generated scripts
typedef enum {
	SCRIPT_STARTUP,									///< Script to be run on startup
	SCRIPT_PROVING,									///< Proving script, run from Configuration
	SCRIPT_PEN_FIRST,								///< First PenScript Ident
	SCRIPT_PEN_MAX = (SCRIPT_PEN_FIRST + V6_MAX_PENS),	///< Maximum Pen scripts
	/// Add new script types and instances here
	SCRIPT_MAX_NUMBER								///< Always at end, shgows the maximum number of available scripts
} T_SCRIPT_IDENT;
//**Class*********************************************************************
///
/// @brief V6 Manage the script processor
/// 
/// Manager for the script processor
///
//****************************************************************************
class CScriptManager: public CPassiveModule {
public:
	static CScriptManager* GetHandle();
	void CleanUp();
private:	// Singleton
	CScriptManager();
	~CScriptManager() {
	}
	;	// Will never be called
	CScriptManager(const CScriptManager&);
	CScriptManager& operator=(const CScriptManager&) {
		return *this;
	}
	;
	static CScriptManager *m_pScriptManagerInstance;
    static QMutex m_CreationMutex;
public:		// API
	V6ERRORINFO Initialise(void);
private:	// Methods
	void ClearPersistVariables();
public:		// Members
private:	// Members
	SS_INITINFO m_SSInitInfo;					///< Script Services initialisation structure
	class CSRAMManager *m_pSRAM;				///< Handle on SRAM manager
	class CSRAMRegion *m_pRegion;				///< Handle on SRAM region for Persist Variables
	char *m_FPCapabiltiiesTable;				///< Capabilities table in text format
};
//**Class*********************************************************************
///
/// @brief V6Manage a script instance
/// 
/// Manages all aspects of a script instance, can be used by any client to create and 
/// run a script
///
//****************************************************************************
class CScriptInstance {
public:
	CScriptInstance();
	~CScriptInstance();
public:		// API
	BOOL BuildAutoScript(char *pSource, T_MATH_TYPE mathType, T_SCRIPT_IDENT ident);
	V6ERRORINFO* CompileScript(BOOL silentError = FALSE);
	V6ERRORINFO* RunScript(float &result);
	USHORT GetFastestDependentRate();
	void SetSetupChangedFlag(BOOL Changed);
	void SetTimeChangedFlag(BOOL Changed);
	void Cleanup();
private:	// Methods
	void HandleScriptError(V6ERRORINFO &scriptErr, BOOL errorInMessageListOnly);
public:		// Members
private:	// Members
	char *m_pScript;			///< Source script
	size_t m_scriptSize;			///< Size of script in bytes
	int m_scriptIndex;			///< Script Index
	int m_performanceIndex;		///< Performance Index of the script
	BOOL m_ScriptBlockCreated;	///< TRUE if script block has been created, otherwise false
	USHORT m_sourceCRC;			///< CRC of source code, to detect if a change has been made
	V6ERRORINFO m_errInfo;		///< Local version of error information, used for all calls
	// DIT dependency list
	int m_numDITDependents;			///< Number of DIT index dependents in list m_dependentList							
	int m_dependentList[MAX_DIT_DEPENDECY_LIST];			///< List it DIT index for a dependency list
	T_SCRIPT_IDENT m_ident;									///< Script Identifier
	BOOL m_CurrentSetupChangeState;		///< Current state of Setup change flag (avoid slow Script Services calls)
	BOOL m_CurrentTimeChangeState;		///< Current state of time change flag (avoid slow Script Services calls)
};
extern CScriptManager *pGlbScriptManager;
#endif // __SCRIPTINSTANCE_H__

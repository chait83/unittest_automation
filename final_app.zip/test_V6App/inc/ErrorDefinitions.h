#include "V6ResourceBase.h"
#include "V6_ErrorDefinitions.h"
#include "V6UIResource.h"
//#include "SS_ErrorDefinitions.h" // has been moved to AppResources.h by the wizard

// ModBusCommon.h: ModBus common declarations.
//////////////////////////////////////////////////////////////////////
#if !defined(__MODBUSCOMMON_H__)
#define __MODBUSCOMMON_H__
#include "MbusRtuMasterProtocol.hpp"
#include "MbusAsciiMasterProtocol.hpp"
#include "MbusTcpMasterProtocol.hpp"
#include "MbusRtuOverTcpMasterProtocol.hpp"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//
// X-Series ModBus master.
//
// Sets the maximum number of transactions per slave device
//#define MAX_TRANSACTIONS		8
// Sets the maximum of ModBus master schedule entries, this is the number of individual data requests.
//#define MAX_SCHEDULE_ENTRIES	MAX_TRANSACTIONS * MAX_SLAVE_DEVICES
// Size of the ModBus read/write buffer (256 float values)
#define MAX_BUFFER_SIZE			1024
// ModBus master minimum sleep time
#define SCHEDULER_MINIMUM_SLEEP	100
// Message timeout values...
#define MB_EN_SLAVE_TIMEOUT			200
#define MB_EN_MASTER_TIMEOUT		250
// These values were chosen to allow communication with some (older) devices.
#define MB_RS_SLAVE_TIMEOUT			200
#define MB_RS_MASTER_TIMEOUT		300
// 500 (or less) is good for a UDC controller
#define E_NET_POLL_DELAY			500
// Some ModBus RS485 devices hold the line for a short time after a message, wait for this time between messages
#define RS485_MESSAGE_SLEEP			5
// Number of times to re-try a message
#define MB_RETRY_COUNT			2
// Maximum number of read failures before the error is reported (keep as small as possable)
#define MB_MAX_FAILURES			4
// Error values
// Outside ModBus map walue.
// returned when there is a data request which is outside the available register map
#define MB_OUTSIDE_MAP		99999.99F
// Comminications Lost.
// returned when communications have been lost to a slave device.
#define MB_COMMS_LOST		88888.88F
// Communications not established
// returned when a device isn't communicating.
#define MB_NO_COMMS			77777.77F
// Default comms not started value
#define MB_COMMS_NOT_STARTED	0.0F
// Running at full speed causes major problems for V5 (Ethernet) Recorders,
// The legacy value needs to be a minimum of 150.
#define TRAFFIC_REDUCTION_TIME					5
#define LEGACY_TRAFFIC_REDUCTION_TIME			200
// After opening the port, wait before talking (but only if it opened, and we are talking Ethernet)
// This is required for UCD controllers and V5 Recorders (Anything less than 250 will cause V5's to lock-up)
#define EN_POST_OPEN_WAIT						100
#define LEGACY_EN_POST_OPEN_WAIT				500
// Communications port identification
typedef enum {
	eRS485 = 0, eEthernet
} T_eCommsPort;
// Device protocol identification (byte swap)
typedef enum {
	eModBus = 0, eModBusX
} T_eProtocol;
// ModBus data request direction, this can be derived from the data request type ( T_eDataRequest )
typedef enum {
	e_Read = 0, e_Write
} T_eDirection;
// Data type being requested, used to decide request size and and byte ordering
typedef enum {
	e_Ushort = 0, e_Short, e_Long, e_Float,
} T_eDataType;
// Slave device error state
typedef enum {
	e_OK = 0,				// Device is OK
	e_CommsErrors,			// Device has had read/write errors
	e_OffLine				// Device is considered off-line, reduce the poll rate
} T_eErrorState;
// ModBus data requests
typedef enum {
	e_ReadCoils = 1,		// Supported 
	e_ReadDiscreteInputs = 2,		// Supported
	e_ReadMultipleRegisters = 3,		// Supported
	e_ReadInputRegisters = 4,		// Supported
	e_WriteCoils = 5,		// Not Supported
	e_WriteSingleRegister = 6,		// Not Supported
	e_ReadExceptionStatus = 7,		// Not Supported
	e_Diagnostics = 8,
	e_GetCommEventCount = 11,		// Not Supported
	e_GetComEventLog = 12,		// Not Suported
	e_ForceMultipleCoils = 15,		// Not Suported
	e_WriteMultipleRegisters = 16,		// Supported
	e_ReportSlaveID = 17,		// Honeywell Specific, (will be) used for connection diagnostics
	e_MaskWriteRegisters = 22,		// Not Suported
	e_ReadWriteRegisters = 23,		// Not Suported
	e_ReportDeviceID = 43		// Not Suported
} T_eDataRequest;
#endif // !defined(__MODBUSCOMMON_H__)

//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n Timer.h
/// @n interface for a high resolution timer.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log:
// 5	Stability Project 1.2.1.1	7/2/2011 5:02:06 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 4	Stability Project 1.2.1.0	7/1/2011 4:27:03 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 3	V6 Firmware 1.2		12/16/2004 5:04:51 PM Graham Waterfield
//		Fixed typo
// 2	V6 Firmware 1.1		12/13/2004 9:00:14 PM Graham Waterfield
//		Allow configuration to be written to
// 1	V6 Firmware 1.0		9/28/2004 4:19:27 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _TIMER_H
#define _TIMER_H
#if !defined(AFX_TIMER_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_TIMER_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Defines.h"
class CTimer {
	// high resolution timer
protected:
	LARGE_INTEGER startCount;
	LARGE_INTEGER endCount;
	double tstart;
	double tstop;
	static double tfreq;
	double time;
	double fps;
	int nFrames;
public:
	CTimer(void);
	~CTimer(void);
	void starttimer(void);
	void stoptimer(void);
	double timeintv(void);
	static double getSystemFreq(void);
	static LONGLONG timeCheck(LONGLONG schedTime);
	static LONGLONG scheduleRuntime(double interval);
	static LONGLONG scheduleTimeTo(LONGLONG schedule);
	static LONGLONG scheduleReferencedRuntime(LONGLONG lastSchedule, double interval);
	double tcorrection;
};
#endif // !defined(AFX_TIMER_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#endif // _TIMER_H

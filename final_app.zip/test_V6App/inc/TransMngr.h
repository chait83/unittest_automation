/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n TransMangr.h
/// @n interface for the abstract CTransMangr class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  16  Stability Project 1.13.1.1 7/2/2011 5:02:11 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  15  Stability Project 1.13.1.0 7/1/2011 4:27:05 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  14  V6 Firmware 1.13 6/3/2005 2:30:43 AM Graham Waterfield
//  Various code improvements & adding RT comp & RT cal calibration
//  13  V6 Firmware 1.12 3/30/2005 5:25:41 PM  Graham Waterfield
//  Debugging to prevent incorrect errors being reported
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _TRANSMANGR_H
#define _TRANSMANGR_H
#if !defined(AFX_TRANSMANGR_H__5F7A1130_FEAF_406D_878E_CF1DECE5A4A4__INCLUDED_)
#define AFX_TRANSMANGR_H__5F7A1130_FEAF_406D_878E_CF1DECE5A4A4__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QMutex>
#include "Defines.h"
#include "BoardManager.h"
class CTransMangr {
public:
	CTransMangr();
	virtual ~CTransMangr();
	BOOL InitialiseTransManager(void);
	class CProtocol* RequestTransToken(class CIOCard *pBoard);
	BOOL AITransSchedule(USHORT CardID);
	void TransactionTerminated(void);
	BOOL InitialiseTransaction(class CIOCard *pBoard);
	BOOL InitialiseTransProcess(USHORT cardNo);
//		BOOL GetCardInfo( USHORT CardID );
//		BOOL CardStartup( USHORT CardID );
//		BOOL Configure( USHORT CardID );
//		BOOL CalPrepare( USHORT CardID );
//		BOOL CalSetPoint( USHORT CardID );
//		BOOL CalTerminate( USHORT CardID );
//		BOOL CalComplete( USHORT CardID);
//		BOOL ReadHistory( USHORT CardID );
//		BOOL SetCardID( USHORT CardID );
//		BOOL StartScheduleAcq( USHORT CardID );
//		BOOL InitialiseBoardCapabilities( void );
//		BOOL SystemConfiguration( void );
//		BOOL QueryConfiguration( void );
	BOOL IsTransMangBusy(void) const;
private:
	BOOL m_ProcessingTransaction;		///< Is transaction manager currently processing a transaction
	USHORT m_CardSlotProcessing;		///< Card slot designator of card currently being processed
//		T_BOARDREF m_TransRef;				///< Info on current board being processed (slot no and channels reference)
	static QMutex m_csVariable;		///< Critical section handler
//		class CTransaction *m_pSPICardTransHndlr[MAX_SCHED_SERVICES];	///< Card slots transaction handlers.
	class CIOCard *m_pBoard[MAX_SCHED_SERVICES];						///< Associated board
	class CProtocol *m_pProtocol;								///< SPI protocol handler
};
#endif // !defined(AFX_TRANSMANGR_H__5F7A1130_FEAF_406D_878E_CF1DECE5A4A4__INCLUDED_)
#endif // _TRANSMANGR_H

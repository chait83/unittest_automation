/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Report system
/// @n Filename:  ReportManager.h
/// @n Description: Interface of the CReportManager class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  32  Stability Project 1.29.1.1 7/2/2011 5:00:25 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  31  Stability Project 1.29.1.0 7/1/2011 4:27:49 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  30  V6 Firmware 1.29 9/23/2008 3:09:31 PM  Build Machine 
//  AMS2750 Merge
//  29  V6 Firmware 1.28 3/19/2008 9:21:23 PM  Roger Dawson  
//  Added the ability to save message lists to external media
// $
//
// **************************************************************************
#ifndef __REPORTMANAGER_H__
#define __REPORTMANAGER_H__
#include <QMutex>
#include <memory>
#include "PenManager.h"
#include "reportgenthread.h"	//PSR - Fix for 1-30DY01Q
//**CReportManager************************************************************
///
/// @brief Singleton class responsible for creating reports when requested by other
/// areas of the system.
/// 
/// Singleton class responsible for creating reports when requested by other
/// areas of the system.
///
//****************************************************************************
class CReportManager {
public:		//Singleton 
	static CReportManager* GetHandle();
	~CReportManager(); //PSR - Fix for 1-30DY01Q
	// Method used to indicate when it is safe to do a confi change or shutdown
	// as there are no reports waiting to be generated
	const bool ReportsBeingProcessed() {
		return (m_usReportsInProgressRefCount != 0);
	}
	static void ProcessSingleMessageTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo,
			ULONG eMessageFilter);
	/// Enum used to indicate the report footer style i.e. two lines or a single line
	typedef enum {
		fseTWO_LINES, fseSINGLE_LINE
	} T_FOOTER_STYLE_ENUM;
private:
	CReportManager();
	CReportManager(const CReportManager&);
	CReportManager& operator=(const CReportManager&) {
		return *this;
	}
	;
	// Singleton auto pointer
	static std::unique_ptr<CReportManager> ms_kReportMgr;
	static QMutex m_CreationMutex;
	// Report pen query
	const bool IsReportPenEnabled(const USHORT penNo);
	const bool IsIndividualReportPenInGroup(const USHORT penNo, const USHORT reportNo, T_PREPORTS ptReports);
	const bool IsIndividualReportPenSelected(const USHORT penNo, const USHORT reportNo, T_PREPORTS ptReports);
	const bool IsReportAllPensSelected(const USHORT reportNo, T_PREPORTS ptReports);
	const bool IsReportPenRequired(const USHORT penNo, const USHORT reportNo, T_PREPORTS ptReports);
	const bool IsIndividualTotalReportPenSelected(const USHORT penNo, const USHORT reportNo, T_PREPORTS ptReports);
	const bool IsTotalReportPenRequired(const USHORT penNo, const USHORT reportNo, T_PREPORTS ptReports);
	// Report selection query
	static const bool IsReportByGroup(const USHORT reportNo, T_PREPORTS ptReports);
	static const bool IsBatchEnabled(const USHORT reportNo, T_PREPORTS ptReports);
	static const QString GetMessageIDString(const USHORT usMESSAGE_TYPE);
	QString GetSecondsSpanString(const LONGLONG time) const;
	void StartNewTabbedItem(QString strUser);
	void TabItem(QString strUser);
	void DisableTabParagraph();
	void CreateDigitalValueTable(const bool digIn, T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
			const USHORT reportNo);
	void BatchInfoReport(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void MessageInfoReport(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void AnnotateTimeDateToReportName(const QString FileName, const CTVtime createTime, QString &FileNameAndDate);
	void AddTotalsToColumn(T_PREPORTS ptReports, const USHORT reportNo, const USHORT penNo);
	void CreateSeperateTotalsTable(T_PREPORTS ptReports, const USHORT reportNo);
	void SetDefaultTableasprintf();
	USHORT GetMainReportTableColumnCount(T_PREPORTS ptReports, const USHORT reportNo);
	QString GetPeriodInformation(T_REPORT_FIELD_TIMINGS period, LONGLONG reportStartTime, LONGLONG &duration,
			QString &when, QString &finished, QString &finshedDate, QString &strReportTypeInfo);
	void CreateTotAveReportPeriodicTable(const bool average, T_REPORT_FIELD_TIMINGS period, T_PREPORTS ptReports,
			class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateMaxMinReportPeriodicTable(T_REPORT_FIELD_TIMINGS period, T_PREPORTS ptReports,
			class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateReportPeriodicTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateTopPulseCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateBottomPulseCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateDigitalInputCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateDigitalOutputCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateEventCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateUserCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreatePenAlarmCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateTotalsTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateMaxMinTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreatePenValueTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void CreateCountersTables(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo);
	void GetReportStartInfo(LONGLONG reportStartTime, UINT &nTotOfDaysInMonth, UINT &nDayInMonth, UINT &nRepStartTimeHH,
			UINT &nRepStartTimeMM, UINT &nRepStartTimeSS);
public:
	int RegisterReport(const QString fileName, const USHORT reportID);
	BOOL GenerateTestReport();
	BOOL GenerateReport(const USHORT reportNo, QString &rstrReportNamePath, QString &rstrErrorMsg,
			HANDLE hCallingThreadHandle = NULL);
	BOOL PrintReport(const QString strTitle, const QString FileAndDir);
	BOOL DeleteReportFile(const QString reportName);
	QString DecodeDataItemValue(T_DATA_ITEM_TYPE type, USHORT ref, USHORT instance);
	QString DecodeDataItemTag(T_DATA_ITEM_TYPE type, USHORT ref, USHORT instance);
	// Additional filename deccorators
	qint64 AppendTimeDateToReportName(const QString FileName, QString &FileNameAndDate);
	void AppendOldTimeDateToReportName(const QString FileName, const qint64 creationTime, QString &FileNameAndDate);
	void AppendInternalReportDirectory(const QString FileName, QString &PathAndFileName);
	void AppendExternalReportDirectory(const QString FileName, QString &PathAndFileName);
	//Send the ReportGenRequest to corresponding thread
	BOOL PostReportGenRequest(USHORT usReportIndex);	//PSR - Fix for 1-30DY01Q
private:
	/// Reference count used to indicate if any reports are currently being generated
	USHORT m_usReportsInProgressRefCount;
	/// Critical section used to avoid re-entrancy issues
	static QMutex m_kCritSect;
	// Method that triggers the sending of the specified report within an email 
	void EmailReport(const QString &rsrREPORT_NAME, const USHORT usREPORT_NO) const;
	// Method that triggers the exporting of the specified report to an external device
	void ExportReport(const QString &rsrREPORT_NAME, const T_LOG_DEVICE eEXPORT_DEV) const;
	USHORT GetMainPenReportTableColumnCount(T_PREPORTS ptReports, const USHORT reportNo);
	// Method that tidies up the report directory
	void TidyReportDirectory();
	// Method that adds the report header
	void AddHeader(CRTFLib &rkRTFFile, const USHORT usREPORT_NO, const LONGLONG llTIME_CREATED);
	// Method that adds the report footer
	void AddFooter(CRTFLib &rkRTFFile, const T_FOOTER_STYLE_ENUM eFOOTER_STYLE);
	// Create a TUS report
	void CreateTUSReport(CRTFLib &kNewRTFFile);
private:		/// member variables
	static T_NUMFORMAT ms_tNumasprintf;		///< Display format for real numbers on reports
	T_NUMFORMAT m_tCounterasprintf;	///< Display format for counter numbers on reports
	CReportGenThread *m_pReportGenThread;	//PSR - Fix for 1-30DY01Q
};
#endif

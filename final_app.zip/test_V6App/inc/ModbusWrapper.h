// ModbusWrapper.h: interface for the CModBus class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(__MODBUSWRAPPER_H__)
#define __MODBUSWRAPPER_H__
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DiagnosticDataTable.hpp"
#include "DataTable.hpp"
#include "V6globals.h"
#include "MbusSlaveServer.hpp"
#include "ScheduleWrapper.h"
#include "V6ActiveModule.h"
// Thread control state
typedef enum {
	TS_INITIALISE,				// Thread initialisation
	TS_IDLE,					// Thread idle (waiting)
	TS_CONFIGURE,				// Thread configure/re-configure
	TS_CONFIG_PREPARE,			// Prepare for config change
	TS_RUNNING,					// Thread running
	TS_SUSPEND,					// Thread suspend
	TS_SHUTDOWN					// Thread shut-down
} MODBUS_THREAD_STATE;
typedef struct {
	BOOL Enabled;
	MODBUS_THREAD_STATE ThreadState;
	BOOL volatile m_IsInIdleState;
} MODBUS_MASTER;
typedef struct {
	BOOL Enabled;
	MODBUS_THREAD_STATE ThreadState;
	BOOL m_IsInIdleState;
	USHORT m_Port;
	MbusDataTable dataTable;
} MODBUS_SLAVE;
//**Class*********************************************************************
///
/// @brief Holder for ModBus configuration and error stats
///
//****************************************************************************
class CModBusStats {
public: // methods
	static CModBusStats* GetHandle();
	void CleanUp();
	void Initialise();
	void Clear();
	BOOL IsEnabled();
	BOOL IsEthernet();
	ULONG GoodMessages() {
		return m_ulGoodMessages;
	}
	;
	ULONG BadMessages() {
		return m_ulBadMessages;
	}
	;
	ULONG SystemMessages() {
		return m_ulSystemErrors;
	}
	;
	void GoodMessage() {
		++m_ulGoodMessages;
	}
	;
	void BadMessage() {
		++m_ulBadMessages;
	}
	;
	void SystemMessage() {
		++m_ulSystemErrors;
	}
	;
	BOOL SetConfiguration();													///> Set new configuration
	void ClearConfiguration() {
		m_pCommunications = NULL;
	}
	;	///> Clear current configuration (probably changing)
	T_PCOMMUNICATIONS CurrentConfiguration() {
		return m_pCommunications;
	}
	;	///> Return a pointer to the current configurations block (or NULL)
private: // methods
	CModBusStats();
	~CModBusStats();
public: // data
	static CModBusStats *pInstance;			///< Single instance object pointer
	static QMutex hCreationMutex;			///< Object creation mutex
private: // data
	ULONG m_ulGoodMessages;					///> Good messages received
	ULONG m_ulBadMessages;					///> Bad messages received
	ULONG m_ulSystemErrors;					///> Internal system errors
	T_PCOMMUNICATIONS m_pCommunications;		///> Current communications config block (NULL if not set)
};
//**Class*********************************************************************
///
/// @brief Modbus slave wrapper/control module
///
//****************************************************************************
class CModBusSlave: public CV6ActiveModule {
public:
//	static CModBusSlave *GetHandle( );
//	void Cleanup( );
	CModBusSlave(T_MODULE_ID moduleId);
	T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	T_V6ACTMOD_RETURN_VALUE Shutdown(void);
	MODBUS_THREAD_STATE GetSlaveState() {
		return m_SlaveState;
	}
	;
	void SetSlaveState(MODBUS_THREAD_STATE NewState) {
		m_SlaveState = NewState;
	}
	;
	MODBUS_SLAVE m_Slave;
private:
	QThread *m_hSlave;
	DWORD m_dwSlaveID;
	MODBUS_THREAD_STATE m_SlaveState;
};
////////////////////////////////////////
// Modbus slave thread
//	
class CModbusSlaveThread: public QThread {
protected:
	CModbusSlaveThread();  // protected constructor used by dynamic creation
	virtual ~CModbusSlaveThread();
	static void ProcessSlave(CModBusSlave *pModBusWrapper);
	static MbusSlaveServer* CreateModbusSlave(MODBUS_SLAVE *Slave);
public:
	static UINT ThreadFunc(LPVOID lpParam);
protected:()
};
//**Class*********************************************************************
///
/// @brief Modbus master wrapper/control module
///
//****************************************************************************
class CModBusMaster: public CV6ActiveModule {
public:
//	static CModBusMaster *GetHandle( );
//	void Cleanup( );
	CModBusMaster(T_MODULE_ID moduleId);
	T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	T_V6ACTMOD_RETURN_VALUE Shutdown(void);
	MODBUS_THREAD_STATE GetMasterState() {
		return m_MasterState;
	}
	;
	void SetMasterState(MODBUS_THREAD_STATE NewState) {
		m_MasterState = NewState;
	}
	;
	MODBUS_MASTER m_Master;
	CModBusSchedule *ScheduleWrapper;
private:
	QThread *m_hMaster;
	DWORD m_dwMasterID;
	MODBUS_THREAD_STATE m_MasterState;
};
////////////////////////////////////////
// Modbus master thread
//	
class CModbusMasterThread: public QThread {
protected:
	CModbusMasterThread();  // protected constructor used by dynamic creation
	virtual ~CModbusMasterThread();
	static void ProcessMaster(CModBusMaster *pModBusWrapper);
public:
	static UINT ThreadFunc(LPVOID lpParam);
};
#endif // !defined(__MODBUSWRAPPER_H__)

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Media Manager
/// @n Filename:  Worker Thread
/// @n Description: Performs background media utilities
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.2.1.1 7/2/2011 5:02:55 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.2.1.0 7/1/2011 4:27:02 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 V6 Firmware 1.2 7/6/2005 3:13:55 PM Martin Miller 
//  Work in progress, contains some test code.
//  Testing data extraction from log queues.
//  2 V6 Firmware 1.1 6/29/2005 6:56:51 PM  Martin Miller 
//  Removed redundant and duplicate code.
// $
//
// **************************************************************************
// WorkerThread.h: interface for the CWorkerThread class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(__WORKERTHREAD_H__)
#define __WORKERTHREAD_H__
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "FileList.h"
// Media manager idle sleep time (in ms) when idle, sleep for 10ms
#define MEDIA_SLEEP_TIME	10
// Media status change check time (in ms) poll every second of idle time
#define MEDIA_POLL_TIME		1000
// Size of the media manager worker thread queue
typedef enum T_THREAD_STATE {
	THREAD_STOPED, THREAD_RUNNING, THREAD_CLOSED,
} THREAD_STATE;
//*******************************************
// Data passed to/from the media manager worker thread
///
/// @brief Holds any data to be passed between the media manager worker thread and the API
//*******************************************
typedef struct T_WORKER_DATA {
	class CMediaAPI *pBaseAPI;					///< Pointer to the host/base API object
	DWORD dwLastError;							///< Last CE error detected
	T_THREAD_STATE ThreadState;					///< Thread running state
} WORKER_DATA;
//**Class*********************************************************************
///
/// @brief Performs background media utilities
/// 
/// Provides back-ground worker functions to the media API
///
//****************************************************************************
class CWorkerThread: public QThread {
public:
	static CWorkerThread* GetHandle();
	virtual ~CWorkerThread();
	DWORD m_dwThreadID;									///< Worker thread ID
	QThread *m_WorkerThread;							///< Worker thread handle
	T_WORKER_DATA m_WorkerData;							///< Shared worker thread data
protected:
	CWorkerThread();
	CWorkerThread(const CWorkerThread&);
	CWorkerThread& operator=(const CWorkerThread&);
	static UINT ThreadFunc(LPVOID lpParam);
private:
	static CWorkerThread *m_pInstance;					///< Single instance object pointer
	static QMutex hCreationMutex;						///< Object construction mutex
};
#endif // !defined(__WORKERTHREAD_H__)

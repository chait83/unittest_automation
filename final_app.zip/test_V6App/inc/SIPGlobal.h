/// @file SIPGlobal.h
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 EditPanel
/// @n Filename: SIPGlobal.h
/// @n Desc:	 Declaration of the data structure used by the Edit
///				 Panel
// ****************************************************************
// Revision History
// ****************************************************************
//  $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 5:01:24 PM Hemant(HAIL)
//  Stability Project: Recorder source has been upgraded from IL
// version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:27:28 PM Hemant(HAIL)
//  Stability Project: Files has been checked in before the merging
// task. The merging will be done between IL version of firmware and JF
// version of firmware. 
//  5 V6 Firmware 1.4 2/15/2007 11:34:41 AM  Amar (HTSL)  
// Added Structure stKeyMapInfoMultiLang
// Extend the keymap for the input panels to allow multiple key layouts
// .
//  4 V6 Firmware 1.3 2/23/2006 6:25:39 PM  Roger Dawson  
// Made changes to simplify the setup of SIP's and Mule's.
//  $
//
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#pragma once
#include "Defines.h"
//Maximum entry that size and position map can contain
#define MAXSPMAPENTRY  80
//Maximum entry that key map can contain
#define MAXKMAPENTRY  60
//Maximum languages or key arrangements for the given panel
#define MAXKEYLANG		  10
//******************************************************
// typedef struct stBitmapInfo
///
/// @brief --- First time initialization parameter
///
/// Contains the parameters that are required to prepare
///	the SIP layout
///
//******************************************************
typedef struct stBitmapInfo {
	void *pBmp;
	DWORD size;
} BITMAP_INFO;
//******************************************************
// typedef struct stSizePosition
///
/// @brief --- First time initialization parameter
///
/// Contains the size and position map of the keys 
///	in the SIP layout
///
//******************************************************
typedef struct stSizePosition {
	WORD sizePositionArray[MAXSPMAPENTRY][5];
	WORD entry;
} SIZE_POSITION;
//******************************************************
// typedef struct stKeyMap
///
/// @brief --- Key Map
///
/// Contains the key map of the keys in the SIP layout	
///
//******************************************************
typedef struct stKeyMap {
	WORD KeyID;
	WCHAR Lower;
	WCHAR Upper;
	WCHAR AULower;
	WCHAR AUUpper;
} KEY_MAP;
//******************************************************
// typedef struct stKeyMapInfoMultiLang
///
/// @brief --- First time initialization parameter
///
/// Contains the key map of the keys in the SIP layout 
/// with the number of entries in the key map for multiple languages	
///
//******************************************************
typedef struct stKeyMapInfoMultiLang {
	KEY_MAP KeyMap[MAXKEYLANG][MAXKMAPENTRY];
	WORD entry;
	WORD Langs;
} KEY_MAP_INFO_MULTI;
//******************************************************
// typedef struct stKeyMapInfo
///
/// @brief --- First time initialization parameter
///
/// Contains the key map of the keys in the SIP layout 
/// with the number of entries in the key map 	
///
//******************************************************
typedef struct stKeyMapInfo {
	KEY_MAP KeyMap[MAXKMAPENTRY];
	WORD entry;
} KEY_MAP_INFO;
//******************************************************
// typedef struct stFontInfo
///
/// @brief --- Font Information
///
/// Contains the font name, font size and font color 
///
//******************************************************
typedef struct stFontInfo {
	WCHAR FontName[20];
	WORD FontSize;
	DWORD FontColor;
} FONT_INFO;
//******************************************************
// typedef struct stOffsetInfo
///
/// @brief --- Offset information
///
/// Contains the X and Y offset value to display the 
/// character in the SIP at down state.
//******************************************************
typedef struct stOffsetInfo {
	short XOffset;
	short YOffset;
} OFFSET_INFO;
//******************************************************
// typedef struct stPositionInfo
///
/// @brief --- First time initialization parameter
///
/// Contains the parameters that are giving the starting
///	position coordinates of the SIP layout in the screen
///
//******************************************************
typedef struct stPositionInfo {
	WORD XCoordinate;
	WORD YCoordinate;
} POSITION_INFO;
//******************************************************
// typedef struct stDisplayInfo
///
/// @brief --- First time initialization parameter
///
/// Contains the parameters that are required to prepare
///	the SIP layout 
///
//******************************************************
typedef struct stDisplayInfo {
	FONT_INFO TextFontInfo;
	FONT_INFO EditFontInfo;
	FONT_INFO DescriptionFontInfo;
	DWORD Background;
	OFFSET_INFO OffsetInfo;
} DISPLAY_INFO;
//******************************************************
// typedef struct stBufferInfo
///
/// @brief --- Run time initialization parameter
///
/// Contains the parameters that are giving the information
///	about the buffer that are going to store the user input 
///
//******************************************************
typedef struct stBufferInfo {
	QString pBuffer;
	WORD BufferLength;
	WORD Limit;
} BUFFERINFO;
//******************************************************
// typedef struct stOtherInfo
///
/// @brief --- Run time initialization parameter
///
/// Contains the parameters that are giving the information
///	about the parameter for that user is going to modify 
/// and the idle timeout value 
///
//******************************************************
typedef struct stOtherInfo {
	WCHAR Description[100];
	QString pHelpTopic;
	QString pHelpChapter;
	DWORD TimeOut;
	WORD IsPassword; // only used on SIP's
	WORD LineLimit;	// only used on MuLE's
} OTHERINFO;
//******************************************************
// typedef struct stKeyText
///
/// @brief --- Run time initialization parameter
///
/// Contains the parameters that are giving the information
///	about the parameter for that user is going to modify 
/// and the idle timeout value 
///
//******************************************************
typedef struct stKeyText {
	WCHAR EditKeyText[10];
	WCHAR InsertKeyText[10];
	WCHAR DeleteKeyText[10];
} KEYTEXT;
//******************************************************
// typedef struct stMulDisplayInfo
///
/// @brief --- First time initialization parameter
///
/// Contains the parameters that are required to prepare
///	the SIP layout 
///
//******************************************************
typedef struct stMulDisplayInfo {
	FONT_INFO TextFontInfo;
	FONT_INFO EditFontInfo;
	FONT_INFO DescriptionFontInfo;
	DWORD Background;
	DWORD IndicatorColor;
	OFFSET_INFO OffsetInfo;
} MULDISPLAY_INFO;
//***** START - constants used by CMuLEPanelDlg*****/
//Edit box key ID
#define MULEDITBOX			81
//Description field key ID
#define MULDESCRIPTION		80
//Cancel key key ID
#define MULCANCEL			86
//OK key key ID
#define MULOK				85
//Help key key ID
#define MULHELP			  87
//Edit key key ID
#define MULEDIT			  82	
//Insert Key Key ID			
#define MULINSERTKEY		83
//Delete Key Key ID
#define MULDELETEKEY		84
//Idle time timer ID for Multiline edit panel
#define IDLEMULTIMEID		103
#define CURRENTLINE			1
#define UPLINE				2
#define DOWNLINE			0
#define CARRIAGERETURN		0x0D
#define LINETERMINATOR		0x0A
#define MULELINETERMINATOR	QString   ("\r\n")
#define STRINGTERMINATOR	'\0'
//***** END - constants used by CMuLEPanelDlg*****/
//***** START - constants used by CEditPanelDlg*****/
//Edit box key ID
#define EDITBOX				61
//Description field key ID
#define DESCRIPTION			62
//Cancel key key ID
#define SIPCANCEL			63
//OK key key ID
#define SIPOK				64
//Caps lock key key ID
#define CAPSLOCK			65
//Shift key key ID
#define SHIFT				66
//Delete key key ID
#define DELETEKEY			67
//AU key key ID
#define AU					68
//Help key key ID
#define HELP				69
//Forward key key ID
#define FORWARD				70
//Backward key key ID
#define BACKWARD			71
//Enter key ID
#define ENTER				72
//Backspace key key ID
#define BACKSPACE			73
//Backslace key key ID
#define BACKSLACE			74	
//Space key key ID
#define SPACE				0
//Maximum ID value that print key can contain 
#define MAXPRINTKEY			59
//Idle time timer ID
#define IDLETIMEID			100
//Double click timer ID
#define DBLCLKTIMEID		101
//Repeat character timer ID
#define	REPEATTIMEID		102
//Edit box ID
#define EDITBOXID			200		
//Static control
#define STATICID			400
//Reset flag value
#define RESETFLAG			0
//Set flag value
#define SETFLAG				1
//Set value
#define SETVALUE			1
//Reset value
#define RESETVALUE			0
//Timer value
#define TIMERVALUE			500
//Repeat timer value
#define REPEATTIMERVALUE	100
//Key ID field position in the size and position map 
#define KEYID				0
//X coordinate field position in the size and position map 
#define XCOORDINATE 1
//Y coordinate field position in the size and position map 
#define YCOORDINATE			2
//Length field position in the size and position map 
#define LENGTH				3
//Width field position in the size and position map 
#define WIDTH				4
//Blank character value
#define BLANK				32
#define PASSWORDCHAR		'*'
//***** END - constants used by CEditPanelDlg*****/
//Callback function declaration 
typedef BOOL (WINAPI *glbpCallbackFunction)(QString);

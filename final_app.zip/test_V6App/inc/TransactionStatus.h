/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: TransactionStatus.h
/// @n Desc:	Keep track of transactions using NV 
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 6	Stability Project 1.3.1.1	7/2/2011 5:02:10 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.3.1.0	7/1/2011 4:27:02 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	V6 Firmware 1.3		6/27/2005 8:11:07 PM	Andy Kassell	Add
//		data item to status store
// 3	V6 Firmware 1.2		10/7/2004 8:00:31 PM	Martin Miller 
//		Fixed build warning in Visual Studio
// $
//
// ****************************************************************
#if !defined(__TRANSACTIONSTATUS_H__)
#define __TRANSACTIONSTATUS_H__
#include "Defines.h"
// Transaction type identifier, for each transaction type add an identifier, this is used 
// when requesting a transaction identifier
typedef enum {
	TRANS_IDENT_NONE = 0,				///< Invalid ident, position not used	
	TRANS_IDENT_START = 1,						///< Start identifier
	TRANS_IDENT_FLASH = TRANS_IDENT_START,	///< Flash transaction identifier
	TRANS_IDENT_SIM_SRAM,					///< Identifier for simulated SRAM
	/// Add additional transaction identifiers here
	TRANS_IDENT_MAX			///< ALWAYS AT END Maximum transaction identifiers
} T_TRANSACTION_IDENT;
// Transaction status, providing the current transaction status of a T_TRANSACTION_HOLDER
typedef enum {
	TRANSACTION_STATUS_NORMAL = 0,		///< Normal status, nothing happening
	TRANSACTION_STATUS_WRITEFILE,				///< Currently writing the file
	TRANSACTION_STATUS_WRITEFLASH,				///< Currently writing the flash
/// User , add more states here as required
} T_TRANSACTION_STATUS;
// Transaction Holder, one exists for each T_TRANSACTION_IDENT up to TRANS_IDENT_MAX
typedef struct								// File status data held in NV-RAM
{
	T_TRANSACTION_IDENT ident;				///< Transaction identifier
	T_TRANSACTION_STATUS Status;				///< Current Transaction status
	DWORD userData;								///< User defined data
} T_TRANSACTION_HOLDER;
//**Class*********************************************************************
///
/// @brief Stores a non-volatile transaction status in RAM
/// 
/// provides a non-volatile transacrion status in NV-RAM for any transactions that need
/// to be undertaken within the system. Static implementation to simplify usage
///
//****************************************************************************
class CTransactionStatus {
public:
	static BOOL Initialise();
	static T_TRANSACTION_STATUS GetStatus(T_TRANSACTION_IDENT ident, DWORD *pData);
	static void SetStatus(T_TRANSACTION_IDENT ident, T_TRANSACTION_STATUS status, DWORD data);
private:
	static T_TRANSACTION_HOLDER *pTransactionBase;
};
#endif // !defined(__TRANSACTIONSTATUS_H__)

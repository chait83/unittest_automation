// TcpSocket.h: interface for the CTcpSocket class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_TCPQAbstractSocket_H__375F2F25_1D4D_4D30_82C7_4CEEF130F011__INCLUDED_)
#define AFX_TCPQAbstractSocket_H__375F2F25_1D4D_4D30_82C7_4CEEF130F011__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V7SecureSocket.h"
class CTcpSocket: public CV7SecureSocket {
public:
	CTcpSocket(ESocketTransMode eSTMode);
	CTcpSocket(HWND hParent, ESocketTransMode eSTMode);
	CTcpSocket(QAbstractSocket skt, ESocketRoleType role, CredHandle *hServerCreds, CtxtHandle *hContext);
	virtual ~CTcpSocket();
	void AcceptServiceSocket(QAbstractSocket serviceSock, HANDLE hCloseEv);
	virtual void OnReceive();
	bool Accept(UINT localPort, int maxConn = SOMAXCONN);
	virtual bool OnAccept(QAbstractSocket serviceSocket);
	virtual void OnClose(int closeEvent);
	bool Create();
	void SetParent(HWND hParent);
	QAbstractSocket GetServiceSocket() {
		return m_sServSock;
	}
	;
	HANDLE GetAcceptEvHandle() {
		return m_hAcceptEv;
	}
	;
	HANDLE GetAcceptedEvHandle() {
		return m_hAcceptedEv;
	}
	;
	HANDLE GetCloseEvHandle() {
		return m_hCloseEv;
	}
	;
	HANDLE GetBackoffEvHandle() {
		return m_hBackoffEv;
	}
	;
	//void SetCloseEvHandle(HANDLE hEv) {m_hCloseEv = hEv;};
	HANDLE GetRecvEvHandle() {
		return m_hRecvEv;
	}
	;
	bool ResumeAcceptThread();
	bool ResumeReadThread();
	QAbstractSocket GetLastServiceSock() {
		return m_sServSock;
	}
	;
	//void SetWSAInit(bool set){m_bWSAStarted = set;};
	void SetFailedServEvent(HANDLE hEv) {
		m_hServFailed = hEv;
	}
	;
	bool Connect(QString &addr, UINT remotePort, HANDLE hCloseEv = NULL);
	HRESULT Disconnect();
protected:
	//Used for TLS feature
	virtual bool OnConnect(QString &addr);
#ifdef DBG_FILE_LOG_STCPS_ENABLE
	virtual void LogDebugMessage(QString  strDebugMsg);
	#endif
private:
	QAbstractSocket m_sServSock;
	HWND m_hParent;
	HANDLE m_hAcceptEv;
	HANDLE m_hAcceptedEv;
	HANDLE m_hRecvEv;
	HANDLE m_hCloseEv;
	HANDLE m_hServFailed;
	HANDLE m_hConnEv;
	HANDLE m_hBackoffEv;
};
#endif // !defined(AFX_TCPQAbstractSocket_H__375F2F25_1D4D_4D30_82C7_4CEEF130F011__INCLUDED_)

// ScriptServices.h : main header file for the SCRIPTSERVICES DLL
//
#if !defined(AFX_SCRIPTSERVICES_H__538F2746_F3A8_4183_85F3_8693F22C2190__INCLUDED_)
#define AFX_SCRIPTSERVICES_H__538F2746_F3A8_4183_85F3_8693F22C2190__INCLUDED_
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
/****************************************** Includes ******************************************************/
#include <SS_CommonDefines.h>
#include "Defines.h"
#include "ErrorServices.h"
#include <QWidget>
/////////////////////////////////////////////////////////////////////////////
// CScriptServicesApp
// See ScriptServices.cpp for the implementation of this class
//
class CScriptServicesApp: public QWidget {
public:
	CScriptServicesApp();
};
/****************************************** Enums ******************************************************/
typedef struct SCRIPTSERVICES_API tagInitInfo {
	void *pPV;
	int nPVMemSize;
	SS_MODE eScriptMode;
	FPGETPROCFUNCPTR *pfnFuncPackGetProc;
	int (*pfnDITVarValid)(char*);
	float (*pfnDITGetVarValue)(int);
	char *pSFCT;
	char *pFPCT;
} SS_INITINFO, *PSS_INITINFO;
/****************************************** Variables ******************************************************/
/********************************************* APIs *********************************************************/
void SCRIPTSERVICES_API SS_Initialize(SS_INITINFO structInitInfo, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_UnInitialise(V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_EnnumerateFuncPackLibrary(OUT int* ppFuncCount, OUT SAFEARRAY** ppFunctionList,V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_EnnumerateScriptFunctionLibrary(OUT int* ppFuncCount, OUT SAFEARRAY** ppFunctionList,V6ERRORINFO* pErrInfo);
void SCRIPTSERVICES_API SS_Validate(BYTE *bScriptSourceBuffer, BOOL *bValid, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_ValidateSB(BYTE *szScriptName, BOOL *bValid, SAFEARRAY **ppFuncList, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_ValidateSF(BYTE *szScriptName, BOOL *bValid, SAFEARRAY **ppFuncList, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_GenerateScriptBlock(BYTE *bScriptSourceBuffer, int *nBlockId, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_Execute(int nBlockId, float *fResult, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_Execute(BYTE *szScriptSource, float *fResult, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_DeleteScriptBlock(int nBlockId, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_DeleteAllScriptBlock(V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_SetState(int nBlockId, int nState, BOOL bValue, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_SetStateForAll(int nState, BOOL bValue, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_GetState(int nBlockId, int nState, BOOL *bValue, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_ResetGlobalContext(V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_RefreshCapabilitiesTable(SS_INITINFO structInitInfo, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_GetExecutionCount(int nBlockId, int *nCount, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_GetPerformanceIndex(int nBlockId, int *nIndex, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API SS_GetDITDependencyList(int nBlockId, int *pDepNumber, int *pDepList, V6ERRORINFO *pErrInfo);
void SCRIPTSERVICES_API LI_MarkFunctionAsModified(QString szFuncName, V6ERRORINFO *pErrInfo);
V6ERRORINFO SCRIPTSERVICES_API LI_IsFunctionLocked(QString szFuncName, BOOL *bValue);
/*Dummy exports */
DWORD SCRIPTSERVICES_API SS_GetFileContents(QString szFileName, char *szFileContents);
void SCRIPTSERVICES_API SS_DataStore(int nId, CExecutionContext *pCtx, V6ERRORINFO *pErrInfo);
/********************************************* Internal Funcs *********************************************************/
int AssignBlockId();
void PrepareOfflineState();
void SetPersistVariable(void *pPV, int nMemSize, V6ERRORINFO *pErrInfo);
void ReleasePersistVariable();
V6ERRORINFO IsFunctionLockedBySB(char *szFuncName, BOOL *bValue);
/* Changed to void since no return values are been used */
void ClearSafeArray(SAFEARRAY **ppFunctionList);
void CopyMaptToSafeArray(SAFEARRAY **ppFuncList, MAPSTR *mapFuncList);
void LoadLexYaccTables();
void UnLoadLexYaccTables();
void ClearScriptFunctionLibrary();
/********************************************* Unused Funcs *********************************************************/
V6ERRORINFO IsFunctionLockedBySB(char *szFuncName, BOOL *bValue);
V6ERRORINFO IsFunctionLockedBySF(char *szFuncName, BOOL *bValue);
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_SCRIPTSERVICES_H__538F2746_F3A8_4183_85F3_8693F22C2190__INCLUDED_)

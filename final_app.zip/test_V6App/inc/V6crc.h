//************************************************************************************
// Module  CRC
// Filename  V6crc.h
/// **************************************************************************
/// @n Module: 		CRC Routines
/// @n Filename:	V6crc.h
/// @n Description: Declaration of the CRC Routines. 
///				The CRC-CCITT DIRECT LOOKUP TABLE method has been 
///				used for CRC calculations 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.3.1.1	7/2/2011 5:02:41 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.3.1.0	7/1/2011 4:26:55 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	V6 Firmware 1.3		5/5/2005 3:16:58 PM	Alistair Brugsch
//		Added additional comments to clarify code, together with making sure
//		const is used whether possible, and all magic numbers are removed. 
// 3	V6 Firmware 1.2		9/16/2004 7:52:57 PM	Alistair Brugsch
//		Rewrote the CRC routines for efficiency and to work correctly
//		according to the CRC-CCITT algorithm
// $
//
// ***************************************************************************
#ifndef _V6CRC_H
#define _V6CRC_H
/// Enumeration for whether the CRC test undertaken have passed or failed
typedef enum _eCrcTestResult {
	CRC_TEST_FAILED, CRC_TEST_PASSED
} T_CRC_TEST_RESULT;
/// Enumeration to identify the Endian Type of the Processor 
typedef enum _eCrcTestEndianResult {
	CRC_BIG_ENDIAN,		// Motorala
	CRC_LITTLE_ENDIAN	// Intel
} T_CRC_ENDIAN_TEST_RESULT;
#define CRC_ONE_BYTE_IN_BITS 8 ///< Represent the number of bits to one byte
#define CRC_ONE_BYTE		1 ///< One Byte
#define CRC_TWO_BYTES		2 ///< Two Bytes
/// CRC-CCITT INFORMATION
//
#define CRC_CCITT_POLYNOMIAL		0x1021 ///< CRC Polynomial Used for Lookup Table Generation 
#define CRC_CCITT_INITIAL_VALUE	0xFFFF ///< Initial value for CRC on the first block of data
#define CRC_CCITT_FINAL_XOR_VALUE 0x0000 ///< XOR with the final calculation to produce the CRC
#define CRC_SELF_TEST_VALUE		0x4560 ///< Checksum for Validating Self Test 
#define CRC_CCITT_TABLE_ARRAY_ELEMENT_SIZE 256	///< Number of Elements required for the CCITT Lookup Table
#define CRC_ZERO							0	///< Represents the value of ZERO
#define CRC_BYTE_MAX_VALUE				0xFF ///< Max Size of a Byte( 255 )
#define CRC_SELF_TEST_NUM_OF_BYTES		5	///< Number of bytes for CRC Self Test
#define CRC_ASCII_ONE_IN_HEX	0x31 ///< ASCII Character 1
#define CRC_ASCII_TWO_IN_HEX	0x32 ///< ASCII Character 2
#define CRC_ASCII_THREE_IN_HEX 0x33 ///< ASCII Character 3
#define CRC_ASCII_FOUR_IN_HEX 0x34 ///< ASCII Character 4
#define CRC_ASCII_FIVE_IN_HEX 0x35 ///< ASCII Character 5 
#define CRC_ENDIAN_TEST_WORD	0x4321 ///< Endian Test Data
#define CRC_ENDIAN_TEST_LOW_BYTE 0x21 ///< Low Byte of the Endian Test Data				
#ifdef __cplusplus // CPLUSPLUS
extern "C" {
#endif
/// Calculate CRC value using an existing CRC
unsigned short CrcRecalc(unsigned char *pDataBlock, const unsigned long length, const unsigned short crc);
/// Calculate CRC value
unsigned short CrcCalc(unsigned char *pDataBlock, const unsigned long length);
/// Test whether the data block is valid or corrupted
T_CRC_TEST_RESULT CrcTest(unsigned char *pDataBlock, const unsigned long length);
/// Test the CRC Value calculated with a previously calculated CRC Value
T_CRC_TEST_RESULT CrcTestCRCValue(const unsigned short calculatedCRC, const unsigned short crc);
/// Calculate CRC and Append to the end of a given data block
unsigned short CrcInsert(unsigned char *pDataBlock, const unsigned long length);
/// Determine if CRC is being calculated correctly, on a given target
T_CRC_TEST_RESULT CrcSelfTest(void);
/// Determine which endian the processor is using. 
T_CRC_ENDIAN_TEST_RESULT CrcEndianTest(void);
#ifdef __cplusplus //CPLUSPLUS
}
#endif
#endif // _V6CRC_H

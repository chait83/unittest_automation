#if !defined(AFX_TOKEN_H_738362C0_B16F_4963_A9BA_BA8928E78E4D__INCLUDED_)
#define AFX_TOKEN_H_738362C0_B16F_4963_A9BA_BA8928E78E4D__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//#include "passsyncengine.h"
#include "V7DbgLogDefines.h"
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	#include "CStorage.h"
#endif
#include <list>
typedef enum token_state {
	TOK_ERR, TOKEN_REQD, TOKEN_OWNED, TOKEN_RETD, TOKEN_REQ_TIMEOUT, TOKEN_RESET, TOKEN_CONN_UNAVAIL
} TOKEN_STATE;
#include <QMutex>
#include "TV6Timer.h"
#include "Defines.h"
const USHORT MAX_TOK_Q_LENGTH = 5;
class CToken {
public:
	CToken(void);
	virtual ~CToken(void);
private:
	BOOL m_bMaster;
    static QMutex m_cs;
	volatile BOOL m_bHaveToken;
	ULONG m_ulTokenHolder;
	ULONG m_ulOurID;
	//how many interactions in progress require the token
	short m_usTokenReqCount; //signed to detect wrapping
	USHORT m_usNextID; //can wrap
	std::list<ULONG> m_TokenReqAddrList; //queue of requesting peers
	std::list<USHORT> m_TokenReqPidList; //queue of requesting transactions
	CTV6Timer m_tokenTimer; //Timer to maintain the lifetime of the token	
public:
	//we are Master funcs
	ULONG TransRequestToken(ULONG ID); //return bHaveToken
	ULONG TransFinishedWithToken(ULONG ID);
	//we are slave funcs
	TOKEN_STATE PeerRequestToken(USHORT *pID, DWORD dwWait = NULL);
	TOKEN_STATE PeerFinishedWithToken(USHORT ID);
	//for the engine to notify the token class
	void TokenArrived();
	//set master/slave/standalone
	void SetMaster(BOOL bMaster) {
		m_bMaster = bMaster;
		ForceTokenReset();
	}
	;
	void ForceTokenReset();
	void SetOurSerialID(ULONG ulSerial) {
		m_ulOurID = ulSerial;
	}
	;
	ULONG WhoHasToken() {
		return m_ulTokenHolder;
	}
	;
	void RefreshTimer(ULONG ulRequestor);
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
public:	
	void LogDebugMessage(QString  strDebugMessage);
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
#endif
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
private:
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif

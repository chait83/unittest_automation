/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Processing
/// @n Filename: TabularReadings.h
/// @n Description: Tabular Readings for Tabular display Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 5:01:59 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:50 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		9/23/2008 12:22:40 PM Build Machine 
// $
//
// **************************************************************************
#ifndef _TABULARREADINGS_H
#define _TABULARREADINGS_H
#include "Defines.h"
#include "V6defines.h"
#include "DataItemBase.h"
#include "DataItemPen.h"
#include <QMutex>
const long MAX_TABULAR_LINES = 20;
const long TABREAD_SIG = 0x94A2;
// Line structure, all the information for 1 line of readings for tabular data
typedef struct {
	LONGLONG time;						//< Time of tabular data line readings
	UCHAR status[V6_MAX_PENS / 2];						//< Status of readings (4 bits for each status)
	float readings[V6_MAX_PENS];				//< Pen readings for time
} T_TABULAR_LINE, *T_PTABULAR_LINE;
// Full page tabular data structure
typedef struct {
	long signature;
	long newestIndex;
	T_TABULAR_LINE data[MAX_TABULAR_LINES];
} T_TABULAR_DATA, *T_PTABULAR_DATA;
//**CTabularReadings ****************************************************
///
/// @brief Class that provides access to the tabular readings
/// 
/// Class that provides the tabular readings
///
//****************************************************************************
class CTabularReadings {
public:
	// Method that creates and initialises the singleton
	static CTabularReadings* Instance();
	// Destructor
	~CTabularReadings();
	// Method to initialise the tabular data instance
	const bool Initialise();
	// Configure tabular readings information, done on every config change and at start-up
	void Configure();
	// Method to reset the whole of the tabular data structure
	void ResetAllTabularData();
	// Method to Add readings to the tabular data structure
	void AddReadings();
	// Set the status of the readings into the status NV, this is arranged in nibbles to save space
	void SetStatus(int penNumber, T_DATAITEM_STATUS status, int dataIndex);
	// Get the status of the reading from NV data structure
	T_DATAITEM_STATUS GetStatus(int penNumber, int dataIndex);
	// Flag that an event has fired requesting a new line of tabbed data, set flag to indicate for use on next cycle
	void SetNewDataFromEventTrigger() {
		m_eventTriggerFired = TRUE;
	}
	;
	// User API
	// Critical section for updates adn access - enter critical section
	void lockForUpdates() {
		m_kCritSection.lock();
	}
	;
	void allowUpdates() {
		m_kCritSection.lock();
	}
	;
	// Method that sets the internal index to reference the newest available set of readings
	const bool SetToNewestReadings();
	// Method that sets the internal index to the next oldest set of readings
	const bool SetToNextReadings();
	// Method that obtains the current time for the currently selected set of readings
	const QString GetCurrentReadingLogTime();
	// Method that obtains the stored pen reading from the currently selected set of readings
	const float GetCurrentReadingPenValue(const USHORT usINSTANCE_NO);
	// Method that obtains the stored pen status from the currently selected set of readings
	const T_DATAITEM_STATUS GetCurrentReadingPenStatus(const USHORT usINSTANCE_NO);
	BOOL IsUpdateRequired() {
		return m_UpdateRequired;
	}
	;
	void SetUpdateRequired(BOOL updateReq) {
		m_UpdateRequired = updateReq;
	}
	;
private:
	int m_CurrentIndex;	//< Current Index of readings (used for extracting readings)
	int m_ulLatestIndex;		//< LatestIndex, the newest index available
	/// Critical section used when obtaining strings and data that can't be obtained in a single instruction
	QMutex m_kCritSection;
	// Singleton auto pointer
	static std::unique_ptr<CTabularReadings> ms_kTabularReadings;
	// Constructor
	CTabularReadings();
	// Handle to the creation mutex
	static QMutex ms_hCreationMutex;
	CDataItemPen *m_pPenDataItem[V6_MAX_PENS];
	T_PTABULAR_DATA m_pNVTabularData;		//< Pointer to the tabualr data held in SRAM
	BOOL m_eventTriggerFired;	//< TRUE if a tabular reading event triggered creating a new line of readings immediatly
	BOOL m_FirstIn;
	LONGLONG m_countDown;//< Countdown to next trigger time, in units of process interval in systimer GetCurrentProcessInterval()
	LONGLONG m_reloadCountdown;				//< Countdown reload timer.
	T_PTABULARDISPLAY m_pTDConfig;			//< Tabular display configuration
	BOOL m_UpdateRequired;			//< Inidcate a new line has been added and an update is required by the OpPanel
};
#endif //_TABULARREADINGS_H

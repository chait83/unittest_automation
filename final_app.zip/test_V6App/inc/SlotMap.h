/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n ConfigManager.h
/// @n interface for the I/O Card slot and channel mapping
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 25	Stability Project 1.22.1.1	7/2/2011 5:01:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 24	Stability Project 1.22.1.0	7/1/2011 4:27:12 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 23	V6 Firmware 1.22		7/31/2006 1:42:34 PM	Graham Waterfield
//		Added ezTrend mods and input GCA damping. Some work done on
//		linearisation tables (but parked until setup UI done)
// 22	V6 Firmware 1.21		2/23/2006 6:13:55 PM	Graham Waterfield
//		Bug fix to prevent H/W diagnostics from being displayed when relevant
//		H/W is not fitted.
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_SLOTMAP_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)
#define AFX_SLOTMAP_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "PassiveModule.h"
#include "V6defines.h"
#include <QMutex>
#define SMAP_ILLEGAL_INDEX 0xff
//**Class*********************************************************************
///
/// @brief Manage access to I/O boards, channels and pre-process queue conversion
/// 
/// This class is a generic class that manages the mapping to and from boards,
/// board channels, system channels and pre-process queues.
///
/// This class is implemented as a singleton and passive module
///
//****************************************************************************
class CSlotMap: public CPassiveModule {
public:		//Singleton 
	static CSlotMap* GetHandle();
	void CleanUp();
	// Get info on a slot
	UCHAR GetIOSlotMaxChannels(const USHORT cardNo) const;
	BOOL IsCardInTopSlot(const USHORT cardNo) const;
	// Get slot numbers from a system channel number
	UCHAR GetDigitalChannelSlotNo(const USHORT IOChannel, const T_PENBASE base) const;
	UCHAR GetPulseInChannelSlotNo(const USHORT PulseChannel, const T_PENBASE base) const;
	UCHAR GetDedicatedPulseInChannelSlotNo(const USHORT PulseChannel, const T_PENBASE) const;
	UCHAR GetAnaOutChannelSlotNo(const USHORT AnaChannel, const T_PENBASE base) const;
	UCHAR GetAnaInChannelSlotNo(const USHORT AnaChannel, const T_PENBASE base) const;
	// Get the starting channel number of any given slot
	// Gets the I/O board channel from system channel number
	UCHAR GetBoardChannelFromAnaInChannel(const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetBoardChannelFromAnaOutChannel(const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetBoardChannelFromDigitalChannel(const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetBoardChannelFromDedicatedPulseInChannel(const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetBoardChannelFromPulseInChannel(const USHORT Channel, const T_PENBASE base) const;
	// Gets the I/O board slot and board channel from system channel number
	BOOL GetSlotAndChannelFromAnalSysChan(const USHORT sysChannelNo, USHORT *pSlotNo, USHORT *pChanNo,
			const T_PENBASE base) const;
	BOOL GetSlotAndChannelFromDigitalSysChan(const USHORT sysChannelNo, USHORT &rSlotNo, USHORT &rChanNo,
			const T_PENBASE base) const;
	BOOL GetSlotAndChannelFromDedicatedPulseSysChan(const USHORT sysChannelNo, USHORT &rSlotNo, USHORT &rChanNo,
			const T_PENBASE base) const;
	BOOL GetSlotAndChannelFromPulseSysChan(const USHORT sysChannelNo, USHORT &rSlotNo, USHORT &rChanNo,
			const T_PENBASE base) const;
	BOOL GetSlotAndChannelFromAnaOutSysChan(const USHORT sysChannelNo, USHORT *pSlotNo, USHORT *pChanNo,
			const T_PENBASE base) const;
	// Get the system channel number for a given board type, slot number and channel number
	UCHAR GetSysChannelFromAnaOutChannel(const USHORT SlotNo, const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetSysChannelFromAnaInChannel(const USHORT SlotNo, const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetSysChannelFromDedicatedPulseChannel(const USHORT SlotNo, const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetSysChannelFromDigIOPulseChannel(const USHORT SlotNo, const USHORT Channel, const T_PENBASE base) const;
	UCHAR GetSysChannelFromDigIOChannel(const USHORT SlotNo, const USHORT Channel, const T_PENBASE base) const;
	// Convert to and from pre-process queues and card/channel numbers
	BOOL GetDigitalPreProcessQueueFromDigitalBoard(const USHORT SlotNo, USHORT *pQueueNo) const;
	BOOL GetPreProcessQueueFromBoardChannel(const USHORT SlotNo, const USHORT Channel, USHORT *pQueueNo) const;
	BOOL GetBoardChannelFromPreProcessQueue(const USHORT QueueNo, USHORT *pSlotNo, USHORT *pChannel) const;
	BOOL GetSysChannelFromPreProcessQueue(const USHORT QueueNo, USHORT *pSysChannel) const;
	USHORT GetBottomSlotChannelSelectedType(const USHORT sysChanNumber, const T_PENBASE base) const;
	USHORT GetChannelSelectedType(const USHORT slotNumber, const USHORT chanNumber) const;
	USHORT GetHWChannelSelectedType(const USHORT slotNumber, const USHORT chanNumber) const;
	// Convert to/from Data item table references
	BOOL ObtainBoardsDICJCRef(const USHORT cardSlot, USHORT *pCJCDIRef, USHORT *pCJCDegCDIRef) const;
	// Summarise what board types are available in the recorder
	const BOOL AICardsAvailable() const;
	const BOOL AOCardsAvailable() const;
	const BOOL DIOCardsAvailable() const;
	const BOOL RelayCardsAvailable() const;
	const BOOL PulseCardsAvailable() const;
	const BOOL IsBoardIOTypeLegal(const USHORT boardType) const;
	void GetSlotStrID(const USHORT Slot, WCHAR *IDText) const;
	void GetIOCardStrID(const UCHAR boardType, QString *pIDText) const;
private:	// Singleton
	CSlotMap();
	CSlotMap(const CSlotMap&);
	CSlotMap& operator=(const CSlotMap&) {
		return *this;
	}
	;
	~CSlotMap();
	USHORT m_LastTopSlotQueue;				///< Last top-slot queue
	USHORT m_LastBottomSlotPulseQueue;		///< Last bottom-slot pulse queue
	USHORT m_LastQueue;						///< Last Pre-process queue
	// Singleton handlers
	static CSlotMap *m_pInstance;
	static QMutex m_CreationMutex;
};
#endif // !defined(AFX_SLOTMAP_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)

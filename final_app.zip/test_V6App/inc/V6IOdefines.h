/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// @n Module: V6 
/// @n Filename: V6IOdefines.h
/// @n Description: Header with defines for V6
///
// *******************************************
// Revision History
// *******************************************
// $Log[4$
//
// *******************************************
/********************************************************************
 *
 *	V6IODefines.h		(C) Honeywell 2003
 *
 *  Header with defines for V6
 *
 *	Ver 1.0 12.11.03	GKW	Created
 *
 *
 ********************************************************************/
#ifndef V6IODEFINES_H
#define V6IODEFINES_H
#ifndef FALSE
#define FALSE		0
#endif
#ifndef TRUE
#define TRUE		1
#endif
#ifndef BOOLEAN
#define BOOLEAN	UCHAR			 	///< TRUE/FALSE
#endif
#ifndef BOOL
#define BOOL BOOLEAN				 	///< TRUE/FALSE
#endif
#ifndef WCHAR
#define WCHAR USHORT  		///< 16-bit UNICODE character
#endif
/****************************************************************************
 *
 *  typedefs used by CodeWarrior beans, repeated here for convenience
 *
 *****************************************************************************/
typedef unsigned char byte;
typedef unsigned int word;
typedef unsigned long dword;
typedef unsigned long dlong[2];
#endif // ndef V6DEFINES_H		
// -------------------- end of V6IODefines.h ---------------------

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOCardInfo.h
/// @n interface of the IOCardStats class.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 22	Stability Project 1.19.1.1	7/2/2011 4:58:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 21	Stability Project 1.19.1.0	7/1/2011 4:27:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 20	V6 Firmware 1.19		2/21/2006 8:34:05 PM	Graham Waterfield
//		Save the general stats downloaded from I/O card
// 19	V6 Firmware 1.18		1/26/2006 5:16:51 PM	Graham Waterfield
//		Add capability to store base range
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _CARDINFO_H
#define _CARDINFO_H
#include "AIRanges.h"
#define MAX_IOBOARDCHANS			16
#define BOARD_REVISION_STR_LEN		3
typedef struct _chanInfo {
	UCHAR ChanCap;					///< The channels capability
	UCHAR ChanSet;					///< The channel type currently set
	T_AIRANGE BaseRangeInfo;		///< The base range selection
} T_CHANINFO, *T_PCHANINFO;
typedef struct _overallBoardInfo {
	float CJCReading;	///< Board old AI card or average CJC reading in deg C
	float CJCReadings[CAIRanges::MAX_CJCS]; ///< Board CJC reading in deg C
	ULONG queueRollover;			///< Main data queue timebase rollover
	ULONG buildNo;				///< Firmware release build number
	ULONG rootBuildNo;				///< App Firmware release build number
	T_CHANINFO chan[MAX_IOBOARDCHANS];		///< Board channels
	UCHAR CardNo;					///< Unique card ID number
	UCHAR CardType;					///< The type of board identified
	UCHAR Channels;					///< Number of channels board supports
	UCHAR BoardRev;				///< The boards revision number
	UCHAR RangeRev;	///< The I/O boards range number obtained from the revision number
	UCHAR FirmwareRev[BOARD_REVISION_STR_LEN];	///< The boards firmware revision number
	USHORT BoardTBRef;				///< The boards current timebase reference
	USHORT IOTicks;					///< The boards last read I/O tick count
	USHORT BdConfigCRC;				///< The boards configuration CRC
	USHORT CalcConfigCRC;			///< The boards calculated configuration CRC
	/// The boards ID (serial number) is made up from first test data (data & rig)
	ULONG DateFirstTested;		///< Date first tested
	UCHAR FirstTestRig;			///< Rig number that the board first tested on
	ULONG DateLastTested;			///< Date of last tested
	UCHAR LastTestRig;			///< Rig number that board was last tested on
	UCHAR CurrentTestRig;			///< Test Rig number that board is currently being tested on
	UCHAR LastTestStatus;			///< Last test status
	UCHAR queueGearing;			///< Main data queue timebase gearing ratio
	BOOL infoUploaded;	///< Has the board info been uploaded from the I/O card
} T_OVERALLBOARDINFO, *T_POVERALLBOARDINFO;
#endif

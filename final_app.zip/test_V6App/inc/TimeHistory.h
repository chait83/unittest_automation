/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Time History
/// @n Filename: TimeHistory.h
/// @n Description: Time history table
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 8	Stability Project 1.5.1.1	7/2/2011 5:02:06 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 7	Stability Project 1.5.1.0	7/1/2011 4:27:42 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 6	V6 Firmware 1.5		3/24/2006 4:49:21 PM	Andy Kassell	Set
//		a 4 byte aligned , not default
// 5	V6 Firmware 1.4		3/23/2006 8:22:05 PM	Andy Kassell 
//		Remove 1 bytre alignment and replace with default alignment.
// $
//
// **************************************************************************
#ifndef _TIMEHISTORY_H
#define _TIMEHISTORY_H
#include "TVtime.h"
#include "CStorage.h"
#include <QTime>
#include <QMutex>
#define TIME_HISTORY_FILENAME			"THistory.tbl"
#define TIME_HISTORY_FILENAME_TEMP		"THisTEMP.tbl"
#define TIME_HISTORY_FILENAME_OLD		"THisOLD.tbl"
#define TABLE_SIZE 256					
#define DELETE_ENTRIES_AMOUNT 256		// ideally a multiple of the table size
#define MAX_FILE_ENTRIES 5120		// ideally a multiple of the table size			
#define FLAG_STARTUP 0x01
#define LATEST_ENTRY 549755813888L	// end of time - 2^39 174 years from 'born on' date
// set 4 byte alignment here
#pragma pack(push, prevpack, 4)
typedef struct TEntry {
	LONGLONG Tick100;
	CTVtime ActualTime;
	UCHAR Flags;
	UCHAR spare;
} TableEntry;
typedef struct TDetailedTimeEntry {
	LONGLONG StartTick100;	// The tick time at which the table entry applies to
	LONGLONG EndTick100;	// The end time of the table entry, this might be 0 in which 
							// case this will be the latest entry and the span/end time is unknown
	CTVtime ActualTime;						// The actual clock time to which the start tick value equates
} DetailedTimeEntry;
// Put back the original packing from the stack				
#pragma pack(pop, prevpack)
class IDirectory_t;
class IFile_t;
template<class T> class IntrusivePtr_t;
class Status_t {
};
//******************************************************
// CTimeHistory
///
/// @brief Maintains the Time History file and table
///		the table is a 'Window' onto the file, and 
///		will update its current position based on the
///		requests for entries.
//******************************************************
class CTimeHistory {
private:
	static CTimeHistory *m_pTimeHistory; ///< static pointer to single instance of class
	virtual Status_t GetPath(WCHAR directoryPath_) const;
	virtual Status_t GetNextDirectory(IntrusivePtr_t<IDirectory_t> &directory);
	virtual Status_t GetNextFile(IntrusivePtr_t<IFile_t> &file);
	virtual Status_t GetDirectory(const WCHAR name, IntrusivePtr_t<IDirectory_t> &result);
	virtual Status_t GetFile(const WCHAR name, IntrusivePtr_t<IFile_t> &result);
	virtual Status_t CreateDirectory(const QString name, IntrusivePtr_t<IDirectory_t> &result);
	virtual Status_t CreateFile(const WCHAR name, IntrusivePtr_t<IFile_t> &file);
	virtual Status_t DeleteDirectory(const WCHAR name);
	virtual Status_t DeleteFile(const WCHAR name);
	QString m_filePathAndFileName;
	CStorage m_Storage;
	static QMutex m_CritSection; ///< critical section for access
	int m_TopOfTableEntry;			///< Entry number of first entry in table
	int m_NumFileEntries;			///< Total number of entries in file
	int m_NumTableEntries;	///< number of entries present in the 'windowing' table (use index 0 to m_NumTableEntries-1)
	TableEntry m_Table[TABLE_SIZE]; ///< The table
	TableEntry m_LatestEntry; ///< Copy of the very latest (last) entry in the file
	TableEntry m_StartupEntry;		///< Copy of the most recent startup entry
	// New time entry related variables
	DetailedTimeEntry *m_TimeDetailsTable;		// A table containing all the detailed time enteries - this
												// will be a circular buffer
	int m_LatestDetailedTimeEntryIndex;	// The index of the latest time entry in the table above
	// private construction / destruction
	CTimeHistory();
	~CTimeHistory();
	CTimeHistory(const CTimeHistory&);
	CTimeHistory& operator=(const CTimeHistory&) {
		return *this;
	}
	BOOL InitTable();
	BOOL ReadTableWindow();
	// Reads a section of the file into the passed in buffer/table
	static const int ReadTableFile(TableEntry *tableToPopulate, int maxNoOfTableEntries, const int seekPosition,
			const int readBytes, CStorage &tableFile, const QString &tableFilename);
	int DeleteOldEntries();
	void Dump();
	// Methods related to getting the new detailed time entries
	const BOOL InitTimeDetailsTable();
	// Adds a time entry to the detailed time table
	void AddEntryToDetailedTime(const TableEntry &latestTimeEntry);
	// Method used to copy common table entry information into a detailed table entry
	static void CopyTimeEntryToDetailed(DetailedTimeEntry &detailedTimeEntryToPopulate,
			const TableEntry &timeEntryToCopy);
	// Method used to copy detailed table entry information from one struct to another
	void CopyTimeEntryDetails(DetailedTimeEntry &timeEntryToPopulate, const DetailedTimeEntry &timeEntryToCopy);
	// Helper method used to get the next oldest time details entry index
	const int GetNextOldestTimeDetailsEntryIndex(const int currentIndex) const;
	// Helper method used to get the next avaiable time details entry index - this would usually be 
	// so we can recycle the index and basically overwrite it with the latest time entry
	const int GetNextFreeTimeDetailsEntryIndex();
public:
	//Singleton 
	static CTimeHistory* GetHandle(); // acquire a copy of the pointer to the single instance
	void CleanUp();
	//	Check the table entry file is valid, creating it should it be too old, not exist
	// or have been affected by an unexpected reboot
	const BOOL ValidateTableEntryFile();
	void ResetHistory();
	void AddEntry(LONGLONG OnGoingTick100, CTVtime ActualTime, BOOL IsStartup =
	FALSE);
	// Methods for getting the old strip chart related entries
	TableEntry* GetEntry(LONGLONG OnGoingTick100);
	TableEntry* GetStartupEntry();
	// Methods for getting the new detailed time entries
	// Get an entry from history table/file based on time/date
	const DetailedTimeEntry GetDetailedTimeEntry(CTVtime targetTime);
};
#endif

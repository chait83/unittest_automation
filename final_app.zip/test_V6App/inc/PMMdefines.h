/// @file CPolicyDataManager.h
/// ***************************************************************************************
/// © Honeywell Trendview
/// ****************************************************************************************
/// @n Module	:	Password Management Module.
/// @n Filename	:	Defines.h
/// @n Desc		:	
///
// ****************************************************************************************
// Revision History
// ****************************************************************************************
// $Log[1]:
// 8	Stability Project 1.5.1.1	7/2/2011 4:59:43 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// $Log" from the functions
// $
//
// ****************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#include "TraceDefines.h"
#ifndef __PMM_DEFINES__
#define __PMM_DEFINES__
/************************ Macros For the Traces ********************************/
/*
 typedef void (*fnTraceStart)(TCHAR *pszPathName );
 typedef void (*fnTrace)(const TCHAR *pszasprintf, ...);
 typedef void (*fnTraceStop)();
 */
/*
 #ifdef qDebugR_ENABLE
 //Tracer On
 //information log
 #ifdef INFO_TRACE_ENABLE
 //information log enabled
 #define LOG_INFO(x,y) if(x) y;
 #else
 //information log disabled
 #define LOG_INFO(x,y) 
 #endif
 //error log
 #ifdef ERROR_TRACE_ENABLE
 //error log enabled
 #define LOG_ERROR(x,y) if(x) y;
 #else
 //error log disabled
 #define LOG_ERROR(x,y) 
 #endif
 //warning log
 #ifdef WARNING_TRACE_ENABLE
 //warning log enabled
 #define LOG_WARNING(x,y) if(x) y;
 #else
 //warning log disabled
 #define LOG_WARNING(x,y) 
 #endif
 #else
 //Tracer Off
 #define LOG_INFO(x,y) 
 #define LOG_ERROR(x,y) 
 #define LOG_WARNING(x,y) 
 #endif
 */
/************* End of Macros for tracer ************************/
#define PMM_qDebugR_MODE TRACE_PMM+TRACE_2_FILE
#define LOG_ERROR	LOG_ERR
/// For the compatibility between the desktop and the WindowsCE
#ifdef UNDER_CE
	#define GETPROCADDRESSSTRING(x) QString  (x)
#else
#define GETPROCADDRESSSTRING(x) x 
#endif
/// ********** Group Defination *********************
# define	ADMINISTRATOR							0
# define	SUPERVISOR								1
# define	ENGINEER								2
# define	TECHNICIAN								3
# define	OPERATOR								4
/// *********** General Defines *********************
# define	GET_POINTERS							0
# define	CHECK_POLICY							1
# define	GET_NVRAM_HANDLE						2
# define	RESET_NVRAM_PMM_CONFIG					3
#define		ZERO									0
#define		OPERATOR_LEVEL							4
# define	MAX_USERS								50
# define	ONESLOT									1
# define	PERM_MASK_SIZE							4
# define	GROUP_OFFSET							1000
# define	USED									1
# define	GET_SLOT_DETAILS						1
# define	BITS_IN_DWORD							32
# define	MAX_AREA								128
/// Constants for the CFR and NonCFR conditions to be checked.
# define 	CHECK_PREVIOUS_PASSWORD					0
# define	CHECK_MAXIMUM_PASSWORD_LENGTH			1
# define 	CHECK_MINIMUM_PASSWORD_LENGTH			2
# define 	CHECK_PASSWORD_NUMERIC					3
# define 	CHECK_PASSWORD_ALPHA					4
# define 	CHECK_PASSWORD_SPLALPHA					5
# define 	CHECK_MAXIMUM_USERNAME_LENGTH			6
# define 	CHECK_MINIMUM_USERNAME_LENGTH			7
# define	SUPERVISOR_PERM							1001
# define	ENGINEER_PERM							1002
# define	TECHNICIAN_PERM							1003
# define	OPERATOR_PERM							1004	
# define	UNRESTRICTED_PERM						1005
# define	GET_USER_DATA_POINTER_WORKING			0
# define	GET_USER_DATA_POINTER_CURRENT			1
# define	GET_POLICY_DATA_POINTER_WORKING			2
# define	GET_POLICY_DATA_POINTER_CURRENT			3
# define	UI_LOGOFF_TIME							0
# define	EXPIRY_DAYS								1
# define	EXPIRY_WARNING							2
# define	MAXIMUM_RETRY							3
# define	MINIMUM_PREVIOUS_PASSWORD				4
# define	MINIMUM_PASSWORD_ALPHA					5
# define	MIMIMUM_PASSWORD_NUMERICS				6
# define	MINIMUM_PASSWORD_LENGTH 				7
# define	MAXIMUM_PASSWORD_LENGTH 				8
# define	MINIMUM_SPECIAL_CHARACTER				9
# define	MAXIMUM_USER_NAME_LENGTH				10
# define	MINIMUM_USER_NAME_LENGTH				11
# define	WEB_LOGOFF_TIME							12	
# define	MAX_USERNAME_PASSWORD_WARNING_CHECK		13
#define		CHECK_GROUP_NAMES_ARRAY_CHECK			14
# define	CHECK_PASSWORD_LENGTH					15
/*****************CFR Constants***********************/
# define	CFRMAX_UI_LOGOFF_TIME					3600
# define	CFRMIN_UI_LOGOFF_TIME					20
# define	CFRMAX_WEB_LOGOFF_TIME					3600
# define	CFRMIN_WEB_LOGOFF_TIME					20
# define	CFRMAX_EXPIRY_DAYS						180
# define	CFRMIN_EXPIRY_DAYS						1
# define	CFRMAX_EXPIRY_WARNING					20
# define	CFRMIN_EXPIRY_WARNING					1
# define	CFRMAX_RETRY							6
# define	CFRMIN_RETRY							1
# define	CFRMAX_PREVIOUS_PASSWORD				12 //Max 12
# define	CFRMIN_PREVIOUS_PASSWORD				1
# define	CFR_MAX_MAXPASSWORD_LENGTH				20
# define	CFR_MIN_MAXPASSWORD_LENGTH				0
# define	CFR_MAX_MINPASSWORD_LENGTH				20
# define	CFR_MIN_MINPASSWORD_LENGTH				6
# define	CFRMAX_PASSWORD_ALPHA					20
# define	CFRMIN_PASSWORD_ALPHA					0
# define	CFR_MAX_PASSWORD_NUMERICS				20	
# define	CFR_MIN_PASSWORD_NUMERICS				0	
# define	CFR_MAX_SPECIAL_CHARACTER				20
# define	CFR_MIN_SPECIAL_CHARACTER				0
# define	CFR_MAX_MAXUSER_NAME_LENGTH				20
# define	CFR_MIN_MAXUSER_NAME_LENGTH				0
# define	CFR_MAX_MINUSER_NAME_LENGTH				20
# define	CFR_MIN_MINUSER_NAME_LENGTH				4
/*****************NONCFR Constants*******************/
# define	NONCFR_MAX_UI_LOGOFF_TIME				3600
# define	NONCFR_MIN_UI_LOGOFF_TIME				20
# define	NONCFR_MAX_WEB_LOGOFF_TIME				3600
# define	NONCFR_MIN_WEB_LOGOFF_TIME				20
# define	NONCFR_MAX_EXPIRY_DAYS					365
# define	NONCFR_MIN_EXPIRY_DAYS					0
# define	NONCFR_MAX_EXPIRY_WARNING				20
# define	NONCFR_MIN_EXPIRY_WARNING				0
# define	NONCFR_MAX_RETRY						10 //Max 10
# define	NONCFR_MIN_RETRY						0	
# define	NONCFR_MAX_PREVIOUS_PASSWORD			12 //Max 12
# define	NONCFR_MIN_PREVIOUS_PASSWORD			0
# define	NONCFR_MAX_PASSWORD_ALPHA				20
# define	NONCFR_MIN_PASSWORD_ALPHA				0
# define	NONCFR_MAX_MAXPASSWORD_LENGTH			20
# define	NONCFR_MIN_MAXPASSWORD_LENGTH			0
# define	NONCFR_MAX_MINPASSWORD_LENGTH			20
# define	NONCFR_MIN_MINPASSWORD_LENGTH			1
# define	NONCFR_MAX_PASSWORD_NUMERICS			20	
# define	NONCFR_MIN_PASSWORD_NUMERICS			0	
# define	NONCFR_MAX_SPECIAL_CHARACTER			20
# define	NONCFR_MIN_SPECIAL_CHARACTER			0
# define	NONCFR_MAX_MAXUSER_NAME_LENGTH			20
# define	NONCFR_MIN_MAXUSER_NAME_LENGTH			0
# define	NONCFR_MAX_MINUSER_NAME_LENGTH			20
# define	NONCFR_MIN_MINUSER_NAME_LENGTH			1
# define	DAYS_IN_MILLI_SEC						(86400000000)	//(24*60*60*1000*1000)
# define	BACKDOOR_USER							MAX_USERS + 1
# define	FIRSTTIME_USER							MAX_USERS + 2
# define	STARTTIME_HOURS							0
# define	STARTTIME_MINUITES						1
# define	ENDTIME_HOURS							2
# define	ENDTIME_MINUITES						3
/* CFR Mode */
#define CFRMODE										1
#define FTPACCESS									1
#define CFR_UI_LOGOFF_TIME							3600
#define CFR_WEB_LOGOFF_TIME							3600
#define CFR_EXPIRY_DAYS								180
#define CFR_EXPIRY_WARNING							20
#define CFR_MAX_RETRY								3
#define CFR_PREV_PWD								6
#define CFR_MIN_ALPHA								0
#define CFR_MAX_LENGTH								20
#define CFR_MIN_NUMBER								0
#define CFR_MIN_LENGTH								6
#define CFR_MIN_NONALPHA							0													
#define USER_MAX_LEN								20
#define USER_MIN_LENGTH								4
/* Non- CFR mode */
#define NONCFRMODE									0
#define NONCFR_UI_LOGOFF_TIME						0
#define NONCFR_WEB_LOGOFF_TIME						0
#define NONCFR_EXPIRY_DAYS							0
#define NONCFR_EXPIRY_WARNING						0
#define NONCFR_RETRY								0
#define NONCFR_PREV_PWD								0
#define NONCFR_MIN_ALPHA							0
#define NONCFR_MAX_LENGTH							20
#define NONCFR_MIN_NUMBER							0
#define NONCFR_MIN_LENGTH							1
#define NONCFR_MIN_NONALPHA							0
#define NONCFR_USER_MAX_LEN							20
#define NONCFR_USER_MIN_LENGTH						1
/***************** Validate the Username against The Below conditions *****************/
#define VALIDATE_USERNAME							0
#define VALIDATE_PASSWORD							1
#define VALIDATE_DAY_MASK							2
#define VALIDATE_LOGIN_TIME							3	
#define VALIDATE_ACCESS_LEVEL						4
#define VALIDATE_PASSWORD_RETRY_COUNT				5
#define VALIDATE_EXPIRY_WARNING						6
#define VALIDATE_EXPIRY_TIME						7	
#define	CHECK_PASSWORD_USERNAME						2
#define	CHECK_USER_FOR_ADMIN						3
#define	CHECK_FOR_DUPLICATE_USER					4
#define	CHECK_USERNAME								5
#define	CHECK_USER_PASSWORD							6
#define CHECK_USER_LEVEL							7
#define	UPDATE_USER_DATA							8
#define	INITIALISE									9
#define CHECK_USERGROUP								10
/************* Special User Defination *******************/
#define FIRST_TIME_USER_ID							52
#define BACKDOOR_USER_ID							51
#endif

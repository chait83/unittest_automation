/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	General
/// @n Filename: SysTimer.h
/// @n Desc:	Routines to V6 specific system timing
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 38	Stability Project 1.35.1.1	7/2/2011 5:01:58 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 37	Stability Project 1.35.1.0	7/1/2011 4:27:22 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 36	V6 Firmware 1.35		3/28/2008 2:58:39 PM	Hemant(HAIL)	New
//		functions added for getting the information of DST/SDT (SNTP Issue)
// 35	V6 Firmware 1.34		3/28/2007 3:49:14 PM	Andy Kassell 
//		Cleanup and add accessors for the hour, day, weekday and month from
//		the process times
// $
//
// ****************************************************************
#include "TVtime.h"
#include "TV6Timer.h"
#include "PassiveModule.h"
#include "NVVariables.h"
#include "DataItemBase.h"
#include "TimeHistory.h"
#include "V6types.h"
#include "i2cbus.h"
#ifndef __SYSTIMER_H__
#define __SYSTIMER_H__
#define DBG_FILE_LOG_SYSTIMER_ENABLE 1
#ifdef DBG_FILE_LOG_SYSTIMER_ENABLE
#include "CStorage.h"
#endif
/// @note processing time slices are calculated in 1/100ths of a seconds but all internals
///	in this module are calculated in Microseconds 1/1,000,000ths of a second
#define CONVERT_100_TO_MICROS(a)	( a * 10000 )	///< convert processing ticks speed 1/100ths to MicroSeconds 1/1,000,000
#define CONVERT_MICROS_TO_100(a)	( a / 10000 )	///< convert MicroSends into processing ticks
#define CONVERT_100_TO_SEC(a)		( a / 100 )		///< convert processing ticks speed 1/100ths to Seconds
const LONGLONG TIMECHANGE_THRESHOLD_USEC = 5000000;	///< Number of micro seconds difference (+ve or -ve) for a large time change
const LONGLONG TIMECHANGE_THRESHOLD_1SEC_SYNC = 500000; //1000000;
const LONGLONG TIMESYNC_THRESHOLD_SEC = 2;
//---------------------------------------------------------------
// Registry entry for checking the value set for DST Auto flag 
//---------------------------------------------------------------
#define RK_CLOCK		TEXT("Software\\Microsoft\\Clock")
#define RV_INDST		TEXT("HomeDST") //are we in DST?
#define RV_AUTODST	TEXT("AutoDST") //do we auto-adjust DST?
#define RV_DSTUI		TEXT("ShowDSTUI") //do we show a message at dst change?
//**Class*********************************************************************
///
/// @brief V6 System Timer
/// 
/// Provide all the timing for the V6 Data Processing
///
//****************************************************************************
class CV6SystemTimer: public CPassiveModule {
public:
	static CV6SystemTimer* GetHandle();
	void CleanUp();
private:	// Singleton
	CV6SystemTimer();
	~CV6SystemTimer() {
	}
	;	// Will never be called
	CV6SystemTimer(const CV6SystemTimer&);
	CV6SystemTimer& operator=(const CV6SystemTimer&) {
		return *this;
	}
	;
	static CV6SystemTimer *m_pV6SystemTimerInstance;
	static QMutex m_CreationMutex;
	unsigned char bcd2bin(unsigned char val);
	BOOL ReadExternalRtcTime(SYSTEMTIME *lpst);
	BOOL I2CRead(HANDLE hContext, BYTE nRegAddr, VOID *pBuffer, UINT32 size);
	BOOL I2CTransfer(HANDLE hI2C, PI2C_TRANSFER_BLOCK pI2CTransferBlock);
	BOOL initRTC(HANDLE hI2C);
	BOOL I2CSetFrequency(HANDLE hI2C, DWORD dwFreq);
	BOOL I2CSetMasterMode(HANDLE hI2C);
	HANDLE I2COpenHandle(LPCWSTR lpDevName);
public:		// API
	void Initialise();
	// Data Processing Access only
	void SetAbsoluteProcessTimeSlice(LONGLONG absoluteTimeIn100);
	void UpdateToNextProcessingTimeSlice();
	void SetProcessInterval(ULONG timeIn100);
	void UpdateProcessTimeSlice(LONGLONG timeIn100);
	//---------------------------------------------------------------
	// General API
	//---------------------------------------------------------------
	const long TimeSlicesBetweenProcAndRealtime100();
	const int GetLastTimeOffInSeconds() {
		return m_LastTimeOffInSeconds;
	}
	;
	ULONG GetLithiumLifeInSeconds() {
		return m_LithiumLifeInSeconds.ul;
	}
	;
	ULONG GetOffTimeInSeconds() {
		return m_OffTimeInSeconds.ul;
	}
	;
	ULONG GetLongestTimeOffInSeconds() {
		return m_LongestTimeOffInSeconds.ul;
	}
	;
	void ResetLithiumLife() {
		m_LithiumLifeInSeconds.ul = 0;
		m_pNVLithiumLifeInSeconds->SetToNV(m_LithiumLifeInSeconds);
	}
	;
	const CTVtime GetPowerOnTime() {
		return m_powerOnTime;
	}
	;
	const float GetElapsedRealTimeInSeconds();
	void AddTimeHistoryStartEntry(CTimeHistory *pTh) {
		pTh->AddEntry(m_OnGoingProcessTick100.ll, m_baseRealTime, TRUE);
	}
	;
	ULONG GetDataProcesssleep() {
		return m_DataProcessingIntervalsleep;
	}
	;
	//---------------------------------------------------------------
	// System Time (Realtime now) API
	//---------------------------------------------------------------
	const LONGLONG GetCurrentSystemTimeTick100();
	const LONGLONG GetHighResOnGoingTick100();
	//---------------------------------------------------------------
	// Process Time (Current process timeslice) API
	//---------------------------------------------------------------
	const CTVtime& GetCurrentProcessTimeRef() {
		return m_currProcessTime;
	}
	;
	const TV5Time& GetCurrentProcessTimeTV5Ref() {
		return m_currProcessTimeTV5;
	}
	;
	const float GetElapsedProcTimeInSeconds() {
		return m_processTimeInSeconds;
	}
	;
	const LONGLONG GetCurrentProcessTimeInMicroSec();	///< Get Process time in Microseconds
	const ULONG GetCurrentProcessInterval() {
		return m_processInterval100;
	}
	;
	const ULONG GetProcessSlicesPerSecond() {
		return m_processSlicesSec;
	}
	;
	const LONGLONG GetOnGoingProcessTick() {
		return m_OnGoingProcessTick100.ll;
	}
	;
	const LONGLONG GetCurrentProcessTick() {
		return m_currProcessTick100;
	}
	;
	void SetOnGoingProcessTick(LONGLONG newtick) {
		m_OnGoingProcessTick100.ll = newtick;
	}
	;
	int GetProcessHour() {
		return m_currProcessTime.GetHour();
	}
	;
	int GetProcessDay() {
		return m_currProcessTime.GetDay();
	}
	;
	int GetProcessWeekDay() {
		return m_currProcessTime.GetDayOfWeek();
	}
	;
	int GetProcessMonth() {
		return m_currProcessTime.GetMonth();
	}
	;
	//---------------------------------------------------------------
	// Time change API
	//---------------------------------------------------------------
	const int RegisterATimeChange(bool bSyncTime = false);	///< Register that the system time has changed
	const BOOL HasTimeChangeOccured() {
		return m_ValidTimeChange;
	}
	;
	void StartTimeHasChanged() {
		m_ValidTimeChange = TRUE;
		m_UncoordinatedTimeChange = FALSE;
	}
	;	// Start a coordinated time change
	void ClearTimeHasChanged() {
		m_ValidTimeChange = FALSE;
	}
	;										// Clear a coordinated time change
	CTVtime GetPreTimeChangeProcessTime() {
		return m_PreTimeChangeProcessTime;
	}
	;
	void CoordinateTimeChangeIfRequired();
#ifdef DBG_FILE_LOG_SYSTIMER_ENABLE
	void LogDebugMessage(QString strDebugMessage);
	void SetDebugLogger(CDebugFileLogger *pDbgFileLogger);
#endif
#ifdef DBG_FILE_LOG_SYSTIMER_ENABLE
	static CDebugFileLogger m_debugFileLogger;
	CDebugFileLogger *m_pDebugFileLogger;
#endif
private:
	void SetDataItemTimeCount() {
		CDataItem::SetCurrentProcessTime(m_OnGoingProcessTick100.val[0].ul);
	}
	;
	int LoadSNTP(void); ///PSR - SNTP
private:
	CTVtime m_powerOnTime;					///< Time unit was powered on
	CTVtime m_currProcessTime;		///< Real world time of current process tick
	TV5Time m_currProcessTimeTV5;		///< Real world time of current process tick as a TV5Time
	CTV6Timer m_baseSysTimerMicroS;	///< Baseline system timer in MicroSeconds
	ULONG m_processInterval100;			///< Process Interval in ticks 1/100
	ULONG m_processSlicesSec;			///< Number of process slices per second( 1sec / m_processInterval100)
	LONGLONG m_currProcessTick100;			///< Current Process Tick in 1/100
	COMBO_VAR8 m_OnGoingProcessTick100;	///< Running Process Tick in Ticks persisted over power fail (1/100)
	QMutex m_SysTimerCS;			///< System Timer Critical section
	float m_processTimeInSeconds;			///< Current Process time since start in seconds
	CNVBasic8TimeVar *m_pOnGoingTimerNV;			///< On going process tick timer, NV space
	BOOL m_ValidTimeChange;				///< A large time change has occured
	BOOL m_UncoordinatedTimeChange;	///< Register a time change locally, uncoordinated as yet
	CTVtime m_timeAdjustment;			///< Absolutine time adjustment for realtime
	CTVtime m_PreTimeChangeProcessTime;			///< The time current process slice would have been (used for logging)
	QString m_strTimeChange;			///< Build date change text when time changed, but only display when cordinated
	int m_LastTimeOffInSeconds;	///< Total time unit was previously switched off in seconds
	CNVBasicVar *m_pNVLithiumLifeInSeconds;	///< Lithium time running in seconds (when power off)
	COMBO_VAR4 m_LithiumLifeInSeconds;
	CNVBasicVar *m_pNVOffTimeInSeconds;			///< Time off in seconds
	COMBO_VAR4 m_OffTimeInSeconds;
	CNVBasicVar *m_pNVLongestTimeOffInSeconds;			///< Longest time off in seconds (max period unpowered)
	COMBO_VAR4 m_LongestTimeOffInSeconds;
	ULONG m_DataProcessingIntervalsleep;			///< Time to sleep between data processing cycles
	bool m_syncNextTime;
public:
	/// @todo - make these private once more (when time history implemented)
	CTVtime m_baseRealTime;					///< Baseline system Time
	LONGLONG m_baseOngoingTick;	///< Baseline the ongoing Tick on startup, to generate HighResOngoingTick
	bool bForceRTCSync;
	volatile bool bUserTriggeredTimeChange;
	QMutex m_SyncRTCCS;			///< System Timer Critical section
public:
	//---------------------------------------------------------------
	// API's for getting the information of DST/SDT
	//---------------------------------------------------------------
	DWORD CheckTime(SYSTEMTIME sysTime, TIME_ZONE_INFORMATION tzi);
	static BOOL LocaleSupportsDST(TIME_ZONE_INFORMATION *ptzi);
	static BOOL DST_DetermineChangeDate(LPSYSTEMTIME pst, BOOL fThisYear = FALSE);
	static WORD GetFirstWeekDayOfMonth(LPSYSTEMTIME pst);
	BOOL DST_Auto(void);
};
#endif // __SYSTIMER_H__

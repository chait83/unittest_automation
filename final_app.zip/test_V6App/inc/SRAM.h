/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: SRAM.h
/// @n Desc:	Manages access to the SRAM for a function related region	
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 23	Stability Project 1.20.1.1	7/2/2011 5:01:30 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 22	Stability Project 1.20.1.0	7/1/2011 4:26:55 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 21	V6 Firmware 1.20		9/23/2008 3:09:33 PM	Build Machine 
//		AMS2750 Merge
// 20	V6 Firmware 1.19		3/28/2007 3:49:55 PM	Andy Kassell	Add
//		Pen report information, max, min, ave and totals for hour, day week
//		and month
// $
//
// ****************************************************************
#ifndef __SRAMUSER_H__
#define __SRAMUSER_H__
#include "DAL.h"							// System abstraction layer
#include "PassiveModule.h"				// Passive Module Base Class
//
#include "Defines.h"
#include <QVector>
#include <QMutex>
/// Enumerated region list, starts at 0 so emun can be used as index into manages region instance in CSRAMManager
enum regionIdent {
	REGION_RESERVED = 0,		///< Reserved region for total SRAM integrity
	REGION_HOTSOAK,							///< Hot soak test region
	REGION_BOOT,							///< Application boot data
	REGION_GENERAL,							///< General NV Info
	REGION_SCRIPT_PV,				///< Persist variables for script services
	REGION_PASSWORD,						///< Password NV info
	REGION_TRANSACTION,						///< Transaction status NV info
	REGION_CONTROLSEQ,						///< Control Sequencer NV info
	REGION_NVVARS,							///< NV system variables
	REGION_TRANSFER,						///< data transfer status
	REGION_LOGGING,							///< NV Logging status
	REGION_ALARMS,							///< Alarm Non volatile information
	REGION_NVQUEUES,						///< Non Volatile queue buffers
	REGION_REPORTS,							///< Report NV information
	REGION_TABULAR,						///< Tabular readings 
	REGION_AMS2750,							///< AMS2750 related data 
	REGION_CSV_TRANS,							///< CSV transactions data
	// Add new regions here <<<<<<<<										
	/// End of region list, NB ALWAYS keep at end of enum list
	REGION_END
};
/// Region signature, held at the start of each SRAM region to indicate use and status
typedef struct _regionSig {
	USHORT signature;	///< signature - see REGION_USED_SIG, shows region being used in present
	USHORT version;		///< Version number of region, maintained by user module
	USHORT autoState;		///< Automatic update state if using managed writes
	USHORT crc;					///< crc of region data, used for diagnostics.
} REGIONSIG, *PREGIONSIG;
/// SRAM access states, these are optional depending on requirements for region
const USHORT SRAM_STATE_NORMAL = 0;			///< Normal state no activity
const USHORT SRAM_STATE_UPDATING = 1;		///< Region being updated
const USHORT SRAM_STATE_FIRSTUSE = 2;	///< First time the region has been used
const USHORT SRAM_STATE_INVALID = 3;		///< Region Invalid
const int MAX_REGION_LIMIT = 100;///< Sensible max number of regions likely, Safeguard against regionEnd being removed from SRAMRegionMap
const int SRAM_REGION_DESC_LEN = 30;	///< Description length of SRAM region
typedef struct _SRAMRegion {
	enum regionIdent id;					///< ID of the SRAM region
	long Start;					///< Offset in bytes to the start of the SRAM
	long End;								///< End in bytes of the Sram region
	WCHAR Name[SRAM_REGION_DESC_LEN];	///< Name of region (for debug purposes
} SRAMREGION, *PSRAMREGION;
//**Class*********************************************************************
///
/// @brief Manage region of SRAM
/// 
/// This class will manage a region of SRAM for a user , 
/// and will provide the functionality to maintain state of transaction
/// and check on startup the status of the SRAM and associated region
///
/// @note SRAM access is only available as 16bit access
///
//****************************************************************************
class CSRAMRegion {
public:
	CSRAMRegion();
	// Region user API
	void* GetAddress() {
		return m_pUserBase;
	}
	long GetAvailableBytes() {
		return (GetMapSize());
	}
	;			///< Get the size of the available memory in the region
	void SetAutoStateToUpdating() {
		m_pRegSig->autoState = SRAM_STATE_UPDATING;
	}
	;		///< Set auto status that update is about to be performed
	void SetAutoStateToNormal() {
		m_pRegSig->autoState = SRAM_STATE_NORMAL;
	}
	;			///< Set auto status that update has been completed
	USHORT GetAutoState() {
		return m_pRegSig->autoState;
	}
	;						///< Get Automatic status, see SRAM_STATE_XXXX 
	void SetCRC();						///< Create the CRC within the header
	BOOL TestCRC();					///< Test the CRC against the current data
	void ClearRegion();							///< Force a region cleardown.
	void SetVersion(USHORT verison) {
		m_pRegSig->version = verison;
	}
	;						///< Set version number, user module dependent
	USHORT GetVersion() {
		return m_pRegSig->version;
	}
	;							///< Get version number, user module dependent
	// Member functions for use by CSRAMManager only
	BOOL Initalise(PSRAMREGION pMapAddr);							///< Initialise region from map entry
	long GetMapEnd() {
		return m_pMapEntry->End;
	}
	;							///< Get the offset of the end of memory
	long GetMapStart() {
		return m_pMapEntry->Start;
	}
	;							///< Get Start offset of region in memory map
	long GetMapSize() {
		return ((m_pMapEntry->End - m_pMapEntry->Start) - sizeof(REGIONSIG));
	}
	;	///< Get usable Size of region
	void SetInUse(BOOL state) {
		m_inUse = state;
	}
	;									///< Set region In Use status
	BOOL IsInUse() {
		return m_inUse;
	}
	;									///< Get region in Use status.
	CDeviceAbstraction* DAL() {
		return m_pDAL;
	}
	;
private:
	void *m_pUserBase;								///< Base address of the user ares, regoin base + signature block
	PREGIONSIG m_pRegSig;			///< pointer to signature block
	PSRAMREGION m_pMapEntry;		///< pointer to entry in SRAMRegionMap
	BOOL m_inUse;					///< Region has been requested and in use
	CDeviceAbstraction *m_pDAL;		///< Device abstraction layer singleton
};
//**Class*********************************************************************
///
/// @brief Manage access to SRAM and all associated regions
/// 
/// This class will manage access to SRAm via regions, each region will be
/// allocated a CSRAMRegion instance.
///
///
//****************************************************************************
class CSRAMManager: public CPassiveModule {
public:		//Singleton 
	static CSRAMManager* GetHandle();
	void CleanUp();
private:	// Singleton
	CSRAMManager();
	CSRAMManager(const CSRAMManager&);
	CSRAMManager& operator=(const CSRAMManager&) {
		return *this;
	}
	;
	~CSRAMManager() {
	}
	;
	static CSRAMManager *m_pInstance;
	static QMutex m_CreationMutex;
public:
	BOOL Initialise();	///< initialise the SRAM manager							
	enum regionError {
		REGION_OKAY,					///< Region request,release successful
		REGION_IN_USE,				///< Region already in use when requested
		REGION_NOT_IN_USE,		///< Region not being used in release request
		REGION_MANAGER_NOT_INIT,			///< Region Manager not Initialised
		REGION_DOES_NOT_EXIST				///< Region requested does not exist
	};
	regionError ReleaseRegion(regionIdent regionId);		///< Release region of SRAM, so can be used by other user
	regionError RequestRegion(regionIdent regionId, CSRAMRegion **pRegion);	///< Request to use a region of SRAM, by region id
	void CRCAllRegions();
private:
	QVector<CSRAMRegion> m_region;			///< Array of CSRAMRegion objects
	short m_totalRegions;				///< Total number of regions available
	BOOL m_Initilaised;				///< Status of the CSRAMManager instance.
private:
	BOOL BuildRegionMap();		///< Build the region map into m_region QVector
	BOOL CheckForRegionOverlap();			///< Check all regoins for overlaps
	CDeviceAbstraction *m_pDAL;			///< Device abstraction layer singleton
	/// @todo AK, possibly add a save to CF for debug, uints could "dump" thier SRAM to CF which could be retuned to base for inspection.
};
void SRAMtestCaddy();						// SRAM Test caddy
#endif // __SRAMUSER_H__

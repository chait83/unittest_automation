/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Time Tasks
/// @n Filename:  TimeChangeNotifyThread.h
/// @n Description: Definition of the CTimeChangeNotifyThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 5:02:06 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:27:44 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 9/13/2006 3:16:51 PM  Roger Dawson  
//  Made improvements to the way printing errors are reported, in
//  particular network logon errors.
//  1 V6 Firmware 1.0 4/7/2006 3:51:04 PM Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_TIMECHANGENOTIFYTHREAD_H__5C141EEA_AC91_4D80_931F_F7A1EFA8EDB7__INCLUDED_)
#define AFX_TIMECHANGENOTIFYTHREAD_H__5C141EEA_AC91_4D80_931F_F7A1EFA8EDB7__INCLUDED_
#include "Defines.h"
#include <QThread>
#include "DSTChangeNotificationThread.h"
#include "EventWrapper.h"
//**CTimeChangeNotifyThread***********************************************************
///
/// @brief	Thread class used to synchronise the current local time with the
///			time history file and synchronise the RTC. This thread is also used to handle
///			network resource logon error events
/// 
/// Thread class used to synchronise the current local time with the
///	time history file and synchronise the RTC. This thread is also used to handle
///	network resource logon error events
///
//****************************************************************************

DWORD  GetTimeZoneInformation(TIME_ZONE_INFORMATION *tzi);
class CTimeChangeNotifyThread: public EventWrapper {
public:
	/// @author : Chaitannya Mahatme : Changed the constructor type from protected to public
	CTimeChangeNotifyThread();  // protected constructor used by dynamic creation
// Attributes
public:
	/// Enum indicating the various thread states
	enum T_TCN_THREAD_STATE {
		tcnINIT, tcnRUNNING, tcnSHUTDOWN,
	};
// Operations
public:
	// The thread function itself
	static UINT TimeChangeNotifyFunc(LPVOID lpParam);
	// Method that signals to the thread we are shutting down
	static void ShutdownThread();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTimeChangeNotifyThread)
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL
// Implementation
protected:
	// Destructor
	virtual ~CTimeChangeNotifyThread();
	// Generated message map functions
	//{{AFX_MSG(CTimeChangeNotifyThread)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
private:
	/// Variable used to indicate the required operational state of the time change monitoring thread
	static T_TCN_THREAD_STATE ms_eState;
	/// The handle to the time change trigger event
	static HANDLE ms_hEvent;
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_TIMECHANGENOTIFYTHREAD_H__5C141EEA_AC91_4D80_931F_F7A1EFA8EDB7__INCLUDED_)

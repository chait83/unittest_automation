/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 UI Control
/// @n Filename: TopStatusBar.h
/// @n Desc:	 Functionality for the main status bar/recorder control
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  41  Stability Project 1.38.1.1 7/2/2011 5:02:08 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  40  Stability Project 1.38.1.0 7/1/2011 4:27:40 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  39  V6 Firmware 1.38 9/14/2010 11:38:46 AM  Build Machine 
//  Revert Code Merge For Replay at fast speed
//  38  V6 Firmware 1.37 9/10/2010 5:55:49 PM  Vivek (HAIL)  
//  Code merge for Replay at fast speed
// $
//
//	29/05/2014  Vellaidurai V  Fixed PAR 1-3DVR1C6 - QXe_Screen Overlapping over NUmeric Keypad_when Alarm is Acknowledge
// ****************************************************************
#if !defined(AFX_TOPSTATUSBAR_H__44D575EB_FD39_420B_9DD4_230EDE18B053__INCLUDED_)
#define AFX_TOPSTATUSBAR_H__44D575EB_FD39_420B_9DD4_230EDE18B053__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TopStatusBar.h : header file
//
#include "TopStatusControl.h"
#include "PenManager.h"
#include "AMS2750TimerCtrlDlg.h"
#include <QDialog>
#include "Widget.h"
const int STATUS_BAR_TIMER_EVENT = 107;
const int MESSAGE_DISPLAY_LIMIT = 9999;	// Total number of unread messages to display before limiting number displayed
const int CONTEXT_BUTTON_DISPLAY_TIME_SECONDS = 3;
const int NAME_ID_SCREEN_CYCLE_IN_SECONDS = 3;
const ULONG MIN_THRESHOLD = (2 * 60 * 60);			///< 2 hours
const ULONG HOUR_THRESHOLD = (2 * 24 * 60 * 60);		///< 2 days
const ULONG DAY_THRESHOLD = (365 * 24 * 60 * 60);		///< 1 year
/////////////////////////////////////////////////////////////////////////////
// CTopStatusBar dialog
// Alarm states for bar mode
typedef enum {
	TOPBARSTAT_ALARM_UNKNOWN,			///< Unknown alarm status
	TOPBARSTAT_ALARM_NONE,				///< No alarms being shown
	TOPBARSTAT_ALARM_ACTIVE_OUT,		///< Alarms active but all out of alarm
	TOPBARSTAT_ALARM_ACTIVE_IN,			///< Alarms active and some in alarm
} T_TOPBARSTAT_ALARM;
// Forward Class Declarations
class CErrorDlg;
class CTopStatusBar: public QDialog {
// Construction
public:
	enum T_STATUSBAR_LOCKED_PURPOSE {
		slpUNLOCKED = 0x00,
		slpGENERAL = 0x01,
		slpFTP_UPLOAD_CFG = 0x02,
		slpREBOOT_PENDING = 0x04,
		slpERROR_DIALOG_ON_DISP = 0x08,
		slpTRIGGER_RESTART = 0x10	// used in conjunction with the reboot pending flag
	};
	bool PostMessage(HANDLE wnd = nullptr, UINT type = 0, WPARAM wParam = 0, LPARAM lParam = 0);
	// Destructor
	~CTopStatusBar(void);
	// Singleton Accessor/Creator
	static CTopStatusBar* Instance(CWidget *pParent = NULL);
	void ShowStatusBar();														///< Show the status Bar
	void HideStatusBar();														///< Hide the status Bar
	void TriggerMainMenu() {
		OnStatusbarMmBtn();
	}
	;						///< Trigger the main menu call externally(F9 op panel)
	void SetEditModeOn() {
		m_InEditMode = TRUE;
	}
	;						///< Set edit config mode on
	void SetEditModeOff() {
		m_InEditMode = FALSE;
	}
	;						///< Set edit config mode off
	const bool GetEditMode() const {
		return (m_InEditMode == TRUE);
	}
	void MoveStatusBar();		// Move and size to position
	void OnCancel();			// Overridden
	void KillStatusBar();		// Shutdown the status bar
	void RedrawScreenNameOnBar();
	void SetVisibleSlide(BOOL visible);
	void SetVisible(BOOL visible);
	void LockStatusBar(bool Locked);
	void ShowContextButton(BOOL SwitchOn, BOOL bOnlyShowHotButtons = FALSE);
	void ShowHotButtons(BOOL SwitchOn);
	const bool IsMenuSystemInUse() {
		return (m_bMenuSystemInUse || !m_Visible);
	}
	BOOL IsTopStatusBarVisble() {
		return (m_Visible);
	}	//Fix for PAR 1-3DVR1C6
	BOOL IsControlBarInUse() {
		return m_ControlBar.GetVisible();
	}
	VOID GetControlBarRect(QRect &rect) {
		m_ControlBar.GetWindowRect(&rect);
	}
	BOOL IsErrorDlgActive() {
		return m_pkErrorDlg != NULL;
	}
	void SetMenuSystemInUse(const bool bMENU_SYSTEM_IN_USE) {
		m_bMenuSystemInUse = bMENU_SYSTEM_IN_USE;
	}
	/// Method that checks if recorder setup configuration commits/loads are allowed 
	const bool SetupChangeAllowed() const {
		return !m_bFTPDownloadDataInProgress;
	}
	/// Method that checks if recorder resets are allowed 
	const bool RecorderResetAllowed() const {
		return !m_bFTPDownloadDataInProgress;
	}
	//RePaint Non Process Screen if not already painted
	VOID RepaintNonProcessScreen(int iScreenType);
	//Show selected Non Process Screen
	BOOL ShowNonProcessScreen(int iScreenType);
	//Hide selected Non Process Screen
	BOOL HideNonProcessScreen(int iScreenNumber);
	// Get window rect if error dialog is visible
	BOOL GetErrorDlgRectIfVisible(QRect &rect);
	// Current Non process dialog
	QDialog *m_pNPSDlg;
	//Fix for PARs 1-1YAI71G and 1-3E85FAM
	//Stop OpPanel Refresh incase child windows that are not full screen occupied opened
	void SetOpPanelRefresh(BOOL bOpPanelRefresh) {
		m_bOpPanelRefresh = bOpPanelRefresh;
	}
	BOOL GetOpPanelRefresh() {
		return (m_bOpPanelRefresh);
	}
	void Update(bool bIsrebootRequested = false);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTopStatusBar)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	virtual void PostNcDestroy();
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL
	virtual void OnOK();
// Implementation
protected:
	// Singleton auto pointer
	static std::unique_ptr<CTopStatusBar> m_TopStatusBarDlg;
	// Generated message map functions
	//{{AFX_MSG(CTopStatusBar)
	void OnPaint();
	virtual BOOL OnInitDialog();
	void OnStatusbarScreenBtn();
	void OnStatusbarMmBtn();
	void OnStatusbarMessBtn();
	void OnStatusbarMemBtn();
	void OnStatusbarAlmBtn();
	HBRUSH OnCtlColor(CDC *pDC, CWidget *pWnd, UINT nCtlColor);
	void OnStatusbarExtra1();
	void OnStatusbarExtra2();
	void OnStatusbarExtra3();		// CR: 3151 Replay at Faster speed.
	void OnStatusbarContextBtn();
	void OnStatusbarHotBtn1();
	void OnStatusbarHotBtn2();
	void OnStatusbarHotBtn3();
	void OnStatusbarHotBtn4();
	//}}AFX_MSG
	LRESULT OnModeChangeMessage(WPARAM wParam, LPARAM lParam);
	LRESULT OnSoftButtonClick(WPARAM wParam, LPARAM lParam);
private:	// Methods
	CTopStatusBar(CWidget *pParent = NULL);  // standard constructor
	void SizeButtons();					///< Resize the buttons
	void SetAlarmButton();				///< Set the alarm button status
	void SetMessagesButton();			///< Set the message button status
	void SetMemoryButton(BOOL bUpdate = FALSE);		///< Setup the memory button status
	void SetButtonsForMode();			///< Setup the buttons depending on the mode
	void SetForSnapMode();				///< Setup snap mode
	void SetForExpertMode();			///< Setup expert mode
	void SetReplayMode(T_TOPBARSTAT_REPLAY replayMode);		///< Setup the mode dependent 
	void ToggleIDAndScreenNames(BOOL cycleDisplay);
	// Method that updates the top statusbar when it is displaying a batch/group screen
	void ToggleBatchInfo(const bool bCYCLE_DISPLAY, const USHORT usGROUP_INDEX);
	// Method that displays a reason for the status bar being locked 
	void ToggleLockedWarning();
	void SetMainMenuButton();			///< Method that sets the locked/unlocked icon on the main menu button
	// Method that allows the user to edit the TUS configuration and start a TUS
	void ShowTUSConfiguration(const bool bSTART_TUS);
	// Method that allows the user to start a TUS
	void ShowStartTUSDlg();
	// Method that allows the user to stop a TUS
	void ShowStopTUSDlg();
	// Method that allows the user to remove TC's from a TUS
	void ShowRemoveTCDlg();
	// Method that shows the AMS2750 timer reset dialog
	void ShowAMS2750TimerCtrlDlg(const USHORT usSCREEN_NO, const T_AMS2750_TIMER_TYPES eTIMER_TYPE);
	// Method that toggles the display with a TC expiry warning when a TC is past its no. of uses or next calibration date
	void ToggleTCExpiryWarning(const bool bCYCLE_DISPLAY);
	// Method that toggles the display with a TC cal excluded warning when the TC cal adjustment is turned off
	void ToggleTCCalExcludedWarning(const bool bCYCLE_DISPLAY);
private:	// members
	BOOL m_Visible;						///< Is Status bar currently visble
	BOOL m_shown;
	BOOL m_InEditMode;					///< Is the system in edit mode?
	COpPanel *m_pOpPanel;				///< Handle on parent windows (OPPanel)
	CPenManager *pPenManager;			///< Handle to PenManager singleton
	QRect m_SBPos;						///< Status Bar position and limits
	CFont m_TimeDateFont;				///< Font used for the time and the date
	CFont m_RecNameFont;				///< Font used name and ID of recorder
	// Size dependent variables
	int m_FontHeight;					///< Height of Font
	int m_TimeDateDistanceFromright;	///< Start position of Time/Date ext from the right hand side
	int m_TimeDateWidth;				///< Width of Time/Date text 
	int m_TimeDateYOffset;				///< Y Offset of time and date
	int m_RecNameDistanceFromright;		///< Start position of Recorder text from the right hand side	
	int m_RecNameWidth;					///< Recorder name and ID text width
	int m_TextHeights;					///< Start position of Time/Date and Recorder text from the right hand side
	int m_BarHeight;					///< Height of Status Bar
	QBrush m_bgBrush;					///< New Background Brush
	COLORREF m_BackColour;				///< Background Colour of dialog
	COLORREF m_TextColour;				///< Text Colour for dialog
	T_TOPBARSTAT_ALARM m_AlarmOverviewStatus;	///< Status of the alarm overview button
	ULONG m_NumberOfAlarmsinAlarm;				///< Number of alarms in alarm the last time status bar was updated
	int m_NumLastUnreadMessages;		///< Last number of unread messages displayed
	USHORT m_numPensLogging;			///< Last number of pens logging
	T_TOPBAR_MODE m_mode;				///< Status Bar mode
	CTopStatusControl m_ControlBar;		///< Control Bar	
	BOOL m_SnapOn;						///< Snap on in screen edit mode(TRUE), off (FALSE)
	BOOL m_ExpertOn;///< Expert mode (object select) on in screen edit mode (TRUE), otherwise on widgets selectable (FALSE)
	T_TOPBARSTAT_REPLAY m_replayMode;	///< Current replay mode
	BOOL m_Linked;
	BOOL m_ScrollChart;
	BOOL m_DualCursors;
	BOOL m_ContextButtonShown;			///< Is Context button displayed
	int m_ContextButtonTimer;			///< Countdown timer for context button
	CNVBasicVar *m_pNVRecordingTime;	///< Available recording time left (in seconds)
	int m_NameRotationCounter;			///< Name rotation count for ID and Screen name
	BOOL m_NameDisplayIsID;				///< ID or screen name being display? TRUE = ID, FALSE = Screen
	QString m_recIDAndName;				///< Cache Recorder ID and name
	/// Flag indicating if the user is in the menu system because the status bar is locked and hidden
	bool m_bMenuSystemInUse;
	/// Flag indicating which password system locked/unlocked bitmap we should display
	bool m_bShowLockedBmp;
	/// Enum indicating the reason the status bar is locked e.g. ftp upload config, reboot, etc.
	ULONG m_ePurposeForLocked;
	/// Flag indicating a FTP download data operation is in progress - used for display purposes
	/// and to indicate commiting setups and operations that require reboots are not allowed
	bool m_bFTPDownloadDataInProgress;
	/// Pointer to the error dialog
	CErrorDlg *m_pkErrorDlg;
	/// Store for the time when the statusbar was last updated
	QDateTime m_tLastUpdateTime;
	// Method that checks the error control system state
	void CheckErrorControlSystem();
	//Variable to stop oppanel refresh
	BOOL m_bOpPanelRefresh;
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_TOPSTATUSBAR_H__44D575EB_FD39_420B_9DD4_230EDE18B053__INCLUDED_)

//************************************************************************************
// © Honeywell Technology Solutions Lab Pvt LTD Bangalore 
//************************************************************************************
// Module  DDPTOOL Constants 
// Filename 	rendview_v6\code\header\constants.h
// Description - Header file contains the definitions common to compile tool and CMM.
//
//*** Revision History ***************************************************************
// $Log[1]:
// 6	Stability Project 1.3.1.1	7/2/2011 4:56:19 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL version
//	of firmware to JF version of firmware.
// $
//************************************************************************************
#pragma once
//#ifndef	UNDER_CE
//
//#endif
/*
 For METADATA
 Struct definitions will have a range of 50 to 999
 Union definitions will have a range from 1000 to 1999
 */
/*#define STRUCT_INDEX_START 100	//100 - 39999 =>39900
 #define UNION_INDEX_START 40000 //40000 - 49999 =>10000
 */
#define UDDT_IDX	100	//100 - 49999 => 49899
#define VARIABLE_BASE 50000		//50000 onwards may 20 of them will be used
#include "Defines.h"
enum enumWCLASS {
	classStandard = 1, classUnique, classStruct, classUnion, classStructmember, classUnionmember, classAutoInitmember
};
#define MD_HEADER_OFFSET_FILENAME 0
#define MD_HEADER_OFFSET_VERNO	80 
#define MD_HEADER_OFFSET_SIZE 82
//ID of the basic data types [1 - 50]
#pragma warning (disable : 4189)
const short REF_UNDTERMINED_DATATYPE = -3;
const short REF_UNION = -2;
const short REF_STRUCT = -1;
const short REF_TV_BOOL = 1;
const short REF_BYTE = 2;
const short REF_CHAR = 3;
const short REF_SHORT = 4;
const short REF_USHORT = 5;
const short REF_BUSHORT = 6;
const short REF_FLOAT = 7;
const short REF_DOUBLE = 8;
const short REF_WORD = 9;
const short REF_DWORD = 10;
const short REF_UCHAR = 11;
const short REF_BUCHAR = 12;
const short REF_LONG = 13;
const short REF_ULONG = 14;
const short REF_BULONG = 15;
const short REF_WCHAR = 16;
const short REF_TCHAR = 17;
const short REF_LONGLONG = 18;
const short REF_quint64 = 19;
const short FILENAME_LEN = 40;
const short STR_LEN = 16;
/*
 Ranges
 */
const short int RANGE_MIN_BYTE = 0;
const short int RANGE_MAX_BYTE = 255; //same for UCHAR
const short int RANGE_MIN_SHORT = -32768;
const short int RANGE_MAX_SHORT = 32767;
const unsigned short RANGE_MIN_USHORT = 0;
const unsigned short RANGE_MAX_USHORT = 65535;
const signed long int RANGE_MIN_LONG = (-2147483647L - 1);
const signed long int RANGE_MAX_LONG = 2147483647L;
const unsigned long RANGE_MIN_ULONG = 0;
const unsigned long RANGE_MAX_ULONG = 4294967295;
const double RANGE_MIN_DOUBLE = -1.7E-308;
const double RANGE_MAX_DOUBLE = 1.7E+308;
const float RANGE_MIN_FLOAT = (float) -3.4E-38;
const float RANGE_MAX_FLOAT = (float) 3.4E+38;
const int64_t RANGE_MIN_LONGLONG = (-9223372036854775807 - 1);
const int64_t RANGE_MAX_LONGLONG = 9223372036854775807;
const uint64_t RANGE_MIN_quint64 = 0;
//const unsigned qint64 RANGE_MAX_quint64 = 18446744073709551614;
const uint64_t RANGE_MAX_quint64 = 0xffffffffffffffff;
typedef struct _Metadata_Header {
	wchar_t szFilename[FILENAME_LEN];
	WORD wVerNo;
	WORD wSize;
} Metadata_Header, *PMetadata_Header;
typedef union _value {
	BYTE b;
	char c;
	UCHAR uc;
	WCHAR wc;
	short s;
	USHORT us;
	long l;
	ULONG ul;
	WORD w;
	DWORD dw;
	float f;
	double d;
	LONGLONG ll;
	quint64 ull;
} value;
typedef struct _MD {
	char Fieldname[STR_LEN]; // need not be wchar... ****16
	WORD wDatatype;											// ****2
	WORD wnumInst;											//	****2
	WORD wnumSubInst;										//	****2
	WORD wclass;								//	****2(has been shifted up)
	value vdefault;											//	****8
	value Lowlmt;											//	****8
	value Hilmt;											//	****8
} MD, *PMD;

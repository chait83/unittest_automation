/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O board
/// @n V6IOProtocol.h
/// @n Header with defines etc for V6 I/O protocol
/// @author DWK
/// @date 21/11/2003
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 13	Stability Project 1.10.1.1	7/2/2011 5:02:43 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.10.1.0	7/1/2011 4:26:57 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	V6 Firmware 1.10		4/14/2005 2:11:18 PM	Mark Dennison 
//		Moved RS232 handshake characters from V6IO.h to this common file
// 10	V6 Firmware 1.9		4/8/2005 5:15:26 PM	Graham Waterfield
//		Successful creation of AI channels
// $
//
// *******************************************
#ifndef V6IOPROTOCOL_H
#define V6IOPROTOCOL_H
/********************************************************************
 * #defines 
 ********************************************************************/
#define	MAX_SPI_MESS_LEN	192	//< max size of SPI message from master
///*************************************************************************				
///					16/08/04 MPD Fact cal only needs about 46 bytes, write digital config 
///					needs about 51 bytes, Update Stats needs about 110 bytes. 
///					192 bytes is serious overkill - but left at 192
///					as there is no need to reduce it
///**************************************************************************/
#define SPI_HEADER_SIZE		4 		///< size of SPI message headers
#define CRC_LENGTH			2		///< length of message CRC in bytes
#define TS_LENGTH				2		///< size of time stamp in bytes
// handy define of the header + CRC size: minimum message overhead
#define SPI_HDR_PLUS_CRC					( SPI_HEADER_SIZE + CRC_LENGTH ) 
#define FP_COMMAND_MODE_REQUEST	0xa5	///< in listener mode, first output is board id, max 0x07
//#define FP_COMMAND_MODE_REQUEST	0x3f	///< in listener mode, first output is board id, max 0x07
// could send ? character to ask if there is remote commander present. Not as random as 0xa5, but
// provides a more recognisable character if RS232 terminal is plugged in.
// however, kept with 0xa5 as 0x3f is a command code as well, and 0xa5 is not.
#define FP_COMMAND_MODE_REPLY		0xfe	///< very unlikely to ever be used as a command code
#define FP_COMMAND_MODE_ERROR		0xfd	///< buffer overflow - only to be read while PC sends data
/************************************************************
 * defines for calibration of AI board returned ADC readings 
 *************************************************************/
#define INTERN_UNDER				0				///< under range 
#define INTERN_CENTRE				32400		///< internal zero (mid-point)
#define INTERN_OVER					64800		///< over range 
//	eg INTERN0 value for 50V input range
// 	allows up to 52V measurement on 50V range
#define		INTERN50V_0			1246		///< Gain 1 (volts)
#define		INTERN25V_0			1246		///< Gain 2 
#define		INTERN12V_0			2492		///< Gain 4
#define		INTERN6V_0			2492		///< Gain 8
#define		INTERN3V_0			2492		///< Gain 16
#define		INTERN1_5_0			2025		///< Gain 32
#define		INTERN0_6_0			8100		///< Gain 64
#define		INTERN0_3_0			8100		///< Gain 128
#define		INTERN1000mV_0	2945		///< Gain 1	(millivolts)
#define		INTERN500mV_0		5400		///< Gain 2
#define		INTERN250mV_0		5400		///< Gain 4
#define		INTERN100mV_0		10800		///< Gain 8
#define		INTERN50mV_0		10800		///< Gain 16
#define		INTERN25mV_0		9900		///< Gain 32
#define		INTERN10mV_0		14400		///< Gain 64
#define		INTERN5mV_0			14400		///< Gain 128
// note: on eg 50V range, calibrate by applying +/-50V
// +50V raw reading -> Count.Span, -50V raw reading -> Count.Zero
// Intern100 defines calculate the count for positive voltage:
#define		INTERN50V_100			((INTERN_CENTRE - INTERN50V_0) + INTERN_CENTRE) ///< Gain 1 (volts)
#define		INTERN25V_100			((INTERN_CENTRE - INTERN25V_0) + INTERN_CENTRE) ///< Gain 2 
#define		INTERN12V_100			((INTERN_CENTRE - INTERN12V_0) + INTERN_CENTRE) ///< Gain 4
#define		INTERN6V_100			((INTERN_CENTRE - INTERN6V_0) + INTERN_CENTRE) ///< Gain 8
#define		INTERN3V_100			((INTERN_CENTRE - INTERN3V_0) + INTERN_CENTRE) ///< Gain 16
#define		INTERN1_5_100			((INTERN_CENTRE - INTERN1_5_0) + INTERN_CENTRE) ///< Gain 32
#define		INTERN0_6_100			((INTERN_CENTRE - INTERN0_6_0) + INTERN_CENTRE) ///< Gain 64
#define		INTERN0_3_100			((INTERN_CENTRE - INTERN0_3_0) + INTERN_CENTRE) ///< Gain 128
#define		INTERN1000mV_100	((INTERN_CENTRE - INTERN1000mV_0) + INTERN_CENTRE) ///< Gain 1	(millivolts)
#define		INTERN500mV_100		((INTERN_CENTRE - INTERN500mV_0) + INTERN_CENTRE) ///< Gain 2
#define		INTERN250mV_100		((INTERN_CENTRE - INTERN250mV_0) + INTERN_CENTRE) ///< Gain 4
#define		INTERN100mV_100		((INTERN_CENTRE - INTERN100mV_0) + INTERN_CENTRE) ///< Gain 8
#define		INTERN50mV_100		((INTERN_CENTRE - INTERN50mV_0) + INTERN_CENTRE) ///< Gain 16
#define		INTERN25mV_100		((INTERN_CENTRE - INTERN25mV_0) + INTERN_CENTRE) ///< Gain 32
#define		INTERN10mV_100		((INTERN_CENTRE - INTERN10mV_0) + INTERN_CENTRE) ///< Gain 64
#define		INTERN5mV_100			((INTERN_CENTRE - INTERN5mV_0) + INTERN_CENTRE) ///< Gain 128
// Intern values for AO card
#define		INTERNAO0mA_0			0x0								///< Minimum output of AO card
#define		INTERNAO4mA_0			((INTERNAO24mA_100 / 24) * 4 )	///< 4mA output
#define		INTERNAO24mA_100		0xffff							///< Maximum output of AO card
#define		INTERNAO21mA_100		((INTERNAO24mA_100 / 24) * 21 )	///< Maximum output that should ever be asked for from the software
#define		INTERNAO20mA_100		((INTERNAO24mA_100 / 24) * 20 )
/************************************************************
 * defines for calibration of NEW AI board (V7AI) returned ADC readings 
 *************************************************************/
#define		V7AI_INTERN_UNDER				0				///< under range 
#define		V7AI_INTERN_CENTRE				8388240		///< internal zero (mid-point)
#define		V7AI_INTERN_OVER				16776480		///< over range 
//	eg INTERN0 value for 50V input range
// 	allows up to 52V measurement on 50V range
#define		V7AI_ISSA_INTERN50V_0			322626		///< Gain 1 (volts)
#define		V7AI_ISSA_INTERN25V_0			322626		///< Gain 2 
#define		V7AI_ISSA_INTERN12V_0			645250		///< Gain 4
#define		V7AI_ISSA_INTERN6V_0			645250		///< Gain 8
#define		V7AI_ISSA_INTERN3V_0			645250		///< Gain 16
#define		V7AI_ISSA_INTERN1_5_0			524266		///< Gain 32
#define		V7AI_ISSA_INTERN0_6_0			2097060		///< Gain 64
#define		V7AI_ISSA_INTERN0_3_0			2097060		///< Gain 128
#define		V7AI_ISSA_INTERN1000mV_0		762568		///< Gain 1	(millivolts)
#define		V7AI_ISSA_INTERN500mV_0			1398040		///< Gain 2
#define		V7AI_ISSA_INTERN250mV_0			1398040		///< Gain 4
#define		V7AI_ISSA_INTERN100mV_0			2796080		///< Gain 8
#define		V7AI_ISSA_INTERN50mV_0			2796080		///< Gain 16
#define		V7AI_ISSA_INTERN25mV_0			2563074		///< Gain 32
#define		V7AI_ISSA_INTERN10mV_0			3728106		///< Gain 64
#define		V7AI_ISSA_INTERN5mV_0			3728106		///< Gain 128
// note: on eg 50V range, calibrate by applying +/-50V
// +50V raw reading -> Count.Span, -50V raw reading -> Count.Zero
// Intern100 defines calculate the count for positive voltage:
#define		V7AI_ISSA_INTERN50V_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN50V_0) + V7AI_INTERN_CENTRE) ///< Gain 1 (volts)
#define		V7AI_ISSA_INTERN25V_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN25V_0) + V7AI_INTERN_CENTRE) ///< Gain 2 
#define		V7AI_ISSA_INTERN12V_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN12V_0) + V7AI_INTERN_CENTRE) ///< Gain 4
#define		V7AI_ISSA_INTERN6V_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN6V_0) + V7AI_INTERN_CENTRE) ///< Gain 8
#define		V7AI_ISSA_INTERN3V_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN3V_0) + V7AI_INTERN_CENTRE) ///< Gain 16
#define		V7AI_ISSA_INTERN1_5_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN1_5_0) + V7AI_INTERN_CENTRE) ///< Gain 32
#define		V7AI_ISSA_INTERN0_6_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN0_6_0) + V7AI_INTERN_CENTRE) ///< Gain 64
#define		V7AI_ISSA_INTERN0_3_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN0_3_0) + V7AI_INTERN_CENTRE) ///< Gain 128
#define		V7AI_ISSA_INTERN1000mV_100		((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN1000mV_0) + V7AI_INTERN_CENTRE) ///< Gain 1	(millivolts)
#define		V7AI_ISSA_INTERN500mV_100		((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN500mV_0) + V7AI_INTERN_CENTRE) ///< Gain 2
#define		V7AI_ISSA_INTERN250mV_100		((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN250mV_0) + V7AI_INTERN_CENTRE) ///< Gain 4
#define		V7AI_ISSA_INTERN100mV_100		((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN100mV_0) + V7AI_INTERN_CENTRE) ///< Gain 8
#define		V7AI_ISSA_INTERN50mV_100		((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN50mV_0) + V7AI_INTERN_CENTRE) ///< Gain 16
#define		V7AI_ISSA_INTERN25mV_100		((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN25mV_0) + V7AI_INTERN_CENTRE) ///< Gain 32
#define		V7AI_ISSA_INTERN10mV_100		((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN10mV_0) + V7AI_INTERN_CENTRE) ///< Gain 64
#define		V7AI_ISSA_INTERN5mV_100			((V7AI_INTERN_CENTRE - V7AI_ISSA_INTERN5mV_0) + V7AI_INTERN_CENTRE) ///< Gain 128
// Intern values for AO card
#define		V7AI_INTERNAO0mA_0			0x0								///< Minimum output of AO card
#define		V7AI_INTERNAO4mA_0			((V7AI_INTERNAO24mA_100 / 24) * 4 )	///< 4mA output
#define		V7AI_INTERNAO24mA_100		0xffff							///< Maximum output of AO card
#define		V7AI_INTERNAO21mA_100		((V7AI_INTERNAO24mA_100 / 24) * 21 )	///< Maximum output that should ever be asked for from the software
#define		V7AI_INTERNAO20mA_100		((V7AI_INTERNAO24mA_100 / 24) * 20 )
/********************************************************************
 * Global variables
 ********************************************************************/
// none defined here
#endif	// ndef V6IOPROTOCOL_H
// -------------------- end of V6IOProtocol.h --------------------- //	
//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		RTDataServer
/// @n Filename:  CSecureSocket.h
/// @n Description: Implementation of the CSecureSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
//-----------------------------------------------------------------------------
#ifndef __SECUREQAbstractSocket_H_
#define __SECUREQAbstractSocket_H_
#pragma once
#include <stdlib.h>
#include <QMutex>
#include <QAbstractSocket>
#include "containers.h"
#include<map>
#include <stdio.h>
#define DFL_SECURE_SOCK_DBG_ENABLE 1
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
#include "CStorage.h"
#endif
//Indicates the max number of clients that
//can be connected at a time
const int MAX_CLIENTS_CONNECTED = 5;
typedef struct clientInfo {
	QAbstractSocket s;
	float min;
	float max;
	float average;
	double timestamp;
} CLIENT_INFO;
//This map holds the client info
//typedef std::map<QAbstractSocket,struct _SecHandle>CLIENT_INFO_MAP;
//typedef std::map<QAbstractSocket,int>CLIENT_INFO_MAP;
//typedef struct
//{
// QAbstractSocket socket;
// struct _SecHandle;
//}QAbstractSocket_INFO;
typedef std::map<QAbstractSocket, struct _SecHandle> QAbstractSocket_INFO_MAP;
//typedef std::map<int,QAbstractSocket_INFO_MAP>CLIENT_INFO_MAP;
typedef std::map<int, QAbstractSocket_INFO_MAP::iterator> CLIENT_INFO_MAP;
typedef std::map<int, PBYTE> DATA_BUFFER_MAP;
class CSecureSocket {
public:
	//Constructor
	CSecureSocket();
	//Destructor
	~CSecureSocket();
	//AcceptAuthSocket
	BOOL AcceptAuthSocket(UINT LocalPort, int maxConn);
	//Disconnect socket
	void Disconnect(QAbstractSocket s, int clientId);
	//Receive bytes for authentication
	BOOL ReceiveBytes(PBYTE pBuf, DWORD cbBuf, DWORD *pcbRead, QAbstractSocket socket);
	//Perform the client authentication
	BOOL DoAuthentication(QAbstractSocket AuthSocket, CredHandle &hCred, struct _SecHandle &hCtxt);
	//Receive message from the client
	BOOL ReceiveMsg(PBYTE pBuf, DWORD cbBuf, DWORD *pcbRead, QAbstractSocket socket);
	//Generate the security server context
	BOOL GenServerContext(BYTE *pIn, DWORD cbIn,/*SecBuffer& OutSecBuff,*/DWORD *pcbOut, BOOL *pfDone,
			BOOL fNewConversation, CredHandle &hCred, struct _SecHandle &hCtxt, BYTE *pOut);
	//Send the message to the client
	BOOL SendMsg(PBYTE pBuf, DWORD cbBuf, QAbstractSocket socket);
	//Send data bytes for authentication to the client
	BOOL SendBytes(PBYTE pBuf, DWORD cbBuf, QAbstractSocket socket);
	//Create the server credentials
	SECURITY_STATUS CreateCredentials(LPSTR pszUser, CredHandle &hCred, struct _SecHandle &hCtxt);
	//Send the encrypted data to the client
	DWORD SendEncrypt(PBYTE pbIoBuffer, int len, QAbstractSocket socket, struct _SecHandle hCtxt);
	//Decrypt the data
	SECURITY_STATUS Decrypt(QAbstractSocket Socket, PCredHandle phCreds, CtxtHandle *phContext, PBYTE pbIoBuffer,
			DWORD cbIoBufferLength, DWORD cbData, DWORD cbIoBuffer, int &datalength, int clientId);
	//! Accepts an incoming connection request.
	/*! Accepts an incoming connection request. You can refuse or accept it.
	 * If refused the serviceSocket will be automatically closed. If
	 * accepted you must create a new (subclassed) CCESocket class and call
	 * its AcceptServiceSocket. The new class will be already connected and
	 * can be used to send and receive data.
	 * @param[in] serviceSocket This is the socket that was connected with
	 *  the remote client. Pass it to AcceptServiceSocket.
	 * @return Return FALSE if you don't accept the connection.
	 */
	virtual bool OnAccept(QAbstractSocket serviceSocket) {
		return FALSE;
	}
	//Start the thread
	static DWORD WINAPI StartThread(LPVOID pParam);
	//This thread accepts the incoming connections
	void AcceptThread();
	//This thread reads the data from the client
	void ReadThread();
	//! Received data notification.
	/*! If you refused the first OnReceive notification (probably because
	 * you didn't implemented it) you'll receive this call. Now you can
	 * access to the data through a data access function.
	 * @remarks You are on a different thread here so pay attentions. MFC
	 *  objects cannot be passed among threads. Make something
	 *  with the data and then send a message to the main thread or
	 *  make something else that will not hurt MFC.
	 */
	virtual void OnReceive(int clientId, int buffLength, QAbstractSocket socket, struct _SecHandle hCtxt) {
	}
	//Read the buffer
	void ReadBuffer(int clientId, PBYTE &buff);
	//Adds the client info and the security context handle to
	//a map
	int AddClientInfo(QAbstractSocket socket, struct _SecHandle hCtxt);
	//Clears the client info from the map
	void ClearClientInfo(QAbstractSocket s, int clientId);
	CLIENT_INFO_MAP GetClientInfo();
	void StartReadThread();
	BOOL Authenticate(CredHandle &hCred, struct _SecHandle &hCtxt, QAbstractSocket socket);
	void ClearBuffer(int clientId);
protected:
	virtual void OnUpdateClientInfo(int nClientId, BOOL bIsConnected) {
	}
	;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	static void LogDebugMessage(QString strDebugMessage);
#endif
public:
	virtual BOOL Accept() {
		return FALSE;
	}
	//Sends the data to the client over secure socket connection
	virtual const bool SendData(int clientId, PBYTE data, int len) {
		return false;
	}
protected:
	//Handle to the read thread
	HANDLE m_readThread;
	//Handle to the accept thread
	HANDLE m_acceptThread;
	enum threadState {
		CLOSED = 0, CLOSING, RUNNING
	};
	enum socketState {
		NONE = 0, DISCONNECTING, CREATED, CONNECTED, ACCEPTING
	};
private:
	QAbstractSocket s;
	WSADATA wsaData;
	QMutex m_csClosedown;
	static QMutex m_readLock;	//!< Controls read buffer access.
	socketState m_socketState;
	bool m_bWSAStarted;
	threadState m_acceptThreadState;
	QMutex m_csSocket;
	//Instance of client map
	CLIENT_INFO_MAP m_clientInfoMap;
	//Instance of socket info map
	QAbstractSocket_INFO_MAP m_socketInfoMap;
	//Instance of Data Buffer Map
	DATA_BUFFER_MAP m_DataBufferMap;
	//Instance of socket
	QAbstractSocket m_sockClient;
#ifdef DFL_SECURE_SOCK_DBG_ENABLE
	static CDebugFileLogger m_debugFileLogger;
#endif
};
#endif

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 General
/// @n Filename: SysInfo.h
/// @n Desc:	 Consilidate all system information for V6 device
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  76  Stability Project 1.73.1.1 7/2/2011 5:01:58 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  75  Stability Project 1.73.1.0 7/1/2011 4:27:29 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  74  V6 Firmware 1.73 9/14/2010 11:47:18 AM  Vivek (HAIL)  
//  Revert Code merge For Replay at faster speed
//  73  V6 Firmware 1.72 9/10/2010 5:55:49 PM  Vivek (HAIL)  
//  Code meryge for Replay at fast speed
// $
//
// ****************************************************************
#ifndef __SYSINFO_H__
#define __SYSINFO_H__
#include "V6defines.h"
#include "PassiveModule.h"
//#include "DevCaps.h"
#include "OEMInfo.h"
#include "NVVariables.h"
#include "flash.h"
#include "OptionsCode.h"
#include <QMap>
#include "MediaUtils.h"
#include "V6Versions.h"
#include "V6ResConstants.h"
#include <QMutex>
#include <QListView>
#include "BoardManager.h"
#include "V6types.h"
#include "V6Config.h"
#include "Conversion.h"
const USHORT SESSION_RESET_NUMBER = 1;				///< Reset value of session number
const USHORT SESSION_INCREMENT = 1;					///< Increment value of session number
const USHORT SESSION_ELEMENT = 0;					///< Element used in COMBO_VAR4 union for session number NV
const int RESET_ACTION_STARTUP = 0;					///< Actions to perform on startup
const int RESET_ACTION_CFG_CHANGE = 1;				///< Actions to perform on config change
const float RECORDER_TEMP_MAX_INVALID = -1000;		///< Recorder max temp rogue value if never been used
const float RECORDER_TEMP_MIN_INVALID = 1000;		///< Recorder min temp rogue value if never been used
const ULONG MANUFACTURING_MODE_IDENT = 0xA5BD0782;	///< Manufacturing mode ident
const ULONG HOTSOAKTEST_MODE_IDENT = 0x50AC7E57;	///< Hot Soak Test mode ident
const ULONG START_MODE_NORMAL = 0;					///< Start mode normal
const ULONG START_MODE_DATA_RESET = 0xFD19A7B2;		///< Start mode with Data reset
// Maths firmware options settings
typedef enum {
	MATH_OPTION_BASIC_BLOCK = 0,			///< Allow a very single line maths block with basic operators + - * / etc..
	MATH_OPTION_FULL_BLOCK,					///< Allow a single line maths block with all operators and functions
	MATH_OPTION_FULL_SCRIPT					///< Allow full scripting
} T_MATH_TYPE_OPTION;
//Demo board possibilities
typedef enum {
	DEMOBRD_NEVER = 0,						///< Never show a demo board
	DEMOBRD_SUBSTITUTE,						///< Substitue demo board if physical board not fitted
	DEMOBRD_OVERRIDE						///< Always use demo board, even if physical IO board fitted
} T_DEMO_BOARD_SETTINGS;
typedef enum {
	DATA_RESET_NOT_SET = 0, DATA_RESET_AUTO_SET, DATA_RESET_USER_SET, DATA_RESET_MAX,
} T_DATA_RESET_TYPE;
////////////////////////////////////////////////////////////////////
// Device identity record.
//
// Used to maintain a copy of important data on the internal SD card,
// can also be used to track recorder swap-out (if required).
typedef struct {
	unsigned long ulSerialNumber;			// Serial number
	unsigned short usSessionNumber;			// Recording session number
	// *** Add but never remove or change order 
//	unsigned long ulMACAddress;			// Ethernet MAC address
//	unsigned short usRecorderNumber;		// Recorder ID number
//	T_TV5TIME	  UpdateTime;				// Time last updated
	USHORT crc;						// File checksum
} T_IDENTITY;
typedef struct {
	// Together the date and rig number of first test is the GUID of any I/O board
	ULONG TimeDateOfFirstTest;				///< Date and time that first upload of software occurred
	UCHAR RigNoOfFirstTest;					///< Rig number that performed first test on board
} T_BRD_SERIAL_NUMBER;
// Information we want to keep as static BUT that is not important if erased
typedef struct {
    QString UpgradeFrom;///< Version we upgraded from, if this is not empty a firmware upgrade has been performed.
	ULONG ConfigVersion;							///< Configuration version, will differ on upgrade if config changes
	ULONG ChartSpeed[LAYOUT_SCREENLIST_SIZE];///< Chart speed index as ULONG bitfield (2 bits per chart, with up to 16 charts per screen)
	T_BRD_SERIAL_NUMBER SlotCardSerialNos[MAXIOCARDS];	///< Serial numbers for each card slot
	ULONG ManufacturingMode;				///< if set to MANUFACTURING_MODE_IDENT, then manufacturing mode will be set
	ULONG PowerOnAction;								///< Action to perform on power on
	ULONG HotSoakTestMode;					///< if set to HOTSOAKTEST_MODE_IDENT, then Hot Soak Test mode will be set
	ULONG ReplayChartSpeed;			///< screen speed index as ULONG bitfield (2 bits per screen, with up to 32 screen)
									/// CR: 3151 Replay at Faster speed
} T_GENERAL_STATIC;
typedef enum {
	SS_INITIAL_BOOT,						/// any items added here MUST have a corresponding string
	SS_INIT_HW,								/// in the SS_STARTUP_STRINGS in OpPanel
	SS_SYS_INTEGRITY,
	SS_LOAD_CONFIGS,
	SS_START_MODULES,
	MAX_STARTUP_SECTIONS
} T_STARTUP_SECTIONS;
const UCHAR MAX_ACTION_CHARS = 100;
typedef enum {
	FUNC_PROTECT_PRODUCTION,				///< Allows access to the production menu 
	FUNC_PROTECT_DIAGNOSTICS,				///< Allows acces to diagnostics pages
	FUNC_FACTORY_RESET,						///< Perform a factory reset (encoded and deleted after use)
	FUNC_DATA_RESET,						///< Perform a Data reset 
	FUNC_RESET_LITHLIFE,					///< Reset the lithium life on a battery change
	FUNC_RESET_BACKLIGHTLIFE,				///< Reset the backlight life on a backlight replacement
	FUNC_PRODUCTION_RESET,					///< Perform a production reset
	FUNC_PROTECT_CAL_TOUCH_SCREEN,			///< Allow touch screen calibration on SCREEN button
	FUNC_ENTER_MFR_MODE,					///< Enter Manufacturing mode
	FUNC_EXIT_MFR_MODE,						///< Exit Manufacturing mode
	FUNC_ENTER_HOTSOAKTEST_MODE,			///< Enter Hot Soak Test mode
	FUNC_EXIT_HOTSOAKTEST_MODE,				///< Exit Hot Soak Test mode
	FUNC_TUS_TEST_MODE,						///< TUS specific test mode, relaxes timings for test and demo's
	FUNC_15SECS_CORRECTIONTIME,
	FUNC_30SECS_CORRECTIONTIME,
	FUNC_45SECS_CORRECTIONTIME
} T_FUNCTION_PROTECTION;
// Recorder Secure Zones
typedef enum {
	REC_SEC_ZONE_SAFE = 0,		///
	REC_SEC_ZONE_PWD,			///
	REC_SEC_ZONE_END,			///
} T_REC_SEC_ZONE;
///////////////////////////////////////////////////////////////////////////////
// fields used to construct the recorder model number (see 43-TV-16-10 Issue Q)
#define SEPERATOR	L"-"
// I/O cards
#define NO_CARD		(WCHAR)'0'
#define AI_3		(WCHAR)'3'
#define AI_4		(WCHAR)'4'
#define AI_6		(WCHAR)'6'
#define AI_8		(WCHAR)'8'
#define PI_4		(WCHAR)'P'
#define AO_2		(WCHAR)'A'
#define AO_4		(WCHAR)'B'
#define AR_4		(WCHAR)'1'
#define AR_8		(WCHAR)'2'
#define DIO_8		(WCHAR)'3'
#define DIO_16		(WCHAR)'4'
#define EZ_COMMS	(WCHAR)'U'
// Product keys
#define QX_KEY		L"TVMIQX"
#define SX_KEY		L"TVMUSX"
#define EX_KEY		L"TVEZQX"
#define NEW_QX_KEY	L"TVMIGR"
#define NEW_SX_KEY	L"TVMUGR"
#define NEW_EX_KEY	L"TVEZGR"
//SCR Support
#define SCR_DRG2_KEY L"TVDRG2"
// Mains filter frequency
#define MAINS_50HZ	(WCHAR)'1'
#define MAINS_60HZ	(WCHAR)'2'
// Manual language
#define LANGUAGE_ENGLISH	(WCHAR)'U'
#define LANGUAGE_FRENCH		(WCHAR)'F'
#define LANGUAGE_GERMAN		(WCHAR)'G'
// Internal Compact Flash size
//#define INT_CF_128			(WCHAR)'0'
//#define INT_CF_256			(WCHAR)'1'
//#define INT_CF_512			(WCHAR)'2'
//#define INT_CF_1GIG			(WCHAR)'3'
//#define INT_CF_2GIG			(WCHAR)'4'
//PSR fix for - 1-3I2G538 PU_Front SD and Internal SD combinations in MSG are not handled in Production Tool begin
//Below options should be updated whenever model section guide is modified
//Correcting the Memory options accroding to MSG
//ToDo: Better read this configuration from ini or xml and make it configurable
#define INT_SD_128			(WCHAR)'0'	//128MB Not supported in GR Recorder as per MSG
#define INT_SD_1GIG			(WCHAR)'0'	//(WCHAR)'1'	//1GB is metioned as option '0'
#define INT_SD_2GIG			(WCHAR)'1'	//(WCHAR)'2'
#define INT_SD_4GIG			(WCHAR)'2' //(WCHAR)'3' //Not supported for EzTrend GR
#define INT_SD_8GIG			(WCHAR)'3' //(WCHAR)'4' //8GB also not supported in GR (for now)
//Get the External Memory (SD) card size as we have MSG options for 8GB External(Front) SD
//For EzTrend only back SD with 1 & 2 GB are available
#define INT_SD_1GB_EXT_SD_8GB	(WCHAR)'3' //New option avaliable in GR MSG for SX and QX
#define INT_SD_2GB_EXT_SD_8GB	(WCHAR)'4' //New option avaliable in GR MSG for SX and QX
#define INT_SD_4GB_EXT_SD_8GB	(WCHAR)'5' //New option avaliable in GR MSG for SX and QX
#define INT_SD_NOT_SUPPORTED	(WCHAR)'9' //This should be changed whenever MSG updated
//PSR fix for - 1-3I2G538 PU_Front SD and Internal SD combinations in MSG are not handled in Production Tool end
// EzTrend Expansion Card
#define EZ_EXPANSION_CARD	(WCHAR)'1'
#define EZ_COMMS_CARD		(WCHAR)'U'
//TM - Specifically added here so that unnecessary dialogs are not 
//included in the XSeries DLL Code
typedef void (WINAPI *glbpStatusListInitFunc)(QListView &rkStatusListCtrl, QString &rstrUserDefBtn1Title,
		QString &rstrUserDefBtn2Title);
void WINAPI OptionsInitFunc(QListView &rkStatusList, QString &rstrUserDefBtn1Title, QString &rstrUserDefBtn2Title);
//**Class*********************************************************************
///
/// @brief V6 System Info
/// 
/// Provide all general information on system
///
//****************************************************************************
class CSysInfo: public CPassiveModule {
public:
	static CSysInfo* GetHandle();
	void CleanUp();
	/// Enumerated list containing the firmware options
	enum T_FIRMWARE_OPT {
		fwoMathsFullBlock,
		fwoMathsFullScript,
		fwoEvents,
		fwoFastScan,
		fwoTotals,
		fwoCustomScrn,
		fwoReports,
		fwoNADCAPRecorder,
		fwoMaintenance,
		fwoPrintSupport,
		fwoTUSMode,
		fwoControlLoops,
		fwoBatch,
		fwoCounters,
		//fwoGroups, removed and now tied into batch
		fwoModbusMaster,
		fwoRemoteViewer,
		fwoTrendBus,
		fwoEmail,
		fwoOPC,
		fwoPwdNetSync,
		fwoExtSD,
		fwoSecureWSD,
		fwoExtraPens,
		fwoRTDataBus,
		fwoHWLock,
		fwoOpcUaServer,
		// insert more firmware options here********
		fwoTotalCredits, // keep at the end of the firmware options list - fwoNoneRequired not relevant
		fwoNoneRequired
	};
	// Variable indicating how many pens are gained per credit
	static const USHORT ms_usNO_PENS_PER_CREDIT;
private:	// Singleton
	CSysInfo();
	~CSysInfo() {
		m_kFWOptWeightMap.clear();
	}
	;	// Will never be called
	CSysInfo(const CSysInfo&);
	CSysInfo& operator=(const CSysInfo&) {
		return *this;
	}
	;
	static CSysInfo *m_pV6SystemInfoInstance;
	static QMutex m_CreationMutex;
	// Map containing the firmware option credit weights
	QMap<T_FIRMWARE_OPT, USHORT> m_kFWOptWeightMap;
	/// Variable indicating the current AMS2750 mode
	T_AMS2750_MODE m_eAMS2750Mode;
    void IncludeTCCal();
    void ExcludeTCCal();
public:		// API
	BOOL Initialise();
	// Session numbers
	const USHORT RollSessionNumber();
	const USHORT GetSessionNumber() {
		return m_sessionNumber.us[SESSION_ELEMENT];
	}
	;	///< runtime session number
	void SetSessionNumber(USHORT newSessionNumber);										///< Set the new session number
	DWORD GetNextSessionNumber() {
		return m_nextSessionNumber;
	}
	;				///< Return next session number 
	DWORD* GetNextSessionNumberPtr() {
		return &m_nextSessionNumber;
	}
	;				///< Return pointer to next session number used by CMM (in CreateCMMHolder)
	// API to access firmware options
	T_MATH_TYPE_OPTION FWOptionMathsType() {
		return static_cast<T_MATH_TYPE_OPTION>(m_GeneralNVCfg.FWOptions.MathsType);
	}
	;		// Maths type see T_MATH_TYPE_OPTION
	BOOL FWOptionEventsAvailable() {
		return m_GeneralNVCfg.FWOptions.Events;
	}
	;
	BOOL FWOptionFastScanAvailable() {
		return m_GeneralNVCfg.FWOptions.FastScan;
	}
	;
	BOOL FWOptionTotalsAvailable() {
		return m_GeneralNVCfg.FWOptions.Totals;
	}
	;
#ifdef DOCVIEW
	BOOL FWOptionCustomScreensAvailable()	{ return TRUE; };
#else
	BOOL FWOptionCustomScreensAvailable() {
		return m_GeneralNVCfg.FWOptions.CustomScreens;
	}
	;
#endif
	BOOL FWOptionReportsAvailable() {
		return m_GeneralNVCfg.FWOptions.Reports;
	}
	;
	BOOL FWOptionAMS2750ProcessAvailable() {
		return m_GeneralNVCfg.FWOptions.AMS2750Process;
	}
	;
	BOOL FWOptionMaintenanceAvailable() {
		return m_GeneralNVCfg.FWOptions.Maintenance;
	}
	;
	BOOL FWOptionPrintSupportAvailable() {
		return m_GeneralNVCfg.FWOptions.PrintSupport;
	}
	;
	BOOL FWOptionTUSModeAvailable() {
		return m_GeneralNVCfg.FWOptions.AMS2750TUS;
	}
	;
	USHORT FWOptionControlLoopsAvailable() {
		return m_GeneralNVCfg.FWOptions.ControlLoops;
	}
	;		// Number of control loops
	BOOL FWOptionBatchAvailable() {
		return m_GeneralNVCfg.FWOptions.Batch || m_GeneralNVCfg.FWOptions.AMS2750Process;
	}
	;
	BOOL FWOptionCountersAvailable() {
		return m_GeneralNVCfg.FWOptions.Counters;
	}
	;
	BOOL FWOptionModbusMasterAvailable() {
		return m_GeneralNVCfg.FWOptions.ModbusMaster;
	}
	;
	BOOL FWOptionModbusSlaveAvailable() {
		return TRUE;
	}
	;
	BOOL FWOptionRemoteViewerAvailable() {
		return m_GeneralNVCfg.FWOptions.RemoteView;
	}
	;
	BOOL FWOptionTrendBusAvailable() {
		return m_GeneralNVCfg.FWOptions.TrendBus;
	}
	;
	BOOL FWOptionEmailAvailable() {
		return m_GeneralNVCfg.FWOptions.Email;
	}
	;
	BOOL FWOptionPasswordCFRAvailable() {
		return m_GeneralNVCfg.FWOptions.PasswordCFR;
	}
	;
	//BOOL FWOptionSecureCommAvailable()		{ return m_GeneralNVCfg.FWOptions.SecureComm; };
	BOOL FWOptionOPCUAAvailable() {
		return m_GeneralNVCfg.FWOptions.OPCUA;
	}
	;
	BOOL FWOptionExtSDAvailable() {
		return m_GeneralNVCfg.FWOptions.ExtSD;
	}
	;
	BOOL FWOptionSecureWSDAvailable() {
		return m_GeneralNVCfg.FWOptions.SecureWSD;
	}
	;
	BOOL FWOptionOpcUaServerAvailable() {
		return m_GeneralNVCfg.FWOptions.OPCUA;
	}
	;
	BOOL FWOptionRTDataBusAvailable() {
		return m_GeneralNVCfg.FWOptions.RTDataBus;
	}
	;
	BOOL FWOptionHWLockAvailable() {
		return m_GeneralNVCfg.FWOptions.HWLock;
	}
	;
#ifdef NO_PASSWORD_NET
	BOOL FWOptionPasswordsSyncAvailable()	{ return FALSE; };
#else
	BOOL FWOptionPasswordsSyncAvailable() {
		return m_GeneralNVCfg.FWOptions.PasswordsSync;
	}
	;
#endif
	ULONG FWOptionExtraPensAvailable() {
		return m_GeneralNVCfg.FWOptions.ExtraPens;
	}
	;
	BOOL FWOptionPasteurisationAvailable() {
		return m_GeneralNVCfg.FWOptions.Pasturisation;
	}
	;
	BOOL ArePasswordsEnabled() {
		return m_PasswordsEnabled;
	}
	;
	void SetPasswordsEnabled(BOOL bEnable) {
		m_PasswordsEnabled = bEnable;
	}
	;
	// Accessors for the OEM text 
    const WCHAR* GetOEMCompanyName() {
		return pOemInfo->GetText(V6RES_TEXT_CONAME)->szTextValue;
	}
	;
    const WCHAR* GetOEMProductRangeName() {
		return pOemInfo->GetText(V6RES_TEXT_PRODGRPNAME)->szTextValue;
	}
	;
    const WCHAR* GetOEMComapnyWebAddress() {
		return pOemInfo->GetText(V6RES_TEXT_WEBADDR)->szTextValue;
	}
	;
    const WCHAR* GetOEMComapnyemail() {
		return pOemInfo->GetText(V6RES_TEXT_EMAIL)->szTextValue;
	}
	;
    const WCHAR* GetOEMDeviceName();
	// Product build info structure
	BOOL BuildProductionInfo();							/// Update the general NV production info record
	BOOL BuildProductionInfo(T_PRECPROD pProductionInfo); /// Update the supplied production info record
	// Pen Availability Accessors
	BOOL ConfigurePens(void);
	const USHORT GetTotalPens() {
		return m_numAvailablePens;
	}
	;
	const BOOL IsPenAvailable(USHORT PenNumber, T_PENBASE base);
	void SetPenAvailable(USHORT penNumber, T_PENBASE base, BOOL available);
	// Localisation temperature units
	T_TEMP_UNIT GetDisplayTempUnits() {
		return static_cast<T_TEMP_UNIT>(m_GeneralNVCfg.Localisation.Tempasprintf);
	}
	;
	float GetLocalTempFromDegC(float degCTemp) {
		return TempFromDegC(GetDisplayTempUnits(), degCTemp, CONVERT_ABSOLUTE);
	}
	;
	float GetDegCTempFromLocal(float localTemp) {
		return TempToDegC(GetDisplayTempUnits(), localTemp, CONVERT_ABSOLUTE);
	}
	;
	float GetLocalTempFromDegCRelative(float degCTemp) {
		return TempFromDegC(GetDisplayTempUnits(), degCTemp, CONVERT_RELATIVE);
	}
	;
	float GetDegCTempFromLocalRelative(float localTemp) {
		return TempToDegC(GetDisplayTempUnits(), localTemp, CONVERT_RELATIVE);
	}
	;
	// Accessor for the profile configuration
	void SetProfileConfig(T_PRECPROFILE pProfile) {
		m_pProfileCfg = pProfile;
	}
	T_PRECPROFILE GetProfileConfig() {
		return m_pProfileCfg;
	}
	void SetGeneralConfig(T_PGENERALCONFIG pGeneral) {
		m_pGeneralCfg = pGeneral;
	}
	;
	T_PGENERALCONFIG GetGeneralConfig() {
		return m_pGeneralCfg;
	}
	;
	T_PRESETACTIONS GetStartupResetAction() {
		return &m_pGeneralCfg->ChangeAction[RESET_ACTION_STARTUP];
	}
	;
	T_PRESETACTIONS GetConfigChangeResetAction() {
		return &m_pGeneralCfg->ChangeAction[RESET_ACTION_CFG_CHANGE];
	}
	;
	// Accessor for the non-volatile factory information
	T_PGENNONVOL GetFactoryConfig() {
		return &m_GeneralNVCfg;
	}
	//Accessor for the number of blocks per file
	void SetNumBlocksPerFile(USHORT NumBlocks) {
		m_NumBlocksPerFile = NumBlocks;
	}
	USHORT GetNumBlocksPerFile() {
		return m_NumBlocksPerFile;
	}
	void SetNumCreatedFiles(USHORT NumFiles) {
		m_NumOfCreatedFiles = NumFiles;
	}
	USHORT GetNumCreatedFiles() {
		return m_NumOfCreatedFiles;
	}
	void SetNumDataBlocks(USHORT numBlocks) {
		m_NumNVDataBlocks = numBlocks;
	}
	USHORT GetNumDataBlocks() {
		return m_NumNVDataBlocks;
	}
	ULONG GetPowerCycles() {
		return m_PowerCycles.ul;
	}
	;
	// Method that intialises the map containing the firmware option weightings
	void InitFWOptWeights();
	// Method used to validate the factory firmware options
	bool ValidateFWOptions(const CSysInfo::T_FIRMWARE_OPT eREQ_CREDIT_TYPE, USHORT &rusCreditsInUse,
			const ULONG ulNO_OF_PENS = 0) const;
	// Method that validates an encoded options code
	bool ValidateOptionsCode(const QString pwcOptionsCode);
	// Method that obtains information about a particular firmware option
	const USHORT GetOptionInfo(const T_FIRMWARE_OPT eOPTION_TYPE, QString &rstrOptionTitle,
			USHORT &rusNoOfCredits) const;
	// Production interface
	T_RECPROD GetProductionInfo() {
		return m_GeneralNVCfg.ProductionInfo;
	}
	;
	void SetProductionInfo(T_PRECPROD pProdInfo);
	void PostUnitConfigurationMode();												// do any post configuration stuff
	void SetUnitIntoTestMode() {
		PostUnitConfigurationMode();
	}
	;			// run the post configuration mode stuff
	BOOL NVSaveToFlash();
	T_FLASH_STATUS NVLoadfromFlash();
	const ULONG GetSerialNumber() {
		return m_GeneralNVCfg.SerialNumber;
	}
	;
	void SetSerialNumber(ULONG newSerial);
	void ReGenerateOptionsCode();
	// Firmware upgrading and status 
	void InstallFirmwareUpgrade();
    const QString GetPreviousFWVersion() {
		return m_staticInfo->UpgradeFrom;
	}
	;
	const QString GetCurrentFWVersion() {
		return V6_VERSION;
	}
	;
	void SetPreviousFWVersion(const QString ver) {
        m_staticInfo->UpgradeFrom = ver;
	}
	;
	void ClearFWUpgradesStatus() {
		m_staticInfo->UpgradeFrom[0] = 0;
	}
	;
	BOOL IsFirmwareUpgraded() {
		return m_FirmwareUpgraded;
	}
	;
	// Firmware 
	BOOL IsFunctionAvailable(T_FUNCTION_PROTECTION functionalArea, BOOL removeFileAfterCheck = FALSE);
	const QString GeneratePWEncodedFilename(QString pFileNamePrefix);
	// Method used to get a particular charts speed
	const ULONG GetChartSpeed(const USHORT usCHART_NO, const USHORT usSCREEN_NO) const;
	// Method used to get replay charts speed for a particular screen
	/// CR: 3151 Replay at Faster speed
	const ULONG GetReplayChartSpeed(const USHORT usSCREEN_NO) const;
	// Method used to get/set a particular board serial number in a recorder slot
	void GetSlotCardSerialNo(const USHORT usSlotNo, ULONG &usFirstTest, UCHAR &ucRigNo);
	void SetSlotCardSerialNo(const USHORT usSlotNo, const ULONG usFirstTest, const UCHAR usRigNo);
	// Method used to set a particular charts speed
	void SetChartSpeed(const USHORT usCHART_NO, const USHORT usSCREEN_NO, const USHORT usSPEED);
	// Method used to set replay charts speed for a particular screen
	/// CR: 3151 Replay at Faster speed
	void SetReplayChartSpeed(const USHORT usSCREEN_NO, const USHORT usSPEED);
	CSoftwareUpdate* SoftwareUpdater() {
		return &m_SoftwareUpdate;
	}
	;
	///Startup screen functions
	void SetStartupSection(T_STARTUP_SECTIONS Section) {
		m_CurrStartupSection = Section;
	}
	T_STARTUP_SECTIONS GetStartupSection() {
		return m_CurrStartupSection;
	}
	void SetStartupAction(const QString wcsAction) {
		wcsAction.toWCharArray(m_wcsAction);
	}
	WCHAR* GetStartupAction() {
		return m_wcsAction;
	}
	void SetStartupSubAction(const QString wcsSubAction) {
		wcsSubAction.toWCharArray(m_wcsSubAction);
	}
	WCHAR* GetStartupSubAction() {
		return m_wcsSubAction;
	}
	void AddStartupErr(LPCTSTR str);
	const QString GetStartupErrList();
	void SetStartupLanguageValid(void) {
		m_bLangValid = TRUE;
	}
	;
	USHORT GetValidLanguage() {
		if (m_bLangValid)
			return m_GeneralNVCfg.Language;
		else
			return 0xFFFF;
	}
	;
	void RegisterNewCJCValue(float cjcjInDegC);
	float GetRecorderMaxTempEver() {
		return m_CJCMax.flt;
	}
	;
	float GetRecorderMinTempEver() {
		return m_CJCMin.flt;
	}
	;
	void SetFactoryResetRequired() {
		m_FactoryReset = TRUE;
	}
	;
	BOOL IsFactoryResetRequested() {
		return m_FactoryReset;
	}
	;
	void SetDataResetRequired(T_DATA_RESET_TYPE eDataReset = DATA_RESET_AUTO_SET) {
		m_eDataReset = eDataReset;
	}
	;
	BOOL IsDataResetRequested();
	T_DATA_RESET_TYPE GetDataResetType() {
		return m_eDataReset;
	}
	;
	void SetManufacturingMode() {
		m_staticInfo->ManufacturingMode = MANUFACTURING_MODE_IDENT;
	}
	;				///< Set recorder into manufacturing mode
	void ClearManufacturingMode() {
		m_staticInfo->ManufacturingMode = 0;
	}
	;										///< Clear recorder from manufacturing mode
	BOOL IsInManufacturingMode() {
		return (m_staticInfo->ManufacturingMode == MANUFACTURING_MODE_IDENT);
	}
	;	///< Check for manufacturing mode
	void SetHotSoakTestMode() {
		m_staticInfo->HotSoakTestMode = HOTSOAKTEST_MODE_IDENT;
	}
	;				///< Set recorder into Hot Soak Test mode
	void ClearHotSoakTestMode() {
		m_staticInfo->HotSoakTestMode = 0;
	}
	;										///< Clear recorder from Hot Soak Test mode
	BOOL IsInHotSoakTestMode() {
		return (m_staticInfo->HotSoakTestMode == HOTSOAKTEST_MODE_IDENT);
	}
	;	///< Check for Hot Soak Test mode
	// AMS2750 TC/RT Calibration exclude accessors
	BOOL AMS2750SensorCalIsExcluded() {
		return ((BOOL) m_TCCalAdjustExclude.ul);
	}
	;
	void ExcludeAMS2750SensorCal();
	void IncludeAMS2750SensorCal();
	ULONG GetStartMode() {
		return m_staticInfo->PowerOnAction;
	}
	;
	void SetStartMode(ULONG startMode) {
		m_staticInfo->PowerOnAction = startMode;
	}
	;
	// Accessor for the current AMS2750 mode
	const T_AMS2750_MODE GetAMS2750Mode() const {
		return m_eAMS2750Mode;
	}
	// Accessor for the current AMS2750 mode
	VOID SetAMS2750Mode(const T_AMS2750_MODE eAMS2750Mode) {
		m_eAMS2750Mode = eAMS2750Mode;
	}
	BOOL IsSecureWSDEnabled();
	//Fix for PAR #1-3ENG3D7 - Code refactoring for Hardware lock fix RecSetupCfgMgr.cpp
	BOOL IsHWLockCommited() {
		return (TRUE == m_uiHWLockCommited);
	}
	BOOL IsRecorderInSafeZone();
	void SetRecSecurityZone(T_REC_SEC_ZONE eRecSecZone);
	T_REC_SEC_ZONE GetRecSecurityZone();
	//BOOL UserInFullMode();
	void SetRemoteUserGotControl(SHORT eRemoteUsrCntrl);
	SHORT GetRemoteUserControl();
	SHORT PreviouslyRemoteUserInCntrl();
private:	// Methods
	BOOL GetIdentity();
	BOOL SetIdentity();
	void ResetSequenceNumbers();
	void SetTotalPens(USHORT num) {
		m_numAvailablePens = num;
	}
	;
	BOOL TestFunctionAvailableFromDevice(T_FUNCTION_PROTECTION functionalArea, BOOL removeFileAfterCheck,
			storageDeviceIdent testDevice);
	//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. begin
	//Ex: strPath would be like "\\SDMemory2\Keys"
	BOOL RemoveKeysDirectory(QString strPath);
	//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. end
	// TC Calibration exclude accessors
	void SetTCCalExclude(BOOL exclude);
public:		// Members
	COEMInfo *pOemInfo;							///< Pointer to OEM information
private:	// Members
	CFlashManager *m_pFlash;					///< Handle on flash manager singleton
	T_GENNONVOL m_GeneralNVCfg;					///< Reference copy of General NV information
	BOOL m_GenNonVolChanged;					///< General non volatile information has changed.
	T_PRECPROFILE m_pProfileCfg;				///< Pointer to the current profile
	T_PGENERALCONFIG m_pGeneralCfg;				///< Pointer to the current General Configuration
    static QMutex m_SysInfoCS;				///< System info Critical section
	BOOL m_Initialised;							///< Guard duplicate initialisation
	BOOL m_penAvailable[V6_MAX_PENS];			///< Status if each Pen, TRUE if pen available for use, otherwise FALSE
	USHORT m_numAvailablePens;					///< Total number of availabler Pens
	COMBO_VAR4 m_sessionNumber;					///< Session reference number held in NV format
	DWORD m_nextSessionNumber;					///< The next available session number to be used in the CMM
	CNVBasicVar *m_pNVSessionNumber;			///< Session Number in NV
	T_IDENTITY m_IndentityInfo;					///< Disk based internal SD/Unit identity
	COptionCode m_OptionCode;					///< Option code cipher/decipher
	USHORT m_NumBlocksPerFile;					///< Number of data blocks per file
	USHORT m_NumOfCreatedFiles;
	USHORT m_NumNVDataBlocks;
	CSoftwareUpdate m_SoftwareUpdate;			///< Software Updating system	
	T_GENERAL_STATIC *m_staticInfo;				///< Pointer to static information, although NV not important
	CNVBasicVar *m_pNVPowerCycles;				///< NV pointer for Number of power cycles so far
	COMBO_VAR4 m_PowerCycles;					///< Number of power cycles so far
	CNVBasicVar *m_pNVCJCMin;					///< NV pointer for CJC minimum seen
	COMBO_VAR4 m_CJCMin;						///< Minimum CJC temperature seen
	CNVBasicVar *m_pNVCJCMax;					///< NV pointer for CJC maximum seen
	COMBO_VAR4 m_CJCMax;						///< Maximum CJC temperature seen
	T_STARTUP_SECTIONS m_CurrStartupSection;
	WCHAR m_wcsAction[MAX_ACTION_CHARS];
	WCHAR m_wcsSubAction[MAX_ACTION_CHARS];
	BOOL m_PasswordsEnabled;
	QString m_strErrList;
	BOOL m_bLangValid;
	BOOL m_FactoryReset;					///< Indicates if a factory reset is required
	T_DATA_RESET_TYPE m_eDataReset;						///< Indicates if a data reset is required
	BOOL m_FirmwareUpgraded;
	CNVBasicVar *m_pNVTCCalAdjustExclude;	///< NV pointer for TC Cal adjust exclusion
	COMBO_VAR4 m_TCCalAdjustExclude;	///< TC Cal adjust exclusion, False = TC cals included, True = TC Cals excluded
	//Fix for PAR #1-3ENG3D7 - Code refactoring for Hardware lock fix RecSetupCfgMgr.cpp
	//This variable indicates the status of HWLock(From FWOptions in COmmited config section)
	//This looks redundant datamemeber but without impacting the existing fulnctionlaity and usgae of pGlbSysInfo 9which seems to be modified 
	//when user changes configuration from UI gives modifiable value in CDeviceAbstraction::IsHardwareLockEnabled()
	//Update this variable during initialization and PostCommitProcessing of General section (General::Factory::Credits::FWOptions)
	UINT m_uiHWLockCommited;
	void setHWLockCommited(UINT uiHWLockCommited) {
		m_uiHWLockCommited = uiHWLockCommited;
	}
	T_REC_SEC_ZONE m_eRecSecZone;
	SHORT m_IsUserRemoteControl;
	SHORT m_PreviouslyRemoteUserInCntrl;
};
#endif

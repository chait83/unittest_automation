/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Error Control System
/// @n Filename:	ErrorControl.cpp
/// @n Description: Implementation for the CErrorControl class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 22	Stability Project 1.17.1.3	7/2/2011 4:57:05 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 21	Stability Project 1.17.1.2	7/1/2011 4:38:16 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 20	Stability Project 1.17.1.1	3/17/2011 3:20:23 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 19	Stability Project 1.17.1.0	2/15/2011 3:03:00 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include <memory>
#include "ErrorControl.h"
#include "StringUtils.h"
#include "StatusListDlg.h"
#include "StringUtils.h"
#include "TransferDevice.h"
#include "MediaManager.h"
#include "EventManager.h"
#include "BatteryManager.h"
#include <QWidget>
#include "StringDefinitions.h"
/// Static const/initialsation
std::auto_ptr<CErrorControl> CErrorControl::ms_kErrorControl;
QMutex CErrorControl::ms_hCreationMutex;
//****************************************************************************
// CErrorControl(void)
///
/// Constructor
///
//****************************************************************************
CErrorControl::CErrorControl() : m_usCJC_IN_ERROR_STATE_BYTE_POS(0), m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS(1), m_usTC_IN_ERROR_STATE_LONGLONG_POS(
		0), m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS(1), m_usNetSyncCountdown(60) {
	memset(m_kaERROR_TYPES, 0, sizeof(T_RECORDER_ERROR_INFO) * retMAX_ERROR_TYPES);
}
//****************************************************************************
// ~CErrorControl(void)
///
/// Destructor
///
//****************************************************************************
CErrorControl::~CErrorControl() {
	//deletion of mutex not required
}
//****************************************************************************
// CErrorControl* Instance()
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CErrorControl* CErrorControl::Instance() {
	// check if the pointer exists yet
	if (ms_kErrorControl.get() == NULL) {
		DWORD waitSingleObjectResult = WAIT_OBJECT_0;
		// An instance has yet to be completed
		waitSingleObjectResult = ms_hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == ms_kErrorControl.get()) {
				// not been created yet therefore create one now
				std::auto_ptr<CErrorControl> kErrorControl(new CErrorControl);
				ms_kErrorControl = kErrorControl;
			}
			//Fix for - 1-3E83LIM - QXe_Reset Setup observed with Error as "ErrorFailed to release_CErrorControlMutex"
			//Check for the NULL handle before attempt to release the mutex
			ms_hCreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
            V6WarningMessageBox(NULL, "CErrorControl WaitForSingleObject Error", "Error", MB_OK);
			break;
		}
		//Fix for -1-3E83LIM - QXe_Reset Setup observed with Error as "ErrorFailed to release_CErrorControlMutex"
		//Check for the NULL handle before attempt to close the mutex handle
	}
	return ms_kErrorControl.get();
}
//****************************************************************************
//	const bool GetHighestPriortyError(	QString &rstrMessage,
//										COLORREF &crBorderColour,
//										COLORREF &crBackgroundColour,
//										bool &rbFlashBorder,
//										T_RECORDER_ERROR_TYPES &reErrorType ) const
///
/// Method that returns the highest priority error information
///
/// @param[out]		QString &rstrMessage - The message to retrieve and display
/// @param[out]		COLORREF &crBorderColour - The border colour to display
/// @param[out]		COLORREF &crBackgroundColour - The background colour to display
/// @param[out]		bool &rbFlashBorder - Flag indicating if we should flash the border
/// @param[out]		T_RECORDER_ERROR_TYPES &reErrorType - The error type - required for ack purposes
///
/// @return True if a message was found
/// 
//****************************************************************************
const bool CErrorControl::GetHighestPriorityError(QString &rstrMessage, COLORREF &crBorderColour,
		COLORREF &crBackgroundColour, bool &rbFlashBorder, T_RECORDER_ERROR_TYPES &reErrorType) {
	// flag indicating we are displaying a message adn thus do not need to search any further
	bool bFoundMessage = false;
	// decrement the netsync countdown if not already zero
	if (m_usNetSyncCountdown != 0) {
		--m_usNetSyncCountdown;
	}
	// check the current error states of items handled by this class e.g. network cable unplugged errors
	CheckErrorStates();
	// loop through all the error conditions until we find one that is active - check the active ones first
	for (USHORT usCount = 0; usCount < retMAX_ERROR_TYPES; usCount++) {
		// check this error can be displayed
		if (DisplayError(static_cast<T_RECORDER_ERROR_TYPES>(usCount))) {
			if ((m_kaERROR_TYPES[usCount].bInErrorState) && (m_kaERROR_TYPES[usCount].bPending)) {
				// we have found an error therefore display it
				// get the message information
				rstrMessage = QString::fromWCharArray(m_kaERROR_TYPES[usCount].wcaErrorMessage);
				// set the error type
				reErrorType = static_cast<T_RECORDER_ERROR_TYPES>(usCount);
				bFoundMessage = true;
				break;
			}
		}
	}
	// if not found a message yet then loop through all the error conditions until we find one that is
	// non-active but still pending - only valid if the auto clear function is not active though
	T_PGENERALCONFIG ptGeneralData =
	pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	if (ptGeneralData != NULL) {
		if (!bFoundMessage) {
			if (ptGeneralData->ErrorControl.AutoClear == FALSE) {
				for (USHORT usCount = 0; usCount < retMAX_ERROR_TYPES; usCount++) {
					// check this error can be displayed
					if (DisplayError(static_cast<T_RECORDER_ERROR_TYPES>(usCount))) {
						if (m_kaERROR_TYPES[usCount].bPending) {
							// we have found an error therefore display it
							// get the message information
							rstrMessage = QString::fromWCharArray(m_kaERROR_TYPES[usCount].wcaErrorMessage);
							// set the error type
							reErrorType = static_cast<T_RECORDER_ERROR_TYPES>(usCount);
							bFoundMessage = true;
							break;
						}
					}
				}
			}
		}
		// may as well always setup the other information, even if we aren't going to
		// display a message
		crBorderColour = ptGeneralData->ErrorControl.BorderColour;
		crBackgroundColour = ptGeneralData->ErrorControl.BkgColour;
		// always flash the border for now - might go into the configuration one day
		rbFlashBorder = true;
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	return bFoundMessage;
}
//****************************************************************************
//	void CheckErrorStates()
///
/// Method that checks the error states of errors handled by this class e.g. network cable unplugged
/// 
//****************************************************************************
void CErrorControl::CheckErrorStates() {
	static int iUpdatePeriod = 0;
	++iUpdatePeriod;
	if (iUpdatePeriod >= 5) {
		// check the mac address is not set to the default
		CheckMACAddress();
		// check the serial number is not set to the default
		CheckSerialNo();
		// check the network cable state first
		CheckNetworkConnection();
		// check the internal memory state
		CheckIntMem();
#ifdef UNDER_CE
    // check the battery life of recorder
    CheckBatteryStatus();
#endif
		/// check the scheduled export device
		CheckSchedExportDev();
		CheckSchedExportDevMissing();
		// check the FTP memory
		CheckFTPMem();
		T_PGENERALCONFIG ptGeneralData =
		pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
		// check if reflash is enabled
		if ((ptGeneralData != NULL) && ptGeneralData->ErrorControl.EnableReflash) {
			// Check if CJC's errors need reflashing
			CheckCJCError();
			// Check if TC's errors need reflashing
			CheckTCError();
		} else if (ptGeneralData == NULL) {
#ifdef _DEBUG
    DebugBreak();
#endif
		}
		iUpdatePeriod = 0;
	}
}
//****************************************************************************
//	void CheckMACAddress()
///
/// Method that checks the mac address is not set to the default
/// 
//****************************************************************************
void CErrorControl::CheckMACAddress() {
	static const UCHAR ucaDEF_MAC_ADDR[6] = { 0x00, 0xD0, 0x6E, 0xFF, 0xFF, 0x06 };
	bool bDefMAC = (memcmp(ucaDEF_MAC_ADDR, pDALGLB->GetMACPtr(),
	BOARDDETAILS_MACADDRESS_SIZE) == 0);
	QString strErrorMessage("");
	// set the appropriate message depending on the current state
	if (!bDefMAC) {
		// don't bother with a past tense message - always auto clear this type of error as it should only
		// exist when the recorder is brand new
	} else {
		strErrorMessage = QWidget::tr("MAC Address Error!!!\r\n%s\r\nThe MAC address is set to default.");
	}
	UpdateErrorCondition(retDEF_MAC, bDefMAC, strErrorMessage);
}
//****************************************************************************
//	void CheckSerialNo()
///
/// Method that checks the serial number is not set to the default
/// 
//****************************************************************************
void CErrorControl::CheckSerialNo() {
	bool bDefSerial = (pGlbSysInfo->GetSerialNumber() == DEFAULT_SERIAL_NUMBER);
#ifndef UNDER_CE
	if (CEmulator::m_SimulatorVol[0])
		bDefSerial = FALSE; // don't flag this error if running simulation within screen designer
#endif 
	QString strErrorMessage("");
	// set the appropriate message depending on the current state
	if (!bDefSerial) {
		// don't bother with a past tense message - always auto clear this type of error as it should only
		// exist when the recorder is brand new
	} else {
		strErrorMessage = QWidget::tr("Serial Number Error!!!\r\n%s\r\nThe serial number is set to default.");
	}
	UpdateErrorCondition(retDEF_SERIAL, bDefSerial, strErrorMessage);
}
//****************************************************************************
//	void CheckNetworkConnection()
///
/// Method that checks the state of the network connection
/// 
//****************************************************************************
void CErrorControl::CheckNetworkConnection() {
	QString strErrorMessage("");
	const bool bLINK_OK = pDALGLB->IsNetworkRunning();
	// set the appropriate message depending on the current state
	if (bLINK_OK) {
		strErrorMessage = QWidget::tr(
				"Network Unavailable!!!\r\n%s\r\nThe network connection was temporarily unavailable.");
	} else {
		strErrorMessage = QWidget::tr(
				"Network Unavailable!!!\r\n%s\r\nThe network connection is currently unavailable.");
	}
	UpdateErrorCondition(retCABLE_UNPLUGGED, !bLINK_OK, strErrorMessage);
}
//****************************************************************************
//	Reports a failure that the Secondary Processor is not responding
///
/// 
//****************************************************************************
void CErrorControl::ReportSecondaryFailure() {
	QString strErrorMessage("");
	// set the appropriate message depending on the current state
	strErrorMessage = QWidget::tr("Fatal Error!\r\n Board Failed to respond.\r\nRestart the system.");
	UpdateErrorCondition(retSecondary_Failure, true, strErrorMessage);
}
//****************************************************************************
//	Reports a failure that the Secondary Processor is not responding
///
/// 
//****************************************************************************
void CErrorControl::ReportSecondaryFwCRCFailure() {
	QString strErrorMessage("");
	// set the appropriate message depending on the current state
	strErrorMessage = QWidget::tr("Fatal Error!\r\nCRC Error.Firmware Corrupted.Contact support team.");
	UpdateErrorCondition(retSecondary_CRC_Failure, true, strErrorMessage);
}
//****************************************************************************
//	void CheckIntMem()
///
/// Method that checks the state of the internal memory
/// 
//****************************************************************************
void CErrorControl::CheckIntMem() {
	CNVBasicVar *pNVparam = NULL;
	pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_RECORDING_TIME));
	const ULONG ulEXPORT_TIME = pNVparam->GetFromNV()->value.ul;
	QString strErrorMsg("");
	// check if the time left is less than our internal memory alarm time
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	if (ptProfile != NULL) {
		if (ulEXPORT_TIME < (ptProfile->Logging.IntMemAlmTime * 3600)) {
			// check if this is a state cahnge in which case we must send a message to the event system
			if (!m_kaERROR_TYPES[retINT_MEM_LO].bInErrorState) {
				pEVENTS->SystemEventTrigger(ecsIntMemLo);
			}
			// when in an error condition always display the lowest time now, not the lowest unacknowldged time
			// reached
			m_kaERROR_TYPES[retINT_MEM_LO].AdditionalData.L[0] = ulEXPORT_TIME;
			if (ulEXPORT_TIME == 0) {
				strErrorMsg = QWidget::tr("Internal Memory Full!!!\r\n%s\r\nLogged data is being lost.");
			} else {
				strErrorMsg =
						QString::asprintf(IDS_ERROR_DLG_INT_MEM_LO_ERROR, "%s",
								CStringUtils::GetAutoDDHHMMSSspanFromSeconds(static_cast<LONGLONG>(ulEXPORT_TIME)).toLocal8Bit().data());
			}
			UpdateErrorCondition(retINT_MEM_LO, true, strErrorMsg);
		} else {
			// we are no longer in an error condition - however we may still have a message that needs
			// acknowledging - check if an error is still pending
			if (m_kaERROR_TYPES[retINT_MEM_LO].bPending) {
				if (m_kaERROR_TYPES[retINT_MEM_LO].AdditionalData.L[0] == 0) {
					strErrorMsg = QWidget::tr("Internal Memory Full!!!\r\n%s\r\nLogged data was lost.");
				} else {
					// there is a message still pending - use the stored export time
					strErrorMsg =
							QString::asprintf(IDS_ERROR_DLG_INT_MEM_WAS_LO_ERROR, "%s",
									CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
											static_cast<LONGLONG>(m_kaERROR_TYPES[retINT_MEM_LO].AdditionalData.L[0])).toLocal8Bit().data());
				}
			}
			// always update the error condition
			UpdateErrorCondition(retINT_MEM_LO, false, strErrorMsg);
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
}
//****************************************************************************
//	void CheckSchedExportDev()
///
/// Method that checks the state of the scheduled export device
/// 
//****************************************************************************
void CErrorControl::CheckSchedExportDev() {
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	T_PCOMMUNICATIONS ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
	QString strErrorMsg("");
	bool bSetToPastTense = false;
	if ((ptProfile != NULL) && (ptCommsData != NULL)) {
		const ULONG ulALARM_TIME = static_cast<ULONG>(ptProfile->Logging.ExpMediaAlmTime * 60);
		// check we are configured to carry out scheduled exports
		if (ptProfile->Logging.DoSchedExport == TRUE) {
			// we are required to perform scheduled exports - now check if the media is present
			CMediaManager *pkMediaManager = CMediaManager::GetHandle();
			// Get status of logging device - is it in there?
			if (ptProfile->Logging.SchedExportDev != LOGDEV_SHARE) {
				// check the device is inserted - external memory missing is handled by a different message
				if (pkMediaManager->IsDeviceInserted(
						CLogDeviceStatus::LogDeviceToStorageDevice(
								static_cast<T_LOG_DEVICE>(ptProfile->Logging.SchedExportDev)))) {
					// the device is inserted so now get hold of the time before the device is full
					CQMonitor *pkQueueMonitor = CQMonitor::GetHandle();
					// now calculate how many minutes it will take to fill this card given it's free space and the buffer zone
					CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();
					const T_STORAGE_DEVICE eSTORAGE_DEVICE = pkDeviceStatus->LogDeviceToStorageDevice(
							static_cast<T_LOG_DEVICE>(ptProfile->Logging.SchedExportDev));
					const long lKB_FREE_SPACE = pkMediaManager->GetFreeSpaceK(eSTORAGE_DEVICE)
							- CTransferDevice::ms_ulFREE_SPACE_MIN_KB;
					// now calculate the number of minutes it would tkae to fill the current device
					const ULONG ulAVERAGE_KB_FILLED_PER_HOUR = pkQueueMonitor->GetBlocksUsedPerHour()
							/ (1024 / QMC_BLOCK_SIZE);
					if (ulAVERAGE_KB_FILLED_PER_HOUR > 0) {
						const long lKB_FREE_SPACE_INC_WAITING_BLOCKS = lKB_FREE_SPACE
								- (pkQueueMonitor->GetBlocksWaiting() / (1024 / QMC_BLOCK_SIZE));
						const float fMINUTES_UNTIL_MEDIA_FULL = static_cast<float>(lKB_FREE_SPACE_INC_WAITING_BLOCKS)
								/ static_cast<float>(ulAVERAGE_KB_FILLED_PER_HOUR) * 60;
						if (lKB_FREE_SPACE > 0) {
							static const float s_fMINUTES_IN_A_YEAR = 24 * 365 * 60;
							// this means there is space - however, it is possible that the disk is heavily fragmented in which and we
							// can't write to it - because of this we are going to say that if the blocks waiting to go to disk exceed
							// the free space then the disk is going to be full
							if (lKB_FREE_SPACE_INC_WAITING_BLOCKS > 0) {
								// check if it is lower than our alarm level
								if (fMINUTES_UNTIL_MEDIA_FULL < ulALARM_TIME) {
									// check if this is a state change in which case we must send a message to the event system
									if (!m_kaERROR_TYPES[retEXT_MEM_LO].bInErrorState) {
										pEVENTS->SystemEventTrigger(ecsExpMemLo);
									}
									// we are in alarm - display the time left as long as it is less that the current time unless we
									// are just about ot go into the alarm state in which case always update the time
									m_kaERROR_TYPES[retEXT_MEM_LO].AdditionalData.L[0] =
											static_cast<ULONG>(fMINUTES_UNTIL_MEDIA_FULL * 60);
									// there is a message still pending - use the stored export time
									strErrorMsg =
											QString::asprintf(
													"External Media Low!!!\r\n%s\r\nThe external media will be full in %s.",
													L"%s",
													CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
															static_cast<LONGLONG>(m_kaERROR_TYPES[retEXT_MEM_LO].AdditionalData.L[0])).toLocal8Bit().data());
									// the media is running out of space - update the time
									UpdateErrorCondition(retEXT_MEM_LO, true, strErrorMsg);
								} else {
									// we are not in the alarm state so set as out of alarm but persist
									// any pending alarms
									bSetToPastTense = true;
								}
							} else {
								// check if this is a state change in which case we must send a message to the event system
								if (!m_kaERROR_TYPES[retEXT_MEM_LO].bInErrorState) {
									pEVENTS->SystemEventTrigger(ecsExpMemLo);
								}
								// assume the media is full although technically it might not be full until
								// the next export is complete - set this as the current alarm state
								// set the remaining export time to 0 so it remains set as the lowest
								m_kaERROR_TYPES[retEXT_MEM_LO].AdditionalData.L[0] = 0;
								strErrorMsg = QWidget::tr(
										"External Media Full!!!\r\n%s\r\nThe external export media is full.");
								UpdateErrorCondition(retEXT_MEM_LO, true, strErrorMsg);
							}
						} else {
							// check if this is a state change in which case we must send a message to the event system
							if (!m_kaERROR_TYPES[retEXT_MEM_LO].bInErrorState) {
								pEVENTS->SystemEventTrigger(ecsExpMemLo);
							}
							// the media must be full - set this as the current alarm state
							// set the remaining export time to 0 so it remains set as the lowest
							m_kaERROR_TYPES[retEXT_MEM_LO].AdditionalData.L[0] = 0;
							strErrorMsg = QWidget::tr(
									"External Media Full!!!\r\n%s\r\nThe external export media is full.");
							UpdateErrorCondition(retEXT_MEM_LO, true, strErrorMsg);
						}
					} else {
						// logging at a very slow rate so we can't determine the log rate - assume we are not in
						// an error condition and persist and old messages
						bSetToPastTense = true;
					}
				} else {
					// the device isn't inserted therefore set as out of alarm but persist any
					// previous messages
					bSetToPastTense = true;
				}
			} else {
				// we could can't get hold of the disk free space for a network share so just
				// set as not in an error condition - this can't be configured either
				// @TODO Once it is possible to configure network shares then this code will need to
				// be revisted - persist any previous messages
				bSetToPastTense = true;
			}
		} else {
			// we are not required to do scheduled exports therefore we cannot be in an alarm
			// state - if there is a pending alarm that needs acknowledging then display it still
			bSetToPastTense = true;
		}
		// check if we must set a message to the past tense
		if (bSetToPastTense) {
			// only update the message if it is still pending acknowledgement
			if (m_kaERROR_TYPES[retEXT_MEM_LO].bPending) {
				// check if the device was full or simply nearly full
				if (m_kaERROR_TYPES[retEXT_MEM_LO].AdditionalData.L[0] == 0) {
					strErrorMsg = QWidget::tr("External Media Full!!!\r\n%s\r\nThe external export media was full.");
				} else {
					// there is a message still pending - use the stored export time
					strErrorMsg =
							QString::asprintf(
									"External Media Low!!!\r\n%s\r\nThe external media would have been full in %s.",
									L"%s",
									CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
											static_cast<LONGLONG>(m_kaERROR_TYPES[retEXT_MEM_LO].AdditionalData.L[0])).toLocal8Bit().data());
				}
			}
			// update the state and the message
			UpdateErrorCondition(retEXT_MEM_LO, false, strErrorMsg);
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
}
//****************************************************************************
//	void CheckSchedExportDevMissing()
///
/// Method that checks if the scheduled export device is present
/// 
//****************************************************************************
void CErrorControl::CheckSchedExportDevMissing() {
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	T_PCOMMUNICATIONS ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
	QString strErrorMsg("");
	bool bSetToPastTense = false;
	if ((ptProfile != NULL) && (ptCommsData != NULL)) {
		if (ptProfile->Logging.DoSchedExport == TRUE) {
			// we are required to perform scheduled exports - now check if the media is present
			CMediaManager *pkMediaManager = CMediaManager::GetHandle();
			// check the device is inserted - external memory missing is handled by a different message
			if (pkMediaManager->IsDeviceInserted(
					CLogDeviceStatus::LogDeviceToStorageDevice(
							static_cast<T_LOG_DEVICE>(ptProfile->Logging.SchedExportDev)))) {
				// the device is inserted so set as out of alarm but persist any previous messages
				bSetToPastTense = true;
			} else {
				// the device isn't inserted therefore set as in the alarm state
				strErrorMsg = QWidget::tr("External Media Missing!!!\r\n%s\r\nThe external export media is missing.");
				UpdateErrorCondition(retEXT_MEDIA_MISSING, true, strErrorMsg);
			}
		} else {
			// we are not required to do scheduled exports therefore we cannot be in an alarm
			// state - if there is a pending alarm that needs acknowledging then display it still
			bSetToPastTense = true;
		}
		// check if we must set a message to the past tense
		if (bSetToPastTense) {
			// only update the message if it is still pending acknowledgement
			if (m_kaERROR_TYPES[retEXT_MEDIA_MISSING].bPending) {
				strErrorMsg = QWidget::tr("External Media Missing!!!\r\n%s\r\nThe external export media was missing.");
			}
			// update the state and the message
			UpdateErrorCondition(retEXT_MEDIA_MISSING, false, strErrorMsg);
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
}
//****************************************************************************
//	void CheckFTPMem()
///
/// Method that checks the state of the FTP memory
/// 
//****************************************************************************
void CErrorControl::CheckFTPMem() {
	CNVBasicVar *pNVparam = NULL;
	pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_FTP_RECORDING_TIME));
	const ULONG ulEXPORT_TIME = pNVparam->GetFromNV()->value.ul;
	QString strErrorMsg("");
	// check if the time left is less than our FTP memory alarm time
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
	if (ptCommsData != NULL) {
		if (ulEXPORT_TIME < (ptCommsData->FTP.FTPMemAlmTime * 3600)) {
			// check if this is a state change in which case we must send a message to the event system
			if (!m_kaERROR_TYPES[retFTP_MEM_LO].bInErrorState) {
				pEVENTS->SystemEventTrigger(ecsFTPMemLo);
			}
			// when in an error condition always display the lowest time now, not the lowest unacknowldged time
			// reached
			m_kaERROR_TYPES[retFTP_MEM_LO].AdditionalData.L[0] = ulEXPORT_TIME;
			if (ulEXPORT_TIME == 0) {
				strErrorMsg = QWidget::tr("FTP Memory Full!!!\r\n%s\r\nLogged data is being lost.");
			} else {
				strErrorMsg =
						QString::asprintf(IDS_ERROR_DLG_FTP_MEM_LO_ERROR, L"%s",
								CStringUtils::GetAutoDDHHMMSSspanFromSeconds(static_cast<LONGLONG>(ulEXPORT_TIME)).toLocal8Bit().data());
			}
			UpdateErrorCondition(retFTP_MEM_LO, true, strErrorMsg);
		} else {
			// we are no longer in an error condition - however we may still have a message that needs
			// acknowledging - check if an error is still pending
			if (m_kaERROR_TYPES[retFTP_MEM_LO].bPending) {
				if (m_kaERROR_TYPES[retFTP_MEM_LO].AdditionalData.L[0] == 0) {
					strErrorMsg = QWidget::tr("FTP Memory Full!!!\r\n%s\r\nLogged data was lost.");
				} else {
					// there is a message still pending - use the stored export time
					strErrorMsg =
							QString::asprintf(IDS_ERROR_DLG_FTP_MEM_WAS_LO_ERROR, L"%s",
									CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
											static_cast<LONGLONG>(m_kaERROR_TYPES[retFTP_MEM_LO].AdditionalData.L[0])).toLocal8Bit().data());
				}
			}
			// always update the error condition
			UpdateErrorCondition(retFTP_MEM_LO, false, strErrorMsg);
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
}
//****************************************************************************
//	void CheckCJCError()
///
/// Method that checks the CJC error state (reflash)
/// 
//****************************************************************************
void CErrorControl::CheckCJCError() {
	m_kCriticalSection.lock();
	// check if we are in an error condition
	if (m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS] != 0) {
		// still in an error condition - check if message is no longer pending and the reflash time
		// has elapsed
		if (!m_kaERROR_TYPES[retCJC_MISSING].bPending) {
			// needs to be reflashed - see if time now exceeds the reflash time
			if ( pSYSTIMER->GetCurrentProcessTimeInMicroSec() > m_kaERROR_TYPES[retCJC_MISSING].llReflashTime) {
				// set back to pending don't bother updating the message as it will already be correct
				m_kaERROR_TYPES[retCJC_MISSING].bPending = true;
			}
		}
	}
	m_kCriticalSection.lock();
}
//****************************************************************************
//	void CheckTCError()
///
/// Method that checks the TC error state (reflash)
/// 
//****************************************************************************
void CErrorControl::CheckTCError() {
	m_kCriticalSection.lock();
	// check if we are in an error condition
	if (m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS] != 0) {
		// still in an error condition - check if message is no longer pending and the reflash time
		// has elapsed
		if (!m_kaERROR_TYPES[retTC_BURNOUT].bPending) {
			// needs to be reflashed - see if time now exceeds the reflash time
			if ( pSYSTIMER->GetCurrentProcessTimeInMicroSec() > m_kaERROR_TYPES[retTC_BURNOUT].llReflashTime) {
				// set back to pending don't bother updating the message as it will already be correct
				m_kaERROR_TYPES[retTC_BURNOUT].bPending = true;
			}
		}
	}
	m_kCriticalSection.lock();
}
//****************************************************************************
//	void CJCMissingError(	const bool bCJC_MISSING,
//							const USHORT usSLOT_NO )
///
/// Event called when a CJC state changes
/// 
/// @param[in]		const bool bCJC_MISSING - Flag indicating if the CJC in question is missing 
/// @param[in]		const USHORT usSLOT_NO - The zero based slot number who's CJC missing state
///					has changed
///
//****************************************************************************
void CErrorControl::CJCMissingError(const bool bCJC_MISSING, const USHORT usSLOT_NO) {
	m_kCriticalSection.lock();
	T_PGENERALCONFIG ptGeneralData =
	pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	QString strErrorMsg("");
	QString strTime("");
    char strBuff[100];
	if (ptGeneralData != NULL) {
		// check if the CJC is missing and thus in error
		if (bCJC_MISSING) {
			// update the time if this is the first instance and there is nothing pending
			if ((m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS] == 0)
					&& (!m_kaERROR_TYPES[retCJC_MISSING].bPending)) {
				m_kaERROR_TYPES[retCJC_MISSING].llFirstTriggerTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			}
			CTVtime kTime(m_kaERROR_TYPES[retCJC_MISSING].llFirstTriggerTime);
			memset(strBuff, 0, 100);
			kTime.TimeToStringShort(strBuff);
			strTime = QString::fromLatin1(strBuff);
			// check if in error already
			if (GetBits(m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS], usSLOT_NO, 1)
					== 0) {
				// not set aleady so set the relevant bits
				SetBits(&m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS],
						static_cast<BYTE>(1), usSLOT_NO, 1);
				// set back to pending and in error
				m_kaERROR_TYPES[retCJC_MISSING].bInErrorState = true;
				m_kaERROR_TYPES[retCJC_MISSING].bPending = true;
			}
			// always reset the relevant bits in the 'have been' area
			SetBits(&m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS],
					static_cast<BYTE>(0), usSLOT_NO, 1);
			// regenerate the error message accordingly
			if (m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS] != 0) {
				// some are in the error state and some have been in the error state without being acknowldeged
                strErrorMsg = QString::asprintf(IDS_ERROR_DLG_CJC_MISSING_MIX_ERROR, strBuff, GetCJCErrorInfo(esrBOTH).toLocal8Bit().data());
			} else {
				// some are in the error state only
                strErrorMsg = QString::asprintf(IDS_ERROR_DLG_CJC_MISSING_ERROR, strBuff, GetCJCErrorInfo(esrIN_ERROR).toLocal8Bit().data());
			}
		} else {
			CTVtime kTime(m_kaERROR_TYPES[retCJC_MISSING].llFirstTriggerTime);
			memset(strBuff, 0, 100);
			kTime.TimeToStringShort(strBuff);
			strTime = QString::fromLatin1(strBuff);
			// not missing therefore set the in error state bit to false and if not autoclear then
			// set the was in error state flag
			// check if in error already
			if (GetBits(m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS], usSLOT_NO, 1)
					== 1) {
				if (ptGeneralData->ErrorControl.AutoClear) {
					// reset the relevant bits
					SetBits(&m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS],
							static_cast<BYTE>(0), usSLOT_NO, 1);
					SetBits(
							&m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS],
							static_cast<BYTE>(0), usSLOT_NO, 1);
					// set to not in error or pending if all off
					if (m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS] == 0) {
						m_kaERROR_TYPES[retCJC_MISSING].bInErrorState = false;
						m_kaERROR_TYPES[retCJC_MISSING].bPending = false;
					} else {
						// regenerate the error message accordingly
						if (m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS]
								!= 0) {
							// some are in the error state and some have been in the error state without being acknowldeged
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_CJC_MISSING_MIX_ERROR, strBuff,
                                    GetCJCErrorInfo(esrBOTH).toLocal8Bit().data());
						} else {
							// some are in the error state only
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_CJC_MISSING_ERROR, strBuff,
                                    GetCJCErrorInfo(esrIN_ERROR).toLocal8Bit().data());
						}
					}
				} else {
					// check if the message is still pending and needs acknowledging
					if (m_kaERROR_TYPES[retCJC_MISSING].bPending) {
						// auto clear not set and still pending therefore put into the 'have been in' error state
						SetBits(&m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS],
								static_cast<BYTE>(0), usSLOT_NO, 1);
						SetBits(
								&m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS],
								static_cast<BYTE>(1), usSLOT_NO, 1);
						// set to not in error if all off
						if (m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS] == 0) {
							m_kaERROR_TYPES[retCJC_MISSING].bInErrorState = false;
							// some are in the error state and some have been in the error state without being acknowldeged
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_CJC_WAS_MISSING_ERROR, strBuff,
                                    GetCJCErrorInfo(esrHAS_BEEN_IN_ERROR).toLocal8Bit().data());
						} else {
							// some are in the error state and some have been in the error state without being acknowldeged
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_CJC_MISSING_MIX_ERROR, strBuff,
                                    GetCJCErrorInfo(esrBOTH).toLocal8Bit().data());
						}
					} else {
						// not pending therefore clear the in error state but don't bother setting the 'have been'
						// error
						SetBits(&m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS],
								static_cast<BYTE>(0), usSLOT_NO, 1);
					}
				}
			}
		}
		// update the message if necessary
        if (strErrorMsg != "") {
			// update the message
            WCHAR *pwStr ;
            strErrorMsg.toWCharArray(pwStr);
            CStringUtils::SafeWcsCpy(m_kaERROR_TYPES[retCJC_MISSING].wcaErrorMessage, pwStr, s_ulMAX_ERROR_BYTES);
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	m_kCriticalSection.unlock();
}
//****************************************************************************
//	void TCBurnoutError(	const bool bTC_BURNOUT,
//							const USHORT usSYSTEM_CHANNEL_NO )
///
/// Event called when a TC Burnout state changes
///
/// @param[in]		const bool bTC_BURNOUT - Flag indicating if the TC in question is in the burnout state
/// @param[in]		const USHORT usSYSTEM_CHANNEL_NO - The zero based system channel number who's
///					TC burnout state has changed
///
//****************************************************************************
void CErrorControl::TCBurnoutError(const bool bTC_BURNOUT, const USHORT usSYSTEM_CHANNEL_NO) {
	m_kCriticalSection.lock();
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
    QString strErrorMsg("");
    char strTime[100];
    memset(strTime,0,100);
	if (ptGeneralData != NULL) {
		// check if the TC is missing and thus in error
		if (bTC_BURNOUT) {
			// update the time if this is the first instance and there is nothing pending
			if ((m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.B[m_usTC_IN_ERROR_STATE_LONGLONG_POS] == 0)
					&& (!m_kaERROR_TYPES[retTC_BURNOUT].bPending)) {
				m_kaERROR_TYPES[retTC_BURNOUT].llFirstTriggerTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			}
			CTVtime kTime(m_kaERROR_TYPES[retTC_BURNOUT].llFirstTriggerTime);
            kTime.TimeToStringShort(strTime);
			// check if in error already
			if (GetBits(m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS],
					static_cast<short>(usSYSTEM_CHANNEL_NO), 1) == 0) {
				// not set aleady so set the relevant bits
				SetBits(&m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS],
						static_cast<short>(1), usSYSTEM_CHANNEL_NO, 1);
				// set back to pending and in error
				m_kaERROR_TYPES[retTC_BURNOUT].bInErrorState = true;
				m_kaERROR_TYPES[retTC_BURNOUT].bPending = true;
			}
			// always reset the relevant bits in the 'have been' area
			SetBits(&m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS],
					static_cast<short>(0), usSYSTEM_CHANNEL_NO, 1);
			// regenerate the error message accordingly
			if (m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS] != 0) {
				// some are in the error state and some have been in the error state without being acknowldeged
                strErrorMsg = QString::asprintf(IDS_ERROR_DLG_TC_BURNOUT_MIX_ERROR, strTime, GetTCErrorInfo(esrBOTH).toLocal8Bit().data());
			} else {
				// some are in the error state only
                strErrorMsg = QString::asprintf(IDS_ERROR_DLG_TC_BURNOUT_ERROR, strTime, GetTCErrorInfo(esrIN_ERROR).toLocal8Bit().data());
			}
		} else {
			CTVtime kTime(m_kaERROR_TYPES[retTC_BURNOUT].llFirstTriggerTime);
            kTime.TimeToStringShort(strTime);
			// not missing therefore set the in error state bit to false and if not autoclear then
			// set the was in error state flag
			// check if in error already
			if (GetBits(m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS],
					usSYSTEM_CHANNEL_NO, 1) == 1) {
				if (ptGeneralData->ErrorControl.AutoClear) {
					// reset the relevant bits
					SetBits(&m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS],
							static_cast<short>(0), usSYSTEM_CHANNEL_NO, 1);
					SetBits(
							&m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS],
							static_cast<short>(0), usSYSTEM_CHANNEL_NO, 1);
					// set to not in error or pending if all off
					if (m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS] == 0) {
						m_kaERROR_TYPES[retTC_BURNOUT].bInErrorState = false;
						m_kaERROR_TYPES[retTC_BURNOUT].bPending = false;
					} else {
						// regenerate the error message accordingly
						if (m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS]
								!= 0) {
							// some are in the error state and some have been in the error state without being acknowldeged
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_TC_BURNOUT_MIX_ERROR, strTime,
                                    GetTCErrorInfo(esrBOTH).toLocal8Bit().data());
						} else {
							// some are in the error state only
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_TC_BURNOUT_ERROR, strTime,
                                    GetTCErrorInfo(esrIN_ERROR).toLocal8Bit().data());
						}
					}
				} else {
					// check if the message is still pending and needs acknowledging
					if (m_kaERROR_TYPES[retTC_BURNOUT].bPending) {
						// auto clear not set and still pending therefore put into the 'have been in' error state
						SetBits(&m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS],
								static_cast<short>(0), usSYSTEM_CHANNEL_NO, 1);
						SetBits(
								&m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS],
								static_cast<short>(1), usSYSTEM_CHANNEL_NO, 1);
						// set to not in error if all off
						if (m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS] == 0) {
							m_kaERROR_TYPES[retTC_BURNOUT].bInErrorState = false;
							// some are in the error state and some have been in the error state without being acknowldeged
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_TC_WAS_BURNOUT_ERROR, strTime,
                                    GetTCErrorInfo(esrHAS_BEEN_IN_ERROR).toLocal8Bit().data());
						} else {
							// some are in the error state and some have been in the error state without being acknowldeged
							strErrorMsg = QString::asprintf(IDS_ERROR_DLG_TC_BURNOUT_MIX_ERROR, strTime,
                                    GetTCErrorInfo(esrBOTH).toLocal8Bit().data());
						}
					} else {
						// not pending therefore clear the in error state but don't bother setting the 'have been'
						// error
						SetBits(&m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS],
								static_cast<short>(0), usSYSTEM_CHANNEL_NO, 1);
					}
				}
			}
		}
		// update the message if necessary
        if (strErrorMsg != "") {
			// update the message

            WCHAR *pwStr ;
            strErrorMsg.toWCharArray(pwStr);
            CStringUtils::SafeWcsCpy(m_kaERROR_TYPES[retTC_BURNOUT].wcaErrorMessage, pwStr,
					s_ulMAX_ERROR_BYTES);
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	m_kCriticalSection.unlock();
}
//****************************************************************************
//	void UpdateErrorCondition(	const T_RECORDER_ERROR_TYPES eERROR_TYPE,
//								const bool bSTATE,
//								QString &rstrErrorMessage )
///
/// Method that sets the correct states for a particular error
///
/// @param[in]		const T_RECORDER_ERROR_TYPES eERROR_TYPE - The error condition
/// @param[in]		const bool bSTATE - The current state for this error
/// @param[in]		QString &rstrErrorMessage - The error message to display
///
//****************************************************************************
void CErrorControl::UpdateErrorCondition(const T_RECORDER_ERROR_TYPES eERROR_TYPE, const bool bIN_ERROR_STATE,
		QString &rstrErrorMessage) {
    char strTime[100];
	m_kCriticalSection.lock();
	// check the state
	if (!bIN_ERROR_STATE) {
		T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
		if (ptGeneralData != NULL) {
			// the item is out of the alarm/error condition - check if autoclear is on or its an item that
			// we always auto clear
			//Batter Error state is NEVER auto clear
			if ((ptGeneralData->ErrorControl.AutoClear) || (retDEF_SERIAL == eERROR_TYPE) || (retDEF_MAC == eERROR_TYPE)
					|| (retBattery_Status != eERROR_TYPE) || (retPWD_NET_SYNC_FAILURE == eERROR_TYPE)) {
				// auto clear is on therefore set the message as no longer valid
				m_kaERROR_TYPES[eERROR_TYPE].bInErrorState = false;
				m_kaERROR_TYPES[eERROR_TYPE].bPending = false;
			} else if (m_kaERROR_TYPES[eERROR_TYPE].bInErrorState) {
				// auto clear is not on and we were in the error condition previosuly,
				// therefore we must clear the error condition now and update the message
				// so that is in the past tense - if it is pending still it will get handled
				m_kaERROR_TYPES[eERROR_TYPE].bInErrorState = false;
				// add the time
                QString strCompleteMsg("");
				CTVtime kTime(m_kaERROR_TYPES[eERROR_TYPE].llFirstTriggerTime);
                char strTime[100];
                memset(strTime, 0,100);
                kTime.TimeToStringShort(strTime);
                strCompleteMsg = QString::asprintf(rstrErrorMessage.toLocal8Bit().data(), strTime);
				// update the message though as it needs to be in the past tense
                WCHAR *pwStr;
                strCompleteMsg .toWCharArray(pwStr);
                CStringUtils::SafeWcsCpy(m_kaERROR_TYPES[eERROR_TYPE].wcaErrorMessage, pwStr, s_ulMAX_ERROR_BYTES);
			}
		} else {
#ifdef _DEBUG
    DebugBreak();
#endif
		}
	} else {
		// we are in an alarm/error condition - check if there has been a state change
		if (!m_kaERROR_TYPES[eERROR_TYPE].bInErrorState) {
			// there has been a state change - check if this is an already pending message though
			// e.g. it is something that is bouncing in and out of alarm and hasn't been achnowldged
			// yet
			if (!m_kaERROR_TYPES[eERROR_TYPE].bPending) {
				// no alarm pending already therefore set to pending and update the time
				m_kaERROR_TYPES[eERROR_TYPE].bPending = true;
				m_kaERROR_TYPES[eERROR_TYPE].llFirstTriggerTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			} else {
				// still a pending alarm to be acknowldged therefore do nothing
			}
			// always update the message
            QString strCompleteMsg("");
			CTVtime kTime(m_kaERROR_TYPES[eERROR_TYPE].llFirstTriggerTime);

            memset(strTime, 0,100);
            kTime.TimeToStringShort(strTime);
            strCompleteMsg = QString::asprintf(rstrErrorMessage.toLocal8Bit().data(), strTime);
			// update the message though as it needs to be in the tense now
            WCHAR *pwStr;
            strCompleteMsg .toWCharArray(pwStr);
            CStringUtils::SafeWcsCpy(m_kaERROR_TYPES[eERROR_TYPE].wcaErrorMessage, pwStr, s_ulMAX_ERROR_BYTES);
			// update the alarm state flag
			m_kaERROR_TYPES[eERROR_TYPE].bInErrorState = true;
		} else {
			// already in the alarm condition therefore check if we have reached a reflash time
			T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
			if (ptGeneralData != NULL) {
				//Batter Error state is always Reflash
				if ((ptGeneralData->ErrorControl.EnableReflash) || (retBattery_Status == eERROR_TYPE)) {
					// check if this alarm is no longer pending in which case it may need to be reflashed
					if (!m_kaERROR_TYPES[eERROR_TYPE].bPending) {
						// needs to be reflashed - see if time now exceeds the reflash time
						if ( pSYSTIMER->GetCurrentProcessTimeInMicroSec()
								> m_kaERROR_TYPES[eERROR_TYPE].llReflashTime) {
							// set back to pending
							m_kaERROR_TYPES[eERROR_TYPE].bPending = true;
						}
					}
				}
				// always update the message
                QString strCompleteMsg("");
				CTVtime kTime(m_kaERROR_TYPES[eERROR_TYPE].llFirstTriggerTime);
                memset(strTime, 0,100);
                kTime.TimeToStringShort(strTime);
                strCompleteMsg = QString::asprintf(rstrErrorMessage.toLocal8Bit().data(), strTime);
				// update the message in case anything has changed

                WCHAR *pwStr;
                strCompleteMsg .toWCharArray(pwStr);
                CStringUtils::SafeWcsCpy(m_kaERROR_TYPES[eERROR_TYPE].wcaErrorMessage, pwStr, s_ulMAX_ERROR_BYTES);
			} else {
#ifdef _DEBUG
      DebugBreak();
#endif
			}
		}
	}
	m_kCriticalSection.unlock();
}
//****************************************************************************
//	const bool DisplayError( const T_RECORDER_ERROR_TYPES eERROR_TYPE ) const
///
/// Method that determines if an error is configured to be displayed
///
/// @param[in]		const T_RECORDER_ERROR_TYPES eERROR_TYPE - The error condition
///
/// @return		True if the error is to be displayed
///
//****************************************************************************
const bool CErrorControl::DisplayError(const T_RECORDER_ERROR_TYPES eERROR_TYPE) const {
	bool bDisplayError = false;
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	if (ptGeneralData != NULL) {
		switch (eERROR_TYPE) {
		case retCABLE_UNPLUGGED:
			bDisplayError = (ptGeneralData->ErrorControl.NetworkDiscon == TRUE);
			break;
		case retINT_MEM_LO:
			bDisplayError = (ptGeneralData->ErrorControl.IntMemLo == TRUE);
			break;
		case retEXT_MEM_LO:
			bDisplayError = (ptGeneralData->ErrorControl.ExportMemLo == TRUE);
			break;
		case retEXT_MEDIA_MISSING:
			bDisplayError = (ptGeneralData->ErrorControl.ExportMedMiss == TRUE);
			break;
		case retFTP_MEM_LO:
			bDisplayError = (ptGeneralData->ErrorControl.FTPMemLo == TRUE);
			break;
		case retCJC_MISSING:
			bDisplayError = (ptGeneralData->ErrorControl.CJCMissing == TRUE);
			break;
		case retTC_BURNOUT:
			bDisplayError = (ptGeneralData->ErrorControl.TCBurnout == TRUE);
			break;
		case retDEF_MAC:
			bDisplayError = true;
			break;
		case retDEF_SERIAL:
			bDisplayError = true;
			break;
		case retBattery_Status:
			bDisplayError = true;
			break;
		case retMAX_ERROR_TYPES:
			// error condition - should never happen
			break;
		case retPWD_NET_SYNC_FAILURE:
			// only show netsync errors when the recorder has been up and running for a while - this gives
			// the master time to startup and/or repond to its slaves
			bDisplayError = (m_usNetSyncCountdown == 0);
			break;
		case retFIRST_EVENT:
		case retLAST_EVENT:
		default:
			// must be an event therefore always display
			bDisplayError = true;
			break;
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	return bDisplayError;
}
//****************************************************************************
//	void ErrorConditionAck( const T_RECORDER_ERROR_TYPES eERROR_TYPE )
///
/// Method that updates the error information following a user acknowledging a message
///
/// @param[in]		const T_RECORDER_ERROR_TYPES eERROR_TYPE - The error condition
///
/// @return		True if the error is to be displayed
///
//****************************************************************************
void CErrorControl::ErrorConditionAck(const T_RECORDER_ERROR_TYPES eERROR_TYPE) {
	m_kCriticalSection.lock();
	m_kaERROR_TYPES[eERROR_TYPE].bPending = false;
	// set the reflash time - do this even if reflash is enabled
	// @TODO We may have a problem where the user ack's a message and then sets the reflash
	// flag or changes the reflash time in the config - the error would use the reflash from
	// before the commit if it were still in an error condition
	m_kaERROR_TYPES[eERROR_TYPE].llReflashTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
	// now add the reflash time in microseconds
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	if (ptGeneralData != NULL) {
		LONGLONG llReflashInterval = SEC_TO_USEC(static_cast<LONGLONG>(ptGeneralData->ErrorControl.ReflashTime) * 60);
		m_kaERROR_TYPES[eERROR_TYPE].llReflashTime += llReflashInterval;
		// if CJC or TC error then always clear the have been error states
		if (eERROR_TYPE == retCJC_MISSING) {
			m_kaERROR_TYPES[eERROR_TYPE].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS] = 0;
		} else if (eERROR_TYPE == retTC_BURNOUT) {
			m_kaERROR_TYPES[eERROR_TYPE].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS] = 0;
		} else if ((eERROR_TYPE >= retFIRST_EVENT) && (eERROR_TYPE <= retLAST_EVENT)) {
			// never reflash events that are displayed - they always have their error conditions cleared once
			// they have been acknowledged
			m_kaERROR_TYPES[eERROR_TYPE].bInErrorState = false;
		} else if (eERROR_TYPE == retBattery_Status) {
			CBatteryManager *pBatteryManager = CBatteryManager::GetHandle();
			quint64 llBatteryReflashTime = pBatteryManager->GetReflashTimeInMilliSec(); //reflash for every 24 hours
			llReflashInterval = MSEC_TO_USEC(static_cast<LONGLONG>(llBatteryReflashTime));
			m_kaERROR_TYPES[eERROR_TYPE].llReflashTime += llReflashInterval;
		}
	} else {
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	m_kCriticalSection.unlock();
}
//****************************************************************************
//	const QString GetCJCErrorInfo( const T_ERROR_STATES_TO_REPORT eERROR_STATES_TO_REPORT  ) const
///
/// Method that converts the CJC error bitfield's into displayable strings
///
/// @return		String containing the error information
///
//****************************************************************************
const QString CErrorControl::GetCJCErrorInfo(const T_ERROR_STATES_TO_REPORT eERROR_STATES_TO_REPORT) const {
    QString strErrorReport("");
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();
    QString strSlotID("");
	// check if the in error state message needs to be displayed
	if ((eERROR_STATES_TO_REPORT == esrIN_ERROR) || (eERROR_STATES_TO_REPORT == esrBOTH)) {
		for (short sCount = 0; sCount < MAX_ANALOGUE_CARDS; sCount++) {
			if (GetBits(m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS], sCount, 1)
					== 1) {
				WCHAR pwcSlotID[4] = { 0, 0, 0, 0 };		//Coverity// CID: 770523
				pkSlotMap->GetSlotStrID(sCount, pwcSlotID);
                strSlotID = QString::asprintf("%s, ", pwcSlotID);
				strErrorReport += strSlotID;
			}
		}
	}
	// check if the has been in error state message needs to be displayed
	if ((eERROR_STATES_TO_REPORT == esrHAS_BEEN_IN_ERROR) || (eERROR_STATES_TO_REPORT == esrBOTH)) {
		for (short sCount = 0; sCount < MAX_ANALOGUE_CARDS; sCount++) {
			if (GetBits(m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS],
					sCount, 1) == 1) {
				WCHAR pwcSlotID[4] = { 0, 0, 0, 0 }; //COVERITY ISSUE ID: 770523
				pkSlotMap->GetSlotStrID(sCount, pwcSlotID);
                strSlotID = QString::asprintf("%s, ", pwcSlotID);
				strErrorReport += strSlotID;
			}
		}
	}
	// remove the trailing comma
    if (strErrorReport != "") {
        strErrorReport.remove(strErrorReport.length() - 2, 2);
	}
	// sanity check - make sure the requested error info matches the current bitfield states
	if ((eERROR_STATES_TO_REPORT == esrIN_ERROR)
			&& (m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS] != 0)) {
		// this is incorrect - flag a problem
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	if ((eERROR_STATES_TO_REPORT == esrHAS_BEEN_IN_ERROR)
			&& (m_kaERROR_TYPES[retCJC_MISSING].AdditionalData.B[m_usCJC_IN_ERROR_STATE_BYTE_POS] != 0)) {
		// this is incorrect - flag a problem
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	return strErrorReport;
}
//****************************************************************************
//	const QString GetTCErrorInfo( const T_ERROR_STATES_TO_REPORT eERROR_STATES_TO_REPORT  ) const
///
/// Method that converts the TC error bitfield's into displayable strings
///
/// @return		String containing the error information
///
//****************************************************************************
const QString CErrorControl::GetTCErrorInfo(const T_ERROR_STATES_TO_REPORT eERROR_STATES_TO_REPORT) const {
    QString strErrorReport("");
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();
    QString strSlotID("");
	// check if the in error state message needs to be displayed
	if ((eERROR_STATES_TO_REPORT == esrIN_ERROR) || (eERROR_STATES_TO_REPORT == esrBOTH)) {
		for (short sCount = 0; sCount < MAX_ANALOGUE_IN; sCount++) {
			if (GetBits(m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS], sCount, 1)
					== 1) {
                strSlotID = QString::asprintf("%d, ", sCount + 1);
				strErrorReport += strSlotID;
			}
		}
	}
	// check if the has been in error state message needs to be displayed
	if ((eERROR_STATES_TO_REPORT == esrHAS_BEEN_IN_ERROR) || (eERROR_STATES_TO_REPORT == esrBOTH)) {
		for (short sCount = 0; sCount < MAX_ANALOGUE_IN; sCount++) {
			if (GetBits(m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS],
					sCount, 1) == 1) {
                strSlotID = QString::asprintf("%d, ", sCount + 1);
				strErrorReport += strSlotID;
			}
		}
	}
	// remove the trailing comma
    if (strErrorReport != "") {
        strErrorReport.remove(strErrorReport.length() - 2, 2);
	}
	// sanity check - make sure the requested error info matches the current bitfield states
	if ((eERROR_STATES_TO_REPORT == esrIN_ERROR)
			&& (m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS] != 0)) {
		// this is incorrect - flag a problem
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	if ((eERROR_STATES_TO_REPORT == esrHAS_BEEN_IN_ERROR)
			&& (m_kaERROR_TYPES[retTC_BURNOUT].AdditionalData.LL[m_usTC_IN_ERROR_STATE_LONGLONG_POS] != 0)) {
		// this is incorrect - flag a problem
#ifdef _DEBUG
    DebugBreak();
#endif
	}
	return strErrorReport;
}
//****************************************************************************
//	void CheckBatteryStatus()
///
/// Method that checks the battery status
///
//****************************************************************************
void CErrorControl::CheckBatteryStatus() {
	QString sysMessage;
	SYSTEMTIME systime;
	GetLocalTime(&systime);
	USHORT bCurYear = systime.wYear;
	CBatteryManager *pBatteryManager = CBatteryManager::GetHandle();
	bool bLithExpired = pBatteryManager->CheckLithiumCellLife();
    QString strErrorMessage("");
    strErrorMessage = QWidget::tr("Detected Low Battery!!!\r\n%s\r\nDevice may not function as intended, replace the battery.");
	UpdateErrorCondition(retBattery_Status, bLithExpired, strErrorMessage);
}

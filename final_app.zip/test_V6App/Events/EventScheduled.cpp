/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Events
/// @n Filename: EventScheduled.cpp
/// @n Desc:	 Time based event triggers
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  10  Stability Project 1.5.1.3 7/2/2011 4:57:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  9 Stability Project 1.5.1.2 7/1/2011 4:38:17 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  8 Stability Project 1.5.1.1 3/17/2011 3:20:23 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  7 Stability Project 1.5.1.0 2/15/2011 3:03:02 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "EventScheduled.h"
#include "TVtime.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//**********************************************************************
/// CEventSchedule constructor
///
//**********************************************************************
CEventSchedule::CEventSchedule() {
	m_Enabled = FALSE;
	m_reloadRequired = TRUE;
	m_FirstRun = TRUE;
	m_IsRunning = TRUE;
	m_resetCounter = FALSE;
}
//**********************************************************************
/// Disable an event schedule as it is no longer required
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::DisableSchedule() {
	// No configuration 
	m_Enabled = FALSE;
	m_reloadRequired = TRUE;
	m_alignRequired = TRUE;
	m_eventExpiryTick = 0;
	m_ResetCountRequired = TRUE;
	m_IsRunning = TRUE;
	m_FirstRun = FALSE;
	m_currentCounter = 0;
	m_resetCounter = FALSE;
}
//**********************************************************************
/// The time has changed, register a reload and re-align
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::RegisterTimeChange() {
	m_reloadRequired = TRUE;
	m_alignRequired = TRUE;
}
//**********************************************************************
/// Setup an individual event from configuration
///
/// @param[in]	pConfig - ptr to the config data to be added, NULL to disable the scedule (i.e. non configured)
/// @param[in]	schedType - T_SCHED_EVENT_SUBTYPE type of schedule required - sesOnce,	sesInterval, sesSpecDays, sesMonthEnd 
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::SetupScheduleFromConfig(T_SCHED_EVENT_SUBTYPE schedType, T_PSCHEDEVENTDATA pConfig, int eventIndex,
		int causeIndex, BOOL configChanged) {
	// A configuration is available, configure.
	m_Enabled = TRUE;
	m_pConfig = pConfig;
	m_type = schedType;
	m_eventIndex = eventIndex;
	m_causeIndex = causeIndex;
	m_reloadRequired = TRUE;
	m_alignRequired = TRUE;
	m_eventExpiryTick = 0;
	int countDownMultiplier = 1;	// Countdown multiplier "could" be more if specific days of week set
	// If a trigger count is set and the schedule type is not "Once", indicate countdown required
	if (pConfig->TriggerCount > 0 && m_type != sesOnce) {
		m_CountdownRequired = TRUE;
	} else {
		m_CountdownRequired = FALSE;
	}
	// Is this the first time run since power on?
	if (m_FirstRun == TRUE) {
		// Yes so countdown was persisted, if used it could already have expired
		if (m_CountdownRequired && m_currentCounter == 0) {
			// yes, the count has expired so stop the schedule running
			m_IsRunning = FALSE;
		}
		m_FirstRun = FALSE;
	}
	// Check if the configuration has changed, if so then we need to reset any scheduled counts and run
	if (configChanged == TRUE) {
		m_resetCounter = TRUE;
		m_IsRunning = TRUE;
	}
	switch (m_type) {
	case sesOnce:		// Schedule once at specified time and Date
	{
		m_strScheduleType = "Once";
		break;
	}
	case sesInterval:	// Schedule at set intervals 
	{
		m_strScheduleType = "Interval";
		break;
	}
	case sesSpecDays:	// Schedule at specific times on set days of the week
	{
		m_strScheduleType = "Specific Days";
		break;
	}
	case sesMonthEnd:	// Schedule at month end
	{
		m_strScheduleType = "Month End";
		break;
	}
	}
	// Do we need to reset the countdown?
	if (m_CountdownRequired == TRUE && m_resetCounter == TRUE) {
		// Yes.
		// If it's specific days we need to change multiplier
		if (m_type == sesSpecDays) {
			// As countdown set in weeks, but we use in days (per triggered event)
			countDownMultiplier = 0;
			for (int daysIndex = 0; daysIndex < DAYS_IN_A_WEEK; daysIndex++) {
				if (IsDayScheduled(daysIndex) == TRUE) {
					countDownMultiplier++;
				}
			}
		}
		// Set the countdown
		m_currentCounter = pConfig->TriggerCount * countDownMultiplier;
		m_resetCounter = FALSE;
	}
}
//**********************************************************************
/// Setup an individual event from configuration
///
/// @return		T_EVENT_SCHEDULE_STATUS indicating schedule status
//**********************************************************************
T_EVENT_SCHEDULE_STATUS CEventSchedule::IsTriggered() {
	T_EVENT_SCHEDULE_STATUS scheduleStatus = SCHED_STATUS_NOACTION;
	// Is the schedule running? it might have expired it's count
	if (m_IsRunning == TRUE) {
		// Does this schedule required to be reloaded?
		if (m_reloadRequired == TRUE) {
			// Yes, recalculate the schedule
			ReloadSchedule();
			m_reloadRequired = FALSE;
			scheduleStatus = SCHED_STATUS_RELOADED;
		}
		// Has the schedule expired?
		if ( pSYSTIMER->GetCurrentProcessTick() >= m_eventExpiryTick) {
			// Schedule has triggered, indicate as such and reload timers
			scheduleStatus = SCHED_STATUS_TRIGGERED;
			// Is this a count based schedule?
			if (m_CountdownRequired == TRUE) {
				// if counter 
				if (m_currentCounter > 0) {
					m_currentCounter--;
				}
				if (m_currentCounter == 0) {
					m_IsRunning = FALSE;
				}
			}
			ReloadSchedule();
		}
	}
	return scheduleStatus;
}
const LONGLONG MINUTE_IN_USEC = (LONGLONG) USEC_IN_A_SEC * 60;
const LONGLONG HOUR_IN_USEC = MINUTE_IN_USEC * 60;
const LONGLONG DAY_IN_USEC = HOUR_IN_USEC * 24;
//**********************************************************************
/// Setup an individual event from configuration
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::ReloadSchedule() {
	CTVtime nextScheduleTime(static_cast<LONGLONG>(0));
	switch (m_type) {
	case sesOnce:		// Schedule once at specified time and Date
	{
		ReloadScheduleOnce(nextScheduleTime);
		break;
	}
	case sesInterval:	// Schedule at set intervals 
	{
		ReloadScheduleInterval(nextScheduleTime);
		break;
	}
	case sesSpecDays:	// Schedule at specific times on set days of the week
	{
		ReloadScheduleSpecificDays(nextScheduleTime);
		break;
	}
	case sesMonthEnd:	// Schedule at month end
	{
		ReloadScheduleMonthEnd(nextScheduleTime);
		break;
	}
	}
	m_nextSchedTime = nextScheduleTime;
	//WCHAR timeString[200];
	//nextScheduleTime.TimeToString(timeString);
	//qDebug("EVT(%d) SCHED(%d) next trigger %s, count = %d \n ", m_eventIndex+1, m_causeIndex+1, timeString, m_currentCounter );
}
//**********************************************************************
/// Setup an individual event from configuration
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::ReloadScheduleInterval(CTVtime &nextSchedule) {
	LONGLONG diffpoint = 0;
	// If the alignment field is set and an alignment is required, perform the alignment
	if (m_pConfig->Alignment != EVENT_ALIGN_TO_NONE && m_alignRequired == TRUE) {
		m_alignRequired = FALSE;
		LONGLONG alignTimeUSec = 0;
		// Load the alignment in micro seconds depending on the setting
		switch (m_pConfig->Alignment) {
		case EVENT_ALIGN_TO_MIN:		// Align to the nearest minute
		{
			alignTimeUSec = MINUTE_IN_USEC;
			break;
		}
		case EVENT_ALIGN_TO_HOUR:		// Align to the nearest hour
		{
			alignTimeUSec = HOUR_IN_USEC;
			break;
		}
		case EVENT_ALIGN_TO_DAY:		// Align to the nearest day
		{
			alignTimeUSec = DAY_IN_USEC;
			break;
		}
		}
		// Get the remaining time in uSec until the next alignment point
		LONGLONG timeOffset = alignTimeUSec - (pSYSTIMER->GetCurrentProcessTimeInMicroSec() % alignTimeUSec);
		// Calculate the interval time in uSec and check if it's less then the 
		// time to the next alignment point, if so, we can start earlier assuring alignment
		LONGLONG intervaluSec = static_cast<LONGLONG>(m_pConfig->IntervalPeriod) * USEC_IN_A_SEC;
		if (intervaluSec < timeOffset) {
			timeOffset = timeOffset % intervaluSec;
		}
		nextSchedule = pSYSTIMER->GetCurrentProcessTimeInMicroSec() + timeOffset;
		m_eventExpiryTick = pSYSTIMER->GetCurrentProcessTick() + ((USEC_TO_TICKS(timeOffset)) + 1);
	} else {
		// If this is not the first load of the expiry time, take into account the granularity error on the processing
		// over the tick to constantly adjust target times to avoid drift.
		if (m_eventExpiryTick > 0) {
			diffpoint = m_eventExpiryTick - pSYSTIMER->GetCurrentProcessTick();
		}
		// Set the new interval 
		diffpoint += (m_pConfig->IntervalPeriod * PROCESS_TICKS_PER_SECOND);
		m_eventExpiryTick = pSYSTIMER->GetCurrentProcessTick() + diffpoint;
		nextSchedule = pSYSTIMER->GetCurrentProcessTimeInMicroSec() + TICKS_TO_USEC(diffpoint);
	}
}
//**********************************************************************
/// Setup an individual event from configuration
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::ReloadScheduleOnce(CTVtime &nextSchedule) {
	// Generate a trigger time
	CTVtime triggerTime(SEC_TO_USEC(static_cast<LONGLONG>(m_pConfig->DateTime)));
	LONGLONG timediff = triggerTime.GetMicroSecs() - pSYSTIMER->GetCurrentProcessTimeInMicroSec();
	if (timediff <= 0) {
		// Scheduled time is in past so turn off the schedule
		timediff = 0;
		m_IsRunning = FALSE;
	}
	m_eventExpiryTick = pSYSTIMER->GetCurrentProcessTick() + (USEC_TO_TICKS(timediff) + 1);
	m_ResetCountRequired = 1;		// Only triggered once
	nextSchedule = triggerTime;
}
//**********************************************************************
/// Setup an month end event from configuration
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::ReloadScheduleMonthEnd(CTVtime &nextSchedule) {
	CTVtime workingTime;
	workingTime = pSYSTIMER->GetCurrentProcessTimeRef();
	// Get the system time from the current process time
	SYSTEMTIME tempTime;
	workingTime.GetSYSTEMTIME(&tempTime);
	// Advance the month, as we trigger at 00:00 on 1st day of month 
	tempTime.wMonth++;
	if (tempTime.wMonth > MONTHS_IN_A_YEAR) {
		// Month has rolled, reset to Jan and advance year
		tempTime.wMonth = 1;
		tempTime.wYear++;
	}
	// Reset the time to the 1st day of the month at 00:00
	tempTime.wDay = 1;
	tempTime.wHour = 0;
	tempTime.wMinute = 0;
	tempTime.wSecond = 0;
	tempTime.wMilliseconds = 0;
	// Set the next month end time
	workingTime.SYSTEMTIMEtoInternal(tempTime);
	// indexOf the time from now until the next month end time
	LONGLONG timediff = workingTime.GetMicroSecs() - pSYSTIMER->GetCurrentProcessTimeInMicroSec();
	// Set next schedule date
	nextSchedule = workingTime;
	// Set trigger point in system ticks
	m_eventExpiryTick = pSYSTIMER->GetCurrentProcessTick() + (USEC_TO_TICKS(timediff) + 1);
}
//**********************************************************************
/// Setup a specific day event from configuration
///
/// @return		nothing
//**********************************************************************
VOID CEventSchedule::ReloadScheduleSpecificDays(CTVtime &nextSchedule) {
	if (m_pConfig->WeekDay == 0) {
		// No days set, so don't run the schedule
		m_IsRunning = FALSE;
	} else {
		// indexOf the next day
		CreateTVTimeForNextSpecificDay(nextSchedule);
		// indexOf the time from now until the next month end time
		LONGLONG timediff = nextSchedule.GetMicroSecs() - pSYSTIMER->GetCurrentProcessTimeInMicroSec();
		// Set trigger point in system ticks
		m_eventExpiryTick = pSYSTIMER->GetCurrentProcessTick() + (USEC_TO_TICKS(timediff) + 1);
	}
}
//**********************************************************************
/// indexOf the next time the schedule needs to fire form the weekdays
///
/// @param[in]	theTimeDate - reference of the TVtime field to populate
///
/// @return		nothing
//**********************************************************************
void CEventSchedule::CreateTVTimeForNextSpecificDay(CTVtime &theTimeDate) {
	// Get the current time and day
	CTVtime currentTimeDate;
	currentTimeDate = pSYSTIMER->GetCurrentProcessTimeRef();
	SYSTEMTIME currentTime;
	currentTimeDate.GetSYSTEMTIME(&currentTime);
	// Assign the current time/date to the target time and then set the target time of day
	SYSTEMTIME targetTime = currentTime;
	targetTime.wHour = (m_pConfig->DateTime / SECONDS_IN_AN_HOUR) % HOURS_IN_A_DAY;
	targetTime.wMinute = (m_pConfig->DateTime / SECONDS_IN_A_MINUTE) % MINUTES_IN_AN_HOUR;
	targetTime.wSecond = m_pConfig->DateTime % SECONDS_IN_A_MINUTE;
	targetTime.wMilliseconds = 0;
	// We now have the next time schedule for the current day
	theTimeDate.SYSTEMTIMEtoInternal(targetTime);
	// Is the next schedule later the same day?
	if ((IsDayScheduled(targetTime.wDayOfWeek) == TRUE)
			&& (theTimeDate.GetMicroSecs() > currentTimeDate.GetMicroSecs())) {
		// Yes it is, nothing to do as theTimeDate is already correct	
	} else {
		// No, we have already tested today, so start from tomorrow and run though
		// until we find a matching day. 
		int dayOfWeekOffset;
		int dayOfWeek = targetTime.wDayOfWeek;
		for (dayOfWeekOffset = 1; dayOfWeekOffset <= DAYS_IN_A_WEEK; dayOfWeekOffset++) {
			theTimeDate += static_cast<LONGLONG>(DAY_IN_USEC);
			dayOfWeek = (targetTime.wDayOfWeek + dayOfWeekOffset) % DAYS_IN_A_WEEK;
			if (IsDayScheduled(dayOfWeek) == TRUE) {
				// Day of week matches, we can break out as the "theTimeDate" ir correct
				break;
			}
		}
	}
}
//**********************************************************************
/// Test if a day is scheduled for the event
///
/// @param[in]	DayNumber - number of day to test 0 = Sunday, 1 = Monday etc..
///
/// @return		TRUE if relevant day is selected for schedule, otherwise FALSE
//**********************************************************************
BOOL CEventSchedule::IsDayScheduled(int DayNumber) {
	BOOL IsDayScheduled = FALSE;
	// get bit state for required day
	USHORT testBits = GetBits(m_pConfig->WeekDay, DayNumber, 1);
	if (testBits != 0) {
		// The bit is Set so day is included
		IsDayScheduled = TRUE;
	}
	return IsDayScheduled;
}
//================================================================================================
// CLinkEventTimer Class
//================================================================================================
//**********************************************************************
/// CLinkEventTimer constructor
///
//**********************************************************************
CLinkEventTimer::CLinkEventTimer() : m_Timer(TIMER_NORMAL_RES) {
	m_TimerRunning = FALSE;
}
//**********************************************************************
/// Reset the linked event timer
///
/// @return		nothing
//**********************************************************************
void CLinkEventTimer::ResetLinkEvent() {
	m_TimerRunning = FALSE;
	m_Timer.ResetAllTimers();
}
//**********************************************************************
/// Start the event trigger delay
///
/// @param[in]	SecondsToTrigger - number fo seconds to delay until triggereing other events
///
/// @return		nothing
//**********************************************************************
void CLinkEventTimer::TriggerEvent(int SecondsToTrigger) {
	if (m_TimerRunning == FALSE) {
		// Timer is not already in operation, so we can start the link event timer
		m_TimerRunning = TRUE;
		m_SecondsToTrigger = SecondsToTrigger;
		m_Timer.StartTimer();
	}
}
//**********************************************************************
/// Check if the event delay is running and has completed, if so 
/// reset the timer and indicate a trigger required
///
/// @return		TRUE if trigger required, otherwise FALSE
//**********************************************************************
BOOL CLinkEventTimer::IsScheduleComplete() {
	BOOL retVal = FALSE;
	if (m_TimerRunning == TRUE) {
		if ( MSEC_TO_SEC( m_Timer.ElapsedTimeInMilliSeconds() ) >= m_SecondsToTrigger) {
			// Time to trigger link event has elapsed
			m_TimerRunning = FALSE;		// Stop the timer running
			m_Timer.ResetAllTimers();	// Clear the actual timer
			retVal = TRUE;				// Register a link event has elapsed		
		}
	}
	return retVal;
}

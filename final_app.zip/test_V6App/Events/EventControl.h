/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Events
/// @n Filename: EventControl.h
/// @n Desc:	 Processing specifics for individual events
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  28  Stability Project 1.25.1.1 7/2/2011 4:57:08 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  27  Stability Project 1.25.1.0 7/1/2011 4:27:44 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  26  V6 Firmware 1.25 9/23/2008 3:09:23 PM  Build Machine 
//  AMS2750 Merge
//  25  V6 Firmware 1.24 3/4/2008 7:00:58 PM Roger Dawson  
//  Added the ability to save screenshots to disk, either manually or via
//  the event system.
// $
//
// ****************************************************************
#ifndef __EVENTCONTROL_H__
#define __EVENTCONTROL_H__
#include "V6defines.h"
#include "V6Config.h"
#include "DataItemIO.h"
#include "EventScheduled.h"
#include "V6globals.h"
#include "NVVariables.h"
#include "DataItemCounter.h"
#include "Alarms.h"
// Event control return info.
typedef enum {
	EVENTCONTROL_OK, EVENTCONTROL_FAILED,
} T_EVENT_CONTROL_RETURN;
// Event list element, contains information about each event triggered
typedef struct {
	T_EVENT_CAUSE_TYPE causeType;		///< Main cause type in v6types.h
	USHORT subType;						///< Subtype of cause
	T_EVENTDATA data;					///< Data for cause, dependent on type
} T_EVENTQUEUE_ELEMENT;
//			B0	B1	B2	B3	B4	B5	B6	B7	B8	B9	B10	B11	B12	B13	B14	B15
//			S0		S1		S2		S3		S4		S5		S6		S7
//			L0				L1				L2				L3
//	Causes 
//
//	Alarm	PenNo**	AlarmNo									
//	Totals	Pens*******************************************	
//	Dig In	Digital Inputs*****************
//	TC BO	Analogues**********************
//	Sched	Not Applicable
//	User	Counters***************************************			UserCnt
//	MaxMin	Pens*******************************************
//	System	Not Applicable
//	UserAct Not Applicable
//	Batch															Grp
// TUS
// AMS2750Timer													Alert
//
//
//	Effects
//
//	Mark															PresetSel
//	Logging	Pens*******************************************	Type	Grp
// Totals	Pens*******************************************	Type	Grp
//	Dig Out	Digital Outputs****************
//	AlmAck	PenNo**	AlarmNo									Type	Grp
//	Email					ScrnSht	Templ**	Recipients***********************
//	Screen													Baklite SrcnNo
//	Print	****************************************************	Media
//	Count	Counters***************************************	Rst/Inc	UserCnt
//	MaxMin	Pens*******************************************	Type	Grp
//	Chart	Not Applicable									Type	Grp
//	Clear	Not Applicable
//	Delay	Events*********	Time***
//	Timers	Timers*********
//	Sound	Sounds*	PlayOnce
//	Display															PresetSel
//	Batch															Grp
//	Report	ReportNo* 
// Update Tabular Readings
// NOTE: Type is meant to refer to the pen selection which may be ALL, GROUP or 
// MULTIPLE INDIVIDIAL SELECTIONS. All will have no sub information, group will
// store a zero based group number in the next byte and the multiple individual
// selection will use the firxt 96 bits. Chart control will only offer all or
// group
const int ALARM_EVENT_CAUSE_PENNUMBER_INDEX = 0;
const int ALARM_EVENT_CAUSE_ALARMNUMBER_INDEX = 1;
const int SCREEN_EFFECT_BACKLIGHT_ON_OFF_STATE = 6;
const int SCREEN_EFFECT_CHANGE_SCREEN_INDEX_NO = 7;
const int EMAIL_EFFECT_RECIPIENTS_INDEX_NUMBER = 2;
const int EMAIL_EFFECT_TEMPLATES_INDEX_NUMBER = 3;
const int EMAIL_EFFECT_ATTACH_SCREENSHOT = 2;
const int USER_COUNTER_NO = 7;
// field used to identify if the event is to reset a counter (0) or increment it (1)
const int RESET_OR_INC_COUNTER = 6;
// E528446
const int SCREEN_EFFECT_CHART_SPEED = 4;
//
/// Field used to identify the location of the variable indicating the delay time for a
/// delayed event
const int EVENT_EFFECT_DELAYED_EVENT_DELAY_TIME_USHORT_INDEX = 2;
/// Field used to identify the location of the variable indicating the current
/// selection for a sound event
const int EVENT_EFFECT_SOUND_USHORT_INDEX = 0;
const int EVENT_EFFECT_SOUND_PLAY_ONCE_INDEX = 1;
const int TCBURNOUT_EVENT_CAUSE_ANANUMBER_INDEX = 0;
/// Field used to identify which preset marker is selected
const int MARKER_EVENT_CAUSE_PRESET_SEL_INDEX = 7;
/// Field used to identify which pen selection type is selected
const int MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX = 6;
/// Field used to identify which group selection type is used for chart control
const int MARKER_EVENT_EFFECT_CHART_CONTROL_GROUP_SEL_USHORT_INDEX = 6;
/// Field used to identify which group is selected
const int MARKER_EVENT_CAUSE_GROUP_SEL_USHORT_INDEX = 7;
const int MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX = 7;
// Field used to indentify the report number location
const int REPORT_NO_EVENT_EFFECT_USHORT_INDEX = 0;
/// Field used to identify which print screenshot external media is selected (ext cf/usb1/usb2)
const int PRINT_SCREENSHOT_EFFECT_EXT_MEDIA_USHORT_INDEX = 7;
/// Field used to identify which AMS2750 timer alert type is selected (Warning/Expired)
const int AMS2750_TIMER_CAUSE_ALERT_TYPE_USHORT_INDEX = 7;
const int TOTALS_1_32 = 0;
const int TOTALS_33_64 = 1;
const int TOTALS_65_96 = 2;
// Subtype definition, this must match the types displayed in the drop list in the UI
typedef enum {
	evtCauseAlarmINTO = 0, evtCauseAlarmOUTOF, evtCauseAlarmACK,
} T_EVENT_ALARM_CAUSE_SUBTYPE;
// defines to tie up with selections in config menu
typedef enum {
	EVT_EFFECT_LOG_START = 0, EVT_EFFECT_LOG_STOP = 1, EVT_EFFECT_DIG_assert = 0, EVT_EFFECT_DIG_CLEAR = 1,
	EVT_EFFECT_COUNT_START = 0, EVT_EFFECT_COUNT_STOP = 1, EVT_EFFECT_COUNT_RESET = 2, EVT_EFFECT_COUNT_RESETSTART = 3,
	EVT_CAUSE_DIG_ON = 0, EVT_CAUSE_DIG_OFF = 1, EVT_CAUSE_DIG_CHANGE = 2,
} T_EVENT_MENU_TYPES;
const int EVENTEFFECT_ITEMLIST_SIZE = EVENTDATA_L_SIZE * 32;	// Number of elements we would eve need to cache
const int EVENTEFFECT_BYTES_FOR_PENS = 12;	// Number of bytes making up a pen bitmask data, 96 / 8
const int EVENTEFFECT_BYTES_FOR_DIGIO_COUNT = 6;	// Number of bytes making up a DIG IO bitmask data, 48 / 8
const int EVENTEFFECT_BYTES_FOR_EVENT_COUNT = 3;	// Number of bytes making up a Event count bitmask data, 20 / 8
const int EVENTEFFECT_BYTES_FOR_PULSE_COUNT = 12;	// Number of bytes making up a Event count bitmask data, 96 / 8
													// where 1-48 are low pulse (1-48) and 49-96 are High pulse (1-48)
const int EVENTEFFECT_BYTES_FOR_SCRIPT_TIMERS = 3;	// Number of bytes making up script timers 20 / 8
const int DIO_CAUSE_CHANGE_MASK_BASE = 3;
//**Class*********************************************************************
///
/// @brief User Counters class
/// 
/// Control an individual user counter
///
//****************************************************************************
class CUserCounter {
public:
	CUserCounter();
public:		// API methods
	void SetupCounter(T_PCOUNTERSDATA pConfig, int Instance);
	void IncrementCounter(float value) {
		m_pUCCounter->IncrementCounter(value);
	}
	;
	void ResetCounter(float value) {
		m_pUCCounter->ResetCounter(value);
	}
	;
	float GetCounterValue() {
		return m_pUCCounter->GetFPValue();
	}
	;
	float GetCounterLimit() {
		return m_pUCConfig->RolloverAt;
	}
	;
	float GetCounterStartValue() {
		return m_pUCConfig->StartAt;
	}
	;
	BOOL IsEnabled() {
		return m_pUCConfig->Enabled;
	}
	;
private:	// Member variables
	BOOL m_oldConfigAvailable;			// Is an old config available to check for changes?
	int m_Instance;						// User counter Instance
	T_PCOUNTERSDATA m_pUCConfig;		// Ptr to User counter configuration
	T_COUNTERSDATA m_OldConfig;			// Instance of counter configuration
	CDataItemCounter *m_pUCCounter;		// Ptr to User counter Data Item table
};
//**Class*********************************************************************
///
/// @brief Helper for each effect
/// 
/// Provide support for the individual effects
///
///
//****************************************************************************
class CEventEffect {
public:		// API methods
	CEventEffect();
	void Setup(int Instance, T_PEVENTEFFECT pConfig);
	BOOL IsEnabled() {
		return m_Enabled;
	}
	;
	void ResetList();
	void BuildList(int bytesToConvert);
	void Trigger(const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX, const USHORT usTRIGGER_INSTANCE);
	void TriggerTotaliserAction();
	void TriggerAlarmAcknowledgeOrReset(T_ALARM_REQUEST reqType);
	void TriggerLoggingAction();
	void TriggerCounter();
	void TriggerMaxMinReset();
	void TriggerChartControl();
	void TriggerTimerControl();
	BOOL IsLinkEffect();
	BOOL TestAndTriggerDelayedEvent();
	void ResetDelayedEvent() {
		m_LinkEvent.ResetLinkEvent();
	}
	;
private:	// Methods
	//	Method that triggers the sending of an email
	void TriggerEmail(const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX, const USHORT usTRIGGER_INSTANCE) const;
	//	Method that creates the email header string
	const QString CreateEmailHeader(const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX,
			const USHORT usTRIGGER_INSTANCE) const;
private:	// Member variables
	BOOL m_Enabled;											///< Is Effect Enabled
	T_PEVENTEFFECT m_pEffectConfig;							///< Configuration for Effect
	int m_Instance;											///< Instance of effect
	USHORT m_ItemList[EVENTEFFECT_ITEMLIST_SIZE];			///< Expanded bitmask into a sequntial list for speed
	USHORT m_ItemListLength;								///< Number of items in sequnetial list
	CDataItemDigitalIOUser digIO;							///< Digital IO usage
	CUserCounter *m_pUserCounter;							///< Ptr to user counter if within effects
	CLinkEventTimer m_LinkEvent;
};
//**Class*********************************************************************
///
/// @brief Control for individual events
/// 
/// Provide all processing for individual events
///
///
//****************************************************************************
class CEventControl {
public:		// API methods
	CEventControl();
	void Initialise(int instance);
	BOOL IsEnabled() {
		return m_Enabled;
	}
	;
	T_EVENT_CONTROL_RETURN SetupEventFromConfig(T_PEVENT pConfig, T_PEVENT pOldConfig);
	BOOL HasActiveType(T_EVENT_CAUSE_TYPE targetType);
	T_EVENT_CONTROL_RETURN TriggerFromCause(T_EVENTQUEUE_ELEMENT *pEventCause);
	CEventSchedule* GetSchedulePtr(int scheduleIndex) {
		return &m_schedule[scheduleIndex];
	}
	;
	BOOL IsScheduleActive(int scheduleIndex) {
		return m_schedule[scheduleIndex].IsEnabled();
	}
	;
	// Schedule countdown NV access
	USHORT GetSchedCount(int index) {
		return m_NVvalue.us[index];
	}
	;
	void SetSchedCount(int index, USHORT count) {
		m_NVvalue.us[index] = count;
	}
	;
	void ResetEventCount() {
		m_pECDataItem->ResetCounter(0);
	}
	;
	void TriggerFromCounterCheck();
	CTVtime GetNextScheduleTime(int causeIndex) {
		return m_schedule[causeIndex].GetNextScheduleTime();
	}
	;
	CEventEffect* GetEventEffectPtr(int effectNo) {
		return &m_effect[effectNo];
	}
	;
private:	// Methods
	BOOL MatchEventCause(int CauseInstance, T_EVENTQUEUE_ELEMENT *pEventCause, ULONG &rulTRIGGER_INSTANCE);
	void TriggerEffects(int effectInstance);
	// Event counter NV access
	float GetEventCount() {
		return m_pECDataItem->GetFPValue();
	}
	;
	void IncrementEventCount() {
		m_pECDataItem->IncrementCounter(1);
	}
	;
	// Time NV information( last time event fired )
	LONGLONG GetNVTime() {
		return m_NVtime;
	}
	;
	void TouchNVTime() {
		m_NVtime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
	}
	;
	void ResetNVTime() {
		m_NVtime = 0;
	}
	;
	void UpdateNVData() {
		m_pNVData->SetToNV(m_NVvalue, m_NVtime);
	}
	;
private:	// Member variables
	BOOL m_Enabled;
	int m_Instance;
	T_PEVENT m_pEventConfig;
	CEventEffect m_effect[EVENT_EFFECT_SIZE];		// Effect operation and optimisation class for each effect instance
	CEventSchedule m_schedule[EVENT_CAUSE_SIZE];	// Allow a schedule for each available cause
	BOOL UserCounterTriggered[EVENT_CAUSE_SIZE];	// State to show that user counters have been triggered already	
	CNVBasic8TimeVar *m_pNVData;					///< Pointer to NV Data
	COMBO_VAR8 m_NVvalue;							///< NV data value
	LONGLONG m_NVtime;								///< NV Time
	CDataItemCounter *m_pECDataItem;				///< Event count data Item
};
#endif //__EVENTCONTROL_H__

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Error Control System
/// @n Filename:	ErrorControl.h
/// @n Description: Definition for the CErrorControl class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 12	Stability Project 1.9.1.1	7/2/2011 4:57:05 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 11	Stability Project 1.9.1.0	7/1/2011 4:27:49 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 10	V6 Firmware 1.9		8/16/2007 5:27:46 PM	Roger Dawson 
//		Added code to hold back from displaying password netsync errors until
//		the recorder has been up and running for at least a minute after the
//		process screen has been displayed. This prevents the error dialog
//		appearing when a large group of recorders startup and the master
//		starts up slightly later than the rest.
// 9	V6 Firmware 1.8		4/26/2007 1:56:53 PM	Roger Dawson 
//		Increased the priority of the password netsync failure as it is
//		considered more important than memory problems.
// $
//
// **************************************************************************
#if !defined(AFX_ERRORCONTROL_H__523A666B_A8B7_486B_97EA_AC575CA24394__INCLUDED_)
#define AFX_ERRORCONTROL_H__523A666B_A8B7_486B_97EA_AC575CA24394__INCLUDED_
#include "V6Config.h"
#include "Defines.h"
#include <QMutex>
/// Enum indicating the error types
typedef enum {
	retDEF_MAC,
	retDEF_SERIAL,
	retCABLE_UNPLUGGED,
	retPWD_NET_SYNC_FAILURE,
	retINT_MEM_LO,
	retEXT_MEM_LO,
	retEXT_MEDIA_MISSING,
	retFTP_MEM_LO,
	retCJC_MISSING,
	retTC_BURNOUT,
	retSecondary_Failure,
	retSecondary_CRC_Failure,
	retBattery_Status,
	// The Event System uses the next twenty items
	retFIRST_EVENT,
	retLAST_EVENT = (retFIRST_EVENT + EVENTSYSTEM_EVENT_SIZE),
	retMAX_ERROR_TYPES
} T_RECORDER_ERROR_TYPES;
// Const indicating the max error message length
static const ULONG s_ulMAX_ERROR_BYTES = 200;
//**CErrorControl*********************************************************************
///
/// @brief Singleton class responsible for processing errors and storing their states. The error
///	dialog itself periodically checks for new error conditions and displays them accordinly
/// 
/// Singleton class responsible for processing errors and storing their states. The error
///	dialog itself periodically checks for new error conditions and displays them accordinly
///
//****************************************************************************
class CErrorControl {
public:
	// Singleton Accessor/Creator
	static CErrorControl* Instance();
	// Destructor
	virtual ~CErrorControl();
	/// Enum indicating the error types
	enum T_ERROR_STATES_TO_REPORT {
		esrIN_ERROR, esrHAS_BEEN_IN_ERROR, esrBOTH
	};
	// Method that returns the highest priority error information
	const bool GetHighestPriorityError(QString &rstrMessage, COLORREF &crBorderColour, COLORREF &crBackgroundColour,
			bool &rbFlashBorder, T_RECORDER_ERROR_TYPES &reErrorType);
	// Method that updates the error information, usually following a user acknowledging a message	
	void ErrorConditionAck(const T_RECORDER_ERROR_TYPES eERROR_TYPE);
	// Event called when a TC Burnout state changes
	void TCBurnoutError(const bool bTC_BURNOUT, const USHORT usSYSTEM_CHANNEL_NO);
	// Event called when a CJC state changes
	void CJCMissingError(const bool bCJC_MISSING, const USHORT usSLOT_NO);
	void ReportSecondaryFailure();
	void ReportSecondaryFwCRCFailure();
	// Method that sets the correct states for a particular error
	void UpdateErrorCondition(const T_RECORDER_ERROR_TYPES eERROR_TYPE, const bool bIN_ERROR_STATE,
			QString &rstrErrorMessage);
private:
	// Constructor
	CErrorControl();
	// Singleton auto pointer
	static std::auto_ptr<CErrorControl> ms_kErrorControl;
	// Handle to the creation mutex
	static QMutex ms_hCreationMutex;
	// Critical section required when updating the error information from the error dialog or
	// the top status bar
	static QMutex m_kCriticalSection;
	/// Union containing additional information for particular events
	typedef union {
		BYTE B[16];
		USHORT S[8];
		ULONG L[4];
		quint64 LL[2];
	} T_ADDITIONAL_INFO_UNION;
	/// Structure containing the error information for a single error type
	typedef struct {
		// Flag indicating if the current error condition is valid e.g. on display, pending or waiting
		// for reflash
		bool bValid;
		// Flag indicating current error condition state
		bool bInErrorState;
		// Flag indicating whether the error needs to be displayed
		bool bPending;
		// Time indicating when the error was first triggered (since it was last cleared)
		LONGLONG llFirstTriggerTime;
		// Time indicating when the error was last cleared - used for reflash
		LONGLONG llReflashTime;
		// The error message to display
		WCHAR wcaErrorMessage[s_ulMAX_ERROR_BYTES];
		// Store for additional information that may be required for a particular error e.g the 
		// Lowest time that the internal memory has reached before the message was cleared or acknowldged
		T_ADDITIONAL_INFO_UNION AdditionalData;
	} T_RECORDER_ERROR_INFO;
	// Array containing 
	T_RECORDER_ERROR_INFO m_kaERROR_TYPES[retMAX_ERROR_TYPES];
	// Const indicating the byte that contains the CJC's in error states
	const USHORT m_usCJC_IN_ERROR_STATE_BYTE_POS;
	// Const indicating the byte that contains the CJC's that were in the error states
	const USHORT m_usCJC_HAVE_BEEN_IN_ERROR_STATE_BYTE_POS;
	// Const indicating the longlong that contains the TC's in error states
	const USHORT m_usTC_IN_ERROR_STATE_LONGLONG_POS;
	// Const indicating the longlong that contains the TC's that were in the error states
	const USHORT m_usTC_HAVE_BEEN_IN_ERROR_STATE_LONGLONG_POS;
	// Start countdown varaible used to hold back password netsync errors that might occur while the master 
	// is still starting up - measured in seconds although this is actually determined by the status bar
	// update rate
	USHORT m_usNetSyncCountdown;
	// Method that checks the error states of errors handled by this class e.g. network cable unplugged
	void CheckErrorStates();
	// Method that checks the mac address is not set to the default
	void CheckMACAddress();
	// Method that checks the serial number is not set to the default
	void CheckSerialNo();
	// Method that checks the state of the network connection
	void CheckNetworkConnection();
	// Method that checks the state of the internal memory
	void CheckIntMem();
	// Method that checks the state of the scheduled export device
	void CheckSchedExportDev();
	// Method that checks if the scheduled export device is present
	void CheckSchedExportDevMissing();
	// Method that checks the state of the FTP memory
	void CheckFTPMem();
	// Method that checks the CJC error state (reflash)
	void CheckCJCError();
	// Method that checks the TC error state (reflash)
	void CheckTCError();
	// Method that checks the battery life
	void CheckBatteryStatus();
	// Method that determines if an error is configured to be displayed
	const bool DisplayError(const T_RECORDER_ERROR_TYPES eERROR_TYPE) const;
	// Method that converts the CJC error bitfield's into displayable strings
	const QString GetCJCErrorInfo(const T_ERROR_STATES_TO_REPORT eERROR_STATES_TO_REPORT) const;
	// Method that converts the TC error bitfield's into displayable strings
	const QString GetTCErrorInfo(const T_ERROR_STATES_TO_REPORT eERROR_STATES_TO_REPORT) const;
};
#endif // !defined(AFX_ERRORCONTROL_H__523A666B_A8B7_486B_97EA_AC575CA24394__INCLUDED_)

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Events
/// @n Filename: EventManager.h
/// @n Desc:	Main event manager and processor
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 26	Stability Project 1.23.1.1	7/2/2011 4:57:08 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 25	Stability Project 1.23.1.0	7/1/2011 4:27:43 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 24	V6 Firmware 1.23		9/23/2008 3:09:24 PM	Build Machine 
//		AMS2750 Merge
// 23	V6 Firmware 1.22		2/6/2008 6:39:33 PM	Andy Kassell	Add
//		public accessor for OpPanel member
// $
//
// ****************************************************************
#ifndef __EVENTMANAGER_H__
#define __EVENTMANAGER_H__
#include "EventControl.h"
#include "PassiveModule.h"
#include "TV6Timer.h"
#include "NVVariables.h"
#include "V6globals.h"
#include "OpPanelIncludes.h"
#include "BatchManager.h"
typedef enum {
	EVENTMANAGER_OK, EVENTMANAGER_FAILED,
} T_EVENT_MANAGER_RETURN;
const int MAX_EVENTLIST_ELEMENTS = 1000;
const int NOTHING_IN_EVENT_QUEUE = -1;
const int MAX_DIGITAL_IO_MASKS = 3;	// Number of digital IO masks in data item table
const int TOTAL_EVENT_SCHEDULES_CAUSES = EVENTSYSTEM_EVENT_SIZE * EVENT_CAUSE_SIZE;
const int TOTAL_EVENT_EFFECTS = EVENTSYSTEM_EVENT_SIZE * EVENT_EFFECT_SIZE;
//**Class*********************************************************************
///
/// @brief List of event controls
/// 
/// A list of event controls
///
//****************************************************************************
class CEventControlList {
public:
	CEventControlList() {
		ResetList();
	}
	;
public:		// API methods
	CEventControl* GetEntry(USHORT Index) {
		return m_pControl[Index];
	}
	;
	void ResetList();
	void AddControlToList(CEventControl *pControl);
	const USHORT NumEventControlsInList() {
		return m_NumEntries;
	}
	;
private:	// Member variables
	CEventControl *m_pControl[EVENTSYSTEM_EVENT_SIZE];
	USHORT m_NumEntries;
};
//**Class*********************************************************************
///
/// @brief Manage events within the recorder
/// 
/// Manage the entire event system
///
/// This class is a singleton.
///
//****************************************************************************
class CEventManager: public CPassiveModule {
public:		//Singleton 
	static CEventManager* GetHandle();
	void CleanUp();
private:	// Singleton
	CEventManager();
	~CEventManager() {
	}
	;	// Will never be called
	CEventManager(const CEventManager&);
	CEventManager& operator=(const CEventManager&) {
		return *this;
	}
	;
	static CEventManager *m_pEventManInstance;
	static QMutex m_CreationMutex;
public:	// API methods
	// Initialise and shutdown of device abstraction
	T_EVENT_MANAGER_RETURN Initialise();
	T_EVENT_MANAGER_RETURN ImplementConfiguration();
	T_EVENT_MANAGER_RETURN Process();
	T_EVENT_MANAGER_RETURN PrepareForConfigChange();
	T_EVENT_MANAGER_RETURN ProcessScreenSaver();
	// Cause activation methods
	void TotaliserActionCause(USHORT totalAction, T_EVENTDATA *pTotaliserMask);
	void MaxMinResetCause(USHORT penNumber);
	void AlarmTransitionCause(USHORT PenNumber, USHORT AlarmNumber, T_EVENT_ALARM_CAUSE_SUBTYPE transitionType);
	void TCBurnoutCause(USHORT AnalogueNumber);
	void DirectEventTrigger(int eventIndex);
	void SystemEventTrigger(T_SYSTEM_EVENT_SUBTYPE sysType);
	void UserActionEventTrigger(T_USER_EVENT_SUBTYPE userType);
	void BatchEventTrigger(T_BATCH_EVENT_SUBTYPE batchOperation, int groupNumber);
	// Trigger a TUS event
	void TUSEventTrigger(const T_TUS_EVENT_SUBTYPE eTUS_OPERATION);
	// Trigger an AMS2750 Timer event
	void AMS2750TimerEventTrigger(const T_AMS2750_TIMER_EVENT_SUBTYPE eTIMER_TYPE,
			const T_AMS2750_TIMER_EVENT_ALERT_TYPE eALERT_TYPE);
	//Trigger an event for TC health monitor
	void TCHealthMonitorEventTrigger(USHORT AnalogueNumber, USHORT HealthStatus, USHORT BurnOutType = 0);
	// Backlight event triggers
	void EventTriggerBackLightOff();
	void EventTriggerBackLightOn();
	// static helpers
	static void SetBitInMask(int BitToSet, T_EVENTDATA *pDataMask);
	static BOOL GetBitInMask(int BitToGet, T_EVENTDATA *pDataMask);
	static void ClearMask(T_EVENTDATA *pDataMask);
	static BOOL AreAnyBitsSet(T_EVENTDATA *pDataMask);
	float GetBacklightExpiredInMinutes() {
		return m_backLightLifeInMins.flt;
	}
	;
	CUserCounter* GetUserCounter(int counter) {
		return &m_UserCounter[counter];
	}
	;
	CEventControl* GetEventControl(int control) {
		return &m_evtControl[control];
	}
	;
	CTVtime GetNextScheduleTime(int EventIndex, int EffectIndex);
	void ResetReplayTimeOut() {
		m_ReplayTimer.StartTimer();
	}
	;
	ULONG ReplayInactivityTime() {
		return static_cast<ULONG>(MSEC_TO_SEC(m_ReplayTimer.ElapsedTimeInMilliSeconds()));
	}
	;
	COpPanel* GetOpPanel() {
		return m_pOpPanel;
	}
	;
private:	// Methods
	T_EVENT_MANAGER_RETURN AddEventCauseToQueue(T_EVENTQUEUE_ELEMENT *pEventCause);	///< Add an event to the queue
	int GetEventCauseFromQueue(T_EVENTQUEUE_ELEMENT *pEventCause);	///< Get the oldest event from the queue
	int GetNumberOfItemsInQueue() {
		return m_QueueNumItems;
	}
	;					///< Get number if items currently in queue
	void ResetCauseQueue();
	void PerformDigitalIOCause();
	void SwitchOnSaver(BOOL SaveOn);
	void PerformScheduleEventCheck();
	void PerformCounterCauseCheck();
	void PerformDelayedEventCheck();
	//TimeSync..
	T_EVENT_MANAGER_RETURN CheckAndSyncTimeOnDigital();
private:	// Member variables
	BOOL m_Initialised;	///< Indicates if the EventManager has been initialised
	T_EVENTQUEUE_ELEMENT m_evtQueue[MAX_EVENTLIST_ELEMENTS];	///< Dedicated event queue, for maximum speed
	int m_QueueLatest;				///< Latest index, used for adding to queue
	int m_QueueOldest;			///< Oldest Index, used for removing from queue
	int m_QueueNumItems;				///< Number of items currently in queue
	QMutex m_accessQueue;	///< Critical section for access to the event queue
	CEventControl m_evtControl[EVENTSYSTEM_EVENT_SIZE];	/// Actual event instances
	CEventSchedule *m_pScheduleList[TOTAL_EVENT_SCHEDULES_CAUSES];	// Maintain a list of active schedules
	int m_NumberOfSchedules;						// Total number of schedules
	CEventControlList m_ActiveEvents;		///< List of active event controls
	CEventControlList m_RoutineTable[ectMaxTypes];		///< routine table for causes and types
	T_PEVENTSYSTEM pEventConfig;
	T_EVENTSYSTEM m_oldEventConfig;	///< Copy of previous event config to detrmine exact changes
	BOOL m_DigitalCauseEnabled;		///< Shows if a digital cause is enabled.
	T_EVENTDATA m_digitalCache;				///< Maintain the digital IO changes
	BOOL m_firstIn;	///< Maintain state of first time though the event system
	CDataItemIO *m_pDigIODataItem[MAX_DIGITAL_IO_MASKS];	///< pointer to data item table for digital IO masks
	USHORT m_workingDigMask[MAX_DIGITAL_IO_MASKS];	///< Working digital masks
	T_PSCREENGENERAL m_pSSConfig;	///< Pointer to Screen Saver Configuration
	CTV6Timer m_SSTimer;								///< Screen saver timer
	CTV6Timer m_ReplayTimer;				///< Replay mode inactivity timer
	BOOL m_ScreenInSaveMode;		///< TRUE if screen save on, FALSE if off
	COpPanel *m_pOpPanel;					///< Handle on OpPanel to get status
	// Pointers to Life history information
	CNVBasicVar *pNVBacklightLife;
	COMBO_VAR4 m_backLightLifeInMins;			///< latest backlight life time
	float m_normalBrightnessFactor;				///< normal brightness fraction
	float m_saverBrightnessFactor;				///< saver brightness fraction
	CUserCounter m_UserCounter[COUNTERS_COUNTER_SIZE];		///< User counters
	int m_totalNumberOfTiggerEffects;			///< Number of triggere effects
	CEventEffect *m_pEffectForLink[TOTAL_EVENT_EFFECTS];///< list of pointer to active event link effects (for event trigger from another event)
	BOOL m_BackLightOffByEvent;	///< Indicates if the switch backlight off by screensave event has been triggered
	BOOL m_BackLightOffByEventTriggered;	///< Indicates if the backlight has been switch off for the same event
	//TimeSync...
	CDataItemIO *pTimeSyncDataItem;
	USHORT oldDigState;
	BOOL digTestFirstIn;
};
// Define global accessor within the EventManager rather then V6Globals to avoid adding to other projects
extern CEventManager *pGlbEventManager;		///< Pointer to the event manager
#define pEVENTS			pGlbEventManager					///< Event system global
#endif //__EVENTMANAGER_H__

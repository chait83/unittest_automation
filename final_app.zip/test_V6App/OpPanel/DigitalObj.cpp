/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: DigitalObj.cpp
/// @n Description: Digital Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  51  Stability Project 1.46.1.3 7/2/2011 4:56:46 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  50  Stability Project 1.46.1.2 7/1/2011 4:38:14 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  49  Stability Project 1.46.1.1 3/17/2011 3:20:22 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  48  Stability Project 1.46.1.0 2/15/2011 3:02:57 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "MathUtils.h"
#include <math.h> // for fabs()
#include <float.h> // for FLT_MAX
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// CDigitalObject Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
/// 
//****************************************************************************
CDigitalObject::CDigitalObject(CWidget *pParentWidget) : CBaseObject(pParentWidget) {
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data begin
	m_bDisplayStar = false;
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data end
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CDigitalObject::OnDraw;
	// set all of the objects internal settings to defaults
	m_CurrentValue = 0.0;
	m_CurrentStatus = DISTAT_NORMAL;
	m_pForeAlarmColour = NULL;
	m_pBackAlarmColour = NULL;
	m_InAlarm = FALSE;
	m_IsLogScale = FALSE;
	memset(&m_Numberasprintf, 0, sizeof(T_NUMFORMAT));
	m_Numberasprintf.Ad = 2; // 2dp.
	wcscpy_s(m_pasprintfStr, sizeof(m_pasprintfStr) / sizeof(WCHAR), L"%%.2f");
	m_pDataItemRef = NULL;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
/// 
//****************************************************************************
void CDigitalObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CDigitalObject data in CMM info block.
	m_pCMMdigital = (T_DIGITALOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		// digital has 1 channel reference
		// reference - default to pen, enabled and updating
		m_pCMMdigital->ChannelInfo.Enabled = TRUE;
		m_pCMMdigital->ChannelInfo.Updates = TRUE;
		m_pCMMdigital->ChannelInfo.ItemType = DI_PEN;
		m_pCMMdigital->ChannelInfo.SubType = 0;
		m_pCMMdigital->ChannelInfo.IndexChan = 0; // use Widget's channel by default
		// set these flags for specific Object (e.g. may be advanced draw only)
		/*
		 m_pCMMbase->IsAdvancedDraw
		 m_pCMMbase->IsBuffered
		 m_pCMMbase->IsPermanent
		 m_pCMMbase->IsBackground
		 m_pCMMbase->IsPrimaryDirect
		 // etc...
		 */
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
	}
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CDigitalObject::ConfigChange() {
	// Data item configuration done here. 
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	// CDigitalObject only has TWO data item references
	if (!m_pDataItemRef)
		m_pDataItemRef = new CDataItemRef(this); // create our Pen reference (always)
	// pass it to our Widget, along with our CMM config
	BOOL refValid = m_pDataItemRef && (m_pWidget->GetDataItem(m_pDataItemRef, &m_pCMMdigital->ChannelInfo));
	// Set our members based on CMM settings and data item info
	// T_BASEOBJECT CMM config to CBaseObject members:
	// use background colour from CMM (e.g. as selected in Screen Designer)	as default
	m_pBackColour = &m_pCMMbase->BackColour;
	if (!m_pCMMbase->FixBackColour) {
		if (m_pCMMbase->AttrBlocks.BackColourBlk)
			// use foreground colour from Attribute block
			m_pBackColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
					m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
		else if (refValid)
			// use background colour from Data Item Table item					
			m_pBackColour = m_pDataItemRef->m_pDataItem->GetColour();
	}
	if (refValid && (GetOpPanel()->m_pReplayScreen) && (!m_pDataItemRef->m_pDataItem->IsEnabled())) {
		// here (only for replay use) if disabled, set forecolour to backcolour
		m_pForeColour = m_pBackColour;
	} else {
		// use foreground colour from CMM (e.g. as selected in Screen Designer) as default
		m_pForeColour = &m_pCMMbase->ForeColour;
		if (!m_pCMMbase->FixForeColour) {
			if (m_pCMMbase->AttrBlocks.ForeColourBlk)
				// use foreground colour from Attribute block
				m_pForeColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
						m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
			else if (refValid)
				// use foreground colour from Data Item Table item
				m_pForeColour = m_pDataItemRef->m_pDataItem->GetColour();
		}
	}
	// use flash atrtribute from Attribute block if set (0=default=FALSE)
	// This is flashing in general of an object, and here has nothing to do with flashing due to an alarm.(but may do below)
	m_pFlashing =
			&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.FlashingBlk)->Flashing;
	// use visible atrtribute from Attribute block if set (0=default=TRUE)
	m_pVisible = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
	m_pForeAlarmColour = m_pBackColour;
	m_pBackAlarmColour = m_pForeColour;
	// T_DIGITALOBJECT CMM config to CDigitalObject members:
	// alarm setup - only if enabled.
	if (m_pCMMdigital->ChannelInfo.Enabled) {
		// use alarm foreground colour from CMM (e.g. as selected in Screen Designer)
		m_pForeAlarmColour = &m_pCMMdigital->FGAlarmCol;
		if (!m_pCMMdigital->ChgFGonAlarm) {
			// it's not a single fixed colour. Do want flashing foreground colour on alarm ?
			if (m_pCMMdigital->FlshFGonAlarm) {
				// here update m_pFlashing, now to be used for alarms.
				m_pFlashing = &m_InAlarm;	// m_InAlarm will get set when alarm is active.
				m_pForeAlarmColour =
						&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_OVERVIEW)->FGCol;
			} else
				// use normal foreground colour from above.
				m_pForeAlarmColour = m_pForeColour;
		}
		// for flashing the background on alarm
		if (m_pCMMdigital->FlshBGonAlarm) {
			// here update the m_pFlashing to be used for alarms.
			m_pFlashing = &m_InAlarm;	// m_InAlarm will get set when alarm is active.
			m_pBackAlarmColour =
					&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_OVERVIEW)->BGCol;
		} else
			// use normal background colour from above.
			m_pBackAlarmColour = m_pBackColour;
	}
	// here set up the display format string
	if (refValid) {
		T_PSCALEINFO pScaleDetails = m_pDataItemRef->m_pDataItem->GetScaleInfo();
		m_Numberasprintf = m_pCMMdigital->Numformat; // use that saved in the CMM for this digital
		if (!m_pCMMdigital->FixNumasprintf)
			if (m_pDataItemRef)
				m_Numberasprintf = pScaleDetails->NumF; // use that from data item table above
		CMathUtils::InitNumberasprintf(m_Numberasprintf, m_pasprintfStr,
				(sizeof(m_pasprintfStr) / sizeof(m_pasprintfStr[0])), pScaleDetails); //coverity fix #780409
		m_IsLogScale = pScaleDetails->LogScale;
	}
}
UINT ex = 0x7f800000; // exponent	
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CDigitalObject::OnDraw(CDigitalObject *pThis, HDC hdc, QRect *pClipRect) {
	//if(pThis->isObjectOverlapped()) 
	//	return;
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data begin		
	// if Update Required make any updates due to data item changes/flashing then do a repaint
	if (pThis->m_UpdateRequired) {
		if (false == pThis->IsDisplayStar()) //Perform normal display with DIT
				{
			//update values only if the DisplayStar set to false
			if (pThis->m_UpdateValue) {
				// Get latest values from Data Item Table	
				// NB: these should always be copied to members within the Object, 
				// so that we can draw the same value next time if required.
				pThis->m_CurrentStatus = pThis->m_pDataItemRef->m_pDataItem->GetStatus();
				if (pThis->m_IsLogScale) {
					float value = pThis->m_pDataItemRef->m_pDataItem->GetFPValue();
					// if we are processing a total and have log scale, use the normal (linear) value
					if (pThis->m_pDataItemRef->m_pDataItem->GetType() == DI_TOTAL) {
						pThis->m_CurrentValue = value;
					} else	// normal case, processs as 10^(value)
					{
						// the value in the DIT is the decade value. 10 to the power of this is the value we want.
						if (value > MAX_POWER_OF_10)	// 10^38.53 is almost FLT_MAX
							pThis->m_CurrentValue = FLT_MAX;
						else
							pThis->m_CurrentValue = pow((float) 10.0, value);
					}
					UINT test = *((UINT*) &pThis->m_CurrentValue); // cast float to UINT and test for invalid				
					// test for FLT_MAX and set status to up arrows if found
					// still do the basic test for invalid value
					if (pThis->m_CurrentValue == FLT_MAX)		// show FLT_MAX as up arrows
					{
						pThis->m_CurrentStatus = DISTAT_INPUT_OVERRANGE;
					} else if ((test & ex) == ex) {
						pThis->m_CurrentStatus = DISTAT_INVALID;
					}
				} else
					pThis->m_CurrentValue = pThis->m_pDataItemRef->m_pDataItem->GetFPValue();
				// update the alarm state (if enabled)
				if (pThis->m_pCMMdigital->EnableAlarm) // using the associated alarm?			
					pThis->m_InAlarm = pThis->m_pDataItemRef->m_pDataItem->GetAlarmStatus();
				pThis->m_UpdateValue = FALSE;
			}
		}
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	}
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data end
	//pThis->m_CurrentValue=pThis->m_pDataItemRef->m_pDataItem->GetFPValue();
	// Optimised drawing for direct foreground:
	// here if pClipRect is null (drawing an update)
	// we could check the pThis->m_pCMMbase->IsBuffered flag.
	// For updates to a non-buffered Object (direct foreground) we can optimise our
	// drawing (just the updating parts) knowing that this object does not overlap any other,
	// (therefore the rest of the object will still be OK)
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	BOOL DrawInFlashState = FALSE;
	if (*(pThis->m_pFlashing)) // if we are flashing set our drawInFlashState.
		DrawInFlashState = pThis->m_FlashState;
	if (pThis->m_pCMMdigital->ChgFGonAlarm) // takes precidence over flashing.
	{
		if (pThis->m_InAlarm)
			SetTextColor(hdc, *pThis->m_pForeAlarmColour);
		else
			SetTextColor(hdc, *pThis->m_pForeColour);
	} else // for flashing (either general or for alarm)
	{
		if (DrawInFlashState)
			SetTextColor(hdc, *pThis->m_pForeAlarmColour);
		else
			SetTextColor(hdc, *pThis->m_pForeColour);
	}
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data begin		
	wchar_t Text[50];
	// under range and over range and total paused done with EUDC characters 
	wchar_t SymbolText[2] = { 0, 0 };
	int Symbolwidth = 30; // width of over and under range characters
	if (false == pThis->IsDisplayStar()) //Perform normal display
			{
		if (pThis->m_CurrentStatus < DISTAT_NORMAL) {
			// fill with large '*' EUDC chars.
			Text[0] = 0xE027;
			Text[1] = 0xE027;
			Text[2] = 0xE027;
			Text[3] = 0xE027;
			Text[4] = 0x0000;
			//MarkD: add arrows for known out-of-range conditions
			if (pThis->m_CurrentStatus == DISTAT_INPUT_OVERRANGE) {
				Text[0] = 0xE051;
				Text[1] = 0xE051;
				Text[2] = 0xE051;
				Text[3] = 0xE051;
			}
			if (pThis->m_CurrentStatus == DISTAT_INPUT_UNDERRANGE) {
				Text[0] = 0xE050;
				Text[1] = 0xE050;
				Text[2] = 0xE050;
				Text[3] = 0xE050;
			}
			if (pThis->m_CurrentStatus == DISTAT_INPUT_UPSCALE_BURNOUT) {
				Text[0] = 0xE051;
				Text[1] = 0xE051;
				Text[2] = 0xE051;
				Text[3] = 0x0000;	// show 3 arrows only, to show a difference to very high temperature
			}
			if (pThis->m_CurrentStatus == DISTAT_INPUT_DOWNSCALE_BURNOUT) {
				Text[0] = 0xE050;
				Text[1] = 0xE050;
				Text[2] = 0xE050;
				Text[3] = 0x0000;	// show 3 arrows only to show a difference to very low temperature
			}
		} else {
			//MarkD: change to scientific when very large, or in log scale, if in Auto mode
			// better to keep log scale consistently in scientific. But if the customer doesn't like it,
			// disable auto decimal places.
			// if processing a total, don't automatically use scientific - just if the number is large.
			BOOL logScale = pThis->m_IsLogScale;
			if (pThis->m_pDataItemRef->m_pDataItem->GetType() == DI_TOTAL)
				logScale = FALSE;	// don't automatically apply scientific if it's a total
			if ((pThis->m_Numberasprintf.Auto == TRUE) && (pThis->m_Numberasprintf.Scientific == FALSE)
					&& ((pThis->m_CurrentValue > 9999999.0) || (pThis->m_CurrentValue < -9999999.0) || logScale))
					// MarkD: if value is higher than can be displayed in normal notation, or is log scale, change to scientific
					{
				// convert the value to formatted string
				swprintf(Text, sizeof(Text) / sizeof(WCHAR), L"%.1e", pThis->m_CurrentValue); // scientific notation
				int length = (int) wcslen(Text);
				wcsncpy_s(&Text[length - 3], 3, &Text[length - 2], 3); // copy last 3 digits (including null) one character back in the string
			} else {
				// convert the value to formatted string
				swprintf(Text, sizeof(Text) / sizeof(WCHAR), pThis->m_pasprintfStr, pThis->m_CurrentValue);
				//MarkD: test for scientific and if so, remove third from last digit to give 2-digit exponent
				if (pThis->m_Numberasprintf.Scientific) {
					int length = (int) wcslen(Text);
					wcsncpy_s(&Text[length - 3], 3, &Text[length - 2], 3); // copy last 3 digits (including null) one character back in the string
				}
				//MarkD:negative out-of-range numbers only display one exponent digit in a DPM. 
				//It would be possible to set Auto up to only print one exponent if the number is a negative number
				// under -10^9. Negative numbers greater than this could be set to display no negative places.
				// But this could also cause confusion due to inconsistency: for now, don't bother
				// The number can be read by clicking to a DPM only screen
			}
		}
		if (pThis->m_CurrentStatus > DISTAT_NORMAL) {
			if (pThis->m_CurrentStatus == DISTAT_UNDERRANGE)
				//SymbolText[0]=0xE000;
				SymbolText[0] = 0xE052;
			if (pThis->m_CurrentStatus == DISTAT_OVERRANGE)
				//SymbolText[0]=0xE001;
				SymbolText[0] = 0xE053;
			if (pThis->m_CurrentStatus == DISTAT_TOTAL_PAUSED) {
				SymbolText[0] = 0xE002;
				Symbolwidth = 28; // 'pause' character is wider.
			}
		}
	} else //DisplayStars set to TRUE
	{
		//Display STARs if the flag is set
		// fill with large '*' EUDC chars.
		//PAR# 1-3K9UACQ - Circular History shows DPM live data -Doug's comment Show "----"
		Text[0] = 0xE034;
		Text[1] = L' ';
		Text[2] = 0xE034;
		Text[3] = L' ';
		Text[4] = 0xE034;
		Text[5] = L' ';
		Text[6] = 0xE034;
		Text[7] = 0x0000;
	}
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data end	
	CFontCache *pfc = CFontCache::GetHandle();
	int yoffset = 0;
	QFont hfont = pfc->GetNumericFont(_Height(pThis->m_ClientRect), &yoffset); // Objects Client Area (bounds less border)
	QFont hOldfont = (QFont) SelectObject(hdc, hfont);
	QRect textrect = pThis->m_ClientRect;
	QRect symbolrect = pThis->m_ClientRect;
	if (SymbolText[0]) {
		SIZE size;
		GetTextExtentPoint(hdc, SymbolText, 1, &size);
		symbolrect.setright(symbolrect).left + (size.cx * Symbolwidth) / 64 + 2;
		if (symbolrect.right > symbolrect.right) // arrow wider than client area?
			symbolrect.setright(symbolrect).right; // make it the full width allowed
		textrect.setleft(symbolrect).right; // otherwise update the client area available for the digital
	}
	if (pThis->m_pCMMbase->IsTransparent) {
		SetBkMode(hdc, TRANSPARENT); // this works like v5. Need full repaint of background to work ok.
		ExtTextOut(hdc, textrect.left, textrect.top - yoffset, ETO_CLIPPED, &pThis->m_ClientRect, Text,
				(UINT) wcslen(Text), NULL);
		if (SymbolText[0])
			ExtTextOut(hdc, symbolrect.left, symbolrect.top - yoffset, ETO_CLIPPED, &symbolrect, SymbolText, 1, NULL);
		SetBkMode(hdc, OPAQUE); // restore it after possibly setting transparent above
	} else {
		// flashing - in general or for an alarm
		if (DrawInFlashState)
			SetBkColor(hdc, *pThis->m_pBackAlarmColour); // yellow etc.
		else
			SetBkColor(hdc, *pThis->m_pBackColour);
		ExtTextOut(hdc, textrect.left, textrect.top - yoffset, ETO_CLIPPED | ETO_OPAQUE, &pThis->m_ClientRect, Text,
				(UINT) wcslen(Text), NULL);
		if (SymbolText[0])
			ExtTextOut(hdc, symbolrect.left, symbolrect.top - yoffset, ETO_CLIPPED | ETO_OPAQUE, &symbolrect,
					SymbolText, 1, NULL);
	}
	SelectObject(hdc, hOldfont);
	pfc->ReleaseFont(hfont);
}
/*	
 int xoffset=pThis->m_ClientRect.left;
 if(pThis->m_IsOverRange || pThis->m_IsUnderRange)
 xoffset+=_Height(pThis->m_ClientRect)*6/14;

 CFontCache *pfc=CFontCache::GetHandle();
 int yoffset=0;
 
 QFont hfont=pfc->GetNumericFont(_Height(pThis->m_ClientRect), &yoffset); // Objects Client Area (bounds less border)
 QFont hOldfont=(QFont)SelectObject(hdc, hfont);
 SetTextColor(hdc,*pThis->m_pForeColour);
 
 if(pThis->m_pCMMbase->IsTransparent)
 {
 SetBkMode(hdc,TRANSPARENT); // this works like v5. Need full repaint of background to work ok.
 ExtTextOut(hdc, xoffset, pThis->m_ClientRect.top-yoffset, ETO_CLIPPED,&pThis->m_ClientRect,Text,wcslen(Text),NULL);
 SetBkMode(hdc,OPAQUE); // restore it after possibly setting transparent above
 }
 else
 {
 SetBkColor(hdc,*pThis->m_pBackColour);
 ExtTextOut(hdc, xoffset, pThis->m_ClientRect.top-yoffset, ETO_CLIPPED|ETO_OPAQUE,&pThis->m_ClientRect,Text,wcslen(Text),NULL);
 }

 if((pThis->m_IsOverRange)||(pThis->m_IsUnderRange))
 {
 // even if it is buffered we need to clip it to ClientRect.
 // update current clipping region
 IntersectClipRect(hdc,pThis->m_ClientRect.left,pThis->m_ClientRect.top,pThis->m_ClientRect.right,pThis->m_ClientRect.bottom);
 if(pThis->m_IsOverRange)
 pThis->DrawUpArrow(hdc);
 
 if(pThis->m_IsUnderRange)
 pThis->DrawDownArrow(hdc);
 // restore clipping region set for screen
 SelectClipRgn(hdc,pThis->m_pWidget->m_pScreen->m_hrgnUpdate);
 }
 
 SelectObject(hdc, hOldfont);		
 pfc->ReleaseFont(hfont);	
 */
/*
 QPoint UpArrow[ARROW_VERTICES]={{3,0},{0,3},{2,3},{2,6},{4,6},{4,3},{6,3}};			
 QPoint DownArrow[ARROW_VERTICES]={{2,1},{2,4},{0,4},{3,7},{6,4},{4,4},{4,1}};			
 //****************************************************************************
 /// 
 ///	Calculate vertices for up and down arrows, scaled on font size.
 ///
 /// @return none
 /// 
 //****************************************************************************
 void CDigitalObject::CalcArrows()
 {
 float sfY=(float)(_Height(m_ClientRect)/7.0); // height of the arrows.
 float sfX=sfY/2;
 for(int i=0; i<7; i++)
 {
 m_UpArrowScaled[i].x=UpArrow[i].x*(long)sfX+m_ClientRect.left;
 m_UpArrowScaled[i].y=UpArrow[i].y*(long)sfY+m_ClientRect.top;
 m_DownArrowScaled[i].x=DownArrow[i].x*(long)sfX+m_ClientRect.left;
 m_DownArrowScaled[i].y=(DownArrow[i].y*(long)sfY+m_ClientRect.top)-1;
 }
 }

 //****************************************************************************
 /// 
 ///	Draw an up arrow
 ///
 /// @param[in] hdc		- Handle to Device Context to use
 ///
 /// @return none
 /// 
 //****************************************************************************
 void CDigitalObject::DrawUpArrow(HDC hdc)
 {
 // Create a pen to and brush to draw and fill Arrow
 QPen hpen= CreatePen(PS_SOLID,1,*m_pForeColour); 
 HBRUSH hbrush = CreateSolidBrush(*m_pForeColour); 
 // select them
 QPen holdpen=(QPen)SelectObject(hdc,hpen);
 HBRUSH holdbrush=(HBRUSH)SelectObject(hdc,hbrush);
 Polygon(hdc, m_UpArrowScaled, ARROW_VERTICES);
 //deselect 
 SelectObject(hdc,holdpen);
 SelectObject(hdc,holdbrush);
 // and delete them
 DeleteObject (hpen);
 DeleteObject (hbrush);	
 
 }

 //****************************************************************************
 /// 
 ///	Draw a down arrow
 ///
 /// @param[in] hdc		- Handle to Device Context to use
 ///
 /// @return none
 /// 
 //****************************************************************************
 void CDigitalObject::DrawDownArrow(HDC hdc)
 {
 // Create a pen to and brush to draw and fill Arrow
 QPen hpen= CreatePen(PS_SOLID,1,*m_pForeColour); 
 HBRUSH hbrush = CreateSolidBrush(*m_pForeColour); 
 // select them
 QPen holdpen=(QPen)SelectObject(hdc,hpen);
 HBRUSH holdbrush=(HBRUSH)SelectObject(hdc,hbrush);
 Polygon(hdc, m_DownArrowScaled, ARROW_VERTICES);
 //deselect 
 SelectObject(hdc,holdpen);
 SelectObject(hdc,holdbrush);
 // and delete them
 DeleteObject (hpen);
 DeleteObject (hbrush);	
 }
 */
//****************************************************************************
///
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CDigitalObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	CBaseObject::SetBounds(bounds, pPos1, pPos2); // call the base Object version
//	CalcArrows(); // recalculate based on new height
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CDigitalObject::Destroy() {
}

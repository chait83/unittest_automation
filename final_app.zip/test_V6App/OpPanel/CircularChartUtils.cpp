/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CircularChartUtils.cpp
/// @n Description: Implementation of the helper class used for calculating 
////				various attributes of circular charts
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]$
//
// **************************************************************************
#include "V6globals.h"
#include "QMDiskServices.h"
#include "CircularChartUtils.h"
#include "conversion.h"
#include <time.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
const int SECONDS_IN_15_MINUTES = SECONDS_IN_A_MINUTE * 15;
const int SECONDS_IN_30_MINUTES = SECONDS_IN_A_MINUTE * 30;
const int SECONDS_IN_4_HOURS = SECONDS_IN_AN_HOUR * 4;
const int SECONDS_IN_8_HOURS = SECONDS_IN_AN_HOUR * 8;
const int SECONDS_IN_12_HOURS = SECONDS_IN_AN_HOUR * 12;
const int SECONDS_IN_2_DAYS = SECONDS_IN_A_DAY * 2;
const int SECONDS_IN_5_DAYS = SECONDS_IN_A_DAY * 5;
const int SECONDS_IN_2_WEEKS = SECONDS_IN_A_WEEK * 2;
const int SECONDS_IN_4_WEEKS = SECONDS_IN_A_WEEK * 4;
const int US_TENTHS_IN_A_SECOND = 1000000;
/// Enum used to indicate each circular chart 'fast' durations. Ensure these values in this enum 
/// always match the index of the strings in IDS_CFG_SCREEN_CIRCULAR_CHART_SPEED_FAST_LIST
enum T_CIRCULAR_CHART_FAST_DURATION {
	CCFD_15_MINUTES, CCFD_30_MINUTES, CCFD_1_HOUR, CCFD_4_HOURS, CCFD_8_HOURS
};
/// Enum used to indicate each circular chart 'medium' duration. Ensure these values in this enum 
/// always match the index of the strings in IDS_CFG_SCREEN_CIRCULAR_CHART_SPEED_MED_LIST
enum T_CIRCULAR_CHART_MED_DURATION {
	CCMD_4_HOURS, CCMD_8_HOURS, CCMD_12_HOURS, CCMD_1_DAY, CCMD_2_DAYS
};
/// Enum used to indicate each circular chart 'slow' duration. Ensure these values in this enum 
/// always match the index of the strings in IDS_CFG_SCREEN_CIRCULAR_CHART_SPEED_SLOW_LIST
enum T_CIRCULAR_CHART_SLOW_DURATION {
	CCSD_2_DAYS, CCSD_5_DAYS, CCSD_1_WEEK, CCSD_2_WEEKS, CCSD_4_WEEKS
};
// The major chart interval quantities and durations, one for each possible chart duration
const int MajorChartIntervalsNos[CCD_NO_OF_CHART_DURATIONS] = { 3, 6, 12, 8, 8, 12, 12, 12, 5, 7, 14, 4 };
const int MajorChartIntervalsDurations[CCD_NO_OF_CHART_DURATIONS] = { 300, 300, 300, 1800, 3600, 3600, 7200, 14400,
		86400, 86400, 86400, 604800 };
// The minor chart interval quantities and durations, one for each possible chart duration
const int MinorChartIntervalsNos[CCD_NO_OF_CHART_DURATIONS] = { 5, 5, 5, 3, 2, 2, 2, 4, 3, 3, 2, 7 };
const int MinorChartIntervalsDurations[CCD_NO_OF_CHART_DURATIONS] = { 60, 60, 60, 600, 1800, 1800, 3600, 3600, 28800,
		28800, 28800, 86400 };
// The subsidiary chart interval quantities and durations, one for each possible chart duration
const int SubsidiaryChartIntervalsNos[CCD_NO_OF_CHART_DURATIONS] = { 2, 0, 0, 2, 3, 3, 3, 0, 4, 2, 0, 0 };
const int SubsidiaryChartIntervalsDurations[CCD_NO_OF_CHART_DURATIONS] = { 30, 0, 0, 300, 600, 600, 1200, 1800, 7200,
		14400, 14400, 28800 };
//****************************************************************************
///
/// Method used to retrieve the realtime chart span for the specified speed and using the time now
///
/// @param[in] pChartInfo - the chart information structure (usually from the recorder profile in the CMM), indicating 
///							aspects such as the actual speed of a fast/med/slow chart and the desired time alignment
/// @param[in] chartSpeed - the current chart speed we wish to retrieve the span information for (fast, medium or slow)
/// @param[out] startTime - the start time for the specified chart speed (inclusive of this actual time
/// @param[out] endTime - the end time for the specified chart speed (non-inclusive of this time i.e. < endTime)
/// @param[out] chartDurationAsStr - the chart duration expressed as a string
///
//****************************************************************************  
void CircularChartUtils::GetCircularChartRealtimeSpan(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
		QTime &startTime, QTime &endTime, QString &chartDurationAsStr) {
	// simply call the historical retrieval method but with an index of 0
	GetCircularChartHistoricalSpan(pChartInfo, chartSpeed, 0, startTime, endTime, chartDurationAsStr);
}
//****************************************************************************
///
/// Method used to retrieve the historical chart span for the specified speed and previous chart index
///
/// @param[in] pChartInfo - the chart information structure (usually from the recorder profile in the CMM), indicating 
///							aspects such as the actual speed of a fast/med/slow chart and the desired time alignment
/// @param[in] chartSpeed - the current chart speed we wish to retrieve the span information for (fast, medium or slow)
/// @param[in] index - an integer value indicating which previous chart index we wish to look at i.e. for a 15 minute
///					  chart speed an index of 0 would return the current realtime span, 1 would return the previous 15
///					  minutes and so on
/// @param[out] startTime - the start time for the specified chart speed (inclusive of this actual time
/// @param[out] endTime - the end time for the specified chart speed (non-inclusive of this time i.e. < endTime)
/// @param[out] chartDurationAsStr - the chart duration expressed as a string
///
//**************************************************************************** 
void CircularChartUtils::GetCircularChartHistoricalSpan(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
		const int index, QTime &startTime, QTime &endTime, QString &chartDurationAsStr) {
	// firstly, get chart span for the specified chart speed
	T_CIRCULAR_CHART_DURATION chartDuration;
	int chartSpanInSeconds = GetChartSpeedSpan(pChartInfo, chartSpeed, chartDuration, chartDurationAsStr);
	// we have a span, now calculate the start time for the selected speed
	QTime startTimeForCurrentTimeSlot(GetChartStartTimeForCurrentTimeSlot(pChartInfo, chartSpanInSeconds));
	// now work back to the correct index and get the start time for that index
	startTime.SetTime(GetChartStartTimeForRequiredTimeSlot(index, chartSpanInSeconds, startTimeForCurrentTimeSlot));
	// now work out the end time
	endTime.SetTime(startTime + ((qint64 ) chartSpanInSeconds * US_TENTHS_IN_A_SECOND));
}
//****************************************************************************
///
/// Method used to get the required chart time divisions
///
/// @param[in] pChartInfo - the chart information structure (usually from the recorder profile in the CMM), indicating 
///							aspects such as the actual speed of a fast/med/slow chart and the desired time alignment
/// @param[in] chartSpeed - the current chart speed we wish to retrieve the span information for (fast, medium or slow)
/// @param[out] chartDivisions - the configuration of the divisions we are to setup within this method
///
//**************************************************************************** 
void CircularChartUtils::GetChartTimeDivisions(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
		T_CIRC_CHART_DIVISIONS &chartDivisions) {
	// firstly, get chart duration enum for the specified chart speed
	T_CIRCULAR_CHART_DURATION chartDuration;
	QString chartDurationAsStr;
	GetChartSpeedSpan(pChartInfo, chartSpeed, chartDuration, chartDurationAsStr);
	chartDivisions.majorDivs.numberOfDivs = MajorChartIntervalsNos[chartDuration];
	chartDivisions.majorDivs.divDurationInSeconds = MajorChartIntervalsDurations[chartDuration];
	chartDivisions.minorDivs.numberOfDivs = MinorChartIntervalsNos[chartDuration];
	chartDivisions.minorDivs.divDurationInSeconds = MinorChartIntervalsDurations[chartDuration];
	chartDivisions.subsideriesPerMinor.numberOfDivs = SubsidiaryChartIntervalsNos[chartDuration];
	chartDivisions.subsideriesPerMinor.divDurationInSeconds = SubsidiaryChartIntervalsDurations[chartDuration];
	// now get the chart queue properties
	GetChartQueueProperties(pChartInfo, chartSpeed, chartDivisions.PointsPerChart, chartDivisions.Tpp);
}
//****************************************************************************
///
/// Method used to retrieve the chart start time for the current time slot (i.e. using the time now)
///
/// @param[in] pChartInfo - the chart information structure (usually from the recorder profile in the CMM), indicating 
///							aspects such as the actual speed of a fast/med/slow chart and the desired time slot alignment
/// @param[in] chartSpanInSeconds - the current chart span in seconds
///
/// @returns	The start time for the current time slot (i.e. realtime) in ms 10ths
///
//**************************************************************************** 
const QTime CircularChartUtils::GetChartStartTimeForCurrentTimeSlot(const T_PCHARTINFO pChartInfo,
		const int chartSpanInSeconds) {
	// this is a number of seconds to remove in order to get to our required date - this is necessary when
	// adjusting the number of hours as we might be going back by a number of days
	qint64 secondsTwiddleFactor = 0;
	// get the date time now
	QDateTime tLocalTimeNow;
	GetV6LocalTime(&tLocalTimeNow);
	// always normalist the seconds and milliseconds
	tLocalTimeNow.wSecond = 0;
	tLocalTimeNow.wMilliseconds = 0;
	// we must now work out the start time for the current time slot - for all chart spans
	// up to daily this is relatively easy, for longer chart spans we need to choose a reference
	// date and work forward from that
	if (chartSpanInSeconds == SECONDS_IN_15_MINUTES) {
		// round to the nearest 15 minute boundary
		tLocalTimeNow.wMinute -= tLocalTimeNow.wMinute % 15;
	} else if (chartSpanInSeconds == SECONDS_IN_30_MINUTES) {
		// round to the nearest 30 minutes
		tLocalTimeNow.wMinute -= tLocalTimeNow.wMinute % 30;
	} else if (chartSpanInSeconds == SECONDS_IN_AN_HOUR) {
		// round to the nearest hour threshold
		tLocalTimeNow.wMinute = 0;
	} else if (chartSpanInSeconds == SECONDS_IN_4_HOURS) {
		tLocalTimeNow.wMinute = 0;
		// round to the nearest 4 hour
		tLocalTimeNow.wHour -= tLocalTimeNow.wHour % 4;
	} else if (chartSpanInSeconds == SECONDS_IN_8_HOURS) {
		tLocalTimeNow.wMinute = 0;
		// round to the nearest 8 hour
		tLocalTimeNow.wHour -= tLocalTimeNow.wHour % 8;
	} else if (chartSpanInSeconds == SECONDS_IN_12_HOURS) {
		tLocalTimeNow.wMinute = 0;
		// round to the nearest 12 hour
		tLocalTimeNow.wHour -= tLocalTimeNow.wHour % 12;
	} else if (chartSpanInSeconds == SECONDS_IN_A_DAY) {
		// day alignment
		tLocalTimeNow.wMinute = 0;
		if (tLocalTimeNow.wHour == pChartInfo->AlignmentHour) {
			// do nothing as the correct hour is selected
		} else if (pChartInfo->AlignmentHour == 0) {
			// simply set the hour to 0
			tLocalTimeNow.wHour = 0;
		} else if (tLocalTimeNow.wHour > pChartInfo->AlignmentHour) {
			// simply set to the alignment hour as it is backward in time but the same day
			tLocalTimeNow.wHour = pChartInfo->AlignmentHour;
		} else if (tLocalTimeNow.wHour < pChartInfo->AlignmentHour) {
			// we need to go back in time, potentially over a day threshold
			// so we must use the twiddle factor instead
			secondsTwiddleFactor = (24 - (pChartInfo->AlignmentHour - tLocalTimeNow.wHour)) * SECONDS_IN_AN_HOUR;
		}
	} else if (chartSpanInSeconds == SECONDS_IN_2_DAYS) {
		tLocalTimeNow.wMinute = 0;
		tLocalTimeNow.wHour = 0;
		// two day alignment requires us to start from the 1st January this current year
		int dayOfYear = GetDayNumber(tLocalTimeNow.wYear, tLocalTimeNow.wMonth, tLocalTimeNow.wDay);
		// go back between 0 and 1 days
		int daysToGoBack = dayOfYear % 2;
		// deduct 0 or 1 days from our current date time if necessary - use the twiddle 
		// factor as it could roll the month over
		secondsTwiddleFactor = daysToGoBack * SECONDS_IN_A_DAY;
	} else if (chartSpanInSeconds == SECONDS_IN_5_DAYS) {
		tLocalTimeNow.wMinute = 0;
		tLocalTimeNow.wHour = 0;
		// five day alignment requires us to start from the 1st January this current year
		int dayOfYear = GetDayNumber(tLocalTimeNow.wYear, tLocalTimeNow.wMonth, tLocalTimeNow.wDay);
		// go back between 0 and 4 days
		int daysToGoBack = dayOfYear % 5;
		// deduct some days from our current date time if necessary - use the twiddle 
		// factor as it could roll the month over
		secondsTwiddleFactor = daysToGoBack * SECONDS_IN_A_DAY;
	} else if (chartSpanInSeconds == SECONDS_IN_A_WEEK) {
		// week alingment requires us to use the day of the week alignment
		tLocalTimeNow.wMinute = 0;
		tLocalTimeNow.wHour = 0;
		// 1 week only, align to mignight on the specified day of the week
		if (tLocalTimeNow.wDayOfWeek == pChartInfo->AlignmentDay) {
			// we already have the correct day so do nothing
		} else if (tLocalTimeNow.wDayOfWeek > pChartInfo->AlignmentDay) {
			// the alignment day was before the current day of the week so simply go
			// back by the difference between the number of days
			secondsTwiddleFactor = (tLocalTimeNow.wDayOfWeek - pChartInfo->AlignmentDay) * SECONDS_IN_A_DAY;
		} else if (tLocalTimeNow.wDayOfWeek < pChartInfo->AlignmentDay) {
			// the alignment day hasn't been reached yet so we must go back to the previous week
			secondsTwiddleFactor = (7 - (pChartInfo->AlignmentDay - tLocalTimeNow.wDayOfWeek)) * SECONDS_IN_A_DAY;
		}
	} else if (chartSpanInSeconds == SECONDS_IN_2_WEEKS) {
		tLocalTimeNow.wMinute = 0;
		tLocalTimeNow.wHour = 0;
		// 2 week alignment requires us to use the start week
		int weekOfYear = GetWeekNumber(tLocalTimeNow.wYear, tLocalTimeNow.wMonth, tLocalTimeNow.wDay);
		// go back between 0 and 1 weeks
		int weeksToGoBack = weekOfYear % 2;
		// deduct some weeks from our current date time if necessary - use the twiddle 
		// factor as it could roll the month over
		secondsTwiddleFactor = weeksToGoBack * SECONDS_IN_A_WEEK;
		// reset the day to Monday
		secondsTwiddleFactor += CalculateMondayNormalisationFactor(tLocalTimeNow.wDayOfWeek);
	} else if (chartSpanInSeconds == SECONDS_IN_4_WEEKS) {
		tLocalTimeNow.wMinute = 0;
		tLocalTimeNow.wHour = 0;
		// 4 week alignment requires us to use the start week
		int weekOfYear = GetWeekNumber(tLocalTimeNow.wYear, tLocalTimeNow.wMonth, tLocalTimeNow.wDay);
		// go back between 0 and 4 weeks
		int weeksToGoBack = weekOfYear % 4;
		// deduct some weeks from our current date time if necessary - use the twiddle 
		// factor as it could roll the month over
		secondsTwiddleFactor = weeksToGoBack * SECONDS_IN_A_WEEK;
		// reset the day to Monday
		secondsTwiddleFactor += CalculateMondayNormalisationFactor(tLocalTimeNow.wDayOfWeek);
	} else {
		// this is an unknown chart speed
		DebugBreak();
	}
	// convert the local time into a time since epoch
	QTime internalTime;
	internalTime.SYSTEMTIMEtoInternal(tLocalTimeNow);
	// remove the twiddle factor as microseconds
	internalTime -= (qint64 ) (secondsTwiddleFactor) * US_TENTHS_IN_A_SECOND;
	return internalTime;
}
//****************************************************************************
///
/// Method used to retrieve the chart start time for the required time slot determined
/// by the passed in index(i.e. using the time now as the starting point) 
///
/// @param[in] index - an integer value indicating which previous chart index we wish to look at i.e. for a 15 minute
///					  chart speed an index of 0 would return the current realtime span, 1 would return the previous 15
///					  minutes and so on
/// @param[in] chartSpanInSeconds - the chart span in seconds
/// @param[in] startTimeForRealtimeTimeSlot - the start time for the realtime time slot i.e. now - using this time
///											 we will need to work backwards to the required index
///
/// @returns	The start time for the required time slot
///
//**************************************************************************** 
const QTime CircularChartUtils::GetChartStartTimeForRequiredTimeSlot(const int index, const int chartSpanInSeconds,
		const QTime startTimeForRealtimeTimeSlot) {
	// calculate the amount of time we need to go back in time
	const qint64 timeJumpBackwardsInSeconds = (qint64 ) chartSpanInSeconds * index * US_TENTHS_IN_A_SECOND;
	// now take the time span above away from the realtime timeslot start time and we have our value
	QTime startTimeForRequiredTimeSlot(startTimeForRealtimeTimeSlot);
	startTimeForRequiredTimeSlot -= timeJumpBackwardsInSeconds;
	return startTimeForRequiredTimeSlot;
}
//****************************************************************************
///
/// Method used to retrieve the chart speed for the specified speed and speed type (fast/med/slow)
///
/// @param[in] pChartInfo - the chart information structure (usually from the recorder profile in the CMM), indicating 
///							aspects such as the actual speed of a fast/med/slow chart and the desired time alignment
/// @param[in] chartSpeed - the current chart speed we wish to retrieve the span information for (fast, medium or slow)
/// @param[out] chartDuration - the duration of the chart given the specified speed and chart info configuration 
/// @param[out] chartDurationAsStr - the chart duration expressed as a string
///
/// @returns	The chart speed span in seconds
///
//**************************************************************************** 
const int CircularChartUtils::GetChartSpeedSpan(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
		T_CIRCULAR_CHART_DURATION &chartDuration, QString &chartDurationAsStr) {
	int chartSpanInSeconds;
	QString chartSpeedList;
	switch (chartSpeed) {
	case SPEED_FAST:
		chartSpanInSeconds = GetFastChartSpeedSpan(pChartInfo->CircFastSpeed, chartDuration);
		// load the fast chart duration list
		chartSpeedList = tr("15 mins|30 mins|1 hour|4 hours|8 hours|");
		// now get the actual chart speed
		chartDurationAsStr = CStringUtils::GetItemAtPos(chartSpeedList, pChartInfo->CircFastSpeed);
		break;
	case SPEED_MEDIUM:
		chartSpanInSeconds = GetMedChartSpeedSpan(pChartInfo->CircMedSpeed, chartDuration);
		// load the fast chart duration list
		chartSpeedList = tr("4 hours|8 hours|12 hours|1 day|2 days|");
		// now get the actual chart speed
		chartDurationAsStr = CStringUtils::GetItemAtPos(chartSpeedList, pChartInfo->CircMedSpeed);
		break;
	case SPEED_SLOW:
	default:
		chartSpanInSeconds = GetSlowChartSpeedSpan(pChartInfo->CircSlowSpeed, chartDuration);
		// load the fast chart duration list
		chartSpeedList = tr("2 days|5 days|1 week|2 weeks|4 weeks|");
		// now get the actual chart speed
		chartDurationAsStr = CStringUtils::GetItemAtPos(chartSpeedList, pChartInfo->CircSlowSpeed);
	}
	return chartSpanInSeconds;
}
//****************************************************************************
///
/// Method used to retrieve the chart drawing/queue properties for the specified speed and speed type (fast/med/slow)
///
/// @param[in] pChartInfo - the chart information structure (usually from the recorder profile in the CMM), indicating 
///							aspects such as the actual speed of a fast/med/slow chart and the desired time alignment
/// @param[in] chartSpeed - the current chart speed we wish to retrieve the span information for (fast, medium or slow)
/// @param[out] pointsPerChart - the number of points used to calcualte one full revolution of the chart
/// @param[out] tpp - the tpp of the points being retrieved from the chart queues
///
/// @returns	The chart speed span in seconds
///
//**************************************************************************** 
const void CircularChartUtils::GetChartQueueProperties(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
		UINT &pointsPerChart, UINT &tpp) {
	// simply fix the number of points per chart at 1800 for now, although this could change
	// and be dependant on the chart speed selected
	pointsPerChart = 1800;
	// get the chart speed tpp for the relevant speed
	switch (chartSpeed) {
	case SPEED_FAST:
		tpp = CirciTrendSelectableFastSpeeds[pChartInfo->CircFastSpeed];
		break;
	case SPEED_MEDIUM:
		tpp = CirciTrendSelectableMedSpeeds[pChartInfo->CircMedSpeed];
		break;
	case SPEED_SLOW:
	default:
		tpp = CirciTrendSelectableSlowSpeeds[pChartInfo->CircSlowSpeed];
	}
}
//****************************************************************************
///
/// Method used to retrieve the fast chart span for the specified speed index
///
/// @param[in] chartSpeedIndex - the chart speed index
/// @param[out] chartDuration - the duration of the chart given the specified speed and chart info configuration 
///
/// @returns	The chart speed span in seconds
///
//**************************************************************************** 
const int CircularChartUtils::GetFastChartSpeedSpan(const int chartSpeedIndex,
		T_CIRCULAR_CHART_DURATION &chartDuration) {
	int chartSpanInSeconds = 0;
	switch (chartSpeedIndex) {
	case CCFD_15_MINUTES:
		chartSpanInSeconds = 900;
		chartDuration = CCD_15_MINUTES;
		break;
	case CCFD_30_MINUTES:
		chartSpanInSeconds = 1800;
		chartDuration = CCD_30_MINUTES;
		break;
	case CCFD_1_HOUR:
		chartSpanInSeconds = 3600;
		chartDuration = CCD_1_HOUR;
		break;
	case CCFD_4_HOURS:
		chartSpanInSeconds = 14400;
		chartDuration = CCD_4_HOURS;
		break;
	case CCFD_8_HOURS:
	default:
		chartSpanInSeconds = 28800;
		chartDuration = CCD_8_HOURS;
	}
	return chartSpanInSeconds;
}
//****************************************************************************
///
/// Method used to retrieve the med chart span for the specified speed index
///
/// @param[in] chartSpeedIndex - the chart speed index
/// @param[out] chartDuration - the duration of the chart given the specified speed and chart info configuration 
///
/// @returns	The chart speed span in seconds
///
//**************************************************************************** 
const int CircularChartUtils::GetMedChartSpeedSpan(const int chartSpeedIndex,
		T_CIRCULAR_CHART_DURATION &chartDuration) {
	int chartSpanInSeconds = 0;
	switch (chartSpeedIndex) {
	case CCMD_4_HOURS:
		chartSpanInSeconds = 14400;
		chartDuration = CCD_4_HOURS;
		break;
	case CCMD_8_HOURS:
		chartSpanInSeconds = 28800;
		chartDuration = CCD_8_HOURS;
		break;
	case CCMD_12_HOURS:
		chartSpanInSeconds = 43200;
		chartDuration = CCD_12_HOURS;
		break;
	case CCMD_1_DAY:
		chartSpanInSeconds = 86400;
		chartDuration = CCD_1_DAY;
		break;
	case CCMD_2_DAYS:
	default:
		chartSpanInSeconds = 172800;
		chartDuration = CCD_2_DAYS;
	}
	return chartSpanInSeconds;
}
//****************************************************************************
///
/// Method used to retrieve the slow chart span for the specified speed index
///
/// @param[in] chartSpeedIndex - the chart speed index
/// @param[out] chartDuration - the duration of the chart given the specified speed and chart info configuration 
///
/// @returns	The chart speed span in seconds
///
//**************************************************************************** 
const int CircularChartUtils::GetSlowChartSpeedSpan(const int chartSpeedIndex,
		T_CIRCULAR_CHART_DURATION &chartDuration) {
	int chartSpanInSeconds = 0;
	switch (chartSpeedIndex) {
	case CCSD_2_DAYS:
		chartSpanInSeconds = 172800;
		chartDuration = CCD_2_DAYS;
		break;
	case CCSD_5_DAYS:
		chartSpanInSeconds = 432000;
		chartDuration = CCD_5_DAYS;
		break;
	case CCSD_1_WEEK:
		chartSpanInSeconds = 604800;
		chartDuration = CCD_1_WEEK;
		break;
	case CCSD_2_WEEKS:
		chartSpanInSeconds = 1209600;
		chartDuration = CCD_2_WEEKS;
		break;
	case CCSD_4_WEEKS:
	default:
		chartSpanInSeconds = 2419200;
		chartDuration = CCD_4_WEEKS;
	}
	return chartSpanInSeconds;
}
//****************************************************************************
///
/// Method used to determine if the current year is a leap year
///
/// @param[in] year - the year we wish to determine if it is a leap year
///
/// @returns	TRUE if the year is a leap year, false if not
///
//****************************************************************************
const BOOL CircularChartUtils::IsLeapYear(int year) {
	if (year % 400 == 0) {
		return TRUE;
	} else if (year % 100 == 0) {
		return FALSE;
	} else if (year % 4 == 0) {
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
///
/// Method used to calculate the day number
///
/// @param[in] year - the year we are calculating against
/// @param[in] month - the month we are calculating against
/// @param[in] day - the day of the month we are calculating against
///
/// @returns	the day of the year starting from 1st January as 0
///
//****************************************************************************
const int CircularChartUtils::GetDayNumber(const int year, const int month, const int day) {
	int leapYearAdjustment = 0;
	int dayOfYear = 0;
	// determine if a leap year
	if (IsLeapYear(year)) {
		leapYearAdjustment = 1;
	}
	// now get the day of the year
	if (month == 1) {
		dayOfYear = day;
	}
	if (month == 2) {
		dayOfYear = 31 + day;
	}
	if (month == 3) {
		dayOfYear = 59 + day + leapYearAdjustment;
	}
	if (month == 4) {
		dayOfYear = 90 + day + leapYearAdjustment;
	}
	if (month == 5) {
		dayOfYear = 120 + day + leapYearAdjustment;
	}
	if (month == 6) {
		dayOfYear = 151 + day + leapYearAdjustment;
	}
	if (month == 7) {
		dayOfYear = 181 + day + leapYearAdjustment;
	}
	if (month == 8) {
		dayOfYear = 212 + day + leapYearAdjustment;
	}
	if (month == 9) {
		dayOfYear = 243 + day + leapYearAdjustment;
	}
	if (month == 10) {
		dayOfYear = 273 + day + leapYearAdjustment;
	}
	if (month == 11) {
		dayOfYear = 304 + day + leapYearAdjustment;
	}
	if (month == 12) {
		dayOfYear = 334 + day + leapYearAdjustment;
	}
	return dayOfYear;
}
//****************************************************************************
///
/// Method used to calculate the week number
///
/// @param[in] day - the day of the month we are calculating against
/// @param[in] month - the month we are calculating against
/// @param[in] year - the year we are calculating against
///
/// @returns	The week of the year as defined by the ISO 8601 standard
///
//****************************************************************************
const int CircularChartUtils::GetWeekNumber(	// Valid values:
		int year, // 1970 to 3000
		int month, // 1 to 12. 1 = Jan.
		int day  // 1 to 31
		) {
	tm date = { 0 };
	date.tm_mday = day;
	date.tm_mon = month - 1;
	date.tm_year = year - 1900;
	// We set time to sometime during the day (midday seems to make sense)
	// so that we don't get problems with daylight saving time.
	date.tm_hour = 12;
	date.tm_yday = GetDayNumber(year, month, day);
	WCHAR buffer[4];
	wcsftime(buffer, 4, L"%W", &date);  // '%W' = week number of the year, eg 1/1/09 == 1
	// get the week number as an integer
	return _wtoi(buffer);
	//return GetWeekNumber(&date);
}
////****************************************************************************
/////
///// Method used to calculate the week number - DEPRECATED FOR NOW AS mktime is not supported in CE
/////
///// @param[in] date - the date we are calculating against
/////
///// @returns	The week of the year as defined by the ISO 8601 standard
/////
////****************************************************************************
//const int CircularChartUtils::GetWeekNumber( struct tm* date )
//{
//if (NULL == date)
//{
//	return 0; // or -1 or throw exception
//}
//::mktime(date);
//// The basic calculation:
//// {Day of Year (1 to 366) + 10 - Day of Week (Mon = 1 to Sun = 7)} / 7
//int monToSun = (date->tm_wday == 0) ? 7 : date->tm_wday; // Adjust zero indexed week day
//int week = ((date->tm_yday + 11 - monToSun) / 7); // Add 11 because yday is 0 to 365.
//// Now deal with special cases:
//// A) If calculated week is zero, then it is part of the last week of the previous year.
//if (week == 0)
//{
//	// We need to find out if there are 53 weeks in previous year.
//	// Unfortunately to do so we have to call mktime again to get the information we require.
//	// Here we can use a slight cheat - reuse this function!
//	// (This won't end up in a loop, because there's no way week will be zero again with these values).
//	tm lastDay = { 0 };
//	lastDay.tm_mday = 31;
//	lastDay.tm_mon = 11;
//	lastDay.tm_year = date->tm_year - 1;
//	// We set time to sometime during the day (midday seems to make sense)
//	// so that we don't get problems with daylight saving time.
//	lastDay.tm_hour = 12;
//	week = GetWeekNumber(&lastDay);
//}
//// B) If calculated week is 53, then we need to determine if there really are 53 weeks in current year
////  or if this is actually week one of the next year.
//else if (week == 53)
//{
//	// We need to find out if there really are 53 weeks in this year,
//	// There must be 53 weeks in the year if:
//	// a) it ends on Thurs (year also starts on Thurs, or Wed on leap year).
//	// b) it ends on Friday and starts on Thurs (a leap year).
//	// In order not to call mktime again, we can work this out from what we already know!
//	int lastDay = date->tm_wday + 31 - date->tm_mday;
//	if (lastDay == 5) // Last day of the year is Friday
//	{
//		// How many days in the year?
//		int daysInYear = date->tm_yday + 32 - date->tm_mday; // add 32 because yday is 0 to 365
//		if (daysInYear < 366)
//		{
//			// If 365 days in year, then the year started on Friday
//			// so there are only 52 weeks, and this is week one of next year.
//			week = 1;
//		}
//	}
//	else if (lastDay != 4) // Last day is NOT Thursday
//	{
//		// This must be the first week of next year
//		week = 1;
//	}
//	// Otherwise we really have 53 weeks!
//}
//return week;
//	return 0;
//}
//****************************************************************************
///
/// Method used to calculate the time required to normalise the specified day to monday
///
/// @param[in] dayOfWeek - the day of the week we are calculating against
///
/// @returns	The normalisation factor in seconds
///
//****************************************************************************
const int CircularChartUtils::CalculateMondayNormalisationFactor(int dayOfWeek) {
	int mondayNormalisationFactor = 0;
	// weeks always start on monday so we need to calcualte how to get to a Monday
	if (dayOfWeek == 1) {
		// do nothing
	} else if (dayOfWeek == 0) {
		// this is sunday so we need to go back 6 days
		mondayNormalisationFactor += 6 * SECONDS_IN_A_DAY;
	} else {
		// we need to go back to day 1 as we are forward of day 1 currently i.e. Tuesday to Saturday
		mondayNormalisationFactor += (dayOfWeek - 1) * SECONDS_IN_A_DAY;
	}
	return mondayNormalisationFactor;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: Template.h 
/// @n Description: Template class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  13  Stability Project 1.10.1.1 7/2/2011 5:02:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  12  Stability Project 1.10.1.0 7/1/2011 4:25:52 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  11  V6 Firmware 1.10 11/28/2005 4:31:12 PM  Jason Parker  
//  Added a member to keep the templates ref in CMM
//  10  V6 Firmware 1.9 9/5/2005 9:26:46 PM Jason Parker  
//  Added m_pMainConfig so that canned screens can use another config
// $
// 
//
// **************************************************************************
#ifndef _TEMPLATE_H
#define _TEMPLATE_H
class COpPanel;
//**Class*********************************************************************
///
/// @brief Template class
/// 
/// This class is used in conjuction with a CScreen Class instance
///
//****************************************************************************
class CTemplate: public CLayoutItem {
private:
public:
	COpPanel *m_pOpPanel;			///< keep pointer to our parent OpPanel
	T_SCRTEMPLATE *m_pCMMtemplate; ///< pointer to our CMM configuration
	CTemplate *m_pNextTpt;			///< pointer to next template in list
	CLayoutConfiguration *m_pConfig; ///< pointer to config where this template resides
	T_LAYOUTITEM m_KeepRef;
	CTemplate(COpPanel *pParent);	///< constructor	
	~CTemplate();					///< destructor
	virtual QString GetId();
	virtual QRect GetLayoutItemBounds() {
		return QRect(0, 0, 319, 239);
	} // @todo - fix this!
	virtual COpPanel* GetOpPanel() {
		return m_pOpPanel;
	}
	//virtual void InitItemProp();	
	void CMMInitTemplate(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, BOOL IsNew); ///< One time Initialisation.	
	void ConfigChange();					///< To be called when data item info changes (setup or Widget rotation etc)
	BOOL MatchLayoutItem(T_LAYOUTITEM *LayoutItem);
	T_LAYOUTITEM GetLayoutItem();
	USHORT GetNumWidgets();
	BOOL GetWidgetConfig(int index, BLOCK_INFO *blockInfo);
};
#endif

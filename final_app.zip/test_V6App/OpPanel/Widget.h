/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Op Panel
/// @n Filename: Widget.h 
/// @n Description: Widget class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 77	Stability Project 1.74.1.1	7/2/2011 5:02:53 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 76	Stability Project 1.74.1.0	7/1/2011 4:25:52 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 75	V6 Firmware 1.74		9/23/2008 3:09:37 PM	Build Machine 
//		AMS2750 Merge
// 74	V6 Firmware 1.73		1/10/2007 4:21:09 PM	Jason Parker 
//		Added function to set the background colour of a widget and its
//		objects (for use in replay)
// $
// 
//
// **************************************************************************
#ifndef _WIDGET_H
#define _WIDGET_H
// forward references
class CBaseObject;
class CScreen;
#include "Defines.h"
#include "Utilities.h"
#include "LayoutItem.h"
#include "CMMDefines.h"
#include <QAbstractItemModel>
#include <QPoint>
//#include CDataItem"
#include "LayoutConfiguration.h"
//for Aligning items on the Widget
enum {
	Selnone, move, netSelect
};
// New data item table reference
class CDataItemRef // widget object's reference to a data item
{
public:
	CBaseObject *m_pObject; // pointer back to our object
	QAbstractItemModel *m_pDataItem;
	CDataItemRef *nextRef; // pointer to next ref (so a list can be formed)
	USHORT Instance;
	ULONG m_LastUpdate100;
	ULONG m_LastUpdateCount;
	BOOL Updates;
	BOOL Rotate;
	CDataItemRef(CBaseObject *wObject) {
		// default everything
		m_pObject = wObject;
		m_pDataItem = NULL;
		Instance = 0;	// instances are zero based.
		m_LastUpdate100 = -100; // force an update straight away
		m_LastUpdateCount = 0;
		Updates = FALSE;
		Rotate = FALSE;
		nextRef = NULL;
	}
};
// Method that sorts the messages into layout item instance no order
bool SortLowestInstFirst(CBaseObject *pkObj1, CBaseObject *pkObj2);
//**Class*********************************************************************
///
/// @brief Widget container class
/// 
/// This class provides a container class which will maintain a list of Objects.
/// Objects may be added/deleted as required.
///
//****************************************************************************
class CWidget: public CLayoutItem {
private:
	CDataItemRef *m_pReferences;	///< list of CDataItemRef's for objects
	QRect m_permRect;	///< Area of Permanent surface to be copied to Backbuffer
	void SetClientRect();
	void AppendObject(CBaseObject *pObj);
	void CheckDDPointers();
	CBaseObject* CreateDerivedObject(BLOCK_INFO *objDetails, ObjectType &reObjType);
	// Method that sets up the parent instance usually following the addition/pasting of the first 
	// object in the widget
	void InitParentChannel();
	// Method that detemines if all objects using the widget channels are currentl
	// setup as pens of some type
	const bool AllWidgetChannelsArePens();
	// Method that makes all the widget channels pen only
	void MakeWidgetChannelsPenOnly();
public:
	CLayoutConfiguration *m_pConfig; ///< pointer to config where this widget resides
	/// Varaible used to indicatge there are no spare screen index left to give to objects
	static const USHORT ms_usNO_FREE_SCREEN_INDEXES;
	// Method that tidies the widget channel list
	void TidyWidgetChannelList();
	// Method used to determine how many objects are using a particular widget channel index
	const USHORT ObjectsUsingIndex(const USHORT usINDEX);
	// Method that returns true if the widget contains a chart or pen pointers object
	const bool ContainsMultiPenObj();
	// Method that returns true if the widget channel index is compatible with the passed in types
	const bool ChannelIndexTypeCompatible(const USHORT usINDEX, const USHORT usTYPE, const USHORT usSUBTYPE);
	// Method that gets the next free screen index
	static const USHORT GetFreeScreenInstIndex(CScreen *pkScreen, const USHORT usREQ_INSTANCE,
			const bool bUPDATE_INSTANCE = false, const USHORT usSTART_INDEX = 0);
	// Method that deletes the channel references for an object prior to it being
	// deleted from the CMM
	void DeleteSelObjChanRef();
	// Method that deletes the channel references for a widget prior to its own deletion
	void DeleteWidgetChanRef();
	// Method that moves all objects that are using the chart channels - this would usually
	// be called when the chart object channels are modified. The objects would then be relinked,
	// if possible, later
	void MoveAllObjsUsingChartChans();
	// Method that merges any duplicate screen instance references
	void MergeDuplicateChannelInst();
	// Method that get an objects name
	const QString GetObjectName(const T_PBASEOBJECT ptBASE_OBJECT);
	// Method that gets the dynamically created name for an object
	const QString GetObjectName(const T_OBJECT_TYPE eOBJECT_TYPE, const USHORT usOBJ_COUNT) const;
	// Method that returns true if the passed in type is pen type or a pen compatible type
	static const bool IsPenCompatibleType(const USHORT usTYPE);
	// Helper method used to determine if the widget contains any chart objects
	const BOOL IsShowingCircularChart();
	// Helper method used to determine if the screen is currently displaying a realtime or historical circular chart
	const BOOL IsShowingRealtimeCircularChart();
	// Method used to put any circular charts the screen may be displaying into and out of
	// showing realtime and historical data
	void SetCircularChartMode(const bool showRealtime);
	// *************************************************************************
	// * MULTIPLE SELECTION OF OBJECTS HAS BEEN REMOVED FROM THE FIRST RELEASE *
	// * SINCE IT HAS NOT BEEN COMPLETELY INTEGRATED WITH OTHER FUNCTIONALITY, *
	// * SUCH AS CUT/COPY/PASTE, DELETE, MOVE, ETC. SEE WIDGET.H (VERSION 45) *
	// * AND WIDGET.CPP (VERSION 58) WHEN MULTIPLE SELECTION WAS ADDED (DKF). *
	// *************************************************************************
	//int m_SelectMode;
	void AlignItems(int AlignState);
	int m_AlignState;
	QRect m_ReferenceBounds;
	//virtual void InitItemProp();
	BOOL RemoveObject(CBaseObject *pObj);
	QRect *m_WidgetClip;	///< pointer to clipping rectangle for Widget (or NULL)
	HRGN m_UpdateRgn;	///< widget's update Region - everything on updating on backbuffer for widget
	HRGN m_ClipRgn;	///< clipping region for those objects that want to change it
	BOOL m_ClipValid;			///< flag to indicate state of clipping region
	CScreen *m_pScreen;				///< pointer to parent Screen
	T_WIDGET *m_pCMMwidget;			///< pointer to T_WIDGET struct in CMM
	CWidget *m_pNextWgt;		///< Used by parent Screen to form a linked list
	CBaseObject *m_pObjects;		///< maintained in 'Z' order (although actual 'visual' order depends on flags)
	CBaseObject *m_pSelectedObject;
	CBaseObject *m_pLastSelectedObject;
	BOOL m_CheckpointRequired;
	BOOL m_WidgetUpdateRequired;		///< set when Data Items have changed and an update is required
	BOOL m_WidgetShowHandles;		///< set when Widget is selected in designer mode. ('grab handles' displayed)
	ResizeType m_WidgetResizeState;	///< set to indicate which 'grab handle' is being adjusted (if any)
	QPoint m_StartPoint;		///< Starting point of a mouse move operation
	QRect m_OriginalBounds;
	QRect m_WidgetClientRect;		///< Size of client area (bounds less border width)
	BOOL m_PermInUse;		///< flag to indicate at least one object is using the permanent surface
	BOOL m_PermValid;				///< is the permanent surface up to date?
	QPoint m_ptCursorOffset;		///< Mouse down point in object relative to object to handle moving a sticky object
	int m_CurrRotateOffset;
	ULONG m_LastRotateUpdate100;
	//E437415
	//LPDIRECTDRAW4			m_pDD;				// DirectDraw object
	//LPDIRECTDRAWSURFACE4	m_pDDSPrimary;		// DirectDraw priamry surface 
	//LPDIRECTDRAWSURFACE4	m_pDDSBackBuffer;	// DirectDraw back buffer surface
	//LPDIRECTDRAWSURFACE4	m_pDDSPermanent;	// DirectDraw permanent surface 
	//LPDIRECTDRAWSURFACE4	m_pDDSAlpha;		// DirectDraw surface (Alpha)
	LPDIRECTDRAW m_pDD;				// DirectDraw object
	LPDIRECTDRAWSURFACE m_pDDSPrimary;		// DirectDraw priamry surface 
	LPDIRECTDRAWSURFACE m_pDDSBackBuffer;	// DirectDraw back buffer surface
	LPDIRECTDRAWSURFACE m_pDDSPermanent;	// DirectDraw permanent surface 
	LPDIRECTDRAWSURFACE m_pDDSAlpha;		// DirectDraw surface (Alpha)
	LPDIRECTDRAWCLIPPER m_pDDClipper;		// DirectDraw Clipper
	int m_InitCount;		// incremented after each initialisation
	/// Variable used to store the channel offset
	static const USHORT ms_usCHANNEL_OFFSET;
	/// Variable indicating a channel is not in use and therefore spare
	static const USHORT ms_usCHANNEL_SPARE;
	/// Varaible indicating the index of the parent channel within the widget channel list
	static const USHORT ms_usPARENT_INDEX;
	CWidget(CScreen *pParentScreen);	///< constructor	
	~CWidget();							///< destructor
	void Destroy();						///< Clean-up function 
	virtual QString GetId();
	virtual QRect GetLayoutItemBounds() {
		return GetWidgetBoundsActual();
	}
	virtual COpPanel* GetOpPanel();	///< Get the OpPanel associated with the layout item
	void CMMInitWidget(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, QRect *bounds);///< One time Initialisation.	
	void CheckObjectLinks();
	void ConfigChange();	///< To be called when data item info changes (setup or Widget rotation etc)
	void SetWidgetBounds(QRect *bounds);	///< set the bounds of Widget, relative to the CScreen top left corner
	QRect GetWidgetBounds();	///< returns bounds of the Widget relative to the CScreen top left corner
	QRect GetWidgetBoundsActual();	///< returns the bounds of the Widget with no offsets applied
	QRect GetWidgetClientActual();
	int GetWidgetBorder();
	T_LAYOUTITEM GetLayoutItem();
	void ChangeWidgetBackground(COLORREF rgb);
	void InvalidateArea(QRect area, BOOL immediate = TRUE);
	BOOL GetDataItem(CDataItemRef *ref, T_CHANNELREF *pChRef);
	BOOL DeleteDataItem(CDataItemRef *ref);
	CDataItem* GetDataItemPtr(T_CHANNELREF *pChRef);
	BOOL CheckDataItems();
	void AddNewObject(BLOCK_INFO *blockInfo, QRect *bounds);
	BOOL MatchLayoutItem(T_LAYOUTITEM *LayoutItem);
	CBaseObject* indexOfObjectInstance(T_LAYOUTITEM *LayoutItem);
	BOOL IsNearHoriz(int nHoriz, int &nHorizNear);	///< Used for moving/resizing a sticky object
	BOOL IsNearVert(int nVert, int &nVertNear);	///< Used for moving/resizing a sticky object
	BOOL PrepareDraw(QRect *pClipRect);
	void DrawBackgound();
	void StandardDraw(HDC primaryDC, HDC backbufferDC, HDC alphaDC);
	void DrawAdvancedandAlpha();
	void SetClipRect(HDC hdc, QRect *cliprect);
	void RestoreClipping(HDC hdc);
	BOOL HitTestHandles(QPoint &point);		///< Check Handles for mouse contact
	void DrawWidgetHandles(HDC hdc);
	void OnSetFocus() {
		;
	}							///< Just receiving the input focus
	void OnKillFocus() {
		;
	}							///< Just losing the input focus
	void CheckObjectOrder();
	BOOL BringObjectToTop(CBaseObject *pObj, BOOL FlagModified = TRUE);
	BOOL SendObjectToBottom(CBaseObject *pObj);
	BOOL BringObjectForward(CBaseObject *pObj);
	BOOL SendObjectBackward(CBaseObject *pObj);
	void OnChar(wchar_t ch) {
		;
	}						///< User input (keyboard or SIP)
	BOOL OnMouseDown(UINT nFlags, QPoint &point);			///< Mouse button down (or touch screen touched) at point
	void OnMouseUp(UINT nFlags, QPoint &point);	///< Mouse button up (or touchscreen)
	void OnMouseMove(UINT nFlags, QPoint &point);	///< Dragging on screen with mouse or touchscreen
	BOOL OnMouseDownRuntime(UINT nFlags, QPoint &point);	///< Mouse button down (or touch screen touched) at point
	BOOL GetObjectConfig(int index, BLOCK_INFO *blockInfo) const;
	// Method that gets a type and subtype for the selected widget channel number/index e.g. DI_PEN, DI_IO etc
	void GetWidgetChannelType(USHORT &rusChanType, USHORT &rusChanSubType, const USHORT usINDEX) const;
	// Method that gets a pointer to an objects first channel ref and returns how many
	// channels this object has
	T_PCHANNELREF GetObjChanRef(CBaseObject *pkBaseObject, USHORT &rusNumChannels);
	// Method that gets a pointer to an objects first channel ref and returns how many
	// channels this object has
	static T_PCHANNELREF GetObjChanRef(T_BASEOBJECT *ptBaseObject, USHORT &rusNumChannels);
	// Accessor Methods
	CScreen* GetScreen() const {
		return m_pScreen;
	}
	T_WIDGET* GetCMMWidget() const {
		return m_pCMMwidget;
	}
	const bool ObjectListFull() {
		return (m_pCMMwidget->NumChannels == WIDGET_CHANNELLIST_SIZE);
	}
	// flags are as for MFC (see CWidget::OnMouseMove)
	/*
	 nFlags 
	 Indicates whether various virtual keys are down. This parameter can be any combination of the following values: 
	 
	 MK_CONTROL Set if the CTRL key is down. 
	 MK_LBUTTON Set if the left mouse button is down. 
	 MK_MBUTTON Set if the middle mouse button is down. 
	 MK_RBUTTON Set if the right mouse button is down. 
	 MK_SHIFT	Set if the SHIFT key is down. 
	 */
// Overridables
public:
};
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: Screen.cpp 
/// @n Description: Screen class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  176  Stability Project 1.169.2.5  8/10/2011 12:08:38 PM  Hemant(HAIL) 
// Fixed PAR # 1-L44JCV (Issue: 32 Pens in a Group)
//  175  Stability Project 1.169.2.4  7/2/2011 5:01:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  174  Stability Project 1.169.2.3  7/1/2011 4:38:51 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  173  Stability Project 1.169.2.2  6/17/2011 8:02:54 PM  Hemant(HAIL) 
// Files updated for "Restrict pen addition limit to 32 in a group".
//  (The issue was observed in internal testing and if more than 32 pens
//  are added to a group and if that group is added to the new screen
//  then the recorder gets hanged. Even the limit of canned screens to
//  display max pens on a screen is 32)
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "AMS2750TUSMgr.h"
#ifndef DOCVIEW
#ifndef V6IOTEST
#include "TopStatusBar.h"
#include "PenManager.h"
#include "BoardManager.h"
#include "BrdInfo.h"
#endif
#else
#include "PenManagerstub.h"
#endif
#ifndef V6IOTEST
#include "CannedScrnData.h"
#endif
#include "UISizeDefines.h"
#ifdef SHOW_CPU
	#include "cpumon.h"
#endif
#ifndef UNDER_CE
// for sndPlaySound on the desktop build
#include "Mmsystem.h"
#pragma comment( lib, "Winmm" )
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define DEF_SCR_BACK_COLOUR 28095///<blue, this value is matched to CMM db
extern BOOL Glb_SeeRegions;
extern BYTE Glb_col;
extern ChartSpeed Glb_ReplaySpeed;
extern int Glb_FontHeight;
extern CSimpleLog logstuff;
#define PCUROBJ m_pSelectedWidget->m_pSelectedObject 
const USHORT CScreen::ms_usUNINITIALISED_INSTANCE = 0xFFFF;
const USHORT CScreen::ms_usINVALID_CHANNEL_NO = 0x00FE;
const USHORT CScreen::ms_usMAX_MULTI_SCREENS = 32;
const USHORT CScreen::ms_usMAX_MINI_SCREENS = 20;
const USHORT CScreen::ms_usMAX_EZ_SCREENS = 12;
//const USHORT CScreen::ms_usMAX_NON_PROCESS_SCREENS	= 32;
const USHORT CScreen::ms_usMAX_XS_MULTI_SCREENS = 20;
const USHORT CScreen::ms_usMAX_XS_MINI_SCREENS = 12;
//****************************************************************************
/// CScreen Constructor
///
/// @param[in] pParent		- Pointer to Parent OpPanel 
/// 
//****************************************************************************
CScreen::CScreen(COpPanel *pParent) : CLayoutItem(otScreen) {
	// set up empty block info structure;
	BLOCK_INFO emptyInfo = { 0, 0, 0, NULL, 0 };
	m_CMMinfo = emptyInfo;
	// keep pointer to our parent OpPanel
	m_pOpPanel = pParent;
	m_pCMMscreen = NULL;
	m_pRealCMMscreen = NULL;
	m_pNextScr = NULL;
	m_pWidgets = NULL;
	m_pTemplate = NULL;
	m_pSelectedWidget = NULL;
	m_pLastSelectedWidget = NULL;
	m_DoneInitalDraw = FALSE;
	m_CheckpointRequired = FALSE;
	m_CannedScreenChanged = FALSE;
	m_ScreenIsMoved = FALSE;
	SetRect(&m_ScreenClientRect, 0, 0, m_pOpPanel->m_ScreenWidth, m_pOpPanel->m_ScreenHeight);
	m_hrgnUpdate = NULL; // DO NOT create a region here
}
//****************************************************************************
/// CScreen Destructor
/// Clean up as Screen is deleted (Destroy function does most of the work)
/// 
/// @todo put whatever we need to do in here !!
//****************************************************************************
CScreen::~CScreen() {
}
//****************************************************************************
/// 
/// Clean up CScreen and everything under it
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CScreen::Destroy() {
	// delete all CWidgets
	while (m_pWidgets) {
		CWidget *pWgt = m_pWidgets;
		RemoveWidget(pWgt); // remove from list
		pWgt->Destroy();	// will remove everything below each CWidget (derived Objects)
		delete pWgt;		// then delete the CWidget object.
	}
	// do not delete CTemplate associated with the CScreen. That will be done by OpPanel.
	// EXCEPT for Canned Screens and Replay screen 
	// ...when we DO delete it since it is not in the general list of templates
	// here we check for canned screen by looking at the template inst.
	// We can't check the screen type field (IsCannedScreen) since it wont be validated if the type of screen has changed
	//if(	m_pTemplate && ( m_pTemplate->GetLayoutItem().CMM_Inst >= CANNED_SCREENS_INST ) )
	if (m_pTemplate) {
		if (m_pOpPanel->m_pCannedConfig
				&& m_pTemplate->m_pConfig->GetConfigId() == m_pOpPanel->m_pCannedConfig->GetConfigId()) // it's the same as the canned screen config
						{
			// here, if a change has been made to the settings for the screen, we need to 
			// create a new template in the CMM, so delete the existing one here.
			if (m_CannedScreenChanged) {
				//m_pOpPanel->m_pCannedConfig->DeleteTemplate(&m_pTemplate->m_KeepRef); // delete template in canned screen CMM
				BLOCK_INFO templateBlockInfo;
				if (m_pOpPanel->m_pCannedConfig->indexOfDataBlock(&m_pTemplate->m_KeepRef, &templateBlockInfo)) {
					((T_SCRTEMPLATE*) templateBlockInfo.pByBlock)->Number = 0; // mark this template to be reused
				}
				m_CannedScreenChanged = FALSE;
			}
			delete m_pTemplate; // delete the c++ template
			m_pTemplate = NULL;
		} else if (m_pOpPanel->m_pReplayScrConfig
				&& m_pTemplate->m_pConfig->GetConfigId() == m_pOpPanel->m_pReplayScrConfig->GetConfigId()) // it's the same as replay config ?
						{
			delete m_pTemplate; // delete the c++ template
			m_pTemplate = NULL;
		}
	}
}
//****************************************************************************
///
/// Initialises the Screen with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Screen
/// Or will be a new defaulted block for a new Screen. 
///
/// @param[in] pConfig	- Configuration to add use
/// @param[in] CMMinfo	- block of CMM info
/// @param[in] IsNew	- flag to indicate this is a new or existing screen
///
/// @return none
/// 
//****************************************************************************
void CScreen::CMMInitScreen(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, BOOL IsNew) {
	// keep a copy of the CMM info block passed in.
	m_CMMinfo = *CMMinfo;
	// set up pointer to T_SCREEN data in CMM info block.
	m_pCMMscreen = (T_SCREEN*) m_CMMinfo.pByBlock;
	m_pRealCMMscreen = m_pCMMscreen; // keep a copy of this (really is the pointer to screen struct in CMM)
	if (IsNew) {
		///only do this for a new screen.
		// initialise the Screen's channel map to all 0xfff
		// These entries are for channels CWidget::ms_usCHANNEL_OFFSET to CWidget::ms_usCHANNEL_OFFSET + 127
		for (int i = 0; i < SCREEN_CHANNELMAP_SIZE; i++) {
			m_pCMMscreen->ChannelMap[i] = CScreen::ms_usUNINITIALISED_INSTANCE; // default value
		}
		m_pCMMscreen->NPItems = 0; // Non process screens use this variable to store number items like pen, user vars, counter to be shown on screen
		// Each entry in the map is the item instance in the Data Item Table.
		m_pCMMscreen->Enabled = TRUE; // enable a new screen
	} else {
		// when loading a previous configuration:
	}
	// in all cases:
	// here check to see if we are using groups for this screen or it is a TUS screen
	if (IsCannedScreen() && (m_pRealCMMscreen->UseGroups || (m_pRealCMMscreen->Type == TPL_AMS2750_TUS_SCREEN))) {
		REFERENCE curmode = m_pOpPanel->m_pMainConfig->GetCMMmode();
		// yes we are, so get/create memory based screen config to use (can then be changed without CMM commit)
		T_SCREEN *pMemoryScreen = CMemoryScreenBlock::GetHandle()->GetMemoryScreenBlock(m_CMMinfo.wInstanceID, curmode);
		if (m_pOpPanel->m_IsCommit) {
			// just committed layout (layout changes) - need to copy the modifiable config to the committed
			T_SCREEN *pMemModifiable = CMemoryScreenBlock::GetHandle()->GetMemoryScreenBlock(m_CMMinfo.wInstanceID,
					CONFIG_MODIFIABLE);
			*pMemoryScreen = *pMemModifiable;
		} else {
			// general operation - when there is a layout rebuild copy the first part of the CMM T_SCREEN (the settings)
			if (m_pOpPanel->m_IsSetupConfigChange == FALSE) // Doing a layout config update, could be committed or modifiable					 
			{
				memcpy(pMemoryScreen, m_pRealCMMscreen,
						((UCHAR*) m_pRealCMMscreen->ChannelMap - (UCHAR*) m_pRealCMMscreen)); // copy the CMM version - there could well be changes we need					
			}
		}
		m_pCMMscreen = pMemoryScreen; // and assign pointer here
	}
	m_DoneInitalDraw = FALSE;
	// Since templates will be loaded up before Screens 
	// we can make the link to our CTemplate
	if (m_pCMMscreen->Type == TPL_REPLAY) {
		PopulateReplayScreen();
	} else if (m_pCMMscreen->Type == TPL_HOTSOAK) {
#ifndef DOCVIEW
#ifndef V6IOTEST
		PopulateHotSoakScreen();
#endif
#endif
	} else if (IsCannedScreen()) {
		// the canned screen templates are added to the cannedscreen config (not the main layout config).
		// there is always a 1:1 mapping between canned screen and it's template.
		// we ensure the template and screen have the same instance number. (+ CANNED_SCREENS_INST)
		T_LAYOUTITEM ref = GetLayoutItem(); // get our layout item ref.
		ref.CMM_Type = BLK_SCRTEMPLATE;
		ref.CMM_Inst += CANNED_SCREENS_INST; // add CANNED_SCREENS_INST to allow for searching for our template
		BLOCK_INFO templateBlockInfo;
		if (m_pOpPanel->m_pCannedConfig->indexOfDataBlock(&ref, &templateBlockInfo)
				&& ((T_SCRTEMPLATE*) templateBlockInfo.pByBlock)->Number) // check template Number not zero
				{
			// found ok.
			m_pTemplate = new CTemplate(m_pOpPanel);
			m_pTemplate->CMMInitTemplate(m_pOpPanel->m_pCannedConfig, &templateBlockInfo, LOADED_INSTANCE);
			// use what it contains...
			int numWidgets = m_pTemplate->GetNumWidgets();
			for (int i = 0; i < numWidgets; i++) {
				BLOCK_INFO blockInfo;
				if (m_pTemplate->GetWidgetConfig(i, &blockInfo)) {
					// found widget and populated blockinfo OK. (contains pointer into CMM for Widget)
					// now create a corresponding C++ Widget for it.
					// Dont forget we are using the m_pCannedConfig
					CWidget *pWidget = new CWidget(this);
					pWidget->CMMInitWidget(m_pOpPanel->m_pCannedConfig, &blockInfo, NULL); // NULL passed for bounds since already configured
					AppendWidget(pWidget);
				}
			}
		} else {
			// need to add new.. pass the screens instance, so that we get a template that has the same.
			if (m_pOpPanel->m_pCannedConfig->AddTemplate(&templateBlockInfo, ref.CMM_Inst) == CONFIG_OK) {
				// added ok, and populated templateBlockInfo with new Template's CMM details
				// now create a C++ Template Object for it.
				m_pTemplate = new CTemplate(m_pOpPanel);
				m_pTemplate->CMMInitTemplate(m_pOpPanel->m_pCannedConfig, &templateBlockInfo, NEW_INSTANCE);
				qDebug("POPULATING CANNED SCREEN %d %s\n", m_pCMMscreen->Number, m_pCMMscreen->Name);
				PopulateCannedScreen();
				// when using groups, the T_SCREEN struct (usually in the main setup) is in memory - same goes for the TUS screen
				if (!m_pRealCMMscreen->UseGroups && (m_pRealCMMscreen->Type != TPL_AMS2750_TUS_SCREEN))
					if (m_pOpPanel->m_pMainConfig->GetCMMmode() == CONFIG_COMMITTED)
						qDebug("======================= MODIFYING a COMITTED CONFIG (this is bad)\n");
				if (m_pOpPanel->m_pCannedConfig->GetCMMmode() == CONFIG_COMMITTED)
					qDebug("======================= MODIFYING a COMITTED CONFIG (this is bad too)\n");
			} else
				qDebug("Error adding template\n");
		}
	} else // for Custom (screen designed) screen:
	{	// modified by rahul to handle non process screens
		if (m_pCMMscreen->Type != TPL_CUSTOM && m_pCMMscreen->Type < TPL_ALARM) {
			// here a user has changed the type. need use the value to find the template instance
			int templno = m_pCMMscreen->Type - TPL_LAST_CANNED;
			// now find the templno'th template 
			CTemplate *ptpl = m_pOpPanel->m_pTemplates;
			int count = 0;
			while ((count < templno) && ptpl)
				ptpl = ptpl->m_pNextTpt;
			//	NB: for this to work CMM needs to be modifiable here
			if (ptpl)
				m_pCMMscreen->Template = ptpl->GetLayoutItem(); // set the type and instance here.
			m_pCMMscreen->Type = TPL_CUSTOM; // update the type here  
			if (pConfig->GetCMMmode() == CONFIG_COMMITTED)
				qDebug("MODIFYING a COMITTED CONFIG\n");
		}
		if (!m_pTemplate) // not already set (can happen for template viewing screen)
			m_pTemplate = m_pOpPanel->indexOfTemplateInstance(&m_pCMMscreen->Template);
		if (m_pTemplate) {
			// Now for our screen we need to create the Widgets and Objects in our associated Template
			// Widgets and Objects are associated with a Template in CMM.
			// However, the C++ versions are to be linked to our CScreen.
			// (Screen could be 'new' but Template could already exist)
			int numWidgets = m_pTemplate->GetNumWidgets();
			for (int i = 0; i < numWidgets; i++) {
				BLOCK_INFO blockInfo;
				if (m_pTemplate->GetWidgetConfig(i, &blockInfo)) {
					// found widget and populated blockinfo OK. (contains pointer into CMM for Widget)
					// now create a corresponding C++ Widget for it.
					CWidget *pWidget = new CWidget(this);
					pWidget->CMMInitWidget(pConfig, &blockInfo, NULL); // NULL passed for bounds since already configured
					AppendWidget(pWidget);
				}
			}
		}
	}
	if (IsCannedScreen() && m_pCMMscreen->UseGroups) {
		// if using groups and the Main config is writable, copy back to the CMM from our memory version.
		// this ensures that we will commit the updated T_SCREEN struct and then if future changes are required
		// but then discarded or parked, we have a correct committed screen to revert back to.
		if (m_pOpPanel->m_pMainConfig->GetCMMmode() == CONFIG_MODIFIABLE) // if writeable update the CMM to match memory version
				{
			//qDebug("UPDATING THE REAL CONFIG inst %d indexes %d %d %d %d\n",m_CMMinfo.wInstanceID,m_pCMMscreen->CannedPens[0].PenIndex,m_pCMMscreen->CannedPens[1].PenIndex,m_pCMMscreen->CannedPens[2].PenIndex,m_pCMMscreen->CannedPens[3].PenIndex);
			*m_pRealCMMscreen = *m_pCMMscreen; // ensure that we update the actual CMM screen if we can
		}
		// when a setup config change has occurred, we will have updated the 'committed' memory version.
		// need now to copy that to the 'working' memory version so it will be up to date for when the working version is required
		if (m_pOpPanel->m_IsSetupConfigChange) {
			T_SCREEN *pMemModifiable = CMemoryScreenBlock::GetHandle()->GetMemoryScreenBlock(m_CMMinfo.wInstanceID,
					CONFIG_MODIFIABLE);
			*pMemModifiable = *m_pCMMscreen; // copy the new latest version.
		}
	}
}
#ifndef DOCVIEW
#ifndef V6IOTEST
//****************************************************************************
/// Rescale a rectangle for use on multitrend (by given factor)
///
/// @return none
/// 
//****************************************************************************
void ScaleRect(QRect *pRect, float factor) {
	float hfac = factor;
	float wfac = factor;
	if (factor > 1.0)
		wfac = factor + (float) 0.2; // here we increase by a larger factor in horizontal direction
	// this is so that buttons don't look crap.
	pRect->left = (long) ((pRect->left * wfac) + 0.5);
	pRect->right = (long) ((pRect->right * wfac) + 0.5);
	pRect->top = (long) ((pRect->top * hfac) + 0.5);
	pRect->bottom = (long) ((pRect->bottom * hfac) + 0.5);
}
//****************************************************************************
/// Populate the Hot Soak Screen
///
/// @return none
/// 
//****************************************************************************
void CScreen::PopulateHotSoakScreen() {
	QRect ScreenArea;
	float multifactor = 1.0;
	WCHAR buff[100];
	if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS) {
		SetRect(&ScreenArea, 0, MULTI_STATUS_BAR_HEIGHT, ARISTOS_MULTI_SX_X, ARISTOS_MULTI_SX_Y);
		//SetRect(&ScreenArea,0,MULTI_STATUS_BAR_HEIGHT,800,600);
		multifactor = 1.5;
	}
	if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS) {
		SetRect(&ScreenArea, 0, MINI_STATUS_BAR_HEIGHT, X_SERIES_MULTI_SX_X, X_SERIES_MULTI_SX_Y);
		//SetRect(&ScreenArea,0,MULTI_STATUS_BAR_HEIGHT,800,600);
		multifactor = 1.5;
	} else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND) {
		SetRect(&ScreenArea, 0, MINI_STATUS_BAR_HEIGHT, ARISTOS_MINI_QX_X, ARISTOS_MINI_QX_Y);
		//SetRect(&ScreenArea,0,MINI_STATUS_BAR_HEIGHT,320,240);	
	} else
		SetRect(&ScreenArea, 0, MINI_EZ_STATUS_BAR_HEIGHT, ARISTOS_MINI_EZ_X, ARISTOS_MINI_EZ_Y);
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pHotSoakScrConfig, &ScreenArea)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 0;
		m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
		// now add the Object's 
		// first of all- message to be displayed over the top
		QRect MsgRect;
		if (multifactor > 1.0)
			SetRect(&MsgRect, 0, MULTI_STATUS_BAR_HEIGHT, ARISTOS_MULTI_SX_X, ARISTOS_MULTI_SX_Y); // multi
		//SetRect(&MsgRect,0,MULTI_STATUS_BAR_HEIGHT,800,600); // multi
		else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
			SetRect(&MsgRect, 0, MINI_STATUS_BAR_HEIGHT, ARISTOS_MINI_QX_X, ARISTOS_MINI_QX_Y);
		else
			SetRect(&MsgRect, 0, MINI_EZ_STATUS_BAR_HEIGHT, ARISTOS_MINI_EZ_X, ARISTOS_MINI_EZ_Y);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &MsgRect)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = QString(255, 255, 255); // white
			PCUROBJ->m_pCMMbase->FixBackColour = TRUE;
			PCUROBJ->m_pCMMbase->BackColour = QString(255, 255, 255); // white
			PCUROBJ->m_pCMMbase->IsBuffered = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Center = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Wordwrap = TRUE;
			if (multifactor > 1.0)
				//((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Height=100;
				((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Height = 150;
			else
				((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Height = 60;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((CTextObject*) PCUROBJ)->SetBounds(&MsgRect); // call this since our rect is in screen co-ords, not relative to widget (as AddNewObject expects)
			((CTextObject*) PCUROBJ)->SetTextString(L"Reconfiguring Please Wait");
			m_pOpPanel->m_HotSoakObjects[HS_MsgBox][HS_Message] = PCUROBJ;
		}
		QRect TitleRect;
		if (multifactor > 1.0)
			SetRect(&TitleRect, 0, MULTI_STATUS_BAR_HEIGHT, ARISTOS_MULTI_SX_X, ARISTOS_MULTI_SX_Y); // mplus
		//SetRect(&TitleRect,0,MULTI_STATUS_BAR_HEIGHT,800,68); // mplus
		else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
			SetRect(&TitleRect, 0, MINI_STATUS_BAR_HEIGHT, ARISTOS_MINI_QX_X, ARISTOS_MINI_QX_Y);
		else
			SetRect(&TitleRect, 0, MINI_EZ_STATUS_BAR_HEIGHT, ARISTOS_MINI_EZ_X, ARISTOS_MINI_EZ_Y);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &TitleRect)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0;			// black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1;			//anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Center = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((CTextObject*) PCUROBJ)->SetBounds(&TitleRect); // call this since our rect is in screen co-ords, not relative to widget (as AddNewObject expects)
			((CTextObject*) PCUROBJ)->SetTextString(L"Factory Hot Soak");
		}
		// Get the Production Information.
		T_RECPROD sProdInfo = pSYSTEM_INFO->GetProductionInfo();
		QRect ModelRectTitle;
		SetRect(&ModelRectTitle, 1, 46, 58, 59);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &ModelRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black				
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&ModelRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&ModelRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"Model No:");
		}
		QRect ModelRectValue;
		SetRect(&ModelRectValue, 60, 45, 320, 60);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &ModelRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&ModelRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&ModelRectValue);
			((CTextObject*) PCUROBJ)->SetTextString(sProdInfo.ModelNoDisplay);
			/*			
			 checking field sizes
			 if(multifactor>1.0)
			 ((CTextObject*)PCUROBJ)->SetTextString(L"TVMUSX-08P000-021-11-0-030-000000-000"); // multi
			 else
			 ((CTextObject*)PCUROBJ)->SetTextString(L"TVMIQX-88-4WW-31-0-030-000000-000"); // EZ
			 
			 */
		}
		QRect MFRSerialRectTitle;
		SetRect(&MFRSerialRectTitle, 1, 62, 73, 75);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &MFRSerialRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&MFRSerialRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&MFRSerialRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"MFR Serial No:");
		}
		QRect MFRSerialRectValue;
		SetRect(&MFRSerialRectValue, 75, 61, 190, 76);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &MFRSerialRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&MFRSerialRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&MFRSerialRectValue);
			// MANUFACTURING serial number e.g. Y669501800001 not the 6 digit serial number.
			((CTextObject*) PCUROBJ)->SetTextString(sProdInfo.mfrsSerialNo);
			//((CTextObject*)PCUROBJ)->SetTextString(L"Y669501800001");	
		}
		QRect OEMSerialRectTitle;
		SetRect(&OEMSerialRectTitle, 1, 78, 73, 91);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &OEMSerialRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&OEMSerialRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&OEMSerialRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"OEM Serial No:");
		}
		QRect OEMSerialRectValue;
		SetRect(&OEMSerialRectValue, 75, 77, 135, 92);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &OEMSerialRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&OEMSerialRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&OEMSerialRectValue);
			// OEM serial number i.e. 123456
			ULONG serial = pSYSTEM_INFO->GetSerialNumber();
			swprintf(buff, L"%06d", serial);
			((CTextObject*) PCUROBJ)->SetTextString(buff);
		}
		QRect FWRectTitle;
		SetRect(&FWRectTitle, 1, 94, 73, 107);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &FWRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&FWRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&FWRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"Firmware:");
		}
		QString strReleaseType = L"Unknown";
		T_RELEASE_TYPE relType = static_cast<T_RELEASE_TYPE>(pDEVICE_INFO->GetFirmwareRelease());
		switch (relType) {
		case RELEASE_ALPHA:				// Alpha release, internal engineering release.
			strReleaseType = tr("Alpha");
			break;
		case RELEASE_BETA:				// Beta release, release to send out for testing/demonstrations etc..
			strReleaseType = tr("Beta");
			break;
		case RELEASE_PRODUCTION:// Production/customer ready release. Promoted beta when satifactory for release to production
			strReleaseType = tr("Release");
			break;
		default:
			strReleaseType = tr("Unknown");
			break;
		}
		swprintf(buff, L"%s %s", pDEVICE_INFO->GetFirmwareVersion(), strReleaseType);
		QRect FWRectValue;
		SetRect(&FWRectValue, 75, 93, 190, 108);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &FWRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0;		// black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&FWRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&FWRectValue);
			((CTextObject*) PCUROBJ)->SetTextString(buff);
		}
		// get the format type of the card e.g. TFAT16, FAT32 etc
		WCHAR wcaInternalCFRawName[ MAX_PATH];
		memset(wcaInternalCFRawName, 0, MAX_PATH);
		int iPathLen = MAX_PATH;
		pDALGLB->GetPath((T_STORAGE_PATH) IDS_INTERNAL_CF, wcaInternalCFRawName, MAX_PATH, &iPathLen);
		wcsncat(wcaInternalCFRawName, MAX_PATH, L"VOL:", MAX_PATH - wcslen(wcaInternalCFRawName));
		BOOL IsTFAT = FALSE;
		switch (MediaUtils::Mediaasprintf(wcaInternalCFRawName)) {
		case FORMAT_TFAT_16:
		case FORMAT_TFAT_32:
			IsTFAT = TRUE;
			break;
		case FORMAT_FAT_16:
		case FORMAT_FAT_32:
		case FORMAT_UNKNOWN:
		default:
			break;
		}
		QRect tfatRectTitle;
		SetRect(&tfatRectTitle, 1, 110, 73, 123);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &tfatRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&tfatRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&tfatRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"TFAT:");
		}
		QRect tfatRectValue;
		SetRect(&tfatRectValue, 75, 109, 135, 124);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &tfatRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&tfatRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&tfatRectValue);
			if (IsTFAT)
				((CTextObject*) PCUROBJ)->SetTextString(L"Yes");
			else
				((CTextObject*) PCUROBJ)->SetTextString(L"NO");
		}
		CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
		CSlotMap *pSlotMap = CSlotMap::GetHandle();
		QString strText = "";
		WCHAR slotNoStr[4];
		int pos = 0;
		int GAP = 20;
		for (int slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
			if ( DEVICE_INFO.GetSlotType(slotNo) != BOARD_IMPOSSIBLE) {
				switch (pBrdInfo->WhatBoardType(slotNo)) {
				case BOARD_AI:
				case BOARD_EZ_AI:
					strText = L"AI";
					break;
				case BOARD_AO:
					strText = L"AO";
					break;
				case BOARD_DIO:
					strText = L"IO";
					break;
				case BOARD_AR:
					strText = L"AR";
					break;
				case BOARD_PI:
					strText = L"PI";
					break;
				case BOARD_NOT_FITTED:
					strText = "";
					break;
				default:
					strText = L"??";
					break;
				};
				QRect RectTitle;
				SetRect(&RectTitle, 1, 130 + pos, 66, 143 + pos);
				if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &RectTitle)) {
					PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
					PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
					PCUROBJ->m_pCMMbase->IsBuffered = 1;
					((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
					((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
					ScaleRect(&RectTitle, multifactor);
					((CTextObject*) PCUROBJ)->SetBounds(&RectTitle);
					pSlotMap->GetSlotStrID(slotNo, slotNoStr);
					if (pBrdInfo->WhatBoardType(slotNo) != BOARD_NOT_FITTED)
						swprintf(buff, L"Slot %s - %d%s", slotNoStr, pBrdInfo->GetNoOfChannels(slotNo), strText);
					else
						swprintf(buff, L"Slot %s - ", slotNoStr);
					((CTextObject*) PCUROBJ)->SetTextString(buff);
				}
				QRect RectValue;
				SetRect(&RectValue, 69, 130 + pos, 141, 143 + pos);
				if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &RectValue)) {
					PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
					PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
					PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
					((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
					((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
					((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Center = TRUE;
					ScaleRect(&RectValue, multifactor);
					((CTextObject*) PCUROBJ)->SetBounds(&RectValue);
					if (pBrdInfo->WhatBoardType(slotNo) != BOARD_NOT_FITTED) {
						if (pBrdInfo->WhatBoardType(slotNo) == BOARD_AO)
							((CTextObject*) PCUROBJ)->SetTextString(L"Check LED's");
						else
							((CTextObject*) PCUROBJ)->SetTextString(L"Unknown");
						m_pOpPanel->m_HotSoakboardsFitted[slotNo] = TRUE;
					} else
						((CTextObject*) PCUROBJ)->SetTextString(L"Not Fitted");
					m_pOpPanel->m_HotSoakObjects[slotNo][HS_Message] = PCUROBJ;
				}
#ifdef UNDER_CE
				if((pBrdInfo->WhatBoardType( slotNo ) != BOARD_NOT_FITTED )&& // no LED if not fitted
				 (pBrdInfo->WhatBoardType( slotNo )!=BOARD_AO)) // no LED for AO board
#endif
				{
					QRect RectLED;
					SetRect(&RectLED, 143, 130 + pos, 156, 143 + pos);
					if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &RectLED)) {
						PCUROBJ->m_pCMMbase->FixBackColour = TRUE;
						PCUROBJ->m_pCMMbase->BackColour = QString(0, 0, 0); // black
						PCUROBJ->m_pCMMbase->Border.BorderUsed = TRUE;
						PCUROBJ->m_pCMMbase->Border.BorderWidth = (USHORT) (3 * multifactor);
						PCUROBJ->m_pCMMbase->IsBuffered = TRUE;
						((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
						ScaleRect(&RectLED, multifactor);
						((CTextObject*) PCUROBJ)->SetBounds(&RectLED);
						((CTextObject*) PCUROBJ)->SetTextString("");
						m_pOpPanel->m_HotSoakObjects[slotNo][HS_LED] = PCUROBJ;
					}
				}
				pos += GAP;
			}
		}
		// CF Card or USB1 for EZ trend
		QRect CfRectTitle;
		SetRect(&CfRectTitle, 1, 130 + pos, 66, 143 + pos);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &CfRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&CfRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&CfRectTitle);
			if (m_pOpPanel->m_pMainConfig->GetRecorderType() != DEV_EZTREND)
				((CTextObject*) PCUROBJ)->SetTextString(L"CF Card");
			else
				((CTextObject*) PCUROBJ)->SetTextString(L"USB 1");
		}
		QRect CfRectValue;
		SetRect(&CfRectValue, 69, 130 + pos, 141, 143 + pos);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &CfRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Center = TRUE;
			ScaleRect(&CfRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&CfRectValue);
			((CTextObject*) PCUROBJ)->SetTextString(L"Good");
			m_pOpPanel->m_HotSoakObjects[HS_CFCard][HS_Message] = PCUROBJ;
		}
		QRect CfRectLED;
		SetRect(&CfRectLED, 143, 130 + pos, 156, 143 + pos);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &CfRectLED)) {
			PCUROBJ->m_pCMMbase->FixBackColour = TRUE;
			PCUROBJ->m_pCMMbase->BackColour = QString(0, 255, 0); // green
			PCUROBJ->m_pCMMbase->Border.BorderUsed = TRUE;
			PCUROBJ->m_pCMMbase->Border.BorderWidth = (USHORT) (3 * multifactor);
			PCUROBJ->m_pCMMbase->IsBuffered = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&CfRectLED, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&CfRectLED);
			((CTextObject*) PCUROBJ)->SetTextString("");
			m_pOpPanel->m_HotSoakObjects[HS_CFCard][HS_LED] = PCUROBJ;
		}
		// 'Running'
		QRect RunningRectValue;
		SetRect(&RunningRectValue, 211, 84, 294, 105);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &RunningRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			//PCUROBJ->m_pCMMbase->ForeColour=0;// black	
			PCUROBJ->m_pCMMbase->ForeColour = QString(0, 0, 255); // blue
			PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Center = TRUE;
			ScaleRect(&RunningRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&RunningRectValue);
			((CTextObject*) PCUROBJ)->SetTextString("");
			m_pOpPanel->m_HotSoakObjects[HS_Running][HS_Message] = PCUROBJ;
		}
		// 'Test'
		QRect TestRectTitle;
		SetRect(&TestRectTitle, 183, 146, 218, 159);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &TestRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&TestRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&TestRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"Test:");
		}
		QRect TestRectValue;
		SetRect(&TestRectValue, 232, 146, 299, 160);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &TestRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&TestRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&TestRectValue);
			swprintf(buff, L"%dHr Soak", m_pOpPanel->m_pHotSoakData->RunTime.GetSeconds() / 3600); //convert span to to hours.
			((CTextObject*) PCUROBJ)->SetTextString(buff);
			m_pOpPanel->m_HotSoakObjects[HS_Test][HS_Message] = PCUROBJ;
		}
		// 'Elapsed'
		QRect ElapsedRectTitle;
		SetRect(&ElapsedRectTitle, 183, 164, 229, 177);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &ElapsedRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&ElapsedRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&ElapsedRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"Elapsed:");
		}
		QRect ElapsedRectValue;
		SetRect(&ElapsedRectValue, 232, 164, 320, 178);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &ElapsedRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Weight = 2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&ElapsedRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&ElapsedRectValue);
			((CTextObject*) PCUROBJ)->SetTextString("");
			m_pOpPanel->m_HotSoakObjects[HS_Elapsed][HS_Message] = PCUROBJ;
		}
		// 'CJC'
		QRect CjcRectTitle;
		SetRect(&CjcRectTitle, 183, 190, 233, 203);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &CjcRectTitle)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			ScaleRect(&CjcRectTitle, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&CjcRectTitle);
			((CTextObject*) PCUROBJ)->SetTextString(L"CJC (©F):");
		}
		//Max
		QRect CjcRectValue;
		SetRect(&CjcRectValue, 239, 184, 301, 197);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &CjcRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			//	((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Weight=2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&CjcRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&CjcRectValue);
			((CTextObject*) PCUROBJ)->SetTextString(L"Max ----");
			m_pOpPanel->m_HotSoakObjects[HS_CJCMax][HS_Message] = PCUROBJ;
		}
		//Min
		SetRect(&CjcRectValue, 239, 198, 301, 211);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &CjcRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0; // black	
			PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			//	((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Weight=2; // semi-bold
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			ScaleRect(&CjcRectValue, multifactor);
			((CTextObject*) PCUROBJ)->SetBounds(&CjcRectValue);
			((CTextObject*) PCUROBJ)->SetTextString(L"Min ----");
			m_pOpPanel->m_HotSoakObjects[HS_CJCMin][HS_Message] = PCUROBJ;
		}
		// PASS/FAIL
		QRect PastFailedRectValue;
		if (multifactor > 1.0) // Rahul need to check the rect size for ARISTOS screen size....
			//SetRect(&PastFailedRectValue,0,500,544,600);	// multi
			SetRect(&PastFailedRectValue, 0, 500, ARISTOS_MULTI_SX_X, ARISTOS_MULTI_SX_Y);	// multi
		//SetRect(&PastFailedRectValue,0,500,800,600);	// multi
		else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
			SetRect(&PastFailedRectValue, 0, 206, 175, ARISTOS_MINI_QX_Y);
		else
			SetRect(&PastFailedRectValue, 0, 206, 175, ARISTOS_MINI_EZ_Y);
		//SetRect(&PastFailedRectValue,0,206,175,240);	
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_TEXTOBJECT, &PastFailedRectValue)) {
			PCUROBJ->m_pCMMbase->FixForeColour = TRUE;
			PCUROBJ->m_pCMMbase->ForeColour = 0;	// black	
			PCUROBJ->m_pCMMbase->FixBackColour = TRUE;
			PCUROBJ->m_pCMMbase->BackColour = QString(255, 255, 255); // white 
			PCUROBJ->m_pCMMbase->IsBuffered = 1; // prevent flicker as updated often
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Font.Quality = 1; //anti aliased
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->FixText = TRUE;
			((T_TEXTOBJECT*) PCUROBJ->m_pCMMbase)->Center = TRUE;
			((CTextObject*) PCUROBJ)->SetBounds(&PastFailedRectValue);
			((CTextObject*) PCUROBJ)->SetTextString("");
			m_pOpPanel->m_HotSoakObjects[HS_PassFail][HS_Message] = PCUROBJ;
		}
		// Start/Stop button
		QRect StartRectbutton;
		SetRect(&StartRectbutton, 182, 110, 319, 139);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_BUTTONOBJECT, &StartRectbutton)) {
			PCUROBJ->m_pCMMbase->BackColour = QString(64, 144, 255); // a nice blue
			PCUROBJ->m_pCMMbase->IsBuffered = TRUE;
			ScaleRect(&StartRectbutton, multifactor);
			((CButtonObject*) PCUROBJ)->SetBounds(&StartRectbutton);
			((CButtonObject*) PCUROBJ)->SetTextString("");
			((CButtonObject*) PCUROBJ)->m_ButtonID = SB_STARTSTOP;
			m_pOpPanel->m_HotSoakObjects[HS_StartStop][HS_Message] = PCUROBJ;
		}
		// prepare for shipment button
		QRect ShipRectbutton;
		SetRect(&ShipRectbutton, 182, 212, 319, 240);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig, BLK_BUTTONOBJECT, &ShipRectbutton)) {
			PCUROBJ->m_pCMMbase->BackColour = QString(64, 144, 255); // a nice blue
			PCUROBJ->m_pCMMbase->IsBuffered = TRUE;
			ScaleRect(&ShipRectbutton, multifactor);
			((CButtonObject*) PCUROBJ)->SetBounds(&ShipRectbutton);
			((CButtonObject*) PCUROBJ)->SetTextString(L"Prepare for Ship");
			((CButtonObject*) PCUROBJ)->m_ButtonID = SB_SHIPPING;
			m_pOpPanel->m_HotSoakObjects[HS_Ship][HS_Message] = PCUROBJ;
		}
		m_pSelectedWidget->ConfigChange();
		m_pOpPanel->RefreshHotSoakScreen(TRUE);
	}
}
#endif
#endif
//****************************************************************************
/// Create the Replay Screen
///
/// @return none
/// 
//****************************************************************************
void CScreen::PopulateReplayScreen() {
	QRect ScreenArea;
	int maxpencount = 0;
	T_DEV_TYPE device = m_pOpPanel->m_pMainConfig->GetRecorderType();
	if (device == DEV_ARISTOS_MULTIPLUS) {
		SetRect(&ScreenArea, 0, 0, ARISTOS_MULTI_SX_X, ARISTOS_MULTI_SX_Y - MULTI_STATUS_BAR_HEIGHT);
		//SetRect(&ScreenArea,0,0,800,600-MULTI_STATUS_BAR_HEIGHT);			
//		maxpencount=12; // 12 pens max for replay on multi
		maxpencount = 18; // 18 pens max for replay on multi(for EDF)
	} else if (device == DEV_ARISTOS_MINITREND) {
		SetRect(&ScreenArea, 0, 0, ARISTOS_MINI_QX_X, ARISTOS_MINI_QX_Y - MINI_STATUS_BAR_HEIGHT);
		//SetRect(&ScreenArea,0,0,320,240-MINI_STATUS_BAR_HEIGHT);
		maxpencount = 8; // for mini and Ez 8 pens max.
	} else if (device == DEV_EZTREND || device == DEV_XS_MINITREND) {
		SetRect(&ScreenArea, 0, 0, ARISTOS_MINI_EZ_X, ARISTOS_MINI_EZ_Y - MINI_EZ_STATUS_BAR_HEIGHT);
		//SetRect(&ScreenArea,0,0,320,240-MINI_STATUS_BAR_HEIGHT);
		maxpencount = 8; // for mini and Ez 8 pens max.
	} else if (device == DEV_XS_MULTIPLUS) {
		SetRect(&ScreenArea, 0, 0, X_SERIES_MULTI_SX_X, X_SERIES_MULTI_SX_Y - MULTI_XS_STATUS_BAR_HEIGHT);
		maxpencount = 18;
	}
	// count the number of pens for the replay screen
	m_pencount = 0;
	for (int p = 0; p < SCREEN_CANNEDPENS_SIZE; p++) {
		// E527303[
		//if(m_pCMMscreen->CannedPens[p].PenIndex!=0xffff)
		if (m_pCMMscreen->ReplayPens[p].PenIndex != 0xffff) //]				
				{
			if (m_pencount < maxpencount)
				m_pencount++;
		}
	}
	// ensure that we have at least 1 pen available
	if (m_pencount == 0) {
		m_pencount = 1;
		// E527303
		//m_pCMMscreen->CannedPens[0].Dpm=TRUE; //ensure enabled as default //old
		m_pCMMscreen->ReplayPens[0].Dpm = TRUE; //ensure enabled as default
	}
	// set up the DPM Area we get one for each pen enabled (up to the max)
	QRect DPMArea = ScreenArea;
	int iDPMWidth = 100;
	if (m_pencount <= 4)
		iDPMWidth = 65;
	DPMArea.setleft(DPMArea).right - iDPMWidth; // larger DPM width for mini.
	ScreenArea.setright(DPMArea).left; // reduce the screenArea
	int dpmheight = _Height(DPMArea) / m_pencount;
	// now create the widgets required and DPM contents. (each pen gets a DPM)
	for (int i = 0; i < m_pencount; i++) {
		QRect res = DPMArea;
		res.setTop(i) * dpmheight;
		if (i < m_pencount - 1)
			res.setBottom(res).top + dpmheight;
		if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pReplayScrConfig, &res)) {
			m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
			m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
			// need to set up the maxmin replay entries in the data item table.
			CDataItemPen *m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_MM_REPLAY, i);
			// E527303[
			//m_pPenDataItem->SetReplayPenConfig(m_pCMMscreen->CannedPens[i].PenIndex); //old
			m_pPenDataItem->SetReplayPenConfig(m_pCMMscreen->ReplayPens[i].PenIndex);
			//]
			m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_MM_REPLAY, i + MAX_REPLAY_PENS);
			// E527303[
			//m_pPenDataItem->SetReplayPenConfig(m_pCMMscreen->CannedPens[i].PenIndex);//old
			m_pPenDataItem->SetReplayPenConfig(m_pCMMscreen->ReplayPens[i].PenIndex);
			//]
			// here the pen index we add is the index of the maxmin in the dit.
			if (AddDPMContents(m_pOpPanel->m_pReplayScrConfig, i, FALSE, FALSE, TRUE)) // no maxmin or total, but it is replay
					{
				m_pSelectedWidget->ConfigChange();
			} else {
				QString strError("");
				// E527303[
				//strError = QString::asprintf( L"Failed to create all DPM objects, %s, Pen %u", m_pCMMscreen->Name, m_pCMMscreen->CannedPens[i].PenIndex + 1 );
				strError = QString::asprintf("Failed to create all DPM objects, %s, Pen %u", m_pCMMscreen->Name,
						m_pCMMscreen->ReplayPens[i].PenIndex + 1);
				//]
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			}
		} else {
			QString strError("");
			// E527303[
			//strError = QString::asprintf( L"Failed to create DPM widget, %s, Pen %u", m_pCMMscreen->Name, m_pCMMscreen->CannedPens[i].PenIndex + 1 );
			strError = QString::asprintf("Failed to create DPM widget, %s, Pen %u", m_pCMMscreen->Name,
					m_pCMMscreen->ReplayPens[i].PenIndex + 1);
			//]
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	}
	// now create the Chart.
	// ScreenArea now contains area remaining for the CHART
	// add the widget
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pReplayScrConfig, &ScreenArea)) {
		// now add the Chart Object (at *relative* 0,0 to widget)
		QRect ChartRect;
		SetRect(&ChartRect, 0, 0, _Width(ScreenArea), _Height(ScreenArea));
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pReplayScrConfig, BLK_CHARTOBJECT, &ChartRect)) {
			((T_CHARTOBJECT*) m_pSelectedWidget->m_pSelectedObject->m_pCMMbase)->IsVertical = m_pCMMscreen->IsVert;
			//	m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->Border.BorderUsed=FALSE; // turn border off for chart object
			CChartObject *pchartObj = (CChartObject*) m_pSelectedWidget->m_pSelectedObject;
			// These addtions were made for EDF
			// here set up the Replay colours for background and background alarm colour
			pchartObj->m_pCMMbase->BackColour = m_pOpPanel->m_pCMMlayout->ChartReplayBCol;
			pchartObj->m_pCMMbase->FixBackColour = TRUE;
			pchartObj->m_pCMMchart->BGAlarmCol = m_pOpPanel->m_pCMMlayout->ChartRplAlmBCol;
			pchartObj->m_pCMMchart->FixBGAlarmCol = TRUE;
			pchartObj->m_pCMMchart->FontHeight = Glb_FontHeight;
			// and replay graduations
			pchartObj->m_pCMMbase->ForeColour = m_pOpPanel->m_pCMMlayout->ChartReplayFCol;
			pchartObj->m_pCMMbase->FixForeColour = TRUE;
			// and add the CursorObject (will go on top, since chart is advanced and in background)
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pReplayScrConfig, BLK_CURSOROBJECT, &ChartRect)) // use same size as chart
					{
				CCursorObject *pcursorobj = (CCursorObject*) m_pSelectedWidget->m_pSelectedObject;
				((T_CURSOROBJECT*) pcursorobj->m_pCMMbase)->IsVertical = m_pCMMscreen->IsVert;
				pcursorobj->m_pCMMbase->Border.BorderUsed = TRUE; // turn border ON to match chart object
				for (int j = 0; j < m_pencount; j++) {
					// here re-use the cannedpens config for our replay screen
					// E527303[
					//SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[j],m_pCMMscreen->CannedPens[j].PenIndex);
					SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[j],
							m_pCMMscreen->ReplayPens[j].PenIndex);
					//]
				}
				m_pSelectedWidget->ConfigChange();
				pchartObj->m_ChartSpeed = Glb_ReplaySpeed;
				pchartObj->m_Tpp = CChartQManager::GetChartSpeed(Glb_ReplaySpeed);
				pchartObj->SetReplayMode(); // put it into replay mode.
				pcursorobj->ConfigChange(); // additional config change required for cursor object to get updated ChartQ's
			} else {
				QString strError("");
				strError = QString::asprintf("Failed to create cursor object, %s", m_pCMMscreen->Name);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			}
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create chart object, %s", m_pCMMscreen->Name);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	} else {
		QString strError("");
		strError = QString::asprintf("Failed to create chart widget, %s", m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
/// Populate a Canned Screen
///
/// @return none
/// 
//****************************************************************************
void CScreen::PopulateCannedScreen() {
	// always reset the screens channel map for a canned screen.
	// we will populate it all again below.
	for (int c = 0; c < SCREEN_CHANNELMAP_SIZE; c++)
		m_pCMMscreen->ChannelMap[c] = CScreen::ms_usUNINITIALISED_INSTANCE; // default value
//	T_CANNEDPENS localScreenPens; // This is to allow groups to preset the pens without affecting the actual pen list for the screen
	QRect ScreenArea;
	int maxpencount = SCREEN_CANNEDPENS_SIZE; // start with the max possible
	if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS
			|| m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS) {
		//SetRect(&ScreenArea,0,MULTI_STATUS_BAR_HEIGHT,800,600);	// status bar height=48 for multi
		if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS)
			SetRect(&ScreenArea, 0, MULTI_STATUS_BAR_HEIGHT, ARISTOS_MULTI_SX_X, ARISTOS_MULTI_SX_Y); // status bar height=64 for multi
		else
			SetRect(&ScreenArea, 0, MULTI_XS_STATUS_BAR_HEIGHT, X_SERIES_MULTI_SX_X, X_SERIES_MULTI_SX_Y); // status bar height=48 for multi
		if ((m_pCMMscreen->Type == TPL_CHRT_DPMS) || (m_pCMMscreen->Type == TPL_CHRT_BARS)
				|| (m_pCMMscreen->Type == TPL_CHRT_DPMS_BARS)) {
			maxpencount = 12; // any canned screen with a chart for for multi has 12 pens max.
		} else if (m_pCMMscreen->Type == TPL_AMS2750_PROCESS_SCREEN) {
			maxpencount = 12;
		}
	} else {
#ifndef V6IOTEST
		if (m_pCMMscreen->Type == TPL_TABULAR_SCREEN) {
			CCannedScrnData::ms_usMAX_MINI_TABULAR_PENS;
		} else if (m_pCMMscreen->Type == TPL_AMS2750_PROCESS_SCREEN) {
			// no pens on display on a QX/QXe AMS2750 process screen
			maxpencount = 0;
		} else
#endif
		{
			// must be DEV_ARISTOS_MINITREND, DEV_EZTREND or DEV_UNKNOWN 
			maxpencount = 8; // for mini and Ez 8 pens max.
		}
		//SetRect(&ScreenArea,0,MINI_STATUS_BAR_HEIGHT,320,240); // status bar height=32 for mini and ez
		if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
			SetRect(&ScreenArea, 0, MINI_STATUS_BAR_HEIGHT, ARISTOS_MINI_QX_X, ARISTOS_MINI_QX_Y); // status bar height=32 for mini and ez
		else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_EZTREND
				|| m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MINITREND)
			SetRect(&ScreenArea, 0, MINI_EZ_STATUS_BAR_HEIGHT, ARISTOS_MINI_EZ_X, ARISTOS_MINI_EZ_Y); // status bar height=32 for mini and ez
		else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS) {
			SetRect(&ScreenArea, 0, 0, X_SERIES_MULTI_SX_X, X_SERIES_MULTI_SX_Y - MULTI_XS_STATUS_BAR_HEIGHT);
		}
	}
	// If this canned screen is showing a group, preset the pens here.
	if (m_pCMMscreen->UseGroups) {
		//default the pens list for the screen
		int p;
		for (p = 0; p < SCREEN_CANNEDPENS_SIZE; p++) {
			m_pCMMscreen->CannedPens[p].PenIndex = 0xffff;
			// also set up the individual pen flags for scale, maxmin and total from the group settings
			m_pCMMscreen->CannedPens[p].Scale = m_pCMMscreen->GroupScales;
			m_pCMMscreen->CannedPens[p].MaxMin = m_pCMMscreen->GroupMaxMins;
			m_pCMMscreen->CannedPens[p].Total = m_pCMMscreen->GroupTotals;
		}
		CPenManager *pPenManager = CPenManager::GetHandle();
		if (pPenManager->IsGroupUsed((T_PEN_GROUPS) (m_pCMMscreen->GroupIndex + 1))) {
			// group is in use. (i.e. there are some pens for it!)
			int pensInGroup =
					pPenManager->GetGroupList((T_PEN_GROUPS) (m_pCMMscreen->GroupIndex + 1))->GetNumberOfPens();
			//
			// Stability Project Fix:
			//
			//if pensInFroup Value is greater than SCREEN_CANNEDPENS_SIZE,reset it to SCREEN_CANNEDPENS_SIZE 
			if (pensInGroup > SCREEN_CANNEDPENS_SIZE)
				pensInGroup = SCREEN_CANNEDPENS_SIZE;
			for (p = 0; p < pensInGroup; p++)
				m_pCMMscreen->CannedPens[p].PenIndex = pPenManager->GetGroupList(
						(T_PEN_GROUPS) (m_pCMMscreen->GroupIndex + 1))->GetEntry(p)->GetPenInstance();
		}
	}
	// count the number of configured pens for this canned screen
	int pencount = 0;
	int scalecount = 0;
	for (int p = 0; p < SCREEN_CANNEDPENS_SIZE; p++) {
		if (m_pCMMscreen->CannedPens[p].PenIndex != 0xffff) {
			if (pencount < maxpencount) {
				pencount++;
				scalecount += m_pCMMscreen->CannedPens[p].Scale;
			}
		}
	}
	// ensure that we have at least 1 pen available
	if (pencount == 0) {
		pencount = 1;
		//	m_pCMMscreen->CannedPens[0].PenIndex=100; // leave pen index as 0xffff which is invalid
	}
	if ((m_pCMMscreen->Type == TPL_CHRT_DPMS) || (m_pCMMscreen->Type == TPL_CHRT_BARS)
			|| (m_pCMMscreen->Type == TPL_CHRT_DPMS_BARS)) {
		QRect DPMArea = ScreenArea;
		// set up the DPM Area (if any). If we have DPM's turned on, we get one for each canned pen that exists.
		if ((m_pCMMscreen->Type == TPL_CHRT_DPMS) || (m_pCMMscreen->Type == TPL_CHRT_DPMS_BARS)) {
			// we have DPM's.
			if (pencount < 5) // for minitrend...
					{	// here the DPM's run along the bottom of the screen.
				DPMArea.setTop(DPMArea).bottom - 24; // DPM height for mini.
				ScreenArea.setBottom(DPMArea).top; // reduce the screenArea
				int dpmwidth = _Width(DPMArea) / pencount;
				// now create the widgets required and DPM contents. (each pen gets a DPM)
				for (int i = 0; i < pencount; i++) {
					QRect res = DPMArea;
					res.setLeft(i) * dpmwidth;
					if (i < pencount - 1)
						res.setright(res).left + dpmwidth;
#ifdef DOCVIEW
					// need to offset the rect here, since AddNewWidget expects screen co-ords.
					OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
	#endif
					if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
						m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
						m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
						if (AddDPMContents(m_pOpPanel->m_pCannedConfig, m_pCMMscreen->CannedPens[i].PenIndex, FALSE,
						FALSE)) // no maxmin or total
								{
							m_pSelectedWidget->ConfigChange();
						} else {
							QString strError("");
							strError = QString::asprintf("Failed to create all DPM objects, %s, Pen %u",
									m_pCMMscreen->Name, m_pCMMscreen->CannedPens[i].PenIndex + 1);
							LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
						}
					} else {
						QString strError("");
						strError = QString::asprintf("Failed to create DPM widget, %s, Pen %u", m_pCMMscreen->Name,
								m_pCMMscreen->CannedPens[i].PenIndex + 1);
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
					}
				}
			} else {
				DPMArea.setleft(DPMArea).right - 54; // DPM width for mini.
				ScreenArea.setright(DPMArea).left; // reduce the screenArea
				int dpmheight = _Height(DPMArea) / pencount;
				// now create the widgets required and DPM contents. (each pen gets a DPM)
				for (int i = 0; i < pencount; i++) {
					QRect res = DPMArea;
					res.setTop(i) * dpmheight;
					if (i < pencount - 1)
						res.setBottom(res).top + dpmheight;
#ifdef DOCVIEW
					// need to offset the rect here, since AddNewWidget expects screen co-ords.
					OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
	#endif
					if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
						m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
						m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
						if (AddDPMContents(m_pOpPanel->m_pCannedConfig, m_pCMMscreen->CannedPens[i].PenIndex, FALSE,
						FALSE)) // no maxmin or total
								{
							m_pSelectedWidget->ConfigChange();
						} else {
							QString strError("");
							strError = QString::asprintf("Failed to create all DPM objects, %s, Pen %u",
									m_pCMMscreen->Name, m_pCMMscreen->CannedPens[i].PenIndex + 1);
							LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
						}
					} else {
						QString strError("");
						strError = QString::asprintf("Failed to create DPM widget, %s, Pen %u", m_pCMMscreen->Name,
								m_pCMMscreen->CannedPens[i].PenIndex + 1);
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
					}
				}
			}
		}
		// set up the Indicator (scale+pointer/bar + alarm mks) area (always 1)
		QRect ScaleArea = ScreenArea;
		int numCreateScales = scalecount;
		if (numCreateScales == 0) {
			numCreateScales++; // default is always 1 scale
			m_pCMMscreen->CannedPens[0].Scale = TRUE; // use first pen. set it here.
		}
		// check here for rotating bars...
		if ((m_pCMMscreen->IsRotate) || (m_pCMMscreen->Type == TPL_CHRT_DPMS)) {
			numCreateScales = 1; // for rotating, or for DPM's only, we only have 1 scale.
			m_pCMMscreen->CannedPens[0].Scale = TRUE; // make sure first pen has a scale. set it here.
		}
		BOOL HasAlarmMarkers = TRUE; // the default is to always have alarm markers.
		if (m_pCMMscreen->Type == TPL_CHRT_DPMS) {
			HasAlarmMarkers = FALSE; // but not for this screen type
			m_pCMMscreen->IsPointer = TRUE; // penpointers only (no bar)
			m_pCMMscreen->IsRotate = FALSE; // no rotating
		}
		int scalethickness;
		if (m_pCMMscreen->IsVert) {
			// vertical chart has horizontal scale(s)
			scalethickness = 33;
			if (numCreateScales > 1)
				scalethickness = 20;
			if (numCreateScales > 4)
				scalethickness = 16;
			ScaleArea.setBottom(ScaleArea).top + (numCreateScales * scalethickness);
			ScreenArea.setTop(ScaleArea).bottom;
		} else {
			// horizontal chart has vertical scale(s)
			scalethickness = 51;
			if (numCreateScales > 1)
				scalethickness = 41;
			if (numCreateScales > 4)
				scalethickness = 21;
			ScaleArea.setleft(ScaleArea).right - (numCreateScales * scalethickness);
			ScreenArea.setright(ScaleArea).left;
		}
		// First create the Chart.
		// ScreenArea now contains area remaining for the CHART
		// add the widget
#ifdef DOCVIEW
		// need to offset the rect here, since AddNewWidget expects screen co-ords.
		OffsetRect(&ScreenArea,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
		if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &ScreenArea)) {
			// now add the Chart Object (at relative 0,0 to widget)
			QRect ChartRect;
			SetRect(&ChartRect, 0, 0, _Width(ScreenArea), _Height(ScreenArea));
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_CHARTOBJECT, &ChartRect)) {
				((T_CHARTOBJECT*) m_pSelectedWidget->m_pSelectedObject->m_pCMMbase)->IsVertical = m_pCMMscreen->IsVert;
				m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->Border.BorderUsed = FALSE; // turn border off for chart object
				CChartObject *pchartObj = (CChartObject*) m_pSelectedWidget->m_pSelectedObject;
				for (int i = 0; i < pencount; i++) {
					SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[i],
							m_pCMMscreen->CannedPens[i].PenIndex);
				}
				m_pSelectedWidget->ConfigChange();
				if (m_pCMMscreen->IsVert) {
					CBaseObject *tempObj = pchartObj;
					// create horizontal Indicators (scales) block..
					int scalenum = 0;
					for (int i = 0; i < pencount; i++) {
						QRect res = ScaleArea;
						if ((m_pCMMscreen->CannedPens[i].Scale) && (scalenum < numCreateScales)) {
							res.setTop(scalenum) * scalethickness;
							res.setBottom(res).top + scalethickness;
							scalenum++;
#ifdef DOCVIEW
							// need to offset the rect here, since AddNewWidget expects screen co-ords.
							OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
		#endif
							if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
								//m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed=1;
								m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
								CBaseObject *pObj = AddIndicatorVContents(m_pCMMscreen->CannedPens[i].PenIndex,
										m_pCMMscreen->IsPointer, HasAlarmMarkers, m_pCMMscreen->IsRotate, tempObj);
								if (pObj) {
									tempObj = pObj;
								}
								m_pSelectedWidget->ConfigChange();
							} else {
								QString strError("");
								strError = QString::asprintf("Failed to create vertical indicator widget, %s",
										m_pCMMscreen->Name);
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
							}
						}
					}
					// now adjust chart to full width - taking all the linked objects with it.
					ChartRect.setleft(0);
					ChartRect.setright(_Width)(ScreenArea);
					((CBaseObject*) pchartObj)->SetBoundsRelative(&ChartRect);
					ChartRect = pchartObj->GetBounds();
					pchartObj->SetLinkLimits(*(int*) &ChartRect.left, *(int*) &ChartRect.right); // and all the other objects
				} else {
					CBaseObject *tempObj = pchartObj;
					// create vertical Indicators (scales) block..
					int scalenum = 0;
					for (int i = 0; i < pencount; i++) {
						QRect res = ScaleArea;
						if ((m_pCMMscreen->CannedPens[i].Scale) && (scalenum < numCreateScales)) {
							res.setLeft(scalenum) * scalethickness;
							res.setright(res).left + scalethickness;
							scalenum++;
#ifdef DOCVIEW
							// need to offset the rect here, since AddNewWidget expects screen co-ords.
							OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
		#endif
							if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
								//m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed=1;
								m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
								CBaseObject *pObj = AddIndicatorHContents(m_pCMMscreen->CannedPens[i].PenIndex,
										m_pCMMscreen->IsPointer, HasAlarmMarkers, m_pCMMscreen->IsRotate, tempObj);
								if (pObj) {
									tempObj = pObj;
								}
								m_pSelectedWidget->ConfigChange();
							} else {
								QString strError("");
								strError = QString::asprintf("Failed to create horizontal indicator widget, %s",
										m_pCMMscreen->Name);
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
							}
						}
					}
					// now adjust chart to full height- taking all the linked objects with it.
					ChartRect.setTop(0);
					ChartRect.setBottom(_Height)(ScreenArea);
					((CBaseObject*) pchartObj)->SetBoundsRelative(&ChartRect);
					ChartRect = pchartObj->GetBounds();
					pchartObj->SetLinkLimits(*(int*) &ChartRect.top, *(int*) &ChartRect.bottom); // and all the other objects
				}
				// now we need to unlink everything. (really only need to unlink across widgets)
				CWidget *pWgt = m_pWidgets;
				while (pWgt) {
					CBaseObject *pScale = NULL;
					CBaseObject *pAlrm = NULL;
					CBaseObject *pBarOrPointer = NULL;
					CBaseObject *tempObj = pWgt->m_pObjects;
					while (tempObj) {
						if (tempObj->m_pCMMbase->ObjectType == ScaleObject)
							pScale = tempObj;
						else if (tempObj->m_pCMMbase->ObjectType == AlarmMrkrObject)
							pAlrm = tempObj;
						else if ((tempObj->m_pCMMbase->ObjectType == BarObject)
								|| (tempObj->m_pCMMbase->ObjectType == PenPointersObject))
							pBarOrPointer = tempObj;
						// break all links.
						tempObj->m_pLinked = NULL;
						tempObj->m_pCMMbase->LinkedObj.CMM_Type = 0;
						tempObj->m_pCMMbase->LinkedObj.CMM_Inst = 0;
						tempObj = tempObj->m_pNextObj;
					}
					// now relink the scale and alarm markers !! (alarm markers have to be linked to draw correctly)
					if (pScale) {
						if (pAlrm)
							pScale->LinkTo(pAlrm);
						if (pBarOrPointer)
							pScale->LinkTo(pBarOrPointer); // relink the bar or pointer too
					}
					pWgt = pWgt->m_pNextWgt;
				}
				if ((m_pCMMscreen->IsRotate) || ((m_pCMMscreen->Type == TPL_CHRT_DPMS) && (m_pCMMscreen->IsPointer))) {
					// here we need to fix the Widgets channel list
					// For Rotating bars/penpointers, we add all the pens and set it up to rotate.
					// For TPL_CHRT_DPMS with PenPointers we set up the channels so that all the pen pointers will be shown in the single Object.
					// if we added a penpointers object to the widget above, it will have set up the WidgetChannel List.
					// so this next part may already be done..
					while (m_pSelectedWidget->m_pCMMwidget->NumChannels < pencount) {
						// the number of channels variable is also the location of the
						// first free widget channel
						const USHORT usSCREEN_INDEX = m_pSelectedWidget->GetFreeScreenInstIndex(this,
								CScreen::ms_usUNINITIALISED_INSTANCE);
						if (usSCREEN_INDEX != CWidget::ms_usNO_FREE_SCREEN_INDEXES) {
							m_pSelectedWidget->m_pCMMwidget->ChannelList[m_pSelectedWidget->m_pCMMwidget->NumChannels] =
									usSCREEN_INDEX + CWidget::ms_usCHANNEL_OFFSET;
							++m_pSelectedWidget->m_pCMMwidget->NumChannels;
						} else {
							// run out of screen indexes - highly unlikely but generate an error to cope with it
							LOG_ERR( TRACE_OPPANEL, "RUN OUT OF FREE SCREEN INSTANCES");
							break;
						}
					}
					for (int i = 0; i < pencount; i++)
						SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[i],
								m_pCMMscreen->CannedPens[i].PenIndex);
					m_pSelectedWidget->m_pCMMwidget->NumChannels = pencount; // set this to actual number of pens
					if (m_pCMMscreen->IsRotate) {
						m_pSelectedWidget->m_pCMMwidget->NumRotateChan = pencount;
						m_pSelectedWidget->m_pCMMwidget->RotateChannels = TRUE;
					}
					m_pSelectedWidget->ConfigChange();
				} /*
				 else
				 {
				 QString strError(QString ::fromWCharArray("") );
				 strError = QString::asprintf( L"Failed to create chart object, %s", m_pCMMscreen->Name );
				 LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, strError );
				 }
				 }
				 else
				 {
				 QString strError(QString ::fromWCharArray("") );
				 strError = QString::asprintf( L"Failed to create chart widget, %s", m_pCMMscreen->Name );
				 LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, strError );
				 }*/
			} else {
				QString strError("");
				strError = QString::asprintf("Failed to create chart object, %s", m_pCMMscreen->Name);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			}
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create chart widget, %s", m_pCMMscreen->Name);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	} else if (m_pCMMscreen->Type == TPL_TABULAR_SCREEN) {
		PopulateTabularProcessScreen(ScreenArea, pencount);
	} else if (m_pCMMscreen->Type == TPL_AMS2750_PROCESS_SCREEN) {
		PopulateAMS2750ProcessScreen(ScreenArea, pencount, scalecount);
	} else if (m_pCMMscreen->Type == TPL_AMS2750_TUS_SCREEN) {
		PopulateAMS2750TUSScreen(ScreenArea, pencount);
	} else {
		// for bars and DPM's
		QRect res;
		for (int i = 0; i < pencount; i++) {
			if (m_pCMMscreen->Type == TPL_DPMS)
				res = SplitRectDPM(i, pencount, ScreenArea);
			else if (m_pCMMscreen->Type == TPL_DPMS_BARS) {
				if (m_pCMMscreen->IsVert) {
					res = SplitRectBarsV(i, pencount, ScreenArea);
				} else
					res = SplitRectBarsH(i, pencount, ScreenArea);
			} else
				res = SplitRectBarsH(i, pencount, ScreenArea);
#ifdef DOCVIEW
			// need to offset the rect here, since AddNewWidget expects screen co-ords.
			OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
			if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
				m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
				m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
				if (m_pCMMscreen->Type == TPL_DPMS) {
					if (!AddDPMContents(m_pOpPanel->m_pCannedConfig, m_pCMMscreen->CannedPens[i].PenIndex,
							m_pCMMscreen->CannedPens[i].MaxMin, m_pCMMscreen->CannedPens[i].Total)) {
						QString strError("");
						strError = QString::asprintf("Failed to create all DPM objects, %s, Pen %u", m_pCMMscreen->Name,
								m_pCMMscreen->CannedPens[i].PenIndex + 1);
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
					}
				} else {
					if (m_pCMMscreen->Type == TPL_DPMS_BARS) {
						if (m_pCMMscreen->IsVert) {
							if (!AddBarVContents(m_pCMMscreen->CannedPens[i].PenIndex,
									m_pCMMscreen->CannedPens[i].MaxMin, m_pCMMscreen->CannedPens[i].Total)) {
								QString strError("");
								strError = QString::asprintf("Failed to create all of V Bar, Pen %u",
										m_pCMMscreen->CannedPens[i].PenIndex + 1);
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
							}
						} else {
							if (!AddBarHContents(m_pCMMscreen->CannedPens[i].PenIndex,
									m_pCMMscreen->CannedPens[i].MaxMin, m_pCMMscreen->CannedPens[i].Total)) {
								QString strError("");
								strError = QString::asprintf("Failed to create all of H Bar, Pen %u",
										m_pCMMscreen->CannedPens[i].PenIndex + 1);
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
							}
						}
					} else {
						if (!AddBarHContents(m_pCMMscreen->CannedPens[i].PenIndex, m_pCMMscreen->CannedPens[i].MaxMin,
								m_pCMMscreen->CannedPens[i].Total)) {
							QString strError("");
							strError = QString::asprintf("Failed to create all of H Bar, Pen %u",
									m_pCMMscreen->CannedPens[i].PenIndex + 1);
							LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
						}
					}
				}
				m_pSelectedWidget->ConfigChange();
			} else {
				QString strError("");
				strError = QString::asprintf("Failed to create widget, %s, Pen %u", m_pCMMscreen->Name,
						m_pCMMscreen->CannedPens[i].PenIndex + 1);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			}
		}
	}
	UnselectAll(); // unselect all objects and widgets on screen
}
//****************************************************************************
///
///	Divide up the full area into totalrect rectangles and return rect n.
/// This function works for DPM shaped rectangles
///
/// @param[in] RectIndex	- index of rectangle to return (0 based)
/// @param[in] TotalRects	- Total number of rectangles to provide for
/// @param[in] HasTotal		- Area to dive up into rectangles
///
/// @return	QRect structure defining rectangle requested
/// 
//****************************************************************************
QRect CScreen::SplitRectDPM(int RectIndex, int TotalRects, QRect FullArea) {
	int numcols = 2; // default for mini + multi. 
	if (TotalRects > 10) // multi 
		numcols = 3;
	if (TotalRects > 21)
		numcols = 4;
	if (TotalRects <= numcols) // single column for fewer entries
		numcols = 1;
	int numrows = TotalRects / numcols;
	int numOddRects = TotalRects % numcols; // number of odd rectangles on top row before main rows start.
	if (numOddRects)
		numrows++;
	int height = _Height(FullArea) / numrows;
	int width = _Width(FullArea) / numcols;
	int Xoffset;
	int Yoffset;
	if (RectIndex < numOddRects) {
		width = _Width(FullArea) / numOddRects;
		Xoffset = RectIndex;
		Yoffset = 0;
	} else {
		Xoffset = (RectIndex - numOddRects) % numcols;
		Yoffset = (RectIndex - numOddRects) / numcols;
		if (numOddRects)
			Yoffset++; // allow for the first row.
	}
	QRect result;
	result.setleft(FullArea).left + (Xoffset * width);
	result.setright(result).left + width;
	result.setTop(FullArea).top + (Yoffset * height);
	result.setBottom(result).top + height;
	// if nearly at the edge, make up to the edge
	if (result.right >= FullArea.right - 10)
		result.setright(FullArea).right;
	if (result.bottom >= FullArea.bottom - 10)
		result.setBottom(FullArea).bottom;
	return result;
}
//****************************************************************************
// void MatchColour( CWidget *pkWidget )
///
/// Method that converts a 16-bit colour into a 32-bit
///
/// @param[in]		CWidget *pkWidget
///
//**************************************************************************** 
void CScreen::MatchColour(CWidget *pkWidget) {
	if (pkWidget != NULL) {
		if (pkWidget->m_pSelectedObject != NULL) {
			if (pkWidget->m_pSelectedObject->m_pCMMbase != NULL) {
				if (pkWidget->m_pCMMwidget != NULL) {
					pkWidget->m_pSelectedObject->m_pCMMbase->BackColour = RGB565toRGB(
							pkWidget->m_pCMMwidget->BackColour);
				} else {
					DebugBreak();
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "DoMatchColour - Widget CMM Base is NULL");
				}
			} else {
				DebugBreak();
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "DoMatchColour - Object CMM Base is NULL");
			}
		} else {
			DebugBreak();
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "DoMatchColour - Selected object is NULL");
		}
	} else {
		DebugBreak();
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "DoMatchColour - Widget is NULL");
	}
}
//****************************************************************************
///
///	Fill the widget with the largest DPM that will fit.
///
/// @param[in] PenIndex		- zero based pen index (0=pen1) (or index into maxmins for replay)
/// @param[in] HasMaxMin	- Include maxmins where possible
/// @param[in] HasTotal		- Include total where possible
/// @param[in] IsReplay		- Special DPM for replay, contains 2 pen values
///
/// @return	T/F - indicating success of adding
/// 
//****************************************************************************
BOOL CScreen::AddDPMContents(CLayoutConfiguration *pConfig, int PenIndex, BOOL HasMaxMin, BOOL HasTotal, BOOL IsReplay) //=FALSE
		{
	USHORT numchans;
	T_PCHANNELREF pchref = NULL;
	BOOL HasAlarmMarkers = TRUE;
	BOOL HasUnits = TRUE;
	BOOL AntiAliasedTag = FALSE;
	int alarmmarkerheight = 10; // for most
	// local pointers for clarity
	CWidget *pWgt = m_pSelectedWidget;
	bool bRetVal = true;
	// DPM can have the following:
	QRect TagRect, ValueRect, MaxTagRect, MaxValueRect, MinTagRect, MinValueRect, TotalTagRect, TotalValueRect,
			UnitsTagRect, AlarmMarkerRect;
	QRect bounds = pWgt->GetWidgetBounds();
	BOOL IsMultiPlus = (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS
			|| m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS);
	int Wwidth = _Width(bounds);
	int Wheight = _Height(bounds);
	int diffX = 0;
	int diffY = 0;
	// here we have kept the widgets designed for each seperate (multi have slightly different style)
	if (IsMultiPlus) {
		// Rahul need to understand login before changing Height and Width....
		if ((Wwidth >= 800) && (Wheight >= 276)) {
			// 800x276 Mplus 
			diffX = Wwidth - 800;
			diffY = Wheight - 276;
			AntiAliasedTag = TRUE;  // for the large font
			alarmmarkerheight = 32;
			SetRect(&TagRect, 10, 1, 604, 64);
			SetRect(&ValueRect, 10, 64, 799, 202);
			SetRect(&MaxTagRect, 10, 203, 71, 239);
			SetRect(&MaxValueRect, 72, 204, 256, 238);
			SetRect(&MinTagRect, 10, 239, 71, 275);
			SetRect(&MinValueRect, 72, 240, 256, 274);
			SetRect(&TotalTagRect, 288, 201, 401, 237);
			SetRect(&TotalValueRect, 289, 240, 490, 274);
			SetRect(&UnitsTagRect, 500, 202, 799, 251);
			SetRect(&AlarmMarkerRect, 609, 1, 799, 35);
		} else if ((Wwidth >= 400) && (Wheight >= 276)) {
			// 400x276 Mplus 
			diffX = Wwidth - 400;
			diffY = Wheight - 276;
			AntiAliasedTag = TRUE;  // for the large font
			alarmmarkerheight = 24;
			SetRect(&TagRect, 4, 1, 258, 31);
			SetRect(&ValueRect, 4, 93, 399, 163);
			SetRect(&MaxTagRect, 4, 234, 34, 254);
			SetRect(&MaxValueRect, 35, 236, 141, 254);
			SetRect(&MinTagRect, 4, 254, 34, 274);
			SetRect(&MinValueRect, 35, 256, 141, 274);
			SetRect(&TotalTagRect, 146, 254, 208, 274);
			SetRect(&TotalValueRect, 209, 256, 332, 274);
			SetRect(&UnitsTagRect, 213, 174, 399, 210);
			SetRect(&AlarmMarkerRect, 258, 1, 399, 31);
		} else if ((Wwidth >= 400) && (Wheight >= 184)) {
			// 400x184 Mplus 
			diffX = Wwidth - 400;
			diffY = Wheight - 184;
			AntiAliasedTag = TRUE;  // for the large font
			alarmmarkerheight = 24;
			SetRect(&TagRect, 4, 1, 258, 31);
			SetRect(&ValueRect, 4, 40, 399, 110);
			SetRect(&MaxTagRect, 4, 146, 34, 164);
			SetRect(&MaxValueRect, 35, 148, 127, 164);
			SetRect(&MinTagRect, 4, 164, 34, 182);
			SetRect(&MinValueRect, 35, 165, 127, 181);
			SetRect(&TotalTagRect, 129, 164, 188, 182);
			SetRect(&TotalValueRect, 189, 165, 298, 181);
			SetRect(&UnitsTagRect, 226, 113, 399, 147);
			SetRect(&AlarmMarkerRect, 258, 1, 399, 31);
		} else if ((Wwidth >= 400) && (Wheight >= 138)) {
			// 400x138 Mplus 
			diffX = Wwidth - 400;
			diffY = Wheight - 138;
			AntiAliasedTag = TRUE;  // for the large font
			alarmmarkerheight = 20;
			SetRect(&TagRect, 4, 1, 275, 25);
			SetRect(&ValueRect, 4, 26, 399, 96);
			SetRect(&MaxTagRect, 4, 104, 28, 120);
			SetRect(&MaxValueRect, 29, 105, 113, 119);
			SetRect(&MinTagRect, 4, 120, 28, 136);
			SetRect(&MinValueRect, 29, 121, 113, 135);
			SetRect(&TotalTagRect, 114, 120, 164, 136);
			SetRect(&TotalValueRect, 165, 121, 266, 135);
			SetRect(&UnitsTagRect, 266, 97, 399, 129);
			SetRect(&AlarmMarkerRect, 277, 1, 399, 25);
		} else if ((Wwidth >= 266) && (Wheight >= 110)) {
			// 266x110 Mplus
			diffX = Wwidth - 266;
			diffY = Wheight - 110;
			alarmmarkerheight = 16;
			SetRect(&TagRect, 2, 1, 172, 18);
			SetRect(&ValueRect, 1, 21, 265, 68);
			SetRect(&MaxTagRect, 2, 81, 26, 95);
			SetRect(&MaxValueRect, 27, 83, 93, 95);
			SetRect(&MinTagRect, 2, 95, 26, 109);
			SetRect(&MinValueRect, 27, 96, 93, 108);
			SetRect(&TotalTagRect, 132, 95, 181, 109);
			SetRect(&TotalValueRect, 183, 96, 265, 108);
			SetRect(&UnitsTagRect, 170, 70, 265, 88);
			SetRect(&AlarmMarkerRect, 174, 1, 265, 17);
		} else if ((Wwidth >= 266) && (Wheight >= 78)) {
			// 266x78 Mplus
			diffX = Wwidth - 266;
			diffY = Wheight - 78;
			alarmmarkerheight = 11;
			SetRect(&TagRect, 2, 1, 118, 16);
			SetRect(&ValueRect, 1, 16, 197, 51);
			SetRect(&MaxTagRect, 2, 51, 26, 64);
			SetRect(&MaxValueRect, 26, 52, 92, 63);
			SetRect(&MinTagRect, 2, 64, 26, 77);
			SetRect(&MinValueRect, 26, 65, 92, 76);
			SetRect(&TotalTagRect, 144, 64, 183, 77);
			SetRect(&TotalValueRect, 185, 65, 265, 76);
			SetRect(&UnitsTagRect, 199, 37, 265, 51);
			SetRect(&AlarmMarkerRect, 187, 1, 265, 15);
		} else if ((Wwidth >= 200) && (Wheight >= 92)) {
			// 200x92 Mplus
			diffX = Wwidth - 200;
			diffY = Wheight - 92;
			alarmmarkerheight = 11;
			SetRect(&TagRect, 2, 1, 118, 17);
			SetRect(&ValueRect, 1, 21, 197, 56);
			SetRect(&MaxTagRect, 2, 62, 26, 76);
			SetRect(&MaxValueRect, 26, 64, 92, 76);
			SetRect(&MinTagRect, 2, 77, 26, 91);
			SetRect(&MinValueRect, 26, 79, 92, 91);
			SetRect(&TotalTagRect, 93, 78, 127, 90);
			SetRect(&TotalValueRect, 128, 79, 199, 89);
			SetRect(&UnitsTagRect, 132, 62, 199, 76);
			SetRect(&AlarmMarkerRect, 121, 1, 199, 19);
		} else if ((Wwidth >= 200) && (Wheight >= 78)) {
			// 200x78 Mplus
			diffX = Wwidth - 200;
			diffY = Wheight - 78;
			SetRect(&TagRect, 2, 1, 118, 15);
			SetRect(&ValueRect, 1, 17, 154, 45);
			SetRect(&MaxTagRect, 2, 55, 26, 66);
			SetRect(&MaxValueRect, 27, 57, 73, 66);
			SetRect(&MinTagRect, 2, 66, 26, 77);
			SetRect(&MinValueRect, 27, 67, 73, 76);
			SetRect(&TotalTagRect, 94, 65, 128, 76);
			SetRect(&TotalValueRect, 129, 66, 199, 75);
			SetRect(&UnitsTagRect, 143, 45, 199, 59);
			SetRect(&AlarmMarkerRect, 132, 2, 199, 16);
		} else if ((Wwidth >= 200) && (Wheight >= 69)) {
			// 200x69 Mplus
			diffX = Wwidth - 200;
			diffY = Wheight - 69;
			SetRect(&TagRect, 2, 1, 105, 12);
			SetRect(&ValueRect, 1, 13, 154, 41);
			SetRect(&MaxTagRect, 2, 46, 26, 57);
			SetRect(&MaxValueRect, 26, 47, 72, 56);
			SetRect(&MinTagRect, 2, 57, 26, 68);
			SetRect(&MinValueRect, 26, 58, 72, 67);
			SetRect(&TotalTagRect, 95, 57, 129, 68);
			SetRect(&TotalValueRect, 129, 58, 199, 67);
			SetRect(&UnitsTagRect, 132, 41, 199, 57);
			SetRect(&AlarmMarkerRect, 132, 2, 199, 13);
		}
//////////////////////////////////////////////// small DPM's here, same as for minitrend for now
		else if ((Wwidth >= 160) && (Wheight >= 24)) {
			// 160x24 (small DPM's)
			diffX = Wwidth - 160;
			diffY = Wheight - 24;
			SetRect(&TagRect, 2, 2, 82, 13);
			SetRect(&ValueRect, 2, 13, 48, 22);
			SetRect(&UnitsTagRect, 126, 11, 159, 22);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 106) && (Wheight >= 24)) {
			// 106x24 (small DPM's)
			diffX = Wwidth - 106;
			diffY = Wheight - 24;
			SetRect(&TagRect, 2, 1, 82, 12);
			SetRect(&ValueRect, 2, 13, 48, 22);
			SetRect(&UnitsTagRect, 72, 12, 105, 23);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 100) && (Wheight >= 26) && IsReplay) // special size for replay only
				{
			// SPECIAL DPM for Replay screen only
			diffX = Wwidth - 100;
			diffY = Wheight - 26;
			// we have pen tag, max and min value from the chart and the units
			SetRect(&TagRect, 2, 3, 61, 14);
			SetRect(&MaxValueRect, 2, 14, 48, 23);
			SetRect(&MinValueRect, 53, 14, 99, 23);
			SetRect(&UnitsTagRect, 63, 3, 99, 14);
			// no maxmin allowed
			HasMaxMin = FALSE;
			// No total allowed
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 65) && (Wheight >= 138) && IsReplay)
		// special size for replay only.Add new condition for reply 		
		//mode to check if the width is less then 65 in replay mode
				{
			diffX = Wwidth - 65;
			diffY = Wheight - 138;
			SetRect(&TagRect, 2, 3, 61, 14);
			SetRect(&UnitsTagRect, 2, 23, 61, 34);
			SetRect(&MaxValueRect, 2, 43, 61, 54);
			SetRect(&MinValueRect, 2, 63, 61, 74);
			// no maxmin allowed
			HasMaxMin = FALSE;
			// No total allowed
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 80) && (Wheight >= 24)) {
			// 80x24 (small DPM's)
			diffX = Wwidth - 80;
			diffY = Wheight - 24;
			SetRect(&TagRect, 2, 1, 79, 12);
			SetRect(&ValueRect, 2, 13, 48, 22);
			SetRect(&UnitsTagRect, 48, 12, 79, 23);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 54) && (Wheight >= 41)) {
			// 54x41 (very small DPM's)
			diffX = Wwidth - 54;
			diffY = Wheight - 41;
			SetRect(&TagRect, 2, 3, 53, 14);
			SetRect(&ValueRect, 7, 16, 53, 25);
			SetRect(&UnitsTagRect, 17, 27, 53, 38);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 54) && (Wheight >= 34)) {
			// 54x34 (smaller DPM)
			diffX = Wwidth - 54;
			diffY = Wheight - 34;
			SetRect(&TagRect, 2, 2, 53, 13);
			SetRect(&ValueRect, 7, 13, 53, 22);
			SetRect(&UnitsTagRect, 17, 22, 53, 33);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 54) && (Wheight >= 26)) {
			// 54x26 (Smallest DPM)
			diffX = Wwidth - 54;
			diffY = Wheight - 26;
			SetRect(&TagRect, 2, 3, 53, 14);
			SetRect(&ValueRect, 7, 14, 53, 23);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
			// no room for units
			HasUnits = FALSE;
		} else {
			bRetVal = false;
		}
	} else // MINITREND
	{
		if ((Wwidth >= 320) && (Wheight >= 104)) {
			// 320x104
			diffX = Wwidth - 320;
			diffY = Wheight - 104;
			AntiAliasedTag = TRUE;  // for the large font
			alarmmarkerheight = 19;
			SetRect(&TagRect, 2, 1, 186, 22);
			SetRect(&ValueRect, 4, 22, 319, 80);
			SetRect(&MaxTagRect, 2, 81, 26, 92);
			SetRect(&MaxValueRect, 26, 82, 72, 91);
			SetRect(&MinTagRect, 2, 92, 26, 103);
			SetRect(&MinValueRect, 26, 93, 72, 102);
			SetRect(&TotalTagRect, 89, 87, 123, 98);
			SetRect(&TotalValueRect, 124, 88, 194, 97);
			SetRect(&UnitsTagRect, 244, 80, 319, 103);
			SetRect(&AlarmMarkerRect, 186, 1, 319, 22);
		} else if ((Wwidth >= 320) && (Wheight >= 69)) {
			// 320x69
			diffX = Wwidth - 320;
			diffY = Wheight - 69;
			SetRect(&TagRect, 2, 1, 173, 13);
			SetRect(&ValueRect, 88, 15, 241, 43);
			SetRect(&MaxTagRect, 2, 46, 26, 57);
			SetRect(&MaxValueRect, 26, 47, 72, 56);
			SetRect(&MinTagRect, 2, 57, 26, 68);
			SetRect(&MinValueRect, 26, 58, 72, 67);
			SetRect(&TotalTagRect, 89, 51, 123, 62);
			SetRect(&TotalValueRect, 124, 52, 194, 61);
			SetRect(&UnitsTagRect, 283, 56, 319, 68);
			SetRect(&AlarmMarkerRect, 252, 1, 319, 11);
		} else if ((Wwidth >= 320) && (Wheight >= 52)) {
			// 320x52
			diffX = Wwidth - 320;
			diffY = Wheight - 52;
			SetRect(&TagRect, 2, 1, 92, 12);
			SetRect(&ValueRect, 88, 12, 241, 40);
			// no maxmin possible
			HasMaxMin = FALSE;
			SetRect(&TotalTagRect, 2, 40, 36, 51);
			SetRect(&TotalValueRect, 36, 41, 106, 50);
			SetRect(&UnitsTagRect, 283, 40, 319, 51);
			SetRect(&AlarmMarkerRect, 252, 1, 319, 11);
		} else if ((Wwidth >= 160) && (Wheight >= 104)) {
			// 160x104
			diffX = Wwidth - 160;
			diffY = Wheight - 104;
			SetRect(&TagRect, 2, 1, 92, 15);
			SetRect(&ValueRect, 6, 24, 159, 52);
			SetRect(&MaxTagRect, 2, 81, 26, 92);
			SetRect(&MaxValueRect, 26, 82, 72, 91);
			SetRect(&MinTagRect, 2, 92, 26, 103);
			SetRect(&MinValueRect, 26, 93, 72, 102);
			SetRect(&TotalTagRect, 89, 81, 123, 92);
			SetRect(&TotalValueRect, 89, 93, 159, 102);
			SetRect(&UnitsTagRect, 113, 60, 159, 74);
			SetRect(&AlarmMarkerRect, 92, 1, 159, 11);
		} else if ((Wwidth >= 160) && (Wheight >= 69)) {
			// 160x69
			diffX = Wwidth - 160;
			diffY = Wheight - 69;
			SetRect(&TagRect, 2, 1, 92, 13);
			SetRect(&ValueRect, 6, 13, 159, 41);
			SetRect(&MaxTagRect, 2, 46, 26, 57);
			SetRect(&MaxValueRect, 26, 47, 72, 56);
			SetRect(&MinTagRect, 2, 57, 26, 68);
			SetRect(&MinValueRect, 26, 58, 72, 67);
			SetRect(&TotalTagRect, 81, 46, 115, 57);
			SetRect(&TotalValueRect, 81, 58, 151, 67);
			SetRect(&UnitsTagRect, 123, 41, 159, 53);
			SetRect(&AlarmMarkerRect, 92, 1, 159, 11);
		} else if ((Wwidth >= 160) && (Wheight >= 52)) {
			// 160x52
			diffX = Wwidth - 160;
			diffY = Wheight - 52;
			SetRect(&TagRect, 2, 1, 92, 12);
			SetRect(&ValueRect, 6, 12, 159, 40);
			// no maxmin possible
			HasMaxMin = FALSE;
			SetRect(&TotalTagRect, 2, 40, 36, 51);
			SetRect(&TotalValueRect, 36, 41, 106, 50);
			SetRect(&UnitsTagRect, 123, 40, 159, 51);
			SetRect(&AlarmMarkerRect, 92, 1, 159, 11);
		} else if ((Wwidth >= 160) && (Wheight >= 24)) {
			// 160x24 (small DPM's)
			diffX = Wwidth - 160;
			diffY = Wheight - 24;
			SetRect(&TagRect, 2, 2, 82, 13);
			SetRect(&ValueRect, 2, 13, 48, 22);
			SetRect(&UnitsTagRect, 126, 11, 159, 22);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 106) && (Wheight >= 24)) {
			// 106x24 (small DPM's)
			diffX = Wwidth - 106;
			diffY = Wheight - 24;
			SetRect(&TagRect, 2, 1, 82, 12);
			SetRect(&ValueRect, 2, 13, 48, 22);
			SetRect(&UnitsTagRect, 72, 12, 105, 23);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 100) && (Wheight >= 26) && IsReplay) // special size for replay only
				{
			// SPECIAL DPM for Replay screen only
			diffX = Wwidth - 100;
			diffY = Wheight - 26;
			// we have pen tag, max and min value from the chart and the units
			SetRect(&TagRect, 2, 3, 61, 14);
			SetRect(&MaxValueRect, 2, 14, 48, 23);
			SetRect(&MinValueRect, 53, 14, 99, 23);
			SetRect(&UnitsTagRect, 63, 3, 99, 14);
			// no maxmin allowed
			HasMaxMin = FALSE;
			// No total allowed
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 65) && (Wheight >= 45) && IsReplay)
		// special size for replay only
				{
			// SPECIAL DPM for Replay screen only
			diffX = Wwidth - 65;
			diffY = Wheight - 45;
			SetRect(&TagRect, 2, 1, 61, 12);
			SetRect(&UnitsTagRect, 2, 12, 61, 23);
			SetRect(&MaxValueRect, 2, 23, 61, 34);
			SetRect(&MinValueRect, 2, 34, 61, 45);
			// no maxmin allowed
			HasMaxMin = FALSE;
			// No total allowed
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 80) && (Wheight >= 24)) {
			// 80x24 (small DPM's)
			diffX = Wwidth - 80;
			diffY = Wheight - 24;
			SetRect(&TagRect, 2, 1, 79, 12);
			SetRect(&ValueRect, 2, 13, 48, 22);
			SetRect(&UnitsTagRect, 48, 12, 79, 23);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 54) && (Wheight >= 41)) {
			// 54x41 (very small DPM's)
			diffX = Wwidth - 54;
			diffY = Wheight - 41;
			SetRect(&TagRect, 2, 3, 53, 14);
			SetRect(&ValueRect, 7, 16, 53, 25);
			SetRect(&UnitsTagRect, 17, 27, 53, 38);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 54) && (Wheight >= 34)) {
			// 54x34 (smaller DPM)
			diffX = Wwidth - 54;
			diffY = Wheight - 34;
			SetRect(&TagRect, 2, 2, 53, 13);
			SetRect(&ValueRect, 7, 13, 53, 22);
			SetRect(&UnitsTagRect, 17, 22, 53, 33);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
		} else if ((Wwidth >= 54) && (Wheight >= 26)) {
			// 54x26 (Smallest DPM)
			diffX = Wwidth - 54;
			diffY = Wheight - 26;
			SetRect(&TagRect, 2, 3, 53, 14);
			SetRect(&ValueRect, 7, 14, 53, 23);
			// no maxmin possible
			HasMaxMin = FALSE;
			// No total possible
			HasTotal = FALSE;
			// no alarm markers
			HasAlarmMarkers = FALSE;
			// no room for units
			HasUnits = FALSE;
		} else {
			bRetVal = false;
		}
	}
	// only proceed if no problems so far
	if (bRetVal) {
		// create the Objects...
		bool bFoundObjectError = false;
		// Textobject - Pen Tag	
		if (m_pOpPanel->AddNewObject(pConfig, BLK_TEXTOBJECT, &TagRect)) {
			MatchColour(pWgt);
			if (AntiAliasedTag)
				((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Font.Quality = 1; //antialiased
			if (IsReplay) {
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->SubType = DI_PEN_MM_REPLAY;
			}
		} else {
			bFoundObjectError = true;
		}
		if (!IsReplay && !bFoundObjectError) {
			// Digitalobject - Main value - only add if we are NOT doing replay
			if (m_pOpPanel->AddNewObject(pConfig, BLK_DIGITALOBJECT, &ValueRect)) {
				MatchColour(pWgt);
				if (_Height(ValueRect) > 14)
					pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = 1; // double buffer larger digitals
			} else {
				bFoundObjectError = true;
			}
		}
		if (HasUnits && !bFoundObjectError) {
			// Textobject - Units Tag	
			if (m_pOpPanel->AddNewObject(pConfig, BLK_TEXTOBJECT, &UnitsTagRect)) {
				MatchColour(pWgt);
				((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->IsUnits = 1;
				((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->IsTag = 0;
				if (IsReplay) {
					pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
					pchref->SubType = DI_PEN_MM_REPLAY;
				}
			} else {
				bFoundObjectError = true;
			}
		}
		if ((HasMaxMin || IsReplay) && !bFoundObjectError) {
			// Digitalobject - Max value
			if (m_pOpPanel->AddNewObject(pConfig, BLK_DIGITALOBJECT, &MaxValueRect)) {
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				if (HasMaxMin) {
					pchref->ItemType = DI_MMA;
					pchref->SubType = DI_MMA_MAX_USER;
				} else {
					pchref->ItemType = DI_PEN; // default 
					pchref->SubType = DI_PEN_MM_REPLAY;
					pWgt->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 1; // fast as possible
				}
				// Digitalobject - Min value
				if (m_pOpPanel->AddNewObject(pConfig, BLK_DIGITALOBJECT, &MinValueRect)) {
					MatchColour(pWgt);
					pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
					if (HasMaxMin) {
						pchref->ItemType = DI_MMA;
						pchref->SubType = DI_MMA_MIN_USER;
					} else {
						pchref->ItemType = DI_PEN; // default 
						pchref->SubType = DI_PEN_MM_REPLAY;
						pchref->IndexChan = 1; // use the next item in the widgets channel list (to be added below)
						pWgt->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 1; // fast as possible
					}
				} else {
					bFoundObjectError = true;
				}
			} else {
				bFoundObjectError = true;
			}
		}
		if (HasMaxMin && !bFoundObjectError) {
			// Textobject - Max Tag
			if (m_pOpPanel->AddNewObject(pConfig, BLK_TEXTOBJECT, &MaxTagRect)) {
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->ItemType = DI_MMA;
				pchref->SubType = DI_MMA_MAX_USER;
				// Textobject - Min Tag
				m_pOpPanel->AddNewObject(pConfig, BLK_TEXTOBJECT, &MinTagRect);
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->ItemType = DI_MMA;
				pchref->SubType = DI_MMA_MIN_USER;
			} else {
				bFoundObjectError = true;
			}
		}
		if (HasTotal && !bFoundObjectError) {
			// Textobject - Total Tag
			if (m_pOpPanel->AddNewObject(pConfig, BLK_TEXTOBJECT, &TotalTagRect)) {
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->ItemType = DI_TOTAL;
				pchref->SubType = DI_TOTAL_READING;
				// Digitalobject - Total value
				m_pOpPanel->AddNewObject(pConfig, BLK_DIGITALOBJECT, &TotalValueRect);
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->ItemType = DI_TOTAL;
				pchref->SubType = DI_TOTAL_READING;
			} else {
				bFoundObjectError = true;
			}
		}
		if (HasAlarmMarkers && !bFoundObjectError) {
			if (m_pOpPanel->AddNewObject(pConfig, BLK_ALARMMRKROBJECT, &AlarmMarkerRect)) {
				MatchColour(pWgt);
				((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Height = alarmmarkerheight;
			} else {
				bFoundObjectError = true;
			}
		}
		if (!bFoundObjectError) {
			if (IsReplay) {
				// first instance is 'parent'
				SetScreenInstance(pWgt->m_pCMMwidget->ChannelList[0], PenIndex);
				USHORT usSCREEN_INDEX = pWgt->GetFreeScreenInstIndex(this, CScreen::ms_usUNINITIALISED_INSTANCE);
				if (usSCREEN_INDEX != CWidget::ms_usNO_FREE_SCREEN_INDEXES) {
					pWgt->m_pCMMwidget->ChannelList[pWgt->m_pCMMwidget->NumChannels] = usSCREEN_INDEX
							+ CWidget::ms_usCHANNEL_OFFSET;
					++pWgt->m_pCMMwidget->NumChannels;
					SetScreenInstance(pWgt->m_pCMMwidget->ChannelList[1], MAX_REPLAY_PENS + PenIndex);
				}
			} else
				SetScreenInstance(pWgt->m_pCMMwidget->ChannelList[0], PenIndex);
			if (diffX)
				diffX /= 2;
			if (diffY)
				diffY /= 2;
			// move objects into middle of widget.
			if ((diffX) || (diffY)) {
				CBaseObject *pObj = pWgt->m_pObjects;
				while (pObj) {
					QRect objBounds = pObj->GetBounds();
					OffsetRect(&objBounds, diffX, diffY);
					pObj->SetBounds(&objBounds);
					pObj = pObj->m_pNextObj;
				}
			}
		}
		// set the error flag accordingly
		bRetVal = !bFoundObjectError;
	}
	return (bRetVal == true);
}
//****************************************************************************
///
///	Divide up the full area into totalrect rectangles and return rect n.
/// This function works for Vertical bar shaped rectangles
///
/// @param[in] RectIndex	- index of rectangle to return (0 based)
/// @param[in] TotalRects	- Total number of rectangles to provide for
/// @param[in] HasTotal		- Area to dive up into rectangles
///
/// @return	QRect structure defining rectangle requested
/// 
//****************************************************************************
QRect CScreen::SplitRectBarsV(int RectIndex, int TotalRects, QRect FullArea) {
	int numrows = 1; // default for mini + multi. 
	if (_Width(FullArea) == ARISTOS_MINI_QX_X || _Width(FullArea) == ARISTOS_MINI_EZ_X) {
		if (TotalRects > 6) // more rows (mini)
			numrows = 2;
	} else {
		if (TotalRects > 8) // more rows (multi)
			numrows = 2;
	}
	int numcols = TotalRects / numrows;
	int numOddRects = TotalRects % numrows; // number of odd rectangles in first column before main columns start.
	if (numOddRects)
		numcols++;
	int height = _Height(FullArea) / numrows;
	int width = _Width(FullArea) / numcols;
	if (numOddRects)
		numcols--; // we only have 3 columns to play with
	int Xoffset;
	int Yoffset;
	if (RectIndex < numOddRects) {
		height = _Height(FullArea) / numOddRects;
		Xoffset = 0;
		Yoffset = RectIndex;
	} else {
		Xoffset = (RectIndex - numOddRects) % numcols;
		Yoffset = (RectIndex - numOddRects) / numcols;
		if (numOddRects)
			Xoffset++; // allow for the first column.
	}
	QRect result;
	result.setleft(FullArea).left + (Xoffset * width);
	result.setright(result).left + width;
	result.setTop(FullArea).top + (Yoffset * height);
	result.setBottom(result).top + height;
	// if nearly at the edge, make up to the edge
	if (result.right >= FullArea.right - 10)
		result.setright(FullArea).right;
	if (result.bottom >= FullArea.bottom - 10)
		result.setBottom(FullArea).bottom;
	return result;
}
//****************************************************************************
///
///	Fill the widget with the largest Vertical Bar that will fit.
///
/// @param[in] PenIndex		- zero based pen index (0=pen1)
/// @param[in] HasMaxMin	- Include maxmin markers on bars
/// @param[in] HasTotal		- Include total where possible
///
/// @return	T/F - indicating success of adding
/// 
//****************************************************************************
BOOL CScreen::AddBarVContents(int PenIndex, BOOL HasMaxMin, BOOL HasTotal) {
	USHORT numchans;
	T_PCHANNELREF pchref = NULL;
	// local pointers for clarity
	CWidget *pWgt = m_pSelectedWidget;
	bool bRetVal = true;
	// Vertical Bar has the following:
	QRect TagRect, ValueRect, TotalTagRect, TotalValueRect, UnitsTagRect, AlarmMarkerRect, BarRect, ScaleRect;
	QRect MaxTagRect, MaxValueRect, MinTagRect, MinValueRect;
	int scalefontheight = 9; // for most of the scales here
	BOOL AntiAliasedTag = FALSE;
	int alarmmarkerheight = 10; // for most
	BOOL IsMplus = FALSE;
	// transparency flags for some of the objects. (trasparency+doublebuffered)
	BOOL TransScale = FALSE;
	BOOL TransAlarms = TRUE; // make all alrarm markers transparent (when stacking they don't draw properly otherwise)
	// double buffered flags for overlapping objects.
	BOOL DBuffValue = FALSE;
	BOOL DBuffBar = TRUE;  // double buffered flag for bar.
	QRect bounds = pWgt->GetWidgetBounds();
	int Wwidth = _Width(bounds);
	int Wheight = _Height(bounds);
	int diffX = 0;
	int diffY = 0;
	//
	// Stability Project Fix:
	//
	//If Wwidth of V bar is less than Minimum width i.e. 53, creation of V-Bar fails and message is displayed under diagnostic message
	//So set it's value to 53
	if (Wwidth < 53) {
		Wwidth = 53;
	}
	if ((Wwidth >= 400) && (Wheight >= 552)) {
		// 400x552 MPlus
		diffX = Wwidth - 400;
		diffY = Wheight - 552;
		AntiAliasedTag = TRUE;  // for the large font
		scalefontheight = 14;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		alarmmarkerheight = 18;
		SetRect(&TagRect, 9, 4, 265, 27);
		SetRect(&ValueRect, 9, 477, 194, 507);
		SetRect(&UnitsTagRect, 195, 477, 399, 507);
		SetRect(&ScaleRect, 176, 27, 285, 473);
		SetRect(&AlarmMarkerRect, 223, 19, 393, 481);
		SetRect(&BarRect, 9, 36, 173, 465);
		SetRect(&TotalTagRect, 8, 528, 68, 546);
		SetRect(&TotalValueRect, 72, 529, 245, 545);
		SetRect(&MaxTagRect, 9, 508, 42, 526);
		SetRect(&MaxValueRect, 43, 509, 191, 525);
		SetRect(&MinTagRect, 196, 508, 229, 526);
		SetRect(&MinValueRect, 230, 509, 378, 525);
	} else if ((Wwidth >= 266) && (Wheight >= 552)) {
		// 266x552 MPlus
		diffX = Wwidth - 266;
		diffY = Wheight - 552;
		AntiAliasedTag = TRUE;  // for the large font
		scalefontheight = 13;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		alarmmarkerheight = 18;
		SetRect(&TagRect, 9, 3, 265, 26);
		SetRect(&ValueRect, 9, 465, 172, 493);
		SetRect(&UnitsTagRect, 9, 493, 265, 517);
		SetRect(&ScaleRect, 123, 28, 228, 458);
		SetRect(&AlarmMarkerRect, 162, 18, 258, 468);
		SetRect(&BarRect, 9, 35, 120, 452);
		SetRect(&TotalTagRect, 9, 532, 61, 546);
		SetRect(&TotalValueRect, 63, 534, 174, 544);
		SetRect(&MaxTagRect, 9, 517, 33, 531);
		SetRect(&MaxValueRect, 34, 519, 114, 529);
		SetRect(&MinTagRect, 116, 517, 140, 531);
		SetRect(&MinValueRect, 141, 519, 221, 529);
	} else if ((Wwidth >= 200) && (Wheight >= 552)) {
		// 200x552 MPlus
		diffX = Wwidth - 200;
		diffY = Wheight - 552;
		scalefontheight = 11;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		alarmmarkerheight = 16;
		SetRect(&TagRect, 9, 3, 199, 19);
		SetRect(&ValueRect, 9, 470, 163, 493);
		SetRect(&UnitsTagRect, 9, 493, 199, 511);
		SetRect(&ScaleRect, 76, 21, 199, 466);
		SetRect(&AlarmMarkerRect, 111, 14, 195, 473);
		SetRect(&BarRect, 9, 28, 74, 460);
		SetRect(&TotalTagRect, 9, 535, 45, 546);
		SetRect(&TotalValueRect, 46, 536, 157, 545);
		SetRect(&MaxTagRect, 9, 511, 33, 522);
		SetRect(&MaxValueRect, 35, 512, 115, 521);
		SetRect(&MinTagRect, 9, 523, 33, 534);
		SetRect(&MinValueRect, 35, 524, 115, 533);
	} else if ((Wwidth >= 160) && (Wheight >= 552)) {
		// 160x552 MPlus
		diffX = Wwidth - 160;
		diffY = Wheight - 552;
		scalefontheight = 11;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		alarmmarkerheight = 14;
		SetRect(&TagRect, 9, 3, 159, 19);
		SetRect(&ValueRect, 11, 469, 159, 492);
		SetRect(&UnitsTagRect, 11, 493, 159, 511);
		SetRect(&ScaleRect, 67, 21, 159, 467);
		SetRect(&AlarmMarkerRect, 100, 15, 159, 473);
		SetRect(&BarRect, 9, 28, 66, 461);
		SetRect(&TotalTagRect, 12, 536, 48, 547);
		SetRect(&TotalValueRect, 48, 537, 159, 546);
		SetRect(&MaxTagRect, 12, 511, 36, 522);
		SetRect(&MaxValueRect, 37, 513, 117, 522);
		SetRect(&MinTagRect, 12, 524, 36, 535);
		SetRect(&MinValueRect, 37, 525, 117, 534);
	} else if ((Wwidth >= 133) && (Wheight >= 552)) {
		// 133x552 MPlus
		diffX = Wwidth - 133;
		diffY = Wheight - 552;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		SetRect(&TagRect, 5, 3, 132, 20);
		SetRect(&ValueRect, 7, 476, 122, 491);
		SetRect(&UnitsTagRect, 7, 491, 132, 505);
		SetRect(&ScaleRect, 61, 25, 132, 474);
		SetRect(&AlarmMarkerRect, 90, 21, 132, 478);
		SetRect(&BarRect, 6, 30, 60, 470);
		SetRect(&TotalTagRect, 7, 528, 53, 540);
		SetRect(&TotalValueRect, 7, 540, 109, 550);
		SetRect(&MaxTagRect, 7, 505, 31, 516);
		SetRect(&MaxValueRect, 32, 506, 102, 515);
		SetRect(&MinTagRect, 7, 517, 31, 528);
		SetRect(&MinValueRect, 32, 518, 102, 527);
	} else if ((Wwidth >= 114) && (Wheight >= 552)) {
		// 114x552 MPlus
		diffX = Wwidth - 114;
		diffY = Wheight - 552;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		SetRect(&TagRect, 7, 3, 113, 20);
		SetRect(&ValueRect, 4, 473, 113, 487);
		SetRect(&UnitsTagRect, 5, 488, 109, 501);
		SetRect(&ScaleRect, 53, 23, 113, 471);
		SetRect(&AlarmMarkerRect, 79, 19, 109, 475);
		SetRect(&BarRect, 7, 28, 52, 467);
		SetRect(&TotalTagRect, 5, 527, 46, 538);
		SetRect(&TotalValueRect, 5, 538, 82, 547);
		SetRect(&MaxTagRect, 5, 502, 29, 513);
		SetRect(&MaxValueRect, 30, 503, 100, 512);
		SetRect(&MinTagRect, 5, 515, 29, 526);
		SetRect(&MinValueRect, 30, 515, 100, 524);
	} else if ((Wwidth >= 100) && (Wheight >= 552)) {
		// 100x552 MPlus
		diffX = Wwidth - 100;
		diffY = Wheight - 552;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		SetRect(&TagRect, 5, 3, 99, 20);
		SetRect(&ValueRect, 4, 473, 99, 487);
		SetRect(&UnitsTagRect, 4, 488, 99, 501);
		SetRect(&ScaleRect, 37, 23, 99, 471);
		SetRect(&AlarmMarkerRect, 65, 19, 96, 475);
		SetRect(&BarRect, 5, 28, 36, 467);
		SetRect(&TotalTagRect, 4, 527, 45, 538);
		SetRect(&TotalValueRect, 3, 538, 73, 547);
		SetRect(&MaxTagRect, 4, 502, 29, 513);
		SetRect(&MaxValueRect, 29, 503, 99, 512);
		SetRect(&MinTagRect, 4, 515, 28, 526);
		SetRect(&MinValueRect, 29, 516, 99, 525);
	} else if ((Wwidth >= 200) && (Wheight >= 276)) {
		// 200x276 MPlus
		diffX = Wwidth - 200;
		diffY = Wheight - 276;
		scalefontheight = 11;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		alarmmarkerheight = 16;
		SetRect(&TagRect, 9, 3, 199, 19);
		SetRect(&ValueRect, 9, 195, 163, 218);
		SetRect(&UnitsTagRect, 9, 218, 199, 236);
		SetRect(&ScaleRect, 76, 21, 168, 194);
		SetRect(&AlarmMarkerRect, 111, 14, 199, 201);
		SetRect(&BarRect, 9, 28, 74, 188);
		SetRect(&TotalTagRect, 9, 260, 45, 271);
		SetRect(&TotalValueRect, 47, 261, 158, 270);
		SetRect(&MaxTagRect, 9, 236, 33, 247);
		SetRect(&MaxValueRect, 35, 237, 115, 246);
		SetRect(&MinTagRect, 9, 248, 33, 259);
		SetRect(&MinValueRect, 35, 249, 115, 258);
	} else if ((Wwidth >= 160) && (Wheight >= 276)) {
		// 160x276 MPlus
		diffX = Wwidth - 160;
		diffY = Wheight - 276;
		scalefontheight = 11;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		alarmmarkerheight = 14;
		SetRect(&TagRect, 9, 3, 159, 19);
		SetRect(&ValueRect, 9, 194, 157, 217);
		SetRect(&UnitsTagRect, 9, 218, 157, 236);
		SetRect(&ScaleRect, 67, 21, 159, 190);
		SetRect(&AlarmMarkerRect, 100, 15, 154, 196);
		SetRect(&BarRect, 9, 28, 66, 184);
		SetRect(&TotalTagRect, 9, 260, 45, 271);
		SetRect(&TotalValueRect, 46, 261, 157, 270);
		SetRect(&MaxTagRect, 9, 236, 33, 247);
		SetRect(&MaxValueRect, 34, 237, 114, 246);
		SetRect(&MinTagRect, 9, 248, 33, 259);
		SetRect(&MinValueRect, 34, 249, 114, 258);
	} else if ((Wwidth >= 133) && (Wheight >= 276)) {
		// 133x276 MPlus
		diffX = Wwidth - 133;
		diffY = Wheight - 276;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		SetRect(&TagRect, 5, 3, 132, 20);
		SetRect(&ValueRect, 7, 199, 122, 214);
		SetRect(&UnitsTagRect, 7, 214, 132, 228);
		SetRect(&ScaleRect, 61, 25, 132, 198);
		SetRect(&AlarmMarkerRect, 89, 21, 125, 202);
		SetRect(&BarRect, 6, 30, 60, 194);
		SetRect(&TotalTagRect, 7, 251, 53, 263);
		SetRect(&TotalValueRect, 7, 263, 109, 273);
		SetRect(&MaxTagRect, 7, 228, 31, 239);
		SetRect(&MaxValueRect, 32, 229, 102, 238);
		SetRect(&MinTagRect, 7, 240, 31, 251);
		SetRect(&MinValueRect, 32, 240, 102, 249);
	} else if ((Wwidth >= 114) && (Wheight >= 276)) {
		// 114x276 MPlus
		diffX = Wwidth - 114;
		diffY = Wheight - 276;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		SetRect(&TagRect, 7, 3, 113, 20);
		SetRect(&ValueRect, 5, 198, 113, 212);
		SetRect(&UnitsTagRect, 5, 212, 113, 225);
		SetRect(&ScaleRect, 53, 23, 113, 195);
		SetRect(&AlarmMarkerRect, 79, 19, 109, 199);
		SetRect(&BarRect, 7, 28, 52, 191);
		SetRect(&TotalTagRect, 5, 251, 46, 262);
		SetRect(&TotalValueRect, 5, 262, 82, 271);
		SetRect(&MaxTagRect, 5, 226, 29, 237);
		SetRect(&MaxValueRect, 30, 227, 100, 236);
		SetRect(&MinTagRect, 5, 239, 29, 250);
		SetRect(&MinValueRect, 30, 239, 100, 248);
	} else if ((Wwidth >= 100) && (Wheight >= 276)) {
		// 100x276 MPlus
		diffX = Wwidth - 100;
		diffY = Wheight - 276;
		TransScale = TRUE;	// scale and alarm markers overlapped. 
		IsMplus = TRUE;
		SetRect(&TagRect, 5, 3, 99, 20);
		SetRect(&ValueRect, 4, 197, 99, 211);
		SetRect(&UnitsTagRect, 4, 212, 99, 224);
		SetRect(&ScaleRect, 39, 23, 99, 195);
		SetRect(&AlarmMarkerRect, 66, 19, 96, 199);
		SetRect(&BarRect, 5, 28, 38, 191);
		SetRect(&TotalTagRect, 4, 251, 45, 262);
		SetRect(&TotalValueRect, 5, 262, 75, 271);
		SetRect(&MaxTagRect, 4, 226, 28, 237);
		SetRect(&MaxValueRect, 29, 227, 99, 236);
		SetRect(&MinTagRect, 4, 239, 28, 250);
		SetRect(&MinValueRect, 29, 240, 99, 249);
	} else
///////////////////////////////////////////////////// MINITREND from here ////////////////////////////////////
	if ((Wwidth >= 160) && (Wheight >= 208)) {
		// 160x208
		diffX = Wwidth - 160;
		diffY = Wheight - 208;
		AntiAliasedTag = TRUE;  // for the large font
		SetRect(&TagRect, 2, 1, 137, 22);
		SetRect(&ValueRect, 1, 160, 139, 185);
		SetRect(&UnitsTagRect, 103, 186, 159, 200);
		SetRect(&ScaleRect, 87, 22, 137, 159);
		SetRect(&AlarmMarkerRect, 137, 18, 159, 163);
		SetRect(&BarRect, 2, 27, 86, 155);
		SetRect(&TotalTagRect, 2, 186, 72, 197);
		SetRect(&TotalValueRect, 2, 197, 72, 206);
	} else if ((Wwidth >= 106) && (Wheight >= 208)) {
		// 106x208
		diffX = Wwidth - 106;
		diffY = Wheight - 208;
		SetRect(&TagRect, 2, 1, 83, 16);
		SetRect(&ValueRect, 5, 167, 105, 185);
		SetRect(&UnitsTagRect, 69, 186, 105, 197);
		SetRect(&ScaleRect, 33, 17, 83, 164);
		SetRect(&AlarmMarkerRect, 83, 13, 105, 168);
		SetRect(&BarRect, 2, 22, 32, 160);
		SetRect(&TotalTagRect, 2, 186, 65, 197);
		SetRect(&TotalValueRect, 2, 197, 72, 206);
	} else if ((Wwidth >= 80) && (Wheight >= 208)) {
		// 80x208
		diffX = Wwidth - 80;
		diffY = Wheight - 208;
		// scale and alarm markers overlapped. 
		// (as a minimum need to be double buffered. make transparent for ease)
		TransScale = TRUE;	// transparent 
		SetRect(&TagRect, 2, 1, 79, 14);
		SetRect(&ValueRect, 2, 171, 79, 185);
		SetRect(&UnitsTagRect, 43, 186, 79, 197);
		SetRect(&ScaleRect, 29, 18, 79, 167);
		SetRect(&AlarmMarkerRect, 57, 14, 79, 171);
		SetRect(&BarRect, 2, 23, 28, 163);
		SetRect(&TotalTagRect, 2, 186, 43, 197);
		SetRect(&TotalValueRect, 2, 197, 72, 206);
	} else if ((Wwidth >= 64) && (Wheight >= 208)) {
		// 64x208
		diffX = Wwidth - 64;
		diffY = Wheight - 208;
		// scale and alarm markers and bar overlapped. 
		TransScale = TRUE;	// transparent 
		DBuffBar = TRUE;
		SetRect(&TagRect, 2, 1, 63, 12);
		SetRect(&ValueRect, 1, 183, 63, 195);
		SetRect(&UnitsTagRect, 27, 196, 63, 207);
		SetRect(&ScaleRect, 2, 16, 52, 179);
		SetRect(&AlarmMarkerRect, 41, 12, 63, 183);
		SetRect(&BarRect, 3, 21, 62, 175);
		// NO TOTAL
		HasTotal = FALSE;
	} else if ((Wwidth >= 53) && (Wheight >= 208)) {
		// 53x208
		diffX = Wwidth - 53;
		diffY = Wheight - 208;
		// scale and alarm markers and bar overlapped. 
		TransScale = TRUE;	// transparent 
		DBuffBar = TRUE;
		SetRect(&TagRect, 2, 1, 52, 12);
		SetRect(&ValueRect, 6, 186, 52, 195);
		SetRect(&UnitsTagRect, 16, 196, 52, 207);
		SetRect(&ScaleRect, 2, 16, 52, 182);
		SetRect(&AlarmMarkerRect, 30, 12, 52, 186);
		SetRect(&BarRect, 3, 21, 51, 178);
		// NO TOTAL
		HasTotal = FALSE;
	} else if ((Wwidth >= 80) && (Wheight >= 104)) {
		// 80x104
		diffX = Wwidth - 80;
		diffY = Wheight - 104;
		scalefontheight = 7; // smaller font for this one.
		TransScale = TRUE;	// transparent 
		DBuffValue = TRUE;  // objects overlap slightly
		SetRect(&TagRect, 2, 1, 57, 12);
		SetRect(&ValueRect, 2, 78, 79, 92);
		SetRect(&UnitsTagRect, 43, 92, 79, 103);
		SetRect(&ScaleRect, 29, 12, 78, 78);
		SetRect(&AlarmMarkerRect, 57, 7, 79, 83);
		SetRect(&BarRect, 2, 16, 28, 75);
		// NO TOTAL
		HasTotal = FALSE;
	} else {
		bRetVal = false;
	}
	// create the Objects if okay so far
	if (bRetVal) {
		bool bFoundObjectError = false;
		// Textobject - Pen Tag	
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &TagRect)) {
			MatchColour(pWgt);
			if (AntiAliasedTag)
				((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Font.Quality = 1; //antialiased
		} else {
			bFoundObjectError = true;
		}
		// Digitalobject - Main value
		if (!bFoundObjectError
				&& m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &ValueRect)) {
			MatchColour(pWgt);
			if (DBuffValue || _Height(ValueRect) > 14)
				pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = 1; // double buffer larger digitals (and special case)
		} else {
			bFoundObjectError = true;
		}
		// Textobject - Units Tag	
		if (!bFoundObjectError
				&& m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &UnitsTagRect)) {
			MatchColour(pWgt);
			((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->IsUnits = 1;
			((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->IsTag = 0;
		} else {
			bFoundObjectError = true;
		}
		if (HasTotal && !bFoundObjectError) {
			// Textobject - Total Tag
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &TotalTagRect)) {
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->ItemType = DI_TOTAL;
				pchref->SubType = DI_TOTAL_READING;
				// Digitalobject - Total value
				if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &TotalValueRect)) {
					MatchColour(pWgt);
					pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
					pchref->ItemType = DI_TOTAL;
					pchref->SubType = DI_TOTAL_READING;
				} else {
					bFoundObjectError = true;
				}
			} else {
				bFoundObjectError = true;
			}
		}
		if (HasMaxMin && !bFoundObjectError) {
			if (IsMplus)	// for vertical bars, only the MPlus recorder has maxmin values.
			{
				// Textobject - Max Tag
				if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &MaxTagRect)) {
					MatchColour(pWgt);
					pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
					pchref->ItemType = DI_MMA;
					pchref->SubType = DI_MMA_MAX_USER;
					// Digitalobject - Max value
					if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &MaxValueRect)) {
						MatchColour(pWgt);
						pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
						pchref->ItemType = DI_MMA;
						pchref->SubType = DI_MMA_MAX_USER;
						// Textobject - Min Tag
						if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &MinTagRect)) {
							MatchColour(pWgt);
							pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
							pchref->ItemType = DI_MMA;
							pchref->SubType = DI_MMA_MIN_USER;
							// Digitalobject - Min value
							if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT,
									&MinValueRect)) {
								MatchColour(pWgt);
								pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
								pchref->ItemType = DI_MMA;
								pchref->SubType = DI_MMA_MIN_USER;
							} else {
								bFoundObjectError = true;
							}
						} else {
							bFoundObjectError = true;
						}
					} else {
						bFoundObjectError = true;
					}
				} else {
					bFoundObjectError = true;
				}
			}
		}
		CBarObject *pBarObj = NULL;
		// ORDER of these 3 important - must add Bar, alarm mks and scale (scale on top.)
		// Barobject - the bar
		if (!bFoundObjectError && m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BAROBJECT, &BarRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = DBuffBar;
			pWgt->m_pSelectedObject->m_pCMMbase->FixBackColour = TRUE;
#ifdef UNDER_CE
			pWgt->m_pSelectedObject->m_pCMMbase->BackColour=QString (239,239,239);
		#else
			pWgt->m_pSelectedObject->m_pCMMbase->BackColour = QString(245, 245, 245);
#endif
			if (!DBuffBar) {
				pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderUsed = TRUE;
				pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderWidth = 1;
			}
			if (HasMaxMin) // show max and min markers on bar
			{
				((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ShowMaxMrkr = TRUE;
				((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ShowMinMrkr = TRUE;
			}
			pBarObj = (CBarObject*) pWgt->m_pSelectedObject;
		} else {
			bFoundObjectError = true;
		}
		CAlarmMarkerObject *pAlmmkrObj = NULL;
		// Alarm marker object - the alarm markers
		if (!bFoundObjectError
				&& m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_ALARMMRKROBJECT, &AlarmMarkerRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TransAlarms;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TransAlarms;
			((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Height = alarmmarkerheight;
			pAlmmkrObj = (CAlarmMarkerObject*) pWgt->m_pSelectedObject;
		} else {
			bFoundObjectError = true;
		}
		// Scaleobject - the scale
		if (!bFoundObjectError && m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_SCALEOBJECT, &ScaleRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TransScale;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TransScale;
			if (IsMplus) {
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorLength = 6; // longer for mplus
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MinorLength = 4;
			} else {
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorLength = 4;
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MinorLength = 2;
			}
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixBaselineClr = TRUE; // black
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixGradsColour = TRUE; // black
			pWgt->m_pSelectedObject->m_pCMMbase->FixForeColour = TRUE; // black
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->LimitFont.Height = scalefontheight;
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorFont.Height = scalefontheight;
			CScaleObject *pScaleObj = (CScaleObject*) pWgt->m_pSelectedObject;
			// link the objects together.
			assert(pAlmmkrObj);
			pScaleObj->LinkTo(pAlmmkrObj, TRUE);
			assert(pBarObj);
			pScaleObj->LinkTo(pBarObj, TRUE);
			SetScreenInstance(pWgt->m_pCMMwidget->ChannelList[0], PenIndex);
			if (diffX)
				diffX /= 2;
			if (diffY)
				diffY /= 2;
			// move objects into middle of widget.
			if ((diffX) || (diffY)) {
				CBaseObject *pObj = pWgt->m_pObjects;
				while (pObj) {
					QRect objBounds = pObj->GetBounds();
					OffsetRect(&objBounds, diffX, diffY);
					pObj->SetBounds(&objBounds);
					pObj = pObj->m_pNextObj;
				}
			}
		} else {
			bFoundObjectError = true;
		}
		bRetVal = !bFoundObjectError;
	}
	return (bRetVal == true);
}
/*
 // CHART 
 QRect temprect;
 //SetRect(&temprect,1,32,99,151);
 SetRect(&temprect,1,1,99,207);
 m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig,BLK_CHARTOBJECT,&temprect);
 
 CChartObject *pchartObj=(CChartObject*)pWgt->m_pSelectedObject;

 // examplebar 
 //SetRect(&temprect,106,38,130,145);
 SetRect(&temprect,106,2,130,206);
 m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig,BLK_EXAMPLEBAR,&temprect);
 MatchColour( pWgt );
 pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered=TransScale;
 pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent=TransScale;
 
 CExampleBar *pexbarObj=(CExampleBar*)pWgt->m_pSelectedObject;
 
 pchartObj->LinkTo(pexbarObj);	

 // now try and extend the bar to it's maximum
 barRect=pexbarObj->GetBounds();
 barRect.top--;
 barRect.bottom++;
 pexbarObj->SetLinkLimits(*(int*)&barRect.top, *(int*)&barRect.bottom);

 */
//****************************************************************************
///
///	Divide up the full area into totalrect rectangles and return rect n.
/// This function works for Horizontal bar shaped rectangles
///
/// @param[in] RectIndex	- index of rectangle to return (0 based)
/// @param[in] TotalRects	- Total number of rectangles to provide for
/// @param[in] HasTotal		- Area to dive up into rectangles
///
/// @return	QRect structure defining rectangle requested
/// 
//****************************************************************************
QRect CScreen::SplitRectBarsH(int RectIndex, int TotalRects, QRect FullArea) {
	int numcols = 1; // default for mini + multi. 
	if (_Width(FullArea) == ARISTOS_MINI_QX_X || _Width(FullArea) == ARISTOS_MINI_EZ_X) {
		if (TotalRects > 6) // more cols (mini)
			numcols = 2;
	} else {
		if (TotalRects > 8) // more cols (multi)
			numcols = 2;
	}
	int numrows = TotalRects / numcols;
	int numOddRects = TotalRects % numcols; // number of odd rectangles on top row before main rows start.
	if (numOddRects)
		numrows++;
	int height = _Height(FullArea) / numrows;
	int width = _Width(FullArea) / numcols;
	int Xoffset;
	int Yoffset;
	if (RectIndex < numOddRects) {
		width = _Width(FullArea) / numOddRects;
		Xoffset = RectIndex;
		Yoffset = 0;
	} else {
		Xoffset = (RectIndex - numOddRects) % numcols;
		Yoffset = (RectIndex - numOddRects) / numcols;
		if (numOddRects)
			Yoffset++; // allow for the first row.
	}
	QRect result;
	result.setleft(FullArea).left + (Xoffset * width);
	result.setright(result).left + width;
	result.setTop(FullArea).top + (Yoffset * height);
	result.setBottom(result).top + height;
	// if nearly at the edge, make up to the edge
	if (result.right >= FullArea.right - 10)
		result.setright(FullArea).right;
	if (result.bottom >= FullArea.bottom - 10)
		result.setBottom(FullArea).bottom;
	return result;
}
//****************************************************************************
///
///	Fill the widget with the largest Horizontal Bar that will fit.
///
/// @param[in] PenIndex		- zero based pen index (0=pen1)
/// @param[in] HasMaxMin	- Include maxmin markers on bars
/// @param[in] HasTotal		- Include total where possible
///
/// @return	T/F - indicating success of adding
/// 
//****************************************************************************
BOOL CScreen::AddBarHContents(int PenIndex, BOOL HasMaxMin, BOOL HasTotal) {
	USHORT numchans;
	T_PCHANNELREF pchref = NULL;
	// local pointers for clarity
	CWidget *pWgt = m_pSelectedWidget;
	bool bRetVal = true;
	// Horizontal Bar has the following:
	QRect TagRect, ValueRect, TotalTagRect, TotalValueRect, UnitsTagRect, AlarmMarkerRect, BarRect, ScaleRect;
	QRect MaxTagRect, MaxValueRect, MinTagRect, MinValueRect;
	int scalefontheight = 9; // for most of the scales here
	int alarmmarkerheight = 10; // for most
	BOOL AntiAliasedTag = FALSE;
	// transparency flags for some of the objects. (trasparency+doublebuffered)
	BOOL TransScale = FALSE;
	BOOL TransAlarms = TRUE; // make all alrarm markers transparent (when stacking they don't draw properly otherwise)
	// double buffered flags for overlapping objects.
	BOOL DBuffBar = TRUE;  // double buffered flag for bar.
	BOOL ResetBar = FALSE; // flag for later multiplus sized widgets in which the bar has been correctly sized and requires adjusting after linking.
	BOOL HasMaxMinValues = HasMaxMin;
	QRect bounds = pWgt->GetWidgetBounds();
	int Wwidth = _Width(bounds);
	int Wheight = _Height(bounds);
	int diffX = 0;
	int diffY = 0;
	if ((Wwidth >= 800) && (Wheight >= 276)) {
		// 800x276 - MPLUS 
		diffX = Wwidth - 800;
		diffY = Wheight - 276;
		AntiAliasedTag = TRUE; // for the large font
		scalefontheight = 14; // mega scale!
		alarmmarkerheight = 20; // bigger alarm markers
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 215, 30);
		SetRect(&TotalTagRect, 221, 4, 300, 28);
		SetRect(&TotalValueRect, 307, 6, 437, 26);
		SetRect(&MaxTagRect, 447, 5, 485, 29);
		SetRect(&MaxValueRect, 486, 6, 617, 26);
		SetRect(&MinTagRect, 623, 5, 661, 29);
		SetRect(&MinValueRect, 662, 6, 793, 26);
		SetRect(&ScaleRect, 1, 54, 631, 83);
		SetRect(&BarRect, 5, 86, 606, 174);
		SetRect(&AlarmMarkerRect, 1, 174, 623, 275);
		SetRect(&ValueRect, 610, 96, 799, 130);
		SetRect(&UnitsTagRect, 610, 134, 799, 174);
	} else if ((Wwidth >= 800) && (Wheight >= 138)) {
		// 800x138 - MPLUS 
		diffX = Wwidth - 800;
		diffY = Wheight - 138;
		AntiAliasedTag = TRUE;  // for the large font
		scalefontheight = 12;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 257, 24);
		SetRect(&TotalTagRect, 287, 5, 356, 24);
		SetRect(&TotalValueRect, 361, 6, 453, 22);
		SetRect(&MaxTagRect, 523, 5, 557, 24);
		SetRect(&MaxValueRect, 558, 6, 650, 22);
		SetRect(&MinTagRect, 665, 5, 699, 24);
		SetRect(&MinValueRect, 700, 6, 792, 22);
		SetRect(&ScaleRect, 1, 28, 642, 47);
		SetRect(&BarRect, 4, 49, 621, 89);
		SetRect(&AlarmMarkerRect, 1, 91, 628, 137);
		SetRect(&ValueRect, 627, 49, 799, 79);
		SetRect(&UnitsTagRect, 628, 82, 799, 116);
	} else if ((Wwidth >= 800) && (Wheight >= 110)) {
		// 800x110 - MPLUS 
		diffX = Wwidth - 800;
		diffY = Wheight - 110;
		AntiAliasedTag = TRUE;  // for the large font
		scalefontheight = 12;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 267, 23);
		SetRect(&TotalTagRect, 282, 5, 366, 24);
		SetRect(&TotalValueRect, 367, 6, 459, 22);
		SetRect(&MaxTagRect, 523, 5, 557, 24);
		SetRect(&MaxValueRect, 558, 6, 650, 22);
		SetRect(&MinTagRect, 665, 5, 699, 24);
		SetRect(&MinValueRect, 701, 6, 793, 22);
		SetRect(&ScaleRect, 1, 29, 651, 47);
		SetRect(&BarRect, 4, 49, 631, 87);
		SetRect(&AlarmMarkerRect, 1, 86, 638, 109);
		SetRect(&ValueRect, 636, 49, 799, 78);
		SetRect(&UnitsTagRect, 638, 79, 796, 106);
	} else if ((Wwidth >= 800) && (Wheight >= 92)) {
		// 800x92 - MPLUS 
		diffX = Wwidth - 800;
		diffY = Wheight - 92;
		AntiAliasedTag = TRUE;  // for the large font
		scalefontheight = 10;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 221, 23);
		SetRect(&TotalTagRect, 288, 5, 372, 24);
		SetRect(&TotalValueRect, 373, 6, 488, 22);
		SetRect(&MaxTagRect, 526, 5, 560, 24);
		SetRect(&MaxValueRect, 561, 6, 653, 22);
		SetRect(&MinTagRect, 668, 5, 702, 24);
		SetRect(&MinValueRect, 703, 6, 795, 22);
		SetRect(&ScaleRect, 1, 31, 632, 48);
		SetRect(&BarRect, 4, 50, 615, 89);
		SetRect(&AlarmMarkerRect, 1, 53, 622, 91);
		SetRect(&ValueRect, 636, 36, 799, 65);
		SetRect(&UnitsTagRect, 638, 64, 799, 91);
	} else if ((Wwidth >= 800) && (Wheight >= 78)) {
		// 800x78 - MPLUS 
		diffX = Wwidth - 800;
		diffY = Wheight - 78;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 163, 17);
		SetRect(&TotalTagRect, 306, 3, 355, 17);
		SetRect(&TotalValueRect, 355, 5, 445, 16);
		SetRect(&MaxTagRect, 575, 3, 599, 17);
		SetRect(&MaxValueRect, 600, 5, 667, 16);
		SetRect(&MinTagRect, 702, 4, 726, 18);
		SetRect(&MinValueRect, 727, 5, 794, 16);
		SetRect(&ScaleRect, 1, 24, 632, 40);
		SetRect(&BarRect, 4, 42, 617, 75);
		SetRect(&AlarmMarkerRect, 1, 42, 624, 77);
		SetRect(&ValueRect, 636, 22, 799, 51);
		SetRect(&UnitsTagRect, 636, 50, 799, 77);
	} else if ((Wwidth >= 800) && (Wheight >= 69)) {
		// 800x69 - MPLUS 
		diffX = Wwidth - 800;
		diffY = Wheight - 69;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 170, 17);
		SetRect(&TotalTagRect, 306, 3, 355, 17);
		SetRect(&TotalValueRect, 355, 4, 450, 15);
		SetRect(&MaxTagRect, 576, 3, 600, 17);
		SetRect(&MaxValueRect, 601, 5, 668, 16);
		SetRect(&MinTagRect, 703, 4, 727, 18);
		SetRect(&MinValueRect, 728, 6, 795, 17);
		SetRect(&ScaleRect, 1, 22, 663, 37);
		SetRect(&BarRect, 4, 39, 648, 66);
		SetRect(&AlarmMarkerRect, 1, 38, 655, 68);
		SetRect(&ValueRect, 668, 25, 799, 48);
		SetRect(&UnitsTagRect, 671, 48, 799, 68);
	} else if ((Wwidth >= 400) && (Wheight >= 110)) {
		// 400x110 - MPLUS 
		diffX = Wwidth - 400;
		diffY = Wheight - 110;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 98, 17);
		SetRect(&TotalTagRect, 98, 3, 143, 17);
		SetRect(&TotalValueRect, 145, 4, 212, 15);
		SetRect(&MaxTagRect, 213, 3, 237, 17);
		SetRect(&MaxValueRect, 238, 4, 305, 15);
		SetRect(&MinTagRect, 306, 3, 330, 17);
		SetRect(&MinValueRect, 331, 4, 398, 15);
		SetRect(&ScaleRect, 1, 29, 280, 46);
		SetRect(&BarRect, 4, 48, 265, 86);
		SetRect(&AlarmMarkerRect, 1, 86, 272, 109);
		SetRect(&ValueRect, 268, 49, 399, 72);
		SetRect(&UnitsTagRect, 271, 73, 399, 97);
	} else if ((Wwidth >= 400) && (Wheight >= 92)) {
		// 400x92 - MPLUS 
		diffX = Wwidth - 400;
		diffY = Wheight - 92;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 99, 18);
		SetRect(&TotalTagRect, 99, 5, 146, 19);
		SetRect(&TotalValueRect, 146, 7, 213, 18);
		SetRect(&MaxTagRect, 214, 5, 238, 19);
		SetRect(&MaxValueRect, 239, 7, 306, 18);
		SetRect(&MinTagRect, 307, 5, 331, 19);
		SetRect(&MinValueRect, 332, 7, 399, 18);
		SetRect(&ScaleRect, 1, 32, 264, 49);
		SetRect(&BarRect, 4, 51, 249, 89);
		SetRect(&AlarmMarkerRect, 1, 53, 256, 91);
		SetRect(&ValueRect, 268, 40, 399, 63);
		SetRect(&UnitsTagRect, 268, 65, 399, 91);
	} else if ((Wwidth >= 400) && (Wheight >= 78)) {
		// 400x78 - MPLUS 
		diffX = Wwidth - 400;
		diffY = Wheight - 78;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 96, 17);
		SetRect(&TotalTagRect, 96, 3, 145, 17);
		SetRect(&TotalValueRect, 145, 4, 212, 15);
		SetRect(&MaxTagRect, 214, 3, 238, 17);
		SetRect(&MaxValueRect, 238, 4, 305, 15);
		SetRect(&MinTagRect, 307, 3, 331, 17);
		SetRect(&MinValueRect, 332, 4, 399, 15);
		SetRect(&ScaleRect, 1, 22, 264, 39);
		SetRect(&BarRect, 4, 41, 249, 75);
		SetRect(&AlarmMarkerRect, 1, 42, 256, 77);
		SetRect(&ValueRect, 268, 29, 399, 52);
		SetRect(&UnitsTagRect, 268, 53, 399, 77);
	} else if ((Wwidth >= 400) && (Wheight >= 69)) {
		// 400x69 - MPLUS 
		diffX = Wwidth - 400;
		diffY = Wheight - 69;
		ResetBar = TRUE;
		SetRect(&TagRect, 3, 1, 96, 17);
		SetRect(&TotalTagRect, 96, 3, 145, 17);
		SetRect(&TotalValueRect, 146, 4, 213, 15);
		SetRect(&MaxTagRect, 214, 3, 238, 17);
		SetRect(&MaxValueRect, 239, 4, 306, 15);
		SetRect(&MinTagRect, 307, 3, 331, 17);
		SetRect(&MinValueRect, 332, 4, 399, 15);
		SetRect(&ScaleRect, 1, 22, 264, 37);
		SetRect(&BarRect, 4, 39, 249, 66);
		SetRect(&AlarmMarkerRect, 1, 39, 256, 68);
		SetRect(&ValueRect, 268, 24, 399, 47);
		SetRect(&UnitsTagRect, 268, 48, 399, 68);
	}
	/////////////////////////////////////////// MINITREND BELOW ///////////////////////////////////////
	else if ((Wwidth >= 320) && (Wheight >= 104)) {
		// 320x104
		diffX = Wwidth - 320;
		diffY = Wheight - 104;
		AntiAliasedTag = TRUE;  // for the large font
		SetRect(&TagRect, 2, 1, 215, 22);
		SetRect(&ValueRect, 219, 54, 319, 72);
		SetRect(&UnitsTagRect, 263, 73, 319, 87);
		SetRect(&ScaleRect, 1, 27, 218, 43);
		SetRect(&AlarmMarkerRect, 1, 80, 210, 102);
		SetRect(&BarRect, 10, 44, 202, 79);
		SetRect(&TotalTagRect, 220, 2, 269, 13);
		SetRect(&TotalValueRect, 221, 14, 291, 23);
		SetRect(&MaxTagRect, 220, 33, 244, 44);
		SetRect(&MaxValueRect, 245, 34, 291, 43);
		SetRect(&MinTagRect, 220, 88, 244, 99);
		SetRect(&MinValueRect, 245, 89, 291, 98);
	} else if ((Wwidth >= 320) && (Wheight >= 69)) {
		// 320x69
		diffX = Wwidth - 320;
		diffY = Wheight - 69;
		SetRect(&TagRect, 2, 1, 111, 13);
		SetRect(&ValueRect, 219, 20, 319, 38);
		SetRect(&UnitsTagRect, 263, 39, 319, 53);
		SetRect(&ScaleRect, 1, 17, 218, 33);
		SetRect(&AlarmMarkerRect, 1, 52, 210, 67);
		SetRect(&BarRect, 10, 34, 202, 52);
		SetRect(&TotalTagRect, 117, 3, 166, 14);
		SetRect(&TotalValueRect, 167, 4, 237, 13);
		SetRect(&MaxTagRect, 220, 3, 244, 14);
		SetRect(&MaxValueRect, 245, 4, 291, 13);
		SetRect(&MinTagRect, 220, 55, 244, 66);
		SetRect(&MinValueRect, 245, 56, 291, 65);
	} else if ((Wwidth >= 320) && (Wheight >= 52)) {
		// 320x52
		diffX = Wwidth - 320;
		diffY = Wheight - 52;
		DBuffBar = TRUE;
		SetRect(&TagRect, 2, 1, 88, 13);
		SetRect(&ValueRect, 242, 14, 319, 28);
		SetRect(&UnitsTagRect, 283, 29, 319, 40);
		SetRect(&ScaleRect, 1, 14, 239, 30);
		SetRect(&AlarmMarkerRect, 3, 37, 231, 49);
		SetRect(&BarRect, 12, 31, 223, 50);
		SetRect(&TotalTagRect, 92, 2, 141, 13);
		SetRect(&TotalValueRect, 142, 3, 212, 12);
		SetRect(&MaxTagRect, 241, 2, 265, 13);
		SetRect(&MaxValueRect, 266, 3, 312, 12);
		SetRect(&MinTagRect, 241, 40, 265, 51);
		SetRect(&MinValueRect, 266, 41, 312, 50);
	} else if ((Wwidth >= 320) && (Wheight >= 41)) {
		// 320x41
		diffX = Wwidth - 320;
		diffY = Wheight - 41;
		DBuffBar = TRUE;
		scalefontheight = 7;
		SetRect(&TagRect, 2, 1, 88, 12);
		SetRect(&ValueRect, 242, 10, 319, 24);
		SetRect(&UnitsTagRect, 283, 26, 319, 38);
		SetRect(&ScaleRect, 1, 12, 239, 26);
		SetRect(&AlarmMarkerRect, 1, 27, 234, 39);
		SetRect(&BarRect, 10, 27, 226, 39);
		SetRect(&TotalTagRect, 119, 1, 168, 12);
		SetRect(&TotalValueRect, 169, 2, 239, 11);
		// No MaxMin values here
		HasMaxMinValues = FALSE;
	} else if ((Wwidth >= 320) && (Wheight >= 34)) {
		// 320x34
		diffX = Wwidth - 320;
		diffY = Wheight - 34;
		DBuffBar = TRUE;
		TransScale = TRUE;
		scalefontheight = 7;
		SetRect(&TagRect, 2, 1, 88, 12);
		SetRect(&ValueRect, 242, 7, 319, 21);
		SetRect(&UnitsTagRect, 283, 21, 319, 33);
		SetRect(&ScaleRect, 1, 12, 239, 32);
		SetRect(&AlarmMarkerRect, 1, 20, 234, 33);
		SetRect(&BarRect, 10, 20, 226, 31);
		SetRect(&TotalTagRect, 119, 1, 168, 12);
		SetRect(&TotalValueRect, 169, 2, 239, 11);
		// No MaxMin values here
		HasMaxMinValues = FALSE;
	} else if ((Wwidth >= 160) && (Wheight >= 52)) {
		// 160x52
		diffX = Wwidth - 160;
		diffY = Wheight - 52;
		DBuffBar = TRUE;
		TransScale = TRUE;
		scalefontheight = 7;
		SetRect(&TagRect, 2, 1, 81, 13);
		SetRect(&ValueRect, 82, 2, 159, 16);
		SetRect(&UnitsTagRect, 123, 40, 159, 51);
		SetRect(&ScaleRect, 1, 17, 159, 40);
		SetRect(&AlarmMarkerRect, 1, 25, 159, 39);
		SetRect(&BarRect, 10, 25, 151, 39);
		SetRect(&TotalTagRect, 1, 40, 50, 51);
		SetRect(&TotalValueRect, 51, 41, 121, 50);
		// No MaxMin values here
		HasMaxMinValues = FALSE;
	} else {
		bRetVal = false;
	}
	// create the Objects if okay so far
	if (bRetVal) {
		bool bFoundObjectError = false;
		// Textobject - Pen Tag	
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &TagRect)) {
			MatchColour(pWgt);
			if (AntiAliasedTag)
				((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Font.Quality = 1; //antialiased
		} else {
			bFoundObjectError = true;
		}
		// Digitalobject - Main value
		if (!bFoundObjectError
				&& m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &ValueRect)) {
			MatchColour(pWgt);
			if (_Height(ValueRect) > 14)
				pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = 1; // double buffer larger digitals
		} else {
			bFoundObjectError = true;
		}
		// Textobject - Units Tag	
		if (!bFoundObjectError
				&& m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &UnitsTagRect)) {
			MatchColour(pWgt);
			((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->IsUnits = 1;
			((T_TEXTOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->IsTag = 0;
		} else {
			bFoundObjectError = true;
		}
		if (!bFoundObjectError && HasTotal) {
			// Textobject - Total Tag
			if (!bFoundObjectError
					&& m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &TotalTagRect)) {
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->ItemType = DI_TOTAL;
				pchref->SubType = DI_TOTAL_READING;
				// Digitalobject - Total value
				if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &TotalValueRect)) {
					MatchColour(pWgt);
					pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
					pchref->ItemType = DI_TOTAL;
					pchref->SubType = DI_TOTAL_READING;
				} else {
					bFoundObjectError = true;
				}
			} else {
				bFoundObjectError = true;
			}
		}
		if (HasMaxMinValues && !bFoundObjectError) {
			// Textobject - Max Tag
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &MaxTagRect)) {
				MatchColour(pWgt);
				pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
				pchref->ItemType = DI_MMA;
				pchref->SubType = DI_MMA_MAX_USER;
				// Digitalobject - Max value
				if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &MaxValueRect)) {
					MatchColour(pWgt);
					pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
					pchref->ItemType = DI_MMA;
					pchref->SubType = DI_MMA_MAX_USER;
					// Textobject - Min Tag
					if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &MinTagRect)) {
						MatchColour(pWgt);
						pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
						pchref->ItemType = DI_MMA;
						pchref->SubType = DI_MMA_MIN_USER;
						// Digitalobject - Min value
						if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &MinValueRect)) {
							MatchColour(pWgt);
							pchref = pWgt->GetObjChanRef(pWgt->m_pSelectedObject, numchans);
							pchref->ItemType = DI_MMA;
							pchref->SubType = DI_MMA_MIN_USER;
						} else {
							bFoundObjectError = true;
						}
					} else {
						bFoundObjectError = true;
					}
				} else {
					bFoundObjectError = true;
				}
			} else {
				bFoundObjectError = true;
			}
		}
		CBarObject *pBarObj = NULL;
		// ORDER of these 3 important - must add Bar, alarm mks and scale (scale on top.)
		// Barobject - the bar
		if (!bFoundObjectError && m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BAROBJECT, &BarRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = DBuffBar;
			pWgt->m_pSelectedObject->m_pCMMbase->FixBackColour = TRUE;
#ifdef UNDER_CE
			pWgt->m_pSelectedObject->m_pCMMbase->BackColour=QString (239,239,239);
		#else
			pWgt->m_pSelectedObject->m_pCMMbase->BackColour = QString(245, 245, 245);
#endif
			pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderUsed = TRUE;
			pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderWidth = 1;
			((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->BarOrientation = 0; // horiz
			if (HasMaxMin) // show max and min MARKERS on bar
			{
				((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ShowMaxMrkr = TRUE;
				((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ShowMinMrkr = TRUE;
			}
			pBarObj = (CBarObject*) pWgt->m_pSelectedObject;
		} else {
			bFoundObjectError = true;
		}
		CAlarmMarkerObject *pAlmmkrObj = NULL;
		// Alarm marker object - the alarm markers
		if (!bFoundObjectError
				&& m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_ALARMMRKROBJECT, &AlarmMarkerRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TransAlarms;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TransAlarms;
			((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Height = alarmmarkerheight; // not all the same height.
			((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Orientation = 0; // horiz
			pAlmmkrObj = (CAlarmMarkerObject*) pWgt->m_pSelectedObject;
		} else {
			bFoundObjectError = true;
		}
		// Scaleobject - the scale
		if (!bFoundObjectError && m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_SCALEOBJECT, &ScaleRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TransScale;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TransScale;
			if (scalefontheight == 14) // for largest only
					{
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorLength = 6;
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MinorLength = 4;
			} else {
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorLength = 4;
				((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MinorLength = 2;
			}
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixBaselineClr = TRUE; // black
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixGradsColour = TRUE; // black
			pWgt->m_pSelectedObject->m_pCMMbase->FixForeColour = TRUE; // black
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->LimitFont.Height = scalefontheight;
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorFont.Height = scalefontheight;
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Orientation = 0; // horiz
			CScaleObject *pScaleObj = (CScaleObject*) pWgt->m_pSelectedObject;
			// link the objects together.
			pScaleObj->LinkTo(pAlmmkrObj, TRUE);
			pScaleObj->LinkTo(pBarObj, TRUE);
			pScaleObj->ConfigChange();
			pAlmmkrObj->ConfigChange();
			// here need to pull the bar back to where we want it. (linking moves it?)
			if (ResetBar) {
				pBarObj->SetBoundsRelative(&BarRect);
				BarRect = pBarObj->GetBounds();
				pBarObj->SetLinkLimits(*(int*) &BarRect.left, *(int*) &BarRect.right); // and all the other objects
			}
			SetScreenInstance(pWgt->m_pCMMwidget->ChannelList[0], PenIndex);
			if (diffX)
				diffX /= 2;
			if (diffY)
				diffY /= 2;
			// move objects into middle of widget.
			if ((diffX) || (diffY)) {
				CBaseObject *pObj = pWgt->m_pObjects;
				while (pObj) {
					QRect objBounds = pObj->GetBounds();
					OffsetRect(&objBounds, diffX, diffY);
					pObj->SetBounds(&objBounds);
					pObj = pObj->m_pNextObj;
				}
			}
		} else {
			bFoundObjectError = true;
		}
		bRetVal = !bFoundObjectError;
	}
	return (bRetVal == true);
}
//****************************************************************************
///
///	Fill the widget with the Vertical Indicators (scale + bar/pointers + alarm mks)
/// NB Vertical indicators are for a vertical chart (i.e. actually horizontal)
///
/// @param[in] PenIndex			- zero based pen index (0=pen1)
/// @param[in] HasPointer		- show pointer(s) or Bar?
/// @param[in] HasAlarmMarkers	- show alarm markers?
/// @param[in] IsRotating		- rotating?
///
/// @return	T/F - indicating success of adding
/// 
//****************************************************************************
CBaseObject* CScreen::AddIndicatorVContents(int PenIndex, BOOL HasPointer, BOOL HasAlarmMarkers, BOOL IsRotating,
		CBaseObject *pLinkObj) {
	// local pointers for clarity
	CWidget *pWgt = m_pSelectedWidget;
	// Vertical Indicator has the following:
	QRect ScaleRect, BarRect, PointerRect, AlarmMarkerRect;
	int scalefontheight = 9;
	int pointerheight = 20;
	QRect bounds = pWgt->GetWidgetBounds();
	int Wwidth = _Width(bounds);
	int Wheight = _Height(bounds);
	int diffX = 0;
	int diffY = 0;
	if ((Wwidth >= 266) && (Wheight >= 33)) {
		// 266x33
		diffX = Wwidth - 266;
		diffY = Wheight - 33;
		SetRect(&ScaleRect, 1, 1, 265, 32);
		SetRect(&BarRect, 12, 12, 249, 30);
#ifdef UNDER_CE
		SetRect(&PointerRect,6,11,254,32);  // use different vertical offset for recorder.
#else		
		SetRect(&PointerRect, 6, 12, 254, 31);
#endif
		SetRect(&AlarmMarkerRect, 3, 11, 257, 31);
	} else if ((Wwidth >= 266) && (Wheight >= 20)) {
		// 266x20
		diffX = Wwidth - 266;
		diffY = Wheight - 20;
		scalefontheight = 7;
		pointerheight = 12;
		SetRect(&ScaleRect, 1, 2, 265, 18);
		SetRect(&BarRect, 10, 10, 252, 17);
		SetRect(&PointerRect, 6, 4, 255, 17);
		SetRect(&AlarmMarkerRect, 1, 9, 260, 19);
	} else if ((Wwidth >= 266) && (Wheight >= 16)) {
		// 266x16
		diffX = Wwidth - 266;
		diffY = Wheight - 16;
		scalefontheight = 7;
		pointerheight = 12;
		SetRect(&ScaleRect, 1, 2, 265, 15);
		SetRect(&BarRect, 10, 10, 252, 14);
		SetRect(&PointerRect, 6, 3, 255, 15);
		SetRect(&AlarmMarkerRect, 1, 6, 260, 15);
	} else
		return NULL;
	// create the Objects...
	// ORDER of these 3 important - must add Bar alarm mks and scale (scale on top.)
	// This always applies for horizontal scale etc.
	CBaseObject *pBarOrPointObj;
	if (!HasPointer) {
		// Barobject 
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BAROBJECT, &BarRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
			// bar border and shading removed
			//		pWgt->m_pSelectedObject->m_pCMMbase->FixBackColour=TRUE;
			//	#ifdef UNDER_CE
			//		pWgt->m_pSelectedObject->m_pCMMbase->BackColour=QString (239,239,239);
			//	#else
			//		pWgt->m_pSelectedObject->m_pCMMbase->BackColour=QString (245,245,245);
			//	#endif
			//
			//		pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderUsed=TRUE;
			//		pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderWidth=1;
			((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->BarOrientation = 0;	// horiz
			if (IsRotating)
				((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo.Rotate = TRUE;
			pBarOrPointObj = pWgt->m_pSelectedObject;
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create bar object, %s, Pen %u", m_pCMMscreen->Name, PenIndex + 1);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	} else {
		// Pen pointers object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_PENPTRSOBJECT, &PointerRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TRUE;
			((T_PENPTRSOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Height = pointerheight;
			((T_PENPTRSOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Orientation = 0;	// horiz
			// since pen pointers has a temp channel ref, it gets set in the object
			//	if(IsRotating)
			//		((CPenPointersObject*)pWgt->m_pSelectedObject)->SetRotating(); // this has no effect - member will be lost
			pBarOrPointObj = pWgt->m_pSelectedObject;
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create pen pointer object, %s, Pen %u", m_pCMMscreen->Name,
					PenIndex + 1);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	}
	CAlarmMarkerObject *pAlmmkrObj = NULL;
	if (HasAlarmMarkers)		// Alarm marker object - the alarm markers
	{
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_ALARMMRKROBJECT, &AlarmMarkerRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TRUE;
			((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Height = 10; // all the same height.
			((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Orientation = 0; // horiz
			if (IsRotating) {
				for (int a = 0; a < ALARMMRKROBJECT_CHANNELINFO_SIZE; a++)
					((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo[a].Rotate = TRUE;
			}
			pAlmmkrObj = (CAlarmMarkerObject*) pWgt->m_pSelectedObject;
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create alarm marker object, %s, Pen %u", m_pCMMscreen->Name,
					PenIndex + 1);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	}
	// Scaleobject - the scale
	if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_SCALEOBJECT, &ScaleRect)) {
		MatchColour(pWgt);
		pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
		pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TRUE;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorLength = 4;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MinorLength = 2;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixBaselineClr = TRUE; // black
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixGradsColour = TRUE; // black
		pWgt->m_pSelectedObject->m_pCMMbase->FixForeColour = TRUE; // black
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->LimitFont.Height = scalefontheight;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorFont.Height = scalefontheight;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Orientation = 0; // horiz
		if (IsRotating) {
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo.Rotate = TRUE;
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo.Updates = TRUE; // needs to have updates to rotate!
		}
		CScaleObject *pScaleObj = (CScaleObject*) pWgt->m_pSelectedObject;
		// use the object supplied above (i.e. chart) from the previous widget to set the link limits for the first object here
		pLinkObj->LinkTo(pScaleObj, TRUE);
		if (pAlmmkrObj) {
			// link the objects together.
			pScaleObj->LinkTo(pAlmmkrObj, TRUE);
			pScaleObj->LinkTo(pBarOrPointObj, TRUE);
		} else
			pScaleObj->LinkTo(pBarOrPointObj, TRUE);
		SetScreenInstance(pWgt->m_pCMMwidget->ChannelList[0], PenIndex);
		if (diffY)
			diffY /= 2;
		// move objects into middle of widget.
		if (diffY) {
			CBaseObject *pObj = pWgt->m_pObjects;
			while (pObj) {
				QRect objBounds = pObj->GetBounds();
				OffsetRect(&objBounds, 0, diffY);
				pObj->SetBounds(&objBounds);
				pObj = pObj->m_pNextObj;
			}
		}
	} else {
		QString strError("");
		strError = QString::asprintf("Failed to create scale object, %s, Pen %u", m_pCMMscreen->Name, PenIndex + 1);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
	return pBarOrPointObj;
}
//****************************************************************************
///
///	Fill the widget with the Horizontal Indicators (scale + bar/pointers + alarm mks)
/// NB Horizontal indicators are for a Horizontal chart (i.e. actually vertical)
///
/// @param[in] PenIndex			- zero based pen index (0=pen1)
/// @param[in] HasPointer		- show pointer(s) or Bar?
/// @param[in] HasAlarmMarkers	- show alarm markers?
/// @param[in] IsRotating		- rotating?
///
/// @return	T/F - indicating success of adding
/// 
//****************************************************************************
CBaseObject* CScreen::AddIndicatorHContents(int PenIndex, BOOL HasPointer, BOOL HasAlarmMarkers, BOOL IsRotating,
		CBaseObject *pLinkObj) {
	// local pointers for clarity
	CWidget *pWgt = m_pSelectedWidget;
	// Vertical Indicator has the following:
	QRect ScaleRect, BarRect, PointerRect, AlarmMarkerRect;
	int scalefontheight = 9;
	int pointerheight = 20;
	int majscalegrads = 4;
	BOOL NoDP = FALSE;
	QRect bounds = pWgt->GetWidgetBounds();
	int Wwidth = _Width(bounds);
	int Wheight = _Height(bounds);
	int diffX = 0;
	if ((Wwidth >= 51) && (Wheight >= 184)) {
		// 51x186
		diffX = Wwidth - 51;
		SetRect(&ScaleRect, 0, 5, 50, 179);
		SetRect(&BarRect, 1, 10, 50, 175);
		SetRect(&PointerRect, 1, 3, 49, 181);
		SetRect(&AlarmMarkerRect, 28, 1, 50, 183);
	} else if ((Wwidth >= 41) && (Wheight >= 184)) {
		// 41x186
		diffX = Wwidth - 41;
		scalefontheight = 7;
		majscalegrads = 2;
		SetRect(&ScaleRect, 0, 6, 40, 178);
		SetRect(&BarRect, 1, 10, 40, 175);
		SetRect(&PointerRect, 2, 3, 39, 181);
		SetRect(&AlarmMarkerRect, 20, 1, 40, 183);
	} else if ((Wwidth >= 21) && (Wheight >= 184)) {
		// 21x186
		diffX = Wwidth - 21;
		scalefontheight = 7;
		pointerheight = 12;
		majscalegrads = 2;
		NoDP = TRUE;
		SetRect(&ScaleRect, 0, 6, 20, 178);
		SetRect(&BarRect, 1, 10, 20, 175);
		SetRect(&PointerRect, 1, 2, 13, 182);
		SetRect(&AlarmMarkerRect, 10, 1, 20, 183);
	} else
		return NULL;
	// create the Objects...
	// ORDER of these 3 important - must add Bar alarm mks and scale (scale on top.)
	// EXCEPT large penpointers need to be on top of scale
	CBaseObject *pBarOrPointObj;
	if (!HasPointer) {
		// Barobject 
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BAROBJECT, &BarRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
			//		pWgt->m_pSelectedObject->m_pCMMbase->FixBackColour=TRUE;
			//	#ifdef UNDER_CE
			//		pWgt->m_pSelectedObject->m_pCMMbase->BackColour=QString (239,239,239);
			//	#else
			//		pWgt->m_pSelectedObject->m_pCMMbase->BackColour=QString (245,245,245);
			//	#endif
			//	pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderUsed=TRUE;
			//	pWgt->m_pSelectedObject->m_pCMMbase->Border.BorderWidth=1;
			if (IsRotating)
				((T_BAROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo.Rotate = TRUE;
			pBarOrPointObj = pWgt->m_pSelectedObject;
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create bar object, %s, Pen %u", m_pCMMscreen->Name, PenIndex + 1);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	} else {
		// Pen pointers object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_PENPTRSOBJECT, &PointerRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TRUE;
			((T_PENPTRSOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Height = pointerheight;
			// since pen pointers has a temp channel ref, it gets set in the object
//			if(IsRotating)
//				((CPenPointersObject*)pWgt->m_pSelectedObject)->SetRotating(); // this has no effect - member will be lost
			pBarOrPointObj = pWgt->m_pSelectedObject;
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create pen pointer object, %s, Pen %u", m_pCMMscreen->Name,
					PenIndex + 1);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	}
	CAlarmMarkerObject *pAlmmkrObj = NULL;
	if (HasAlarmMarkers) {
		// Alarm marker object - the alarm markers
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_ALARMMRKROBJECT, &AlarmMarkerRect)) {
			MatchColour(pWgt);
			pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
			pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TRUE;
			((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->Height = 10; // all the same height.
			if (IsRotating)
				for (int a = 0; a < ALARMMRKROBJECT_CHANNELINFO_SIZE; a++)
					((T_ALARMMRKROBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo[a].Rotate = TRUE;
			pAlmmkrObj = (CAlarmMarkerObject*) pWgt->m_pSelectedObject;
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create alarm marker object, %s, Pen %u", m_pCMMscreen->Name,
					PenIndex + 1);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	}
	// Scaleobject - the scale
	if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_SCALEOBJECT, &ScaleRect)) {
		MatchColour(pWgt);
		pWgt->m_pSelectedObject->m_pCMMbase->IsBuffered = TRUE;
		pWgt->m_pSelectedObject->m_pCMMbase->IsTransparent = TRUE;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorLength = majscalegrads;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MinorLength = 2;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixBaselineClr = TRUE; // black
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->FixGradsColour = TRUE; // black
		pWgt->m_pSelectedObject->m_pCMMbase->FixForeColour = TRUE; // black
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->LimitFont.Height = scalefontheight;
		((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->MajorFont.Height = scalefontheight;
		//	if(NoDP) // thinnist scale - set number of decimal places to none.
		//	{
		//		((T_SCALEOBJECT*)pWgt->m_pSelectedObject->m_pCMMbase)->FixNumasprintf=TRUE;
		//		((T_SCALEOBJECT*)pWgt->m_pSelectedObject->m_pCMMbase)->Numasprintf.Auto=FALSE;
		//		((T_SCALEOBJECT*)pWgt->m_pSelectedObject->m_pCMMbase)->Numasprintf.Ad=0;
		//	}
		if (IsRotating) {
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo.Rotate = TRUE;
			((T_SCALEOBJECT*) pWgt->m_pSelectedObject->m_pCMMbase)->ChannelInfo.Updates = TRUE; // needs to have updates to rotate!
		}
		CScaleObject *pScaleObj = (CScaleObject*) pWgt->m_pSelectedObject;
		if (HasPointer && (pointerheight > 15))  // large pointers on top (to make easier reading of pen number)
			pWgt->BringObjectToTop(pBarOrPointObj, FALSE); // don't flag modified
		// use the object supplied above (i.e. chart) from the previous widget to set the link limits for the first object here
		pLinkObj->LinkTo(pScaleObj, TRUE);
		if (pAlmmkrObj) {
			// link the objects together.
			pScaleObj->LinkTo(pAlmmkrObj, TRUE);
			pScaleObj->LinkTo(pBarOrPointObj, TRUE);
		} else
			pScaleObj->LinkTo(pBarOrPointObj, TRUE);
		SetScreenInstance(pWgt->m_pCMMwidget->ChannelList[0], PenIndex);
		if (diffX)
			diffX /= 2;
		// move objects into middle of widget.
		if ((diffX)) {
			CBaseObject *pObj = pWgt->m_pObjects;
			while (pObj) {
				QRect objBounds = pObj->GetBounds();
				OffsetRect(&objBounds, diffX, 0);
				pObj->SetBounds(&objBounds);
				pObj = pObj->m_pNextObj;
			}
		}
	} else {
		QString strError("");
		strError = QString::asprintf("Failed to create scale object, %s, Pen %u", m_pCMMscreen->Name, PenIndex + 1);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
	return pBarOrPointObj;
}
//****************************************************************************
///
///	Screen's Channel Map conversion.
///
/// @param[in] channel - Channel to convert
///
/// @return Instance number in Data Item table, ms_usINVALID_CHANNEL_NO if the channel is invalid or
///			ms_usUNINITIALISED_INSTANCE is the instance number is invalid
/// 
//****************************************************************************
USHORT CScreen::ChannelToInstance(int channel) {
	// CHANNEL		INSTANCE
	// 0 (CWidget::ms_usCHANNEL_OFFSET)				1
	// 1 (CWidget::ms_usCHANNEL_OFFSET + 1)			2
	// 2 (CWidget::ms_usCHANNEL_OFFSET + 2)			3
	// 3 (CWidget::ms_usCHANNEL_OFFSET + 3)			20  
	// 4 (CWidget::ms_usCHANNEL_OFFSET + 4)			15
	// 5 (CWidget::ms_usCHANNEL_OFFSET + 5)			10
	// Each entry in the map is the item instance in the Data Item Table.
	// Map will be created with Instance numbers in order, but can be edited (as above)
	USHORT usInstanceNo = 0;
	if ((channel < CWidget::ms_usCHANNEL_OFFSET)
			|| (channel >= (CWidget::ms_usCHANNEL_OFFSET + SCREEN_CHANNELMAP_SIZE))) {
		usInstanceNo = ms_usINVALID_CHANNEL_NO;
	} else {
		usInstanceNo = m_pCMMscreen->ChannelMap[channel - CWidget::ms_usCHANNEL_OFFSET];
	}
	return usInstanceNo;
}
//****************************************************************************
///
///	Function to add a new Widget
///
/// @param[in] pConfig	 - Configuration to add to
/// @param[in] blockInfo - pointer to BLOCK_INFO in CMM for Widget to add 
/// @param[in] bounds	 - can be NULL
///
/// @return none
/// 
//****************************************************************************
void CScreen::AddNewWidget(CLayoutConfiguration *pConfig, BLOCK_INFO *blockInfo, QRect *bounds) {
	// before calling this function, Widget already has a CMM entry
	// now create a corresponding C++ Widget for it.
	CWidget *pWidget = new CWidget(this);
	pWidget->CMMInitWidget(pConfig, blockInfo, bounds); // bounds can be NULL
	AppendWidget(pWidget);
	m_pSelectedWidget = pWidget;
}
//****************************************************************************
///
///	searches list of CWidgets for matching CMM widget
///
/// @param[in] LayoutItem - type and instance reference from CMM
///
/// @return pointet to Widget found or NULL
/// 
//****************************************************************************
CWidget* CScreen::indexOfWidgetInstance(T_LAYOUTITEM *LayoutItem) {
	CWidget *pWgt = m_pWidgets;
	while (pWgt) {
		if (pWgt->MatchLayoutItem(LayoutItem))
			return pWgt;
		pWgt = pWgt->m_pNextWgt;
	}
	return NULL; // not matched.
}
//****************************************************************************
///
///	Function to check if this CScreen matches a LayoutItem reference from 
/// the CMM.
///
/// @param[in] LayoutItem - type and instance reference from CMM
///
/// @return TRUE/FALSE
/// 
//****************************************************************************
BOOL CScreen::MatchLayoutItem(T_LAYOUTITEM *LayoutItem) {
	return ((m_CMMinfo.wInstanceID == LayoutItem->CMM_Inst) && // match type and instance?
			(m_CMMinfo.wBlockType == LayoutItem->CMM_Type)); // check it's BLK_SCREEN
}
//****************************************************************************
///
/// Returns the T_LAYOUTITEM of this Screen
///
/// @param none
///
/// @return T_LAYOUTITEM
/// 
//****************************************************************************
T_LAYOUTITEM CScreen::GetLayoutItem() {
	T_LAYOUTITEM ref;
	ref.CMM_Type = m_CMMinfo.wBlockType;
	ref.CMM_Inst = m_CMMinfo.wInstanceID;
	return ref;
}
//****************************************************************************
///
/// Is this screen a canned screen?
///
/// @param none
///
/// @return TRUE/FALSE
/// 
//****************************************************************************
BOOL CScreen::IsCannedScreen() {
	return (m_pCMMscreen->Type < TPL_LAST_CANNED);
}
//****************************************************************************
///
/// Appends a Widget to the end of the list for the Screen
/// 
/// @param[in] pWgt - pointer to CWidget to append 
///
/// @return none
/// 
//****************************************************************************
void CScreen::AppendWidget(CWidget *pWidget) {
	CWidget **pWgt = &m_pWidgets; // address of head of list pointer
	while (*pWgt) {
		pWgt = &((*pWgt)->m_pNextWgt); // traverse any items in list
	}
	(*pWgt) = pWidget; // assign onto end of list
	pWidget->m_pNextWgt = NULL;
}
//****************************************************************************
///
/// removes a Widget from the list for the Screen (NB: DOES NOT DELETE IT)
/// 
/// @param[in] pWgt - pointer to CWidget to remove
///
/// @return TRUE if removed OK, FALSE if not found
/// 
//****************************************************************************
BOOL CScreen::RemoveWidget(CWidget *pWidget) {
	CWidget **pWgt = &m_pWidgets;
	BOOL found = FALSE;
	while (*pWgt) {
		if (*pWgt == pWidget) {
			// found our object.
			*pWgt = pWidget->m_pNextWgt; // remove it from list
			pWidget->m_pNextWgt = NULL;
			found = TRUE;
			break;
		}
		pWgt = &((*pWgt)->m_pNextWgt);
	}
	return found;
}
//****************************************************************************
///
/// Bring Widget to the top of the Z order (end of the list)
/// 
/// @param[in] pWgt - pointer to Widget to bring to top
///
/// @return TRUE if completed OK, FALSE if not found
/// 
//****************************************************************************
BOOL CScreen::BringWidgetToTop(CWidget *pWidget) {
	if (!GetOpPanel()->m_bBringObjectOrWidgetToTop)
		return TRUE; // overruled !!
	if (pWidget->m_pNextWgt == NULL)
		return TRUE; // already at top !!
	CWidget **pWgt = &m_pWidgets;
	BOOL found = FALSE;
	while (*pWgt) {
		if ((*pWgt) == pWidget) {
			// found our widget.
			*pWgt = pWidget->m_pNextWgt; // remove it from list
			pWidget->m_pNextWgt = NULL;
			found = TRUE;
			// continue to end of list....
		}
		pWgt = &((*pWgt)->m_pNextWgt);
	}
	if (found)
		(*pWgt) = pWidget; // append our widget to end of list (top of Z order)
	return found;
}
//****************************************************************************
///
/// Move Widget to the bottom of the Z order (head of the list)
/// 
/// @param[in] pWgt - pointer to widget to send to bottom
///
/// @return TRUE if completed OK, FALSE if not found
/// 
//****************************************************************************
BOOL CScreen::SendWidgetToBottom(CWidget *pWidget) {
	CWidget **pWgt = &m_pWidgets;
	if ((*pWgt) == pWidget)
		return TRUE; // already at bottom !!
	BOOL found = FALSE;
	while ((*pWgt)) {
		if ((*pWgt) == pWidget) {
			// found our object.
			*pWgt = pWidget->m_pNextWgt; // remove it from list
			pWidget->m_pNextWgt = NULL;
			found = TRUE;
			break;
		}
		pWgt = &((*pWgt)->m_pNextWgt);
	}
	if (found) {
		// insert at head...
		pWidget->m_pNextWgt = m_pWidgets;
		m_pWidgets = pWidget;
	}
	return found;
}
//****************************************************************************
///
/// Invalidates the rectangle on the screen and causes an immediate update
/// 
/// @param[in] area - QRect to invalidate
///
/// @return none
/// 
//****************************************************************************	
void CScreen::InvalidateArea(QRect area) {
	if (m_ScreenIsMoved) {
		area.setTop(m_pOpPanel)->m_moveOffset;
		area.setBottom(m_pOpPanel)->m_moveOffset;
	}
	InvalidateRect(m_pOpPanel->m_hWnd, &area, FALSE);
	UpdateWindow(m_pOpPanel->m_hWnd);
}
//****************************************************************************
///
/// Called to check all the Widgets on the screen to check for updates
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************	
void CScreen::Refresh() {
	// call CheckDataItems on each of our widgets
	if (!m_DoneInitalDraw)
		return;
	BOOL doDraw = FALSE;
	CWidget *pWgt = m_pWidgets;
	while (pWgt) {
		if (pWgt->CheckDataItems())
			doDraw = TRUE;
		pWgt = pWgt->m_pNextWgt;
	}
	if (doDraw)
		DrawScreen(NULL); // now do any drawing if necessary.
}
//****************************************************************************
///
/// Draws the Recorder screen area (for screen designer use)
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************	
void CScreen::ShowRecScreenArea() {
	HDC Tdc;
	HRESULT hrT;
	hrT = m_pOpPanel->m_pDDSBackBuffer->GetDC(&Tdc);
	if (!FAILED(hrT)) {
		COLORREF crScreen;
		if (m_pCMMscreen->UseTmpltColour)
			crScreen = RGB565toRGB(m_pTemplate->m_pCMMtemplate->BackColour); // use backcolour from Template
		else
			crScreen = RGB565toRGB(m_pCMMscreen->BackColour); // use Screen's backcolour
		CDC *newdc = CDC::FromHandle(Tdc);
		// Draw screen with a lighter colour than the recorder screen area.
		newdc->FillSolidRect(&m_ScreenClientRect, ColourAdjust(crScreen, 40));
		// Draw recorder screen area.
		QBrush brushRecScreenArea;
		brushRecScreenArea.CreateSolidBrush(crScreen);
		QBrush *pOldBrush = newdc->SelectObject(&brushRecScreenArea);
		newdc->Rectangle(&GetOpPanel()->m_RecScreenArea);
		// Restore the original brush.
		newdc->SelectObject(pOldBrush);
		// Draw status bar if it is present.
		if (m_pTemplate->m_pCMMtemplate->StatusBar) {
			CBitmap StatusBarBitmap;
			if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
				StatusBarBitmap.LoadBitmap(L"SCD_STATUS_BAR_MINI");
			else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS)
				StatusBarBitmap.LoadBitmap(L"SCD_STATUS_BAR_MULTI");
			else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_EZTREND
					|| m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MINITREND)
				StatusBarBitmap.LoadBitmap(L"SCD_STATUS_BAR_MINI_QXE");
			else if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS)
				StatusBarBitmap.LoadBitmap(L"SCD_STATUS_BAR_OLD_MULTI");
			BITMAP bmpInfo;
			StatusBarBitmap.GetBitmap(&bmpInfo);
			// Create an in-memory DC compatible with
			// the display DC we're using to paint.
			CDC dcMemory;
			dcMemory.CreateCompatibleDC(newdc);
			// Select the bitmap into the in-memory DC.
			CBitmap *pOldBitmap = dcMemory.SelectObject(&StatusBarBitmap);
			// Copy the bits from the in-memory DC into the on-screen DC to actually do the painting.
			newdc->BitBlt(GetOpPanel()->m_RecScreenArea.left, GetOpPanel()->m_RecScreenArea.top, bmpInfo.bmWidth,
					bmpInfo.bmHeight, &dcMemory, 0, 0, SRCCOPY);
			// Restore the original bitmap.
			dcMemory.SelectObject(pOldBitmap);
		}
		m_pOpPanel->m_pDDSBackBuffer->ReleaseDC(Tdc);
	}
}
//****************************************************************************
///
/// display screen mode and name (testing only)
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************	
void CScreen::ShowInfo() {
	HDC Tdc;
	HRESULT hrT;
	hrT = m_pOpPanel->m_pDDSBackBuffer->GetDC(&Tdc);
	if (!FAILED(hrT)) {
		QRect rect = { 2, 2, 320, 20 };
#ifdef DOCVIEW
		OffsetRect(&rect,GetOpPanel()->m_RecScreenOffset.x,GetOpPanel()->m_RecScreenOffset.y);
#endif	
// for testing purposes - show screen name and mode
		SetTextColor(Tdc, QString(0, 0, 0)); // black
		SetBkMode(Tdc, TRANSPARENT);
		CFontCache *pfc = CFontCache::GetHandle();
		QFont hfont;
		hfont = pfc->GetFont(_Height(rect), QFont::Bold, 0, ANTIALIASED_QUALITY);
		/*
		 hfont=pfc->GetFont(_Height(rect));
		 hfont=pfc->GetFont(_Height(rect),QFont::Bold);
		 hfont=pfc->GetFont(_Height(rect),QFont::Normal,FF_MODERN);
		 hfont=pfc->GetFont(_Height(rect),QFont::Bold,FF_MODERN);
		 hfont=pfc->GetFont(_Height(rect),QFont::Normal,FF_MODERN,ANTIALIASED_QUALITY);
		 hfont=pfc->GetFont(_Height(rect),QFont::Bold,FF_MODERN,ANTIALIASED_QUALITY);
		 hfont=pfc->GetFont(_Height(rect),QFont::Normal,FF_DONTCARE,ANTIALIASED_QUALITY);
		 hfont=pfc->GetFont(_Height(rect),QFont::Bold,FF_DONTCARE,ANTIALIASED_QUALITY);
		 */
		QFont hOldfont = (QFont) SelectObject(Tdc, hfont);
		WCHAR buffer[200];
		if (m_pOpPanel->m_EditMode == RUN_MODE)
			swprintf(buffer, L"%s - RUN mode", m_pCMMscreen->Name);
		else
			swprintf(buffer, L"%s - DESIGNER mode", m_pCMMscreen->Name);
		//qDebug("Showing :%s\n",buffer);
		DrawText(Tdc, buffer, -1, &rect, DT_SINGLELINE);
		SelectObject(Tdc, hOldfont);
		pfc->ReleaseFont(hfont);
		SetBkMode(Tdc, OPAQUE);
		m_pOpPanel->m_pDDSBackBuffer->ReleaseDC(Tdc);
	}
}
//****************************************************************************
///
/// Draws the Widgets on the screen in the 
/// 
/// @param[in] pClipRect - pointer to clipping QRect or NULL when performing Updates
///
/// @return none
/// 
//****************************************************************************	
DWORD listbytes;
HRGN hWindowRgn;
void CScreen::DrawScreen(QRect *pClipRect) {
	HRESULT hres;
//qDebug("\n+++++++++++++++STARTING DRAW PASS HERE+++++++++++++++++++++++++++++++++++\n");
	if ((m_pOpPanel->m_pDD == NULL) || m_pOpPanel->m_Inactive)
		return;
	if (InterlockedIncrement(&m_pOpPanel->m_IsDrawing) > 1) {
		InterlockedDecrement(&m_pOpPanel->m_IsDrawing);
		return;
	}
	m_pOpPanel->GetClientRect(&m_pOpPanel->m_DesktopRect);
//***519766 	
#ifndef UNDER_CE // required only for desktop builds		
	m_ScreenClientRect = m_pOpPanel->m_DesktopRect;
	m_pOpPanel->ClientToScreen(&m_pOpPanel->m_DesktopRect); // convert to screen co-ords
#endif	
	m_pOpPanel->m_OutputRect = m_pOpPanel->m_DesktopRect;
#ifndef DOCVIEW
	if ((m_pTemplate && m_pTemplate->m_pCMMtemplate->StatusBar == FALSE) && m_pOpPanel->m_DoScreenMove) {
		m_pOpPanel->m_OutputRect.setTop(m_pOpPanel)->m_moveOffset;
		m_ScreenIsMoved = TRUE;
	} else
		m_ScreenIsMoved = FALSE;
#endif
	// here set up clipper for primary surface.
	// NB do not change clipping region in Object drawing (or be very careful)
	// since clipping set up correctly if say dialog is visible.
	// if then change it or set it to NULL, dialog can get drawn over.
	if (pClipRect) {
		QRect temp = *pClipRect;
#ifndef UNDER_CE // required only for desktop builds		
		m_pOpPanel->ClientToScreen(&temp);
#endif
		m_hrgnUpdate = CreateRectRgnIndirect(&temp); // update area only
	} else
		m_hrgnUpdate = CreateRectRgnIndirect(&m_pOpPanel->m_DesktopRect); // whole screen 
	// get'window'cliplist from ddClipperWindow
	//m_pOpPanel->m_pDDClipperWindow->GetClipList(NULL,NULL,&listbytes);
	//519766
	m_pOpPanel->m_pDDClipper->GetClipList(NULL, NULL, &listbytes);
	// here we have the window cliplist. This will take account of overlapping windows 
	// for desktop and dialog boxes for recorder. 
	// If nothing is actually visible (e.g. due to being covered by a dialog) then 
	// none of the Object draw code will be done. Once uncovered, a WM_PAINT will be triggered
	// and any updates that were not done will still be flagged. (WM_PAINT and updates at same time)
	if (listbytes) {
		m_pOpPanel->SetClipListBuffer(listbytes);
		//m_pOpPanel->m_pDDClipperWindow->GetClipList(NULL,m_pOpPanel->m_pClipList,&listbytes);
		m_pOpPanel->m_pDDClipper->GetClipList(NULL, m_pOpPanel->m_pClipList, &listbytes);
		hWindowRgn = ExtCreateRegion(NULL, listbytes, m_pOpPanel->m_pClipList);
		// now do intersection with m_hrgnUpdate
		int res = CombineRgn(m_hrgnUpdate, m_hrgnUpdate, hWindowRgn, RGN_AND);
		DeleteObject(hWindowRgn);
		if (res <= NULLREGION) {
			// nothing is visible
			DeleteObject(m_hrgnUpdate);
			InterlockedDecrement(&m_pOpPanel->m_IsDrawing);
			return;
		}
	} else {
		// nothing (for OpPanel) is visible
		DeleteObject(m_hrgnUpdate);
		InterlockedDecrement(&m_pOpPanel->m_IsDrawing);
		return;
	}
	// ok, so here, something on OpPanel is visible !!
	listbytes = GetRegionData(m_hrgnUpdate, 0, NULL);
	if (listbytes) {
		m_pOpPanel->SetClipListBuffer(listbytes);
		GetRegionData(m_hrgnUpdate, listbytes, m_pOpPanel->m_pClipList);
		HRESULT hr = m_pOpPanel->m_pDDClipper->SetClipList(m_pOpPanel->m_pClipList, 0);
	}
	if (pClipRect) // i.e. For a real update rectangle (WM_PAINT case) - moving widget or object or dialog or menu
	{
		// for the WM_PAINT case, we have an area that we need to update on the screen. Since this may involve 
		// painting some background (for screen and/or widget) then painting Objects on top, it directs all this to 
		// the backbuffer, so we won't see a flickery update. (esp in screen designer when moving objects/widgets about)
		// This applies to everything, including objects that normally draw direct to the primary surface.
		// blt in the background colour for the screen.
		DDBLTFX ddbltfx;
		memset(&ddbltfx, 0, sizeof(ddbltfx));
		ddbltfx.dwSize = sizeof(ddbltfx);
		// for desktop, FILLCOLOUR Macro will be expanded to convert 16 bit colour to 32 bit RGB888
		if (m_pCMMscreen->UseTmpltColour)
			ddbltfx.dwFillColor = FILLCOLOUR(m_pTemplate->m_pCMMtemplate->BackColour); // use backcolour from Template
		else
			ddbltfx.dwFillColor = FILLCOLOUR(m_pCMMscreen->BackColour); // use Screen's backcolour
#ifdef _DEBUG
	// for testing: here use the Glb_col to show the update area. (add addtional lines below)
	if(Glb_SeeRegions)
	{
		Glb_col+=25;	
		ddbltfx.dwFillColor = FILLCOLOURFROMRGB(GetColour(Glb_col));
	}
#endif	
		// if screen moved, adjust cliprect by same amount
		if (m_ScreenIsMoved) {
			pClipRect->top -= m_pOpPanel->m_moveOffset;
			pClipRect->bottom -= m_pOpPanel->m_moveOffset;
			if (pClipRect->top < 0)
				pClipRect->top = 0;
		}
#ifdef UNDER_CE
		hres=m_pOpPanel->m_pDDSBackBuffer->Blt(pClipRect, NULL, NULL, DDBLT_COLORFILL | DDBLT_WAITNOTBUSY | DDBLT_WAITVSYNC, &ddbltfx); // back buffer
#else
		hres = m_pOpPanel->m_pDDSBackBuffer->Blt(pClipRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx); // back buffer
#endif
		//E519766
		//hres=m_pOpPanel->m_pDDSPrimary->Blt(pClipRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx); // back buffer
#ifdef DOCVIEW
		ShowRecScreenArea();
	//	ShowInfo(); // mode and screen number (testing)
#else
		//	ShowInfo(); // mode and screen number (testing)
#endif
		// for Each Widget, check to see if it falls in the update rectangle	
		CWidget *pWgt = m_pWidgets;
		while (pWgt) {
			if (pWgt->PrepareDraw(pClipRect)) {
				// Has some part within update rectangle, so Draw background 
				pWgt->DrawBackgound();
			}
			pWgt = pWgt->m_pNextWgt;
		}
		// now aquire HDC's for the surfaces, and perform all the Standard drawing.
		// NB we don't get the primary surface here - it all goes to backbuffer 
		HDC hdcBackBuffer;
		HDC hdcAlpha;
		HRESULT hr1 = m_pOpPanel->m_pDDSBackBuffer->GetDC(&hdcBackBuffer); // back buffer
		HRESULT hr2 = m_pOpPanel->m_pDDSAlpha->GetDC(&hdcAlpha); // alpha buffer
#ifdef SHOW_CPU
		// Draw CPU % on screen
		float cpuUsage = GetCurrentCPUUtilization();
		QString csTxt ;
		csTxt = QString::asprintf("CPU: %.02f%s", cpuUsage,L"%");
		//txtRect will be the generic re-used box for drawing text
		QRect TxtRect;
		//draw the static text boxes
		TxtRect.left	= 50;
		TxtRect.right	= 200;
		TxtRect.top		= 100;
		TxtRect.bottom	= 100+100;
	
		SetTextColor(hdcBackBuffer,QString (0,0,255));
		DrawText(hdcBackBuffer, csTxt,-1,&TxtRect,DT_SINGLELINE|DT_LEFT);
#endif
#ifndef UNDER_CE // required only for desktop builds		
		// since m_hrgnUpdate is in screen co-ords, need to offset it for use with hdcBackBuffer since we
		// are using the backbuffer here in place of the primary surface
		OffsetRgn(m_hrgnUpdate, -m_pOpPanel->m_OutputRect.left, -m_pOpPanel->m_OutputRect.top);
#endif
		if (!FAILED(hr1)) {
			SelectClipRgn(hdcBackBuffer, NULL);
			SelectClipRgn(hdcAlpha, NULL);
			// do a pass of all widgets
			CWidget *pWgt = m_pWidgets;
			while (pWgt) {
				if (pWgt->m_WidgetClip) // was set up during prepare draw if required.				
					pWgt->StandardDraw(hdcBackBuffer, hdcBackBuffer, hdcAlpha); // Standard Objects drawn now
				pWgt = pWgt->m_pNextWgt;
			}
			m_pOpPanel->m_pDDSBackBuffer->ReleaseDC(hdcBackBuffer);
			//	m_pOpPanel->m_pDDSAlpha->ReleaseDC(hdcAlpha); 
		}
		if (SUCCEEDED(hr2))
			m_pOpPanel->m_pDDSAlpha->ReleaseDC(hdcAlpha);
		// now do special draw 
		pWgt = m_pWidgets;
		while (pWgt) {
			if (pWgt->m_WidgetClip) // was set up during prepare draw if required.
			{
				// Has some part within update rectangle, so perform any advanced draw and alpha operations
				pWgt->DrawAdvancedandAlpha(); // substitute back buffer for primary surface
			}
			pWgt = pWgt->m_pNextWgt;
		}
		// Here all updates are now ready to go to primary
		QRect dest = *pClipRect;
#ifndef UNDER_CE // required only for desktop builds		
		OffsetRect(&dest, m_pOpPanel->m_OutputRect.left, m_pOpPanel->m_OutputRect.top);
#endif
		// this blt is done in conjunction with our directdraw clipper
		// so will avoid any dialogs/menus etc.
		CURSOR_OFF;
		//E437415
		//DDBLT_WAIT flag is no longer supported for windows embedded ce 6.0
		//Use DDBLT_WAITNOTBUSY instead of DDBLT_WAIT in following statement
		//E519766
		//E529380 should do above changes only for CE compilation.
#ifdef UNDER_CE
		 hres=m_pOpPanel->m_pDDSPrimary->Blt(&dest, m_pOpPanel->m_pDDSBackBuffer, pClipRect, DDBLT_WAITNOTBUSY, NULL);	
#else
		hres = m_pOpPanel->m_pDDSPrimary->Blt(&dest, m_pOpPanel->m_pDDSBackBuffer, pClipRect, DDBLT_WAIT, NULL);
#endif
		CURSOR_ON;
		if (hres != 0) {
			m_pOpPanel->m_ResetDDrequired = TRUE;
		}
	} else // usual case - just doing repaints to objects due to data item table updates
	{
		// no need to fill with screen background colour (not an updating area, so will not be changed.)
		// for Each Widget, check to see if it has to be refreshed.
		CWidget *pWgt = m_pWidgets;
		while (pWgt) {
			if (pWgt->PrepareDraw(NULL)) // checks m_WidgetUpdateRequired flag
					{
				// Widget has some updating to be done, so Draw background 
				pWgt->DrawBackgound();
			}
			pWgt = pWgt->m_pNextWgt;
		}
		// now aquire HDC's for the surfaces, and perform all the Standard drawing.
		CURSOR_OFF; // delete cursor here (required for recorder since we may output to priamary here via hdcPrimary)
		HDC hdcPrimary;
		HDC hdcBackBuffer;
		HDC hdcAlpha;
#ifndef UNDER_CE
		HRESULT hr = m_pOpPanel->m_pDDSPrimary->GetDC(&hdcPrimary); // primary surface
#else
		HRESULT hr = S_OK;
#endif
		HRESULT hr1 = m_pOpPanel->m_pDDSBackBuffer->GetDC(&hdcBackBuffer); // back buffer
		HRESULT hr2 = m_pOpPanel->m_pDDSAlpha->GetDC(&hdcAlpha); // alpha buffer
#ifdef SHOW_CPU
		// Draw CPU % to screen
		float cpuUsage = GetCurrentCPUUtilization();
		QString csTxt ;
		
		csTxt = QString::asprintf("CPU: %.02f%s", cpuUsage,L"%");
		//txtRect will be the generic re-used box for drawing text
		QRect TxtRect;
		//draw the static text boxes
		TxtRect.left	= 50;
		TxtRect.right	= 200;
		TxtRect.top		= 65;
		TxtRect.bottom	= 65+100;
		
		SetTextColor(hdcBackBuffer,QString (0,0,255));
		DrawText(hdcBackBuffer, csTxt,-1,&TxtRect,DT_SINGLELINE|DT_LEFT);
#endif
		if (!FAILED(hr)) {
#ifndef UNDER_CE // For desktop, need to set this here again
			SelectClipRgn(hdcPrimary, m_hrgnUpdate);
#endif
			SelectClipRgn(hdcBackBuffer, NULL);
			SelectClipRgn(hdcAlpha, NULL);
#ifndef UNDER_CE
			QPoint previous;
			SetViewportOrgEx(hdcPrimary, m_pOpPanel->m_OutputRect.left, m_pOpPanel->m_OutputRect.top, &previous);
#endif
			// do a pass of all widgets
			CWidget *pWgt = m_pWidgets;
			while (pWgt) {
				if (pWgt->m_WidgetUpdateRequired) // for those widgets marked as requiring a repaint
#ifndef UNDER_CE
					pWgt->StandardDraw(hdcPrimary, hdcBackBuffer, hdcAlpha); // Standard Objects drawn now
#else
					pWgt->StandardDraw(hdcBackBuffer, hdcBackBuffer, hdcAlpha); // Standard Objects drawn now
#endif
				pWgt = pWgt->m_pNextWgt;
			}
#ifndef UNDER_CE
			// put back previous viewport origin
			SetViewportOrgEx(hdcPrimary, previous.x, previous.y, NULL);
#endif
#ifndef UNDER_CE
			m_pOpPanel->m_pDDSPrimary->ReleaseDC(hdcPrimary);
#endif
			// E529380 We should not release m_pDDSBackBuffer and m_pDDSAlpha DCs here 
			// as this is success case only for m_pDDSPrimary 
			// 100%CPU consumption issue fixed....
			/*m_pOpPanel->m_pDDSBackBuffer->ReleaseDC(hdcBackBuffer); 
			 m_pOpPanel->m_pDDSAlpha->ReleaseDC(hdcAlpha); */
		}
		// Release m_pDDSBackBuffer and m_pDDSAlpha DCs here
		// 100%CPU consumption issue fixed....
		if (SUCCEEDED(hr1))
			m_pOpPanel->m_pDDSBackBuffer->ReleaseDC(hdcBackBuffer);
		if (SUCCEEDED(hr2))
			m_pOpPanel->m_pDDSAlpha->ReleaseDC(hdcAlpha);
		// here all widgets requiring an update have painted all their updates to backbuffer, alpha and primary.
		// now bring them all together
		HRGN hrgnTotal;
		hrgnTotal = CreateRectRgn(0, 0, 0, 0); // empty region
		// run through all the widgets looking for those with updates flagged
		pWgt = m_pWidgets;
		while (pWgt) {
			if (pWgt->m_WidgetUpdateRequired) {
				// Has some updates due so perform any advanced draw and alpha operations
				pWgt->DrawAdvancedandAlpha();
				// add widgets region into the total region 
				CombineRgn(hrgnTotal, hrgnTotal, pWgt->m_UpdateRgn, RGN_OR); // union with hrgnTotal
			}
			pWgt = pWgt->m_pNextWgt;
		}
		// now we have all the widgets requiring an update in hrgnTotal
		// now exclude those that fall outside of window clipping.
#ifndef UNDER_CE // required only for desktop builds		
		// since m_hrgnUpdate is in screen co-ords, need to offset our total before combining
		OffsetRgn(hrgnTotal, m_pOpPanel->m_OutputRect.left, m_pOpPanel->m_OutputRect.top);
#endif
		int res = CombineRgn(hrgnTotal, hrgnTotal, m_hrgnUpdate, RGN_AND); // intersection
		if (res > NULLREGION) // check that we need to do a blt at all
				{
			int numbytes = GetRegionData(hrgnTotal, 0, NULL);
			if (numbytes) {
				// setting the cliplist with a screen co-ords region	
				m_pOpPanel->SetClipListBuffer(numbytes);
				GetRegionData(hrgnTotal, numbytes, m_pOpPanel->m_pClipList);
				m_pOpPanel->m_pDDClipper->SetClipList(m_pOpPanel->m_pClipList, 0);
			}
			// now back buffer to primary
			QRect dest;
			GetRgnBox(hrgnTotal, &dest); //screen co-ords
			QRect box = dest;
#ifndef UNDER_CE // required only for desktop builds		
			OffsetRect(&box, -m_pOpPanel->m_OutputRect.left, -m_pOpPanel->m_OutputRect.top); // to back buffer surface co-ords
#endif			
			//E437415
			//DDBLT_WAIT flag is no longer supported for windows embedded ce 6.0
			//Use DDBLT_WAITNOTBUSY instead of DDBLT_WAIT in following statement
			//E519766
			//E529380 should do above changes only for CE compilation.
#ifdef UNDER_CE
			hres=m_pOpPanel->m_pDDSPrimary->Blt(&dest, m_pOpPanel->m_pDDSBackBuffer, &box, DDBLT_WAITNOTBUSY, NULL);
#else
			hres = m_pOpPanel->m_pDDSPrimary->Blt(&dest, m_pOpPanel->m_pDDSBackBuffer, &box, DDBLT_WAIT, NULL);
#endif
			CURSOR_ON; // turned off above..
		}
		DeleteObject(hrgnTotal);
	}
	// put clipping back to initial state... (add this again if required)
	// m_pOpPanel->SetUpDefaultClip();
	// m_pOpPanel->m_pDDClipper->SetClipList(m_pOpPanel->m_pClipList,0);
	DeleteObject(m_hrgnUpdate);
	InterlockedDecrement(&m_pOpPanel->m_IsDrawing);
	if (pClipRect)
		m_DoneInitalDraw = TRUE; // done a WM_PAINT, so ok to start updates now
}
//****************************************************************************
///
/// Handler for mouse/touchscreen button down at runtime
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnMouseDownRuntime(UINT nFlags, QPoint &point) {
#ifndef DOCVIEW
	// see if we have a hidden status bar and now need to show it.
	if ((m_pCMMscreen->Enabled) && (!m_pOpPanel->m_pReplayScreen)) // anabled and not during replay
			{
		m_pOpPanel->m_MoveScreenTick = GetTickCount(); //reset here
		m_pOpPanel->m_DoScreenMove = TRUE;
		if (m_pTemplate != NULL && m_pTemplate->m_pCMMtemplate != NULL
				&& m_pTemplate->m_pCMMtemplate->StatusBar == FALSE) // no status bar 
		{
			if (!m_ScreenIsMoved) // and not already showing moved
			{
				m_ScreenIsMoved = TRUE;
				CTopStatusBar::Instance(m_pOpPanel)->SetVisibleSlide(TRUE);
				m_pOpPanel->Repaint();
				return; // finish early, first click used to show menu
			}
		}
	}
#endif
	// see if user has clicked on a Widget
	CWidget *pWgt = m_pWidgets;
	while (pWgt) {
		if (PtInRect(&pWgt->GetWidgetBounds(), point)) {
			// this is the widget clicked within. (no overlapping widgets allowed at runtime)
			// now see if an object is clicked or just the widget
			if (pWgt->OnMouseDownRuntime(nFlags, point) == FALSE) {
				// just the widget. show a menu here or something.
				m_pSelectedWidget = NULL;
			} else
				m_pSelectedWidget = pWgt;
			m_pLastSelectedWidget = pWgt;
			break; // all done here
		}
		pWgt = pWgt->m_pNextWgt;
	}
}
//****************************************************************************
///
/// Handler for mouse/touchscreen button down
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnMouseDown(UINT nFlags, QPoint &point) {
	// If we're performing a simulated move, where the user
	// wants to move an object or widget using one of the arrow
	// keys, then we're simulating an LButtonDown on the object
	// or widget, passing in point. In this case, we don't want
	// to select an object within a widget being moved nor do
	// we want to detect a hit on one of the widget's handles.
	// If an object is being moved, we also don't want to detect
	// a hit on one of the object's handles.
	CWidget *pWgt = m_pWidgets;
	if (m_pOpPanel->m_eSimulatedMove == SIMULATED_MOVE_OBJECT)
		m_pSelectedWidget->m_pSelectedObject->m_ResizeState = ResizeNone;
	else if (m_pOpPanel->m_eSimulatedMove == SIMULATED_MOVE_WIDGET)
		m_pSelectedWidget->m_WidgetResizeState = ResizeNone;
	else
		// ok to detect a hit on a handle
		while (pWgt) {
			if (pWgt->m_WidgetShowHandles) {
				// need to see if we have clicked on a handle
				if (pWgt->HitTestHandles(point)) {
					// yes, so we are resizing
					m_StartPoint = point;	// save starting point
					m_pSelectedWidget = pWgt;
					return;
				}
			}
			pWgt = pWgt->m_pNextWgt;
		}
	CWidget *pOldSelectedWidget = m_pSelectedWidget;
	if (m_pSelectedWidget)
		m_pSelectedWidget = NULL;
	// otherwise here we are looking to see if user has clicked on the Widget (not on its handles)
	QRect oldSelectionRect = { 0, 0, 0, 0 };
	QRect newSelectionRect = { 0, 0, 0, 0 };
	pWgt = m_pWidgets;
	while (pWgt) {
		if ((pWgt->m_WidgetShowHandles) || (pWgt == pOldSelectedWidget)) {
			oldSelectionRect = pWgt->GetWidgetBounds(); // original selection
			pWgt->m_WidgetShowHandles = FALSE;		 // turn off for now
			pWgt->m_pCMMwidget->IsSelected = FALSE;
		}
		if (PtInRect(&pWgt->GetWidgetBounds(), point))
			m_pSelectedWidget = pWgt; // the point is within the bounds of this object, so set as selected.
									  // need to keep checking as we work up the Z order, may be another later..
		pWgt = pWgt->m_pNextWgt;
	}
	// after doing the entire list we will have tested top of Z order last
	// selecting an Widget needs to bring it to top of Z order.
	if (m_pSelectedWidget) {
		BringWidgetToTop(m_pSelectedWidget);
		m_StartPoint = point;						// save starting point			
		newSelectionRect = m_pSelectedWidget->GetWidgetBounds();
		if (pOldSelectedWidget && (pOldSelectedWidget != m_pSelectedWidget)) {
			// here turn off all the objects that may have handles on in the old selected widget
			CBaseObject *pObj = pOldSelectedWidget->m_pObjects;
			while (pObj) {
				pObj->m_ShowHandles = FALSE;
				pObj->m_pCMMbase->IsSelected = FALSE;
				pObj = pObj->m_pNextObj;
			}
			pOldSelectedWidget->m_pSelectedObject = NULL;
		}
		// now see if an object is selected or the whole widget
		if (m_pSelectedWidget->OnMouseDown(nFlags, point) == FALSE) {
			m_pSelectedWidget->m_WidgetShowHandles = TRUE; // not on an object, so show the widget handles
			m_pSelectedWidget->m_pCMMwidget->IsSelected = TRUE;
			// Save cursor offset relative to selected widget.
			// This is used when we need to stick a sticky widget.
			m_ptCursorOffset.x = point.x - newSelectionRect.left;
			m_ptCursorOffset.y = point.y - newSelectionRect.top;
			// Clip the cursor so that it stays on the same spot of
			// the selected widget within the bounds of the OpPanel.
#ifndef DOCVIEW
			// Set up indents of the cursor within the selected widget.
			// We will then transfer these indents to the OpPanel as the
			// clipping rectangle.
			int nleftIndent = point.x - newSelectionRect.left;
			int nTopIndent = point.y - newSelectionRect.top;
			int nrightIndent = newSelectionRect.right - point.x;
			int nBottomIndent = newSelectionRect.bottom - point.y;
			QRect desktop = m_pOpPanel->m_DesktopRect;
			if (m_ScreenIsMoved) {
				desktop.setTop(m_pOpPanel)->m_moveOffset;
				desktop.setBottom(m_pOpPanel)->m_moveOffset;
			}
			// Set up the clipping rectangle to be the OpPanel bounds
			// in screen coordinates and transfer widget indents to it.
			// Need to add one to right and bottom else clip too soon.
			QRect rcClip(desktop);
			rcClip.setLeft(nleftIndent);
			rcClip.setTop(nTopIndent);
			rcClip.setRight(nrightIndent) - 1;
			rcClip.setBottom(nBottomIndent) - 1;
			::ClipCursor(rcClip);
#else // DOCVIEW
			// Compute the widget rectangle relative to (0,0) on the
			// scrollable drawing surface, regardless of our current
			// scroll position.
			QRect WidgetRect(m_pSelectedWidget->GetWidgetBounds());
			WidgetRect.OffsetRect(m_pOpPanel->GetDeviceScrollPosition());
			QRect OpPanelRect;
			m_pOpPanel->OpPanelRect = rect();
			// Determine how far we can travel in each direction from
			// the mouse down point so that we can set up a clipping
			// rectangle for the cursor to be within the bounds of the
			// OpPanel. For example, we can travel left from the mouse
			// down point until we reach either the left side of the
			// OpPanel (point.x) or the left side of the scrollable
			// drawing surface (WidgetRect.left).
			int nleftTravel=__min(point.x, WidgetRect.left);
			int nTopTravel=__min(point.y, WidgetRect.top);
			int nrightTravel=__min(OpPanelRect.right-point.x, SCROLLABLE_DRAWING_SURFACE-WidgetRect.right);
			int nBottomTravel=__min(OpPanelRect.bottom-point.y, SCROLLABLE_DRAWING_SURFACE-WidgetRect.bottom);
			QPoint ptOrigin(point);
			m_pOpPanel->ClientToScreen(&ptOrigin);
			QRect rcClip(ptOrigin.x-nleftTravel,
						 ptOrigin.y-nTopTravel,
						 ptOrigin.x+nrightTravel,
						 ptOrigin.y+nBottomTravel);
			::ClipCursor(rcClip);
#endif
			// Object not selected - force link mode off.
			m_pOpPanel->m_bLinkMode = FALSE;
			m_pOpPanel->m_pLinkSelectedObject = NULL;
		}
//		m_pSelectedWidget->m_PermValid=FALSE; // any moving or resizing causes reload of perm surface Objects for this Widget
	} else // widget not selected, so object not selected - force link mode off
	{
		m_pOpPanel->m_bLinkMode = FALSE;
		m_pOpPanel->m_pLinkSelectedObject = NULL;
	}
	// here we now make the union of the two rectangles (old and new)
	// and repaint the total area.
	UnionRect(&newSelectionRect, &oldSelectionRect, &newSelectionRect);
	if (!IsRectEmpty(&newSelectionRect)) {
		InflateRect(&newSelectionRect, GRABSIZE, GRABSIZE); // allow for grab handles (on all sides)
//		OutputDebugString(L" Before invalidate\n");
		InvalidateArea(newSelectionRect);
//		OutputDebugString(L"		After invalidate\n");
	}
}
//****************************************************************************
///
/// Mouse/touchscreen Move handler at runtime
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnMouseMoveRuntime(UINT nFlags, QPoint &point) {
	// do we have a Widget selected? (for runtime implies there is an object on it selected)
	if (m_pSelectedWidget)
		if (m_pSelectedWidget->m_pSelectedObject)
			m_pSelectedWidget->m_pSelectedObject->OnMouseMove(nFlags, point); // pass it down to the Object
}
//****************************************************************************
///
/// Mouse/touchscreen Move handler
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnMouseMove(UINT nFlags, QPoint &point) {
	int diffX = point.x - m_StartPoint.x;
	int diffY = point.y - m_StartPoint.y;
	m_StartPoint = point; // update the starting point for next move
	// do we have a Widget selected?
	if (m_pSelectedWidget) {
		// is it a Widget operation or Objects within it?
		if (!m_pSelectedWidget->m_WidgetShowHandles)
			m_pSelectedWidget->OnMouseMove(nFlags, point); // pass it down to the Widget (for Object operations)
		else {
			// Widget resizing/moving operation
			m_CheckpointRequired = TRUE; // need to perform a checkpoint when the move is complete
			QRect bounds = m_pSelectedWidget->GetWidgetBounds();
			QRect oldBounds = bounds;
			// get the bounding rectangle of our contents, anchored at the top of the Widget.
			// need to anchor the top left corner (since this part does not change)
			int border = m_pSelectedWidget->GetWidgetBorder();
			QRect contents = bounds;
			contents.setright(contents).left + border;
			contents.setBottom(contents).top + border;
			if (border == 0) {
				contents.right++;
				contents.bottom++;
			}
			CBaseObject *pObj = m_pSelectedWidget->m_pObjects;
			while (pObj) {
				UnionRect(&contents, &contents, &pObj->GetBounds());
				pObj = pObj->m_pNextObj;
			}
			if (m_pSelectedWidget->m_WidgetResizeState != ResizeNone) {
				// Handle sticky widgets mode.
				BOOL stick = FALSE;
				int newtop;
				int newbottom;
				int newleft;
				int newright;
				int nJumpX; // how much to jump when sticking a widget
				int nJumpY; // how much to jump when sticking a widget
				switch (m_pSelectedWidget->m_WidgetResizeState) {
				case Topleft:
					bounds.setTop(diffY);
					bounds.setLeft(diffX);
					if (IsNearHoriz(bounds.top, newtop)) {
						nJumpX = 0;
						nJumpY = newtop - bounds.top;
						bounds.setTop(newtop);
						stick = TRUE;
					}
					if (IsNearVert(bounds.left, newleft)) {
						nJumpX = newleft - bounds.left;
						if (!stick) // don't overwrite horiz results above!
							nJumpY = 0;
						bounds.setleft(newleft);
						stick = TRUE;
					}
					break;
				case Topmiddle:
					bounds.setTop(diffY);
					if (IsNearHoriz(bounds.top, newtop)) {
						nJumpX = 0;
						nJumpY = newtop - bounds.top;
						bounds.setTop(newtop);
						stick = TRUE;
					}
					break;
				case Topright:
					bounds.setTop(diffY);
					bounds.setRight(diffX);
					if (IsNearHoriz(bounds.top, newtop)) {
						nJumpX = 0;
						nJumpY = newtop - bounds.top;
						bounds.setTop(newtop);
						stick = TRUE;
					}
					if (IsNearVert(bounds.right, newright)) {
						nJumpX = newright - bounds.right;
						if (!stick) // don't overwrite horiz results above!
							nJumpY = 0;
						bounds.setright(newright);
						stick = TRUE;
					}
					break;
				case rightmiddle:
					bounds.setRight(diffX);
					if (IsNearVert(bounds.right, newright)) {
						nJumpX = newright - bounds.right;
						nJumpY = 0;
						bounds.setright(newright);
						stick = TRUE;
					}
					break;
				case Bottomright:
					bounds.setBottom(diffY);
					bounds.setRight(diffX);
					if (IsNearVert(bounds.right, newright)) {
						nJumpX = newright - bounds.right;
						nJumpY = 0;
						bounds.setright(newright);
						stick = TRUE;
					}
					if (IsNearHoriz(bounds.bottom, newbottom)) {
						if (!stick) // don't overwrite vert results above!
							nJumpX = 0;
						nJumpY = newbottom - bounds.bottom;
						bounds.setBottom(newbottom);
						stick = TRUE;
					}
					break;
				case Bottommiddle:
					bounds.setBottom(diffY);
					if (IsNearHoriz(bounds.bottom, newbottom)) {
						nJumpX = 0;
						nJumpY = newbottom - bounds.bottom;
						bounds.setBottom(newbottom);
						stick = TRUE;
					}
					break;
				case Bottomleft:
					bounds.setBottom(diffY);
					bounds.setLeft(diffX);
					if (IsNearVert(bounds.left, newleft)) {
						nJumpX = newleft - bounds.left;
						nJumpY = 0;
						bounds.setleft(newleft);
						stick = TRUE;
					}
					if (IsNearHoriz(bounds.bottom, newbottom)) {
						if (!stick) // don't overwrite vert results above!
							nJumpX = 0;
						nJumpY = newbottom - bounds.bottom;
						bounds.setBottom(newbottom);
						stick = TRUE;
					}
					break;
				case leftmiddle:
					bounds.setLeft(diffX);
					if (IsNearVert(bounds.left, newleft)) {
						nJumpX = newleft - bounds.left;
						nJumpY = 0;
						bounds.setleft(newleft);
						stick = TRUE;
					}
					break;
				default:
					break;
				}
				if (stick) {
					m_StartPoint.x += nJumpX;
					m_StartPoint.y += nJumpY;
					QPoint cursorpoint(point.x + nJumpX, point.y + nJumpY);
					m_pOpPanel->ClientToScreen(&cursorpoint);
					::SetCursorPos(cursorpoint.x, cursorpoint.y); // stop cursor slipping off handle
				}
				// now check new size against resizing limits of Widget
				// need to check in this way to keep position
				int minWidth = border * 3;
				int minHeight = border * 3;
				// Cannot resize smaller than contents
				if (minWidth < _Width(contents))
					minWidth = _Width(contents);
				if (minHeight < _Height(contents))
					minHeight = _Height(contents);
				// now check against limits..
				switch (m_pSelectedWidget->m_WidgetResizeState) {
				// LEFT
				case Topleft:
				case leftmiddle:
				case Bottomleft:
					if (_Width(bounds) - border < minWidth)
						bounds.setleft(bounds).right - border - minWidth;
					break;
				default:
					break;
				}
				switch (m_pSelectedWidget->m_WidgetResizeState) {
				// TOP
				case Topleft:
				case Topmiddle:
				case Topright:
					if (_Height(bounds) - border < minHeight)
						bounds.setTop(bounds).bottom - border - minHeight;
					break;
				default:
					break;
				}
				switch (m_pSelectedWidget->m_WidgetResizeState) {
				// RIGHT
				case Topright:
				case rightmiddle:
				case Bottomright:
					if (bounds.right - border < bounds.left + minWidth)
						bounds.setright(bounds).left + border + minWidth;
					break;
				default:
					break;
				}
				switch (m_pSelectedWidget->m_WidgetResizeState) {
				// BOTTOM
				case Bottomleft:
				case Bottommiddle:
				case Bottomright:
					if (bounds.bottom - border < bounds.top + minHeight)
						bounds.setBottom(bounds).top + border + minHeight;
					break;
				default:
					break;
				}
				// NOTE: The following doesn't apply to Screen Designer because we
				// do allow the user to resize a widget outside the boundary of the
				// screen, since Screen Designer supports scrolling and a blank area
				// around the screen.
#ifndef DOCVIEW
				// check resizing against Screen here...
				if (bounds.left < m_ScreenClientRect.left)
					bounds.setleft(m_ScreenClientRect).left;
				if (bounds.top < m_ScreenClientRect.top)
					bounds.setTop(m_ScreenClientRect).top;
				if (bounds.right > m_ScreenClientRect.right)
					bounds.setright(m_ScreenClientRect).right;
				if (bounds.bottom > m_ScreenClientRect.bottom)
					bounds.setBottom(m_ScreenClientRect).bottom;
#endif
			} else {
				// moving 
				OffsetRect(&bounds, diffX, diffY);
				// NOTE: The following doesn't apply to Screen Designer because we
				// do allow the user to move a widget outside the boundary of the
				// screen, since Screen Designer supports scrolling and a blank area
				// around the screen.
#ifndef DOCVIEW
				// if it has moved outside the boundary of the Screen, set it back 		
				if (bounds.left < m_ScreenClientRect.left)
					OffsetRect(&bounds, m_ScreenClientRect.left - bounds.left, 0);
				if (bounds.top < m_ScreenClientRect.top)
					OffsetRect(&bounds, 0, m_ScreenClientRect.top - bounds.top);
				if (bounds.right > m_ScreenClientRect.right)
					OffsetRect(&bounds, m_ScreenClientRect.right - bounds.right, 0);
				if (bounds.bottom > m_ScreenClientRect.bottom)
					OffsetRect(&bounds, 0, m_ScreenClientRect.bottom - bounds.bottom);
#endif
				// Handle sticky widgets mode.
				BOOL stick = FALSE;
				int newtop;
				int newbottom;
				int newleft;
				int newright;
				int nJumpX; // how much to jump when sticking a widget
				int nJumpY; // how much to jump when sticking a widget
				if (IsNearHoriz(bounds.top, newtop)) {
					nJumpX = 0;
					nJumpY = newtop - bounds.top;
					stick = TRUE;
				} else if (IsNearHoriz(bounds.bottom, newbottom)) {
					nJumpX = 0;
					nJumpY = newbottom - bounds.bottom;
					stick = TRUE;
				}
				if (IsNearVert(bounds.left, newleft)) {
					nJumpX = newleft - bounds.left;
					if (!stick) // don't overwrite horiz results above!
						nJumpY = 0;
					stick = TRUE;
				} else if (IsNearVert(bounds.right, newright)) {
					nJumpX = newright - bounds.right;
					if (!stick) // don't overwrite horiz results above!
						nJumpY = 0;
					stick = TRUE;
				}
				if (stick) {
					OffsetRect(&bounds, nJumpX, nJumpY);
					m_StartPoint.x += nJumpX;
					m_StartPoint.y += nJumpY;
					QPoint cursorpoint(bounds.left + m_ptCursorOffset.x, bounds.top + m_ptCursorOffset.y);
					m_pOpPanel->ClientToScreen(&cursorpoint);
					::SetCursorPos(cursorpoint.x, cursorpoint.y); // stop cursor slipping off widget
				}
			}
			// Here the bounds have been validated. Apply to the Widget.
			//m_pSelectedWidget->SetWidgetBounds(&bounds);
			m_pOpPanel->UpdateBounds(&bounds, &m_pSelectedWidget->GetLayoutItem()); // apply to all Widgets on all screens using template
			// now (if required) move objects the same amount !!
			diffX = bounds.left - oldBounds.left;
			diffY = bounds.top - oldBounds.top;
			if ((diffX != 0) || (diffY != 0)) {
				pObj = m_pSelectedWidget->m_pObjects;
				while (pObj) {
					QRect objBounds = pObj->GetBounds();
					OffsetRect(&objBounds, diffX, diffY);
					//pObj->SetBounds(&objBounds);
					m_pOpPanel->UpdateBounds(&objBounds, &m_pSelectedWidget->GetLayoutItem(), &pObj->GetLayoutItem()); // apply to all objects on all screens using template
					pObj = pObj->m_pNextObj;
				}
			}
			m_pSelectedWidget->m_PermValid = FALSE; // any moving or resizing causes reload of perm surface Objects for this Widget
			// here we want to invalidate the area around the object, so we repaint the parts that 
			// need updating only
			UnionRect(&bounds, &oldBounds, &bounds);
			InflateRect(&bounds, GRABSIZE, GRABSIZE); // allow for grab handles
			//OutputDebugString(L" Before invalidate\n");
			InvalidateArea(bounds);
			//OutputDebugString(L"		After invalidate\n");
		}
	}
}
//****************************************************************************
///
/// Handler for mouse/touchscreen up at runtime
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnMouseUpRuntime(UINT nFlags, QPoint &point) {
	if (m_pSelectedWidget)
		if (m_pSelectedWidget->m_pSelectedObject)
			m_pSelectedWidget->m_pSelectedObject->OnMouseUp(nFlags, point); // pass it down to the Object
	m_pSelectedWidget = NULL;
	// here for replay mode check to see which digital was selected
	if (m_pCMMscreen->Type == TPL_REPLAY) {
		OnReplayWidgetClick();
	}
}
//****************************************************************************
///
/// Handler for mouse/touchscreen clicked Widget in replay at runtime
///
/// @param[in] none
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnReplayWidgetClick() {
	if (m_pLastSelectedWidget && (!m_pLastSelectedWidget->ContainsMultiPenObj())) // not chart or penpointer, so must be DPM
			{
		// here must be DPM
		// want to remove/re-add the pen trace to the chart and disable/enable DPM.
		// get the parent channel from the top of the Widget channel list
		int channel = m_pLastSelectedWidget->m_pCMMwidget->ChannelList[0];
		// now map channel to replay maxmin index (used in the DPM's)
		int index = ChannelToInstance(channel);
		// This gives us the index into the list of pens for replay (held in the canned pens for the screen)
		// re-use the DPM flag - normally for canned screens but fine here for replay
		// if it is currently disabled, allow enable
		// E527303
		//if(!m_pCMMscreen->CannedPens[index].Dpm)
		//	m_pCMMscreen->CannedPens[index].Dpm=TRUE;
		if (!m_pCMMscreen->ReplayPens[index].Dpm)
			m_pCMMscreen->ReplayPens[index].Dpm = TRUE;
		else {
			// here check this is not the last enabled dpm (must always keep 1)
			int dpmsOn = 0;
			for (int i = 0; i < m_pencount; i++) {
				// E527303
				//if(m_pCMMscreen->CannedPens[i].Dpm)
				if (m_pCMMscreen->ReplayPens[i].Dpm)
					if (++dpmsOn > 1)
						break; // found more than 1 so ok.
			}
			if (dpmsOn > 1) {
				//m_pCMMscreen->CannedPens[index].Dpm=FALSE; // allowed to do it //E527303
				m_pCMMscreen->ReplayPens[index].Dpm = FALSE;
			} else
				sndPlaySound(L"Default.wav", SND_FILENAME | SND_ASYNC | SND_NOSTOP); // play default sound to indicate can't be done
		}
		// need to set up the maxmin replay entries in the data item table.
		CDataItemPen *m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_MM_REPLAY, index);
		//E527303
		//m_pPenDataItem->SetEnabled(m_pCMMscreen->CannedPens[index].Dpm);
		m_pPenDataItem->SetEnabled(m_pCMMscreen->ReplayPens[index].Dpm);
		m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_MM_REPLAY, index + MAX_REPLAY_PENS);
		//E527303
		//m_pPenDataItem->SetEnabled(m_pCMMscreen->CannedPens[index].Dpm);
		m_pPenDataItem->SetEnabled(m_pCMMscreen->ReplayPens[index].Dpm);
		//if(m_pCMMscreen->CannedPens[index].Dpm)
		if (m_pCMMscreen->ReplayPens[index].Dpm)
			m_pLastSelectedWidget->ChangeWidgetBackground(QString(255, 255, 255));
		else
			//m_pLastSelectedWidget->ChangeWidgetBackground(pOEM_INFO->GetColour( V6RES_COLOUR_STATUSBAR_BKG )->pColor); // get nice blue for honeywell
			m_pLastSelectedWidget->ChangeWidgetBackground(QString(171, 191, 209)); // get nice blue for honeywell
		m_pLastSelectedWidget->ConfigChange(); // reconfigure DPM Widget
		if (m_pOpPanel->m_pReplayChartObject)
			m_pOpPanel->m_pReplayChartObject->ConfigChange(); // reconfigure chart
		m_pOpPanel->Repaint();
	}
}
//****************************************************************************
///
/// Handler for mouse/touchscreen up
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnMouseUp(UINT nFlags, QPoint &point) {
	::ClipCursor(NULL);
	if (m_pSelectedWidget)
		m_pSelectedWidget->OnMouseUp(nFlags, point); // pass it down to the Widget (for Object operations)
	if (m_CheckpointRequired) {
#ifdef DOCVIEW
		m_pOpPanel->GetDocument()->Checkpoint(L"Adjust Widget"); ///@todo get string from string table
#endif
		m_CheckpointRequired = FALSE;
	}
}
//****************************************************************************
///
/// Handler for keypresses (run mode only, pass onto Object)
///
/// @param[in] ch	- character
/// 
/// @return none
/// 
//****************************************************************************	
void CScreen::OnChar(wchar_t ch) {
	if (m_pSelectedWidget)
		if (m_pSelectedWidget->m_pSelectedObject)
			m_pSelectedWidget->m_pSelectedObject->OnChar(ch); // pass it down to the Object
}
//****************************************************************************
///
/// Screen's ConfigChange function, called after changes to properties
/// or a setup configuration change
///
/// @param none
/// @return none
/// 
//****************************************************************************	
void CScreen::ConfigChange() {
	m_DoneInitalDraw = FALSE; // to ensure we get a full draw afterwards. (via WM_PAINT)
	InterlockedIncrement(&m_pOpPanel->m_Inactive); // prevent OpPanel refresh's drawing for now
	CLayoutItem::ConfigChange();
	// here check to see if we need to change the screen type back to TPL_CUSTOM from its temporary template index value
	if ((m_pCMMscreen->Type < TPL_CUSTOM) && (m_pCMMscreen->Type >= TPL_LAST_CANNED) && !IsNonProcessScreen()) {
		// here a user has changed the type. need use the value to find the template instance
		int templno = m_pCMMscreen->Type - TPL_LAST_CANNED;
		// now find the templno'th template 
		CTemplate *ptpl = m_pOpPanel->m_pTemplates;
		int count = 0;
		while ((count < templno) && ptpl) {
			ptpl = ptpl->m_pNextTpt;
			count++;
		}
		//	NB: for this to work CMM needs to be modifiable here
		if (ptpl)
			m_pCMMscreen->Template = ptpl->GetLayoutItem(); // set the type and instance here.
		m_pCMMscreen->Type = TPL_CUSTOM; // update the type here  
		if (this->m_pOpPanel->m_pMainConfig->GetCMMmode() == CONFIG_COMMITTED)
			qDebug("MODIFYING a COMITTED CONFIG\n");
	}
	CWidget *pWidget = m_pWidgets;
	while (pWidget) {
		pWidget->ConfigChange();
		pWidget = pWidget->m_pNextWgt;
	}
	InterlockedDecrement(&m_pOpPanel->m_Inactive); // to allow drawing again.
}
QString CScreen::GetId() {
	QString sId;
	if (GetLayoutItem().CMM_Inst == TEMPLATE_SCREEN_INST)
		sId = m_pTemplate->GetId();
	else
		sId = QString::asprintf("Screen %d - '%s'", m_pCMMscreen->Number, m_pCMMscreen->Name);
	return sId;
}
//****************************************************************************
// const bool SetScreenInstance( const USHORT usWIDGET_CHAN_NUM, const USHORT usREQUIRED_INSTANCE )
///
/// Method that sets the screen instnace corresponding to the widget channel number
///
/// @param[in]			const USHORT usWIDGET_CHAN_NUM - The widget channel number
/// @param[in]			const USHORT usREQUIRED_INSTANCE - The required instance number
/// 
/// @return				True if the instance number was updated okay
/// 
//****************************************************************************	
const bool CScreen::SetScreenInstance(const USHORT usWIDGET_CHAN_NUM, const USHORT usREQUIRED_INSTANCE) {
	// check the widget is within the correct range
	bool bSuccess = false;
	if (usWIDGET_CHAN_NUM >= CWidget::ms_usCHANNEL_OFFSET) {
		const USHORT usSCREEN_INDEX = usWIDGET_CHAN_NUM - CWidget::ms_usCHANNEL_OFFSET;
		m_pCMMscreen->ChannelMap[usSCREEN_INDEX] = usREQUIRED_INSTANCE;
		bSuccess = true;
	}
	return bSuccess;
}
BOOL CScreen::IsNearHoriz(int nHoriz, int &nHorizNear) {
	if (!COpPanel::m_bStickyWidgets)
		return FALSE;
	QRect RecorderRect(m_pOpPanel->m_RecScreenArea);
	if (m_pTemplate->m_pCMMtemplate->StatusBar)
		if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
			RecorderRect.setTop(MINI_STATUS_BAR_HEIGHT);
		else
			RecorderRect.setTop(MINI_EZ_STATUS_BAR_HEIGHT);
	// first check against recorder screen
	if (abs(RecorderRect.top - nHoriz) <= 2) {
		nHorizNear = RecorderRect.top;
		return TRUE;
	}
	if (abs(RecorderRect.bottom - nHoriz) <= 2) {
		nHorizNear = RecorderRect.bottom;
		return TRUE;
	}
	// then through widgets based on Z order
	CWidget *pWgt = m_pWidgets;
	while (pWgt) {
		if (pWgt != m_pSelectedWidget) // don't check ourselves
				{
			QRect baserect(pWgt->GetWidgetBounds());
			if (abs(baserect.top - nHoriz) <= 2) {
				nHorizNear = baserect.top;
				return TRUE;
			}
			if (abs(baserect.bottom - nHoriz) <= 2) {
				nHorizNear = baserect.bottom;
				return TRUE;
			}
		}
		pWgt = pWgt->m_pNextWgt;
	}
	return FALSE;
}
BOOL CScreen::IsNearVert(int nVert, int &nVertNear) {
	if (!COpPanel::m_bStickyWidgets)
		return FALSE;
	QRect RecorderRect(m_pOpPanel->m_RecScreenArea);
	if (m_pTemplate->m_pCMMtemplate->StatusBar)
		if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
			RecorderRect.setTop(MINI_STATUS_BAR_HEIGHT);
		else
			RecorderRect.setTop(MINI_EZ_STATUS_BAR_HEIGHT);
	// first check against recorder screen
	if (abs(RecorderRect.left - nVert) <= 2) {
		nVertNear = RecorderRect.left;
		return TRUE;
	}
	if (abs(RecorderRect.right - nVert) <= 2) {
		nVertNear = RecorderRect.right;
		return TRUE;
	}
	// then through widgets based on Z order
	CWidget *pWgt = m_pWidgets;
	while (pWgt) {
		if (pWgt != m_pSelectedWidget) // don't check ourselves
				{
			QRect baserect(pWgt->GetWidgetBounds());
			if (abs(baserect.left - nVert) <= 2) {
				nVertNear = baserect.left;
				return TRUE;
			}
			if (abs(baserect.right - nVert) <= 2) {
				nVertNear = baserect.right;
				return TRUE;
			}
		}
		pWgt = pWgt->m_pNextWgt;
	}
	return FALSE;
}
//****************************************************************************
///
/// Unselect all widgets and objects
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CScreen::UnselectAll() {
	CWidget *pWgt = m_pWidgets;
	while (pWgt) {
		CBaseObject *pObj = pWgt->m_pObjects;
		while (pObj) {
			pObj->m_ShowHandles = FALSE;
			pObj->m_pCMMbase->IsSelected = FALSE;
			pObj = pObj->m_pNextObj;
		}
		pWgt->m_WidgetShowHandles = FALSE;
		pWgt->m_pCMMwidget->IsSelected = FALSE;
		pWgt->m_pSelectedObject = NULL;
		pWgt = pWgt->m_pNextWgt;
	}
	m_pSelectedWidget = NULL;
}
//****************************************************************************
///
/// Method that populates the tabular process screen
/// 
/// @param[in]		const QRect tSCREEN_AREA - The screen area that we must fully populate
/// @param[in]		const int iPEN_COUNT - The number of pens configured for this canned screen
///
//****************************************************************************
void CScreen::PopulateTabularProcessScreen(const QRect tSCREEN_AREA, const int iPEN_COUNT) {
	// this is a tabular display template
	QRect res = tSCREEN_AREA;
#ifdef DOCVIEW
	// need to offset the rect here, since AddNewWidget expects screen co-ords.
	OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
	// add the widget that will contain the tabular display object
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
		m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
		// make the tabular object use the maximum possible are of the widget
		QRect TabularRect;
		SetRect(&TabularRect, 0, 0, _Width(tSCREEN_AREA), _Height(tSCREEN_AREA));
		// create the tabular display object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TABULAROBJECT, &TabularRect)) {
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->Border.BorderUsed = FALSE; // turn border off for tabular display object
			// always fix the background colour
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->FixBackColour = TRUE;
			// always make the background colour white and thus non-configurable
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->BackColour = 0xFFFFFF;
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->FixForeColour = m_pCMMscreen->FixForeColour;
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->ForeColour = m_pCMMscreen->ForeColour;
			CTabularDisplayObject *pkTabularDisplayObj = (CTabularDisplayObject*) m_pSelectedWidget->m_pSelectedObject;
			// setup the widget channel list based on the canned screen pen selection
			for (int i = 0; i < iPEN_COUNT; i++) {
				SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[i],
						m_pCMMscreen->CannedPens[i].PenIndex);
			}
			// update the config
			m_pSelectedWidget->ConfigChange();
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create the tabular display object, %s", m_pCMMscreen->Name);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	} else {
		QString strError("");
		strError = QString::asprintf("Failed to create tabular display widget, %s", m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
///
/// Method that populates the AMS2750 process screen
/// 
/// @param[in]		const QRect tSCREEN_AREA - The screen area that we must fully populate
/// @param[in]		const int iPEN_COUNT - The number of pens configured for this canned screen
/// @param[in]		const int iSCALE_COUNT - The number of pen scales configured for this canned screen
///
//****************************************************************************
void CScreen::PopulateAMS2750ProcessScreen(const QRect tSCREEN_AREA, const int iPEN_COUNT, const int iSCALE_COUNT) {
	bool bFoundObjectError = false;
	// this is a AMS2750 process screen template
	QRect tScreenRect = tSCREEN_AREA;
#ifdef DOCVIEW
	// need to offset the rect here, since AddNewWidget expects screen co-ords.
	OffsetRect(&tScreenRect,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
	// check if this is an SX or a QX/QXe
	if (m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS
			|| m_pOpPanel->m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS) {
		// this is an SX therefore we must essentially show a DPM/Chart/Bars screen with an area at
		// the bottom reserved for the AMS2750 furnace status
		QRect tAMS2750StatusRect;
		QRect DPMArea = tSCREEN_AREA;
		QRect tRemainingScreenArea = tSCREEN_AREA;
		const int iAMS2750_STATUS_AREA_HIEGHT = 100;
		// set up the DPM Area - we get one for each canned pen that exists.
		// we have DPM's.
		if (iPEN_COUNT < 5) // the DPMs will need to run along the bottom of the screen
				{
			// setup the AMS2750 status area
			tAMS2750StatusRect = tSCREEN_AREA;
			// run along the entire width of the screen but reduce the height
			tAMS2750StatusRect.setTop(tAMS2750StatusRect).bottom - iAMS2750_STATUS_AREA_HIEGHT;
			// reduce the DPM area accordingly
			DPMArea.setBottom(tAMS2750StatusRect).top;
			// here the DPM's run along the bottom of the screen but above the AMS2750 status
			DPMArea.setTop(DPMArea).bottom - 24; // DPM height
			tRemainingScreenArea.setBottom(DPMArea).top; // reduce the remaining screenArea
			int dpmwidth = _Width(DPMArea) / iPEN_COUNT;
			// now create the widgets required and DPM contents. (each pen gets a DPM)
			for (int i = 0; i < iPEN_COUNT; i++) {
				QRect res = DPMArea;
				res.setLeft(i) * dpmwidth;
				if (i < iPEN_COUNT - 1)
					res.setright(res).left + dpmwidth;
#ifdef DOCVIEW
				// need to offset the rect here, since AddNewWidget expects screen co-ords.
				OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
				if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
					m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
					m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
					if (AddDPMContents(m_pOpPanel->m_pCannedConfig, m_pCMMscreen->CannedPens[i].PenIndex, FALSE, FALSE)) // no maxmin or total
							{
						m_pSelectedWidget->ConfigChange();
					} else {
						QString strError("");
						strError = QString::asprintf("Failed to create all DPM objects, %s, Pen %u", m_pCMMscreen->Name,
								m_pCMMscreen->CannedPens[i].PenIndex + 1);
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
					}
				} else {
					QString strError("");
					strError = QString::asprintf("Failed to create DPM widget, %s, Pen %u", m_pCMMscreen->Name,
							m_pCMMscreen->CannedPens[i].PenIndex + 1);
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
				}
			}
		} else {
			DPMArea.setleft(DPMArea).right - 54; // DPM width
			tRemainingScreenArea.setright(DPMArea).left; // reduce the screenArea
			// now setup the AMS2750 status area
			tAMS2750StatusRect = tRemainingScreenArea;
			tAMS2750StatusRect.setTop(tAMS2750StatusRect).bottom - iAMS2750_STATUS_AREA_HIEGHT;
			tRemainingScreenArea.setBottom(tAMS2750StatusRect).top;
			int dpmheight = _Height(DPMArea) / iPEN_COUNT;
			// now create the widgets required and DPM contents. (each pen gets a DPM)
			for (int i = 0; i < iPEN_COUNT; i++) {
				QRect res = DPMArea;
				res.setTop(i) * dpmheight;
				if (i < iPEN_COUNT - 1)
					res.setBottom(res).top + dpmheight;
#ifdef DOCVIEW
				// need to offset the rect here, since AddNewWidget expects screen co-ords.
				OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
				if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
					m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
					m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
					if (AddDPMContents(m_pOpPanel->m_pCannedConfig, m_pCMMscreen->CannedPens[i].PenIndex, FALSE, FALSE)) // no maxmin or total
							{
						m_pSelectedWidget->ConfigChange();
					} else {
						QString strError("");
						strError = QString::asprintf("Failed to create all DPM objects, %s, Pen %u", m_pCMMscreen->Name,
								m_pCMMscreen->CannedPens[i].PenIndex + 1);
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
					}
				} else {
					QString strError("");
					strError = QString::asprintf("Failed to create DPM widget, %s, Pen %u", m_pCMMscreen->Name,
							m_pCMMscreen->CannedPens[i].PenIndex + 1);
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
				}
			}
		}
		// set up the Indicator (scale+pointer/bar + alarm mks) area (always 1)
		QRect ScaleArea = tRemainingScreenArea;
		int numCreateScales = iSCALE_COUNT;
		if (numCreateScales == 0) {
			numCreateScales++; // default is always 1 scale
			m_pCMMscreen->CannedPens[0].Scale = TRUE; // use first pen. set it here.
		}
		// check here for rotating bars...
		if (m_pCMMscreen->IsRotate) {
			numCreateScales = 1; // for rotating, or for DPM's only, we only have 1 scale.
			m_pCMMscreen->CannedPens[0].Scale = TRUE; // make sure first pen has a scale. set it here.
		}
		BOOL HasAlarmMarkers = TRUE; // the default is to always have alarm markers.
		int scalethickness;
		if (m_pCMMscreen->IsVert) {
			// vertical chart has horizontal scale(s)
			scalethickness = 33;
			if (numCreateScales > 1)
				scalethickness = 20;
			if (numCreateScales > 4)
				scalethickness = 16;
			ScaleArea.setBottom(ScaleArea).top + (numCreateScales * scalethickness);
			tRemainingScreenArea.setTop(ScaleArea).bottom;
		} else {
			// horizontal chart has vertical scale(s)
			scalethickness = 51;
			if (numCreateScales > 1)
				scalethickness = 41;
			if (numCreateScales > 4)
				scalethickness = 21;
			ScaleArea.setleft(ScaleArea).right - (numCreateScales * scalethickness);
			tRemainingScreenArea.setright(ScaleArea).left;
		}
		// First create the Chart.
		// ScreenArea now contains area remaining for the CHART
		// add the widget
#ifdef DOCVIEW
		// need to offset the rect here, since AddNewWidget expects screen co-ords.
		OffsetRect(&tRemainingScreenArea,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
		if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tRemainingScreenArea)) {
			// now add the Chart Object (at relative 0,0 to widget)
			QRect ChartRect;
			SetRect(&ChartRect, 0, 0, _Width(tRemainingScreenArea), _Height(tRemainingScreenArea));
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_CHARTOBJECT, &ChartRect)) {
				((T_CHARTOBJECT*) m_pSelectedWidget->m_pSelectedObject->m_pCMMbase)->IsVertical = m_pCMMscreen->IsVert;
				m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->Border.BorderUsed = FALSE; // turn border off for chart object
				CChartObject *pchartObj = (CChartObject*) m_pSelectedWidget->m_pSelectedObject;
				for (int i = 0; i < iPEN_COUNT; i++) {
					SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[i],
							m_pCMMscreen->CannedPens[i].PenIndex);
				}
				m_pSelectedWidget->ConfigChange();
				if (m_pCMMscreen->IsVert) {
					CBaseObject *tempObj = pchartObj;
					// create horizontal Indicators (scales) block..
					int scalenum = 0;
					for (int i = 0; i < iPEN_COUNT; i++) {
						QRect res = ScaleArea;
						if ((m_pCMMscreen->CannedPens[i].Scale) && (scalenum < numCreateScales)) {
							res.setTop(scalenum) * scalethickness;
							res.setBottom(res).top + scalethickness;
							scalenum++;
#ifdef DOCVIEW
							// need to offset the rect here, since AddNewWidget expects screen co-ords.
							OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
		#endif
							if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
								//m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed=1;
								m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
								CBaseObject *pObj = AddIndicatorVContents(m_pCMMscreen->CannedPens[i].PenIndex,
										m_pCMMscreen->IsPointer, HasAlarmMarkers, m_pCMMscreen->IsRotate, tempObj);
								if (pObj) {
									tempObj = pObj;
								}
								m_pSelectedWidget->ConfigChange();
							} else {
								QString strError("");
								strError = QString::asprintf("Failed to create vertical indicator widget, %s",
										m_pCMMscreen->Name);
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
							}
						}
					}
					// now adjust chart to full width - taking all the linked objects with it.
					ChartRect.setleft(0);
					ChartRect.setright(_Width)(tRemainingScreenArea);
					((CBaseObject*) pchartObj)->SetBoundsRelative(&ChartRect);
					ChartRect = pchartObj->GetBounds();
					pchartObj->SetLinkLimits(*(int*) &ChartRect.left, *(int*) &ChartRect.right); // and all the other objects
				} else {
					CBaseObject *tempObj = pchartObj;
					// create vertical Indicators (scales) block..
					int scalenum = 0;
					for (int i = 0; i < iPEN_COUNT; i++) {
						QRect res = ScaleArea;
						if ((m_pCMMscreen->CannedPens[i].Scale) && (scalenum < numCreateScales)) {
							res.setLeft(scalenum) * scalethickness;
							res.setright(res).left + scalethickness;
							scalenum++;
#ifdef DOCVIEW
							// need to offset the rect here, since AddNewWidget expects screen co-ords.
							OffsetRect(&res,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
		#endif
							if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &res)) {
								m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
								CBaseObject *pObj = AddIndicatorHContents(m_pCMMscreen->CannedPens[i].PenIndex,
										m_pCMMscreen->IsPointer, HasAlarmMarkers, m_pCMMscreen->IsRotate, tempObj);
								if (pObj) {
									tempObj = pObj;
								}
								m_pSelectedWidget->ConfigChange();
							} else {
								QString strError("");
								strError = QString::asprintf("Failed to create horizontal indicator widget, %s",
										m_pCMMscreen->Name);
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
							}
						}
					}
					// now adjust chart to full height- taking all the linked objects with it.
					ChartRect.setTop(0);
					ChartRect.setBottom(_Height)(tRemainingScreenArea);
					((CBaseObject*) pchartObj)->SetBoundsRelative(&ChartRect);
					ChartRect = pchartObj->GetBounds();
					pchartObj->SetLinkLimits(*(int*) &ChartRect.top, *(int*) &ChartRect.bottom); // and all the other objects
				}
				// now we need to unlink everything. (really only need to unlink across widgets)
				CWidget *pWgt = m_pWidgets;
				while (pWgt) {
					CBaseObject *pScale = NULL;
					CBaseObject *pAlrm = NULL;
					CBaseObject *pBarOrPointer = NULL;
					CBaseObject *tempObj = pWgt->m_pObjects;
					while (tempObj) {
						if (tempObj->m_pCMMbase->ObjectType == ScaleObject)
							pScale = tempObj;
						else if (tempObj->m_pCMMbase->ObjectType == AlarmMrkrObject)
							pAlrm = tempObj;
						else if ((tempObj->m_pCMMbase->ObjectType == BarObject)
								|| (tempObj->m_pCMMbase->ObjectType == PenPointersObject))
							pBarOrPointer = tempObj;
						// break all links.
						tempObj->m_pLinked = NULL;
						tempObj->m_pCMMbase->LinkedObj.CMM_Type = 0;
						tempObj->m_pCMMbase->LinkedObj.CMM_Inst = 0;
						tempObj = tempObj->m_pNextObj;
					}
					// now relink the scale and alarm markers !! (alarm markers have to be linked to draw correctly)
					if (pScale) {
						if (pAlrm)
							pScale->LinkTo(pAlrm);
						if (pBarOrPointer)
							pScale->LinkTo(pBarOrPointer); // relink the bar or pointer too
					}
					pWgt = pWgt->m_pNextWgt;
				}
				if (m_pCMMscreen->IsRotate) {
					// here we need to fix the Widgets channel list
					// For Rotating bars/penpointers, we add all the pens and set it up to rotate.
					// For TPL_CHRT_DPMS with PenPointers we set up the channels so that all the pen pointers will be shown in the single Object.
					// if we added a penpointers object to the widget above, it will have set up the WidgetChannel List.
					// so this next part may already be done..
					while (m_pSelectedWidget->m_pCMMwidget->NumChannels < iPEN_COUNT) {
						// the number of channels variable is also the location of the
						// first free widget channel
						const USHORT usSCREEN_INDEX = m_pSelectedWidget->GetFreeScreenInstIndex(this,
								CScreen::ms_usUNINITIALISED_INSTANCE);
						if (usSCREEN_INDEX != CWidget::ms_usNO_FREE_SCREEN_INDEXES) {
							m_pSelectedWidget->m_pCMMwidget->ChannelList[m_pSelectedWidget->m_pCMMwidget->NumChannels] =
									usSCREEN_INDEX + CWidget::ms_usCHANNEL_OFFSET;
							++m_pSelectedWidget->m_pCMMwidget->NumChannels;
						} else {
							// run out of screen indexes - highly unlikely but generate an error to cope with it
							LOG_ERR( TRACE_OPPANEL, "RUN OUT OF FREE SCREEN INSTANCES");
							break;
						}
					}
					for (int i = 0; i < iPEN_COUNT; i++)
						SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[i],
								m_pCMMscreen->CannedPens[i].PenIndex);
					m_pSelectedWidget->m_pCMMwidget->NumChannels = iPEN_COUNT; // set this to actual number of pens
					if (m_pCMMscreen->IsRotate) {
						m_pSelectedWidget->m_pCMMwidget->NumRotateChan = iPEN_COUNT;
						m_pSelectedWidget->m_pCMMwidget->RotateChannels = TRUE;
					}
					m_pSelectedWidget->ConfigChange();
				}
			} else {
				QString strError("");
				strError = QString::asprintf("Failed to create chart object, %s", m_pCMMscreen->Name);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			}
		} else {
			QString strError("");
			strError = QString::asprintf("Failed to create chart widget, %s", m_pCMMscreen->Name);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
#ifdef DOCVIEW
		// need to offset the rect here, since AddNewWidget expects screen co-ords.
		OffsetRect(&tAMS2750StatusRect,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
		// now create the AMS2750 status area
		if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tAMS2750StatusRect)) {
			m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
			//m_pSelectedWidget->m_pCMMwidget->BackColour = m_pCMMscreen->BackColour;
			COLORREF crBkgCol = QString(255, 252, 204);
			m_pSelectedWidget->m_pCMMwidget->BackColour = RGBtoRGB565(crBkgCol);
			CGeneralSetupConfig *pkGeneralSetup = pSETUP->GetGeneralSetupConfig();
			T_PFURNACESCONFIG ptFurnaces = pkGeneralSetup->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
			CButtonObject *pkSelectedBtn = NULL;
			CTextObject *pkSelectedText = NULL;
			// normalise the coordinates to the widget
			SetRect(&tAMS2750StatusRect, 0, 0, _Width(tAMS2750StatusRect), _Height(tAMS2750StatusRect));
			// add the title text
			QRect tTitleRect = tAMS2750StatusRect;
			tTitleRect.setBottom(tTitleRect).top + 22;
			tTitleRect.setLeft(200);
			tTitleRect.setRight(200);
			QString strTitleText("");
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTitleRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTitleText = tr("AMS2750 Status");
				pkSelectedText->SetTextString(strTitleText.GetBuffer(strTitleText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 20;
				pkSelectedText->m_pCMMtext->Font.Weight = 3;
				pkSelectedText->m_pCMMtext->Center = TRUE;
			} else {
				bFoundObjectError = true;
			}
			// add the furnace name text
			QRect tFurnaceRect = tAMS2750StatusRect;
			tFurnaceRect.setTop(22);
			tFurnaceRect.setBottom(tFurnaceRect).top + 22;
			tFurnaceRect.left = (tFurnaceRect.right / 4);
			tFurnaceRect.right = (tFurnaceRect.right / 2);
			// get the furnace text for this group before creating the object as we may need to enlarge the rect size
			if (m_pCMMscreen->GroupIndex < GENERALCONFIG_GROUPNAME_SIZE) {
				strTitleText = QString::asprintf(IDS_AMS2750_PROCESS_SCREEN_FURNACE_TITLE,
						ptFurnaces->Furnaces[m_pCMMscreen->GroupIndex].Name);
				if (strTitleText.size() > 35) {
					// enlarge the rect
					tFurnaceRect.setLeft(180);
				} else if (strTitleText.size() > 25) {
					// enlarge the rect
					tFurnaceRect.setLeft(100);
				}
			} else {
				strTitleText = L"Invalid group no";
			}
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedText->SetTextString(strTitleText.GetBuffer(strTitleText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
				pkSelectedText->m_pCMMtext->Font.Weight = 1;
				pkSelectedText->m_pCMMtext->Center = TRUE;
			} else {
				bFoundObjectError = true;
			}
			// add the furnace class text
			QRect tClassRect = tAMS2750StatusRect;
			tClassRect.setTop(22);
			tClassRect.setBottom(tClassRect).top + 22;
			tClassRect.setright(3) * (tAMS2750StatusRect.right / 4);
			tClassRect.left = (tAMS2750StatusRect.right / 2);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tClassRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				// get the class text for this group
				CGeneralSetupConfig *pkGeneralSetup = pSETUP->GetGeneralSetupConfig();
				T_PFURNACESCONFIG ptFurnaces = pkGeneralSetup->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
				if (m_pCMMscreen->GroupIndex < GENERALCONFIG_GROUPNAME_SIZE) {
					QString strClassList("");
					strClassList = tr("1|2|3|4|5|6|");
					strTitleText = QString::asprintf(IDS_AMS2750_PROCESS_SCREEN_CLASS_TITLE,
							CStringUtils::GetItemAtPos(strClassList,
									ptFurnaces->Furnaces[m_pCMMscreen->GroupIndex].FurnaceClass));
				} else {
					strTitleText = "";
				}
				pkSelectedText->SetTextString(strTitleText.GetBuffer(strTitleText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
				pkSelectedText->m_pCMMtext->Font.Weight = 1;
				pkSelectedText->m_pCMMtext->Center = TRUE;
			} else {
				bFoundObjectError = true;
			}
			// add the TUS button and its label
			const LONG lBUTTON_SEPARATION = (tAMS2750StatusRect.right / 5) - 2;
			QRect tBtnRect = tAMS2750StatusRect;
			tBtnRect.setTop(43);
			tBtnRect.setBottom(93);
			tBtnRect.setleft(78);
			tBtnRect.setright(tBtnRect.left() + 73;
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtTUS_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the buttons associated tag
			QRect tTagRect = tAMS2750StatusRect;
			tTagRect.setTop(49);
			tTagRect.setBottom(86);
			tTagRect.setleft(15);
			tTagRect.setright(tTagRect).left + 63;
			QString strTagText("");
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("TUS Due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the instrument calibration button and its label
			tBtnRect.setLeft(lBUTTON_SEPARATION);
			tBtnRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtINST_CAL_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 18;
				pkSelectedBtn->m_pCMMbutton->Wordwrap = FALSE;
			} else {
				bFoundObjectError = true;
			}
			tTagRect.setLeft(lBUTTON_SEPARATION);
			tTagRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("Inst Cal due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the SAT button and its label
			tBtnRect.setLeft(lBUTTON_SEPARATION);
			tBtnRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtSAT_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			tTagRect.setLeft(lBUTTON_SEPARATION);
			tTagRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("SAT Due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the control TC button and its label
			tBtnRect.setLeft(lBUTTON_SEPARATION);
			tBtnRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtCONTROL_TC_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			tTagRect.setLeft(lBUTTON_SEPARATION);
			tTagRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("Control TC/RT Due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the process instrument button and its label
			tBtnRect.setLeft(lBUTTON_SEPARATION);
			tBtnRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				strTagText = tr("Sensor Status");
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString(strTagText.GetBuffer(strTagText.size()));
				pkSelectedBtn->m_pCMMbutton->Type = cbtTC_USAGE_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			tTagRect.setLeft(lBUTTON_SEPARATION);
			tTagRect.setRight(lBUTTON_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("Process Inst.");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
		} else {
			bFoundObjectError = true;
		}
	} else {
		// this is a QX or QXe therefore all we are required to show is the AMS2750 furnace status
		// add the widget that will contain the buttons 
		if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tScreenRect)) {
			m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = 1;
			//m_pSelectedWidget->m_pCMMwidget->BackColour = m_pCMMscreen->BackColour;
			COLORREF crBkgCol = QString(255, 252, 204);
			m_pSelectedWidget->m_pCMMwidget->BackColour = RGBtoRGB565(crBkgCol);
			CGeneralSetupConfig *pkGeneralSetup = pSETUP->GetGeneralSetupConfig();
			T_PFURNACESCONFIG ptFurnaces = pkGeneralSetup->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
			CButtonObject *pkSelectedBtn = NULL;
			CTextObject *pkSelectedText = NULL;
			// add the title text
			QRect tTitleRect = { 5, 0, 315, 19 };
			QString strTitleText("");
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTitleRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTitleText = tr("AMS2750 Status");
				pkSelectedText->SetTextString(strTitleText.GetBuffer(strTitleText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
				pkSelectedText->m_pCMMtext->Font.Weight = 3;
				pkSelectedText->m_pCMMtext->Center = TRUE;
			} else {
				bFoundObjectError = true;
			}
			// add the furnace name text
			QRect tFurnaceRect = { 5, 20, 155, 38 };
			LONG lFurnaceNameExtra = 0;
			// get the furnace text for this group - do it before creating the object as we may need to expand the object
			if (m_pCMMscreen->GroupIndex < GENERALCONFIG_GROUPNAME_SIZE) {
				strTitleText = QString::asprintf(IDS_AMS2750_PROCESS_SCREEN_FURNACE_TITLE,
						ptFurnaces->Furnaces[m_pCMMscreen->GroupIndex].Name);
				// check if the text is too long
				if (strTitleText.size() > 26) {
					// add our own ellipsis
					strTitleText.remove(26, strTitleText.size() - 26);
					strTitleText += L"..";
				}
				if (strTitleText.size() > 20) {
					lFurnaceNameExtra = 55;
					tFurnaceRect.setRight(lFurnaceNameExtra);
				}
			} else {
				strTitleText = L"Invalid group no";
			}
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedText->SetTextString(strTitleText.GetBuffer(strTitleText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
				pkSelectedText->m_pCMMtext->Font.Weight = 1;
				pkSelectedText->m_pCMMtext->Center = TRUE;
			} else {
				bFoundObjectError = true;
			}
			// add the furnace class text
			QRect tClassRect = { 165 + lFurnaceNameExtra, 20, 315, 38 };
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tClassRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				// get the class text for this group
				CGeneralSetupConfig *pkGeneralSetup = pSETUP->GetGeneralSetupConfig();
				T_PFURNACESCONFIG ptFurnaces = pkGeneralSetup->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
				if (m_pCMMscreen->GroupIndex < GENERALCONFIG_GROUPNAME_SIZE) {
					QString strClassList("");
					strClassList = tr("1|2|3|4|5|6|");
					strTitleText = QString::asprintf(IDS_AMS2750_PROCESS_SCREEN_CLASS_TITLE,
							CStringUtils::GetItemAtPos(strClassList,
									ptFurnaces->Furnaces[m_pCMMscreen->GroupIndex].FurnaceClass));
				} else {
					strTitleText = "";
				}
				pkSelectedText->SetTextString(strTitleText.GetBuffer(strTitleText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
				pkSelectedText->m_pCMMtext->Font.Weight = 1;
				pkSelectedText->m_pCMMtext->Center = TRUE;
			} else {
				bFoundObjectError = true;
			}
			// add the TUS button and its label
			QRect tBtnRect = { 80, 45, 145, 90 };
			const int iVERTICAL_SEPARATION = 55;
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtTUS_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 16;
			} else {
				bFoundObjectError = true;
			}
			// add the buttons associated tag
			QRect tTagRect = { 15, 50, 78, 90 };
			QString strTagText("");
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("TUS Due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the instrument calibration button and its label
			tBtnRect.setTop(iVERTICAL_SEPARATION);
			tBtnRect.setBottom(iVERTICAL_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtINST_CAL_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 16;
				pkSelectedBtn->m_pCMMbutton->Wordwrap = FALSE;
			} else {
				bFoundObjectError = true;
			}
			tTagRect.setTop(iVERTICAL_SEPARATION);
			tTagRect.setBottom(iVERTICAL_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("Inst Cal due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the SAT button and its label
			tBtnRect.setTop(45);
			tBtnRect.setBottom(90);
			tBtnRect.setleft(235);
			tBtnRect.setright(300);
			tTagRect.setTop(50);
			tTagRect.setBottom(90);
			tTagRect.setleft(165);
			tTagRect.setright(228);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtSAT_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 16;
			} else {
				bFoundObjectError = true;
			}
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("SAT Due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the control TC button and its label
			tBtnRect.setTop(iVERTICAL_SEPARATION);
			tBtnRect.setBottom(iVERTICAL_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString("");
				pkSelectedBtn->m_pCMMbutton->Type = cbtCONTROL_TC_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 16;
			} else {
				bFoundObjectError = true;
			}
			tTagRect.setTop(iVERTICAL_SEPARATION);
			tTagRect.setBottom(iVERTICAL_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("Control TC/RT Due In:");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
			// add the process instrument button and its label
			tBtnRect.setTop(iVERTICAL_SEPARATION);
			tBtnRect.setBottom(iVERTICAL_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
				strTagText = tr("Sensor Status");
				pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
				pkSelectedBtn->m_ButtonID = SB_CUSTOM;
				pkSelectedBtn->SetTextString(strTagText.GetBuffer(strTagText.size()));
				pkSelectedBtn->m_pCMMbutton->Type = cbtTC_USAGE_TIMER;
				pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
				pkSelectedBtn->m_pCMMbutton->Font.Height = 16;
			} else {
				bFoundObjectError = true;
			}
			tTagRect.setTop(iVERTICAL_SEPARATION);
			tTagRect.setBottom(iVERTICAL_SEPARATION);
			if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
				pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
				strTagText = tr("Process Inst.");
				pkSelectedText->SetTextString(strTagText.GetBuffer(strTagText.size()));
				MatchColour(m_pSelectedWidget);
				pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
				pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
				pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
				pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
				pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
				pkSelectedText->m_pCMMtext->IsTag = FALSE;
				pkSelectedText->m_pCMMtext->FixText = TRUE;
				pkSelectedText->m_pCMMtext->Font.Height = 18;
			} else {
				bFoundObjectError = true;
			}
		} else {
			bFoundObjectError = true;
		}
	}
	// log an error if one or more objects failed to be created
	if (bFoundObjectError) {
		QString strError("");
		strError = QString::asprintf("Failed to create AMS2750 process screen display object(s), %s",
				m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
///
/// Method that populates the AMS2750 TUS screen
///
/// @param[in]		const QRect tSCREEN_AREA - The screen area that we must fully populate
/// @param[in]		const int iPEN_COUNT - The number of pens configured for this canned screen
///
//****************************************************************************
void CScreen::PopulateAMS2750TUSScreen(const QRect tSCREEN_AREA, const int iPEN_COUNT) {
	bool bFoundObjectError = false;
	// this is a AMS2750 TUS screen template
	QRect tRemainingScreenArea = tSCREEN_AREA;
#ifdef DOCVIEW
	// need to offset the rect here, since AddNewWidget expects screen co-ords.
	OffsetRect(&tRemainingScreenArea,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
	tRemainingScreenArea.setLeft(1);
	tRemainingScreenArea.setRight(1);
	tRemainingScreenArea.setTop(1);
	tRemainingScreenArea.setBottom(1);
	const LONG lTITLE_AREA_HEIGHT = 124;
	QRect tTitleInfoRect = tRemainingScreenArea;
	tTitleInfoRect.setBottom(lTITLE_AREA_HEIGHT) - 1;
	tRemainingScreenArea.setTop(lTITLE_AREA_HEIGHT);
	PopulateTUSTitleRect(tTitleInfoRect);
	QRect tTUSStatusRect = tRemainingScreenArea;
	LONG lSTATUS_RECT_HEIGHT = 225;
	tTUSStatusRect.setBottom(tTUSStatusRect).top + lSTATUS_RECT_HEIGHT;
	tRemainingScreenArea.setTop(tTUSStatusRect).bottom + 1;
	// add TUS status rect
	PopulateTUSStatusRect(tTUSStatusRect);
	// set up the Indicator (scale+pointer/bar + alarm mks) area (always 1)
	// leave some are on the right for the 3 dpm's
	LONG lLEFT_DPM_AREA_WIDTH = 80;
	QRect tScaleArea = tRemainingScreenArea;
	tScaleArea.setRight(lLEFT_DPM_AREA_WIDTH);
	tRemainingScreenArea.setleft(tScaleArea).right;
	// finally add the DPM's
	PopulateTUSDPMArea(tRemainingScreenArea);
	// add TUS chart rect
	PopulateTUSChartRect(tScaleArea);
	// log an error if one or more objects failed to be created
	if (bFoundObjectError) {
		QString strError("");
		strError = QString::asprintf("Failed to create AMS2750 TUS screen display object(s), %s", m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
///
/// Method that populates the AMS2750 TUS title rect
///
/// @param[in]		const QRect tTITLE_AREA - The title area that we must populate
///
//****************************************************************************
void CScreen::PopulateTUSTitleRect(const QRect tTITLE_RECT) {
	bool bFoundObjectError = false;
#ifndef DOCVIEW	
	const COLORREF crWHITE = QString(255, 255, 255);
	LONG lBTNS_START_X_COORD = 515;
	LONG lBTN_WIDTH = 88;
	T_CHANNELREF *ptChanRef = NULL;
	USHORT usNumChannels = 0;
	CAMS2750TUSMgr *pkTUSStatusMgr = CAMS2750TUSMgr::Instance();
	QString strText("");
	CTextObject *pkSelectedText = NULL;
	// sort out the widgets rects first
	const LONG lTITLE_TEXT_RECT_HEIGHT = 18;
	// initialise some const's needed for drawing the username and time values and labels
	const LONG lAPPROX_CHAR_WIDTH = 5;
	const LONG lTIME_TEXT_WHITESPACE_WIDTH = 3;
	QRect tTitleInfoRect = tTITLE_RECT;
	QRect tFurnaceInfoRect = tTitleInfoRect;
	tTitleInfoRect.setBottom(tTitleInfoRect).top + lTITLE_TEXT_RECT_HEIGHT;
	tFurnaceInfoRect.setTop(tTitleInfoRect).bottom;
	// we now have the title rect sort and the furnace rect takes up the entire width of the screen - need
	// need to split it up
	QRect tBtnInfoRect = tFurnaceInfoRect;
	tFurnaceInfoRect.setright(tFurnaceInfoRect).left + lBTNS_START_X_COORD;
	tBtnInfoRect.setleft(tFurnaceInfoRect).right;
	// we now have the button rect sort so all we have to do it split the furnace rect into two so we end
	// up with the furnace rect and time rect - get th width of what remaining and divide into 3
	const LONG llFURNACE_INFO_X_SEPERATION = (_Width(tFurnaceInfoRect) / 3);
	QRect tTimeInfoRect = tFurnaceInfoRect;
	tTimeInfoRect.setleft(tTimeInfoRect).right - llFURNACE_INFO_X_SEPERATION;
	tFurnaceInfoRect.setright(tTimeInfoRect).left;
	// detemrine the space available for 4 lines of information in the furnace and time info areas
	const LONG llFURNACE_INFO_Y_SEPERATION = _Height(tFurnaceInfoRect) / 4;
	;
	CGeneralSetupConfig *pkGenSetupCfg = pSETUP->GetGeneralSetupConfig();
	T_PFURNACESCONFIG ptFurnaceInfo = pkGenSetupCfg->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
	// add the widget that will contain the title information display object
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tTitleInfoRect)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = FALSE;
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWHITE));
		// draw the title text object
		QRect tTitleTextRect = tTitleInfoRect;
		SetRect(&tTitleTextRect, 0, 0, _Width(tTitleInfoRect), _Height(tTitleInfoRect));
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTitleTextRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			CDataItemGeneral *pkTUSStateDIT = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL,
					DI_GENTYPE_GENERAL, DI_GEN_AMS2750_TUS_START_TIME));
			strText = QString::asprintf(IDS_TUS_SCREEN_TUS_TITLE, pkTUSStateDIT->GetUnits());
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(QString(200, 200, 200));
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = TRUE;
			pkSelectedText->m_pCMMtext->Font.Height = 16;
			pkSelectedText->m_pCMMtext->Font.Weight = 3;
			// add a single pixel border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = true;
	}
	// add the widget that will contain the title information display object
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tFurnaceInfoRect)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = FALSE;
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWHITE));
		SetRect(&tFurnaceInfoRect, 0, 0, _Width(tFurnaceInfoRect), _Height(tFurnaceInfoRect));
		// Add the various labels, some dynamic and some static
		// reduce the width to one third of the area not used for the buttons
		tFurnaceInfoRect.setright(lBTNS_START_X_COORD);
		tFurnaceInfoRect.setright(tFurnaceInfoRect).left + llFURNACE_INFO_X_SEPERATION;
		tFurnaceInfoRect.setBottom(tFurnaceInfoRect).top + llFURNACE_INFO_Y_SEPERATION;
		// indent the left slightly so the text is right against the border
		tFurnaceInfoRect.setLeft(5);
		// create the furnace section title
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = tr("Furnace");
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 14;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		tFurnaceInfoRect.setTop(llFURNACE_INFO_Y_SEPERATION);
		tFurnaceInfoRect.setBottom(llFURNACE_INFO_Y_SEPERATION);
		// create the furnace name label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = QString::asprintf(IDS_TUS_SCREEN_NAME_LABEL, ptFurnaceInfo->Furnaces[0].Name);
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		tFurnaceInfoRect.setTop(llFURNACE_INFO_Y_SEPERATION);
		tFurnaceInfoRect.setBottom(llFURNACE_INFO_Y_SEPERATION);
		// create the furnace model number label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = QString::asprintf(IDS_TUS_SCREEN_MODEL_NO_LABEL, ptFurnaceInfo->Furnaces[0].ModelNo);
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		tFurnaceInfoRect.setTop(llFURNACE_INFO_Y_SEPERATION);
		tFurnaceInfoRect.setBottom(llFURNACE_INFO_Y_SEPERATION);
		// create the furnace instrument type label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceInfoRect)) {
			QString strInstTypeList("");
			strInstTypeList = tr("A|B|C|D|E|");
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = QString::asprintf(IDS_TUS_SCREEN_INST_TYPE_LABEL,
					CStringUtils::GetItemAtPos(strInstTypeList, ptFurnaceInfo->Furnaces[0].InstType));
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		// now do the data in the middle column
		tFurnaceInfoRect.setTop(0);
		tFurnaceInfoRect.setBottom(tFurnaceInfoRect).top + llFURNACE_INFO_Y_SEPERATION;
		tFurnaceInfoRect.setLeft(llFURNACE_INFO_X_SEPERATION);
		tFurnaceInfoRect.setRight(llFURNACE_INFO_X_SEPERATION);
		// move down onto the next line as the top space is blank
		tFurnaceInfoRect.setTop(llFURNACE_INFO_Y_SEPERATION);
		tFurnaceInfoRect.setBottom(llFURNACE_INFO_Y_SEPERATION);
		// reduce the width and insert the start text
		strText = tr("Username:");
		QRect tUsernameLabel = tFurnaceInfoRect;
		tUsernameLabel.setright(tUsernameLabel).left
				+ ((strText.size() * lAPPROX_CHAR_WIDTH) + lTIME_TEXT_WHITESPACE_WIDTH);
		// create the username label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tUsernameLabel)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = TRUE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		// the actual username value will need to be to the right of the username label
		LONG lPREVIOUS_X_START_POS = tFurnaceInfoRect.left;
		tFurnaceInfoRect.setleft(tUsernameLabel).right;
		// create the username value
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the next item in the widgets channel list (to be added below)
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[ptChanRef->IndexChan],
					DI_GEN_LOGGED_IN_USER);
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = FALSE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
			pkSelectedText->ConfigChange();
		} else {
			bFoundObjectError = true;
		}
		// restore the correct left position
		tFurnaceInfoRect.setleft(lPREVIOUS_X_START_POS);
		tFurnaceInfoRect.setTop(llFURNACE_INFO_Y_SEPERATION);
		tFurnaceInfoRect.setBottom(llFURNACE_INFO_Y_SEPERATION);
		// create the no. of TC's label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = QString::asprintf(IDS_TUS_SCREEN_NO_OF_TC_LABEL, pkTUSStatusMgr->GetNoOfTUSTCs());
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		tFurnaceInfoRect.setTop(llFURNACE_INFO_Y_SEPERATION);
		tFurnaceInfoRect.setBottom(llFURNACE_INFO_Y_SEPERATION);
		// create the furnace class label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tFurnaceInfoRect)) {
			QString strClassList("");
			strClassList = tr("1|2|3|4|5|6|");
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = QString::asprintf(IDS_TUS_SCREEN_CLASS_LABEL,
					CStringUtils::GetItemAtPos(strClassList, ptFurnaceInfo->Furnaces[0].FurnaceClass));
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = true;
	}
	// we now have to do the time information - this will require 3 seperate widgets because of diffulties with using multple 
	// channel refs (with different instances) within the same widget
	// add the widget that will contain the time information display object
	tTimeInfoRect.setBottom(tTimeInfoRect).top + (llFURNACE_INFO_Y_SEPERATION * 2);
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tTimeInfoRect)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = FALSE;
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWHITE));
		QRect tStartTimeInfoRect = tTimeInfoRect;
		SetRect(&tStartTimeInfoRect, 0, 0, _Width(tTimeInfoRect), _Height(tTimeInfoRect));
		tStartTimeInfoRect.setBottom(tStartTimeInfoRect).top + llFURNACE_INFO_Y_SEPERATION;
		// create the time section title
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tStartTimeInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = tr("Time");
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 14;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		tStartTimeInfoRect.setTop(llFURNACE_INFO_Y_SEPERATION);
		tStartTimeInfoRect.setBottom(llFURNACE_INFO_Y_SEPERATION);
		// reduce the width and insert the start text
		strText = tr("Started:");
		tStartTimeInfoRect.right = ((strText.size() * lAPPROX_CHAR_WIDTH) + lTIME_TEXT_WHITESPACE_WIDTH);
		// create the started time label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tStartTimeInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = TRUE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		// the actual time value will need to be slightly to the right
		tStartTimeInfoRect.setleft(tStartTimeInfoRect).right;
		tStartTimeInfoRect.setright(_Width)(tTimeInfoRect);
		// create the started time value
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tStartTimeInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the next item in the widgets channel list (to be added below)
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[ptChanRef->IndexChan],
					DI_GEN_AMS2750_TUS_START_TIME);
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = TRUE;
			pkSelectedText->m_pCMMtext->FixText = FALSE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = false;
	}
	// now do the elapsed time widget
	tTimeInfoRect.setTop(tTimeInfoRect).bottom;
	tTimeInfoRect.setBottom(tTimeInfoRect).top + llFURNACE_INFO_Y_SEPERATION;
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tTimeInfoRect)) {
		QRect tElapsedTimeInfoRect = tTimeInfoRect;
		SetRect(&tElapsedTimeInfoRect, 0, 0, _Width(tTimeInfoRect), _Height(tTimeInfoRect));
		// reduce the width and insert the elapsed text
		strText = tr("Elapsed:");
		tElapsedTimeInfoRect.right = ((strText.size() * lAPPROX_CHAR_WIDTH) + lTIME_TEXT_WHITESPACE_WIDTH);
		// create the elapsed time label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tElapsedTimeInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = TRUE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		// the actual time value will need to be slightly to the right
		tElapsedTimeInfoRect.setleft(tElapsedTimeInfoRect).right;
		tElapsedTimeInfoRect.setright(_Width)(tTimeInfoRect);
		// create the elapsed time value
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tElapsedTimeInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the next item in the widgets channel list (to be added below)
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[ptChanRef->IndexChan],
					DI_GEN_AMS2750_TUS_ELAPSED_TIME);
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 50; // twice a second
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = TRUE;
			pkSelectedText->m_pCMMtext->FixText = FALSE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = false;
	}
	// now do the TUS status widget
	tTimeInfoRect.setTop(tTimeInfoRect).bottom;
	tTimeInfoRect.setBottom(tTimeInfoRect).top + llFURNACE_INFO_Y_SEPERATION;
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tTimeInfoRect)) {
		QRect tStatusInfoRect = tTimeInfoRect;
		SetRect(&tStatusInfoRect, 0, 0, _Width(tTimeInfoRect), _Height(tTimeInfoRect));
		// reduce the width and insert the start text
		strText = tr("Condition:");
		tStatusInfoRect.right = ((strText.size() * lAPPROX_CHAR_WIDTH) + lTIME_TEXT_WHITESPACE_WIDTH);
		// create the TUS state label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tStatusInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkSelectedText->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = TRUE;
			pkSelectedText->m_pCMMtext->FixText = TRUE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		// the actual time value will need to be slightly to the right
		tStatusInfoRect.setleft(tStatusInfoRect).right;
		tStatusInfoRect.setright(_Width)(tTimeInfoRect);
		// create the TUS running status
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tStatusInfoRect)) {
			pkSelectedText = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the next item in the widgets channel list (to be added below)
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[ptChanRef->IndexChan],
					DI_GEN_AMS2750_TUS_START_TIME);
			pkSelectedText->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWHITE);
			pkSelectedText->m_pCMMtext->Font.Quality = 1; //antialiased
			pkSelectedText->m_pCMMtext->Wordwrap = TRUE;
			pkSelectedText->m_pCMMtext->Base.FixForeColour = TRUE;
			pkSelectedText->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkSelectedText->m_pCMMtext->Base.IsBuffered = TRUE;
			pkSelectedText->m_pCMMtext->IsTag = FALSE;
			pkSelectedText->m_pCMMtext->IsUnits = TRUE;
			pkSelectedText->m_pCMMtext->FixText = FALSE;
			pkSelectedText->m_pCMMtext->Center = FALSE;
			pkSelectedText->m_pCMMtext->Font.Height = 13;
			pkSelectedText->m_pCMMtext->Font.Weight = 1;
			// no border
			pkSelectedText->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = true;
	}
	// add the widget that will contain the button objects
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tBtnInfoRect)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = FALSE;
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWHITE));
		// normalise the buttons area
		SetRect(&tBtnInfoRect, 0, 0, _Width(tBtnInfoRect), _Height(tBtnInfoRect));
		// Add the buttons on the RHS now
		CButtonObject *pkSelectedBtn = NULL;
		COLORREF crBtnBkgCol = QString(221, 233, 243);
		const LONG lHORIZ_BTN_SEPERATION = 95;
		const LONG lBTN_TOP = tBtnInfoRect.top + 4;
		const LONG lBTN_BOTTOM = tBtnInfoRect.bottom - 4;
		// add the start/stop TUS button
		QRect tBtnRect = { 0, lBTN_TOP, lBTN_WIDTH, lBTN_BOTTOM };
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
			pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkSelectedBtn->m_ButtonID = SB_CUSTOM;
			if (pkTUSStatusMgr->GetTUSState() == CAMS2750TUSMgr::tusRUNNING) {
				strText = tr("Stop TUS");
				pkSelectedBtn->SetTextString(strText.GetBuffer(strText.size()));
			} else {
				strText = tr("Start TUS");
				pkSelectedBtn->SetTextString(strText.GetBuffer(strText.size()));
			}
			pkSelectedBtn->m_pCMMbutton->Type = cbtSTART_STOP_TUS;
			pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
			pkSelectedBtn->m_pCMMbutton->Font.Height = 14;
			pkSelectedBtn->m_pCMMbase->BackColour = static_cast<ULONG>(crBtnBkgCol);
		} else {
			bFoundObjectError = true;
		}
		// add the configure TUS button
		tBtnRect.setLeft(lHORIZ_BTN_SEPERATION);
		tBtnRect.setRight(lHORIZ_BTN_SEPERATION);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
			pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkSelectedBtn->m_ButtonID = SB_CUSTOM;
			// show the text greyed out if the TUS is already running
			if (pkTUSStatusMgr->GetTUSState() == CAMS2750TUSMgr::tusRUNNING) {
				pkSelectedBtn->m_pCMMbase->ForeColour = QString(127, 127, 127);
			} else {
				pkSelectedBtn->m_pCMMbase->ForeColour = QString(0, 0, 0);
			}
			strText = tr("Configure TUS");
			pkSelectedBtn->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedBtn->m_pCMMbutton->Type = cbtCONFIGURE_TUS;
			pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
			pkSelectedBtn->m_pCMMbutton->Font.Height = 14;
			pkSelectedBtn->m_pCMMbase->BackColour = static_cast<ULONG>(crBtnBkgCol);
		} else {
			bFoundObjectError = true;
		}
		// add the export TUS button
		tBtnRect.setLeft(lHORIZ_BTN_SEPERATION);
		tBtnRect.setRight(lHORIZ_BTN_SEPERATION);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
			pkSelectedBtn = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
			// show the text greyed out if the TUS is already running
			if (pkTUSStatusMgr->GetTUSState() == CAMS2750TUSMgr::tusRUNNING) {
				pkSelectedBtn->m_pCMMbase->ForeColour = QString(127, 127, 127);
			} else {
				pkSelectedBtn->m_pCMMbase->ForeColour = QString(0, 0, 0);
			}
			pkSelectedBtn->m_ButtonID = SB_CUSTOM;
			strText = tr("Export TUS");
			pkSelectedBtn->SetTextString(strText.GetBuffer(strText.size()));
			pkSelectedBtn->m_pCMMbutton->Type = cbtEXPORT_TUS;
			pkSelectedBtn->m_pCMMbutton->Style = WINDOWS_STYLE;
			pkSelectedBtn->m_pCMMbutton->Font.Height = 14;
			pkSelectedBtn->m_pCMMbase->BackColour = static_cast<ULONG>(crBtnBkgCol);
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = false;
	}
#endif
	// log an error if one or more objects failed to be created
	if (bFoundObjectError) {
		QString strError("");
		strError = QString::asprintf("Failed to create AMS2750 TUS screen display object(s), %s", m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
///
/// Method that populates the AMS2750 TUS status rect
///
/// @param[in]		const QRect tSTATUS_AREA - The status area that we must populate
///
//****************************************************************************
void CScreen::PopulateTUSStatusRect(const QRect tSTATUS_RECT) {
	bool bFoundObjectError = false;
#ifndef DOCVIEW	
	QRect tStatusRect = tSTATUS_RECT;
	CTextObject *pkTextObj = NULL;
	QString strText("");
	CAMS2750TUSMgr *pkTUSStatusMgr = CAMS2750TUSMgr::Instance();
	COLORREF crWidgetBkgCol = QString(255, 255, 255);
	QRect tTUSObjectWidgetRect = tSTATUS_RECT;
	tTUSObjectWidgetRect.setright(tTUSObjectWidgetRect).left + CTUSObject::m_lWIDTH;
	const long lBTN_LEFT_INDENT = 32;
	const long lBTN_RIGHT_INDENT = 32;
	const long lBTN_HEIGHT = 48;
	// add the TUS status information
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tTUSObjectWidgetRect)) {
		COLORREF crTUSObjBkgCol = QString(170, 170, 170);
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = FALSE;
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWidgetBkgCol));
		// TUS object is a standard width
		SetRect(&tStatusRect, 0, 0, CTUSObject::m_lWIDTH, _Height(tStatusRect));
		// create the TUS status object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TUSOBJECT, &tStatusRect)) {
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->Border.BorderUsed = FALSE; // turn border off for tabular display object
			// always fix the background colour
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->FixBackColour = TRUE;
			// always make the background colour white and thus non-configurable
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->BackColour = crTUSObjBkgCol;
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->FixForeColour = m_pCMMscreen->FixForeColour;
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->ForeColour = m_pCMMscreen->ForeColour;
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[0], gs_usSPECIAL_TUS_PEN_START_INST);
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 10; // fast as possible
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = true;
	}
	// add the TC override area
	QRect tTCOverrideWidgetRect = tSTATUS_RECT;
	tTCOverrideWidgetRect.setLeft(CTUSObject)::m_lWIDTH;
	tTCOverrideWidgetRect.setBottom(tTCOverrideWidgetRect).top + (_Height(tTCOverrideWidgetRect) / 2);
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tTCOverrideWidgetRect)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = FALSE;
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWidgetBkgCol));
		QRect tTextRect = tSTATUS_RECT;
		SetRect(&tTextRect, 0, 10, _Width(tTCOverrideWidgetRect), _Height(tTCOverrideWidgetRect) / 2);
		// create the text object above the TC override button
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTextRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strText = tr("TUS Sensors Stabilized Manual Override");
			pkTextObj->SetTextString(strText.GetBuffer(strText.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crWidgetBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = FALSE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 16;
			pkTextObj->m_pCMMtext->Font.Weight = 3;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		} else {
			bFoundObjectError = true;
		}
		QRect tBtnRect = tTextRect;
		tBtnRect.setTop(tBtnRect).bottom;
		tBtnRect.setLeft(lBTN_LEFT_INDENT);
		tBtnRect.setRight(lBTN_RIGHT_INDENT);
		tBtnRect.setBottom(tBtnRect.top() + lBTN_HEIGHT;
		// create the text object above the TC override button
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
			COLORREF crBtnBkgCol = QString(221, 233, 243);
			CButtonObject *pkBtnObj = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
			// show the text greyed out if the TUS is stopped
			if (pkTUSStatusMgr->GetTUSStateMachine() != TSM_ALL_TCS_IN_SOAK) {
				pkBtnObj->m_pCMMbase->ForeColour = QString(127, 127, 127);
			} else {
				pkBtnObj->m_pCMMbase->ForeColour = QString(0, 0, 0);
			}
			pkBtnObj->m_ButtonID = SB_CUSTOM;
			strText = tr("TUS Sensors Stabilized");
			pkBtnObj->SetTextString(strText.GetBuffer(strText.size()));
			pkBtnObj->m_pCMMbutton->Type = cbtTUS_TC_STABLE;
			pkBtnObj->m_pCMMbutton->Style = WINDOWS_STYLE;
			pkBtnObj->m_pCMMbutton->Font.Height = 14;
			pkBtnObj->m_pCMMbase->BackColour = static_cast<ULONG>(crBtnBkgCol);
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = true;
	}
	// finally add the remove TC and restart soak area
	QRect tTUSControlWidgetRect = tTCOverrideWidgetRect;
	tTUSControlWidgetRect.setTop(tTCOverrideWidgetRect).bottom + 1;
	tTUSControlWidgetRect.setBottom(tTUSControlWidgetRect).top + _Height(tTCOverrideWidgetRect);
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tTUSControlWidgetRect)) {
		m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed = FALSE;
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWidgetBkgCol));
		const long lBTN_SEPERATION = 5;
		QRect tBtnRect = tTUSControlWidgetRect;
		SetRect(&tBtnRect, 0, lBTN_SEPERATION, _Width(tTUSControlWidgetRect), _Height(tTUSControlWidgetRect) / 2);
		tBtnRect.setLeft(lBTN_LEFT_INDENT);
		tBtnRect.setRight(lBTN_RIGHT_INDENT);
		tBtnRect.setBottom(tBtnRect.top() + lBTN_HEIGHT;
		// create the text object above the TC override button
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
			COLORREF crBtnBkgCol = QString(221, 233, 243);
			CButtonObject *pkBtnObj = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
			// show the text greyed out if the TUS is stopped or TC's cannot be removed 
			const USHORT usMIN_TCS = pkTUSStatusMgr->GetMinTCAllowed();
			const USHORT usTOTAL_TCS = pkTUSStatusMgr->GetNoOfTUSTCs();
			if ((pkTUSStatusMgr->GetTUSState() != CAMS2750TUSMgr::tusRUNNING) || ((usMIN_TCS == usTOTAL_TCS)))
			{
				pkBtnObj->m_pCMMbase->ForeColour = QString(127, 127, 127);
			} else {
				pkBtnObj->m_pCMMbase->ForeColour = QString(0, 0, 0);
			}
			pkBtnObj->m_ButtonID = SB_CUSTOM;
			strText = tr("Remove TUS Sensors");
			pkBtnObj->SetTextString(strText.GetBuffer(strText.size()));
			pkBtnObj->m_pCMMbutton->Type = cbtTUS_REMOVE_TCS;
			pkBtnObj->m_pCMMbutton->Style = WINDOWS_STYLE;
			pkBtnObj->m_pCMMbutton->Font.Height = 14;
			pkBtnObj->m_pCMMbase->BackColour = static_cast<ULONG>(crBtnBkgCol);
		} else {
			bFoundObjectError = true;
		}
		tBtnRect.setTop(lBTN_HEIGHT) + lBTN_SEPERATION;
		tBtnRect.setBottom(lBTN_HEIGHT) + lBTN_SEPERATION;
		// create the text object above the TC override button
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_BUTTONOBJECT, &tBtnRect)) {
			COLORREF crBtnBkgCol = QString(221, 233, 243);
			CButtonObject *pkBtnObj = static_cast<CButtonObject*>(m_pSelectedWidget->m_pSelectedObject);
			// show the text greyed out if the TUS is stopped
			if (pkTUSStatusMgr->GetTUSState() != CAMS2750TUSMgr::tusRUNNING) {
				pkBtnObj->m_pCMMbase->ForeColour = QString(127, 127, 127);
			} else {
				pkBtnObj->m_pCMMbase->ForeColour = QString(0, 0, 0);
			}
			pkBtnObj->m_ButtonID = SB_CUSTOM;
			strText = tr("Restart Soak");
			pkBtnObj->SetTextString(strText.GetBuffer(strText.size()));
			pkBtnObj->m_pCMMbutton->Type = cbtTUS_RESTART_SOAK;
			pkBtnObj->m_pCMMbutton->Style = WINDOWS_STYLE;
			pkBtnObj->m_pCMMbutton->Font.Height = 14;
			pkBtnObj->m_pCMMbase->BackColour = static_cast<ULONG>(crBtnBkgCol);
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = true;
	}
#endif
	// log an error if one or more objects failed to be created
	if (bFoundObjectError) {
		QString strError("");
		strError = QString::asprintf("Failed to create AMS2750 TUS screen display object(s), %s", m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
///
/// Method that populates the AMS2750 TUS chart rect
///
/// @param[in]		const QRect tSCHART_AREA - The chart area that we must populate
///
//****************************************************************************
void CScreen::PopulateTUSChartRect(const QRect tCHART_RECT) {
	bool bFoundObjectError = false;
	BOOL HasAlarmMarkers = TRUE; // the default is to always have alarm markers.
	// horizontal chart has vertical scale(s)
	int iSCALE_THICKNESS = 51;
	QRect tScaleArea = tCHART_RECT;
	QRect tChartRect = tCHART_RECT;
	tScaleArea.setleft(tScaleArea).right - iSCALE_THICKNESS;
	tChartRect.setright(tScaleArea).left;
	// Create the Chart area
#ifdef DOCVIEW
	// need to offset the rect here, since AddNewWidget expects screen co-ords.
	OffsetRect(&tChartRect,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tChartRect)) {
		// now add the Chart Object (at relative 0,0 to widget)
		QRect tClientChartRect = tChartRect;
		SetRect(&tClientChartRect, 0, 0, _Width(tClientChartRect), _Height(tClientChartRect));
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_CHARTOBJECT, &tClientChartRect)) {
			((T_CHARTOBJECT*) m_pSelectedWidget->m_pSelectedObject->m_pCMMbase)->IsVertical = FALSE;
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->Border.BorderUsed = FALSE; // turn border off for chart object
			// always use pen pointers
			m_pCMMscreen->IsPointer = TRUE;
			// do not rotate the pen pointers
			m_pCMMscreen->IsRotate = FALSE;
			CChartObject *pchartObj = static_cast<CChartObject*>(m_pSelectedWidget->m_pSelectedObject);
#ifndef DOCVIEW
			// setup any special grid lines now
			CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
			float fGridLine1 = 0;
			float fGridLine2 = 0;
			float fSetpointLine = 0;
			pkTUSMgr->GetGridLineValues(fGridLine1, fGridLine2, fSetpointLine);
			if (fGridLine1 != FLT_MAX) {
				pchartObj->m_pCMMchart->IncGridLine1 = TRUE;
				pchartObj->m_pCMMchart->GridLine1 = fGridLine1;
			}
			if (fGridLine2 != FLT_MAX) {
				pchartObj->m_pCMMchart->IncGridLine2 = TRUE;
				pchartObj->m_pCMMchart->GridLine2 = fGridLine2;
			}
			if (fSetpointLine != FLT_MAX) {
				pchartObj->m_pCMMchart->IncSetpointLine = TRUE;
				pchartObj->m_pCMMchart->SetpointLine = fSetpointLine;
			}
#endif
			// add the special pens
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[0], gs_usSPECIAL_TUS_PEN_START_INST);
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[1], gs_usSPECIAL_TUS_PEN_START_INST + 1);
			m_pSelectedWidget->ConfigChange();
			// copy the canned channel map so the replay screen works okay
			for (int iCount = 0; iCount < SCREEN_CANNEDPENS_SIZE; iCount++) {
				m_pCMMscreen->CannedPens[iCount] = m_pRealCMMscreen->CannedPens[iCount];
			}
			// draw the other horizontal chart objects
			CBaseObject *tempObj = pchartObj;
			// create 1 vertical Indicators (scales) block..
#ifdef DOCVIEW
			// need to offset the rect here, since AddNewWidget expects screen co-ords.
			OffsetRect(&tScaleArea,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
			if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tScaleArea)) {
				m_pSelectedWidget->m_pCMMwidget->BackColour = 65535; // white specified
				CBaseObject *pObj = AddIndicatorHContents(gs_usSPECIAL_TUS_PEN_START_INST, m_pCMMscreen->IsPointer,
						HasAlarmMarkers, m_pCMMscreen->IsRotate, tempObj);
				if (pObj) {
					tempObj = pObj;
				}
				m_pSelectedWidget->ConfigChange();
			} else {
				bFoundObjectError = true;
			}
			// now adjust chart to full height- taking all the linked objects with it.
			tClientChartRect.setTop(0);
			tClientChartRect.setBottom(_Height)(tChartRect);
			((CBaseObject*) pchartObj)->SetBoundsRelative(&tClientChartRect);
			tClientChartRect = pchartObj->GetBounds();
			pchartObj->SetLinkLimits(*(int*) &tClientChartRect.top, *(int*) &tClientChartRect.bottom); // and all the other objects
			// now we need to unlink everything. (really only need to unlink across widgets)
			CWidget *pWgt = m_pWidgets;
			while (pWgt) {
				CBaseObject *pScale = NULL;
				CBaseObject *pAlrm = NULL;
				CBaseObject *pBarOrPointer = NULL;
				CBaseObject *tempObj = pWgt->m_pObjects;
				while (tempObj) {
					if (tempObj->m_pCMMbase->ObjectType == ScaleObject)
						pScale = tempObj;
					else if (tempObj->m_pCMMbase->ObjectType == AlarmMrkrObject)
						pAlrm = tempObj;
					else if ((tempObj->m_pCMMbase->ObjectType == BarObject)
							|| (tempObj->m_pCMMbase->ObjectType == PenPointersObject))
						pBarOrPointer = tempObj;
					// break all links.
					tempObj->m_pLinked = NULL;
					tempObj->m_pCMMbase->LinkedObj.CMM_Type = 0;
					tempObj->m_pCMMbase->LinkedObj.CMM_Inst = 0;
					tempObj = tempObj->m_pNextObj;
				}
				// now relink the scale and alarm markers !! (alarm markers have to be linked to draw correctly)
				if (pScale) {
					if (pAlrm)
						pScale->LinkTo(pAlrm);
					if (pBarOrPointer)
						pScale->LinkTo(pBarOrPointer); // relink the bar or pointer too
				}
				pWgt = pWgt->m_pNextWgt;
			}
			while (m_pSelectedWidget->m_pCMMwidget->NumChannels < 2) {
				// the number of channels variable is also the location of the
				// first free widget channel
				const USHORT usSCREEN_INDEX = m_pSelectedWidget->GetFreeScreenInstIndex(this,
						CScreen::ms_usUNINITIALISED_INSTANCE);
				if (usSCREEN_INDEX != CWidget::ms_usNO_FREE_SCREEN_INDEXES) {
					m_pSelectedWidget->m_pCMMwidget->ChannelList[m_pSelectedWidget->m_pCMMwidget->NumChannels] =
							usSCREEN_INDEX + CWidget::ms_usCHANNEL_OFFSET;
					++m_pSelectedWidget->m_pCMMwidget->NumChannels;
				} else {
					// run out of screen indexes - highly unlikely but generate an error to cope with it
					LOG_ERR( TRACE_OPPANEL, "RUN OUT OF FREE SCREEN INSTANCES");
					break;
				}
			}
			for (int i = 0; i < 2; i++)
				SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[i],
						m_pCMMscreen->CannedPens[i].PenIndex);
			m_pSelectedWidget->m_pCMMwidget->NumChannels = 2; // set this to actual number of pens
		} else {
			bFoundObjectError = true;
		}
	} else {
		bFoundObjectError = true;
	}
	// log an error if one or more objects failed to be created
	if (bFoundObjectError) {
		QString strError("");
		strError = QString::asprintf("Failed to create AMS2750 TUS screen display object(s), %s", m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
///
/// Method that populates the AMS2750 TUS DPM area
///
/// @param[in]		const QRect tDPM_AREA - The DPM area that we must populate
///
//****************************************************************************
void CScreen::PopulateTUSDPMArea(const QRect tDPM_AREA) {
	bool bFoundObjectError = false;
	QRect tDigObjRect;
	QRect tTagRect;
	QRect tLabelRect;
	QRect tUnitsRect;
	COLORREF crWidgetBkgCol = QString(170, 170, 170);
	COLORREF crObjBkgCol = QString(255, 255, 255);
	T_PCHANNELREF ptChanRef = NULL;
	QRect tWidgetRect = tDPM_AREA;
	CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
	T_PPEN ptMaxTCPen = pkPenConfig->GetPen(gs_usSPECIAL_TUS_PEN_START_INST, ZERO_BASED, CONFIG_COMMITTED);
	T_PPEN ptMinTCPen = pkPenConfig->GetPen(gs_usSPECIAL_TUS_PEN_START_INST + 1, ZERO_BASED, CONFIG_COMMITTED);
	tWidgetRect.setBottom(tWidgetRect).top + (_Height(tDPM_AREA) / 3);
	const LONG lWIDGET_HEIGHT = tWidgetRect.bottom - tWidgetRect.top;
	const LONG lUNITS_LABEL_WIDTH = 18;
	QRect tDPMRect = { 0, 0, 0, 0 };
	USHORT usNumChannels = 0;
	SetRect(&tDPMRect, 1, 0, _Width(tWidgetRect), _Height(tWidgetRect));
	const LONG lOBJ_HEIGHT = _Height(tDPMRect) / 5;
	CTextObject *pkTextObj = NULL;
	CDigitalObject *pkDigObj = NULL;
	QString strLabel("");
	// get the display temerpature units
	QString strTempUnits("");
	switch ( pSYSTEM_INFO->GetDisplayTempUnits()) {
	case TEMP_DEG_C:
		strTempUnits = L"C";
		break;
	case TEMP_DEG_F:
		strTempUnits = L"F";
		break;
	case TEMP_KELVIN:
		strTempUnits = L"K";
		break;
	default:
		strTempUnits = L"ERR";
		break;
	}
#ifdef DOCVIEW
	// need to offset the rect here, since AddNewWidget expects screen co-ords.
	OffsetRect(&tWidgetRect,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tWidgetRect)) {
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWidgetBkgCol));
		// reduce the size of this rect so that we can fit three horizontally
		//tDPMRect.setBottom(lDPM_HEIGHT);
		tLabelRect = tDPMRect;
		tLabelRect.setBottom(tLabelRect).top + lOBJ_HEIGHT;
		// create a blank text object to give us a bit of white space
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = "";
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
		// move down
		tLabelRect.setTop(lOBJ_HEIGHT);
		tLabelRect.setBottom(lOBJ_HEIGHT);
		// create the max TC label text object 
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = tr("Max TUS Sensor");
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = FALSE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = ptMaxTCPen->Style.Colour;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
		tTagRect = tLabelRect;
		tTagRect.setTop(lOBJ_HEIGHT);
		tTagRect.setBottom(lOBJ_HEIGHT);
		// create the max tc name text object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the next item in the widgets channel list (to be added below)
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[ptChanRef->IndexChan],
					DI_GEN_AMS2750_MAX_TC);
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 1; // fast as possible
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = TRUE;
			pkTextObj->m_pCMMtext->FixText = FALSE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = ptMaxTCPen->Style.Colour;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
			pkTextObj->ConfigChange();
		}
		tDigObjRect = tTagRect;
		tDigObjRect.setTop(lOBJ_HEIGHT);
		tDigObjRect.setBottom(lOBJ_HEIGHT);
		tDigObjRect.setRight(lUNITS_LABEL_WIDTH);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &tDigObjRect)) {
			pkDigObj = static_cast<CDigitalObject*>(m_pSelectedWidget->m_pSelectedObject);
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->BackColour = static_cast<ULONG>(crObjBkgCol);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the current item in the widgets channel list added for the text object above
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 1; // fast as possible
			pkDigObj->m_pCMMbase->FixForeColour = TRUE;
			pkDigObj->m_pCMMbase->ForeColour = ptMaxTCPen->Style.Colour;
			pkDigObj->m_pCMMdigital->FixNumasprintf = TRUE;
			pkDigObj->m_pCMMdigital->Numformat.Auto = FALSE;
			pkDigObj->m_pCMMdigital->Numformat.Scientific = FALSE;
			pkDigObj->m_pCMMdigital->Numformat.Ad = 1;
		} else {
			bFoundObjectError = true;
		}
		tUnitsRect.setTop(tDigObjRect).top;
		tUnitsRect.setBottom(tDigObjRect).bottom;
		tUnitsRect.setleft(tDigObjRect).right;
		tUnitsRect.setright(tTagRect).right;
		// create the max tc units label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tUnitsRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkTextObj->SetTextString(strTempUnits.GetBuffer(strTempUnits.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = FALSE;
			pkTextObj->m_pCMMtext->IsUnits = FALSE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = ptMaxTCPen->Style.Colour;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
			pkTextObj->ConfigChange();
		}
		tLabelRect = tDigObjRect;
		tLabelRect.setright(tTagRect).right;
		tLabelRect.setTop(lOBJ_HEIGHT);
		tLabelRect.setBottom(_Height)(tWidgetRect) - 1;
		// create a blank text object to give us a bit of white space
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = "";
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
	}
	// move onto the Min TC column now
	tWidgetRect.setTop(lWIDGET_HEIGHT);
	tWidgetRect.setBottom(lWIDGET_HEIGHT);
#ifdef DOCVIEW
	// need to offset the rect here, since AddNewWidget expects screen co-ords.
	OffsetRect(&tWidgetRect,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tWidgetRect)) {
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWidgetBkgCol));
		// move by an extra pixel so we end up with a seperator line betwen the groups of digitals/text objects
		tLabelRect = tDPMRect;
		tLabelRect.setBottom(tLabelRect).top + lOBJ_HEIGHT;
		// create a blank text object to give us a bit of white space
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = "";
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
		// move down
		tLabelRect.setTop(lOBJ_HEIGHT);
		tLabelRect.setBottom(lOBJ_HEIGHT);
		// create the min TC label text object 
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = tr("Min TUS Sensor");
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = FALSE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = ptMinTCPen->Style.Colour;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
		tTagRect = tLabelRect;
		tTagRect.setTop(lOBJ_HEIGHT);
		tTagRect.setBottom(lOBJ_HEIGHT);
		// create the min tc name text object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the next item in the widgets channel list (to be added below)
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[ptChanRef->IndexChan],
					DI_GEN_AMS2750_MIN_TC);
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 1; // fast as possible
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = TRUE;
			pkTextObj->m_pCMMtext->FixText = FALSE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = ptMinTCPen->Style.Colour;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
			pkTextObj->ConfigChange();
		}
		tDigObjRect = tTagRect;
		tDigObjRect.setTop(lOBJ_HEIGHT);
		tDigObjRect.setBottom(lOBJ_HEIGHT);
		tDigObjRect.setRight(lUNITS_LABEL_WIDTH);
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &tDigObjRect)) {
			pkDigObj = static_cast<CDigitalObject*>(m_pSelectedWidget->m_pSelectedObject);
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->BackColour = static_cast<ULONG>(crObjBkgCol);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the current item in the widgets channel list added for the text object above
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 1; // fast as possible
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->FixForeColour = TRUE;
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->ForeColour = ptMinTCPen->Style.Colour;
			pkDigObj->m_pCMMdigital->FixNumasprintf = TRUE;
			pkDigObj->m_pCMMdigital->Numformat.Auto = FALSE;
			pkDigObj->m_pCMMdigital->Numformat.Scientific = FALSE;
			pkDigObj->m_pCMMdigital->Numformat.Ad = 1;
		} else {
			bFoundObjectError = true;
		}
		tUnitsRect.setTop(tDigObjRect).top;
		tUnitsRect.setBottom(tDigObjRect).bottom;
		tUnitsRect.setleft(tDigObjRect).right;
		tUnitsRect.setright(tTagRect).right;
		// create the min tc units label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tUnitsRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkTextObj->SetTextString(strTempUnits.GetBuffer(strTempUnits.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = FALSE;
			pkTextObj->m_pCMMtext->IsUnits = FALSE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = ptMinTCPen->Style.Colour;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
			pkTextObj->ConfigChange();
		}
		tLabelRect = tDigObjRect;
		tLabelRect.setright(tTagRect).right;
		tLabelRect.setTop(lOBJ_HEIGHT);
		tLabelRect.setBottom(_Height)(tWidgetRect) - 1;
		// create a blank text object to give us a bit of white space
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = "";
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
	} else {
		bFoundObjectError = true;
	}
	// move onto the TC Diff column now
	tWidgetRect.setTop(lWIDGET_HEIGHT);
	tWidgetRect.setBottom(lWIDGET_HEIGHT);
#ifdef DOCVIEW
	// need to offset the rect here, since AddNewWidget expects screen co-ords.
	OffsetRect(&tWidgetRect,m_pOpPanel->m_RecScreenOffset.x,m_pOpPanel->m_RecScreenOffset.y);
#endif
	if (m_pOpPanel->AddNewWidget(m_pOpPanel->m_pCannedConfig, &tWidgetRect)) {
		m_pSelectedWidget->m_pCMMwidget->BackColour = static_cast< USHORT >(RGBtoRGB565(crWidgetBkgCol));
		// move by an extra pixel so we end up with a seperator line betwen the groups of digitals/text objects
		tLabelRect = tDPMRect;
		tLabelRect.setBottom(tLabelRect).top + lOBJ_HEIGHT;
		// create a blank text object to give us a bit of white space
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = "";
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
		// move down
		tLabelRect.setTop(lOBJ_HEIGHT);
		tLabelRect.setBottom(lOBJ_HEIGHT);
		// create the min TC label text object 
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = tr("TUS Sensor");
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = FALSE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
		tTagRect = tLabelRect;
		tTagRect.setTop(lOBJ_HEIGHT);
		tTagRect.setBottom(lOBJ_HEIGHT);
		// create the tc diff name text object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tTagRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = tr("Diff");
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = TRUE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
			pkTextObj->ConfigChange();
		}
		tDigObjRect = tTagRect;
		tDigObjRect.setTop(lOBJ_HEIGHT);
		tDigObjRect.setBottom(lOBJ_HEIGHT);
		tDigObjRect.setRight(lUNITS_LABEL_WIDTH);
		// now add the TC diff value digital object
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_DIGITALOBJECT, &tDigObjRect)) {
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->BackColour = static_cast<ULONG>(crObjBkgCol);
			ptChanRef = m_pSelectedWidget->GetObjChanRef(m_pSelectedWidget->m_pSelectedObject, usNumChannels);
			ptChanRef->Enabled = TRUE;
			ptChanRef->Updates = TRUE;
			ptChanRef->ItemType = DI_GENERAL; // default 
			ptChanRef->SubType = DI_GENTYPE_GENERAL;
			ptChanRef->IndexChan = 0; // use the current item in the widgets channel list added for the text object above
			SetScreenInstance(m_pSelectedWidget->m_pCMMwidget->ChannelList[ptChanRef->IndexChan],
					DI_GEN_AMS2750_TC_DIFF);
			m_pSelectedWidget->m_pSelectedObject->m_pCMMbase->UpdateRate100 = 1; // fast as possible
		} else {
			bFoundObjectError = true;
		}
		tUnitsRect.setTop(tDigObjRect).top;
		tUnitsRect.setBottom(tDigObjRect).bottom;
		tUnitsRect.setleft(tDigObjRect).right;
		tUnitsRect.setright(tTagRect).right;
		// create the tc diff units label
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tUnitsRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			pkTextObj->SetTextString(strTempUnits.GetBuffer(strTempUnits.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			pkTextObj->m_pCMMtext->Font.Quality = 1; //antialiased
			pkTextObj->m_pCMMtext->Wordwrap = TRUE;
			pkTextObj->m_pCMMtext->Base.FixForeColour = TRUE;
			pkTextObj->m_pCMMtext->Base.ForeColour = QString(0, 0, 0); // black
			pkTextObj->m_pCMMtext->Base.IsBuffered = TRUE;
			pkTextObj->m_pCMMtext->IsTag = FALSE;
			pkTextObj->m_pCMMtext->IsUnits = FALSE;
			pkTextObj->m_pCMMtext->FixText = TRUE;
			pkTextObj->m_pCMMtext->Center = TRUE;
			pkTextObj->m_pCMMtext->Font.Height = 12;
			pkTextObj->m_pCMMtext->Font.Weight = 1;
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
			pkTextObj->ConfigChange();
		}
		tLabelRect = tDigObjRect;
		tLabelRect.setright(tTagRect).right;
		tLabelRect.setTop(lOBJ_HEIGHT);
		tLabelRect.setBottom(_Height)(tWidgetRect);
		// create a blank text object to give us a bit of white space
		if (m_pOpPanel->AddNewObject(m_pOpPanel->m_pCannedConfig, BLK_TEXTOBJECT, &tLabelRect)) {
			pkTextObj = static_cast<CTextObject*>(m_pSelectedWidget->m_pSelectedObject);
			strLabel = "";
			pkTextObj->SetTextString(strLabel.GetBuffer(strLabel.size()));
			pkTextObj->m_pCMMtext->Base.BackColour = static_cast<ULONG>(crObjBkgCol);
			// no border
			pkTextObj->m_pCMMtext->Base.Border.BorderUsed = FALSE;
		}
	} else {
		bFoundObjectError = true;
	}
	// log an error if one or more objects failed to be created
	if (bFoundObjectError) {
		QString strError("");
		strError = QString::asprintf("Failed to create AMS2750 TUS screen display object(s), %s", m_pCMMscreen->Name);
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	}
}
//****************************************************************************
///
/// Mehod that returns true if the Pen is currently displed on active screen
///
/// @param[in]		const QRect tDPM_AREA - The DPM area that we must populate
///
//****************************************************************************
BOOL CScreen::IsPenSelected(T_PEN *ptPenData) {
	if (ptPenData) {
		if (m_pCMMscreen->UseGroups) {
			// Groups Enabled check if Pen is in this Group;
			if (m_pCMMscreen->GroupIndex + 1 == ptPenData->GroupNumber)
				return TRUE;
		} else {
			// check if Pen is selected to display on screen
			for (int i = 0; i < 32; i++) {
				if (m_pCMMscreen->CannedPens[i].PenIndex == ptPenData->Instance)
					return TRUE;
			}
			return FALSE;
		}
	}
	return false;
}
//****************************************************************************
///
/// Mehod that returns true if the Timer/User var is currently displed on active screen
///
/// @param[in]		const QRect tDPM_AREA - The DPM area that we must populate
///
//****************************************************************************
BOOL CScreen::IsItemSelected(CPickerData *ptPickerData, USHORT usCurrItem, T_CFG_DATA_TYPE dataType, int MaxItems) {
	if (ptPickerData) {
		USHORT *pusData = NULL;
		pusData = reinterpret_cast< USHORT*>(ptPickerData);
		CPickerData kPickerData(pusData, dataType, 0, 0, false, 0, MaxItems, 0);
		CPickerMgr kPickerMgr;
		kPickerData.SetupPickerMgr(kPickerMgr);
		CPickerItem *pkItem = kPickerMgr.GetFirstItem();
		while (pkItem != NULL) {
			if (pkItem->GetInstanceNo() == usCurrItem)
				return pkItem->GetSelected();
			pkItem = kPickerMgr.GetNextItem();
		}
		return FALSE;
	}
	return FALSE;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: DigitalObj.h
/// @n Description: Digital Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  14  Stability Project 1.11.1.1 7/2/2011 4:56:46 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  13  Stability Project 1.11.1.0 7/1/2011 4:25:53 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  12  V6 Firmware 1.11 9/23/2008 3:09:23 PM  Build Machine 
//  AMS2750 Merge
//  11  V6 Firmware 1.10 11/22/2005 9:52:48 PM  David Fulmer (Ft
//  Washington) Fixed problem with keeping the link positions aligned for
//  multiple scale instances on multiple custom screens using the same
//  template
// $
//
// **************************************************************************
#ifndef _DIGITALOBJ_H
#define _DIGITALOBJ_H
#define ARROW_VERTICES 7
//**Class*********************************************************************
///
/// @brief Digital Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used to show digital values in a Widget in OpPanel
///
//****************************************************************************
class CDigitalObject: public CBaseObject {
private:
	float m_CurrentValue;			///< Current value of channel (pen) to be displayed
	T_DATAITEM_STATUS m_CurrentStatus; ///< Current status
	BOOL m_InAlarm;					///< Current alarm state (if enabled for this digital)
	BOOL m_IsLogScale;
	COLORREF *m_pForeAlarmColour;  ///< colour for flashing foreground 
	COLORREF *m_pBackAlarmColour;	///< colour for flashing background
	T_NUMFORMAT m_Numberasprintf;
	WCHAR m_pasprintfStr[20];
//	QPoint m_DownArrowScaled[ARROW_VERTICES];
//	QPoint m_UpArrowScaled[ARROW_VERTICES];
	CDataItemRef *m_pDataItemRef;	///< data item table references 0=Pen, 1=Alarm
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data begin
	bool m_bDisplayStar;
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data end
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CDigitalObject *pThis, HDC hdc, QRect *pClipRect);
	void CalcArrows();
	void DrawUpArrow(HDC hdc);
	void DrawDownArrow(HDC hdc);
	void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL); // virtual function override
public:
	CDigitalObject(CWidget *pWidget);
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data begin
	bool IsDisplayStar() {
		return m_bDisplayStar;
	}
	void SetDisplayStar(bool bDisplayStar) {
		m_bDisplayStar = bDisplayStar;
	}
	//PSR Fix for PAR# 1-3K9UACQ - Circular History shows DPM live data end
	T_DIGITALOBJECT *m_pCMMdigital;	///< pointer to our CMM configuration
};
#endif

/// @file 
/// **************************************************************************
/// ï¿½ Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: Utilities.cpp 
/// @n Description: Utility functions for OpPanel
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  69  Stability Project 1.64.1.3 7/2/2011 5:02:23 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  68  Stability Project 1.64.1.2 7/1/2011 4:39:05 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  67  Stability Project 1.64.1.1 3/17/2011 3:20:53 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  66  Stability Project 1.64.1.0 2/15/2011 3:04:09 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
// 
// **************************************************************************
#include "V6defines.h"
#include "V6Config.h"
#include "StoragePaths.h"
#include "V6globals.h"
#include "FFConversionInfo.h"
#include "TVtime.h"
#include "Utilities.h"
#include "StringUtils.h"
#include "math.h"
#include "SystemConfiguration.h"
#include "UISizeDefines.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#ifdef TTR6SETUP
	int Glb_BitsPerPixel=0;
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
///
/// function for drawing "grab handles" 
/// this will be used by both Objects and Widgets
///
/// @param[in] hdc		- Device Context handle to draw to
/// @param[in] bounds	- reference to bounds to draw handles around 
/// @param[in] colour	- colour of handles to draw 
///
/// @return none
/// 
//****************************************************************************
void DrawHandles(HDC hdc, QRect &bounds, COLORREF colour) {
	// set up a rectangles for each handle..
	QRect topleft, topmiddle, topright, rightmiddle, bottomright, bottommiddle, bottomleft, leftmiddle;
	// configure top-left handle
	SetRect(&topleft, bounds.left - GRABSIZE, bounds.top - GRABSIZE, bounds.left + GRABSIZE + 1,
			bounds.top + GRABSIZE + 1);
	// configure top handle
	topmiddle = topleft;
	OffsetRect(&topmiddle, (_Width(bounds) - 1) / 2, 0);
	// configure top-right handle
	topright = topleft;
	OffsetRect(&topright, _Width(bounds) - 1, 0);
	// configure left handle
	leftmiddle = topleft;
	OffsetRect(&leftmiddle, 0, (_Height(bounds) - 1) / 2);
	// configure right handle
	rightmiddle = leftmiddle;
	OffsetRect(&rightmiddle, _Width(bounds) - 1, 0);
	// configure bottom-right handle
	bottomright = topright;
	OffsetRect(&bottomright, 0, _Height(bounds) - 1);
	// configure bottom handle
	bottommiddle = topmiddle;
	OffsetRect(&bottommiddle, 0, _Height(bounds) - 1);
	// configure bottom-left handle
	bottomleft = topleft;
	OffsetRect(&bottomleft, 0, _Height(bounds) - 1);
	// create the brush to fill the handles with
	HBRUSH handlebrush = CreateSolidBrush(colour);
	HBRUSH hOldBrush = (HBRUSH) SelectObject(hdc, handlebrush);
	// create the pen to use for the edges of the handles
	QPen hPen = ::CreatePen(PS_SOLID, 0, RGB(255, 255, 255)); // white
	QPen hOldPen = (QPen) SelectObject(hdc, hPen);
	// draw all the rectangles (drawn with the current pen and filled with the current brush)
	Rectangle(hdc, topmiddle.left, topmiddle.top, topmiddle.right, topmiddle.bottom);
	Rectangle(hdc, bottommiddle.left, bottommiddle.top, bottommiddle.right, bottommiddle.bottom);
	Rectangle(hdc, leftmiddle.left, leftmiddle.top, leftmiddle.right, leftmiddle.bottom);
	Rectangle(hdc, rightmiddle.left, rightmiddle.top, rightmiddle.right, rightmiddle.bottom);
	Rectangle(hdc, topleft.left, topleft.top, topleft.right, topleft.bottom);
	Rectangle(hdc, topright.left, topright.top, topright.right, topright.bottom);
	Rectangle(hdc, bottomleft.left, bottomleft.top, bottomleft.right, bottomleft.bottom);
	Rectangle(hdc, bottomright.left, bottomright.top, bottomright.right, bottomright.bottom);
	// tidy up
	SelectObject(hdc, hOldPen);
	SelectObject(hdc, hOldBrush);
	DeleteObject(hPen);
	DeleteObject(handlebrush);
}
//****************************************************************************
///
/// function for Hit Testing "grab handles" for Objects and Widgets
/// A rectangle will be created for each handle and the mouse point checked
/// to see if it is inside any of them. If so, the resizeState will be set
/// to identify which handle it is.
///
/// @param[in] bounds		- reference to bounds to check handles around 
/// @param[out] resizeState	- reference to resize operation enum
/// @param[in] point		- mouse point to hit test
///
/// @return True/False (True if a handle is hit)
/// 
//****************************************************************************
BOOL HitTestHandles(QRect &bounds, ResizeType &resizeState, QPoint &point) {
	// set up a rectangles for each handle..
	QRect topleft, topmiddle, topright, leftmiddle, rightmiddle, bottomleft, bottommiddle, bottomright;
	// The handles are drawn in a certain order, so we need to hit-test in reverse order.
	// configure bottom-right handle
	SetRect(&bottomright, bounds.right - GRABSIZE, bounds.bottom - GRABSIZE, bounds.right + GRABSIZE + 1,
			bounds.bottom + GRABSIZE + 1);
	// Hit test bottom-right
	if (PtInRect(&bottomright, point)) {
		resizeState = Bottomright;
		return TRUE;
	}
	// configure bottom left handle
	bottomleft = bottomright;
	OffsetRect(&bottomleft, -(_Width(bounds) - 1), 0);
	// Hit test bottom left handle
	if (PtInRect(&bottomleft, point)) {
		resizeState = Bottomleft;
		return TRUE;
	}
	// configure top-right handle
	topright = bottomright;
	OffsetRect(&topright, 0, -(_Height(bounds) - 1));
	// Hit test top-right handle
	if (PtInRect(&topright, point)) {
		resizeState = Topright;
		return TRUE;
	}
	// configure top-left handle	
	topleft = bottomleft;
	OffsetRect(&topleft, 0, -(_Height(bounds) - 1));
	// Hit test top-left handle
	if (PtInRect(&topleft, point)) {
		resizeState = Topleft;
		return TRUE;
	}
	// configure right handle	
	rightmiddle = topright;
	OffsetRect(&rightmiddle, 0, (_Height(bounds) - 1) / 2);
	// Hit test right handle	
	if (PtInRect(&rightmiddle, point)) {
		resizeState = rightmiddle;
		return TRUE;
	}
	// configure left handle	
	leftmiddle = rightmiddle;
	OffsetRect(&leftmiddle, -(_Width(bounds) - 1), 0);
	// Hit test left handle	
	if (PtInRect(&leftmiddle, point)) {
		resizeState = leftmiddle;
		return TRUE;
	}
	// configure bottom handle	
	bottommiddle = bottomleft;
	OffsetRect(&bottommiddle, (_Width(bounds) - 1) / 2, 0);
	// Hit test bottom handle	
	if (PtInRect(&bottommiddle, point)) {
		resizeState = Bottommiddle;
		return TRUE;
	}
	// configure top handle	
	topmiddle = bottommiddle;
	OffsetRect(&topmiddle, 0, -(_Height(bounds) - 1));
	// Hit test top handle	
	if (PtInRect(&topmiddle, point)) {
		resizeState = Topmiddle;
		return TRUE;
	}
	// otherwise, no handle hit.
	resizeState = ResizeNone;
	return FALSE;
}
int dcount = 0;
struct t_points {
	long tl_left;
	long tl_top;
	long tr_right;
	long tr_top;
	long br_right;
	long br_bottom;
	long bl_left;
	long bl_bottom;
	long tl_left2;
	long tl_top2;
} points;
//****************************************************************************
///
/// function for drawing a border
/// this will be used by both Objects and Widgets
///
/// @param[in] hdc		- Device Context handle to draw to
/// @param[in] bounds	- bounds of object/widget to draw border within
/// @param[in] border	- border details struct 
///
/// @return none
/// 
//****************************************************************************
void DrawBorder(HDC hdc, QRect bounds, T_BORDER *border) {
	if (border->BorderStyle == bsFLAT) //flat
			{
		// create the pen to use for the border
		QPen hPen = ::CreatePen(PS_SOLID, 0, border->BorderColour); // get from cmm
		QPen hOldPen = (QPen) SelectObject(hdc, hPen);
		points.tl_left = points.tl_left2 = bounds.left;
		points.tl_top = points.tl_top2 = bounds.top;
		points.tr_right = bounds.right - 1;
		points.tr_top = bounds.top;
		points.br_right = bounds.right - 1;
		points.br_bottom = bounds.bottom - 1;
		points.bl_left = bounds.left;
		points.bl_bottom = bounds.bottom - 1;
		for (int i = 0; i < border->BorderWidth; i++) {
			// draw the border 
			// draw in lines, since rectangle fills with the current brush!
			// use polyline here to draw 4 lines in one hit.
			Polyline(hdc, (QPoint*) &points, 5);
			// then update the points
			points.tl_left++;
			points.tl_top++;
			points.tr_right--;
			points.tr_top++;
			points.br_right--;
			points.br_bottom--;
			points.bl_left++;
			points.bl_bottom--;
			points.tl_left2++;
			points.tl_top2++;
		}
		// tidy up
		SelectObject(hdc, hOldPen);
		DeleteObject(hPen);
	} else // other
	{
		COLORREF colour1;
		COLORREF colour2;
		COLORREF colour3;
		COLORREF colour4;
		if (border->BorderStyle == bsRAISED) //raised
				{
			colour1 = ColourAdjust(border->BorderColour, +70);
			colour2 = ColourAdjust(border->BorderColour, -20);
			colour3 = ColourAdjust(border->BorderColour, -70);
			colour4 = ColourAdjust(border->BorderColour, +40);
		} else // inset
		{
			colour1 = ColourAdjust(border->BorderColour, -70);
			colour2 = ColourAdjust(border->BorderColour, +40);
			colour3 = ColourAdjust(border->BorderColour, +70);
			colour4 = ColourAdjust(border->BorderColour, -20);
		}
		QPen hPen1 = ::CreatePen(PS_SOLID, 0, colour1);
		QPen hPen2 = ::CreatePen(PS_SOLID, 0, colour2);
		QPen hPen3 = ::CreatePen(PS_SOLID, 0, colour3);
		QPen hPen4 = ::CreatePen(PS_SOLID, 0, colour4);
		QPen hOldPen = (QPen) SelectObject(hdc, hPen4); // keep original pen here
		for (int i = 0; i < border->BorderWidth; i++) {
			// draw the border 
			// draw in lines, since rectangle fills with the current brush!
			MoveToEx(hdc, bounds.left, bounds.top, NULL);
			SelectObject(hdc, hPen1);
			LineTo(hdc, bounds.right - 1, bounds.top);
			SelectObject(hdc, hPen2);
			LineTo(hdc, bounds.right - 1, bounds.bottom - 1);
			SelectObject(hdc, hPen3);
			LineTo(hdc, bounds.left, bounds.bottom - 1);
			SelectObject(hdc, hPen4);
			LineTo(hdc, bounds.left, bounds.top);
			InflateRect(&bounds, -1, -1);
		}
		SelectObject(hdc, hOldPen); // put the original pen back
		// and tidy up
		DeleteObject(hPen4);
		DeleteObject(hPen3);
		DeleteObject(hPen2);
		DeleteObject(hPen1);
	}
}
//****************************************************************************
///
/// Returns a 16-bit or 32-bit Fill colour
///
/// @param[in] x- 16-bit (RGB565) colour. Return it unchanged on 16-bit system
///
/// @return fill colour 
/// 
//****************************************************************************
DWORD Fillcolour(USHORT x) {
	if (Glb_BitsPerPixel == 32)
		return RGB565toRGB888(x);	// extracting 32-bit colour from 16-bit colour
	else
		return x; // use the colour as it is
}
//****************************************************************************
///
/// Returns a 16-bit or 32-bit Fill colour
///
/// @param[in] x- 32-bit RGB colour. Return it unchanged on 32-bit system
///
/// @return fill colour 
/// 
//****************************************************************************
DWORD Fillcolourfromrgb(COLORREF x) {
	if (Glb_BitsPerPixel == 16)
		return RGBtoRGB565(x);	// extracting 16-bit colour from 32-bit colour
	else
		return RGBtoRGB888(x); // get an RGB888 from the RGB colour (both 32-bit)
}
//****************************************************************************
///
///	Adjust a colour's components (red, green and blue) by an amount 
///
/// @param[in] colour	- COLORREF to change
/// @param[in] adjust	- amount to add to each component
///
/// @return COLORREF of the adjusted colour.
/// 
//****************************************************************************
COLORREF ColourAdjust(COLORREF colour, int adjust) {
	int r = GetRValue(colour);
	int g = GetGValue(colour);
	int b = GetBValue(colour);
	r += adjust;
	if (r < 0)
		r = 0;
	else if (r > 255)
		r = 255;
	g += adjust;
	if (g < 0)
		g = 0;
	else if (g > 255)
		g = 255;
	b += adjust;
	if (b < 0)
		b = 0;
	else if (b > 255)
		b = 255;
	return RGB(r, g, b);
}
//****************************************************************************
///
/// Selects a 16-bit or 32-bit Transparent Alpha blend
///
/// @param[in] pDestSurf- pointer to destination surface
/// @param[in] pSrcSurf	- pointer to source surface
/// @param[in] destX	- destination X coordinate
/// @param[in] destY	- destination Y coordinate
/// @param[in] srcX		- source X coordinate
/// @param[in] srcY		- source Y coordinate
/// @param[in] width	- width of rectangle to blend
/// @param[in] height	- height of rectangle to blend
/// @param[in] colourKey- source colour Key for Transparent area
///
/// @return none
/// 
//****************************************************************************
//E437415
void ChooseTransAlphaBlend(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height, DWORD colourKey) {
	if (Glb_BitsPerPixel == 16)
		TransAlphaBlend16(pDestSurf, pSrcSurf, destX, destY, srcX, srcY, width, height, (unsigned short) colourKey);
	else
		TransAlphaBlend32(pDestSurf, pSrcSurf, destX, destY, srcX, srcY, width, height, colourKey);
}
//****************************************************************************
///
/// Performs a 16-bit Transparent Alpha blend
///
/// @param[in] pDestSurf- pointer to destination surface
/// @param[in] pSrcSurf	- pointer to source surface
/// @param[in] destX	- destination X coordinate
/// @param[in] destY	- destination Y coordinate
/// @param[in] srcX		- source X coordinate
/// @param[in] srcY		- source Y coordinate
/// @param[in] width	- width of rectangle to blend
/// @param[in] height	- height of rectangle to blend
/// @param[in] colourKey- source colour Key for Transparent area (16-bit)
///
/// @return none
/// 
//****************************************************************************
//E437415
void TransAlphaBlend16(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height, WORD colourKey) {
	//E437415
	DDSURFACEDESC destDesc, srcDesc; // two surface descriptions
	memset(&destDesc, 0, sizeof(destDesc));
	memset(&srcDesc, 0, sizeof(srcDesc));
	destDesc.dwSize = sizeof(destDesc);
	srcDesc.dwSize = sizeof(srcDesc);
	// now try and lock the surfaces
	//E437415
	//DDLOCK_WAIT flag is no longer supported for windows embedded ce 6.0
	//Use DDLOCK_WAITNOTBUSY instead of DDLOCK_WAIT
	//E529380 should do above changes only for CE compilation.
#ifdef UNDER_CE
	if(SUCCEEDED(pDestSurf->Lock(NULL,&destDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
	if (SUCCEEDED(pDestSurf->Lock(NULL, &destDesc, DDLOCK_WAIT, NULL)))
#endif
			{
		//E437415
		//DDLOCK_WAIT flag is no longer supported for windows embedded ce 6.0
		//Use DDLOCK_WAITNOTBUSY instead of DDLOCK_WAIT in following statement
		// if(SUCCEEDED(pSrcSurf->Lock(NULL,&srcDesc,DDLOCK_WAIT,NULL)))
		//DDLOCK_WAITNOTBUSY :if a previous drawing operation is in progress at the time of the call, 
		//this flag defers returning from the call until the surface is locked or an error occurs.
		//E519766
		//E529380 should do above changes only for CE compilation.
#ifdef UNDER_CE
 		if(SUCCEEDED(pSrcSurf->Lock(NULL,&srcDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
		if (SUCCEEDED(pSrcSurf->Lock(NULL, &srcDesc, DDLOCK_WAIT, NULL)))
#endif
				{
			// surface description details now obtained
			// obtain pointers to start of surface data
			WORD *pDest = (WORD*) destDesc.lpSurface;
			WORD *pSrc = (WORD*) srcDesc.lpSurface;
			// then update to the correct positions on the surfaces
			pDest += destX + (destY * (destDesc.lPitch / 2)); // lPitch is in bytes
			pSrc += srcX + (srcY * (srcDesc.lPitch / 2));
			while (--height >= 0) // each horizontal line
			{
				// set pointers for start of each row
				WORD *pDestWord = pDest;
				WORD *pSrcWord = pSrc;
				int column = width;
				while (--column >= 0) // each column
				{
					// check for source colour key (source is transparent here, so destination remains as it is)
					if (*pSrcWord != colourKey)
						*pDestWord = ((*pSrcWord & 0xF7DE) >> 1) + ((*pDestWord & 0xF7DE) >> 1); // fast 50:50 blend		
					// move on..
					pDestWord++;
					pSrcWord++;
				}
				// now calculate start of next row
				pDest += (destDesc.lPitch / 2);
				pSrc += (srcDesc.lPitch / 2);
			}
			pSrcSurf->Unlock(NULL);
		}
		pDestSurf->Unlock(NULL);
	}
}
//****************************************************************************
///
/// Performs a 32-bit Transparent Alpha blend
///
/// @param[in] pDestSurf- pointer to destination surface
/// @param[in] pSrcSurf	- pointer to source surface
/// @param[in] destX	- destination X coordinate
/// @param[in] destY	- destination Y coordinate
/// @param[in] srcX		- source X coordinate
/// @param[in] srcY		- source Y coordinate
/// @param[in] width	- width of rectangle to blend
/// @param[in] height	- height of rectangle to blend
/// @param[in] colourKey- source colour Key for Transparent area (32-bit)
///
/// @return none
/// 
//****************************************************************************
//E437415
void TransAlphaBlend32(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height, DWORD colourKey) {
	//E437415
	DDSURFACEDESC destDesc, srcDesc; // two surface descriptions
	memset(&destDesc, 0, sizeof(destDesc));
	memset(&srcDesc, 0, sizeof(srcDesc));
	destDesc.dwSize = sizeof(destDesc);
	srcDesc.dwSize = sizeof(srcDesc);
	// now try and lock the surfaces
	//E437415
	//DDLOCK_WAIT flag is no longer supported for windows embedded ce 6.0
	//Use DDLOCK_WAITNOTBUSY instead of DDLOCK_WAIT
	//E519766
	//E529380 should do above changes only for CE compilation.
#ifdef UNDER_CE
	if(SUCCEEDED(pDestSurf->Lock(NULL,&destDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
	if (SUCCEEDED(pDestSurf->Lock(NULL, &destDesc, DDLOCK_WAIT, NULL)))
#endif
			{
		//E529380 should do above changes only for CE compilation.
#ifdef UNDER_CE
		if(SUCCEEDED(pSrcSurf->Lock(NULL,&srcDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
		if (SUCCEEDED(pSrcSurf->Lock(NULL, &srcDesc, DDLOCK_WAIT, NULL)))
#endif
				{
			// surface description details now obtained
			// obtain pointers to start of surface data
			DWORD *pDest = (DWORD*) destDesc.lpSurface;
			DWORD *pSrc = (DWORD*) srcDesc.lpSurface;
			// then update to the correct positions on the surfaces
			pDest += destX + (destY * (destDesc.lPitch / 4)); // lPitch is in bytes
			pSrc += srcX + (srcY * (srcDesc.lPitch / 4));
			while (--height >= 0) // each horizontal line
			{
				// set pointers for start of each row
				DWORD *pDestDWord = pDest;
				DWORD *pSrcDWord = pSrc;
				int column = width;
				while (--column >= 0) // each column
				{
					// check for source colour key (source is transparent here, so destination remains as it is)
					if (*pSrcDWord != colourKey)
						*pDestDWord = ((*pSrcDWord & 0x00FEFEFE) >> 1) + ((*pDestDWord & 0x00FEFEFE) >> 1);	// fast 50:50 blend		
					// move on..
					pDestDWord++;
					pSrcDWord++;
				}
				// now calculate start of next row
				pDest += (destDesc.lPitch / 4);
				pSrc += (srcDesc.lPitch / 4);
			}
			pSrcSurf->Unlock(NULL);
		}
		pDestSurf->Unlock(NULL);
	}
}
//****************************************************************************
///
/// Selects a 16-bit or 32-bit Alpha blend (no colour key)
///
/// @param[in] pDestSurf- pointer to destination surface
/// @param[in] pSrcSurf	- pointer to source surface
/// @param[in] destX	- destination X coordinate
/// @param[in] destY	- destination Y coordinate
/// @param[in] srcX		- source X coordinate
/// @param[in] srcY		- source Y coordinate
/// @param[in] width	- width of rectangle to blend
/// @param[in] height	- height of rectangle to blend
///
/// @return none
/// 
//****************************************************************************
//E437415
void ChooseAlphaBlend(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height) {
	if (Glb_BitsPerPixel == 16)
		AlphaBlend16(pDestSurf, pSrcSurf, destX, destY, srcX, srcY, width, height);
	else
		AlphaBlend32(pDestSurf, pSrcSurf, destX, destY, srcX, srcY, width, height);
}
//****************************************************************************
///
/// Performs a standard 16-bit Alpha blend (no colour Key)
///
/// @param[in] pDestSurf- pointer to destination surface
/// @param[in] pSrcSurf	- pointer to source surface
/// @param[in] destX	- destination X coordinate
/// @param[in] destY	- destination Y coordinate
/// @param[in] srcX		- source X coordinate
/// @param[in] srcY		- source Y coordinate
/// @param[in] width	- width of rectangle to blend
/// @param[in] height	- height of rectangle to blend
///
/// @return none
/// 
//****************************************************************************
//E437415
void AlphaBlend16(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX, int srcY,
		int width, int height) {
	//E437415
	DDSURFACEDESC destDesc, srcDesc; // two surface descriptions
	memset(&destDesc, 0, sizeof(destDesc));
	memset(&srcDesc, 0, sizeof(srcDesc));
	destDesc.dwSize = sizeof(destDesc);
	srcDesc.dwSize = sizeof(srcDesc);
	// now try and lock the surfaces
	//E437415
	//DDLOCK_WAIT flag is no longer supported for windows embedded ce 6.0
	//Use DDLOCK_WAITNOTBUSY instead of DDLOCK_WAIT 
	//E519766
#ifdef UNDER_CE
	if(SUCCEEDED(pDestSurf->Lock(NULL,&destDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
	if (SUCCEEDED(pDestSurf->Lock(NULL, &destDesc, DDLOCK_WAIT, NULL)))
#endif
			{
#ifdef UNDER_CE
		if(SUCCEEDED(pSrcSurf->Lock(NULL,&srcDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
		if (SUCCEEDED(pSrcSurf->Lock(NULL, &srcDesc, DDLOCK_WAIT, NULL)))
#endif
				{
			// surface description details now obtained
			// obtain pointers to start of surface data
			WORD *pDest = (WORD*) destDesc.lpSurface;
			WORD *pSrc = (WORD*) srcDesc.lpSurface;
			// then update to the correct positions on the surfaces
			pDest += destX + (destY * (destDesc.lPitch / 2)); // lPitch is in bytes
			pSrc += srcX + (srcY * (srcDesc.lPitch / 2));
			while (--height >= 0) // each horizontal line
			{
				// set pointers for start of each row
				WORD *pDestWord = pDest;
				WORD *pSrcWord = pSrc;
				int column = width;
				while (--column >= 0) // each column
				{
					*pDestWord = ((*pSrcWord & 0xF7DE) >> 1) + ((*pDestWord & 0xF7DE) >> 1);	// fast 50:50 blend		
					// move on..
					pDestWord++;
					pSrcWord++;
				}
				// now calculate start of next row
				pDest += (destDesc.lPitch / 2);
				pSrc += (srcDesc.lPitch / 2);
			}
			pSrcSurf->Unlock(NULL);
		}
		pDestSurf->Unlock(NULL);
	}
}
//****************************************************************************
///
/// Performs a standard 32-bit Alpha blend (no colour Key)
///
/// @param[in] pDestSurf- pointer to destination surface
/// @param[in] pSrcSurf	- pointer to source surface
/// @param[in] destX	- destination X coordinate
/// @param[in] destY	- destination Y coordinate
/// @param[in] srcX		- source X coordinate
/// @param[in] srcY		- source Y coordinate
/// @param[in] width	- width of rectangle to blend
/// @param[in] height	- height of rectangle to blend
///
/// @return none
/// 
//****************************************************************************
//E437415
void AlphaBlend32(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX, int srcY,
		int width, int height) {
	DDSURFACEDESC destDesc, srcDesc; // two surface descriptions
	memset(&destDesc, 0, sizeof(destDesc));
	memset(&srcDesc, 0, sizeof(srcDesc));
	destDesc.dwSize = sizeof(destDesc);
	srcDesc.dwSize = sizeof(srcDesc);
	// now try and lock the surfaces
	//E437415
	//DDLOCK_WAIT flag is no longer supported for windows embedded ce 6.0
	//Use DDLOCK_WAITNOTBUSY instead of DDLOCK_WAIT 
	//E519766
#ifdef UNDER_CE	
	if(SUCCEEDED(pDestSurf->Lock(NULL,&destDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
	if (SUCCEEDED(pDestSurf->Lock(NULL, &destDesc, DDLOCK_WAIT, NULL)))
#endif
			{
#ifdef UNDER_CE
		if(SUCCEEDED(pSrcSurf->Lock(NULL,&srcDesc,DDLOCK_WAITNOTBUSY,NULL)))
#else
		if (SUCCEEDED(pSrcSurf->Lock(NULL, &srcDesc, DDLOCK_WAIT, NULL)))
#endif
				{
			// surface description details now obtained
			// obtain pointers to start of surface data
			DWORD *pDest = (DWORD*) destDesc.lpSurface;
			DWORD *pSrc = (DWORD*) srcDesc.lpSurface;
			// then update to the correct positions on the surfaces
			pDest += destX + (destY * (destDesc.lPitch / 4)); // lPitch is in bytes
			pSrc += srcX + (srcY * (srcDesc.lPitch / 4));
			while (--height >= 0) // each horizontal line
			{
				// set pointers for start of each row
				DWORD *pDestDWord = pDest;
				DWORD *pSrcDWord = pSrc;
				int column = width;
				while (--column >= 0) // each column
				{
					*pDestDWord = ((*pSrcDWord & 0x00FEFEFE) >> 1) + ((*pDestDWord & 0x00FEFEFE) >> 1);	// fast 50:50 blend		
					// move on..
					pDestDWord++;
					pSrcDWord++;
				}
				// now calculate start of next row
				pDest += (destDesc.lPitch / 4);
				pSrc += (srcDesc.lPitch / 4);
			}
			pSrcSurf->Unlock(NULL);
		}
		pDestSurf->Unlock(NULL);
	}
}
//****************************************************************************
///
/// Adds a drop shadow (32-bit)
///
/// @param[in] hDC		- DC to take background from and to update
/// @param[in] boxrect	- pointer to rectangle to add drop shadow to
/// @param[in] cliprect	- pointer to clipping rect in which to work
///
/// @return none
/// 
//****************************************************************************
BYTE cols[] = { 10, 17, 25, 46, 71, 102 };
BYTE revcols[] = { 102, 71, 46, 25, 17, 10 };
BYTE EndSquare[6][9] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 6, 7, 10, 11, 13, 14, 3, 4, 6, 8, 11, 14, 17, 19, 22, 4, 6,
		8, 14, 20, 27, 33, 36, 41, 5, 7, 11, 20, 32, 43, 51, 59, 65, 6, 10, 14, 27, 43, 59, 68, 79, 87 };
void DropShadow(HDC hDC, QRect *boxrect, QRect *cliprect) {
	QRect botrect, siderect;
	botrect.setleft(boxrect)->left - 2;
	botrect.setTop(boxrect)->bottom;
	botrect.setright(boxrect)->right;
	botrect.setBottom(botrect).top + 6;
	siderect.setleft(boxrect)->right;
	siderect.setTop(boxrect)->top - 1;
	siderect.setright(siderect).left + 6;
	siderect.setBottom(boxrect)->bottom + 6;
	UCHAR *pbits;
	BITMAPINFO *binfo = (BITMAPINFO*) ::GlobalAlloc(GMEM_FIXED, sizeof(BITMAPINFO) + sizeof(RGBQUAD) * 255);
	if (!binfo)
		return; // no mem. don't do it!
	ZeroMemory(binfo, sizeof(BITMAPINFO));
	HDC hDClocal = CreateCompatibleDC(NULL);
	QRect rectemp;
	if (IntersectRect(&rectemp, &botrect, cliprect)) {
		// in the clipping region, so draw it.
//		qDebug("bottom\n");
		int xwidth = BYTESPERLINE(_Width(botrect), 24);
		binfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		binfo->bmiHeader.biWidth = _Width(botrect);
		binfo->bmiHeader.biHeight = _Height(botrect);
		binfo->bmiHeader.biPlanes = 1;
		binfo->bmiHeader.biBitCount = 24;
		binfo->bmiHeader.biCompression = BI_RGB;
		QImage hbmp = CreateDIBSection(hDC, // handle to DC
				binfo, // bitmap data
				DIB_RGB_COLORS, // data type indicator
				(void**) &pbits, // will be set tp point to bit values
				NULL, // handle to file mapping object
				0); // offset to bitmap bit values
		QImage holdbmp = (QImage) SelectObject(hDClocal, hbmp);
		BitBlt(hDClocal, 0, 0, _Width(botrect), _Height(botrect), hDC, botrect.left, botrect.top, SRCCOPY);
		// now do the rows...
		// don't forget the dib is upsidedown....
		int loopx = (_Width(botrect) - 3) * 3;
		int x, y;
		for (y = 0; y < 6; y++) {
			int offset = y * xwidth;
			BYTE col;
			for (x = 0; x < loopx; x++) {
				if (x < 27)
					col = EndSquare[y][x / 3];
				else
					col = cols[y];
				short val = pbits[x + offset];
				val -= col;
				if (val < 0)
					pbits[x + offset] = 0;
				else
					pbits[x + offset] = (BYTE) val;
			}
			// do the last 3 pixels section.
			for (x = 0; x < 9; x++) {
				col = EndSquare[y][8 - (x / 3)];
				short val = pbits[x + loopx + offset];
				val -= col;
				if (val < 0)
					pbits[x + loopx + offset] = 0;
				else
					pbits[x + loopx + offset] = (BYTE) val;
			}
		}
		// now put into place
		BitBlt(hDC, botrect.left, botrect.top, _Width(botrect), _Height(botrect), hDClocal, 0, 0, SRCCOPY);
		SelectObject(hDClocal, holdbmp);
		DeleteObject(hbmp);
	}
	if (IntersectRect(&rectemp, &siderect, cliprect)) {
		// in the cliprect, so draw side
//		qDebug("side\n");
		int xwidth = BYTESPERLINE(_Width(siderect), 24);
		binfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		binfo->bmiHeader.biWidth = _Width(siderect);
		binfo->bmiHeader.biHeight = _Height(siderect);
		binfo->bmiHeader.biPlanes = 1;
		binfo->bmiHeader.biBitCount = 24;
		binfo->bmiHeader.biCompression = BI_RGB;
		QImage hbmp = CreateDIBSection(hDC, // handle to DC
				binfo, // bitmap data
				DIB_RGB_COLORS, // data type indicator
				(void**) &pbits, // will be set tp point to bit values
				NULL, // handle to file mapping object
				0); // offset to bitmap bit values
		QImage holdbmp = (QImage) SelectObject(hDClocal, hbmp);
		BitBlt(hDClocal, 0, 0, _Width(siderect), _Height(siderect), hDC, siderect.left, siderect.top, SRCCOPY);
		// don't forget the dib is upsidedown....
		int x, y;
		for (x = 0; x < 18; x++) {
			BYTE col;
			for (y = 0; y < _Height(siderect) - 9; y++) {
				if (y < 9)
					col = EndSquare[5 - (x / 3)][y];	//reversed x			
				else
					col = revcols[x / 3]; // reversed x	 
				short val = pbits[x + y * xwidth];
				val -= col;
				if (val < 0)
					pbits[x + y * xwidth] = 0;
				else
					pbits[x + y * xwidth] = (BYTE) val;
			}
			int start = y;
			for (y = 0; y < 9; y++) {
				col = EndSquare[5 - (x / 3)][8 - y];	//reversed x and y			
				short val = pbits[x + (y + start) * xwidth];
				val -= col;
				if (val < 0)
					pbits[x + (y + start) * xwidth] = 0;
				else
					pbits[x + (y + start) * xwidth] = (BYTE) val;
			}
		}
		// now put into place
		BitBlt(hDC, siderect.left, siderect.top, _Width(siderect), _Height(siderect), hDClocal, 0, 0, SRCCOPY);
		SelectObject(hDClocal, holdbmp);
		DeleteObject(hbmp);
	}
	DeleteDC(hDClocal);
	::GlobalFree(binfo);
}
#ifndef UNDER_CE // not used so remove code form target build
/****************************************************************************
 Description - Load a DIB from a file
 Parameters - filename
 Returns - pointer to DIB memory block
 ****************************************************************************/
BITMAPINFOHEADER* LoadDIBFromFile(QString filename)
{
  CStorage file;
  BITMAPFILEHEADER bmfHeader;


  if(file.Open(filename,CStorage::ReadOnly | CStorage::shareDenyWrite )==0)
    return NULL;


  DWORD dwBitsSize = (DWORD)file.size();

  // valid??
  if (file.Read((LPSTR)&bmfHeader, sizeof(bmfHeader)) != sizeof(bmfHeader))
  {
    file.close();
    return NULL;
  }


  if (bmfHeader.bfType != DIB_HEADER_MARKER)
  {
    file.close();
    return NULL;
  }

  dwBitsSize -= sizeof(BITMAPFILEHEADER); // set correct size
  // Allocate memory
  // Use GlobalAlloc since it aligns on 8 byte boundary

  UCHAR* pDIB =  (UCHAR*)::GlobalAlloc(GMEM_FIXED , dwBitsSize);

  if(pDIB==NULL)
  {
    file.close();
    return NULL;
  }

  // read the bits.

  if (file.Read(pDIB, dwBitsSize) != dwBitsSize)
  {
    file.close();
    ::GlobalFree(pDIB);
    return NULL;
  }

  file.close();



  if (!IS_WIN30_DIB(pDIB))
  {
    ::GlobalFree(pDIB);
    return NULL;
  }

  // otherwise we now have our pDIB

  return (BITMAPINFOHEADER*)pDIB;
}





/****************************************************************************
 Description - Load a DIB from a file to a DirectDraw surface
 Parameters - surface, filename, size and location on surface
 Returns - error code
****************************************************************************/
HRESULT LoadBitmapToSurf(IDirectDrawSurface4 * pdds, QString filename, RECT rect)
{

  BITMAPINFOHEADER *binfo=LoadDIBFromFile(filename);
  HRESULT hr;

  if(binfo==NULL)
    return E_FAIL;


  // now we have two cases to cover
  // we have a bitmap with a colour table, i.e. 2,4,8 bits per pixel
  // or we have a bitmap with more than 256 colours, and no colour table.


  int bitsoffset=0;

  int numColoursInTable=binfo->biClrUsed;
  if(numColoursInTable==0)
  {
    if(binfo->biBitCount <= 8)
    numColoursInTable= (1 << binfo->biBitCount);
  }


  if (binfo->biCompression == BI_BITFIELDS)
   /* Remember that 16/32bpp dibs can still have a color table */
   bitsoffset=(sizeof(DWORD) * 3) + (numColoursInTable * sizeof(RGBQUAD) + binfo->biSize);
  else
   bitsoffset=(numColoursInTable * sizeof(RGBQUAD) + binfo->biSize);



  HDC hdc;

  if ((hr = pdds->GetDC(&hdc)) == DD_OK)
  {

#ifdef UNDER_CE
    //::SetStretchBltMode(hdc, BILINEAR);	// default looks ok on CE no need to change mode
#else
    ::SetStretchBltMode(hdc, HALFTONE);
#endif

    if(!::StretchDIBits(hdc,
         rect.left, rect.top,
         _Width(rect),_Height(rect),
         0,							// SrcX
         0,							// SrcY
         binfo->biWidth,  // wSrcWidth
         binfo->biHeight, // wSrcHeight
         ((UCHAR*)binfo)+bitsoffset,  // lpBits
         (PBITMAPINFO)binfo,			// lpBitsInfo
         DIB_RGB_COLORS,				// wUsage
         SRCCOPY))					// dwROP
      hr=E_FAIL;




    ::SetBrushOrgEx(hdc,0,0,NULL); // because of HALFTONE

    pdds->ReleaseDC(hdc);
  }


  ::GlobalFree(binfo);

  return hr;
}



/****************************************************************************
 Description - load DIB from file, convert to 16bpp and save to a file
 Parameters - none
 Returns - T/F
****************************************************************************/
BOOL ImportBitmap()
{

  // now prompt the user to select the bitmap....
  wchar_t szFilter[] = L"Bitmap Files (*.bmp)|*.bmp|Bitmap Files (*.dib)|*.dib||";

  QString str;
  {
    CFileDialog cfd(TRUE,L".bmp",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szFilter);
    cfd.m_ofn.lpstrTitle=L"Load Bitmap";

    if(cfd.exec()==IDOK)
    {
    str=cfd.GetPathName();
    }
    else
    return FALSE;

  }



  CStorage file;
  BITMAPFILEHEADER bmfHeader;


  if(file.Open(str,CStorage::ReadOnly | CStorage::shareDenyWrite )==0)
    return FALSE;


  DWORD dwBitsSize = (DWORD)file.size();

  // valid??
  if (file.Read((LPSTR)&bmfHeader, sizeof(bmfHeader)) != sizeof(bmfHeader))
  {
    file.close();
    return FALSE;
  }


  if (bmfHeader.bfType != DIB_HEADER_MARKER)
  {
    file.close();
    return FALSE;
  }

  dwBitsSize -= sizeof(BITMAPFILEHEADER); // set correct size
  // Allocate memory
  // Use GlobalAlloc since it aligns on 8 byte boundary

  UCHAR* pDIB =  (UCHAR*)::GlobalAlloc(GMEM_FIXED , dwBitsSize);

  if(pDIB==NULL)
  {
    file.close();
    return FALSE;
  }

  // read the bits.

  if (file.Read(pDIB, dwBitsSize) != dwBitsSize)
  {
    file.close();
    ::GlobalFree(pDIB);
    return FALSE;
  }

  file.close();



  if (!IS_WIN30_DIB(pDIB))
  {
    ::GlobalFree(pDIB);
    return FALSE;
  }

  // otherwise we now have our pDIB



  BITMAPINFO *binfo=(BITMAPINFO *)pDIB;

  if(binfo->bmiHeader.biCompression)
  {
    ::MessageBox(0,L"Cannot use Compressed bitmaps",L"Error",MB_OK|MB_ICONEXCLAMATION);
    ::GlobalFree(pDIB);
    return FALSE;
  }




  // now we have two cases to cover
  // we have a bitmap with a colour table, i.e. 2,4,8 bits per pixel
  // or we have a bitmap with more than 256 colours, and no colour table.


  int bitsoffset=0;

  int numColoursInTable=binfo->bmiHeader.biClrUsed;
  if(numColoursInTable==0)
  {
    if(binfo->bmiHeader.biBitCount <= 8)
    numColoursInTable= (1 << binfo->bmiHeader.biBitCount);
  }


  if (binfo->bmiHeader.biCompression == BI_BITFIELDS)
   /* Remember that 16/32bpp dibs can still have a color table */
   bitsoffset=(sizeof(DWORD) * 3) + (numColoursInTable * sizeof(RGBQUAD) + binfo->bmiHeader.biSize);
  else
   bitsoffset=(numColoursInTable * sizeof(RGBQUAD) + binfo->bmiHeader.biSize);


  HDC hSrcMemDC = CreateCompatibleDC(NULL);
  HDC hDstMemDC = CreateCompatibleDC(NULL);



  UCHAR *m_pdibbits=NULL;

  HBITMAP hSrcBmp=CreateDIBSection(hSrcMemDC, // handle to DC
            binfo,  // bitmap data
            DIB_RGB_COLORS,// data type indicator
            (void**)&m_pdibbits, // will be set tp point to bit values
            NULL,// handle to file mapping object
            0);  // offset to bitmap bit values

  SelectObject(hSrcMemDC, hSrcBmp);

  // copy our loaded DIB's bits into the DIBSection we have created.
  memcpy(m_pdibbits,((UCHAR*)binfo)+bitsoffset,dwBitsSize-bitsoffset);




  // we need to create a 16-bit colour version for the result

  UCHAR* pNewDib =  (UCHAR*)::GlobalAlloc(GMEM_FIXED , sizeof(BITMAPINFO2));

  DWORD newWidth=binfo->bmiHeader.biWidth;
  DWORD newHeight=binfo->bmiHeader.biHeight;

  //if(newWidth>800)
  //	newWidth=800;

  //if(newHeight>600)
  //	newHeight=600;
  //

  if(newWidth>ARISTOS_MULTI_SX_X)
    newWidth=ARISTOS_MULTI_SX_X;

  if(newHeight>ARISTOS_MULTI_SX_Y)
    newHeight=ARISTOS_MULTI_SX_Y;


  BITMAPINFO2 *ConvertedBinfo=(BITMAPINFO2*)pNewDib;

  ConvertedBinfo->bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
  ConvertedBinfo->bmiHeader.biWidth=newWidth;
  ConvertedBinfo->bmiHeader.biHeight=newHeight;
  ConvertedBinfo->bmiHeader.biPlanes=1;
  ConvertedBinfo->bmiHeader.biBitCount=16;   // want 16 bit
  ConvertedBinfo->bmiHeader.biCompression=BI_BITFIELDS;
  ConvertedBinfo->bmiHeader.biSizeImage=((newWidth + (newWidth & 1)) << 1) * newHeight;
  ConvertedBinfo->bmiHeader.biXPelsPerMeter=0;
  ConvertedBinfo->bmiHeader.biYPelsPerMeter=0;
  ConvertedBinfo->bmiHeader.biClrUsed=0;
  ConvertedBinfo->bmiHeader.biClrImportant=0;

  // followed by 3 DWORD masks, red, green then blue (5-6-5)
  ConvertedBinfo->redMask=0xF800;
  ConvertedBinfo->greenMask=0x07E0;
  ConvertedBinfo->blueMask=0x001F;




  UCHAR *m_pbits=NULL;

  HBITMAP hDstBmp=CreateDIBSection(hDstMemDC, // handle to DC
            (BITMAPINFO*)ConvertedBinfo,  // bitmap data
            DIB_RGB_COLORS,// data type indicator
            (void**)&m_pbits, // will be set tp point to bit values
            NULL,// handle to file mapping object
            0);  // offset to bitmap bit values

  SelectObject(hDstMemDC, hDstBmp);




  // now copy the bitmap from one to the other.

#ifdef UNDER_CE
//	::SetStretchBltMode(hDstMemDC, BILINEAR);
#else
  ::SetStretchBltMode(hDstMemDC, HALFTONE);
#endif


 /* Make GDI do the conversion between the different BPP formats */
  StretchBlt(hDstMemDC, 0, 0, newWidth, newHeight, hSrcMemDC, 0, 0, binfo->bmiHeader.biWidth, binfo->bmiHeader.biHeight, SRCCOPY);

#ifndef UNDER_CE
  GdiFlush();
  ::SetBrushOrgEx(hDstMemDC,0,0,NULL); // because of HALFTONE
#endif



  // ok now save our dibsection.

  HANDLE hf;       // file handle
  BITMAPFILEHEADER hdr;   // bitmap file-header
  PBITMAPINFOHEADER pbih;   // bitmap info-header
  //  LPBYTE lpBits;      // memory pointer
  DWORD dwTotal;      // total count of bytes
  DWORD cb;       // incremental count of bytes
  BYTE *hp;       // byte pointer
  DWORD dwTmp;

  pbih = (PBITMAPINFOHEADER) ConvertedBinfo;

  // Create the .BMP file.
  hf = CreateFile(L"C:\\outfile.bmp",
       GENERIC_READ | GENERIC_WRITE,
       (DWORD) 0,
        NULL,
       CREATE_ALWAYS,
       FILE_ATTRIBUTE_NORMAL,
       (HANDLE) NULL);
  if (hf == INVALID_HANDLE_VALUE)
    qDebug(L"Failed 1\n");

  hdr.bfType = 0x4d42;    // 0x42 = "B" 0x4d = "M"
  // Compute the size of the entire file.
  hdr.bfSize = (DWORD) (sizeof(BITMAPINFO2) + pbih->biSizeImage + sizeof(BITMAPFILEHEADER));// SIZEOF_BITMAPFILEHEADER_PACKED);
  hdr.bfReserved1 = 0;
  hdr.bfReserved2 = 0;

  // Compute the offset to the array of color indices.
  hdr.bfOffBits = (DWORD) (sizeof(BITMAPINFO2) + sizeof(BITMAPFILEHEADER)); // SIZEOF_BITMAPFILEHEADER_PACKED);

  // Copy the BITMAPFILEHEADER into the .BMP file.
  if (!WriteFile(hf, (LPVOID) &hdr, sizeof(BITMAPFILEHEADER),
    (LPDWORD) &dwTmp,  NULL))
  {
   qDebug(L"Failed 2\n");
  }

  // Copy the BITMAPINFOHEADER and MASKS into the file.
  if (!WriteFile(hf, (LPVOID) pbih, sizeof(BITMAPINFO2), (LPDWORD) &dwTmp, ( NULL)))
    qDebug(L"Failed 3\n");

  // Copy the array of color indices into the .BMP file.
  dwTotal = cb = pbih->biSizeImage;
  hp = m_pbits;
  if (!WriteFile(hf, (LPSTR) hp, (int) cb, (LPDWORD) &dwTmp,NULL))
     qDebug(L"Failed 4\n");

  // Close the .BMP file.
   if (!//No need to close the mutex in Qt)
     qDebug(L"Failed 5\n");


  DeleteDC(hSrcMemDC);
  DeleteDC(hDstMemDC);
  DeleteObject(hSrcBmp);
  DeleteObject(hDstBmp);

  // free the converted bitmap
  ::GlobalFree(pNewDib);
  // free the original bitmap
  ::GlobalFree(pDIB);


  return TRUE;
}
#endif





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CDib class implementation.
//




/******************************************************************************
 *                          *
 * HPALETTE CreatePaletteFromRGBQUAD(LPRGBQUAD rgbqPalette, WORD wEntries)  *
 *                          *
 * Parameter:                       *
 *                          *
 * LPRGBQUAD    - pointer to RGBQUADs             *
 * WORD     - the number of RGBQUADs we are pointing to     *
 *                          *
 * Return Value:                      *
 *                          *
 * HPALETTE   - returns a handle to a palette or NULL if it failes  *
 *                          *
 * Description:                     *
 *                          *
 * This function will build a valid HPALETTE when given an array of RGBQUADs  *
 *                          *
 *****************************************************************************/
HPALETTE CreatePaletteFromRGBQUAD(LPRGBQUAD rgbqPalette, WORD wEntries)
{
  HPALETTE hPal;
  LPLOGPALETTE lplgPal;
  int i;

  lplgPal = (LPLOGPALETTE)GlobalAlloc(GPTR, sizeof(LOGPALETTE) + sizeof(PALETTEENTRY) * wEntries);
  if (!lplgPal)
  return NULL;

  lplgPal->palVersion = 0x300;
  lplgPal->palNumEntries = wEntries;

  for (i=0; i<wEntries; i++) {
  lplgPal->palPalEntry[i].peRed = rgbqPalette[i].rgbRed;
  lplgPal->palPalEntry[i].peGreen = rgbqPalette[i].rgbGreen;
  lplgPal->palPalEntry[i].peBlue  = rgbqPalette[i].rgbBlue;
  lplgPal->palPalEntry[i].peFlags = 0;
  }

  hPal = CreatePalette(lplgPal);
  GlobalFree(lplgPal);

  return hPal;
}


//**********************************************************************
///
/// Constructor (default)
///
/// @param none
///
//**********************************************************************
CDib::CDib()
{
  Init(); // initialize everything to Null/empty
}

//**********************************************************************
///
/// Initialize members to Null/empty
///
/// @param none
///
/// @return	none
///
//**********************************************************************
void CDib::Init()
{
  memset(&m_bfh,0,sizeof(m_bfh));
  m_pBInfoH=NULL;
  m_bitsoffset=0;  // if this is zero we know the Dib is not yet valid.
}


//**********************************************************************
///
/// Constructor - supplied with a filename to load DIB from
///
/// @param[in]	pfilename - path and filename to use
///
//**********************************************************************
CDib::CDib(QString  pfilename)
{
  Init(); // initialize everything to Null/empty

  CStorage file;
  BITMAPFILEHEADER bmfHeader;


  if(file.Open(pfilename, CStorage::ReadOnly | CStorage::shareDenyWrite )==0)
    return;


  m_bfh.dibSizebytes = (int)file.size();

  if (file.Read((LPSTR)&bmfHeader, sizeof(bmfHeader)) != sizeof(bmfHeader))
  {
    file.close();
    return;
  }


  if (bmfHeader.bfType != DIB_HEADER_MARKER)
  {
    file.close();
    return;
  }

  m_bfh.dibSizebytes -= sizeof(BITMAPFILEHEADER); // set correct size of DIB

  // Allocate memory
  // Use GlobalAlloc since it aligns on 8 byte boundary
  BITMAPINFOHEADER* pDIB = (BITMAPINFOHEADER*)::GlobalAlloc(GMEM_FIXED , m_bfh.dibSizebytes);

  if(pDIB==NULL)
  {
    file.close();
    return;
  }

  // read the bits.

  if (file.Read(pDIB, m_bfh.dibSizebytes) != m_bfh.dibSizebytes)
  {
    file.close();
    ::GlobalFree(pDIB);
    return;
  }

  file.close();


  if (!IS_WIN30_DIB(pDIB))
  {
    ::GlobalFree(pDIB);
    return;
  }



  // check for compressed bitmaps (also jpegs) - reject for now
  if((pDIB->biCompression!=BI_RGB)&&(pDIB->biCompression!=BI_BITFIELDS))
  {
//		::MessageBox(0,L"Cannot use Compressed bitmaps",L"Error",MB_OK|MB_ICONEXCLAMATION);
    ::GlobalFree(pDIB);
    return;
  }

  // otherwise we now have our DIB loaded
  m_pBInfoH=pDIB;  // DIB is now valid (m_pBInfoH is set)


  // now calc the bitsoffset. (rather than a pointer to the bits. this is more useful)

  int numColoursInTable=m_pBInfoH->biClrUsed;
  if(numColoursInTable==0)
  {
    if(m_pBInfoH->biBitCount <= 8)
    numColoursInTable= (1 << m_pBInfoH->biBitCount);
  }


  if (m_pBInfoH->biCompression == BI_BITFIELDS)
   // Remember that 16/32bpp dibs can still have a color table
   m_bitsoffset=(sizeof(DWORD) * 3) + (numColoursInTable * sizeof(RGBQUAD) + m_pBInfoH->biSize);
  else
   m_bitsoffset=(numColoursInTable * sizeof(RGBQUAD) + m_pBInfoH->biSize);


  // set up name and uniqueID
  // extract the name from the path and filename.

  int len=(int)wcslen(pfilename);

  while(pfilename[len-1]!=L'\\')
    len--;

  CStringUtils::SafeWcsCpy(m_bfh.Name, &pfilename[len], BITMAP_VISIBLE_NAME_LENGTH);

  CTVtime uniq;
  uniq.TimeNow();
  m_bfh.UniqueID=uniq.GetMicroSecs(); // this time is as good as a unique ID.

}




//**********************************************************************
///
/// Constructor - for reading a DIB from the Bitmap collection file
///
/// @param[in]	pBCFile	-	pointer to file at correct position
/// @param[in]	bfhdr	-	pointer to header already read
///
//**********************************************************************
CDib::CDib(CStorage *pBCFile, BCF_FILE_HEADER *bfhdr)
{
  Init(); // initilize everything to Null/empty

  m_bfh=*bfhdr; // copy header info (name, id etc)

  // Allocate memory
  // Use GlobalAlloc since it aligns on 8 byte boundary
  m_pBInfoH = (BITMAPINFOHEADER*)::GlobalAlloc(GMEM_FIXED , m_bfh.dibSizebytes);

  if(m_pBInfoH==NULL)
    return;


  // read the bits.

  if (pBCFile->Read(m_pBInfoH, m_bfh.dibSizebytes) != m_bfh.dibSizebytes)
    return; // cannot read them

  // now calc the bitsoffset. (rather than a pointer to the bits. this is more useful)

  int numColoursInTable=m_pBInfoH->biClrUsed;
  if(numColoursInTable==0)
  {
    if(m_pBInfoH->biBitCount <= 8)
    numColoursInTable= (1 << m_pBInfoH->biBitCount);
  }


  if (m_pBInfoH->biCompression == BI_BITFIELDS)
   // Remember that 16/32bpp dibs can still have a color table
   m_bitsoffset=(sizeof(DWORD) * 3) + (numColoursInTable * sizeof(RGBQUAD) + m_pBInfoH->biSize);
  else
   m_bitsoffset=(numColoursInTable * sizeof(RGBQUAD) + m_pBInfoH->biSize);

}




//**********************************************************************
///
/// Constructor - for creating a DIB by copying an existing DIB and
///				  allowing changes in bit depth and/or size
///
/// @param[in] pSourceDIB -	pointer to source DIB
/// @param[in] bitDepth	  -	bit depth required
/// @param[in] width	  -	width required
/// @param[in] height	  -	height required
///
//**********************************************************************
CDib::CDib(CDib* pSourceDIB, UINT bitDepth, UINT width, UINT height)
{
  Init(); // initilize everything to Null/empty

  // copy the file header info
  m_bfh=pSourceDIB->m_bfh;

  BITMAPINFOHEADER tempBInfoH;

  memset(&tempBInfoH,0,sizeof(tempBInfoH));
  tempBInfoH.biSize=sizeof(BITMAPINFOHEADER);
  tempBInfoH.biWidth=width;
  tempBInfoH.biHeight=height;
  tempBInfoH.biPlanes=1;
  tempBInfoH.biBitCount=bitDepth;

  if(bitDepth==16)
    tempBInfoH.biCompression=BI_BITFIELDS;
  else
    tempBInfoH.biCompression=BI_RGB;

  tempBInfoH.biSizeImage=BYTESPERLINE(width,bitDepth)*height; // new size probably different, so update it with dimensions and bit depth

  if((tempBInfoH.biCompression==BI_RGB)&&(bitDepth<=8))
  {
    // copy these across from source image
    tempBInfoH.biClrUsed=pSourceDIB->m_pBInfoH->biClrUsed;
    tempBInfoH.biClrImportant=pSourceDIB->m_pBInfoH->biClrImportant;
  }



  int numColoursInTable=tempBInfoH.biClrUsed;
  if(numColoursInTable==0)
  {
    if(tempBInfoH.biBitCount <= 8)
    numColoursInTable= (1 << tempBInfoH.biBitCount);
  }


  if (tempBInfoH.biCompression == BI_BITFIELDS)
   // don't allow for a colour table here for newly created 16/32bpp
   m_bitsoffset=(sizeof(DWORD) * 3) + tempBInfoH.biSize;
  else
   m_bitsoffset=numColoursInTable * sizeof(RGBQUAD) + tempBInfoH.biSize;



  // now we have the bitsoffset, set the size of our dib in the fileheader
  m_bfh.dibSizebytes=m_bitsoffset+tempBInfoH.biSizeImage;

  // alloc the dib to full size.
  // Use GlobalAlloc since it aligns on 8 byte boundary
  m_pBInfoH = (BITMAPINFOHEADER*)::GlobalAlloc(GMEM_FIXED , m_bfh.dibSizebytes);

  if(m_pBInfoH==NULL)
    return;

  // copy temp info over
  memcpy(m_pBInfoH,&tempBInfoH,sizeof(BITMAPINFOHEADER));


  // set up masks or copy colour table if required.
  if(m_pBInfoH->biCompression == BI_BITFIELDS)
  {
    if(m_pBInfoH->biBitCount==16)
    {
    // add 565 masks
    // 3 DWORD masks, red, green then blue (5-6-5)
    ((BITMAPINFO2*)m_pBInfoH)->redMask=0xF800;
    ((BITMAPINFO2*)m_pBInfoH)->greenMask=0x07E0;
    ((BITMAPINFO2*)m_pBInfoH)->blueMask=0x001F;
    }
  }
  else if(numColoursInTable)
  {
    // copy colour table from sourceDIb
    memcpy(GetpColourTbl(),pSourceDIB->GetpColourTbl(),numColoursInTable * sizeof(RGBQUAD));
  }




  HDC hDC = CreateCompatibleDC(NULL);

  UCHAR *m_pbits=NULL;

  HBITMAP hDstBmp=CreateDIBSection(hDC, // handle to DC
            (BITMAPINFO*)m_pBInfoH,  // bitmap data
            DIB_RGB_COLORS,// data type indicator
            (void**)&m_pbits, // will be set tp point to bit values
            NULL,// handle to file mapping object
            0);  // offset to bitmap bit values

  SelectObject(hDC, hDstBmp);



 #ifdef UNDER_CE
    //::SetStretchBltMode(hdc, BILINEAR);	// default looks ok on CE no need to change mode
#else
  if(m_pBInfoH->biBitCount <= 8)
    ::SetStretchBltMode(hDC, COLORONCOLOR);
  else
    ::SetStretchBltMode(hDC, HALFTONE);


#endif
    ::StretchDIBits(hDC,
        0, 0, m_pBInfoH->biWidth,m_pBInfoH->biHeight,
        0, 0, pSourceDIB->m_pBInfoH->biWidth,pSourceDIB->m_pBInfoH->biHeight,
        (UCHAR*)pSourceDIB->GetpBits(),			// lpBits
        (PBITMAPINFO)pSourceDIB->GetpBInfo(),	// lpBitsInfo
        DIB_RGB_COLORS,							// wUsage
        SRCCOPY);								// dwROP



#ifndef UNDER_CE
    ::SetBrushOrgEx(hDC,0,0,NULL); // because of HALFTONE
#endif


  // copy the bits from the DIBSection to our destination DIB
  memcpy(GetpBits(),m_pbits,m_pBInfoH->biSizeImage);

  DeleteDC(hDC);
  DeleteObject(hDstBmp);

}





//**********************************************************************
///
/// Constructor - for creating a DIB by copying an existing DIB and
///				  allowing changes in bit depth and/or size
///
/// @param[in] pSourceDIB -	pointer to source DIB
/// @param[in] bitDepth	  -	bit depth required
/// @param[in] width	  -	width required
/// @param[in] height	  -	height required
///
//**********************************************************************
/*
CDib::CDib(CDib* pSourceDIB, UINT bitDepth, UINT width, UINT height)
{
  Init(); // initilize everything to Null/empty

  // copy the file header info
  m_bfh=pSourceDIB->m_bfh;

  BITMAPINFOHEADER tempBInfoH;

  memset(&tempBInfoH,0,sizeof(tempBInfoH));
  tempBInfoH.biSize=sizeof(BITMAPINFOHEADER);
  tempBInfoH.biWidth=width;
  tempBInfoH.biHeight=height;
  tempBInfoH.biPlanes=1;
  tempBInfoH.biBitCount=bitDepth;

  if(bitDepth==16)
    tempBInfoH.biCompression=BI_BITFIELDS;
  else
    tempBInfoH.biCompression=BI_RGB;

  tempBInfoH.biSizeImage=BYTESPERLINE(width,bitDepth)*height; // new size probably different, so update it with dimensions and bit depth

  if((tempBInfoH.biCompression==BI_RGB)&&(bitDepth<=8))
  {
    // copy these across from source image
    tempBInfoH.biClrUsed=pSourceDIB->m_pBInfoH->biClrUsed;
    tempBInfoH.biClrImportant=pSourceDIB->m_pBInfoH->biClrImportant;
  }



  int numColoursInTable=tempBInfoH.biClrUsed;
  if(numColoursInTable==0)
  {
    if(tempBInfoH.biBitCount <= 8)
    numColoursInTable= (1 << tempBInfoH.biBitCount);
  }


  if (tempBInfoH.biCompression == BI_BITFIELDS)
   // don't allow for a colour table here for newly created 16/32bpp
   m_bitsoffset=(sizeof(DWORD) * 3) + tempBInfoH.biSize;
  else
   m_bitsoffset=numColoursInTable * sizeof(RGBQUAD) + tempBInfoH.biSize;



  // now we have the bitsoffset, set the size of our dib in the fileheader
  m_bfh.dibSizebytes=m_bitsoffset+tempBInfoH.biSizeImage;

  // alloc the dib to full size.
  // Use GlobalAlloc since it aligns on 8 byte boundary
  m_pBInfoH = (BITMAPINFOHEADER*)::GlobalAlloc(GMEM_FIXED , m_bfh.dibSizebytes);

  if(m_pBInfoH==NULL)
    return;

  // copy temp info over
  memcpy(m_pBInfoH,&tempBInfoH,sizeof(BITMAPINFOHEADER));


  // set up masks or copy colour table if required.
  if(m_pBInfoH->biCompression == BI_BITFIELDS)
  {
    if(m_pBInfoH->biBitCount==16)
    {
    // add 565 masks
    // 3 DWORD masks, red, green then blue (5-6-5)
    ((BITMAPINFO2*)m_pBInfoH)->redMask=0xF800;
    ((BITMAPINFO2*)m_pBInfoH)->greenMask=0x07E0;
    ((BITMAPINFO2*)m_pBInfoH)->blueMask=0x001F;
    }
  }
  else if(numColoursInTable)
  {
    // copy colour table from sourceDIb
    memcpy(GetpColourTbl(),pSourceDIB->GetpColourTbl(),numColoursInTable * sizeof(RGBQUAD));
  }


  // new dib now created.  now copy between the dibs

  HDC hSrcMemDC = CreateCompatibleDC(NULL);
  HDC hDstMemDC = CreateCompatibleDC(NULL);


  UCHAR *m_pdibbits=NULL;

  HBITMAP hSrcBmp=CreateDIBSection(hSrcMemDC, // handle to DC
            (BITMAPINFO*)pSourceDIB->m_pBInfoH,  // bitmap data
            DIB_RGB_COLORS,// data type indicator
            (void**)&m_pdibbits, // will be set tp point to bit values
            NULL,// handle to file mapping object
            0);  // offset to bitmap bit values

  SelectObject(hSrcMemDC, hSrcBmp);

  // copy our loaded DIB's bits into the DIBSection we have created.
  memcpy(m_pdibbits,pSourceDIB->GetpBits(),pSourceDIB->m_pBInfoH->biSizeImage);


  UCHAR *m_pbits=NULL;

  HBITMAP hDstBmp=CreateDIBSection(hDstMemDC, // handle to DC
            (BITMAPINFO*)m_pBInfoH,  // bitmap data
            DIB_RGB_COLORS,// data type indicator
            (void**)&m_pbits, // will be set tp point to bit values
            NULL,// handle to file mapping object
            0);  // offset to bitmap bit values

  SelectObject(hDstMemDC, hDstBmp);


#ifndef UNDER_CE
  ::SetStretchBltMode(hDstMemDC, HALFTONE);
#endif

  // Make GDI do the conversion between the different BPP formats
  StretchBlt(hDstMemDC, 0, 0, m_pBInfoH->biWidth,m_pBInfoH->biHeight,
     hSrcMemDC, 0, 0, pSourceDIB->m_pBInfoH->biWidth, pSourceDIB->m_pBInfoH->biHeight, SRCCOPY);

#ifndef UNDER_CE
  GdiFlush();
  ::SetBrushOrgEx(hDstMemDC,0,0,NULL); // because of HALFTONE
#endif

  // copy the bits from the DIBSection to our destination DIB
  memcpy(GetpBits(),m_pbits,m_pBInfoH->biSizeImage);


  DeleteDC(hSrcMemDC);
  DeleteDC(hDstMemDC);
  DeleteObject(hSrcBmp);
  DeleteObject(hDstBmp);
}
*/





//**********************************************************************
///
/// Destructor
///
//**********************************************************************
CDib::~CDib()
{
  if(m_pBInfoH)
  {
    ::GlobalFree(m_pBInfoH);
  }
}



//**********************************************************************
///
/// LoadToSurface - Load a CDib to the supplied suface in the requied
///					position and dimensions
///
/// @param[in] pdds	-	pointer to surface
/// @param[in] rect	-	size and position
///
///	@return T/F
///
//**********************************************************************
//E437415
BOOL CDib::LoadToSurface(IDirectDrawSurface * pdds, RECT rect)
{

  if(m_pBInfoH==NULL) // valid CDib?
    return FALSE;


  HDC hdc;
  if (pdds->GetDC(&hdc)== DD_OK)
  {

#ifdef UNDER_CE
    //::SetStretchBltMode(hdc, BILINEAR);	// default looks ok on CE no need to change mode
#else
    ::SetStretchBltMode(hdc, HALFTONE);
#endif

    ::StretchDIBits(hdc,
        rect.left, rect.top,
        _Width(rect),_Height(rect),
        0,									// SrcX
        0,									// SrcY
        m_pBInfoH->biWidth,					// wSrcWidth
        m_pBInfoH->biHeight,				// wSrcHeight
        ((UCHAR*)m_pBInfoH)+m_bitsoffset,	// lpBits
        (PBITMAPINFO)m_pBInfoH,				// lpBitsInfo
        DIB_RGB_COLORS,						// wUsage
        SRCCOPY);							// dwROP


#ifndef UNDER_CE
    ::SetBrushOrgEx(hdc,0,0,NULL); // because of HALFTONE
#endif

    pdds->ReleaseDC(hdc);
  }

  return TRUE;
}









/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CBitmapCollectionFile class implementation.
//


//**********************************************************************
///
/// Constructor
///
/// @param[in]	pfilename - path and filename to use
/// @param[in]	openMode  - reading or writing or both
///
//**********************************************************************
CBitmapCollectionFile::CBitmapCollectionFile(QString  pfilename, Mode openMode)
{
  m_IsValid=FALSE;

  if(openMode==ReadOnly)
  {
    // here we are looking to read an existing BCF
    m_IsValid=m_file.Open(pfilename, CStorage::ReadOnly | CStorage::shareDenyWrite );
  }
  else if(openMode==WriteOnly)
  {
    // here we are creating (or overwriting) a BCF
    m_IsValid=m_file.Open(pfilename,CStorage::WriteOnly|CStorage::modeCreate| CStorage::shareDenyWrite); // here will truncate if it exits.
  }
  else if(openMode==ReadOnlyWrite)
  {
    m_IsValid=m_file.Open(pfilename,CStorage::ReadOnlyWrite|CStorage::modeCreate|CStorage::Append| CStorage::shareDenyWrite); // here no truncate
  }
}



//**********************************************************************
///
/// Destructor
///
//**********************************************************************
CBitmapCollectionFile::~CBitmapCollectionFile()
{
  if(m_IsValid)
  {
    m_file.close();
    m_IsValid=FALSE;
  }
}




//**********************************************************************
///
/// Add Dib to collection file, making any conversions as necessary
/// based upon the T_DEV_TYPE that will use it.
///	NB this changes the format of the original CDib
///
/// @param[in,out] pDIB	 - address of pointer to CDib
/// @param[in] BCFtype	 - destination details
/// @param[in] reqWidth	 - (optional) desired width
/// @param[in] reqHeight - (optional) desired height
///
///	@return T/F
///
//**********************************************************************
BOOL CBitmapCollectionFile::AddDib(CDib** pDIB, T_DEV_TYPE BCFtype, int reqWidth, int reqHeight) // reqWidth=0, reqHeight=0
{

  if(!m_IsValid)
    return FALSE;

  if(!(*pDIB)->GetpBInfo())
    return FALSE;

  // here we need to check that the DIB is correct for type for the destination

  // for screen designer, the max size is 800x600, but all colour info is preserved (e.g. 24 bit)

  // for mini and Ez the max size is 320x240 with max 16 bit colour depth
  // for multi the max size is 800x600 with max 16 bit colour depth

  // Check and reduce size first. Then reduce colour depth afterwards if required.

  // start max for all
  int maxWidth	= ARISTOS_MULTI_SX_X;
  int maxHeight	= ARISTOS_MULTI_SX_Y;

  //E519766

  if(BCFtype != DEV_PC_SCREEN_DESIGNER && BCFtype != DEV_ARISTOS_MULTIPLUS && BCFtype != DEV_PC_MULTI && BCFtype != DEV_SCR_MINITREND )
  {
    // Need to verify this
    if ( BCFtype == DEV_ARISTOS_MINITREND)
    {
    maxWidth	= ARISTOS_MINI_QX_X;
    maxHeight	= ARISTOS_MINI_QX_Y;
    }
    else if( BCFtype == DEV_PC_MINI  )
    {
    maxWidth	= ARISTOS_PC_MINI_QX_X;
    maxHeight	= ARISTOS_PC_MINI_QX_Y;
    }
    //E374454-Modified as PAR 1-3A91NYS checks.
    else if(BCFtype==DEV_XS_EZTREND || BCFtype==DEV_ARISTOS_EZTREND)
    {
    maxWidth	= ARISTOS_MINI_EZ_X;
    maxHeight	= ARISTOS_MINI_EZ_Y;
    }
  }
  //E374454 -Fix for 1-3A91NYS -> Blur issue in XSeries Multitrend.
  if(BCFtype==DEV_XS_MULTIPLUS)
  {
  maxWidth=X_SERIES_MULTI_SX_X;
  maxHeight=X_SERIES_MULTI_SX_Y;

  }


  RECT bmpsize=(*pDIB)->GetDimensions(); // get current Dib dimensions
  int curWidth=bmpsize.right;
  int curHeight=bmpsize.bottom;


  // if required dimensions were passed as default (0) then set them to the existing size here.
  if(reqWidth==0)
    reqWidth=curWidth;

  if(reqHeight==0)
    reqHeight=curHeight;


  // Check Size conversion
  if((curWidth>maxWidth)||(curHeight>maxHeight)||(curWidth!=reqWidth)||(curHeight!=reqHeight))
  {
    // need to resize this DIB

    if(curWidth!=reqWidth)
    curWidth=reqWidth;

    if(curHeight!=reqHeight)
    curHeight=reqHeight;

    if(curWidth>maxWidth)
    curWidth=maxWidth;

    if(curHeight>maxHeight)
    curHeight=maxHeight;

    CDib *ptemp=new CDib(*pDIB,(*pDIB)->GetBitDepth(),curWidth,curHeight); // same colour depth, just resized.
    //CDib *ptemp=new CDib(*pDIB,16,curWidth,curHeight); // 16 bit and  resized.

    if(ptemp)
    {
    delete (*pDIB);
    *pDIB=ptemp;
    }
  }

  // Check colour depth conversion
  if(BCFtype!=DEV_PC_SCREEN_DESIGNER)
  {
    if((*pDIB)->GetBitDepth()>16)
    {
    // here need to reduce colour depth to 16 bit
    CDib *ptemp=new CDib(*pDIB,16,curWidth,curHeight); // new colour depth, same size.

    if(ptemp)
    {
      delete *pDIB;
      *pDIB=ptemp;
    }
    }
  }

  // now append to the collection
  if((*pDIB)&&(*pDIB)->GetpBInfo()) // valid
  {
    m_file.SeekToEnd(); // appending
    m_file.write((*pDIB)->GetBCFHeader(),sizeof(BCF_FILE_HEADER));
    m_file.write((*pDIB)->GetpBInfo(),(*pDIB)->GetFullSizeBytes());
  }

  return TRUE;
}



//**********************************************************************
///
///	Delete Dib from collection file
///
/// @param[in] UniqueID - unique of Dib to delete
///
/// @return	T/F
///
//**********************************************************************
BOOL CBitmapCollectionFile::DeleteDib(LONGLONG UniqueID)
{

  // do this by reading and writing a new bcf file without the dib to delete

  if(!m_IsValid)
    return FALSE;

  BOOL found=FALSE;

  CBitmapCollectionFile *tempbcf=new CBitmapCollectionFile(L"temp.bcf",CBitmapCollectionFile::WriteOnly);

  CDib *pDib=GetFirstDib();
  while(pDib)
  {
    if(pDib->GetBCFHeader()->UniqueID!=UniqueID) // check it's not the one we wish to delete (exclude)
    tempbcf->AddDib(&pDib,DEV_PC_SCREEN_DESIGNER); // say for screen designer use (no restriction)
    else
    found=TRUE;

    delete pDib; // delete the DIb

    pDib=GetNextDib();
  }

  // find the location of our file
  QString PathAndFileName=m_file.GetFilePath();

  // now close it
  m_file.close();
  m_IsValid=FALSE;

  delete tempbcf; // delete the temp file object.


  // now switch the temporary file into place.
  CStorage tempStorage;
  tempStorage.Remove(PathAndFileName);

  // rename current file
  tempStorage.Rename(L"temp.bcf", PathAndFileName );


  // now re-open our file
  m_IsValid=m_file.Open(PathAndFileName,CStorage::ReadOnlyWrite|CStorage::modeCreate|CStorage::Append| CStorage::shareDenyWrite); // here no truncate

  return found; // if it was actually deleted
}




//**********************************************************************
///
///	Load a CDib from the collection file, from it's ID
///
/// @param[in] matchID -	Unique ID of CDib to find in collection file
///
/// @return	pointer to CDib (or NULL if not found)
///
//**********************************************************************
CDib* CBitmapCollectionFile::LoadDib(LONGLONG matchID)
{

  if(!m_IsValid)
    return NULL;

  m_file.seek(0);

  // traverse the file, loading the headers and looking for the UniqueID

  BOOL found=FALSE;
  BCF_FILE_HEADER hdr;

  int ret=m_file.Read(&hdr,sizeof(hdr));

  while(ret==sizeof(hdr))
  {
    if(hdr.UniqueID==matchID)
    {
    // found the bitmap header
    found=TRUE;
    break;
    }
    m_file.Seek(hdr.dibSizebytes,CStorage::current);  // move on past this DIB
    ret=m_file.Read(&hdr,sizeof(hdr));
  }


  if(found)
  {
    // create our CDib object
    CDib *loadedDib=new CDib(&m_file,&hdr); // pass the file and the header we have read so far

    return loadedDib;
  }

  return NULL;
}



//**********************************************************************
///
///	Load first CDib from the collection file
///
/// @param[in] none
///
/// @return	pointer to CDib (or NULL if none found)
///
//**********************************************************************
CDib* CBitmapCollectionFile::GetFirstDib()
{

  if(!m_IsValid)
    return NULL;

  m_file.seek(0);

  // get the first from the file
  BCF_FILE_HEADER hdr;

  int ret=m_file.Read(&hdr,sizeof(hdr));

  if(ret==sizeof(hdr))
  {
    // found the bitmap header

    // create our CDib object
    CDib *loadedDib=new CDib(&m_file,&hdr); // pass the file and the header we have read so far

    return loadedDib;
  }

  return NULL;
}




//**********************************************************************
///
///	Load the next CDib from the collection file (after calling GetFirstDib)
///
/// @param[in] none
///
/// @return	pointer to CDib (or NULL if none found)
///
//**********************************************************************
CDib* CBitmapCollectionFile::GetNextDib()
{

  if(!m_IsValid)
    return NULL;

  // get the next from the file
  BCF_FILE_HEADER hdr;

  int ret=m_file.Read(&hdr,sizeof(hdr));

  if(ret==sizeof(hdr))
  {
    // found the bitmap header

    // create our CDib object
    CDib *loadedDib=new CDib(&m_file,&hdr); // pass the file and the header we have read so far

    return loadedDib;
  }

  return NULL;
}




//**********************************************************************
///
///	Load the n'th CDib from the collection file
///
/// @param[in] nth - the index of the DIB to get. (0 based)
///
/// @return	pointer to CDib (or NULL if not found)
///
//**********************************************************************
CDib* CBitmapCollectionFile::GetnthDib(int index)
{

  if(!m_IsValid)
    return NULL;

  m_file.seek(0);

  // traverse the file, loading the headers and til the nth one

  BOOL found=FALSE;
  BCF_FILE_HEADER hdr;
  int count=0;

  int ret=m_file.Read(&hdr,sizeof(hdr));

  while(ret==sizeof(hdr))
  {
    if(count==index)
    {
    // found the bitmap header
    found=TRUE;
    break;
    }
    m_file.Seek(hdr.dibSizebytes,CStorage::current);  // move on past this DIB
    ret=m_file.Read(&hdr,sizeof(hdr));
    count++;
  }


  if(found)
  {
    // create our CDib object
    CDib *loadedDib=new CDib(&m_file,&hdr); // pass the file and the header we have read so far

    return loadedDib;
  }

  return NULL;
}



//**********************************************************************
///
///	static member function for building filename of collection file
///
/// @param[in] PathAndFileName - pointer to buffer to fill
///
/// @return	none
///
//**********************************************************************
void CBitmapCollectionFile::BuildFilename(QString  PathAndFileName)
{

#ifdef DOCVIEW
  // for screen designer
  ::GetModuleFileName(AfxGetInstanceHandle(), PathAndFileName, MAX_PATH);

  int len=wcslen(PathAndFileName);
  while(PathAndFileName[len-1]!=L'\\')
    len--;

  swprintf(&PathAndFileName[len],L"SDLib.bcf"); // append the library name
#else

  // for recorder (in intcf config)
  pDALGLB->BuildPath( IDS_INTERNAL_SD, IDS_CONFIG_DATA, SYSCONFIG_DEFAULT_PERSISTED_BITMAPS_FILENAME, PathAndFileName, MAX_PATH );

#endif

}






//**********************************************************************
///
///	function for updating collection file with the contents of another
/// If the same Dib exists in both, the largest will be kept
///
/// @param[in] PathAndFileName - pointer to buffer to fill
/// @param[in] BCFtype	 - destination details
///
/// @return	none
///
//**********************************************************************
void CBitmapCollectionFile::UpdateCollection(CBitmapCollectionFile *pSource, T_DEV_TYPE BCFtype)
{

  // for each dib in the source file, look up the Dib in this file
  CDib *pSourceDib=pSource->GetFirstDib();
  while(pSourceDib)
  {
    CDib *pDib=LoadDib(pSourceDib->GetBCFHeader()->UniqueID); // try and load same dib from our collection

    if(pDib)
    {
    // found matching Dib. check the sizes

    RECT sourceSize=pSourceDib->GetDimensions();
    RECT curSize=pDib->GetDimensions();

    if( (_Height(sourceSize)>_Height(curSize)) && (_Width(sourceSize)>_Width(curSize)) )
    {
      // it is bigger, so delete it from current
      DeleteDib(pSourceDib->GetBCFHeader()->UniqueID);

      AddDib(&pSourceDib, BCFtype); // and add bigger version.
    }

    delete pDib;
    }
    else // not found, so add it to our collection.
    AddDib(&pSourceDib,BCFtype);

    delete pSourceDib;

    pSourceDib=pSource->GetNextDib();
  }

}




//**********************************************************************
///
///	function for updating collection file with a CDib
/// If the Dib exists in the collection, the largest will be kept
///
/// @param[in] PathAndFileName - pointer to buffer to fill
/// @param[in] BCFtype	 - destination details
/// @param[in] reqWidth	 - (optional) desired width
/// @param[in] reqHeight - (optional) desired height
///
/// @return	none
///
//**********************************************************************
void CBitmapCollectionFile::AddToCollection(CDib **ppSourceDib, T_DEV_TYPE BCFtype, int reqWidth, int reqHeight) // reqWidth=0, reqHeight=0
{

  // look up the Dib in this file
  CDib *pDib=LoadDib((*ppSourceDib)->GetBCFHeader()->UniqueID);

  if(pDib)
  {
    // found matching Dib. check the sizes

    RECT curSize=pDib->GetDimensions();

    // if current is equal or bigger than this, then ignore it.
    if( (reqHeight>_Height(curSize)) || (reqWidth>_Width(curSize)) )
    {
    // it is bigger, so delete it from current
    DeleteDib(pDib->GetBCFHeader()->UniqueID);

    AddDib(ppSourceDib, BCFtype, reqWidth, reqHeight); // and add bigger version.
    }

    delete pDib;
  }
  else // not found, so add it to our collection.
    AddDib(ppSourceDib,BCFtype, reqWidth, reqHeight);

}


















//**********************************************************************
///
/// Converts the CTVtime to 2 strings (specific for chart/cursor use)
///
/// @param[in]	ptime - pointer to CTVtime to convert
/// @param[in]	buff1 - pointer to buffer to fill with Date
/// @param[in]	buff2 - pointer to buffer to fill with Time
/// @param[in]	seeFracs - see fractions of a second
///
/// @return		None
///
//**********************************************************************
void TimeToString(CTVtime *ptime, QString buff1, QString buff2, BOOL seeFracs)//=FALSE
{

  // get internal time into a SYSTEMTIME
  SYSTEMTIME st;
  ptime->GetSYSTEMTIME(&st);


  //PSR Fix for 1-3DOGTGP - localization of Dateformat begin
  // put date into buff1

  USHORT usLanguage = LANG_ENGLISH;
  USHORT usSubLanguage = SUBLANG_DEFAULT;
  if(pGlbSysInfo)
  {
    //GetLanguage
    USHORT usLang = pGlbSysInfo->GetValidLanguage();
    switch (static_cast< T_LANGUAGES >(usLang))
    {
    case lngEnglish:
    usLanguage = LANG_ENGLISH;
    usSubLanguage = SUBLANG_ENGLISH_UK;
    break;
    case lngEngUS:
    usLanguage = LANG_ENGLISH;
    usSubLanguage = SUBLANG_ENGLISH_US;
    break;
    case lngFra:
    usLanguage = LANG_FRENCH;
    usSubLanguage = SUBLANG_FRENCH;
    break;
    case lngGer:
    usLanguage = LANG_GERMAN;
    usSubLanguage = SUBLANG_GERMAN;
    break;
    case lngIta:
    usLanguage = LANG_ITALIAN;
    usSubLanguage = SUBLANG_ITALIAN;
    break;
    case lngSpa:
    usLanguage = LANG_SPANISH;
    usSubLanguage = SUBLANG_SPANISH;
    break;
    case lngBraz:
    usLanguage = LANG_PORTUGUESE; ///Set Brazilian is mentioned as Protugese in MSDN
    usSubLanguage = SUBLANG_PORTUGUESE_BRAZILIAN;
    break;
    case lngPol:
    usLanguage = LANG_POLISH;
    break;
    case lngHung:
    usLanguage = LANG_HUNGARIAN;
    break;
    case lngSlo:
    usLanguage = LANG_SLOVAK;
    break;
    case lngCze:
    usLanguage = LANG_CZECH;
    break;
    case lngTurk:
    usLanguage = LANG_TURKISH;
    break;
    case lngRom:
    usLanguage = LANG_ROMANIAN;
    break;
    case lngRus:
    usLanguage = LANG_RUSSIAN;
    break;
    case lngPor:
    usLanguage = LANG_PORTUGUESE;
    break;
    case lngGrk:
    usLanguage = LANG_GREEK;
    break;
    case lngBulg:
    usLanguage = LANG_BULGARIAN;
    break;
    //#if LangChinese == 1
    case lngChin:
    usLanguage = LANG_CHINESE;
    usSubLanguage = SUBLANG_CHINESE_SIMPLIFIED;
    break;
    //#endif
    //#if LangJapanese == 1
    case lngJap:
    usLanguage = LANG_JAPANESE;
    break;
    //#endif
    //#if LangKorean == 1
    case lngKor:
    usLanguage = LANG_KOREAN;
    break;
    //#endif kiran
    case 0xFFFF:
    default:
    //display nothing
    break;
    }
  }

  //Check -if the LOCALE Identifier is installed and is valid on the OS side
  if(IsValidLocale(MAKELCID(MAKELANGID(usLanguage,usSubLanguage),SORT_DEFAULT),LCID_INSTALLED))
  {
    //we got LCID so can be used to get localized string
    if(GetDateasprintf(MAKELCID(MAKELANGID(usLanguage,usSubLanguage),SORT_DEFAULT),
      0,
      &st,
      L"dd MMM yy",  // date part 05
      buff1,
      15)==0)
    {
    *buff1=0; // null terminate if fails
    }
  }
  else
  {
    //This is if no locale present in the PC then use default selected system font in controlpanle -regional settings
    //This works with regional settings option.
    //The difference b/w Xs and GR is GR does not set the localization languae in OS and it does only at application level
    //where as XS sets both places OS level and Application level
    if(GetDateasprintf(LOCALE_USER_DEFAULT,  0,
      &st,
      L"dd MMM yy",  // date part 05
      buff1,
      15)==0)
    {
    *buff1=0; // null terminate if fails
    }
  }
  //PSR Fix for 1-3DOGTGP - localization of Dateformat end


  // put time into buff2
  if(GetTimeasprintf(LOCALE_USER_DEFAULT,
      0,
      &st,
      L"HH':'mm':'ss",
      buff2,
      9)==0)
  {
    *buff2=0; // null terminate if fails
  }
  else
  if(seeFracs) // optional additon of 100ths sec
    swprintf(&buff2[8],L".%02d",st.wMilliseconds/10);

}


//**********************************************************************
///
/// Converts the CTVtime SPAN to a string in the form hh Hr(s) mm Min(s)
///
/// @param[in]	ptime - pointer to CTVtime to convert
/// @param[in]	buff  - pointer to buffer to fill with time
///
/// @return		None
///
//**********************************************************************
void TimeSpanToStringHM(CTVtime *ptime, QString buff)
{

  // get internal time into a SYSTEMTIME
  SYSTEMTIME st;
  ptime->GetSYSTEMTIME(&st);

  int totHours=st.wHour+(st.wDay-1)*24; // day-1 since 1st Jan 1970 is day 1 not day 0.
  swprintf(buff,L"%dHrs",totHours);


  int len = (int)wcslen(buff);

  if(totHours==1)	// remove 's' from hrs
    len--;

  if(st.wMinute==1)
    swprintf(&buff[len],L" %dMin",st.wMinute); // no 's' on mins
  else
    swprintf(&buff[len],L" %dMins",st.wMinute);

}





//**********************************************************************
///
/// Converts the CTVtime SPAN to a string in the form hh Hr(s) mm Min(s)
///
/// @param[in]	time100 - pointer to time100 to convert
/// @param[in]	buff  - pointer to buffer to fill with time (30 chars ok)
/// @param[in]	seeFracs - see fractions of a second
///
/// @return		None
///
//**********************************************************************
void Span100ToHMSF(LONGLONG time100, QString buff, BOOL seeSecs, BOOL seeFracs)//=FALSE
{

  int hours=int(time100/360000);
  time100-=hours*360000; // take off hours

  int mins=int(time100/6000);
  time100-=mins*6000;		 // take of mins

  int secs=int(time100/100);
  time100-=secs*100;		 // take off secs

  int fracs=(int)time100/10;


  // max hours will be less than 267 (max tpp 120000 * 800)


  WCHAR secsbuff[10];

  if(seeFracs || ((hours==0)&&(mins==0)&&(secs==0)))
    swprintf(secsbuff,L"%d.%d Secs",secs,fracs);
  else
  {
    if(seeSecs || ((hours==0)&&(mins==0)))
    {
    if(secs==1)
      swprintf(secsbuff,L"%d Sec",secs);
    else
      swprintf(secsbuff,L"%d Secs",secs);
    }
    else
    secsbuff[0]=0; // empty
  }


  WCHAR minsbuff[10];

  if((hours==0)&&(mins==0))
    minsbuff[0]=0; // empty
  else
  {
    if(mins==1)
    swprintf(minsbuff,L"%d Min ",mins);
    else
    swprintf(minsbuff,L"%d Mins ",mins);
  }


  if(hours==0)
    swprintf(buff,L"%c%s%s%c",0xE032,minsbuff,secsbuff,0xE033);
  else
  if(hours==1)
    swprintf(buff,L"%c%d Hr %s%s%c",0xE032,hours,minsbuff,secsbuff,0xE033);
  else
    swprintf(buff,L"%c%d Hrs %s%s%c",0xE032,hours,minsbuff,secsbuff,0xE033);

}





//****************************************************************************
///
/// @brief V5 colour palette
///
/// This colour table is taken from V5 and is used for Pen colours etc.
///
//****************************************************************************

BYTE Glb_GfxDACTableWin[]=
{
  // R, G, B
  0,0,0,			// Colour  0
  255,255,255,  // Colour  1
  100,65,40,		// Colour  2
  140,80,30,		// Colour  3
  180,98,20,		// Colour  4
  200,105,15,		// Colour  5
  255,128,0,		// Colour  6
  66,25,5,		// Colour  7
  136,107,93,		// Colour  8
  150,88,68,		// Colour  9
  166,75,47,		// Colour  10
  182,97,70,		// Colour  11
  198,120,94,		// Colour  12
  214,142,118,  // Colour  13
  230,165,143,  // Colour  14
  246,187,166,  // Colour  15
  255,200,180,  // Colour  16
  255,214,155,  // Colour  17
  234,199,161,  // Colour  18
  8,8,8,			// Colour  19
  16,16,16,		// Colour  20
  24,24,24,		// Colour  21
  32,32,32,		// Colour  22
  40,40,40,		// Colour  23
  48,48,48,		// Colour  24
  56,56,56,		// Colour  25
  64,64,64,		// Colour  26
  72,72,72,		// Colour  27
  80,80,80,		// Colour  28
  88,88,88,		// Colour  29
  96,96,96,		// Colour  30
  104,104,104,  // Colour  31
  112,112,112,  // Colour  32
  120,120,120,  // Colour  33
  128,128,128,  // Colour  34
  136,136,136,  // Colour  35
  144,144,144,  // Colour  36
  152,152,152,  // Colour  37
  160,160,160,  // Colour  38
  168,168,168,  // Colour  39
  176,176,176,  // Colour  40
  184,184,184,  // Colour  41
  192,192,192,  // Colour  42
  200,200,200,  // Colour  43
  208,208,208,  // Colour  44
  216,216,216,  // Colour  45
  224,224,224,  // Colour  46
  232,232,232,  // Colour  47
  240,240,240,  // Colour  48
  248,248,248,  // Colour  49
  226,168,125,  // Colour  50
  216,149,107,	// Colour  51
  32,0,0,			// Colour  52
  48,0,0,			// Colour  53
  64,0,0,			// Colour  54
  80,0,0,			// Colour  55
  96,0,0,			// Colour  56
  112,0,0,		// Colour  57
  128,0,0,		// Colour  58
  144,0,0,		// Colour  59
  160,0,0,		// Colour  60
  176,0,0,		// Colour  61
  192,0,0,		// Colour  62
  208,0,0,		// Colour  63
  224,0,0,		// Colour  64
  240,0,0,		// Colour  65
  255,0,0,		// Colour  66
  255,16,16,		// Colour  67
  255,32,32,		// Colour  68
  255,48,48,		// Colour  69
  255,64,64,		// Colour  70
  255,80,80,		// Colour  71
  255,96,96,		// Colour  72
  255,112,112,  // Colour  73
  255,128,128,  // Colour  74
  255,144,144,  // Colour  75
  255,160,160,  // Colour  76
  255,176,176,  // Colour  77
  255,192,192,  // Colour  78
  255,208,208,  // Colour  79
  255,224,224,  // Colour  80
  255,240,240,  // Colour  81
  238,223,206,  // Colour  82
  175,101,64,		// Colour  83
  0,0,32,			// Colour  84
  0,0,48,			// Colour  85
  0,0,64,			// Colour  86
  0,0,80,			// Colour  87
  0,0,96,			// Colour  88
  0,0,112,		// Colour  89
  0,0,128,		// Colour  90
  0,0,144,		// Colour  91
  0,0,160,		// Colour  92
  0,0,176,		// Colour  93
  0,0,192,		// Colour  94
  0,0,208,		// Colour  95
  0,0,224,		// Colour  96
  0,0,240,		// Colour  97
  0,0,255,		// Colour  98
  16,16,255,		// Colour  99
  32,32,255,		// Colour  100
  48,48,255,		// Colour  101
  64,64,255,		// Colour  102
  80,80,255,		// Colour  103
  96,96,255,		// Colour  104
  112,112,255,  // Colour  105
  128,128,255,  // Colour  106
  144,144,255,  // Colour  107
  160,160,255,  // Colour  108
  176,176,255,  // Colour  109
  192,192,255,  // Colour  110
  208,208,255,  // Colour  111
  224,224,255,  // Colour  112
  240,240,255,  // Colour  113
  204,132,89,		// Colour  114
  152,83,53,		// Colour  115
  0,32,0,			// Colour  116
  0,48,0,			// Colour  117
  0,64,0,			// Colour  118
  0,80,0,			// Colour  119
  0,96,0,			// Colour  120
  0,112,0,		// Colour  121
  0,128,0,		// Colour  122
  0,144,0,		// Colour  123
  0,160,0,		// Colour  124
  0,176,0,		// Colour  125
  0,192,0,		// Colour  126
  0,208,0,		// Colour  127
  0,224,0,		// Colour  128
  0,240,0,		// Colour  129
  0,255,0,		// Colour  130
  16,255,16,		// Colour  131
  32,255,32,		// Colour  132
  48,255,48,		// Colour  133
  64,255,64,		// Colour  134
  80,255,80,		// Colour  135
  96,255,96,		// Colour  136
  112,255,112,  // Colour  137
  128,255,128,  // Colour  138
  144,255,144,  // Colour  139
  160,255,160,  // Colour  140
  176,255,176,  // Colour  141
  192,255,192,  // Colour  142
  208,255,208,  // Colour  143
  224,255,224,  // Colour  144
  240,255,240,  // Colour  145
  168,92,58,		// Colour  146
  87,30,18,		// Colour  147
  32,0,32,		// Colour  148
  48,0,48,		// Colour  149
  64,0,64,		// Colour  150
  80,0,80,		// Colour  151
  96,0,96,		// Colour  152
  112,0,112,		// Colour  153
  128,0,128,		// Colour  154
  144,0,144,		// Colour  155
  160,0,160,		// Colour  156
  176,0,176,		// Colour  157
  192,0,192,		// Colour  158
  208,0,208,		// Colour  159
  224,0,224,		// Colour  160
  240,0,240,		// Colour  161
  255,0,255,		// Colour  162
  255,16,255,		// Colour  163
  255,32,255,		// Colour  164
  255,48,255,		// Colour  165
  255,64,255,		// Colour  166
  255,80,255,		// Colour  167
  255,96,255,		// Colour  168
  255,112,255,  // Colour  169
  255,128,255,  // Colour  170
  255,144,255,  // Colour  171
  255,160,255,  // Colour  172
  255,176,255,  // Colour  173
  255,192,255,  // Colour  174
  255,208,255,  // Colour  175
  255,224,255,  // Colour  176
  255,240,255,  // Colour  177
  242,114,53,		// Colour  178
  140,74,41,		// Colour  179
  0,32,32,		// Colour  180
  0,48,48,		// Colour  181
  0,64,64,		// Colour  182
  0,80,80,		// Colour  183
  0,96,96,		// Colour  184
  0,112,112,		// Colour  185
  0,128,128,		// Colour  186
  0,144,144,		// Colour  187
  0,160,160,		// Colour  188
  0,176,176,		// Colour  189
  0,192,192,		// Colour  190
  0,208,208,		// Colour  191
  0,224,224,		// Colour  192
  0,240,240,		// Colour  193
  0,255,255,		// Colour  194
  16,255,255,		// Colour  195
  32,255,255,		// Colour  196
  48,255,255,		// Colour  197
  64,255,255,		// Colour  198
  80,255,255,		// Colour  199
  96,255,255,		// Colour  200
  112,255,255,  // Colour  201
  128,255,255,  // Colour  202
  144,255,255,  // Colour  203
  160,255,255,  // Colour  204
  176,255,255,  // Colour  205
  192,255,255,  // Colour  206
  208,255,255,  // Colour  207
  224,255,255,  // Colour  208
  240,255,255,  // Colour  209
  227,103,48,		// Colour  210
  183,86,37,		// Colour  211
  32,32,0,		// Colour  212
  48,48,0,		// Colour  213
  64,64,0,		// Colour  214
  80,80,0,		// Colour  215
  96,96,0,		// Colour  216
  112,112,0,		// Colour  217
  128,128,0,		// Colour  218
  144,144,0,		// Colour  219
  160,160,0,		// Colour  220
  176,176,0,		// Colour  221
  192,192,0,		// Colour  222
  208,208,0,		// Colour  223
  224,224,0,		// Colour  224
  240,240,0,		// Colour  225
  255,255,0,		// Colour  226
  255,255,16,		// Colour  227
  255,255,32,		// Colour  228
  255,255,48,		// Colour  229
  255,255,64,		// Colour  230
  255,255,80,		// Colour  231
  255,255,96,		// Colour  232
  255,255,112,  // Colour  233
  255,255,128,  // Colour  234
  255,255,144,  // Colour  235
  255,255,160,  // Colour  236
  255,255,176,  // Colour  237
  255,255,192,  // Colour  238
  255,255,208,  // Colour  239
  255,255,224,  // Colour  240
  255,255,240,  // Colour  241
  248,165,85,		// Colour  242
  200,90,39,		// Colour  243
  255,255,255,  // Colour  244
  255,255,255,  // Colour  245
  255,255,255,  // Colour  246
  255,255,255,  // Colour  247
  255,255,255,  // Colour  248
  255,255,255,  // Colour  249
  255,255,255,  // Colour  250
  255,255,255,  // Colour  251
  255,255,255,  // Colour  252
  255,255,255,  // Colour  253
  255,255,255,  // Colour  254
  255,255,255		// Colour  255
};


//****************************************************************************
///
/// Returns a colour from the V5 palette when passed the colour number
///
/// @param[in] number - colour number required
///
/// @return Colour
///
//****************************************************************************
COLORREF GetColour(int number)
{
  int i=number*3;
  return RGB(Glb_GfxDACTableWin[i],Glb_GfxDACTableWin[i+1],Glb_GfxDACTableWin[i+2]);
}





/*
#ifdef MIPS
  #define MEMCPY MIPS_memcpy
#else
  #define MEMCPY memcpy
#endif
*/

/*
#ifdef UNDER_CE

// 2.5 times faster memcpy for more than 32 bytes.
static void MIPS_memcpy(void *dst, const void *src, int size)
{
  __asm(
    "addi   $8,$6,-32;"   //  Size-64
    "bltz   $8,bucle3;"   //  If it´s a small buffer, it´s not worth using cache ops.

    "andi   $9,$4,0xF;"
    "beq    $9,$0,bucle2;"

    "bucle1:"       //  Loop until Dst buffer is 16-byte aligned
    "lb   $8,0($5);"
    "sb   $8,0($4);"
    "addi $4,$4,1;"
    "addi $5,$5,1;"
    "addi $6,$6,-1;"
    "andi $8,$4,0xF;"
    "bne  $8,$0,bucle1;"

    "bucle2:"       //  Loop while nbytes to copy > 16
    "ulw  $8,0($5);"
    "ulw  $9,4($5);"
    "ulw  $10,8($5);"
    "ulw  $11,12($5);"
    ".set noreorder;"
    "cache  13,0($4);"    //  Create a new cache block
    ".set reorder;"
    "sw   $8,0($4);"
    "sw   $9,4($4);"
    "sw   $10,8($4);"
    "sw   $11,12($4);"
    "addi $4,$4,16;"
    "addi $5,$5,16;"
    "addi $6,$6,-16;"
    "addi $8,$6,-16;"
    "bgtz $8,bucle2;"

    "bucle3:"       //  Loop until all the bytes have been copied
    "lb   $8,0($5);"
    "sb   $8,0($4);"
    "addi $4,$4,1;"
    "addi $5,$5,1;"
    "addi $6,$6,-1;"
    "bgtz $6,bucle3;",dst,src,size);
}
#endif
*/



// Global font array
WCHAR GlbFontList[7][20]={L"Tahoma",
        L"Times New Roman",
        L"Courier New",
        L"Tahoma",
        L"",
        L"",
        L""};


// German and english. fits 7 digits. (all normal and <=7 not anti-aliased)
double offsetFactor=0.2499;
double heightFactor=1.25;


// semi-bold (<=7 pixel normal and not anti-aliased).  works ok, but only 6 digits
//double offsetFactor=0.2499;
//double heightFactor=1.25;


// actually came back with these for (0.8) semi-bold anti-aliased
//double offsetFactor=0.250;
//double heightFactor=1.296;



//****************************************************************************
///
/// Test function to calculate best font height factor and -ve offset to apply
///
//****************************************************************************
#ifdef _DEBUG
#include "UISizeDefines.h"
void CalcNumericFontConstants()
{

  HDC hdc=GetDC(HWND_DESKTOP);

  BOOL HasBrokenTop=FALSE;
  BOOL HasBrokenBottom=FALSE;
  BOOL Updated=FALSE;

  for(int boxH=7; boxH<140; boxH++)
  {

    int fontheight=(int)((heightFactor*boxH)+0.5);		 // 1.30 ish height
    int yoffset=(int)((fontheight*offsetFactor)+0.5); 	 // 0.25 ish offset adjustment (-y direction) to centralise it.


    // set params as required - bold/typeface etc.

    LOGFONT lf;
    lf.lfHeight=-fontheight;  // here less than 0 to indicate matching character height, not cell height
    lf.lfWidth=0;
    lf.lfEscapement=0;
    lf.lfOrientation=0;

    lf.lfWeight=FW_NORMAL;
  //	lf.lfWeight=FW_SEMIBOLD;

    lf.lfItalic=0;
    lf.lfUnderline=0;
    lf.lfStrikeOut=0;
    lf.lfCharSet=DEFAULT_CHARSET;			// based on Locale (for english and US, will be ANSI_CHARSET)
    lf.lfOutPrecision=OUT_DEFAULT_PRECIS;
    lf.lfClipPrecision=CLIP_DEFAULT_PRECIS;

    if(boxH<=7) // smaller fonts look same/better as default
    {
    lf.lfQuality=DEFAULT_QUALITY; // DEFAULT_QUALITY ANTIALIASED_QUALITY CLEARTYPE_QUALITY
    lf.lfWeight=FW_NORMAL;
    }
    else
    lf.lfQuality=ANTIALIASED_QUALITY; // for larger fonts. clean them up

    lf.lfPitchAndFamily=DEFAULT_PITCH |FF_DONTCARE;
    wcscpy(lf.lfFaceName,GlbFontList[0]); // Tahoma for digital objects since more compact

    HFONT fontHandle=CreateFontIndirect(&lf);
    if(fontHandle!=NULL)
    {

    // created ok.
    // select the font into our dc
    // for numeric output, we do this to get the details of the created font

    HFONT hOldfont=(HFONT)SelectObject (hdc, fontHandle);

    TEXTMETRIC physfont;
    GetTextMetrics(hdc, &physfont);


    // CHANGE THIS AS REQUIRED e.g. 0,8 for German.
    QString text=L"0.8";

    // for desktop or multiplus testing use this:
    Rectangle(hdc,0,0,ARISTOS_MULTI_SX_X,ARISTOS_MULTI_SX_Y);
    RECT testbox={5,10,ARISTOS_MULTI_SX_X-20,40};

/*
    // if you want to run this test on minitrend, use this.  However, results for desktop seem to be the same.
    RECT testbox={5,10,318,40};
    Rectangle(hdc,0,0,320,240);
*/

    testbox.setBottom(testbox).top+boxH;

    ExtTextOut(hdc, testbox.left, testbox.top-yoffset, ETO_OPAQUE,&testbox,text,(UINT)wcslen(text),NULL);
    SelectObject (hdc, hOldfont);

    DeleteObject(fontHandle);

    BOOL breakstop=FALSE;
    BOOL breaksbottom=FALSE;

    COLORREF testpixel=GetPixel(hdc,2,2);

    // now check around the border of the box, to see if we have overlapped.
    for (int x=testbox.left-1; x<=testbox.right; x++)
    {
      if( GetPixel(hdc,x,testbox.top-1)!=testpixel)
      {
        breakstop=TRUE;
        break;
      }

      if(GetPixel(hdc,x,testbox.bottom)!=testpixel)
      {
        breaksbottom=TRUE;
        break;
      }
    }

    if((breakstop && breaksbottom) ||(HasBrokenTop && breaksbottom)||(HasBrokenBottom && breakstop))
    {
      // height is too big.
      heightFactor-=0.001;
      boxH--;
      Updated=TRUE;
    }
    else
    if(breakstop)
    {
      offsetFactor-=0.0001;
      boxH--;
      HasBrokenTop=TRUE;
      Updated=TRUE;
    }
    else
    if(breaksbottom)
    {
      offsetFactor+=0.0001;
      boxH--;
      HasBrokenBottom=TRUE;
      Updated=TRUE;
    }
    else
    {
      qDebug(L"OK at %d,  hf=%f  of=%f \n",boxH,heightFactor,offsetFactor);

      if(boxH>7)
      {
        if(Updated)
        {
        boxH=6; // back to the start...
        HasBrokenTop=FALSE;
        HasBrokenBottom=FALSE;
        }

      }
      Updated=FALSE;
    }

    }

  }

  ReleaseDC(HWND_DESKTOP,hdc);

  qDebug(L" hf=%f  of=%f \n",heightFactor,offsetFactor);
}

#endif


// Font Cache class implementation.

CFontCache* CFontCache::m_pFontCacheInstance=NULL;
//****************************************************************************
/// CFontCache Constructor
///
/// @param none
///
//****************************************************************************
CFontCache::CFontCache()
{
  // inti the font cache slots
  for(int i=0; i<FONT_CACHE_SIZE; i++)
    InitFontEntry(i);

  // create our DeviceContext for font usage..
  m_fontHdc=CreateCompatibleDC(NULL); // compatible with our current screen.

//	CalcNumericFontConstants();
}

//****************************************************************************
/// CFontCache Destructor
///
/// @param none
///
//****************************************************************************
CFontCache::~CFontCache()
{
  for(int i=0; i<FONT_CACHE_SIZE; i++)
  {
    if(m_fontCache[i].fontHandle)
    {
    DeleteObject(m_fontCache[i].fontHandle);
    m_fontCache[i].fontHandle=NULL;
    }
  }
  DeleteDC(m_fontHdc);
}



//****************************************************************************
///
///	Clients call this function to get a pointer to the CFontCache Singleton
///	(there is only one CFontCache instance and all clients use it)
///
/// @param none
///
/// @return pointer to CFontCache instance
///
//****************************************************************************
CFontCache* CFontCache::GetHandle()
{
  if(!m_pFontCacheInstance)
    m_pFontCacheInstance=new CFontCache();

  return m_pFontCacheInstance;
}


//****************************************************************************
///
///	Tidy up and call destructor
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CFontCache::CleanUp()
{
  if(m_pFontCacheInstance)
    delete m_pFontCacheInstance;

  m_pFontCacheInstance = NULL;
}




//****************************************************************************
///
/// Private function to init required details in cache struct
///
/// @param[in] index	- Entry to initialise
///
/// @return none
///
//****************************************************************************
void CFontCache::InitFontEntry(int index)
{
  // only really need to init these.
  m_fontCache[index].fontHandle=0;
  m_fontCache[index].inUse=0;
  m_fontCache[index].usageCount=0;
  m_fontCache[index].isNumeric=FALSE;
}



//****************************************************************************
///
/// Decrements the usage counts for all cache entries.  Usage counts can go
/// negative.  When searching for an entry to replace, the lowest will be
/// selected.
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CFontCache::DecUsageCounts()
{

  for(int i=0; i<FONT_CACHE_SIZE; i++)
  {
    m_fontCache[i].usageCount--;
  }



}


//****************************************************************************
///
/// Called to release a font (after a call to GetNumericFont or GetFont)
///
/// @param[in] FontHandle	- Font handle to release
///
/// @return none
///
//****************************************************************************
void CFontCache::ReleaseFont(HFONT FontHandle)
{
  try
  {

  // search for and
  int inusefonts1=0;
  int inusefonts2=0;

  int i=0;
  for(i=0; i<FONT_CACHE_SIZE; i++)
  {
    //Aditya  - Sometimes when m_fontCache is null , it is crashing here. So introduced null check and kept try/catch
    ////1-12OLZIP
    if(m_fontCache[i].fontHandle != NULL && m_fontCache[i].inUse)
    inusefonts1+=m_fontCache[i].inUse;
  }


  for(i=0; i<FONT_CACHE_SIZE; i++)
  {
    //Aditya  - Sometimes when m_fontCache is null , it is crashing here. So introduced null check and kept try/catch
    ////1-12OLZIP
    if(m_fontCache[i].fontHandle != NULL && m_fontCache[i].fontHandle == FontHandle)
    {
    // yes it's a match.
    m_fontCache[i].inUse--;
    if(m_fontCache[i].inUse<0)
      DebugBreak();
    }
    //Aditya  - Sometimes when m_fontCache is null , it is crashing here. So introduced null check and kept try/catch
    //1-12OLZIP
    if(m_fontCache[i].fontHandle != NULL && m_fontCache[i].inUse)
    inusefonts2+=m_fontCache[i].inUse;

  }
  if(inusefonts2>=inusefonts1)
  {
    qDebug(L"==============FONTS ISSUE HERE\n");
  }

//	qDebug(L"FONTS in use  was:%d now:%d\n",inusefonts1,inusefonts2);

  }
  catch(...)
  {
  }
}


//****************************************************************************
///
/// Gets a 'numeric font' suitable for NUMERIC OUTPUT ONLY i.e. digitals
/// yOffset returned should be subtracted from the required 'Top' position
/// This font in NOT suitable for any other output since it has been sized
/// to the requiredHeight, with no space above or below for accents or decenders.
///
/// @param[in] RequiredHeight	- Height of required font
/// @param[in] pYoffset			- address of yOffset variable to fill
///
/// @return Handle to the font (or NULL)
///
//****************************************************************************
HFONT CFontCache::GetNumericFont(int RequiredHeight, int *pYoffset)
{

  // first check to see if this font already exists in the cache

  int firstEmpty=FONT_CACHE_SIZE;
  int lowestIndex=FONT_CACHE_SIZE;
  int lowestCount=0x7fffffff; // maxint


  // try and match with an existing font.

  for(int i=0; i<FONT_CACHE_SIZE; i++)
  {
    if(m_fontCache[i].fontHandle) // valid fonthandle? (non zero)
    {
    if(m_fontCache[i].isNumeric &&							// Numeric fonts ONLY
      (m_fontCache[i].requiredHeight==RequiredHeight))
    {
      // yes it's a match.
      m_fontCache[i].inUse++;
      m_fontCache[i].usageCount++;

      *pYoffset=m_fontCache[i].yOffset;
      return m_fontCache[i].fontHandle;
    }

    if(!m_fontCache[i].inUse && (m_fontCache[i].usageCount<lowestCount))
    {
      lowestCount=m_fontCache[i].usageCount;
      lowestIndex=i;
    }
    }
    else
    {
    if(i<firstEmpty)
      firstEmpty=i;
    }

  }

  // ok here we haven't got it.
  // do we have room?
  if(firstEmpty==FONT_CACHE_SIZE)
  {
    // all slots have been used - check usage counts to see which can go
    DecUsageCounts(); // decrement all useage counters

    if(lowestIndex==FONT_CACHE_SIZE)
    DebugBreak();

    DeleteObject(m_fontCache[lowestIndex].fontHandle);
    m_fontCache[lowestIndex].fontHandle=0;
    firstEmpty=lowestIndex;
  }

  // here we are ready to create the font and put in firstEmpty slot in cache



  // now uses constants calculated by CalcNumericFontConstants
  int fontheight=(int)((RequiredHeight*heightFactor)+0.5); // increase the size to fit the digits to the height req
  int yoffset=(int)((fontheight*offsetFactor)+0.5); 	 //  offset adjustment (-y direction) to centralise it.


  // ensure these params match those required - bold/typeface etc.

  LOGFONT lf;
  lf.lfHeight=-fontheight;  // here less than 0 to indicate matching character height, not cell height
  lf.lfWidth=0;
  lf.lfEscapement=0;
  lf.lfOrientation=0;

  lf.lfWeight=FW_NORMAL;
//	lf.lfWeight=FW_SEMIBOLD;

  lf.lfItalic=0;
  lf.lfUnderline=0;
  lf.lfStrikeOut=0;
  lf.lfCharSet=DEFAULT_CHARSET;			// based on Locale (for english and US, will be ANSI_CHARSET)
  lf.lfOutPrecision=OUT_DEFAULT_PRECIS;
  lf.lfClipPrecision=CLIP_DEFAULT_PRECIS;

  if(RequiredHeight<14) // smaller fonts look same/better as default
  {
    lf.lfQuality=DEFAULT_QUALITY; // DEFAULT_QUALITY ANTIALIASED_QUALITY CLEARTYPE_QUALITY
//		lf.lfWeight=FW_NORMAL;
  }
  else
    lf.lfQuality=ANTIALIASED_QUALITY; // for larger fonts. clean them up


  lf.lfPitchAndFamily=DEFAULT_PITCH |FF_DONTCARE;

#if _MSC_VER < 1400
  wcscpy(lf.lfFaceName, GlbFontList[0]); // Tahoma for digital objects since more compact
#else
  wcscpy_s(lf.lfFaceName, sizeof(lf.lfFaceName)/sizeof(WCHAR), GlbFontList[0]); // Tahoma for digital objects since more compact
#endif





  if((m_fontCache[firstEmpty].fontHandle=CreateFontIndirect(&lf))!=NULL)
  {
    // created ok. - save the params in the cache.

    m_fontCache[firstEmpty].requiredHeight=RequiredHeight;// save initial requested height
    m_fontCache[firstEmpty].isNumeric=TRUE;
    m_fontCache[firstEmpty].yOffset=(short)yoffset;
    m_fontCache[firstEmpty].inUse=1;
    m_fontCache[firstEmpty].usageCount=1;

    *pYoffset=m_fontCache[firstEmpty].yOffset; // return the yoffset
    return m_fontCache[firstEmpty].fontHandle;
  }


  // did not create font - return invalid font handle
  return NULL;

}
////Aditya: Created one more function to take float values //1-YVI2O0
HFONT CFontCache::GetNumericFont1(float RequiredHeight, int *pYoffset)
{

  // first check to see if this font already exists in the cache

  int firstEmpty=FONT_CACHE_SIZE;
  int lowestIndex=FONT_CACHE_SIZE;
  int lowestCount=0x7fffffff; // maxint


  // try and match with an existing font.

  for(int i=0; i<FONT_CACHE_SIZE; i++)
  {
    if(m_fontCache[i].fontHandle) // valid fonthandle? (non zero)
    {
    if(m_fontCache[i].isNumeric &&							// Numeric fonts ONLY
      (m_fontCache[i].requiredHeight==RequiredHeight))
    {
      // yes it's a match.
      m_fontCache[i].inUse++;
      m_fontCache[i].usageCount++;

      *pYoffset=m_fontCache[i].yOffset;
      return m_fontCache[i].fontHandle;
    }

    if(!m_fontCache[i].inUse && (m_fontCache[i].usageCount<lowestCount))
    {
      lowestCount=m_fontCache[i].usageCount;
      lowestIndex=i;
    }
    }
    else
    {
    if(i<firstEmpty)
      firstEmpty=i;
    }

  }

  // ok here we haven't got it.
  // do we have room?
  if(firstEmpty==FONT_CACHE_SIZE)
  {
    // all slots have been used - check usage counts to see which can go
    DecUsageCounts(); // decrement all useage counters

    if(lowestIndex==FONT_CACHE_SIZE)
    DebugBreak();

    DeleteObject(m_fontCache[lowestIndex].fontHandle);
    m_fontCache[lowestIndex].fontHandle=0;
    firstEmpty=lowestIndex;
  }

  // here we are ready to create the font and put in firstEmpty slot in cache



  // now uses constants calculated by CalcNumericFontConstants
  int fontheight=(int)((RequiredHeight*heightFactor)+0.5); // increase the size to fit the digits to the height req
  int yoffset=(int)((fontheight*offsetFactor)+0.5); 	 //  offset adjustment (-y direction) to centralise it.


  // ensure these params match those required - bold/typeface etc.

  LOGFONT lf;
  lf.lfHeight=-fontheight;  // here less than 0 to indicate matching character height, not cell height
  lf.lfWidth=0;
  lf.lfEscapement=0;
  lf.lfOrientation=0;

//	lf.lfWeight=FW_NORMAL;
//	lf.lfWeight=FW_SEMIBOLD;
  lf.lfWeight=FW_BOLD;  //Aditya. Makeing it bold to make clear and visible. //PAR:1-1NA990N

  lf.lfItalic=0;
  lf.lfUnderline=0;
  lf.lfStrikeOut=0;
  lf.lfCharSet=DEFAULT_CHARSET;			// based on Locale (for english and US, will be ANSI_CHARSET)
  lf.lfOutPrecision=OUT_DEFAULT_PRECIS;
  lf.lfClipPrecision=CLIP_DEFAULT_PRECIS;

  if(RequiredHeight<14) // smaller fonts look same/better as default
  {
    lf.lfQuality=DEFAULT_QUALITY; // DEFAULT_QUALITY ANTIALIASED_QUALITY CLEARTYPE_QUALITY
//		lf.lfWeight=FW_NORMAL;
  }
  else
    lf.lfQuality=ANTIALIASED_QUALITY; // for larger fonts. clean them up


  lf.lfPitchAndFamily=DEFAULT_PITCH |FF_DONTCARE;

#if _MSC_VER < 1400
  wcscpy(lf.lfFaceName, GlbFontList[0]); // Tahoma for digital objects since more compact
#else
  wcscpy_s(lf.lfFaceName, sizeof(lf.lfFaceName)/sizeof(WCHAR), GlbFontList[0]); // Tahoma for digital objects since more compact
#endif





  if((m_fontCache[firstEmpty].fontHandle=CreateFontIndirect(&lf))!=NULL)
  {
    // created ok. - save the params in the cache.

    m_fontCache[firstEmpty].requiredHeight=RequiredHeight;// save initial requested height
    m_fontCache[firstEmpty].isNumeric=TRUE;
    m_fontCache[firstEmpty].yOffset=(short)yoffset;
    m_fontCache[firstEmpty].inUse=1;
    m_fontCache[firstEmpty].usageCount=1;

    *pYoffset=m_fontCache[firstEmpty].yOffset; // return the yoffset
    return m_fontCache[firstEmpty].fontHandle;
  }


  // did not create font - return invalid font handle
  return NULL;

}









//****************************************************************************
///
/// Gets a font suitable for general output of text and digits.
/// (for numeric only output use GetNumericFont)
/// The optional paramters below are the general font defines used for LOGFONT
///
/// @param[in] RequiredHeightOr- Height (and orientation) of required font
/// @param[in] Weight			- (Optional) defaults to FW_NORMAL
/// @param[in] Face				- (Optional) defaults to 0 (Arial)
/// @param[in] Quality			- (Optional) defaults to DEFAULT_QUALITY
/// @param[in] anticlk			- (Optional) defaults to FALSE (clockwise)
///
/// @return Handle to the font (or NULL)
///
//****************************************************************************
HFONT CFontCache::GetFont(int RequiredHeightOr, int Weight, int Face, int Quality, BOOL anticlk) // Weight=FW_NORMAL, Face=0, Quality=DEFAULT_QUALITY, anticlk=FALSE
{
  // first check to see if this font already exists in the cache

  int firstEmpty=FONT_CACHE_SIZE;
  int lowestIndex=FONT_CACHE_SIZE;
  int lowestCount=0x7fffffff; // maxint


  // try and match with an existing font.

  for(int i=0; i<FONT_CACHE_SIZE; i++)
  {
    if(m_fontCache[i].fontHandle) // valid fonthandle? (non zero)
    {
    if((!m_fontCache[i].isNumeric) &&						// NOT Numeric fonts
     (m_fontCache[i].requiredHeight==RequiredHeightOr) &&
     (m_fontCache[i].weight==Weight) &&
     (m_fontCache[i].face==Face) &&
     (m_fontCache[i].quality==Quality)&&
     (m_fontCache[i].anticlk==anticlk))
    {
      // yes it's a match.
      m_fontCache[i].inUse++;
      m_fontCache[i].usageCount++;
      return m_fontCache[i].fontHandle;
    }

    if((m_fontCache[i].inUse==0) && (m_fontCache[i].usageCount<lowestCount))
    {
      lowestCount=m_fontCache[i].usageCount;
      lowestIndex=i;
    }
    }
    else
    {
    if(i<firstEmpty)
      firstEmpty=i;
    }

  }

  // ok here we haven't got it.
  // do we have room?
  if(firstEmpty==FONT_CACHE_SIZE)
  {
    // all slots have been used - check usage counts to see which can go
    DecUsageCounts(); // decrement all useage counters

    if(lowestIndex==FONT_CACHE_SIZE)
    DebugBreak();

    DeleteObject(m_fontCache[lowestIndex].fontHandle);
    m_fontCache[lowestIndex].fontHandle=0;
    firstEmpty=lowestIndex;
  }

  // here we are ready to create the font and put in firstEmpty slot in cache

  LOGFONT lf;
  lf.lfWidth=0;
  if(RequiredHeightOr<0) // we are using -ve height to indicate rotated 90 degrees.
  {
    if ( pDALGLB->IsRecorderEzTrend() )
    {
    lf.lfWidth=5;
    }
    else if ( pDALGLB->IsRecorderMini() )
    {
    lf.lfWidth=8;
    }
    else
    {
    lf.lfWidth=7;
    }
    lf.lfHeight=-RequiredHeightOr;
  }
  else
  {
    lf.lfHeight=RequiredHeightOr;  // Match cell height
  }



  if(RequiredHeightOr<0) // we are using -ve height to indicate rotated 90 degrees.
  {
    // then flag says which way (clockwise/anti-clockwise)
    if(anticlk)
    {
    lf.lfEscapement=900;  // reads upwards
    lf.lfOrientation=900;
    }
    else
    {
    lf.lfEscapement=2700;	// reads downwards
    lf.lfOrientation=2700;
    }
  }
  else
  {
    lf.lfEscapement=0;
    lf.lfOrientation=0;
  }


  lf.lfWeight=Weight; // FW_NORMAL FW_BOLD
  lf.lfItalic=0;
  lf.lfUnderline=0;
  lf.lfStrikeOut=0;
  lf.lfCharSet=DEFAULT_CHARSET; // based on Locale (for english and US, will be ANSI_CHARSET)
  lf.lfOutPrecision=OUT_DEFAULT_PRECIS;
  lf.lfClipPrecision=CLIP_DEFAULT_PRECIS;
  lf.lfQuality=Quality; // DEFAULT_QUALITY ANTIALIASED_QUALITY CLEARTYPE_QUALITY
  lf.lfPitchAndFamily=DEFAULT_PITCH|FF_DONTCARE; // FF_DONTCARE  FF_MODERN

#if _MSC_VER < 1400
  wcscpy(lf.lfFaceName, GlbFontList[Face]);
#else
  wcscpy_s(lf.lfFaceName, sizeof(lf.lfFaceName)/sizeof(WCHAR), GlbFontList[Face]);
#endif





  if((m_fontCache[firstEmpty].fontHandle=CreateFontIndirect(&lf))!=NULL)
  {
    // created ok - save the info in the cache
    m_fontCache[firstEmpty].requiredHeight=RequiredHeightOr;
    m_fontCache[firstEmpty].isNumeric=FALSE;
    m_fontCache[firstEmpty].weight=Weight;
    m_fontCache[firstEmpty].face=Face;
    m_fontCache[firstEmpty].quality=Quality;
    m_fontCache[firstEmpty].anticlk=anticlk;

    m_fontCache[firstEmpty].inUse=1;
    m_fontCache[firstEmpty].usageCount=1;

    return m_fontCache[firstEmpty].fontHandle;
  }


  // did not create font - return invalid font handle
  qDebug(L"INVALID FONT HERE\n");
  DebugBreak();
  return NULL;

}
//****************************************************************************
//  int ConvertFontWeight( const T_FONT_WEIGHT eFONT_WEIGHT ) const
///
/// Method that converts the CMM font weights to an actual weight
///
/// @param[in]		const T_FONT_WEIGHT eFONT_WEIGHT - The required font weight
///
/// @return		The actual font weight as required by windows
///
//****************************************************************************
int CFontCache::ConvertFontWeight( const T_FONT_WEIGHT eFONT_WEIGHT ) const
{
  int iFontWeight = FW_NORMAL;
  switch( eFONT_WEIGHT )
  {
    case fwNormal:
    iFontWeight = FW_NORMAL;
    break;
    case fwMedium:
    iFontWeight = FW_MEDIUM;
    break;
    case fwSemiBold:
    iFontWeight = FW_SEMIBOLD;
    break;
    case fwBold:
    iFontWeight = FW_BOLD;
    break;
  }
  return iFontWeight;
}
//****************************************************************************
//  int ConvertFontQuality( const T_FONT_QUALITY eFONT_QUALITY ) const
///
/// Method that converts the CMM font quality to an actual windows quality
///
/// @param[in]		const T_FONT_QUALITY eFONT_QUALITY - The required font quality
///
/// @return		The actual font quality as required by windows
///
//****************************************************************************
int CFontCache::ConvertFontQuality( const T_FONT_QUALITY eFONT_QUALITY ) const
{
  int iFontQuality = fqDefault;
  switch( eFONT_QUALITY )
  {
    case fqDefault:
    iFontQuality = DEFAULT_QUALITY;
    break;
    case fqAntialiased:
    iFontQuality = ANTIALIASED_QUALITY;
    break;
    case fqClearType:
    iFontQuality = 5;
    break;
  }
  return iFontQuality;
}



/////////////////////////////////////////////
// scale graduations class implementation


//****************************************************************************
/// CGrads Constructor
///
/// @param none
///
//****************************************************************************
CGrads::CGrads()
{
  m_IsZoomed=FALSE;
  m_Zero=0;
  m_Span=0;
  m_ZoomZero=0;
  m_ZoomSpan=0;
  m_majorCount=0;
  m_count=0;
}

//****************************************************************************
/// Called to set the 'zoom' paratmeters for the graduations
///
/// @param[in] isZoomed	-	Is the scale zoomed?
/// @param[in] zoomZero	-	bottom of zoom
/// @param[in] zoomSpan	-	top of zoom.
///
/// @return none
///
//****************************************************************************
void CGrads::SetZoomed(BOOL isZoomed, float zoomZero, float zoomSpan)
{
  m_IsZoomed=isZoomed;
  m_ZoomZero=zoomZero;
  m_ZoomSpan=zoomSpan;

  // inverse scale ?
  if(m_ZoomZero>m_ZoomSpan)
  {
    m_ZoomZero=zoomSpan;
    m_ZoomSpan=zoomZero;
  }

}



//****************************************************************************
/// Get the first major grad starting from the end of the scale that will be visible
/// Consider whether the scale is in zoom mode.
///
/// @param none
///
/// @return first major graduation
///
//****************************************************************************
float CGrads::GetFirstMajorGrad()
{

  // The major divisions for a log scale are on the decades (a single decade = 1).
  // The major divisions for a linear scale are based on the user-specified spacing in EU.

  if(m_pScaleInfo->LogScale)
    return (float)(int)((m_IsZoomed ? m_ZoomZero : m_Zero)+1); // get next decade

  // for linear scale
  if(m_IsZoomed)
  {
    // Determine how many minor graduations "n" we need from the
    // end of the scale until we pass the zoomed end of the scale.
    // Solve for "n" in equation: fLowerEnd+(GetMinorDivs()*n)>fZoomedLowerEnd

    int n=(int)ceil((m_ZoomZero-m_Zero)/m_pScaleInfo->MajorDivs);
    if(m_Zero+(m_pScaleInfo->MajorDivs*n)==m_ZoomZero)
    n++; // first major grad at zoomed lower end - we want to go past it
    return m_Zero+(m_pScaleInfo->MajorDivs*n);
  }
  else
    return m_Zero+m_pScaleInfo->MajorDivs;

}



//****************************************************************************
// Get the first minor grad that will be visible in the scale.
// Consider whether the scale is in zoom mode.
///
/// @param ///@ todo
///
/// @return first minor graduation
///
//****************************************************************************
float CGrads::GetFirstMinorGrad(int &nDecade, int &nDiv)
{

  if(m_pScaleInfo->LogScale)
  {
    // Get the first logarithm (log10(2) through log10(9)) that when added
    // to the decade (1, 2, 3, ...) of the lower end or the zoomed lower end
    // depending on the zoom mode is greater than that lower end. Return this
    // division (2 through 9) so that we can continue drawing minor grads from it.

    float fEnd=m_IsZoomed ? m_ZoomZero : m_Zero;

    nDecade=(int)fEnd;
    nDiv=2;

    float fGrad;
    while((fGrad=nDecade+(float)log10((double)nDiv))<=fEnd)
    ++nDiv;

    if(nDiv==10)
    {
    // We're into the next decade. Example is starting from lower
    // end of 95. log10(95)=1.9777. Decade is 1 and log(9)=.9542.

    ++nDecade;
    nDiv=1; // will be incremented to 2 by caller before it is used
    fGrad=(float)nDecade;
    }

    return fGrad;
  }


  // for linear scale
  if(m_IsZoomed)
  {
    // Determine how many minor graduations "n" we need from the
    // end of the scale until we pass the zoomed end of the scale.
    // Solve for "n" in equation: fLowerEnd+(GetMinorDivs()*n)>fZoomedLowerEnd

    int n=(int)ceil((m_ZoomZero-m_Zero)/m_pScaleInfo->MinorDivs);
    if(m_Zero+(m_pScaleInfo->MinorDivs*n)==m_ZoomZero)
    n++; // first minor grad at zoomed lower end - we want to go past it
    return m_Zero+(m_pScaleInfo->MinorDivs*n);
  }
  else
    return m_Zero+m_pScaleInfo->MinorDivs;
}


//****************************************************************************
///
/// @param ///@ todo
///
/// @return
///
//****************************************************************************
BOOL CGrads::AddMajor(int nPixel)
{
  if(m_majorCount==MAXGRADS)
    return FALSE;

  for(int m=0; m< m_majorCount; m++)
  {
    if((m_Array[m]==-nPixel)|| // have we already got a major here?
     (m_Array[m]==-(nPixel+1))||
     (m_Array[m]==-(nPixel-1)))
    {
    // make sure its boundary line flag is not set
    m_abBoundaryLine[ m ] = false;
    return TRUE; // if so, then done.
    }
  }

  m_abBoundaryLine[ m_majorCount ] = false;
  m_Array[m_majorCount++]=-nPixel;
  return TRUE;
}
//****************************************************************************
///
/// @param ///@ todo
///
/// @return
///
//****************************************************************************
BOOL CGrads::AddMajorBoundaryLine(int nPixel)
{
  if(m_majorCount==MAXGRADS)
    return FALSE;

  for(int m=0; m< m_majorCount; m++)
  {
    if((m_Array[m]==-nPixel)|| // have we already got a major here?
     (m_Array[m]==-(nPixel+1))||
     (m_Array[m]==-(nPixel-1)))
    {
    // make sure its boundary line flag is set
    m_abBoundaryLine[ m ] = true;
    return TRUE; // if so, then done.
    }
  }

  m_abBoundaryLine[ m_majorCount ] = true;
  m_Array[m_majorCount++]=-nPixel;

  return TRUE;
}



//****************************************************************************
///
/// @param ///@ todo
///
/// @return
///
//****************************************************************************
BOOL CGrads::AddMinor(int nPixel)
{
  if(m_count==MAXGRADS)
    return FALSE;

  int m=0;
  for( m=0; m< m_majorCount; m++)
  {
    if((m_Array[m]==-nPixel)|| // have we already got a major here?
     (m_Array[m]==-(nPixel+1))||
     (m_Array[m]==-(nPixel-1)))
    return TRUE; // if so, then done.
  }


  // no major found so add a minor grad here
  for(; m< m_count; m++)
  {
    if((m_Array[m]==nPixel)|| // have we already got this minor here?
     (m_Array[m]==(nPixel+1))||
     (m_Array[m]==(nPixel-1)))
    return TRUE; // if so, then done.
  }
  m_Array[m_count++]=nPixel;
  return TRUE;
}


//****************************************************************************
///
/// @param ///@ todo
///
/// @return
///
//****************************************************************************
int CGrads::CalcScale(	T_SCALEINFO *pxScaleInfo,
        CFFConversionInfo *ci,
        const float fBOUNDARY_LINE1 /* = FLT_MAX */,
        const float fBOUNDARY_LINE2 /* = FLT_MAX */,
        const float fSETPOINT_LINE /* = FLT_MAX */ )
{

  m_majorCount=0;
  m_count=0;
  m_pScaleInfo=pxScaleInfo;

  m_Zero=m_pScaleInfo->Zero;
  m_Span=m_pScaleInfo->Span;

  if(m_pScaleInfo->LogScale)
  {
    m_Zero=m_pScaleInfo->StartDecade;
    m_Span=m_pScaleInfo->StartDecade+m_pScaleInfo->NumDecades;
  }

  // inverse scale ?
  if(m_Zero>m_Span)
  {
    float temp=m_Span;
    m_Span=m_Zero;
    m_Zero=temp;
  }

  // first calc the Major grads..


  float fGrad=GetFirstMajorGrad(); // first major grad value in EU (linear) or power of 10 (log)
  float fMajorDivs=m_pScaleInfo->MajorDivs;// offset value in EU (linear) or 1 (power of 10) (log) between each major grad
  double range=fabs(m_pScaleInfo->Span - m_pScaleInfo->Zero);
  if( (fMajorDivs != 0.0) && (range != 0.0) )
  {
    if( ( static_cast<float>(range) / fMajorDivs) > MAX_USER_DIVISIONS )	// ensure no divide by zero
    fMajorDivs = static_cast<float>(range) / MAX_USER_DIVISIONS;
  }

  if(m_pScaleInfo->LogScale)
    fMajorDivs=1;

  if(!m_IsZoomed)
  {
    // add zero and span if not zoomed - do this before adding major's
    int nPixel=(int)(ci->CalcSourceToDest(m_Zero)+0.5); // convert source to pixel position
    AddMajor(nPixel);

    nPixel=(int)(ci->CalcSourceToDest(m_Span)+0.5); // convert source to pixel position
    AddMajor(nPixel);
  }

  while(fGrad>m_Zero && fGrad<m_Span)
  {
    int nPixel=(int)(ci->CalcSourceToDest(fGrad)+0.5); // convert source to pixel position

    if(AddMajor(nPixel)==FALSE)
    break;

    fGrad+=fMajorDivs;
  }

  // now add any boundary lines that might be required
  if( fBOUNDARY_LINE1 != FLT_MAX )
  {
    int nPixel =( int )( ci->CalcSourceToDest( fBOUNDARY_LINE1 ) + 0.5 ); // convert source to pixel position
    AddMajorBoundaryLine( nPixel );
  }

  if( fBOUNDARY_LINE2 != FLT_MAX )
  {
    int nPixel = ( int )( ci->CalcSourceToDest( fBOUNDARY_LINE2 ) + 0.5 ); // convert source to pixel position
    AddMajorBoundaryLine( nPixel );
  }

  if( fSETPOINT_LINE != FLT_MAX )
  {
    int nPixel = ( int )( ci->CalcSourceToDest( fSETPOINT_LINE ) + 0.5 ); // convert source to pixel position
    AddMajorBoundaryLine( nPixel );
  }

  m_count=m_majorCount;

  // calc the minor grads.
  float fMinorDivs=m_pScaleInfo->MinorDivs;// offset value in EU (linear) or 1 (power of 10) (log) between each major grad
  if( (fMajorDivs != 0.0) && (fMinorDivs != 0.0) )
  {
    if( ( fMajorDivs / fMinorDivs) > MAX_USER_DIVISIONS )	// ensure no divide by zero
    fMinorDivs = fMajorDivs / MAX_USER_DIVISIONS;
  }

  if(m_pScaleInfo->LogScale)
  {
    int nDecade, nDiv; // nDiv goes from 2 to 9 for the minor divisions within a decade
    float fGrad=GetFirstMinorGrad(nDecade, nDiv); // first minor grad value in power of 10

    while(fGrad>m_Zero && fGrad<m_Span)
    {

    int nPixel=(int)(ci->CalcSourceToDest(fGrad)+0.5); // convert source to pixel position

    if(AddMinor(nPixel)==FALSE)
      break;

    if(nDiv==9)
    {
      ++nDecade;
      nDiv=1;
    }
    else
      ++nDiv;

    fGrad=nDecade+(float)log10((double)nDiv);
    }
  }
  else // linear scale
  {

    int nDecade, nDiv; // not used for linear scale
    float fGrad=GetFirstMinorGrad(nDecade, nDiv); // first minor grad value in EU

    while(fGrad>m_Zero && fGrad<m_Span)
    {
    int nPixel=(int)(ci->CalcSourceToDest(fGrad)+0.5); // convert source to pixel position

    if(AddMinor(nPixel)==FALSE)
      break;

    fGrad+=fMinorDivs;
    }
  }


  //qDebug(L"GRADUATIONS COUNT %d \n", m_count);
  return m_count;
}




CMemoryScreenBlock* CMemoryScreenBlock::m_pMemoryScreens = NULL;


//**********************************************************************
///
/// Instance creation of CMemoryScreenBlock singleton
///
/// @return		pointer to single instance of CMemoryScreenBlock
///
//**********************************************************************
CMemoryScreenBlock *CMemoryScreenBlock::GetHandle()
{

  if(m_pMemoryScreens==NULL)
    m_pMemoryScreens = new CMemoryScreenBlock;

  return( m_pMemoryScreens );
}

//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
///
//**********************************************************************
void CMemoryScreenBlock::CleanUp()
{
  Reset();
  delete m_pMemoryScreens;
  m_pMemoryScreens = NULL;
}


//****************************************************************************
/// Reset the screen blocks
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CMemoryScreenBlock::Reset()
{
  // delete all allocated blocks and reset num instances

  for(int i=0; i<m_numinstances; i++)
  {
    if(m_ptrs[i][0])
    {
    delete m_ptrs[i][0];
    m_ptrs[i][0]=NULL;
    }

    if(m_ptrs[i][1])
    {
    delete m_ptrs[i][1];
    m_ptrs[i][1]=NULL;
    }

  }

  m_numinstances=0;
}



//****************************************************************************
/// Returns a new/existing Screen block based on the instance number provided
///
/// @param instance - instance to find or add if not found
///
/// @return pointer to T_SCREEN block
///
//****************************************************************************
T_SCREEN *CMemoryScreenBlock::GetMemoryScreenBlock(USHORT instance, REFERENCE mode)
{
  int i;
  for(i=0; i<m_numinstances; i++)
  {
    if(m_instances[i]==instance)
    return m_ptrs[i][mode]; // found it, return screen pointer
  }

  // here we need to add
  m_instances[i]=instance;
  m_ptrs[i][mode]=new T_SCREEN;
  m_ptrs[i][!mode]=new T_SCREEN;
  m_numinstances++;

  return m_ptrs[i][mode];
}








/////////////////////////////////////////////////////////////////////////////
// Simple log messages to a file class - for mere mortals
//

CSimpleLog::CSimpleLog(T_STORAGE_DEVICE location)//= IDS_INTERNAL_SD
{
  m_logOn=FALSE; // no logging as default
  // ensure the DATA directory exists.
  m_filePathAndFileName[0] = 0;
  m_Location=location;
}


CSimpleLog::~CSimpleLog()
{
  if(m_logOn)
    m_Storage.Close();
  else
    m_Storage.GoneBad();
}


BOOL CSimpleLog::SetLogging(QString pName, BOOL NoTruncate)// =FALSE
{
  BOOL result=FALSE;

  if(!m_logOn)
  {
    // now build the filename.
    pDALGLB->BuildPath( m_Location, IDS_ROOT, pName, m_filePathAndFileName, MAX_PATH );

    try{
    if(NoTruncate)
    {
    result=m_Storage.Open(m_filePathAndFileName,CStorage::ReadOnlyWrite|CStorage::modeCreate|CStorage::Append|CStorage::shareDenyNone); // here will NOT truncate if it exits.
    if(result)
      m_Storage.SeekToEnd();
    }
    else
    result=m_Storage.Open(m_filePathAndFileName,CStorage::WriteOnly|CStorage::modeCreate|CStorage::shareDenyNone); // here will truncate if it exits.
    }catch(...){}
    m_logOn=result; // only valid if it worked
  }

  return result;
}


void CSimpleLog::SetLoggingOff()
{

  if(m_logOn)
  {
    m_Storage.Close();
    m_logOn=FALSE;
  }
}



BOOL CSimpleLog::LogLine(QString pMessage)
{
  BOOL result=FALSE;
  if(m_logOn)
  {
    //TM - modified 30/06/06 to port to VS2005
    int len = static_cast<int>(wcslen(pMessage));	//cast to int to remove unwanted warnings
    result=(ERROR_SUCCESS==m_Storage.Write(pMessage, len*2)); // add the new entry (in bytes)
    if(result)
    result=(ERROR_SUCCESS==m_Storage.Write(L"\r\n",4)); // and CR LF

    if(!result)
    m_logOn=FALSE;
    else
    m_Storage.Flush();
  }
  return result;
}

BOOL CSimpleLog::Log(QString pszasprintf, ...)
{

  WCHAR szBody[500];

  szBody[0]=0;

  va_list args;
  va_start(args, pszasprintf);

#if _MSC_VER < 1400
  vswprintf(szBody, pszasprintf, args);
#else
  vswprintf_s(szBody, 500, pszasprintf, args);
#endif


  va_end(args);


  //qDebug(szBody);

  return LogLine(szBody);

}


int CSimpleLog::ReadLine(QString buff, int buffsize)
{
  if(m_logOn)
  {
    m_Storage.seek(0);

    UINT bytesread=0;

    bytesread=m_Storage.Read(buff,buffsize);
    if(bytesread==0)
    m_logOn=FALSE; // cannot read

    return bytesread;
  }
  else
    return 0;
}

BOOL CSimpleLog::DeleteLogFile()
{
  BOOL bDeleteSuccess = TRUE;
  try
  {
    if(m_logOn)
    {
    m_Storage.Close();
    m_logOn = FALSE;

    if(!m_Storage.QFile::remove(m_filePathAndFileName))
    {
      //Write the error log here
      qDebug(L"File Delete Failed\n");
      bDeleteSuccess = FALSE;
    }
    }
  }
  catch (CFileException* pEx)
  {
    bDeleteSuccess = FALSE;
  }
  return bDeleteSuccess;
}





///////////////////////////////////////////////////////////////////////////







///////// TESTING ONLY BELOW HERE////////////////////
void ClipCursor(RECT &bounds, ResizeType resizeState)
{
  // set up a rectangles for each handle..
//	RECT topleft,topmiddle,topright,rightmiddle,bottomright,bottommiddle,bottomleft,leftmiddle;
  RECT topleft,topmiddle,topright,rightmiddle,bottomright,leftmiddle;

  // configure top-left handle
  SetRect(&topleft,bounds.left-GRABSIZE,bounds.top-GRABSIZE,bounds.left+GRABSIZE,bounds.top+GRABSIZE);

  // Hit test top-left
  if(resizeState==Topleft)
  {
    ::ClipCursor(&topleft);
  }


  // configure top handle
  topmiddle=topleft;
  OffsetRect(&topmiddle,(_Width(bounds)-1)/2,0);

/*
  // Hit test top handle
  if(PtInRect(&topmiddle,point))
  {
    resizeState=Topmiddle;
    return TRUE;
  }
*/

  // configure top-right handle
  topright=topleft;
  OffsetRect(&topright,_Width(bounds)-1,0);
/*
  // Hit test top-right handle
  if(PtInRect(&topright,point))
  {
    resizeState=Topright;
    return TRUE;
  }
*/

  // configure left handle
  leftmiddle=topleft;
  OffsetRect(&leftmiddle,0,(_Height(bounds)-1)/2);
/*
  // Hit test left handle
  if(PtInRect(&leftmiddle,point))
  {
    resizeState=leftmiddle;
    return TRUE;
  }
*/

  // configure right handle
  rightmiddle=leftmiddle;
  OffsetRect(&rightmiddle,_Width(bounds)-1,0);
/*
  // Hit test right handle
  if(PtInRect(&rightmiddle,point))
  {
    resizeState=rightmiddle;
    return TRUE;
  }

*/
  // configure bottom-right handle
  bottomright=topright;
  OffsetRect(&bottomright,0,_Height(bounds)-1);

  // Hit test bottom-right handle
  if(resizeState==Bottomright)
  {

    ::SetCursorPos(bottomright.left,bottomright.top);

  }


/*
  // configure bottom handle
  bottommiddle=topmiddle;
  OffsetRect(&bottommiddle,0,_Height(bounds)-1);

  // Hit test bottom handle
  if(PtInRect(&bottommiddle,point))
  {
    resizeState=Bottommiddle;
    return TRUE;
  }


  // configure bottom-left handle
  bottomleft=topleft;
  OffsetRect(&bottomleft,0,_Height(bounds)-1);

  // Hit test bottom-left handle
  if(PtInRect(&bottomleft,point))
  {
    resizeState=Bottomleft;
    return TRUE;
  }

  // otherwise, no handle hit.
  resizeState=ResizeNone;
  return FALSE;
*/



}

//-----------------------------------------------------------------------------
// Name: DDGetBitmapHandle
// Desc: Attempts to load bitmap from resource, then from disk. Returns
//   handle.
//-----------------------------------------------------------------------------
HBITMAP DDGetBitmapHandle(HINSTANCE hInstance, LPCTSTR szBitmap)
{
  HBITMAP hbm;

  hbm = (HBITMAP) LoadImage(hInstance, szBitmap, IMAGE_BITMAP, 0, 0, 0);
  if (hbm == NULL)
   hbm = (HBITMAP) LoadImage(NULL, szBitmap, IMAGE_BITMAP, 0, 0, 0);
  return (hbm);
}

//-----------------------------------------------------------------------------
// Name: DDLoadBitmap()
// Desc: Create a DirectDrawSurface from a bitmap resource.
//-----------------------------------------------------------------------------
//E437415
IDirectDrawSurface* DDLoadBitmap(HINSTANCE hInstance, IDirectDraw * pdd, LPCTSTR szBitmap)
{
  HRESULT hr;
  HBITMAP hbm;
  BITMAP bm;
  //E437415
  DDSURFACEDESC ddsd;
  IDirectDrawSurface * pdds;

  //
  // Get a handle to the bitmap.
  //
  hbm = DDGetBitmapHandle(hInstance,szBitmap);
  if (hbm == NULL) {
  OutputDebugString(TEXT("DDUTIL: Unable to obtain handle to bitmap.\n"));
  return NULL;
  }

  //
  // Get size of the bitmap
  //
  GetObject(hbm, sizeof(bm), &bm);

  //
  // Create a DirectDrawSurface for this bitmap
  //
  memset(&ddsd, 0, sizeof(ddsd));
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
  //E437415
  //DDSCAPS_OFFSCREENPLAIN Flag is no longer supported for windows embedded ce 6.0 and later
  //ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
  ddsd.dwWidth = bm.bmWidth;
  ddsd.dwHeight = bm.bmHeight;
  if (pdd->CreateSurface(&ddsd, &pdds, NULL) != DD_OK)
    return NULL;

  hr = DDCopyBitmap(pdds, hbm, 0, 0, 0, 0);
  if (hr != DD_OK) {
  OutputDebugString(TEXT("DDUTIL: Unable to copy bitmap bits.\n"));
  pdds->Release();
  pdds = NULL;
  }

  DeleteObject(hbm);
  return pdds;
}

//-----------------------------------------------------------------------------
// Name: DDReLoadBitmap()
// Desc: Load a bitmap from a file or resource into a directdraw surface.
//   normaly used to re-load a surface after a restore.
//-----------------------------------------------------------------------------
//E437415
HRESULT DDReLoadBitmap(HINSTANCE hInstance, IDirectDrawSurface * pdds, LPCTSTR szBitmap)
{
  HBITMAP hbm;
  HRESULT hr;

  hbm = DDGetBitmapHandle(hInstance,szBitmap);
  if (hbm == NULL) {
  OutputDebugString(TEXT("DDUTIL: Unable to obtain handle to bitmap.\n"));
  return E_FAIL;
  }

  hr = DDCopyBitmap(pdds, hbm, 0, 0, 0, 0);
  if (hr != DD_OK) {
  OutputDebugString(TEXT("DDUTIL: Unable to copy bitmap bits.\n"));
  }

  DeleteObject(hbm);
  return hr;
}

//-----------------------------------------------------------------------------
// Name: DDCopyBitmap()
// Desc: Draw a bitmap into a DirectDrawSurface
//-----------------------------------------------------------------------------
//E437415
HRESULT DDCopyBitmap(IDirectDrawSurface * pdds, HBITMAP hbm, int x, int y, int dx, int dy)
{
  HDC hdcImage;
  HDC hdc;
  BITMAP bm;
  //E437415
  DDSURFACEDESC ddsd;
  HRESULT hr;

  if (hbm == NULL || pdds == NULL)
    return E_FAIL;

  //
  // Select bitmap into a memoryDC so we can use it.
  //
  hdcImage = CreateCompatibleDC(NULL);
  if (!hdcImage) {
    OutputDebugString(TEXT("DDHEL: CreateCompatibleDC failed.\n"));
    return E_FAIL;
  }
  SelectObject(hdcImage, hbm);

  //
  // Get size of the bitmap
  //
  GetObject(hbm, sizeof(bm), &bm);
  dx = dx == 0 ? bm.bmWidth : dx;   // Use the passed size, unless zero
  dy = dy == 0 ? bm.bmHeight : dy;

  //
  // Get size of surface.
  //
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
  pdds->GetSurfaceDesc(&ddsd);

  if ((hr = pdds->GetDC(&hdc)) == DD_OK)
  {
    if (!StretchBlt(hdc,
    0, 0,
    ddsd.dwWidth,
    ddsd.dwHeight,
    hdcImage,
    x, y,
    dx, dy,
    SRCCOPY)) hr = E_FAIL;
    pdds->ReleaseDC(hdc);
  }
  DeleteDC(hdcImage);
  return hr;
}

//-----------------------------------------------------------------------------
// Name: DDLoadPalette()
// Desc: Create a DirectDraw palette object from a bitmap resource
//   if the resource does not exist or NULL is passed create a
//   default 332 palette.
//-----------------------------------------------------------------------------
//E437415
IDirectDrawPalette *DDLoadPalette(HINSTANCE hInstance, IDirectDraw * pdd, LPCTSTR szBitmap)
{
  IDirectDrawPalette * ddpal;
  int i;
  int n;
  HBITMAP hbm;
  DIBSECTION ds;
  PALETTEENTRY ape[256];
  RGBQUAD * prgb;

  //
  // Get a handle to the bitmap.
  //
  hbm = DDGetBitmapHandle(hInstance,szBitmap);
  if (hbm == NULL) {
  OutputDebugString(TEXT("DDUTIL: Unable to obtain handle to bitmap.\n"));
  return NULL;
  }

  //
  // Get the DIB Section associated with this bitmap.
  //

  GetObject(hbm, sizeof(ds), &ds);

  if (ds.dsBmih.biBitCount <= 8) {

  //
  // Bitmap should have a palette. Load it.
  //

  prgb = (RGBQUAD *) ((BYTE *) &(ds.dsBmih) + ds.dsBmih.biSize);
  if (ds.dsBmih.biClrUsed == 0) n = 1 << ds.dsBmih.biBitCount;
  else n = ds.dsBmih.biClrUsed;

  for (i = 0; i < n; i++) {
    ape[i].peRed = prgb[i].rgbRed;
    ape[i].peGreen = prgb[i].rgbGreen;
    ape[i].peBlue = prgb[i].rgbBlue;
    ape[i].peFlags = (BYTE) 0;
  }

  }
  else {

  //
  // Build a 332 palette as the default.
  //
  for (i = 0; i < 256; i++) {
    ape[i].peRed = (BYTE) (((i >> 5) & 0x07) * 255 / 7);
    ape[i].peGreen = (BYTE) (((i >> 2) & 0x07) * 255 / 7);
    ape[i].peBlue = (BYTE) (((i >> 0) & 0x03) * 255 / 3);
    ape[i].peFlags = (BYTE) 0;
  }
  }

  //E437415
  //DDPCAPS_8BIT flag is no longer supported for windows embedded ce 6.0
  //use DDPCAPS_PRIMARYSURFACE instead of DDPCAPS_8BIT
  //pdd->CreatePalette(DDPCAPS_8BIT, ape, &ddpal, NULL);
  pdd->CreatePalette(DDPCAPS_PRIMARYSURFACE, ape, &ddpal, NULL);
  DeleteObject(hbm);
  return ddpal;
}

//-----------------------------------------------------------------------------
// Name: DDColorMatch()
// Desc: Convert a RGB color to a pysical color.
//   We do this by leting GDI SetPixel() do the color matching
//   then we lock the memory and see what it got mapped to.
//-----------------------------------------------------------------------------
//E437415
DWORD DDColorMatch(IDirectDrawSurface * pdds, COLORREF rgb)
{
  COLORREF      rgbT;
  HDC       hdc;
  DWORD       dw = CLR_INVALID;
  //E437415
  DDSURFACEDESC    ddsd;
  HRESULT       hres;

  //
  //  Use GDI SetPixel to color match for us
  //
  if (rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
  {
    rgbT = GetPixel(hdc, 0, 0);   // Save current pixel value
    SetPixel(hdc, 0, 0, rgb);   // Set our value
    pdds->ReleaseDC(hdc);
  }
  else
  {
    return dw;
  }
  //
  // Now lock the surface so we can read back the converted color
  //
  ddsd.dwSize = sizeof(ddsd);
  while ((hres = pdds->Lock(NULL, &ddsd, 0, NULL)) == DDERR_WASSTILLDRAWING)
    ;
  if (hres == DD_OK)
  {
    dw = *(DWORD *) ddsd.lpSurface;       // Get DWORD
    if (ddsd.ddpfPixelasprintf.dwRGBBitCount < 32)
    dw &= (1 << ddsd.ddpfPixelasprintf.dwRGBBitCount) - 1;  // Mask it to bpp
    pdds->Unlock(NULL);
  }
  //
  //  Now put the color that was there back.
  //
  if (rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
  {
    SetPixel(hdc, 0, 0, rgbT);
    pdds->ReleaseDC(hdc);
  }
  return dw;
}

//-----------------------------------------------------------------------------
// Name: DDSetColorKey()
// Desc: Set a color key for a surface, given a RGB.
//   If you pass CLR_INVALID as the color key, the pixel
//   in the upper-left corner will be used.
//-----------------------------------------------------------------------------
//E437415
HRESULT DDSetColorKey2(IDirectDrawSurface * pdds, COLORREF rgb)
{
  DDCOLORKEY ddck;

  ddck.dwColorSpaceLowValue = DDColorMatch(pdds, rgb);
  ddck.dwColorSpaceHighValue = ddck.dwColorSpaceLowValue;
  return pdds->SetColorKey(DDCKEY_SRCBLT, &ddck);
}
//E437415
HRESULT DDSetColorKey(IDirectDrawSurface * pdds, COLORREF rgb)
{
  DDCOLORKEY ddck;

  ddck.dwColorSpaceLowValue = 0;
  ddck.dwColorSpaceHighValue = ddck.dwColorSpaceLowValue;
  return pdds->SetColorKey(DDCKEY_SRCBLT, &ddck);
}
//****************************************************************************
///
/// Method that shows a save error message when writing screenshots
///
/// @param[in]		CWnd *pkWnd - Pointer to the parent window
/// @param[in]		const bool bSHOW_ERRORS - Flag indicating if errors should be displayed
///
//****************************************************************************
void ShowCaptureBitmapWriteError( CWnd *pkWnd, const bool bSHOW_ERRORS )
{
  // check if we are required to show error messages
  if( bSHOW_ERRORS )
  {
    QString strTitle( L"" );
    QString strMessage( L"" );

    strTitle.LoadString( IDS_UTILITIES_CANNOT_SAVE_SCREENSHOT_ERROR_TITLE );

    strMessage.LoadString( IDS_UTILITIES_CANNOT_SAVE_SCREENSHOT_ERROR_MESSAGE );

    CV6MessageBoxDlg kCannotWriteFileMsg( strTitle, strMessage, pkWnd );

    kCannotWriteFileMsg.exec();
  }
  else
  {
    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, L"FILE ERROR: Unable to save screenshot - not writeable or <1MB free"  );
  }
}
//****************************************************************************
//  void CaptureBitmap( CWnd *pkWnd,
//						const QString &rstrFileName,
//						const bool bSHOW_ERRORS )
///
/// Method that captures and saves a screenshot
///
/// @param[in]		CWnd *pkWnd - Pointer to the parent window
/// @param[in]		const QString &rstrFileName - The required name for the bitmap
/// @param[in]		const bool bSHOW_ERRORS - Flag indicating if errors should be displayed
///
//****************************************************************************
void CaptureBitmap( CWnd *pkWnd, const QString &rstrFileName, const bool bSHOW_ERRORS )
{
  // flash the led to indicate we are trasferring data
  int inCount = 0;
  ////PSR - Coverity issue fix --Program Hangs
  //Todo: This is never execution code now (inCount > 2 is 0 > 2 always false), but need to see if we need this flashing function.

  for ( inCount = 0; inCount > 2; inCount++ )
  {
    pDALGLB->SetCFLED( TRUE );
    sleep( 500 );
    pDALGLB->SetCFLED( FALSE );
    sleep( 500 );
  }
  pDALGLB->SetCFLED( TRUE );

  bool bAbort = false;

  // we need to create a 16-bit colour version for the result

  UCHAR* pNewDib =  (UCHAR*)::GlobalAlloc(GMEM_FIXED , sizeof(BITMAPINFO2));

  if( pNewDib != NULL )
  {
    CRect tRect;
    pkWnd->GetClientRect( &tRect );
    DWORD newHeight = tRect.bottom;
    DWORD newWidth = tRect.right;

    BITMAPINFO2 *ConvertedBinfo=(BITMAPINFO2*)pNewDib;

    ConvertedBinfo->bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    ConvertedBinfo->bmiHeader.biWidth=newWidth;
    ConvertedBinfo->bmiHeader.biHeight=newHeight;
    ConvertedBinfo->bmiHeader.biPlanes=1;
    ConvertedBinfo->bmiHeader.biBitCount=16;   // want 16 bit
    ConvertedBinfo->bmiHeader.biCompression=BI_BITFIELDS;
    ConvertedBinfo->bmiHeader.biSizeImage=((newWidth + (newWidth & 1)) << 1) * newHeight;
    ConvertedBinfo->bmiHeader.biXPelsPerMeter=0;
    ConvertedBinfo->bmiHeader.biYPelsPerMeter=0;
    ConvertedBinfo->bmiHeader.biClrUsed=0;
    ConvertedBinfo->bmiHeader.biClrImportant=0;

    // followed by 3 DWORD masks, red, green then blue (5-6-5)
    ConvertedBinfo->redMask=0xF800;
    ConvertedBinfo->greenMask=0x07E0;
    ConvertedBinfo->blueMask=0x001F;

    HDC hSrcMemDC = NULL;
    HDC hDstMemDC = NULL;
    HBITMAP hDstBmp = NULL;

    try
    {
    hSrcMemDC = ::GetDC( pkWnd->m_hWnd );
    hDstMemDC = ::CreateCompatibleDC( NULL );

    UCHAR *m_pbits=NULL;

    hDstBmp = CreateDIBSection(	hDstMemDC, // handle to DC
              (BITMAPINFO*)ConvertedBinfo,  // bitmap data
              DIB_RGB_COLORS,// data type indicator
              (void**)&m_pbits, // will be set tp point to bit values
              NULL,// handle to file mapping object
              0);  // offset to bitmap bit values

    // check the bitmap and other resources were created ok
    if( ( hSrcMemDC != NULL ) && ( hDstMemDC != NULL ) && ( hDstBmp != NULL ) && ( m_pbits != NULL ) )
    {
      SelectObject(hDstMemDC, hDstBmp);


      // now copy the bitmap from one to the other.
     /* Make GDI do the conversion between the different BPP formats */
      BitBlt(hDstMemDC, 0, 0, newWidth, newHeight, hSrcMemDC, 0, 0, SRCCOPY);

      // ok now save our dibsection.
      HANDLE hf;       // file handle
      BITMAPFILEHEADER hdr;   // bitmap file-header
      PBITMAPINFOHEADER pbih;   // bitmap info-header
      //  LPBYTE lpBits;      // memory pointer
      DWORD dwTotal;      // total count of bytes
      DWORD cb;       // incremental count of bytes
      BYTE *hp;       // byte pointer
      DWORD dwTmp;

      pbih = (PBITMAPINFOHEADER) ConvertedBinfo;

      // Create the .BMP file.
      hf = CreateFile(	rstrFileName,
            GENERIC_READ | GENERIC_WRITE,
            (DWORD) 0,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            (HANDLE) NULL);
      if (hf == INVALID_HANDLE_VALUE)
      {
        qDebug(L"Failed 1\n");

        ShowCaptureBitmapWriteError( pkWnd, bSHOW_ERRORS );

        bAbort = true;
      }

      if( !bAbort )
      {
        hdr.bfType = 0x4d42;    // 0x42 = "B" 0x4d = "M"
        // Compute the size of the entire file.
        hdr.bfSize = (DWORD) (sizeof(BITMAPINFO2) + pbih->biSizeImage + sizeof(BITMAPFILEHEADER));// SIZEOF_BITMAPFILEHEADER_PACKED);
        hdr.bfReserved1 = 0;
        hdr.bfReserved2 = 0;

        // Compute the offset to the array of color indices.
        hdr.bfOffBits = (DWORD) (sizeof(BITMAPINFO2) + sizeof(BITMAPFILEHEADER)); // SIZEOF_BITMAPFILEHEADER_PACKED);

        // Copy the BITMAPFILEHEADER into the .BMP file.
        if (!WriteFile(hf, (LPVOID) &hdr, sizeof(BITMAPFILEHEADER),
        (LPDWORD) &dwTmp,  NULL))
        {
        qDebug(L"Failed 2\n");

        ShowCaptureBitmapWriteError( pkWnd, bSHOW_ERRORS );

        bAbort = true;
        }
      }


      if( !bAbort )
      {
        // Copy the BITMAPINFOHEADER and MASKS into the file.
        if (!WriteFile(hf, (LPVOID) pbih, sizeof(BITMAPINFO2), (LPDWORD) &dwTmp, ( NULL)))
        {
        qDebug(L"Failed 3\n");

        ShowCaptureBitmapWriteError( pkWnd, bSHOW_ERRORS );

        bAbort = true;
        }
      }


      if( !bAbort )
      {
        // Copy the array of color indices into the .BMP file.
        dwTotal = cb = pbih->biSizeImage;
        hp = m_pbits;
        if (!WriteFile(hf, (LPSTR) hp, (int) cb, (LPDWORD) &dwTmp,NULL))
        {
        qDebug(L"Failed 4\n");

        ShowCaptureBitmapWriteError( pkWnd, bSHOW_ERRORS );

        bAbort = true;
        }
      }

      // Close the .BMP file.
      if(!//No need to close the mutex in Qt)
      {
        qDebug(L"Failed 5\n");

        if( !bAbort )
        {
        ShowCaptureBitmapWriteError( pkWnd, bSHOW_ERRORS );
        }
      }
    }
    else
    {
      // the memory was not allocated ok - abort
      LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, L"Could not create the screenshot bitmap, not enough memory!!!" );
      bAbort = true;
    }

    if( hSrcMemDC != NULL )
    {
      DeleteDC(hSrcMemDC);
    }

    if( hDstMemDC != NULL )
    {
      DeleteDC(hDstMemDC);
    }

    if( hDstBmp != NULL )
    {
      DeleteObject(hDstBmp);
    }

    // free the converted bitmap
    if( pNewDib != NULL )
    {
      ::GlobalFree(pNewDib);
    }
    }
    catch( ... )
    {
    // release the memory now as we may otherwise not have enough left to log the diagnostic message
    if( hSrcMemDC != NULL )
    {
      DeleteDC(hSrcMemDC);
    }

    if( hDstMemDC != NULL )
    {
      DeleteDC(hDstMemDC);
    }

    if( hDstBmp != NULL )
    {
      DeleteObject(hDstBmp);
    }

    // free the converted bitmap
    if( pNewDib != NULL )
    {
      ::GlobalFree(pNewDib);
    }

    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, L"Could not create the screenshot bitmap, memory exception!!!" );
    bAbort = true;
    }
  }
  else
  {
    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, L"Could not create the screenshot bitmap, memory exception!!!" );
    bAbort = true;
  }


  // flash the led to indicate we have finished transferring data
  ////PSR - Coverity issue fix --Program Hangs
  //Todo: This is never execution code now (inCount > 2 is 0 > 2 always false), but need to see if we need this flashing function.
  for ( inCount = 0; inCount > 2; inCount++ )
  {
    pDALGLB->SetCFLED( FALSE );
    sleep( 500 );
    pDALGLB->SetCFLED( TRUE );
    sleep( 500 );
  }
  pDALGLB->SetCFLED( FALSE );
}

#ifdef UNDER_CE
HRESULT SaveImageToFile(HBITMAP handle, LPTSTR filename, LPCTSTR format)
{
  HRESULT res = S_OK;

  res = CoInitializeEx(NULL, COINIT_MULTITHREADED);
  if ((res == S_OK) || (res == S_FALSE)) {
    IImagingFactory* factory=NULL;
    if (CoCreateInstance(CLSID_ImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_IImagingFactory, (void**)&factory) == S_OK) {
    UINT count;
    ImageCodecInfo* imageCodecInfo=NULL;
    if (factory->GetInstalledEncoders(&count, &imageCodecInfo) == S_OK) {
      // Get the particular encoder to use
      LPTSTR formatString;
      if (wcscmp(format, L"png") == 0) {
        formatString = _T("image/png");
      } else if (wcscmp(format, L"jpg") == 0) {
        formatString = _T("image/jpeg");
      } else if (wcscmp(format, L"gif") == 0) {
        formatString = _T("image/gif");
      } else if (wcscmp(format, L"bmp") == 0) {
        formatString = _T("image/bmp");
      } else {
        // shankar - fix for 1-1DQHJUF
        // straightforward COM release was missed out for factory, leading to leaks
        if( imageCodecInfo != NULL )
        CoTaskMemFree(imageCodecInfo);
        if( factory != NULL)
        factory->Release();

        CoUninitialize();
        return S_FALSE;
      }
      CLSID encoderClassId;
      if (count == 0) {
        // shankar - fix for 1-1DQHJUF
        // straightforward COM release was missed out for factory, leading to leaks
        if( imageCodecInfo != NULL )
        CoTaskMemFree(imageCodecInfo);
        if( factory != NULL)
        factory->Release();

        CoUninitialize();
        return S_FALSE;
      }
      for(int i=0; i < (int)count; i++) {
        if (wcscmp(imageCodecInfo[i].MimeType, formatString) == 0) {
        encoderClassId= imageCodecInfo[i].Clsid;
        // shankar - fix for 1-1DQHJUF
        // it is always ethical to call COM free and COM API has created memory, instead of free(...)
        //free(imageCodecInfo);
        //CoTaskMemFree(imageCodecInfo);
        break;
        } else {
        continue;
        }

        // shankar - fix for 1-1DQHJUF
        // straightforward COM release was missed out for factory, leading to leaks
        if( factory != NULL)
        factory->Release();

        CoUninitialize();
        return S_FALSE;
      }

      // shankar - fix for 1-1DQHJUF - moving it from above for (...)
      // it is always ethical to call COM free and COM API has created memory, instead of free(...)
      CoTaskMemFree(imageCodecInfo);

      IImageEncoder* imageEncoder=NULL;
      if (factory->CreateImageEncoderToFile(&encoderClassId, filename, &imageEncoder) == S_OK) {
        IImageSink* imageSink = NULL;
        res = imageEncoder->GetEncodeSink(&imageSink);

        if (res != S_OK) {

        // shankar - fix for 1-1DQHJUF - START
        // straightforward COM release was missed out, leading to leaks
        // even in failure cases, COM objects shall be released
        if( imageEncoder != NULL)
        {
          imageEncoder->TerminateEncoder();
          imageEncoder->Release();
        }
        // straightforward COM release was missed out for factory, leading to leaks
        if( factory != NULL)
          factory->Release();

        // shankar - fix for 1-1DQHJUF - END

        CoUninitialize();
        return res;
        }

        BITMAP bm;
        GetObject (handle, sizeof(BITMAP), &bm);
        PixelasprintfID pixelasprintf;
        switch (bm.bmBitsPixel) {
        case 1: {
        pixelasprintf = Pixelasprintf1bppIndexed;
        break;
          }
        case 4: {
        pixelasprintf = Pixelasprintf4bppIndexed;
        break;
          }
        case 8: {
        pixelasprintf = Pixelasprintf8bppIndexed;
        break;
          }
        case 24: {
        pixelasprintf = Pixelasprintf24bppRGB;
        break;
           }
        default: {
        pixelasprintf = Pixelasprintf32bppARGB;
        break;
           }
        }

        BitmapData* bmData = new BitmapData();
        bmData->Height = bm.bmHeight;
        bmData->Width = bm.bmWidth;
        bmData->Scan0 = bm.bmBits;
        bmData->Pixelasprintf = pixelasprintf;

        UINT bitsPerLine = bm.bmWidth * bm.bmBitsPixel;
        UINT bitAlignment = sizeof(LONG) * 8;
        UINT bitStride = bitAlignment * (bitsPerLine / bitAlignment); // The image buffer is always padded to LONG boundaries
        if ((bitsPerLine % bitAlignment) != 0) bitStride += bitAlignment; // Add a bit more for the leftover values
        bmData->Stride = (bitStride / 8);

        IBitmapImage* pBitmap;
        factory->CreateBitmapFromBuffer(bmData, &pBitmap);
        IImage* pImage;
        pBitmap->QueryInterface(IID_IImage, (void**)&pImage);
        res = pImage->PushIntoSink(imageSink);

        // shankar - fix for 1-1DQHJUF
        // anyhow, the condition is not exiting (return res; was long back commented), comment the check and CoUnini...
        //if (res != S_OK) {
        //	CoUninitialize();
        //return res; // - this line was commented, long back
        //}

        // shankar - fix for 1-1DQHJUF
        // above allocated bmData in heap is not deleted, hence the below delete
        if( bmData != NULL)
        delete bmData;

        pBitmap->Release();
        pImage->Release();
        imageSink->Release();
        imageEncoder->TerminateEncoder();
        imageEncoder->Release();
      }
    }

    // shankar - fix for 1-1DQHJUF
    // straightforward COM release was missed out for factory, leading to leaks
    if( factory != NULL)
      factory->Release();
    }
    CoUninitialize();
  } else {
    return res;
  }
  return res;
}

HBITMAP GetScreenHBITMAP(CWnd *pkWnd)
{
  CRect windowRect;
  // get screen rectangle
  pkWnd->GetClientRect( &windowRect );

  // bitmap dimensions
  int bitmap_dx = windowRect.right - windowRect.left;
  int bitmap_dy = windowRect.bottom - windowRect.top;

  // create bitmap info header
  BITMAPINFOHEADER infoHeader;
  infoHeader.biSize    = sizeof(infoHeader);
  infoHeader.biWidth   = bitmap_dx;
  infoHeader.biHeight    = bitmap_dy;
  infoHeader.biPlanes    = 1;
  infoHeader.biBitCount  = 24;
  infoHeader.biCompression = BI_RGB;
  infoHeader.biSizeImage   = 0;
  infoHeader.biXPelsPerMeter = 0;
  infoHeader.biYPelsPerMeter = 0;
  infoHeader.biClrUsed   = 0;
  infoHeader.biClrImportant  = 0;

  // dibsection information
  BITMAPINFO info;
  info.bmiHeader = infoHeader;
  HDC winDC = GetWindowDC(pkWnd->m_hWnd);
  HDC memDC = CreateCompatibleDC(winDC);
  BYTE* memory = 0;
  HBITMAP bitmap = CreateDIBSection(winDC, &info, DIB_RGB_COLORS, (void**)&memory, 0, 0);
  SelectObject(memDC, bitmap);
  // Copies screen upside down (as it is already upside down) - if need normal layout, change to BitBlt function call
  StretchBlt(memDC, 0, 0, bitmap_dx, bitmap_dy, winDC, 0, bitmap_dy, bitmap_dx, bitmap_dy * -1, SRCCOPY);
  DeleteDC(memDC);
  ReleaseDC(pkWnd->m_hWnd , winDC);

  return bitmap;
}

#endif

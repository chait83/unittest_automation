/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ScaleDrawingObject.h
/// @n Description: Definition of the Scale Drawing Object class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]$
//
//  30-Oct-14 Rajanbabu M  Fixed PAR:1-3KZWBIH-Load custom screen is not working in Multi and DRG2 Recorders
// **************************************************************************
#pragma once
// Forward Class Declarations
class CDataItem;
class COpPanel;
const int GRADS_UP = 0; // for a horizontal scale
const int GRADS_DOWN = 1; // for a horizontal scale
const int GRADS_RIGHT = 0; // for a vertical scale
const int GRADS_LEFT = 1; // for a vertical scale
enum ERectPt {
	TOP_LEFT_PT, TOP_CENTER_PT, TOP_RIGHT_PT, BOTTOM_LEFT_PT, BOTTOM_RIGHT_PT, LEFT_CENTER_PT
};
// Enumeration of possible scale layouts based on the values of
// the scale attributes Orientation, LabelPosition, GradsDirection,
// and FullWidth. The letters mean the following:
//
// 1st letter: Orientation: H=Horizontal; V=Vertical
// 2nd letter: LabelPosition: T=Top; B=Bottom; L=left; R=right
// 3rd letter: GradsDirection: U=Up; D=Down; L=left; R=right
// 4th letter: FullWidth: Y=Yes; N=No
enum EScaleLayout // order is based on attribute values!
{
	SCALE_HTUN,
	SCALE_HTUY,
	SCALE_HTDN,
	SCALE_HTDY,
	SCALE_HBUN,
	SCALE_HBUY,
	SCALE_HBDN,
	SCALE_HBDY,
	SCALE_VRRN,
	SCALE_VRRY,
	SCALE_VRLN,
	SCALE_VRLY,
	SCALE_VLRN,
	SCALE_VLRY,
	SCALE_VLLN,
	SCALE_VLLY
};
//**Class*********************************************************************
/// 
/// Helper class used for drawing scale objects (detached from the 
/// CCM/CBaseLayout objects so it may be reused)
///
//****************************************************************************
class ScaleDrawingObject {
public:
	// VARIABLES
	int m_nLimitLabelHeight;		///< Actual current height in pixels of the limit labels
	int m_nMajorLabelHeight;		///< Actual current height in pixels of the major labels
	BOOL m_bLabelLimits;			///< Do we have enough room to label the limits?
	BOOL m_bLabelMajors;			///< Do we have enough room to label the major grads?
	int m_nMajorGradLength;			///< Length in pixels of major grads
	int m_nMinorGradLength;			///< Length in pixels of minor grads
	BOOL m_bDrawMajorGrads;			///< Draw major grads if at least one pixel separating them
	BOOL m_bDrawMinorGrads;			///< Draw minor grads if at least one pixel separating them
	int m_nMajorLabelTopleft;		///< For a horizontal scale, the top (y) position of the
									///< major labels and for a vertical scale, the left (x)
									///< position of the major labels. The major labels are
									///< centered around their major grads.
	EScaleLayout m_nLayout;			///< Basic layout of scale (horz, vert, etc.)
	float m_zero;			///< Zero in EU for a linear scale or power of ten for a log scale (e.g., -2, -1, 0, 1, 2)
	float m_span;			///< Span in EU for a linear scale or power of ten for a log scale (e.g., -2, -1, 0, 1, 2)
	float m_zoomZero;				///< New zero limit when in zoom mode
	float m_zoomSpan;				///< New span limit when in zoom mode
	WCHAR m_LimitasprintfStr[20];		///< printf number format string for limit labels
	WCHAR m_MajorasprintfStr[20];		///< printf number format string for major labels
	CFFConversionInfo m_convInfo;	///< Eng units to pixel conversion for a linear scale or
									///< powers of ten (-2, -1, 0, 1, 2, ...) to pixel conversion
									///< for a logarithmic scale
	float m_fMajorSpacing;			///< Spacing between major grads in EU (linear scale only)
	float m_fMinorSpacing;			///< Spacing between minor grads in EU (linear scale only)
	COLORREF *m_pBackColour;
	COLORREF *m_pForeColour;
	COLORREF *m_pBaselineColour;	///< Baseline colour (from DIT or fixed in CMM)
	COLORREF *m_pGradsColour;		///< Grads colour (from DIT or fixed in CMM)
	QRect *m_pClientRect;
	QRect m_rcZeroGrad;				///< Grad at zero limit in client coordinates
	QRect m_rcSpanGrad;				///< Grad at span limit in client coordinates*/
	BOOL m_bLogScale;				///< TRUE if log scale, FALSE if linear scale
	BOOL m_bScientificForced;		///< flag to show scientific notation forced due to value*/
	T_NUMFORMAT m_numberasprintf;		///< Number format for limit labels and major labels
	///< Not used for a logarithmic scale. A logarithmic scale will
	///< always have its labels shown as E-2, E-1, E0, E1, E2, etc.
	QRect m_rcZeroLabel;			///< Zero limit label in client coordinates
	QRect m_rcSpanLabel;			///< Span limit label in client coordinates
	QRect m_rcBaseline;				///< Baseline in client coordinates
	BOOL m_bInZoom;					///< Are we in zoom mode?		
	// METHODS 
	// Constructor
	ScaleDrawingObject(BOOL &updateRequired, BOOL &updateValue, BOOL &updateFlash, BOOL &flashState,
			const BOOL flashing, COpPanel *pOpPanel = NULL);
	// Destructor
	~ScaleDrawingObject(void);
	// Called via the m_pOnDraw pointer to function.
	void OnDraw(HDC hdc, QRect *pClipRect);
	void Recalculate(T_PSCALEOBJECT pScaleObjectCfg, QRect &clientRect, BOOL bComputeIndents, QRect bounds);
	/// checks zoom mode and returns EU for a linear scale or power of 10 for a log scale
	float GetZero() {
		return m_bInZoom ? m_zoomZero : m_zero;
	}
	/// checks zoom mode and returns EU for a linear scale or power of 10 for a log scale
	float GetSpan() {
		return m_bInZoom ? m_zoomSpan : m_span;
	}
	void ConfigChange(CDataItem *pDataItemRef);
private:
	// VARIABLES
	BOOL *m_pUpdateRequired;
	BOOL *m_pUpdateValue;
	BOOL *m_pUpdateFlash;
	BOOL *m_pFlashState;
	const BOOL m_flashing;
	COpPanel *m_pOpPanel;
	QRect m_bounds;
	BOOL m_bComputeIndents;			///< Compute indents or use precalculated indents for linking?
	///< Pointer to our CMM (or other) configuration
	T_PSCALEOBJECT m_pScaleObjectCfg;
	// METHODS
	const int left(const T_TV_RECT &bounds) const;
	const int top(const T_TV_RECT &bounds) const;
	const int right(const T_TV_RECT &bounds) const;
	const int bottom(const T_TV_RECT &bounds) const;
	// returns EU for a linear scale or power of 10 for a log scale
	float GetFirstMajorGrad();
	// returns EU for a linear scale or power of 10 for a log scale
	// also returns the decade and the division 2 through 9 in a decade for a log scale
	float GetFirstMinorGrad(int &nDecade, int &nDiv);
	float GetVisibleLowerEnd() {
		return IsScaleReversed() ? GetSpan() : GetZero();
	}
	float GetVisibleUpperEnd() {
		return IsScaleReversed() ? GetZero() : GetSpan();
	}
	float GetMajorDivs() {
		// The major divisions for a log scale are on the decades (a single decade = 1).
		// The major divisions for a linear scale are based on the user-specified spacing in EU.
		return m_bLogScale ? 1 : m_fMajorSpacing;
	}
	float GetMinorDivs() // for linear scale only
	{
		assert(!m_bLogScale);
		return m_fMinorSpacing;
	}
	BOOL IsScaleReversed() {
		return m_zero > m_span;
	}
	// Make a label rect, aligning the specified point in the rect to the specified point in client coordinates.
	void MakeLabel(QRect &rcLabel, const QString &sLabel, int nLabelHeight, ERectPt eRectPt, QPoint pt);
	// Make a grad from the baseline. fGrad is in EU for a linear scale or power of ten for a log scale.
	BOOL MakeGrad(BOOL bCheck, QRect &rcGrad, float fGrad, int nMaxDistanceFromBaseline, int nMinDistanceFromBaseline =
			0);
	void MakeLimitLabels();
	void RecalculateBaseline();
	void RecalculateBaselineIndent();
	void RecalculateGrads();
	void RecalculateLabels();
	void RecalculateMajorLabelTopleft();
	void RecalculateScaleLimits();
	// Check if any of the limit labels and/or major labels overlap.
	BOOL IsLabelOverlap(int &nWorstOverlap);
	// Reduce the font sizes of the limit labels and major labels until there
	// is no longer any overlap between them or we can't reduce size any further.
	BOOL ReduceLabelSizes(int &nWorstOverlap);
	// Zoom the scale to the specified zero and span, showing these numbers
	// on the scale as the new limits. Use the major grads and minor grads
	// spacing from the data item table.
	void Zoom(float fZero, float fSpan);
	// Cancel zoom mode on the scale. Use the zero and span and major grads
	// and minor grads spacing from the data item table.
	void CancelZoom();
};

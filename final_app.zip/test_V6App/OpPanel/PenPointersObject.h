/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: PenPointersObject.h
/// @n Description: Pen Pointers Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  27  Stability Project 1.24.1.1 7/2/2011 4:59:40 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  26  Stability Project 1.24.1.0 7/1/2011 4:25:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  25  V6 Firmware 1.24 2/3/2006 6:01:16 PM Mark Dennison 
//  Toggle of pen pointers improved, to be regular instead of depending
//  on pen rates
//  24  V6 Firmware 1.23 2/3/2006 4:09:33 PM Mark Dennison 
//  Toggle pen pointers (slowly) so covered ponters are seen eventually
// $
//
// **************************************************************************
#ifndef _PENPOINTERSOBJECT_H
#define _PENPOINTERSOBJECT_H
const int HORZ_LEFT_PENPTR = 0xE005; // horizontal left-facing pen pointer EUDC
const int HORZ_RIGHT_PENPTR = 0xE015; // horizontal right-facing pen pointer EUDC
const int VERT_DOWN_PENPTR = 0xE006; // vertical down-facing pen pointer EUDC
const int VERT_UP_PENPTR = 0xE016; // vertical up-facing pen pointer EUDC
const int MAX_PEN_POINTERS = 32; // max pen pointers in a pen pointers object
const int PENPTR_HEIGHT_LIMIT_FOR_NUMPRINT = 15; // don't show tiny pen numbers
//**Class*********************************************************************
///
/// @brief Pen Pointers Object
/// 
/// This class is a simple standard drawn object for the pen pointers object
/// which is derived from the CBaseObject class.
///
/// NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE!
/// NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE!
///
/// Any CPenPointersObject member variable, including any member variable in
/// any of its base classes, updated by SetBounds or the Recalculate method
/// within it must be saved and restored in method SavePenPointersObjectState
/// and method RestorePenPointersObjectState. This is necessary so methods
/// CalcLinkPositions and CanSetLinkPositions can be treated as "const" methods
/// (i.e., they do not update the internal state of the pen pointers object).
///
//****************************************************************************
class CPenPointersObject: public CBaseObject {
private:
	CDataItemRef *m_pDataItemRef[MAX_PEN_POINTERS];
	///< Data item table references (enabled pens sorted by pen number).
	///< Each pen pointer travels in its own lane in a pen pointers object.
	///< The lanes may overlap one another. For a vertical pen pointers
	///< object, the lowest-numbered pen pointer is in the leftmost lane
	///< and the highest-numbered pen pointer is in the rightmost lane.
	///< For a horizontal pen pointers object, the lowest-numbered pen
	///< pointer is in the bottommost lane and the highest-numbered pen
	///< pointer is in the topmost lane.
	T_PENPTRSOBJECT *m_pCMMpens;	///< Pointer to our CMM configuration
	CFFConversionInfo m_ci[MAX_PEN_POINTERS];
	///< Eng units to pixel conversion for a linear scale or
	///< powers of ten (-2, -1, 0, 1, 2, ...) to pixel conversion for
	///< a logarithmic scale. Note that each pen can have its own scale,
	///< so if pen 1's scale can range from 0 to 100 and pen 2's scale
	///< can range from 0 to 200 and pen 1's value is 50 and pen 2's
	///< value is 100, then both of their pen pointers will be located
	///< at the same position within the pen pointers object.
	float m_fCurrentValue[MAX_PEN_POINTERS]; ///< Current pen value for each pen pointer
	BOOL m_bCurrentAlarm[MAX_PEN_POINTERS]; ///< Alarm flag for each pen pointer 
	T_DATAITEM_STATUS m_eCurrentStatus[MAX_PEN_POINTERS]; ///< Current status for each pen pointer
	COLORREF *m_pForeAlarmColour;  ///< Colour for flashing foreground on pen pointer
	// ***** THE HANDLING OF OUT-OF-RANGE READINGS AND VALID READINGS IS DISCUSSED BELOW *****
	// Assume a pen pointers object shows "n" pen pointers, with the number of underrange pen pointers
	// represented by "ur", and the number of overrange pen pointers represented by "or", and the number
	// of pen pointers with valid readings represented by "vr", where n = ur + or + vr.
	// FIXED SPACING METHOD (used): Allocate "n" travel lanes for the pen pointers with valid readings
	// and allocate "n" positions for the underrange pen pointers and allocate "n" positions for the
	// overrange pen pointers. This is the method used, rather than the following method:
	// MAXIMISED SPACING METHOD (not used): Allocate "vr" travel lanes for the pen pointers with valid
	// readings and allocate "ur" positions for the underrange pen pointers and allocate "or" positions
	// for the overrange pen pointers.
	// To clarify the fixed spacing method and the maximised spacing method further, if the pen pointers
	// object is displaying 8 pen pointers, but only pens 1 and 8 have valid readings, then there will be
	// six unused lanes between pen pointer 1 and pen pointer 8 using the fixed spacing method, but there
	// will be only two (spacious) travel lanes for pen pointer 1 and pen pointer 8 using the maximised
	// spacing method.
	// A horizontal pen pointers object has pen pointers displayed in horizontal lanes. Pen pointers
	// with valid readings are displayed with vertical pen pointer symbols in the "valid reading" lanes.
	// Pen pointers with out-of-range readings are displayed with horizontal pen pointer symbols in the
	// "out-of-range" lanes either at the zero position for underrange readings or at the span position
	// for overrange readings.
	// A vertical pen pointers object has pen pointers displayed in vertical lanes. Pen pointers
	// with valid readings are displayed with horizontal pen pointer symbols in the "valid reading" lanes.
	// Pen pointers with out-of-range readings are displayed with vertical pen pointer symbols in the
	// "out-of-range" lanes either at the zero position for underrange readings or at the span position
	// for overrange readings.
	int m_nValidReadingLaneOffset;	///< Number of pixels offsetting one "valid reading" lane from another
	int m_nOutOfRangeLaneOffset;	///< Number of pixels offsetting one "out-of-range" lane from another
	USHORT m_uTestCase;				///< Last executed test case for debugging purposes
	int m_nNumPens;					///< Number of pen pointers shown in pen pointers object
									///< Equal to the number of enabled pen channels in widget
	int m_nPrevHeight;				///< Force scale indent change on Height property change
	int m_nPenFontHeight;			///< Pen pointer numeric font height in pixels
	int m_nCharCellHeight;			///< Character cell height in pixels
	int m_nCharCellWidth;			///< Character cell width in pixels
	int m_nPenHeight;				///< "Valid reading" pen pointer height in pixels
	int m_nPenWidth;				///< "Valid reading" pen pointer width in pixels
	QPoint m_ptArrowTip;			///< "Valid reading" tip of arrow relative to top-left of character cell
	BOOL m_RotateSources;			///< rotate the pointer sources
	BOOL m_bInAlarm;				///< Is any pen pointer in alarm?
	BOOL m_bInZoom;					///< Are we in zoom mode?
	float m_fZoomZero;				///< New zero limit when in zoom mode (applies to all pens)
	float m_fZoomSpan;				///< New span limit when in zoom mode (applies to all pens)
	int m_nLastLane;				///< MarkD: used to toggle which pointer is on top
	int m_nAlarmsActive;			///< MarkD: also used to control rate of pointer toggle
	LONGLONG m_llPreviousLaneToggle;			///< MarkD: used to set a time between toggles
	int m_nFirstAlarm;				///< MarkD: also used to set a time between toggles
	// Derived objects must draw themselves.
	// Called via the m_pOnDraw pointer to function.
	static void OnDraw(CPenPointersObject *pThis, HDC hdc, QRect *pClipRect);
	void DrawPenPointer(CDC *pDC, int nLane, BOOL DrawInFlashState);
	void Recalculate();
	void RecalculatePenPointerLanes();
	void RecalculateScaleLimits();
	BOOL SavePenPointersObjectState(BYTE *pbySaveBuffer, int nSaveBufferByteSize);
	void RestorePenPointersObjectState();
	void Save(void *pbySrc, int nSrcByteSize);
	void Restore(void *pbyDst, int nDstByteSize);
	BOOL m_bSaveOk;
	BYTE *m_pbySaveBuffer;
	int m_nSaveBufferBytesRemaining;
	static int CompareDataItemRefs(const void *arg1, const void *arg2);
	static int GetPenNumber(CDataItemRef *pDataItemRef);
	int GetPenNumber(int nLane);
	float GetZero(int nLane) // checks zoom mode and returns EU for a linear scale or power of 10 for a log scale
			{
		return m_bInZoom ? m_fZoomZero : m_pDataItemRef[nLane]->m_pDataItem->GetZero();
	}
	float GetSpan(int nLane) // checks zoom mode and returns EU for a linear scale or power of 10 for a log scale
			{
		return m_bInZoom ? m_fZoomSpan : m_pDataItemRef[nLane]->m_pDataItem->GetSpan();
	}
	float GetVisibleLowerEnd(int nLane) {
		return IsScaleReversed(nLane) ? GetSpan(nLane) : GetZero(nLane);
	}
	float GetVisibleUpperEnd(int nLane) {
		return IsScaleReversed(nLane) ? GetZero(nLane) : GetSpan(nLane);
	}
	BOOL IsScaleReversed(int nLane) {
		return m_pDataItemRef[nLane]->m_pDataItem->GetZero() > m_pDataItemRef[nLane]->m_pDataItem->GetSpan();
	}
	void ExecuteTestCase(USHORT uTestCase);	///< Execute a test case identified by number
public:
	//virtual void InitItemProp();
	virtual void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);///< set bounds of the object relative to the CScreen's top left corner.
	CPenPointersObject(CWidget *pWidget);
	// Zoom all scales to the specified zero and span.
	void Zoom(float fZero, float fSpan);
	// Cancel zoom mode on the scales.
	void CancelZoom() {
		m_bInZoom = FALSE;
	}
	void SetRotating();
	// overidden functions that must be supplied
	virtual void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	virtual void ConfigChange();								///< config changes	
	virtual void Destroy();
	virtual LinkOrientation GetLinkOrient();						///< can the Object be linked and if so, which way?
	virtual BOOL CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2);///< calculate the link positions from the object limits
	virtual BOOL CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2);///< baseobject version does not impose any restrictions
};
#endif

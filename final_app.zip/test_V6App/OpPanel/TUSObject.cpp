/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: TUSObject.cpp
/// @n Description: TUS Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 5:02:12 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:39:03 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:51 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:04:06 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include <float.h>
#include "MathUtils.h"
#include "AMS2750TUSMgr.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// Static Initialisation
// shankar fix for 1-12F5AAE - below hardcoded values are now being changed for GR Series. There seems to be no rationale to these numbers
// hence new numbers too would not have rationale, except for the fact they are increased from previous hardcoded values.
//const LONG CTUSObject::m_laCOL_WIDTHS[ 13 ] = { 1, 30, 45, 45, 45, 45, 65, 65, 65, 65, 65, 65, 45 };
const LONG CTUSObject::m_laCOL_WIDTHS[13] = { 1, 45, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70 };
const LONG CTUSObject::m_lWIDTH = CTUSObject::m_laCOL_WIDTHS[0] + CTUSObject::m_laCOL_WIDTHS[1]
		+ CTUSObject::m_laCOL_WIDTHS[2] + CTUSObject::m_laCOL_WIDTHS[3] + CTUSObject::m_laCOL_WIDTHS[4]
		+ CTUSObject::m_laCOL_WIDTHS[5] + CTUSObject::m_laCOL_WIDTHS[6] + CTUSObject::m_laCOL_WIDTHS[7]
		+ CTUSObject::m_laCOL_WIDTHS[8] + CTUSObject::m_laCOL_WIDTHS[9] + CTUSObject::m_laCOL_WIDTHS[10]
		+ CTUSObject::m_laCOL_WIDTHS[11] + CTUSObject::m_laCOL_WIDTHS[12];
//****************************************************************************
///
/// Constructor
///
/// @param[in/out] CWidget *pWidget - Pointer to the parent widget
/// 
//****************************************************************************
CTUSObject::CTUSObject(CWidget *pWidget) : CBaseObject(pWidget), m_crTUSNotStarted(QString(255, 255, 255)), m_crTUSInDetect(
		QString(200, 255, 255)), m_crTUSInInSoak(QString(255, 200, 255)), m_crTUSInInStability(QString(255, 255, 100)), m_crTUSFailed(
		QString(255, 100, 100)), m_crTUSPassed(QString(100, 255, 100)), m_crTUSInactive(QString(227, 227, 227)) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CTUSObject::OnDraw;
	m_crTitleCellBackGndColour = QString(200, 200, 200);
	m_pDataItemRef = NULL;
	m_tSpecialTUSPen.Enabled = TRUE;
	m_tSpecialTUSPen.IndexChan = 0;
	m_tSpecialTUSPen.ItemType = DI_PEN;
	m_tSpecialTUSPen.SubType = DI_PEN_READING;
	m_tSpecialTUSPen.Rotate = FALSE;
	m_tSpecialTUSPen.Updates = TRUE;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Required size and position for a new Object
///
/// @return none
/// 
//****************************************************************************
void CTUSObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CTabularDisplayObject data in CMM info block.
	m_pCMMTUS = (T_TUSOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		// set these flags for specific Object (e.g. may be advanced draw only)
		/*
		 m_pCMMbase->IsAdvancedDraw
		 m_pCMMbase->IsPermanent
		 m_pCMMbase->IsB#include "BitmapObj.h"ackground
		 m_pCMMbase->IsPrimaryDirect
		 // etc...
		 */
		m_pCMMbase->IsBuffered = TRUE;
	} else {
		// When loading a previous configuration:
	}
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CTUSObject::ConfigChange() {
	// Data item configuration done here. 
	if (!m_pDataItemRef) {
		// for text objects, only create a reference if required
		m_pDataItemRef = new CDataItemRef(this); // create our single reference
	}
	if ((m_pDataItemRef != NULL) && (m_pWidget->GetDataItem(m_pDataItemRef, &m_tSpecialTUSPen))) {
		// set the data item ref to be updated also
		m_pDataItemRef->Updates = TRUE;
	}
	// Set our members based on CMM settings and data item info
	// T_BASEOBJECT CMM config to CBaseObject members:
	if (m_pCMMbase->FixForeColour) {
		// Use foreground colour from CMM (e.g. as selected in Screen Designer).
		m_pForeColour = &m_pCMMbase->ForeColour;
	} else if (m_pCMMbase->AttrBlocks.ForeColourBlk) {
		// Use foreground colour from Attribute block.
		m_pForeColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
	} else {
		// set the forecolour to the cmm base object colour as we have to make the time appear and that isn't
		// pen related
		m_pForeColour = &m_pCMMbase->ForeColour;
	}
	if (m_pCMMbase->FixBackColour) {
		// Use background colour from CMM (e.g. as selected in Screen Designer).
		m_pBackColour = &m_pCMMbase->BackColour;
	} else if (m_pCMMbase->AttrBlocks.BackColourBlk) {
		// Use background colour from Attribute block.
		m_pBackColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
	}
	// Use visible attribute from Attribute block if set (1=default=TRUE).
	m_pVisible = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
}	//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CTUSObject::OnDraw(CTUSObject *pThis, HDC hdc, QRect *pClipRect) {
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	// if Update Required make any updates due to data item changes/flashing then do a repaint
	if (pThis->m_UpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object.
		if (pThis->m_UpdateValue) {
			pThis->m_UpdateValue = FALSE;
		}
		// also handle any flashing updates here even though they aren't currently used at the moment
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	}
	// Draw border if required - shouldn't happen with our canned screens
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered)) {
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	}
	// Update the current clipping region. This handling will prevent
	// anything from being drawn outside the pen pointers object.
	pThis->m_pWidget->SetClipRect(hdc, &pThis->m_ClientRect);
	CDC *pDC = CDC::FromHandle(hdc);
	int nOldBkMode = pDC->GetBkMode();
	int nOldBkColour = pDC->GetBkColor();
	COLORREF crOldTextColour = pDC->GetTextColor();
	if (!pThis->m_pCMMbase->IsTransparent) {
		// Create a brush for background
		HBRUSH hBrushback = CreateSolidBrush(*pThis->m_pBackColour);
		FillRect(hdc, &pThis->m_ClientRect, hBrushback);
		// Delete the brush object and free all resources associated with it.
		DeleteObject(hBrushback);
	}
// Get the font for the required pen pointer size.
	CFontCache *pkFontCache = CFontCache::GetHandle();
	int iYOffset = 0;
	QFont hFont = pkFontCache->GetNumericFont(8, &iYOffset);
	QFont hOldFont = (QFont) pDC->SelectObject(hFont);
#ifndef DOCVIEW	
	QRect tSTATUS_RECT = pThis->m_ClientRect;
	// for each set point we need to draw a row of information - do the titles first
	const LONG lCELL_HEIGHT = (((tSTATUS_RECT.bottom - tSTATUS_RECT.top) - 1) / ( FURNACESCONFIG_SETPOINTS_SIZE + 1));
	const LONG lHALF_CELL_HEIGHT = lCELL_HEIGHT / 2;
	QRect tCellRect = { tSTATUS_RECT.left, tSTATUS_RECT.top + 1, tSTATUS_RECT.left + m_laCOL_WIDTHS[1], tSTATUS_RECT.top
			+ lCELL_HEIGHT + 1 };
	QRect tInnerCellRect;
	QString strText("");
	CGeneralSetupConfig *pkGenSetupCfg = pSETUP->GetGeneralSetupConfig();
	T_PFURNACESCONFIG ptFurnaces = pkGenSetupCfg->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
	// get the display temerpature units
	QString strTempUnits("");
	switch ( pSYSTEM_INFO->GetDisplayTempUnits()) {
	case TEMP_DEG_C:
		strTempUnits = L"C";
		break;
	case TEMP_DEG_F:
		strTempUnits = L"F";
		break;
	case TEMP_KELVIN:
		strTempUnits = L"K";
		break;
	default:
		strTempUnits = L"ERR";
		break;
	}
	QString strMinutes("");
	strMinutes = tr("Mins.");
	CAMS2750TUSMgr *pkTUSStatusMgr = CAMS2750TUSMgr::Instance();
	for (int iSetPointCount = -1; iSetPointCount < FURNACESCONFIG_SETPOINTS_SIZE; iSetPointCount++) {
		// check if this is the first row in which case we must do the titles
		if (iSetPointCount == -1) {
			// set point no title - leave empty
			HBRUSH hTitleCellBackGndBrush = CreateSolidBrush(pThis->m_crTitleCellBackGndColour);
			tCellRect.setleft(tSTATUS_RECT).left + m_laCOL_WIDTHS[0];
			tCellRect.setright(tCellRect).left + m_laCOL_WIDTHS[1];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			// fill in the cell background for the title cells
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			// set the correct text colour	
			pDC->SetTextColor(QString(0, 0, 0));
			pDC->SetBkMode(TRANSPARENT);
			strText = "";
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK /*| DT_VCENTER */);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[2];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Setpoint (Tol.)");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK /*| DT_VCENTER */);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[3];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Status");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[4];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Max Sensor");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[5];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Min Sensor");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[6];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Max Sensor Diff");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[7];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Max Sensor SP Diff");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[8];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Max Ramp Overshoot");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[9];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Ramp duration");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[10];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Sensor Lag into Soak");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[11];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Stable Soak Duration");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[12];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hTitleCellBackGndBrush);
			strText = tr("Meets Class");
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			DeleteObject(hTitleCellBackGndBrush);
		} else {
			HBRUSH hCellBackGndBrush = NULL;
			QString strStatus("");
			// this is the set point information
			switch (pkTUSStatusMgr->GetSPStatus(iSetPointCount)) {
			case SOAK_STATUS_NOTSTARTED:
				hCellBackGndBrush = CreateSolidBrush(pThis->m_crTUSNotStarted);
				strStatus = "";
				break;
			case SOAK_STATUS_SOAK_DETECT:
				strStatus = tr("Detect");
				hCellBackGndBrush = CreateSolidBrush(pThis->m_crTUSInDetect);
				break;
			case SOAK_STATUS_IN_SOAK:
				strStatus = tr("Soak");
				hCellBackGndBrush = CreateSolidBrush(pThis->m_crTUSInInSoak);
				break;
			case SOAK_STATUS_IN_STABILITY:
				strStatus = tr("Stable");
				hCellBackGndBrush = CreateSolidBrush(pThis->m_crTUSInInStability);
				break;
			case SOAK_STATUS_PASSED:
				strStatus = tr("Done");
				hCellBackGndBrush = CreateSolidBrush(pThis->m_crTUSPassed);
				break;
			case SOAK_STATUS_FAILED:
				strStatus = tr("Failed");
				hCellBackGndBrush = CreateSolidBrush(pThis->m_crTUSFailed);
				break;
			case SOAK_STATUS_NOTENABLED:
			default:
				strStatus = "";
				hCellBackGndBrush = CreateSolidBrush(pThis->m_crTUSInactive);
				break;
			}
			tCellRect.setleft(tSTATUS_RECT).left + m_laCOL_WIDTHS[0];
			tCellRect.setright(tCellRect).left + m_laCOL_WIDTHS[1];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			strText = QString::asprintf("%u", iSetPointCount + 1);
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[2];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%0.2f%s (+/-%0.1f)",
				pSYSTEM_INFO->GetLocalTempFromDegC(ptFurnaces->Setpoints[iSetPointCount].Level), strTempUnits,
						pkTUSStatusMgr->GetSoakTolerance(iSetPointCount));
			} else {
				strText = tr("NA");
			}
			DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			// now do the setpoint test status
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[3];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				DrawText(hdc, strStatus, strStatus.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the max TC naem and value
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[4];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(lHALF_CELL_HEIGHT);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			QString strMaxTC(pkTUSStatusMgr->GetSPMaxTCName(iSetPointCount));
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				DrawText(hdc, strMaxTC, strMaxTC.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setTop(lHALF_CELL_HEIGHT);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			const float fMAX_TC_VAL = pkTUSStatusMgr->GetSPMaxTCValue(iSetPointCount);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%0.2f%s", fMAX_TC_VAL, strTempUnits);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the min TC and value
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[5];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(lHALF_CELL_HEIGHT);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			QString strMinTC(pkTUSStatusMgr->GetSPMinTCName(iSetPointCount));
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				DrawText(hdc, strMinTC, strMinTC.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setTop(lHALF_CELL_HEIGHT);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			const float fMIN_TC_VAL = pkTUSStatusMgr->GetSPMinTCValue(iSetPointCount);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%0.2f%s", fMIN_TC_VAL, strTempUnits);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the max/min TC diff names and value
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[6];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(lHALF_CELL_HEIGHT);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%s - %s", strMaxTC, strMinTC);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setTop(lHALF_CELL_HEIGHT);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			const float fMAX_MIN_TC_DIFF_VAL = fMAX_TC_VAL - fMIN_TC_VAL;
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%0.2f%s", fMAX_MIN_TC_DIFF_VAL, strTempUnits);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the max TC to setpoint diff names and value
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[7];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(lHALF_CELL_HEIGHT);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = pkTUSStatusMgr->GetSPMaxTCDiffWrtSPName(iSetPointCount);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setTop(lHALF_CELL_HEIGHT);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%0.2f%s", pkTUSStatusMgr->GetSPMaxTCDiffWrtSPValue(iSetPointCount),
						strTempUnits);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the max ramp overshoot names and value
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[8];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(lHALF_CELL_HEIGHT);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = pkTUSStatusMgr->GetSPMaxRampOvershootTCName(iSetPointCount);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setTop(lHALF_CELL_HEIGHT);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%0.2f%s", pkTUSStatusMgr->GetSPMaxRampOvershootTCValue(iSetPointCount),
						strTempUnits);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the ramp duration
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[9];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%s",
						CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
								static_cast<LONGLONG>(pkTUSStatusMgr->GetSPRampDuration(iSetPointCount)), true));
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the TC lag duration
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[10];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%s",
						CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
								static_cast<LONGLONG>(pkTUSStatusMgr->GetSPTCLagIntoSoak(iSetPointCount)), true));
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the soak duration
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[11];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%u %s", pkTUSStatusMgr->GetSPMaxTCSoakDuration(iSetPointCount),
						strMinutes);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			// now do the class met
			tCellRect.setleft(tCellRect).right;
			tCellRect.setRight(m_laCOL_WIDTHS)[12];
			tInnerCellRect = tCellRect;
			tInnerCellRect.setRight(1);
			tInnerCellRect.setBottom(1);
			FillRect(hdc, &tInnerCellRect, hCellBackGndBrush);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strText = QString::asprintf("%s", pkTUSStatusMgr->GetSPFurnaceClassMet(iSetPointCount), strMinutes);
				DrawText(hdc, strText, strText.size(), &tInnerCellRect, DT_CENTER | DT_WORDBREAK);
			}
			DeleteObject(hCellBackGndBrush);
		}
		// move onto the next line
		tCellRect.setTop(lCELL_HEIGHT);
		tCellRect.setBottom(lCELL_HEIGHT);
	}
#endif
	pDC->SelectObject(hOldFont);
	pkFontCache->ReleaseFont(hFont);
	// Restore GDI objects after drawing pen pointers.
	pDC->SetBkMode(nOldBkMode);
	pDC->SetBkColor(nOldBkColour);
	pDC->SetTextColor(crOldTextColour);
	// Restore clipping region 
	pThis->m_pWidget->RestoreClipping(hdc);
}
//****************************************************************************
///
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CTUSObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	CBaseObject::SetBounds(bounds, pPos1, pPos2); // call the base Object version
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CTUSObject::Destroy() {
}
//****************************************************************************
/// 
/// Accessor method that indicates the TUS display object needs updating
///
/// @return true if an update is required because the TUS information have been changed
/// 
//****************************************************************************
const bool CTUSObject::DisplayUpdateRequired() const {
#ifndef DOCVIEW
	CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
	return (pkTUSMgr->IsUpdateRequired() == TRUE);
#else
	return false;
#endif
}
//****************************************************************************
/// 
/// Method that resets the flag that indicates the TUS display object needs updating - usually reset after 
/// the update flag for the object has been set
/// 
//****************************************************************************
void CTUSObject::ResetDisplayUpdateFlag() {
#ifndef DOCVIEW
	CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
	pkTUSMgr->SetUpdateRequired( FALSE);
#endif
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: Utilities.h 
/// @n Description: Utility functions for OpPanel
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4}:
//  8  V6 Firmware1.7 02/12/2004 11:25:33  Jason Parker  Sort
//  out CURSOR_ON CURSOR_OFF macros
//  7  V6 Firmware1.6 09/11/2004 16:39:26  Jason Parker  More
//  colour Macro's
//  6  V6 Firmware1.5 27/10/2004 17:08:20  Jason Parker  latest
//  framework updates
//  5  V6 Firmware1.4 22/10/2004 08:14:25  Jason Parker  Latest
//  additions to framework
//  4  V6 Firmware1.3 13/10/2004 10:24:45  Jason Parker  Updated
//  framework
//  3  V6 Firmware1.2 01/10/2004 16:08:53  Jason Parker  Updated
//  as part of OpPanel Framework
//  2  V6 Firmware1.1 22/09/2004 16:43:05  Jason Parker  updated
//  1  V6 Firmware1.0 21/09/2004 17:24:01  Jason Parker  
// $
// 
// **************************************************************************
#ifndef _UTILITIES_H
#define _UTILITIES_H
#include <QFont>
#include "Widget.h"
#include "Defines.h"
#include "CStorage.h"
#include "StoragePaths.h"
#include "hw_defs.h"
#include "V6Config.h"
#include "CMMDefines.h"
// macro similar to RGB macro, but for 16-bit 565 display
//#define RGB565(r, g, b) ((r >> 3) << 11)| ((g >> 2) << 5)| ((b >> 3) << 0)
// more accurate conversion.
#define RGB565(r, g, b)  ((((USHORT)(r*31.0/255.0+0.5))<<11)| (((USHORT)(g*63.0/255.0+0.5))<<5)|((USHORT)(b*31.0/255.0+0.5)))
// macro to convert RGB to RGB565
//#define RGBtoRGB565(rgb) ((GetRValue(rgb) >> 3) << 11)| ((GetGValue(rgb) >> 2) << 5)| ((GetBValue(rgb) >> 3) << 0)
// more accurate colour matching
#define RGBtoRGB565(rgb)  ((((USHORT)(GetRValue(rgb)*31.0/255.0+0.5))<<11)| (((USHORT)(GetGValue(rgb)*63.0/255.0+0.5))<<5)|(((USHORT)(GetBValue(rgb)*31.0/255.0+0.5))<< 0))
// macros to extract red, green and blue components from RGB565
#define GetR_565(rgb) (rgb >> 11)
#define GetG_565(rgb) ((rgb >> 5) & 0x003F)
#define GetB_565(rgb) (rgb & 0x001F)
// here define RGB888 for 32bit pixel format (reverse of RGB macro!)
#define RGB888(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
//#define RGB565toRGB(rgb) RGB(GetR_565(rgb)<<3 ,GetG_565(rgb)<<2,GetB_565(rgb)<<3) not as accurate as below
// more accurate colour matching
#define RGB565toRGB(rgb)	RGB( (USHORT)(GetR_565(rgb)*255.0/31.0+0.5), (USHORT)(GetG_565(rgb)*255.0/63.0+0.5), (USHORT)(GetB_565(rgb)*255.0/31.0+0.5))
#define RGB565toRGB888(rgb) RGB888( (USHORT)(GetR_565(rgb)*255.0/31.0+0.5), (USHORT)(GetG_565(rgb)*255.0/63.0+0.5), (USHORT)(GetB_565(rgb)*255.0/31.0+0.5))
#define RGBtoRGB888(rgb)	RGB888(GetRValue(rgb),GetGValue(rgb),GetBValue(rgb))
extern int Glb_BitsPerPixel; // set by OpPanel
#ifdef UNDER_CE
	#define AlphaBlend AlphaBlend16
	#define TransAlphaBlend TransAlphaBlend16
	#define FILLCOLOUR(x) x				///< 16-bit colour required - no conversion
	#define FILLCOLOURFROMRGB(x) RGBtoRGB565(x) // convert form RGB to RGB565
#else
#define AlphaBlend ChooseAlphaBlend
#define TransAlphaBlend ChooseTransAlphaBlend
#define FILLCOLOUR(x) Fillcolour(x)	
#define FILLCOLOURFROMRGB(x) Fillcolourfromrgb(x)
#endif
#include "Defines.h"
typedef USHORT Colour; // work with 16-bit 565 colours when possible for speed on recorder
					 // this type does not change for the desktop. (still 16-bit)
#define _Height(rect) (rect.bottom-rect.top)
#define _Width(rect) (rect.right-rect.left)
extern int Glb_MouseOn; // set by OpPanel
#ifdef UNDER_CE
#define CURSOR_ON if(Glb_MouseOn) SetCursor(::LoadCursorW(NULL, IDC_ARROW)) // enable cursor
#define CURSOR_OFF SetCursor(NULL) // disable cursor
#else
#define CURSOR_ON
#define CURSOR_OFF
#endif
#define GRABSIZE 4
#define LOADED_INSTANCE FALSE
#define NEW_INSTANCE	TRUE
enum ResizeType {
	ResizeNone, Topleft, Topmiddle, Topright, rightmiddle, Bottomright, Bottommiddle, Bottomleft, leftmiddle,
};
/// Enumerated types for the various border styles
enum T_BORDER_STYLE {
	bsFLAT, bsRAISED, bsINSET
};
const int OBJECT_HORIZONTAL = 0;
const int OBJECT_VERTICAL = 1;
class CFFConversionInfo;
//****************************************************************************
///
/// @brief Utility functions for Op Panel
/// 
/// These functions are general purpose and may be used throughout the Op Panel 
///
//****************************************************************************
void DrawHandles(HDC hdc, QRect &bounds, COLORREF colour);
BOOL HitTestHandles(QRect &bounds, ResizeType &resizeState, QPoint &point);
void DrawBorder(HDC hdc, QRect bounds, T_BORDER *border);
DWORD Fillcolour(USHORT x);
DWORD Fillcolourfromrgb(COLORREF x);
COLORREF ColourAdjust(COLORREF colour, int adjust);
void DropShadow(HDC hDC, QRect *boxrect, QRect *cliprect);
//void ClipCursor(QRect &bounds, ResizeType resizeState);
//E47415 
void TransAlphaBlend16(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height, WORD colourkey);
//E47415 
void TransAlphaBlend32(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height, DWORD colourkey);
//E47415 
void ChooseTransAlphaBlend(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height, DWORD colourKey);
//E47415 
void AlphaBlend16(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX, int srcY,
		int width, int height);
//E47415 
void AlphaBlend32(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX, int srcY,
		int width, int height);
//E47415 
void ChooseAlphaBlend(LPDIRECTDRAWSURFACE pDestSurf, LPDIRECTDRAWSURFACE pSrcSurf, int destX, int destY, int srcX,
		int srcY, int width, int height);
//E47415 
//IDirectDrawPalette * DDLoadPalette(HINSTANCE hInstance, IDirectDraw4 * pdd, LPCTSTR szBitmap);
IDirectDrawPalette* DDLoadPalette(HINSTANCE hInstance, IDirectDraw *pdd, LPCTSTR szBitmap);
//E47415 
//IDirectDrawSurface4 * DDLoadBitmap(HINSTANCE hInstance, IDirectDraw4 * pdd, LPCTSTR szBitmap);
IDirectDrawSurface* DDLoadBitmap(HINSTANCE hInstance, IDirectDraw *pdd, LPCTSTR szBitmap);
QImage DDGetBitmapHandle(HINSTANCE hInstance, LPCTSTR szBitmap);
HRESULT DDReLoadBitmap(HINSTANCE hInstance, IDirectDrawSurface *pdds, LPCTSTR szBitmap);
//E437415
//HRESULT DDCopyBitmap(IDirectDrawSurface4 * pdds, QImage hbm, int x, int y, int dx, int dy);
//DWORD  DDColorMatch(IDirectDrawSurface4 * pdds, COLORREF rgb);
//HRESULT DDSetColorKey(IDirectDrawSurface4 * pdds, COLORREF rgb);
//HRESULT DDSetColorKey2(IDirectDrawSurface4 * pdds, COLORREF rgb);
HRESULT DDCopyBitmap(IDirectDrawSurface *pdds, QImage hbm, int x, int y, int dx, int dy);
DWORD DDColorMatch(IDirectDrawSurface *pdds, COLORREF rgb);
HRESULT DDSetColorKey(IDirectDrawSurface *pdds, COLORREF rgb);
HRESULT DDSetColorKey2(IDirectDrawSurface *pdds, COLORREF rgb);
#ifndef UNDER_CE // remove form target build 
BITMAPINFOHEADER* LoadDIBFromFile(QString filename);
//E437415
//HRESULT LoadBitmapToSurf(IDirectDrawSurface4 * pdds, QString filename, QRect rect);
HRESULT LoadBitmapToSurf(IDirectDrawSurface *pdds, QString filename, QRect rect);
BOOL ImportBitmap();
#endif
//**Class*********************************************************************
///
/// @brief Dib class
/// 
///	This class provides a wrapper for Device Independent Bitmaps
///
//****************************************************************************
// Dib Header Marker - used in reading/writing DIBs to files
#define DIB_HEADER_MARKER  ((WORD) ('M' << 8) | 'B')
#define IS_WIN30_DIB(lpbi) ((*(LPDWORD)(lpbi)) == sizeof(BITMAPINFOHEADER))
/* Macro to determine the bytes in a DWORD aligned DIB scanline */
#define BYTESPERLINE(Width, BPP) ((WORD)((((DWORD)(Width)*(DWORD)(BPP) + 31) >> 5)) << 2) 
#define BITMAP_VISIBLE_NAME_LENGTH	30
// BITMAPINFO struct plus the colour masks for 16 bit 565
typedef struct tagBITMAPINFO2 {
	BITMAPINFOHEADER bmiHeader;
	DWORD redMask;
	DWORD greenMask;
	DWORD blueMask;
} BITMAPINFO2;
// these headers will preceed the DIB's in the bitmap collection file.
struct BCF_FILE_HEADER {
	LONGLONG UniqueID;
	WCHAR Name[BITMAP_VISIBLE_NAME_LENGTH]; // human readable name for image (defaults to filename of original bmp)
	int dibSizebytes;
};
// only individual bitmaps will be read into memory - there will not be the need for storing a large number in memory
// class for handling an X series DIB within memory
class CDib {
private:
	BCF_FILE_HEADER m_bfh;			// id, name and bytes size info
	BITMAPINFOHEADER *m_pBInfoH;	// pointer to global alloc'd mem of header and colour table and bitmapbits
	UINT m_bitsoffset;				// offset from m_pBInfoH to the data bits of the bitmap
	void Init();
public:
	CDib();
	CDib(QString pfilename);
	CDib(QFile *pBCFile, BCF_FILE_HEADER *bfhdr);
	CDib(CDib *pDIB, UINT bitDepth, UINT width, UINT height);
	~CDib();
	//E437415
	//BOOL LoadToSurface(IDirectDrawSurface4 * pdds, QRect rect);
	BOOL LoadToSurface(IDirectDrawSurface *pdds, QRect rect);
	BYTE* GetpBInfo() {
		return ((BYTE*) m_pBInfoH);
	}
	BYTE* GetpColourTbl() {
		return ((BYTE*) m_pBInfoH) + m_pBInfoH->biSize;
	}
	BYTE* GetpBits() {
		return ((BYTE*) m_pBInfoH) + m_bitsoffset;
	}
	UINT GetFullSizeBytes() {
		return m_bfh.dibSizebytes;
	}
	BCF_FILE_HEADER* GetBCFHeader() {
		return &m_bfh;
	}
	UINT GetBitDepth() {
		return m_pBInfoH->biBitCount;
	}
	QRect GetDimensions() {
		QRect temp = { 0, 0, m_pBInfoH->biWidth, m_pBInfoH->biHeight };
		return temp;
	}
};
//**Class*********************************************************************
///
/// @brief Bitmap Collection File 
/// 
/// This class is used to mantain and manage Bitmap Collection Files
///
//****************************************************************************
// class to represent a bitmap collection file
class CBitmapCollectionFile {
private:
	QFile m_file;
	BOOL m_IsValid;
public:
	enum Mode {
		ReadOnly, WriteOnly, ReadOnlyWrite
	};
	CBitmapCollectionFile(QString pfilename, Mode readwrite);
	~CBitmapCollectionFile();
	// operations
	BOOL AddDib(CDib **pDIB, T_DEV_TYPE BCFtype, int reqWidth = 0, int reqHeight = 0); // BCFtype determines screen size.
	BOOL DeleteDib(LONGLONG UniqueID);
	CDib* LoadDib(LONGLONG UniqueID);
	CDib* GetFirstDib();
	CDib* GetNextDib();
	CDib* GetnthDib(int index);
	static void BuildFilename(QString PathAndFileName);
	void UpdateCollection(CBitmapCollectionFile *pSource, T_DEV_TYPE BCFtype);
	void AddToCollection(CDib **ppSourceDib, T_DEV_TYPE BCFtype, int reqWidth = 0, int reqHeight = 0); // BCFtype determines screen size.
};
void TimeToString(CTVtime *ptime, QString buff1, QString buff2, BOOL seeFracs = FALSE);
void TimeSpanToStringHM(CTVtime *ptime, QString buff);
void Span100ToHMSF(LONGLONG time100, QString buff, BOOL seeSecs = FALSE, BOOL seeFracs = FALSE);
COLORREF GetColour(int num);
//**Class*********************************************************************
///
/// @brief Font Cache
/// 
/// This class is a font Cache and is implemented as a singleton 
///
//****************************************************************************
class CFontCache {
private:
	struct FontEntry {
		QFont fontHandle;		///< Font handle
		int usageCount;			///< count to give hint to usage amount
		BOOL isNumeric;			///< Numeric use only (font is sized so that digits fill the height requested)
		short inUse;			///< actually being used at this moment in time (cannot be deleted)
		short requiredHeight;	///< Height requested by client
		short yOffset;			///< yOffset to be subtracted from required 'Top' for drawing Numeric text only
		short weight;			///< bold / normal etc
		BYTE quality;			///< default / antialiased etc
		BYTE face;				///< 0=Arial, 1=Times New Roman, 2=Courier New, 3=Tahoma
		BYTE anticlk;			///< 0= clockwise or 2700 1= anti-clockwise or 900
	};
#define FONT_CACHE_SIZE 20
	FontEntry m_fontCache[FONT_CACHE_SIZE]; ///< font cache array
	// private construction / destruction
	CFontCache();
	~CFontCache();
	CFontCache(const CFontCache&);
	CFontCache& operator=(const CFontCache&) {
		return *this;
	}
	;
	static CFontCache *m_pFontCacheInstance; ///< static pointer to single instance of class
	// internal functions
	void InitFontEntry(int index);
	void DecUsageCounts();
public:
	/// Enumerated variables indicating the required weight of a font
	enum T_FONT_WEIGHT {
		fwNormal, fwMedium, fwSemiBold, fwBold
	};
	/// Enumerated variables indicating the required quality of a font
	enum T_FONT_QUALITY {
		fqDefault, fqAntialiased, fqClearType
	};
	HDC m_fontHdc;							///< Device context handle for extracting metrics for numeric fonts
	//Singleton 
	static CFontCache* GetHandle(); // acquire a copy of the pointer to the single instance
	void CleanUp();
	QFont GetNumericFont(int RequiredHeight, int *pYoffset); // Numeric font for digitals etc
	QFont GetNumericFont1(float RequiredHeight, int *pYoffset); ////Aditya: Created one more function to take float values //1-YVI2O0
	// general font for any alpha numeric text	
	QFont GetFont(int RequiredHeight, int Weight = QFont::Normal, int Face = 0, int Quality = DEFAULT_QUALITY,
			BOOL anticlk = FALSE); //Face = 0 (Arial)
	void ReleaseFont(QFont FontHandle);	 // must be called after either GetFont call.
	// Method that converts the CMM font weights to an actual weight
	int ConvertFontWeight(const T_FONT_WEIGHT eFONT_WEIGHT) const;
	// Method that converts the CMM font quality to a windows quality
	int ConvertFontQuality(const T_FONT_QUALITY eFONT_QUALITY) const;
};
//**Class*********************************************************************
///
/// @brief Scale Graduations 
/// 
/// This class produces scale graduations for use on the chart etc.
///
//****************************************************************************
#define MAXGRADS 300
class CGrads {
	T_SCALEINFO *m_pScaleInfo;
	BOOL m_IsZoomed;
	float m_Zero;
	float m_Span;
	float m_ZoomZero;
	float m_ZoomSpan;
	int m_majorCount;
	// array of flags indicating if this is actually some kind of boundary line which requires a different pen colour when plotted - major grads only
	bool m_abBoundaryLine[MAXGRADS];
	BOOL AddMajor(int npixel);
	BOOL AddMinor(int nPixel);
	BOOL AddMajorBoundaryLine(int npixel);
	float GetFirstMajorGrad();
	float GetFirstMinorGrad(int &nDecade, int &nDiv);
public:
	int m_count;
	short m_Array[MAXGRADS];
	CGrads();
	void SetZoomed(BOOL isZoomed, float zoomZero, float zoomSpan);
	int CalcScale(T_SCALEINFO *pScaleInfo, CFFConversionInfo *ci, const float fBOUNDARY_LINE1 = FLT_MAX,
			const float fBOUNDARY_LINE2 = FLT_MAX, const float fSETPOINT_LINE = FLT_MAX);
	// Accessor for the boundary line flag
	const bool IsBoundaryLine(const int iGRAD_NO) const {
		return m_abBoundaryLine[iGRAD_NO];
	}
};
class CMemoryScreenBlock {
public:		//Singleton 
	static CMemoryScreenBlock* GetHandle();
	void CleanUp();
private:	// Singleton
	CMemoryScreenBlock() {
		m_numinstances = 0;
	}
	;
	~CMemoryScreenBlock() {
	}
	;	// Will never be called
	CMemoryScreenBlock(const CMemoryScreenBlock&);
	CMemoryScreenBlock& operator=(const CMemoryScreenBlock&) {
		return *this;
	}
	;
	static CMemoryScreenBlock *m_pMemoryScreens;
	T_SCREEN *m_ptrs[20][2];
	USHORT m_instances[20];
	USHORT m_numinstances;
public:
	void Reset();
	T_SCREEN* GetMemoryScreenBlock(USHORT instance, REFERENCE mode);
};
class CSimpleLog {
private:
	WCHAR m_filePathAndFileName[MAX_PATH];
	CStorage m_Storage;
	T_STORAGE_DEVICE m_Location;
	BOOL m_logOn;
public:
	CSimpleLog(T_STORAGE_DEVICE location = IDS_INTERNAL_SD);
	~CSimpleLog();
	BOOL LogLine(QString pMessage);
	BOOL Log(QString pszasprintf, ...);
	BOOL SetLogging(QString pName, BOOL NoTruncate = FALSE);
	void SetLoggingOff();
	int ReadLine(QString buff, int buffsize);
	BOOL DeleteLogFile();
};
// Method that captures and saves a screenshot
void CaptureBitmap(CWidget *pkWnd, const QString &rstrFileName, const bool bSHOW_ERRORS = false);
#ifdef UNDER_CE
HRESULT SaveImageToFile(QImage handle, QString filename, LPCTSTR format);
QImage GetScreenHBITMAP(CWidget *pkWnd);
#endif
#endif

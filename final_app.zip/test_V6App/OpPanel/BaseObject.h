/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: BaseObject.h 
/// @n Description: Base Object class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  48  Stability Project 1.45.1.1 7/2/2011 4:55:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  47  Stability Project 1.45.1.0 7/1/2011 4:25:51 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  46  V6 Firmware 1.45 10/20/2008 4:46:09 PM  Vivek (HAIL)  
//  Issue: Show scales, orientation, cycle scales and scale indicator
//  appear on the QX/QXe AMS2750 Process screen menu even though they
//  have no effect.
//  45  V6 Firmware 1.44 9/23/2008 3:09:20 PM  Build Machine 
//  AMS2750 Merge
// $
//
// **************************************************************************
#ifndef _BASEOBJECT_H
#define _BASEOBJECT_H
enum LinkOrientation {
	LINK_NONE, LINK_HORIZONTAL, LINK_VERTICAL
};
enum LinkError // LinkTo errors
{
	LINK_ERROR_NONE,					///< Object passed to LinkTo was successfully linked in
	LINK_ERROR_ALREADY_LINKED,			///< Object passed to LinkTo is already linked
	LINK_ERROR_CANNOT_LINK,				///< Object passed to LinkTo does not support linking
	LINK_ERROR_SAME_OBJECT,				///< Object passed to LinkTo is the same object
	LINK_ERROR_BETWEEN_WIDGETS,			///< Object passed to LinkTo not in same widget
	LINK_ERROR_WRONG_ORIENTATION,		///< Object passed to LinkTo has wrong orientation (horiz/vert)
	LINK_ERROR_CANNOT_SET_LINK_LIMITS	///< Link limits could not be set (SetLinkLimits returned an error)
};
#include "LayoutItem.h"
#include "ScrnDesCfgMgr.h"
//**Class*********************************************************************
///
/// @brief Abstract Base Object
/// 
/// This class provides a base Object which is to be used as the base for all 
/// derived Objects contained within Widgets within the Op Panel.
///
//****************************************************************************
class CBaseObject: public CLayoutItem {
private:
	static void OnDraw(CBaseObject *pThis, HDC hdc, QRect *pClipRect); ///< derived classes will override this function.
public:
	void InitBaseProp();		///<Init BaseObject part of the derived object
	// Accessor
	CWidget* GetWidget() {
		return m_pWidget;
	}
	//BOOL isObjectOverlapped();
	CWidget *m_pWidget;				///< pointer to parent Widget
	T_BASEOBJECT *m_pCMMbase;		///< pointer to T_BASEOBJECT struct in CMM
	CBaseObject *m_pNextObj;		///< Used by parent Widget to form a linked list
	CBaseObject *m_pLinked;			///< pointer to a Linked Object,for passing resize parameters
	BOOL m_Originator;
	COLORREF *m_pForeColour;		///< pointer to foreground colour to use (fixed/data item/attribute block)
	COLORREF *m_pBackColour;		///< pointer to background colour to use (fixed/data item/attribute block)
	BOOL *m_pFlashing;				///< pointer to Objects flashing state in specified attribute block 
	BOOL *m_pVisible;				///< pointer to Objects visible state in specified attribute block 
	BOOL m_UpdateRequired;			///< set when one or both of the flags below are set.
	BOOL m_UpdateValue;				///< set when Data Items have changed and an update is required
	BOOL m_UpdateRotate;
	BOOL m_UpdateFlash;				///< set when Flash ready an update is required
	BOOL m_FlashState;				///< toggled between TRUE (flash state draw) and FALSE (normal state draw)
	ULONG m_LastFlashUpdate100;		///< time of last flash (process ticks 100ths)
	BOOL m_ShowHandles;				///< set when Object is selected in designer mode. ('grab handles' displayed)
	ResizeType m_ResizeState;		///< set to indicate which 'grab handle' is being adjusted (if any)
	QRect m_ClientRect;				///< Size of client area (bounds less border width)
	//E437415
	//LPDIRECTDRAWSURFACE4 m_pDDSurf;	///< pointer to Objects private surface (if implemented)
	LPDIRECTDRAWSURFACE m_pDDSurf;	///< pointer to Objects private surface (if implemented)
	Colour m_ColourKey;				///< colourKey for Transparent Operations (otherwise -1)
	void (*m_pOnDraw)(void*, HDC, QRect*);		///< function pointer for speed when calling OnDraw
	CBaseObject(CWidget *pParentWidget);	///< constructor	
	~CBaseObject();							///< destructor
	void CMMInitBase(BLOCK_INFO *CMMinfo);	///< One time Initialisation called for BaseObject.
	QRect GetBoundsRelative();				///< returns bounds of the object relative to the Widget's top left corner.
	void SetBoundsRelative(QRect *bounds);	///< set the bounds of the object relative to the Widget's top left corner.
	virtual QRect GetBounds();				///< returns bounds of the object relative to the CScreen's top left corner.
	QRect GetBoundsActual();					///< returns bounds of the object with no offsets
	virtual void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);///< set bounds of the object relative to the CScreen's top left corner.
	virtual float GetXfactor(QRect bounds);
	int left();
	int top();
	int right();
	int bottom();
	void SetClientRect();
	virtual BOOL GetUpdateRect(QRect *pUpdateRect, LONGLONG ticks100 = 0);
	BOOL HitTestHandles(QPoint &point);		///< Check Handles for mouse contact
	void DrawObjectHandles(HDC hdc);		///< Draw the grab Handles to standard device context
	void SetColourKey(Colour colr);			///< Set the Transparency colour for blts and alpha blends
	//E437415
	//void DrawObjectHandles(LPDIRECTDRAWSURFACE4 pDDsurf);	///< Draw the grab Handles to directdraw surface
	void DrawObjectHandles(LPDIRECTDRAWSURFACE pDDsurf);	///< Draw the grab Handles to directdraw surface
	T_LAYOUTITEM GetLayoutItem();
	BOOL MatchLayoutItem(T_LAYOUTITEM *LayoutItem);
	// linking functions
	BOOL LinkTo(CBaseObject *pObj, BOOL bDeferLinking = FALSE, LinkError *pLinkError = NULL, BOOL bDoingDeferedLink =
	FALSE);
	BOOL Unlink();
	BOOL SetLinkLimits(int &lim1, int &lim2, int *pPos1 = NULL, int *pPos2 = NULL);
	BOOL TestLinkPositions(int pos1, int pos2);
	virtual LinkOrientation GetLinkOrient() {
		return LINK_NONE;
	}						///< can the Object be linked and if so, which way?
	virtual BOOL CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2);///< calculate the link positions from the object limits
	virtual BOOL CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2);///< baseobject version does not impose any restrictions
	virtual QString GetId();
	virtual QRect GetLayoutItemBounds() {
		return GetBoundsActual();
	}
	virtual COpPanel* GetOpPanel();			///< Get the OpPanel associated with the layout item
	// Derived Objects will override these as required		
	// (pure virtual functions below make this an abstract class)
	virtual void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds)=0;	///< init first time	
	virtual void Destroy()=0;							///< Clean-up function 
	virtual int GetMinHeight() {
		return MINHEIGHT;
	}		///< Function to return the minimium height for a derived Object
	virtual int GetMinWidth() {
		return MINWIDTH;
	}			///< Function to return the minimium width for a derived Object
	virtual void OnSetFocus() {
		;
	}						///< Just receiving the input focus
	virtual void OnKillFocus() {
		;
	}						///< Just losing the input focus
	virtual void OnChar(wchar_t ch) {
		;
	}					///< User input (keyboard or SIP)
	virtual void OnMouseDown(UINT nFlags, QPoint &p) {
		;
	}	///< Mouse button down (or touch screen touched) at point
	virtual void OnMouseUp(UINT nFlags, QPoint &p) {
		;
	}	///< Mouse button up (or touchscreen)
	virtual void OnMouseMove(UINT nFlags, QPoint &p) {
		;
	}	///< Dragging on screen with mouse or touchscreen
	/// Accessor method for the recorder screen type (800*600 or 320*240)
	static const bool IsSXRecorder() {
		return !m_bIsQXRecorder;
	}
	// flags are as for MFC (see CWidget::OnMouseMove)
	/*
	 nFlags 
	 Indicates whether various virtual keys are down. This parameter can be any combination of the following values: 
	 
	 MK_CONTROL  Set if the CTRL key is down. 
	 MK_LBUTTON  Set if the left mouse button is down. 
	 MK_MBUTTON  Set if the middle mouse button is down. 
	 MK_RBUTTON  Set if the right mouse button is down. 
	 MK_SHIFT	 Set if the SHIFT key is down. 
	 */
// Overridables
public:
	// Method that gets the maximum allowable number of chart pens given the current device type
	const USHORT GetMaxChartPens();
	/// Variable indicating the maximum number of multitrend chart pens
	static const USHORT ms_usMAX_MULTITREND_CHART_PENS;
	/// Variable indicating the maximum number of minitrend chart pens
	static const USHORT ms_usMAX_MINITREND_CHART_PENS;
protected:
	static bool m_bIsQXRecorder;	///< Flag indicating if the recorder is a QX
	static bool ms_bRecorderTypeInit;///< Flag indicating if the recorder types has been determined yet - used on the recorder
									 ///< to decrease processing overheads
};
#endif

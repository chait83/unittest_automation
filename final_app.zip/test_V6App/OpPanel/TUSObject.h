/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: TUSObject.h
/// @n Description: Definition of the TUS Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:02:12 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:25:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 9/23/2008 12:21:12 PM  Build Machine  
// $
//
// **************************************************************************
#ifndef _TUSOBJECT_H
#define _TUSOBJECT_H
//**CTUSObject ****************************************************
///
/// @brief TUS Object
/// 
/// This class is a custom drawn object for the TUS object
/// which is derived from the CBaseObject class.
///
//****************************************************************************
class CTUSObject: public CBaseObject {
private:
	T_TUSOBJECT *m_pCMMTUS;	///< Pointer to our CMM configuration
	COLORREF m_crTitleCellBackGndColour;		///< Variable indicating the the background colour of the title cells
	// Colours used for the cell backgrounds
	const COLORREF m_crTUSNotStarted;
	const COLORREF m_crTUSInDetect;
	const COLORREF m_crTUSInInSoak;
	const COLORREF m_crTUSInInStability;
	const COLORREF m_crTUSFailed;
	const COLORREF m_crTUSPassed;
	const COLORREF m_crTUSInactive;
	// Derived objects must draw themselves.
	// Called via the m_pOnDraw pointer to function.
	static void OnDraw(CTUSObject *pThis, HDC hdc, QRect *pClipRect);
	// data item table reference to the special TUS pen (used to force updates on the widget)
	CDataItemRef *m_pDataItemRef;
	// Structure that holds details of the special TUS pen
	T_CHANNELREF m_tSpecialTUSPen;
public:
	virtual void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);///< set bounds of the object relative to the CScreen's top left corner.
	// Constructor
	CTUSObject(CWidget *pWidget);
	// overidden functions that must be supplied
	virtual void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	virtual void ConfigChange();					///< config changes	
	virtual void Destroy();
	// Array containing the column widths
	static const LONG m_laCOL_WIDTHS[13];
	// Variable containing the width of a TUS object
	static const LONG m_lWIDTH;
	// Accessor method that indicates the TUS display object needs updating
	const bool DisplayUpdateRequired() const;
	// Method that resets the flag that indicates the TUS display object needs updating
	void ResetDisplayUpdateFlag();
};
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: LayoutItem.h 
/// @n Description: Layout item class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  42  Stability Project 1.39.1.1 7/2/2011 4:58:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  41  Stability Project 1.39.1.0 7/1/2011 4:25:53 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  40  V6 Firmware 1.39 10/23/2006 7:32:25 PM  Jason Parker  Min
//  Object size now 5x5
//  39  V6 Firmware 1.38 1/9/2006 8:40:24 PM David Fulmer (Ft
//  Washington) Sync Screen Designer's Properties window on selecting a
//  template or screen
// $
//
// **************************************************************************
#ifndef _LAYOUTITEM_H
#define _LAYOUTITEM_H
#define _SIZECHAR(wItem)  (sizeof(wItem)/sizeof(WCHAR))
#define MAX_NAME_TYPE_CAT		22///<this value is matched to the default value of the CMM db
#define DEF_BORDER_WIDTH	1 ///<this value is matched to the default value of the CMM db
#define MAX_BORDER_WIDTH	15///<this value is matched to the MAX_LIMIT value of the CMM db
#define MAX_TMPLT_SCR_NUM	255///<this value is matched to the MAX_LIMIT value of the CMM db
#define ONDRAWCAST void(__cdecl*)(void*,HDC,QRect*)
#define MINWIDTH 5
#define MINHEIGHT 5
#define MAX_COMBO_ITEMS 8
#define MAX_CMBSTR_LENGTH 32//length increased from 16 to 32
#define LEN_PROP_NAME			32 //length 24 is too short for decently readable property names
#define LEN_PROP_DESCRIPTION	156
#define LEN_WCHAR_TYPE			48 ///<This is for Widget Name, Type, Category strings
#define IS_PROP(p) (((ULONG_PTR)(p) >> 16) == 0) // similar to IS_INTRESOURCE
#define USE_PROP(p) (LPWSTR)((ULONG_PTR)((WORD)(p))) // similar to MAKEINTRESOURCE
#include "CMMDefines.h"
///< forward references
class CWidget;
class COpPanel;
enum {
	Grey, Red, Blue, Green, Magenta, Cyan, Yellow
};
//*******************************************************
// enum 
///
/// Bar Styles
///
//*******************************************************
enum {
	BAR_STYLE_SOLID, BAR_STYLE_FADE, BAR_STYLE_DYNAMIC, BAR_STYLE_TRAFFICLIGHT
};
//*******************************************************
// enum 
///
/// BarType field for the BarObject
///
//*******************************************************
enum {
	None, Up, Down, Based, Progress
};
//*******************************************************
// enum 
///
/// Range(over/Under),Invalid Reading,Burnout(high/Low) errors field for the BarObject
///
//*******************************************************
enum {
	OVER_RNG_ERR, UNDER_RNG_ERR, INVALID_READING, UPSCALE_BURNOUT, DOWNSCALE_BURNOUT
};
//*******************************************************
// enum 
///
/// Attributes which can be changed for a layout item
///
//*******************************************************
enum ELayoutItemAttribute {
	ATTR_NONE,		///< no attribute
	ATTR_LEFT,		///< left position for an object/widget
	ATTR_TOP,		///< top position for an object/widget
	ATTR_WIDTH,		///< width for an object/widget
	ATTR_HEIGHT		///< height for an object/widget
};
class CLayoutItem {
// Overridables
public:
	/// Enumerated varaibles indicating the item type this class relates too
	enum T_ITEM_TYPE {
		otTemplate, otScreen, otWidget, otObject
	};
	virtual QString GetId() {
		return "";
	}
	virtual QRect GetLayoutItemBounds() {
		return QRect(0, 0, 0, 0);
	}
	virtual COpPanel* GetOpPanel() = 0;	///< Get the OpPanel associated with the layout item
	virtual void ConfigChange() {
	}		///< To be called when data item info changes (setup or Widget rotation etc)
	BLOCK_INFO GetCMMInfo() {
		return m_CMMinfo;
	}
// Implementation
public:
	virtual ~CLayoutItem();
	const bool IsWidget() const {
		return (m_eITEM_TYPE == otWidget);
	}
	const bool IsTemplate() const {
		return (m_eITEM_TYPE == otTemplate);
	}
	const bool IsScreen() const {
		return (m_eITEM_TYPE == otScreen);
	}
	const bool IsObject() const {
		return (m_eITEM_TYPE == otObject);
	}
	// Accessor Methods
	const T_ITEM_TYPE GetItemType() {
		return m_eITEM_TYPE;
	}
	BLOCK_INFO m_CMMinfo;				///< block of CMM info
// Constructors
protected:
	CLayoutItem(const T_ITEM_TYPE eITEM_TYPE = otObject); // cannot instantiate directly
private:
	/// The item type e.g. screen, widget, object
	const T_ITEM_TYPE m_eITEM_TYPE;
};
#endif

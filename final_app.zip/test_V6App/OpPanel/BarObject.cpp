/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: BarObject.cpp
/// @n Description: Derived Object barObject
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  96  Stability Project 1.91.1.3 7/2/2011 4:55:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  95  Stability Project 1.91.1.2 7/1/2011 4:37:58 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  94  Stability Project 1.91.1.1 3/17/2011 3:20:10 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  93  Stability Project 1.91.1.0 2/15/2011 3:02:14 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include <float.h>
#include <math.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CBarObject::CBarObject(CWidget *pWidget) : CBaseObject(pWidget) {
	// reassign function pointer (speed issue)
	m_ErrIndicator = 0;
	m_bSetErrors = FALSE;
	m_fZoomZero = 0.0;
	m_fZoomSpan = 100.0;
	m_pAboveColour = &G_abovecolour; //point to some default
	m_pBelowColour = &G_belowcolour; //point to some default
	m_DrawInFlashState = FALSE;
	m_bInZoom = FALSE;
	m_bLogScale = FALSE;
	m_bLogScaleScrDes = FALSE;
	m_bSetScale = FALSE;
	m_dcMemory = NULL;
	//local copy from DataItemTable
	int j;
	//flash Colour1 and FalshColour2 for each error indicator
	for (j = 0; j < MAX_ERR_INDICATOR_COLS; j++) {
		m_DiErrIndicatorFlashCols[j] = RGB565(255, 255, 0); // yellow;
		m_DiErrIndicatorInterFlashCols[j] = RGB565(0, 0, 0); // black;
	}
	for (j = 0; j < MAX_ERR_INDICATOR_COLS; j++) {
		m_pErrIndicatorFlashCols[j] = &m_DiErrIndicatorFlashCols[j];
		m_pErrIndicatorInterFlashCols[j] = &m_DiErrIndicatorInterFlashCols[j];
	}
	m_IsOverRange = FALSE;
	m_IsUnderRange = FALSE;
	m_IsInvalidReading = FALSE;
	m_IsUpscBurnout = FALSE;
	m_IsDownscBurnout = FALSE;
	m_IsUpscBurnout = FALSE;
	m_IsDownscBurnout = FALSE;
	m_drawvalue = 0;
	m_drawvalSpan = 0;
	m_drawvalZero = 0;
	m_ScaleReversed = FALSE;
	m_pOnDraw = (ONDRAWCAST) & CBarObject::OnDraw;
	// set all of the objects internal settings to defaults
	// set range of bar from 0 to 100 (ignoring 4% above and below)
	m_TopLimit = 100.0;
	m_BottomLimit = 0.0;
	m_CurrentValue = 60.0;
	for (int i = 0; i < MAX_DIT_REF_BAROBJ; i++) {
		m_pDataItemRef[i] = NULL;
	}
	// init these here to prevent exception later on.
	m_MaxValue = 0.0;
	m_MinValue = 0.0;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Required size and position for a new Object
///
/// @return none
/// 
//****************************************************************************
void CBarObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CEBarObject data in CMM info block.
	m_pCMMBar = (T_BAROBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		// set these flags for specific Object (e.g. may be advanced draw only)
		/*
		 m_pCMMbase->IsAdvancedDraw
		 m_pCMMbase->IsBuffered
		 m_pCMMbase->IsPermanent
		 m_pCMMbase->IsBackground
		 m_pCMMbase->IsPrimaryDirect
		 // etc...
		 */
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
	}
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CBarObject::ConfigChange() {
	// Data item configuration done here. 
	// example bar only has one data item reference and has the following CMM config:
	// ChannelInfo 
	//		ItemType = Pen
	//		IndexChan = 0	...index into Widget's Channel 'List'
	//		Instance = 1
	T_CHANNELREF tPenMaxChan;
	T_CHANNELREF tPenMinChan;
	// always initialise the first data item channel
	if (m_pDataItemRef[CURRENT_VAL] == NULL)
		m_pDataItemRef[CURRENT_VAL] = new CDataItemRef(this);
	// only create the min and max markers if the relevant flags are set and the first data item
	// is set to pen reading
	if (m_pCMMBar->ChannelInfo.ItemType == DI_PEN) {
		// check the max marker first and check we have not already enabled this item
		if ((m_pCMMBar->ShowMaxMrkr == TRUE) && (m_pDataItemRef[MAX_VAL] == NULL)) {
			m_pDataItemRef[MAX_VAL] = new CDataItemRef(this);
			// setup the dummy channel ref
			memcpy(&tPenMaxChan, &m_pCMMBar->ChannelInfo, sizeof(T_CHANNELREF));
			// set to MMA and MAX
			tPenMaxChan.ItemType = DI_MMA;
			tPenMaxChan.SubType = DI_MMA_MAX_USER;
		} else if ((m_pCMMBar->ShowMaxMrkr == FALSE) && (m_pDataItemRef[MAX_VAL] != NULL)) {
			// not wanted so set to NULL
			m_pWidget->DeleteDataItem(m_pDataItemRef[MAX_VAL]);
			m_pDataItemRef[MAX_VAL] = NULL;
		} else if (m_pCMMBar->ShowMaxMrkr == TRUE) {
			// must be no change so just copy the channel structure
			memcpy(&tPenMaxChan, &m_pCMMBar->ChannelInfo, sizeof(T_CHANNELREF));
			// set to MMA and MAX
			tPenMaxChan.ItemType = DI_MMA;
			tPenMaxChan.SubType = DI_MMA_MAX_USER;
		}
		// now check the min marker
		// check the max marker first and check we have not already enabled this item
		if ((m_pCMMBar->ShowMinMrkr == TRUE) && (m_pDataItemRef[MIN_VAL] == NULL)) {
			m_pDataItemRef[MIN_VAL] = new CDataItemRef(this);
			// setup the dummy channel ref
			memcpy(&tPenMinChan, &m_pCMMBar->ChannelInfo, sizeof(T_CHANNELREF));
			// set to MMA and MIN
			tPenMinChan.ItemType = DI_MMA;
			tPenMinChan.SubType = DI_MMA_MIN_USER;
		} else if ((m_pCMMBar->ShowMinMrkr == FALSE) && (m_pDataItemRef[MIN_VAL] != NULL)) {
			// not wanted so set to NULL
			m_pWidget->DeleteDataItem(m_pDataItemRef[MIN_VAL]);
			m_pDataItemRef[MIN_VAL] = NULL;
		} else if (m_pCMMBar->ShowMinMrkr == TRUE) {
			// must be no change so just copy the channel structure
			memcpy(&tPenMinChan, &m_pCMMBar->ChannelInfo, sizeof(T_CHANNELREF));
			// set to MMA and MIN
			tPenMinChan.ItemType = DI_MMA;
			tPenMinChan.SubType = DI_MMA_MIN_USER;
		}
	} else {
		// the channel is not looking at a pen reading so we do not want to show any max/min information
		if (m_pDataItemRef[MAX_VAL] != NULL) {
			m_pWidget->DeleteDataItem(m_pDataItemRef[MAX_VAL]);
			m_pDataItemRef[MAX_VAL] = NULL;
		}
		if (m_pDataItemRef[MIN_VAL] != NULL) {
			m_pWidget->DeleteDataItem(m_pDataItemRef[MIN_VAL]);
			m_pDataItemRef[MIN_VAL] = NULL;
		}
	}
	if (m_pDataItemRef[CURRENT_VAL]) {
		// pass it to our Widget, along with our CMM config
		if (m_pWidget->GetDataItem(m_pDataItemRef[CURRENT_VAL], &m_pCMMBar->ChannelInfo)) {
			// worked OK. Now set our members based on CMM settings and data item info
			//DataItemGeneral generalDetails=m_pDataItemRef->m_pDataItem->GetGeneral();
			T_PSCALEINFO ScaleDetails = m_pDataItemRef[CURRENT_VAL]->m_pDataItem->GetScaleInfo();
			m_bLogScale = ScaleDetails->LogScale;
			// T_BASEOBJECT CMM config to CBaseObject members:
			// set our internal members values from the Attribute block or source or CMM 
			if (m_pCMMbase->FixForeColour)
				// use foreground colour from CMM (e.g. as selected in Screen Designer)
				m_pForeColour = &m_pCMMbase->ForeColour;
			else {
				if (m_pCMMbase->AttrBlocks.ForeColourBlk)
					// use foreground colour from Attribute block
					m_pForeColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
							m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
				else {	// use foreground colour from Data Item Table item
						//m_DiFColour=generalDetails.ItemColour;
					m_pForeColour = m_pDataItemRef[CURRENT_VAL]->m_pDataItem->GetColour();
				}
			}
			if (m_pCMMbase->FixBackColour)
				// use background colour from CMM (e.g. as selected in Screen Designer)
				m_pBackColour = &m_pCMMbase->BackColour;
			else {
				if (m_pCMMbase->AttrBlocks.BackColourBlk)
					// use foreground colour from Attribute block
					m_pBackColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
							m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
				else {
					// use background colour from Data Item Table item
					//m_DiBColour=generalDetails.ItemColour; 
					m_pBackColour = m_pDataItemRef[CURRENT_VAL]->m_pDataItem->GetColour();
				}
			}
			if (m_pCMMBar->FixAboveColour)
				// use background colour from CMM (e.g. as selected in Screen Designer)
				m_pAboveColour = &m_pCMMBar->SldAboveClr;
			else {
				// use background colour from Data Item Table item
				m_pAboveColour = m_pDataItemRef[CURRENT_VAL]->m_pDataItem->GetColour();
			}
			if (m_pCMMBar->FixBelowColour)
				// use background colour from CMM (e.g. as selected in Screen Designer)
				m_pBelowColour = &m_pCMMBar->SldBelowClr;
			else {
				// use background colour from Data Item Table item
				m_pBelowColour = m_pDataItemRef[CURRENT_VAL]->m_pDataItem->GetColour();
			}
			// use flash atrtribute from Attribute block if set (0=default=FALSE)
			m_pFlashing =
					&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.FlashingBlk)->Flashing;
			// use visible atrtribute from Attribute block if set (0=default=TRUE)
			m_pVisible =
					&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
			// use colours from screen Designer
			for (int j = 0; j < MAX_ERR_INDICATOR_COLS; j++) {
				*m_pErrIndicatorFlashCols[j] = m_pCMMBar->ErrIndFlsClr[j];
				*m_pErrIndicatorInterFlashCols[j] = m_pCMMBar->ErrIndIntFlsClr[j];
			}
			// T_BAROBJECT CMM config to CBarObject members:
			///@todo, get the m_bInZoomMode 
			if (!m_bSetScale)			///@todo, remove this check after testing, all scale params set here
			{
				if (!m_bInZoom)		///@todo, in zoom mode get the zoomZero and zoomSpan from whereever it is being set
									///here, it is set from the Screen Designer or DIT
				{
					if (m_pCMMBar->FixTopLimit)
						m_TopLimit = m_pCMMBar->TopLimit;
					else {
						if (m_bLogScale)
							m_TopLimit = (float) ScaleDetails->StartDecade + ScaleDetails->NumDecades;
						else
							m_TopLimit = m_pDataItemRef[CURRENT_VAL]->m_pDataItem->GetSpan();
					}
					if (m_pCMMBar->FixBotLimit)
						m_BottomLimit = m_pCMMBar->BotLimit;
					else {
						if (m_bLogScale)
							m_BottomLimit = ScaleDetails->StartDecade;
						else
							m_BottomLimit = m_pDataItemRef[CURRENT_VAL]->m_pDataItem->GetZero();
					}
				} else					//////@todo, get the value of m_fZoomSpan and m_fZoomZero from screen designer
				{
					m_TopLimit = m_fZoomSpan;				//this could be log scale Num Decades or linear scale Span
					m_BottomLimit = m_fZoomZero;			//this could be log scale Start Decade or linear scale Zero
				}
			} else///@todo, remove this whole else clause after testing. Is the scale type(lin/log), zoom mode set in SCr Designer?
			{
				m_bLogScale = m_bLogScaleScrDes;
				m_TopLimit = m_pCMMBar->TopLimit;
				m_BottomLimit = m_pCMMBar->BotLimit;
			}
		}
	}
	m_MaxValue = 0.0;
	m_MinValue = 0.0;
	if (m_pDataItemRef[MAX_VAL]) {
		// pass it to our Widget, along with our CMM config
		if (m_pWidget->GetDataItem(m_pDataItemRef[MAX_VAL], &tPenMaxChan)) {
			m_MaxValue = m_pDataItemRef[MAX_VAL]->m_pDataItem->GetFPValue();
		}
	}
	if (m_pDataItemRef[MIN_VAL]) {
		// pass it to our Widget, along with our CMM config
		if (m_pWidget->GetDataItem(m_pDataItemRef[MIN_VAL], &tPenMinChan)) {
			m_MinValue = m_pDataItemRef[MIN_VAL]->m_pDataItem->GetFPValue();
		}
	}
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
}	//****************************************************************************
///
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CBarObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	CBaseObject::SetBounds(bounds, pPos1, pPos2); // call the base Object version
// this was done every time in OnDraw. Now done on config change only.
	float SpanDest;
	float ZeroDest;
	m_ScaleReversed = IsScaleReversed(this);
	if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL) //vertical
			{
		SpanDest = (float) m_ClientRect.top;
		ZeroDest = (float) m_ClientRect.bottom - 1; // -1 because we don't use the Bottom edge
	} else //horizontal
	{
		SpanDest = (float) m_ClientRect.right - 1; // -1 because we don't use the right edge
		ZeroDest = (float) m_ClientRect.left;
	}
	m_conv.CalcFConvInfo(m_BottomLimit, m_TopLimit, ZeroDest, SpanDest);
	m_drawvalSpan = (int) (m_conv.CalcSourceToDestCapped(m_TopLimit) + 0.5);
	m_drawvalZero = (int) (m_conv.CalcSourceToDestCapped(m_BottomLimit) + 0.5);
	//static int nCount=0;
	//qDebug("Exited CBarObject::SetBounds for %x on screen (%d,%d) bounds=(%d,%d,%d,%d) pos=(%d,%d) ZeroDest=%f SpanDest=%f (%d)\n", this, m_pWidget->m_pScreen->m_CMMinfo.wBlockType, m_pWidget->m_pScreen->m_CMMinfo.wInstanceID, bounds->left, bounds->top, bounds->right, bounds->bottom, pPos1 ? *pPos1 : -1, pPos2 ? *pPos2 : -1, ZeroDest, SpanDest, ++nCount);
}
//****************************************************************************
///
/// Drawing function. 
/// This function must do all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed, and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. In both cases the function must 
/// draw *at least* as much as defined by the Clipping Rectangle. Any addtional
/// drawing that is done (outside of the ClipRect) will have no effect, but in 
/// some cases it is easier (and quicker) to simply draw everything for the 
/// Object rather than work out just those parts actually required.
///
///	NB: the ClipRect pointer can be NULL indicating the complete Object *must*
/// be fully redrawn. In this case the Object can inspect Widgets m_UpdateRgn
/// to see if an optimised draw is possible. At least part of the Object will 
/// be contained in the region for the draw function to have been called
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CBarObject::OnDraw(CBarObject *pThis, HDC hdc, QRect *pClipRect) {
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	///@todo, remove after testing
	if (pThis->m_bSetErrors) {
		pThis->m_IsOverRange = (pThis->m_ErrIndicator == 0);
		pThis->m_IsUnderRange = (pThis->m_ErrIndicator == 1);
		pThis->m_IsInvalidReading = (pThis->m_ErrIndicator == 2);
		pThis->m_IsUpscBurnout = (pThis->m_ErrIndicator == 3);
		pThis->m_IsDownscBurnout = (pThis->m_ErrIndicator == 4);
	}
	// if Update Required make any updates due to data item changes then do a full repaint
	if (pThis->m_UpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object.
		if (pThis->m_UpdateValue) {
			pThis->m_CurrentValue = pThis->m_pDataItemRef[0]->m_pDataItem->GetFPValue();
			pThis->m_IsOverRange = ((pThis->m_pDataItemRef[0]->m_pDataItem->GetStatus() == DISTAT_OVERRANGE)
					|| (pThis->m_pDataItemRef[0]->m_pDataItem->GetStatus() == DISTAT_INPUT_OVERRANGE));
			pThis->m_IsUnderRange = ((pThis->m_pDataItemRef[0]->m_pDataItem->GetStatus() == DISTAT_UNDERRANGE)
					|| (pThis->m_pDataItemRef[0]->m_pDataItem->GetStatus() == DISTAT_INPUT_UNDERRANGE));
			pThis->m_IsUpscBurnout =
					(pThis->m_pDataItemRef[0]->m_pDataItem->GetStatus() == DISTAT_INPUT_UPSCALE_BURNOUT);
			pThis->m_IsDownscBurnout = (pThis->m_pDataItemRef[0]->m_pDataItem->GetStatus()
					== DISTAT_INPUT_DOWNSCALE_BURNOUT);
			pThis->m_IsInvalidReading = (pThis->m_pDataItemRef[0]->m_pDataItem->GetStatus() == DISTAT_INVALID);
			if (pThis->m_pDataItemRef[MAX_VAL] != NULL) {
				pThis->m_MaxValue = pThis->m_pDataItemRef[MAX_VAL]->m_pDataItem->GetFPValue();
			}
			if (pThis->m_pDataItemRef[MIN_VAL] != NULL) {
				pThis->m_MinValue = pThis->m_pDataItemRef[MIN_VAL]->m_pDataItem->GetFPValue();
			}
			pThis->m_UpdateValue = FALSE;
		}
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	}
	pThis->m_DrawInFlashState = FALSE;
	if (*(pThis->m_pFlashing)) // if we are flashing set our drawInFlashState.
		pThis->m_DrawInFlashState = pThis->m_FlashState;
	// draw border if required
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		//need to fix this in the properties window
		//if BorderUsed = No, BorderStyle field should be disabled or hidden
		//						BorderWidth is Disabled or Hidden
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	// same action whether log scale or not
	pThis->m_drawvalue = (int) (pThis->m_conv.CalcSourceToDestCapped(pThis->m_CurrentValue) + 0.5);
	if ((pThis->m_IsOverRange) || (pThis->m_IsUpscBurnout))
		pThis->m_drawvalue = pThis->m_drawvalSpan;
	else if ((pThis->m_IsUnderRange) || (pThis->m_IsDownscBurnout) || (pThis->m_IsInvalidReading))
		pThis->m_drawvalue = pThis->m_drawvalZero;
//set bar type	
	pThis->SetBarType(hdc);
	if (pThis->m_IsOverRange)
		pThis->SetErrIndicators(hdc, OVER_RNG_ERR, 0xE031, 0xE033);						//vertical code,horizontal code
	else if (pThis->m_IsUnderRange)
		pThis->SetErrIndicators(hdc, UNDER_RNG_ERR, 0xE030, 0xE032);
	if (pThis->m_IsInvalidReading)
		pThis->SetErrIndicators(hdc, INVALID_READING, g_wcINVALID, g_wcINVALID);//same (asterisk)code , vertical or horizontal
	if (pThis->m_IsUpscBurnout)
		pThis->SetErrIndicators(hdc, UPSCALE_BURNOUT, 0xE031, 0xE033);
	else if (pThis->m_IsDownscBurnout)
		pThis->SetErrIndicators(hdc, DOWNSCALE_BURNOUT, 0xE030, 0xE032);
	pThis->SetMaxMinMarkers(hdc);
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CBarObject::Destroy() {
}
//****************************************************************************
///
/// SetBarType function. 
/// Sets ValueRect and BackRect boundaries to Fill in the FillBar function
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use
/// @return none
/// 
//****************************************************************************
void CBarObject::SetBarType(HDC hdc) {
	QRect valueRect, backRect;
	int DrawPosition;
	QRect bounds = m_ClientRect;
	valueRect = m_ClientRect; // Objects Client Area (bounds less border)
	backRect = m_ClientRect; // Objects Client Area (bounds less border)
	//in this switch statement, valuerect and backrect vertices are set, FillBar fills accoring to Bar Style
	switch (m_pCMMBar->BarType) {
	case None:
		if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL) //vertical
				{
			valueRect.setTop(m_drawvalue);
			backRect.setBottom(valueRect).top;
		} else {
			valueRect.setright(m_drawvalue);
			backRect.setleft(valueRect).right;
		}
//not sure if need to set the default pen colour to back and fore rect. From V5 screen designer it looks like default pen colour is set
//for barType None
		m_pForeColour = &m_pCMMbase->ForeColour;
		m_pBackColour = &m_pCMMbase->BackColour;
		//Fade or Solid type, draw the same way
		FillBar(hdc, valueRect, backRect);
		if (m_pCMMBar->LevelCap)
			SetLevelCap(hdc, valueRect);
		break;
	case Up:
		if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL) //vertical
				{
			valueRect.setTop(m_drawvalue);
			backRect.setBottom(valueRect).top;
		} else {
			valueRect.setright(m_drawvalue);
			backRect.setleft(valueRect).right;
		}
		FillBar(hdc, valueRect, backRect);
		if (m_pCMMBar->LevelCap)
			SetLevelCap(hdc, valueRect);
		break;
	case Down:
		if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL) //vertical
				{
			backRect.setTop(m_drawvalue);
			valueRect.setBottom(backRect).top;
		} else {
			backRect.setright(m_drawvalue);
			valueRect.setleft(backRect).right;
		}
		//switch the colours
		FillBar(hdc, valueRect, backRect);
		if (m_pCMMBar->LevelCap)
			SetLevelCap(hdc, backRect);
		break;
	case Based:
		//valuerect is based at this point. 
		//backRect.bottom remains the same
		//(MarkD) probably no requirement for log10 function here - it was removed from OnDraw
		//if(m_bLogScale)
		//	DrawPosition=(int)(m_conv.CalcSourceToDestCapped((float)log10(m_pCMMBar->BasePoint))+0.5);
		//else
		DrawPosition = (int) (m_conv.CalcSourceToDestCapped(m_pCMMBar->BasePoint) + 0.5);
		if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL)		//vertical
				{
			if (m_CurrentValue < m_pCMMBar->BasePoint) {
				valueRect.top = (DrawPosition == 0) ? m_ClientRect.top : DrawPosition;
				valueRect.setBottom(m_drawvalue);
				//backRect.bottom is ClientRect.bottom
				FillBar(hdc, valueRect, backRect);
				if (m_pCMMBar->LevelCap)
					SetLevelCap(hdc, valueRect, rectleftTop);
			} else {
				valueRect.setTop(m_drawvalue);
				valueRect.bottom = (DrawPosition == 0) ? m_ClientRect.bottom : DrawPosition;
				//backRect.top and bottom are clientREct.top and bottom
				FillBar(hdc, valueRect, backRect);
				if (m_pCMMBar->LevelCap)
					SetLevelCap(hdc, valueRect, rectrightBottom);
			}
		} else {
			if (m_CurrentValue < m_pCMMBar->BasePoint) {
				valueRect.right = (DrawPosition == 0) ? m_ClientRect.right : DrawPosition;
				valueRect.setleft(m_drawvalue);
				//backRect.bottom is ClientRect.bottom
				FillBar(hdc, valueRect, backRect);
				if (m_pCMMBar->LevelCap)
					SetLevelCap(hdc, valueRect, rectleftTop);
			} else {
				valueRect.setright(m_drawvalue);
				valueRect.left = (DrawPosition == 0) ? m_ClientRect.left : DrawPosition;
				//backRect.top and bottom are clientREct.top and bottom
				FillBar(hdc, valueRect, backRect);
				if (m_pCMMBar->LevelCap)
					SetLevelCap(hdc, valueRect, rectrightBottom);
			}
		}
		break;
	default:
		break;
	}
}
//****************************************************************************
///
/// SetLevelCap function. 
///
/// @param[in] hdc			- Handle to Device Context to use
/// @param[in] valueRect	- value Rectangle (forerectangle)
/// @param[in] backRect		- back Rectangle (background rectangle), bar is drawn 
///							 using these 2 rectangles
/// @return none
/// 
//****************************************************************************
void CBarObject::SetLevelCap(HDC hdc, QRect LevelRect, int rectSide) {
	QPen myPen = ::CreatePen(PS_SOLID, 0, m_pCMMBar->LevelCapClr);
	QPen oldpen = (QPen) SelectObject(hdc, myPen);
	//draw level cap
	QPoint CapStart, CapEnd;
	if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL)		//vertical
			{
		if (rectSide)		//top side of rect
		{
			CapStart.y = LevelRect.top;
			CapEnd.y = LevelRect.top;
		} else {
			CapStart.y = LevelRect.bottom;
			CapEnd.y = LevelRect.bottom;
		}
		CapStart.x = LevelRect.left;
		CapEnd.x = LevelRect.right;
	} else {
		if (rectSide) {
			CapStart.x = LevelRect.right;
			CapEnd.x = LevelRect.right;
		} else {
			CapStart.x = LevelRect.left;
			CapEnd.x = LevelRect.left;
		}
		CapStart.y = LevelRect.top;
		CapEnd.y = LevelRect.bottom;
	}
	MoveToEx(hdc, CapStart.x, CapStart.y, NULL);
	LineTo(hdc, CapEnd.x, CapEnd.y);
	SelectObject(hdc, oldpen);
	DeleteObject(myPen);
}
//****************************************************************************
///
/// FillBar function. 
/// Fills bar solid, Fade, Traffic light pattern or Dynamically
/// @param[in] hdc			- Handle to Device Context to use
/// @param[in] valueRect	- value Rectangle (forerectangle)
/// @param[in] backRect		- back Rectangle (background rectangle), bar is drawn 
///							 using these 2 rectangles
/// @return none
/// 
//****************************************************************************
void CBarObject::FillBar(HDC hdc, QRect valueRect, QRect backRect) {
	HBRUSH hBrushback, hBrushfore, brClr;
	CDC *pDC = CDC::FromHandle(hdc);
	QRect valRect1, valRect2, valRect3;
	int DrawPositionG, DrawPositionA;		//for Traffic light colouring
	if (m_pCMMbase->IsTransparent)
		SetBkMode(hdc, TRANSPARENT);
	else {
//fill backRect, fade, solid or any type, fill the same way
		hBrushback = CreateSolidBrush(*m_pBackColour);
//solid fill
		FillRect(hdc, &m_ClientRect, hBrushback);
		DeleteObject(hBrushback);
	}
	switch(m_pCMMBar->BarStyle)
	{
		case BAR_STYLE_SOLID:
		if (m_pCMMBar->BarType != None) {
			if (m_pCMMBar->BarType == Based)
				//colour the valueRect with above or Below Colour depending upon currval<basepoint or greater
				hBrushfore = (m_CurrentValue <= m_pCMMBar->BasePoint) ? CreateSolidBrush(*m_pBelowColour) : hBrushfore =
																				CreateSolidBrush(*m_pAboveColour);
			else
				hBrushfore = CreateSolidBrush(*m_pForeColour);
			FillRect(hdc, &valueRect, hBrushfore);
			DeleteObject(hBrushfore);
		}
		break;
		case BAR_STYLE_FADE:
		switch (m_pCMMBar->BarType)		//bar type none is already handled
		{
		case None:
			break;
		case Up:
		case Based:
		case Down:
			FillBarFade(hdc, valueRect);
			break;
		default:
			break;
		}
		break;
		case BAR_STYLE_TRAFFICLIGHT:
		//for now make both trafic and dynamic the same
		//first devide the bar into 3 regions
		switch (m_pCMMBar->BarType) {
		case None:
			break;
		case Up:
			///@todo, need to reduce the size of this case label...needs very careful cleanup!!!
			//valueRect bottom is fixed, top moves
			//(MarkD) probably no requirement for log10 function here - it was removed from OnDraw
			//if(m_bLogScale)
			//{
			//	DrawPositionG=(int)(m_conv.CalcSourceToDestCapped((float)log10(m_pCMMBar->BreakPtGreen))+0.5);
			//	DrawPositionA=(int)(m_conv.CalcSourceToDestCapped((float)log10(m_pCMMBar->BreakPtAmber))+0.5);
			//}
			//else
			//{
			DrawPositionG = (int) (m_conv.CalcSourceToDestCapped(m_pCMMBar->BreakPtGreen) + 0.5);
			DrawPositionA = (int) (m_conv.CalcSourceToDestCapped(m_pCMMBar->BreakPtAmber) + 0.5);
			//}
			valRect1 = valRect2 = valRect3 = valueRect;
			if (m_CurrentValue <= m_pCMMBar->BreakPtGreen) {
				//colour valRect1 Green
				//leave valRect2 and 3 with the background colour
				if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL)				//vertical
						{
					valRect1.setBottom(valueRect).bottom;
					valRect1.setTop(m_drawvalue);
				} else {
					valRect1.setleft(valueRect).left;
					valRect1.setright(m_drawvalue);
				}
				brClr = CreateSolidBrush(RGB(0, 255, 0));
				FillRect(hdc, &valRect1, brClr);
				DeleteObject(brClr);
			} else if ((m_CurrentValue <= m_pCMMBar->BreakPtAmber) && (m_CurrentValue > m_pCMMBar->BreakPtGreen)) {
				//colour valRect1 Green
				//colour ValRect2 Amber
				//colour ValRect3 with background colour
				if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL)				//vertical
						{
					valRect1.setBottom(valueRect).bottom;
					valRect1.top = (DrawPositionG == 0) ? m_ClientRect.top : DrawPositionG;
					valRect2.setBottom(valRect1).top;
					valRect2.setTop(m_drawvalue);
				} else {
					valRect1.setleft(valueRect).left;
					valRect1.right = (DrawPositionG == 0) ? m_ClientRect.right : DrawPositionG;
					valRect2.setleft(valRect1).right;
					valRect2.setright(m_drawvalue);
				}
				brClr = CreateSolidBrush(RGB(0, 255, 0));
				FillRect(hdc, &valRect1, brClr);
				DeleteObject(brClr);
				brClr = CreateSolidBrush(RGB(255, 233, 30));				//amber colour, RGB from Jason Parker
				FillRect(hdc, &valRect2, brClr);
				DeleteObject(brClr);
			} else {
				//colour valRect1 Green
				//colour ValRect2 Amber
				//colour ValRect3 Red
				if (m_pCMMBar->BarOrientation == OBJECT_VERTICAL)				//vertical
						{
					if (m_pCMMBar->BreakPtGreen <= m_pCMMBar->BreakPtAmber) {
						valRect1.setBottom(valueRect).bottom;
						valRect1.top = (DrawPositionG == 0) ? m_ClientRect.top : DrawPositionG;
						valRect2.setBottom(valRect1).top;
						valRect2.top = (DrawPositionA == 0) ? m_ClientRect.top : DrawPositionA;
						valRect3.setBottom(valRect2).top;
						valRect3.setTop(m_drawvalue);
					} else {
						valRect1.setBottom(valueRect).bottom;
						valRect1.top = (DrawPositionG == 0) ? m_ClientRect.top : DrawPositionG;
						valRect3.setBottom(valRect1).top;
						valRect3.setTop(m_drawvalue);
						//just make no rect
						valRect2.setBottom(m_ClientRect).top;
						valRect2.setTop(m_ClientRect).top;
						valRect2.setleft(m_ClientRect).top;
						valRect2.setright(m_ClientRect).top;
					}
				} else {
					if (m_pCMMBar->BreakPtGreen <= m_pCMMBar->BreakPtAmber) {
						valRect1.setleft(valueRect).left;
						valRect1.right = (DrawPositionG == 0) ? m_ClientRect.right : DrawPositionG;
						valRect2.setleft(valRect1).right;
						valRect2.right = (DrawPositionA == 0) ? m_ClientRect.right : DrawPositionA;
						valRect3.setleft(valRect2).right;
						valRect3.setright(m_drawvalue);
					} else {
						valRect1.setleft(valueRect).left;
						valRect1.right = (DrawPositionG == 0) ? m_ClientRect.right : DrawPositionG;
						valRect3.setleft(valRect1).right;
						valRect3.setright(m_drawvalue);
						//just make no rect
						valRect2.setleft(m_ClientRect).top;
						valRect2.setright(m_ClientRect).top;
						valRect2.setleft(m_ClientRect).top;
						valRect2.setright(m_ClientRect).top;
					}
				}
				brClr = CreateSolidBrush(RGB(0, 255, 0));
				FillRect(hdc, &valRect1, brClr);
				DeleteObject(brClr);
				brClr = CreateSolidBrush(RGB(255, 233, 30));				//amber colour, RGB from Jason Parker
				FillRect(hdc, &valRect2, brClr);
				DeleteObject(brClr);
				brClr = CreateSolidBrush(RGB(255, 0, 0));
				FillRect(hdc, &valRect3, brClr);
				DeleteObject(brClr);
			}
			break;
		case Based:
			///@todo, this type is not supported for Traffic light style. So, take care of this 
			//in properties window
			//as approved by Graham Cheale (3/18/05), Traffic light and Based types are incompatible. So, for now make
			//based type work similar to Solid Based Type until SCreen DEsigner handles
			//these incompatible types
			//colour the valueRect with above or Below Colour depending upon currval<basepoint or greater
			hBrushfore = CreateSolidBrush(*m_pForeColour);
			FillRect(hdc, &valueRect, hBrushfore);
			DeleteObject(hBrushfore);
			break;
		case Down:
			//backRect.bottom remain the same, valueRect.bottom moves
			//(MarkD) probably no requirement for log10 function here - it was removed from OnDraw
			//if(m_bLogScale)
			//{
			//	DrawPositionG=(int)(m_conv.CalcSourceToDestCapped((float)log10(m_pCMMBar->BreakPtGreen))+0.5);
			//	DrawPositionA=(int)(m_conv.CalcSourceToDestCapped((float)log10(m_pCMMBar->BreakPtAmber))+0.5);
			//}
			//else
			//{
			DrawPositionG = (int) (m_conv.CalcSourceToDestCapped(m_pCMMBar->BreakPtGreen) + 0.5);
			DrawPositionA = (int) (m_conv.CalcSourceToDestCapped(m_pCMMBar->BreakPtAmber) + 0.5);
			//}
			valRect1 = valRect2 = valRect3 = valueRect;
		if(m_CurrentValue<= m_pCMMBar->BreakPtGreen)
		{
			//colour valRect1 Green, valRect 2 amber if brekpointAmber > brekpoint Green
			//valRect3 Red
			if(m_pCMMBar->BarOrientation==OBJECT_VERTICAL)//vertical
			//if brekpointAmber is less than brekpoint Green, no Amber is shown
			{
				if(m_pCMMBar->Brere

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Op Panel
/// @n Filename: Screen.h 
/// @n Description: Screen class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 49	Stability Project 1.46.1.1	7/2/2011 5:01:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 48	Stability Project 1.46.1.0	7/1/2011 4:25:52 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 47	V6 Firmware 1.46		9/23/2008 3:09:32 PM	Build Machine 
//		AMS2750 Merge
// 46	V6 Firmware 1.45		3/23/2007 5:51:58 PM	Jason Parker 
//		Enable custom screens with status bar turned off to have status bar
//		hide and shown and screen moved down accordingly
// $
// 
//
// **************************************************************************
#ifndef _SCREEN_H
#define _SCREEN_H
#define SB_STARTSTOP		1
#define SB_SHIPPING			2 
#define SB_CUSTOM			3
class COpPanel;
class CTemplate;
/// Enum indicating the various custom button functions
typedef enum {
	cbtTC_USAGE_TIMER,
	cbtTUS_TIMER,
	cbtSAT_TIMER,
	cbtINST_CAL_TIMER,
	cbtCONTROL_TC_TIMER,
	cbtSTART_STOP_TUS,
	cbtCONFIGURE_TUS,
	cbtEXPORT_TUS,
	cbtTUS_TC_STABLE,
	cbtTUS_REMOVE_TCS,
	cbtTUS_RESTART_SOAK
} T_CUSTOM_BTN_TYPES;
//**Class*********************************************************************
///
/// @brief Screen class
/// 
/// This class maintain a list of Widgets built from the CMM info of the 
/// associated template
///
//****************************************************************************
class CScreen: public CLayoutItem {
public:
	COpPanel *m_pOpPanel;			///< keep pointer to our parent OpPanel
	T_SCREEN *m_pCMMscreen;			///< pointer to CMM... somtimes.
	T_SCREEN *m_pRealCMMscreen;		///< actual pointer to real CMM !
	CScreen *m_pNextScr;
	CWidget *m_pWidgets;
	CTemplate *m_pTemplate;			///< pointer to Template instance
	HRGN m_hrgnUpdate;
	QRect m_ScreenClientRect;
	CWidget *m_pSelectedWidget;	///< Currently selected widget (target for operations - different from showing handles)
	CWidget *m_pLastSelectedWidget;		///< last selected widget 
	QPoint m_StartPoint;
	BOOL m_DoneInitalDraw;		///< Used to prevent refresh before the full screen has been painted
	BOOL m_CheckpointRequired;
	QPoint m_ptCursorOffset;		///< Mouse down point in widget relative to widget to handle moving a sticky widget
	BOOL m_CannedScreenChanged;
	int m_pencount;					///< for replay use
	BOOL m_ScreenIsMoved;
	/// Variable indicating an uninitialised instance number
	static const USHORT ms_usUNINITIALISED_INSTANCE;
	/// Variable indicating an invalid widget/object channel number
	static const USHORT ms_usINVALID_CHANNEL_NO;
	/// Variable indicating the maximum number of screens allowed on a MULTITREND
	static const USHORT ms_usMAX_MULTI_SCREENS;
	/// Variable indicating the maximum number of screens allowed on a MINITREND
	static const USHORT ms_usMAX_MINI_SCREENS;
	/// Variable indicating the maximum number of screens allowed on an EZTREND
	static const USHORT ms_usMAX_EZ_SCREENS;
	//Variable for old xseries screen limits...
	static const USHORT ms_usMAX_XS_MULTI_SCREENS;
	static const USHORT ms_usMAX_XS_MINI_SCREENS;
	///// Variable indicating the maximum number of screens allowed on a MULTITREND
	//static const USHORT ms_usMAX_NON_PROCESS_SCREENS;
	CScreen(COpPanel *pParent);	///< constructor	
	~CScreen();					///< destructor
	virtual QString GetId();
	virtual QRect GetLayoutItemBounds() {
		return m_ScreenClientRect;
	}
	virtual COpPanel* GetOpPanel() {
		return m_pOpPanel;
	}
	void CMMInitScreen(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, BOOL IsNew); ///< One time Initialisation.	
	void ConfigChange(); ///< To be called when data item info changes (setup or Widget rotation etc)
	void Destroy();										///< Clean-up function 
	USHORT ChannelToInstance(int channel);
	// Method that sets the screen instnace corresponding to the widget channel number
	const bool SetScreenInstance(const USHORT usWIDGET_CHAN_NUM, const USHORT usREQUIRED_INSTANCE);
	BOOL IsNearHoriz(int nHoriz, int &nHorizNear);						///< Used for moving/resizing a sticky widget
	BOOL IsNearVert(int nVert, int &nVertNear);	///< Used for moving/resizing a sticky widget
	//virtual void InitItemProp();
	void AddNewWidget(CLayoutConfiguration *pConfig, BLOCK_INFO *blockInfo, QRect *bounds);
	CWidget* indexOfWidgetInstance(T_LAYOUTITEM *LayoutItem);
	BOOL MatchLayoutItem(T_LAYOUTITEM *LayoutItem);
	T_LAYOUTITEM GetLayoutItem();
	BOOL IsCannedScreen();
	void PopulateCannedScreen();
	void PopulateReplayScreen();
	void PopulateHotSoakScreen();
	BOOL AddDPMContents(CLayoutConfiguration *pconfig, int PenIndex, BOOL HasMaxMin, BOOL HasTotal, BOOL IsReplay =
			FALSE);
	QRect SplitRectDPM(int RectIndex, int TotalRects, QRect FullArea);
	BOOL AddBarVContents(int PenIndex, BOOL HasMaxMin, BOOL HasTotal);
	QRect SplitRectBarsV(int RectIndex, int TotalRects, QRect FullArea);
	BOOL AddBarHContents(int PenIndex, BOOL HasMaxMin, BOOL HasTotal);
	QRect SplitRectBarsH(int RectIndex, int TotalRects, QRect FullArea);
	CBaseObject* AddIndicatorVContents(int PenIndex, BOOL HasPointer, BOOL HasAlaramMarkers, BOOL IsRotating,
			CBaseObject *pLinkObj);
	CBaseObject* AddIndicatorHContents(int PenIndex, BOOL HasPointer, BOOL HasAlaramMarkers, BOOL IsRotating,
			CBaseObject *pLinkObj);
	// Accessor method for the screen CMM item
	T_PSCREEN GetCMMScreen() {
		return m_pRealCMMscreen;
	}
	void AppendWidget(CWidget *pWgt);
	BOOL RemoveWidget(CWidget *pWgt);
	BOOL BringWidgetToTop(CWidget *pWgt);
	BOOL SendWidgetToBottom(CWidget *pWgt);
	void InvalidateArea(QRect area);
	void Refresh();
	void DrawScreen(QRect *pClipRect);
	void ShowRecScreenArea(); ///< screen designer function only
	void ShowInfo();
	void UnselectAll();
	void OnChar(wchar_t ch);				///< User input (keyboard or SIP)
	void OnMouseDown(UINT nFlags, QPoint &point);			///< Mouse button down (or touch screen touched) at point
	void OnMouseUp(UINT nFlags, QPoint &point);	///< Mouse button up (or touchscreen)
	void OnMouseMove(UINT nFlags, QPoint &point);	///< Dragging on screen with mouse or touchscreen
	void OnMouseDownRuntime(UINT nFlags, QPoint &point);	///< Mouse button down (or touch screen touched) at point
	void OnMouseUpRuntime(UINT nFlags, QPoint &point);	///< Mouse button up (or touchscreen)
	void OnReplayWidgetClick();
	void OnMouseMoveRuntime(UINT nFlags, QPoint &point);	///< Dragging on screen with mouse or touchscreen
	void MatchColour(CWidget *pkWidget);
	// Mehod that returns true if screen is non process screen
	BOOL IsNonProcessScreen() {
		return m_pCMMscreen->Type >= TPL_ALARM && m_pCMMscreen->Type < TPL_NP_LAST;
	}
	// Mehod that returns true if the Pen is currently displed on active screen
	BOOL IsPenSelected(T_PEN *ptPenData);
	// Mehod that returns true if the Script Timer is currently displed on active screen
	BOOL IsItemSelected(CPickerData *ptPickerData, USHORT usCurrItem, T_CFG_DATA_TYPE dataType, int MaxItems);
	// Helper method used to determine if the screen contains any chart objects
	const BOOL IsShowingCircularChart() const;
	// Helper method used to determine if the screen is currently displaying a realtime or historical circular chart
	const BOOL IsShowingRealtimeCircularChart() const;
	// Method used to put any circular charts the screen may be displaying into and out of
	// showing realtime and historical data
	void SetCircularChartMode(const bool showRealtime);
private:
	// Method that populates the tabular process screen
	void PopulateTabularProcessScreen(const QRect tSCREEN_AREA, const int iPEN_COUNT);
	// Method that populates the AMS2750 process screen
	void PopulateAMS2750ProcessScreen(const QRect tSCREEN_AREA, const int iPEN_COUNT, const int iSCALE_COUNT);
	// Method that populates the AMS2750 TUS screen
	void PopulateAMS2750TUSScreen(const QRect tSCREEN_AREA, const int iPEN_COUNT);
	// Method that populates the AMS2750 TUS title rect
	void PopulateTUSTitleRect(const QRect tTITLE_RECT);
	// Method that populates the AMS2750 TUS status rect
	void PopulateTUSStatusRect(const QRect tSTATUS_RECT);
	// Method that populates the AMS2750 TUS chart rect
	void PopulateTUSChartRect(const QRect tCHART_RECT);
	// Method that populates the AMS2750 TUS DPM area
	void PopulateTUSDPMArea(const QRect tDPM_AREA);
	//PSR - 1-27DX2UY begin
	float getResolutionFactor();
	float getNormalizedResFactor();
	//PSR - 1-27DX2UY end
};
#endif

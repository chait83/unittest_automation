/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ButtonObj.cpp
/// @n Description: Button Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  9 Stability Project 1.4.1.3 7/2/2011 4:55:47 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  8 Stability Project 1.4.1.2 7/1/2011 4:38:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  7 Stability Project 1.4.1.1 3/17/2011 3:20:12 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  6 Stability Project 1.4.1.0 2/15/2011 3:02:20 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "AMS2750TCStatusMgr.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
// Colours used for illustrating the various button conditions
const COLORREF CButtonObject::ms_crOK = QString(0, 255, 0);
const COLORREF CButtonObject::ms_crWarning = QString(255, 169, 99);
const COLORREF CButtonObject::ms_crError = QString(255, 0, 0);
const COLORREF CButtonObject::ms_crInactive = QString(127, 127, 127);
//****************************************************************************
/// CButtonObject Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
/// 
//****************************************************************************
CButtonObject::CButtonObject(CWidget *pParentWidget) : CBaseObject(pParentWidget) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CButtonObject::OnDraw;
	// set all of the objects internal settings to defaults
	m_pDataItemRef = NULL;
	m_DrawButtonDown = FALSE;
	m_ButtonIsDown = FALSE;
	m_ButtonID = SB_CUSTOM;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
/// 
//****************************************************************************
void CButtonObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CButtonObject data in CMM info block.
	m_pCMMbutton = (T_BUTTONOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		m_pCMMbutton->ChannelInfo.Enabled = TRUE; // button objects are enabled for dataitem by default.
		m_pCMMbutton->ChannelInfo.Updates = FALSE; // but they don't get updated.
		// m_pCMMbase->BackColour=RGB565toRGB(m_pWidget->m_pCMMwidget->BackColour);
		m_pCMMbase->BackColour = QString(180, 180, 180); // mid grey
		m_pCMMbase->FixBackColour = TRUE;
		m_pCMMbase->ForeColour = QString(0, 0, 0);
		m_pCMMbase->FixForeColour = TRUE;
		m_pCMMbutton->Font.Quality = 1; // antialias
		m_pCMMbutton->Style = 1;
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
		m_pCMMbutton->ChannelInfo.Updates = FALSE; // ensure button Objects do not get updated.
	}
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CButtonObject::ConfigChange() {
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	// Data item configuration done here. 
	// CButtonObject only has one data item reference
	BOOL refValid = FALSE;
	if (!m_pDataItemRef) {
		// for button objects, only create a reference if required
		if (m_pCMMbutton->ChannelInfo.Enabled)
			m_pDataItemRef = new CDataItemRef(this);	// create our single reference
	}
	if ((m_pDataItemRef) && (m_pWidget->GetDataItem(m_pDataItemRef, &m_pCMMbutton->ChannelInfo)))
		refValid = TRUE;
	if (m_pCMMbutton->Style == WINDOWS_STYLE) {
		m_pCMMbutton->Base.Border.BorderUsed = 1;
		m_pCMMbutton->Base.Border.BorderWidth = 1;
		m_pCMMbutton->Base.Border.BorderStyle = bsFLAT;
		m_pCMMbutton->Base.Border.BorderColour = 0;
	} else {
		m_pCMMbutton->Base.Border.BorderUsed = 1;
		m_pCMMbutton->Base.Border.BorderWidth = 3;
		m_pCMMbutton->Base.Border.BorderStyle = bsRAISED;
		m_pCMMbutton->Base.Border.BorderColour = m_pCMMbase->BackColour;
	}
	// Now set our members based on CMM settings and data item info
	// T_BASEOBJECT CMM config to CBaseObject members:
	// set our internal members values from the Attribute block or source or CMM 
	// HERE may want to do something different for buttons, since they are not 'pen' related as such
	// so the foreground and background are already fixed.
	// use foreground colour from CMM (e.g. as selected in Screen Designer) as default
	m_pForeColour = &m_pCMMbase->ForeColour;
	if (!m_pCMMbase->FixForeColour) {
		if (m_pCMMbase->AttrBlocks.ForeColourBlk)
			// use foreground colour from Attribute block
			m_pForeColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
					m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
		else if (refValid)
			m_pForeColour = m_pDataItemRef->m_pDataItem->GetColour();// use foreground colour from Data Item Table item		
	}
	// use background colour from CMM (e.g. as selected in Screen Designer) as default
	m_pBackColour = &m_pCMMbase->BackColour;
	if (!m_pCMMbase->FixBackColour) {
		if (m_pCMMbase->AttrBlocks.BackColourBlk)
			// use foreground colour from Attribute block
			m_pBackColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
					m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
		else if (refValid)
			m_pBackColour = m_pDataItemRef->m_pDataItem->GetColour();// use background colour from Data Item Table item
	}
}
//****************************************************************************
///
/// Drawing function. 
/// This function must do all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed, and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. In both cases the function must 
/// draw *at least* as much as defined by the Clipping Rectangle. Any addtional
/// drawing that is done (outside of the ClipRect) will have no effect, but in 
/// some cases it is easier (and quicker) to simply draw everything for the 
/// Object rather than work out those parts actually required.
///
///	NB: the ClipRect pointer can be NULL indicating the draw is the result of
/// a data update. if m_UpdateRequired is set, then the complete Object should
/// be fully redrawn. If not, the Object can inspect Widgets m_UpdateRgn
/// to see if an optimised draw is possible. At least part of the Object will 
/// be contained in the region for the draw function to have been called
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CButtonObject::OnDraw(CButtonObject *pThis, HDC hdc, QRect *pClipRect) {
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	// if Update Required make any updates due to data item changes then do a repaint
	if (pThis->m_UpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object, 
		// so that we can draw the same value next time if required.
		// does not really apply to button objects !!
		pThis->m_UpdateValue = FALSE;
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	} else {
		// i.e. m_UpdateRequired is FALSE - no data update here
		if (pClipRect == NULL) {
			// Optimised drawing for overlapped objects:
			// here we are drawing because of an update to some other object that overlaps.	
			// We could inspect our parent widget's update region to see how much we need to 
			// draw, setting ObjClipRect, or simply draw everything.
		}
	}
	// Optimised drawing for direct foreground:
	// here if pClipRect is null (drawing an update)
	// we could check the pThis->m_pCMMbase->IsBuffered flag.
	// For updates to a non-buffered Object (direct foreground) we can optimise our
	// drawing (just the updating parts) knowing that this object does not overlap any other,
	// (therefore the rest of the object will still be OK)
	if (pThis->m_pCMMbutton->Style != WINDOWS_STYLE) {
		if (pThis->m_DrawButtonDown)
			pThis->m_pCMMbutton->Base.Border.BorderStyle = bsINSET; // inset
		else
			pThis->m_pCMMbutton->Base.Border.BorderStyle = bsRAISED; // raised
	}
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	BOOL DrawInFlashState = FALSE;
	if (*(pThis->m_pFlashing)) // if we are flashing set our drawInFlashState.
		DrawInFlashState = pThis->m_FlashState;
	QRect buttrect = pThis->m_ClientRect;
	QRect textrect = buttrect;
	if (pThis->m_pCMMbutton->Style == WINDOWS_STYLE) {
		InflateRect(&textrect, -2, -2);
		//colours taken from XP
		QPen hPenWhite = ::CreatePen(PS_SOLID, 0, QString(255, 255, 255));
		QPen hPenKaki = ::CreatePen(PS_SOLID, 0, QString(241, 239, 226));
		QPen hPenLtGry = ::CreatePen(PS_SOLID, 0, QString(157, 157, 161));
		QPen hPenDkGry = ::CreatePen(PS_SOLID, 0, QString(113, 111, 100));
		// do not draw on the bottom or rightmost edge
		buttrect.right--;
		buttrect.bottom--;
		if (!pThis->m_DrawButtonDown) {
			// first white pen.
			QPen oldpen = (QPen) SelectObject(hdc, hPenWhite);
			MoveToEx(hdc, buttrect.right, buttrect.top, NULL);
			LineTo(hdc, buttrect.left, buttrect.top);
			LineTo(hdc, buttrect.left, buttrect.bottom);
			// now dk grey
			SelectObject(hdc, hPenDkGry);
			LineTo(hdc, buttrect.right, buttrect.bottom);
			LineTo(hdc, buttrect.right, buttrect.top - 1);
			InflateRect(&buttrect, -1, -1);
			// now khaki
			SelectObject(hdc, hPenKaki);
			MoveToEx(hdc, buttrect.right, buttrect.top, NULL);
			LineTo(hdc, buttrect.left, buttrect.top);
			LineTo(hdc, buttrect.left, buttrect.bottom);
			// now light grey
			SelectObject(hdc, hPenLtGry);
			LineTo(hdc, buttrect.right, buttrect.bottom);
			LineTo(hdc, buttrect.right, buttrect.top - 1);
			SelectObject(hdc, oldpen);
			InflateRect(&buttrect, -1, -1);
			buttrect.right++;
			buttrect.bottom++;
		} else {
			// light grey
			QPen oldpen = (QPen) SelectObject(hdc, hPenLtGry);
			MoveToEx(hdc, buttrect.left, buttrect.top, NULL);
			LineTo(hdc, buttrect.left, buttrect.bottom);
			LineTo(hdc, buttrect.right, buttrect.bottom);
			LineTo(hdc, buttrect.right, buttrect.top);
			LineTo(hdc, buttrect.left, buttrect.top);
			SelectObject(hdc, oldpen);
			InflateRect(&buttrect, -1, -1);
			buttrect.right++;
			buttrect.bottom++;
			OffsetRect(&textrect, 1, 1);
		}
		DeleteObject(hPenWhite);
		DeleteObject(hPenKaki);
		DeleteObject(hPenLtGry);
		DeleteObject(hPenDkGry);
	} else {
		if (pThis->m_DrawButtonDown) {
			InflateRect(&textrect, -1, -1);
		}
	}
	CFontCache *pfc = CFontCache::GetHandle();
	QFont hfont;
	if (pThis->m_ButtonID == SB_CUSTOM) {
		hfont = pfc->GetFont(pThis->m_pCMMbutton->Font.Height,
				pfc->ConvertFontWeight(static_cast<CFontCache::T_FONT_WEIGHT>(pThis->m_pCMMbutton->Font.Weight)),
				pThis->m_pCMMbutton->Font.Face,
				pfc->ConvertFontQuality(static_cast<CFontCache::T_FONT_QUALITY>(pThis->m_pCMMbutton->Font.Quality))); // Objects Client Area (bounds less border)
	} else {
		hfont = pfc->GetFont(_Height(textrect),
				pfc->ConvertFontWeight(static_cast<CFontCache::T_FONT_WEIGHT>(pThis->m_pCMMbutton->Font.Weight)),
				pThis->m_pCMMbutton->Font.Face,
				pfc->ConvertFontQuality(static_cast<CFontCache::T_FONT_QUALITY>(pThis->m_pCMMbutton->Font.Quality))); // Objects Client Area (bounds less border)
	}
	QFont hOldfont = (QFont) SelectObject(hdc, hfont);
	if (DrawInFlashState)
		SetTextColor(hdc, *pThis->m_pBackColour);
	else
		SetTextColor(hdc, *pThis->m_pForeColour);
	QString strCustomBtnText("");
	if (pThis->m_pCMMbase->IsTransparent)
		SetBkMode(hdc, TRANSPARENT); // this works like v5. Need full repaint of background to work ok.
	else {
		// DrawText does not fill the rectangle passed as ExtTextOut does.
		// could make this configurable if we wanted to not do it.
		HBRUSH hBrushback; // Create a brush for background
		if (pThis->m_ButtonID == SB_CUSTOM) {
			COLORREF crBkgCol = 0;
#ifndef DOCVIEW
			// get the button text required for custom buttons now as well as setting up the background colours
			switch (pThis->m_pCMMbutton->Type) {
			case cbtTC_USAGE_TIMER: {
				CAMS2750TCStatusMgr *pkTCStatusMgr = CAMS2750TCStatusMgr::Instance();
				// setup the button text first
				if (pkTCStatusMgr->NoTrackedTCs()) {
					strCustomBtnText = tr("NA");
				} else {
					strCustomBtnText = pThis->m_pCMMbutton->Text;
				}
				if (pkTCStatusMgr->TCInExpiredState()) {
					crBkgCol = ms_crError;
				} else if (pkTCStatusMgr->TCInWarningState()) {
					crBkgCol = ms_crWarning;
				} else if (pkTCStatusMgr->NoTrackedTCs()) {
					crBkgCol = ms_crInactive;
				} else {
					crBkgCol = ms_crOK;
				}
			}
				break;
			case cbtTUS_TIMER: {
				CAMS2750TimerCtrlMgr *pkTimerCtrlMgr = CAMS2750TimerCtrlMgr::Instance();
				// setup the button text first
				if (pkTimerCtrlMgr->GetTimerStatus(AMS2750_TIMER_TYPE_TUS,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex)
						== CAMS2750TimerCtrlMgr::TIMER_DISABLED) {
					strCustomBtnText = tr("NA");
				} else {
					strCustomBtnText = QString::asprintf(IDS_AMS2750_TIMER_BTN_DAYS_TITLE,
							pkTimerCtrlMgr->GetDaysUntilCalExpiry(AMS2750_TIMER_TYPE_TUS,
									pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex));
				}
				crBkgCol = SetTimerBtnCol(AMS2750_TIMER_TYPE_TUS,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex);
			}
				break;
			case cbtSAT_TIMER: {
				CAMS2750TimerCtrlMgr *pkTimerCtrlMgr = CAMS2750TimerCtrlMgr::Instance();
				// setup the button text first
				if (pkTimerCtrlMgr->GetTimerStatus(AMS2750_TIMER_TYPE_SAT,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex)
						== CAMS2750TimerCtrlMgr::TIMER_DISABLED) {
					strCustomBtnText = tr("NA");
				} else {
					strCustomBtnText = QString::asprintf(IDS_AMS2750_TIMER_BTN_DAYS_TITLE,
							pkTimerCtrlMgr->GetDaysUntilCalExpiry(AMS2750_TIMER_TYPE_SAT,
									pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex));
				}
				crBkgCol = SetTimerBtnCol(AMS2750_TIMER_TYPE_SAT,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex);
			}
				break;
			case cbtINST_CAL_TIMER: {
				CAMS2750TimerCtrlMgr *pkTimerCtrlMgr = CAMS2750TimerCtrlMgr::Instance();
				// setup the button text first
				if (pkTimerCtrlMgr->GetTimerStatus(AMS2750_TIMER_TYPE_INST_CAL,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex)
						== CAMS2750TimerCtrlMgr::TIMER_DISABLED) {
					strCustomBtnText = tr("NA");
				} else {
					strCustomBtnText = QString::asprintf(IDS_AMS2750_TIMER_BTN_DAYS_TITLE,
							pkTimerCtrlMgr->GetDaysUntilCalExpiry(AMS2750_TIMER_TYPE_INST_CAL,
									pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex));
				}
				crBkgCol = SetTimerBtnCol(AMS2750_TIMER_TYPE_INST_CAL,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex);
			}
				break;
			case cbtCONTROL_TC_TIMER: {
				CAMS2750TimerCtrlMgr *pkTimerCtrlMgr = CAMS2750TimerCtrlMgr::Instance();
				// setup the button text first
				if (pkTimerCtrlMgr->GetTimerStatus(AMS2750_TIMER_TYPE_CONTROL_TC,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex)
						== CAMS2750TimerCtrlMgr::TIMER_DISABLED) {
					strCustomBtnText = tr("NA");
				} else {
					strCustomBtnText = QString::asprintf(IDS_AMS2750_TIMER_BTN_DAYS_TITLE,
							pkTimerCtrlMgr->GetDaysUntilCalExpiry(AMS2750_TIMER_TYPE_CONTROL_TC,
									pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex));
				}
				crBkgCol = SetTimerBtnCol(AMS2750_TIMER_TYPE_CONTROL_TC,
						pThis->m_pWidget->m_pScreen->m_pCMMscreen->GroupIndex);
			}
				break;
			case cbtSTART_STOP_TUS:
				// use the normal button colour
				crBkgCol = *pThis->m_pBackColour;
				// for now use the normal button text but in the future this will
				// need to toggle depending on whether a TUS is running
				strCustomBtnText = pThis->m_pCMMbutton->Text;
				break;
			case cbtEXPORT_TUS:
			case cbtCONFIGURE_TUS:
			case cbtTUS_TC_STABLE:
			case cbtTUS_REMOVE_TCS:
			case cbtTUS_RESTART_SOAK:
			default:
				// use the normal button colour
				crBkgCol = *pThis->m_pBackColour;
				// use the configured button text
				strCustomBtnText = pThis->m_pCMMbutton->Text;
				break;
			}
#else
			// just set all the buttons to the okay state (usually green)
			crBkgCol = ms_crOK;
#endif
			SetBkColor(hdc, crBkgCol);
			hBrushback = CreateSolidBrush(crBkgCol);
		} else {
			if (DrawInFlashState) {
				SetBkColor(hdc, *pThis->m_pForeColour);
				hBrushback = CreateSolidBrush(*pThis->m_pForeColour);
			} else {
				SetBkColor(hdc, *pThis->m_pBackColour);
				hBrushback = CreateSolidBrush(*pThis->m_pBackColour);
			}
		}
		FillRect(hdc, &buttrect, hBrushback);
		// Delete the brush object and free all resources associated with it.
		DeleteObject(hBrushback);
	}
	// check which button type this is before drawing the text
	if (pThis->m_ButtonID == SB_CUSTOM) {
		// use DrawText rather than ExtTextOut here, since required for wordwrap option.
		if (strCustomBtnText != "") {
			DrawText(hdc, strCustomBtnText, strCustomBtnText.size(), &textrect,
					DT_NOPREFIX | DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		}
	} else {
		// use DrawText rather than ExtTextOut here, since required for wordwrap option.
		UINT len = (UINT) wcslen(pThis->m_pCMMbutton->Text);
		if (len)
			DrawText(hdc, pThis->m_pCMMbutton->Text, len, &textrect, DT_NOPREFIX | DT_CENTER | DT_SINGLELINE);
	}
	SetBkMode(hdc, OPAQUE); // restore it after possibly setting transparent above
	SelectObject(hdc, hOldfont);
	pfc->ReleaseFont(hfont);
}
//****************************************************************************
///
/// Handles Mouse down on button
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CButtonObject::OnMouseDown(UINT nFlags, QPoint &point) {
	m_ButtonIsDown = TRUE;
	m_DrawButtonDown = TRUE;
	m_pWidget->InvalidateArea(GetBounds());
}
//****************************************************************************
///
/// Handles mouse move for button
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CButtonObject::OnMouseMove(UINT nFlags, QPoint &point) {
	if (nFlags & MK_LBUTTON) // leftbutton down
			{
		// see if user has now moved outside of client bounds	
		BOOL buttonDownstate = m_ButtonIsDown;
		if (!PtInRect(&GetBounds(), point))
			buttonDownstate = FALSE;
		if (m_DrawButtonDown != buttonDownstate) {
			m_DrawButtonDown = buttonDownstate;
			m_pWidget->InvalidateArea(GetBounds());
		}
	}
}
//****************************************************************************
///
/// Handler for mouse/touchscreen up
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CButtonObject::OnMouseUp(UINT nFlags, QPoint &point) {
	if (m_ButtonIsDown && m_DrawButtonDown) {
		qDebug("SELECTED !!!!\n");
		if (m_ButtonID <= SB_SHIPPING) {
			AfxGetMainWnd()->PostMessage(WM_SOFTBUTTON, m_ButtonID, m_pWidget->m_pScreen->m_pCMMscreen->Number);
		} else {
			CButtonObject *pkButtonObj = dynamic_cast<CButtonObject*>(m_pWidget->m_pSelectedObject);
			if (pkButtonObj != NULL) {
				AfxGetMainWnd()->PostMessage(WM_SOFTBUTTON, pkButtonObj->m_pCMMbutton->Type,
						m_pWidget->m_pScreen->m_pCMMscreen->Number);
			}
		}
	}
	m_ButtonIsDown = FALSE;
	m_DrawButtonDown = FALSE;
	m_pWidget->InvalidateArea(GetBounds());
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CButtonObject::Destroy() {
}
//****************************************************************************
/// QString CButtonObject::GetTextString() 
/// 
/// Method that returns a pointer to an internal string that is a copy of the text string held in
/// the CMM
///
/// @return A pointer to an internal string that is a copy of the text string held in the CMM
///
//****************************************************************************
QString  CButtonObject::GetTextString() {
	return m_pCMMbutton->Text;
}
//****************************************************************************
/// 
/// Sets the internal string in the CMM
///
/// @param[in] pText	- text to set
/// @return none
///
//****************************************************************************
void CButtonObject::SetTextString(QString pText) {
	CStringUtils::SafeWcsCpy(m_pCMMbutton->Text, pText, BUTTONOBJECT_TEXT_LEN);
	ConfigChange();
}
#ifndef DOCVIEW	
//****************************************************************************
/// 
/// Method that obtains the required background colour for an AMS2750 timer
///
/// @param[in]	const T_AMS2750_TIMER_TYPES eTIMER_TYPE - The timer type we are checking
/// @param[in]	const USHORT usGROUP_NO - THe group number of the screen this button is on
///
/// @return The required colour given the passed in timers current state
///
//****************************************************************************
const COLORREF CButtonObject::SetTimerBtnCol(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO) {
	CAMS2750TimerCtrlMgr *pkTimerCtrlMgr = CAMS2750TimerCtrlMgr::Instance();
	COLORREF crBkgCol = 0;
	switch (pkTimerCtrlMgr->GetTimerStatus(eTIMER_TYPE, usGROUP_NO)) {
	case CAMS2750TimerCtrlMgr::TIMER_GOOD:
		crBkgCol = ms_crOK;
		break;
	case CAMS2750TimerCtrlMgr::TIMER_WARNING:
		crBkgCol = ms_crWarning;
		break;
	case CAMS2750TimerCtrlMgr::TIMER_EXPIRED:
		crBkgCol = ms_crError;
		break;
	case CAMS2750TimerCtrlMgr::TIMER_DISABLED:
	default:
		crBkgCol = ms_crInactive;
		break;
	}
	return crBkgCol;
}
#endif

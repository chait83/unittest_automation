/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: TabularDisplayObject.h
/// @n Description: TabularDisplay Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:01:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:25:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 9/23/2008 12:21:12 PM  Build Machine  
// $
//
// **************************************************************************
#ifndef _TABULARDISPLAYOBJECT_H
#define _TABULARDISPLAYOBJECT_H
#include "TabularReadings.h"
const int MAX_TABULAR_PENS = SCREEN_CANNEDPENS_SIZE; // max pens in a tabular display object
//**CTabularDisplayObject ****************************************************
///
/// @brief Tabular Display Object
/// 
/// This class is a simple standard drawn object for the tabular display object
/// which is derived from the CBaseObject class.
///
//****************************************************************************
class CTabularDisplayObject: public CBaseObject {
private:
	CDataItemRef *m_pDataItemRef[MAX_TABULAR_PENS];	///< Data item table references (enabled pens sorted by pen number).
	T_TABULAROBJECT *m_pCMMTabDisp;	///< Pointer to our CMM configuration
	CFFConversionInfo m_ci[MAX_TABULAR_PENS];
	BOOL m_bCurrentAlarm[MAX_TABULAR_PENS]; ///< Alarm flag for each pen pointer - not used currently
	T_PSCALEINFO m_patScaleInfo[MAX_TABULAR_PENS]; ///< Current scale information for each pen
	WCHAR m_awcasprintfStr[MAX_TABULAR_PENS][20]; ///< asprintfted string for each pen value - used as a quick means of creating the formatted string
	int m_iInnerDataRowStartPos;		///< The start position of ther first inner data row
	int m_iDifferentReadingsSeperation; ///< The seperation between seperate sets of readings
	int m_iInnerDataRowHeight;			///< The height of the inner data row readings
	int m_iInnerDataRowEndPos;			///< The end position of ther last inner data row
	int m_iInnerDataRowHorizBorder;		///< The width of the horizontal border for the data rows
	USHORT m_usNoOfCols;				///< Variable indicating the numbers of columns for this device type
	USHORT m_usNoOfSetsOfSingleReadings;				///< Variable indicating the number of sets of data reading that
														///< are on display
	USHORT m_usNoOfRowsPerSetOfReadings;					///< Variable indicating the number of rows required for a
															///< complete set of readings
	COLORREF m_crInnerBorderColour;		///< Variable indicating the border colour for the inner area
	COLORREF m_crCellBackGndColour;		///< Variable indicating the the background colour of the cells containing
										///< individual readings
	COLORREF *m_pForeAlarmColour;  ///< Colour for flashing foreground on pen pointer
	int m_nNumPens;					///< Number of pen pointers shown in pen pointers object
									///< Equal to the number of enabled pen channels in widget
	BOOL m_bInAlarm;				///< Is any pen pointer in alarm? - not used currently
	// Derived objects must draw themselves.
	// Called via the m_pOnDraw pointer to function.
	static void OnDraw(CTabularDisplayObject *pThis, HDC hdc, QRect *pClipRect);
	static int CompareDataItemRefs(const void *arg1, const void *arg2);
	static int GetPenNumber(CDataItemRef *pDataItemRef);
	int GetPenNumber(int nLane);
	// This function will setup the correct rect sizes and seperations for the cells
	void DetermineRectSizes();
public:
	virtual void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);///< set bounds of the object relative to the CScreen's top left corner.
	// Constructor
	CTabularDisplayObject(CWidget *pWidget);
	// overidden functions that must be supplied
	virtual void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	virtual void ConfigChange();								///< config changes	
	virtual void Destroy();
	// Accessor method that indicates if the tabular readings have been updated and thus this object need 
	// updating
	const bool UpdateTableRequired() const;
	// Method that resets the flag that indicates the tabular readings have been updated - usually reset after 
	// the update flag for the object has been set
	void ResetUpdateTableFlag();
	static const USHORT ms_usQX_NO_OF_PEN_COLS;	///< Const indicating the number of pen columns on a QX/QXe
	static const USHORT ms_usSX_NO_OF_PEN_COLS; ///< Const indicating the number of pen columns on an SX
	static float m_fResFactor;
	void getResFactorFromOpPanel();
};
#endif

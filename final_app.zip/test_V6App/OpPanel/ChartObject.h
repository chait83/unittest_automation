/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ChartObject.h
/// @n Description: Derived Object 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  35  Stability Project 1.32.1.1 7/2/2011 4:56:04 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  34  Stability Project 1.32.1.0 7/1/2011 4:25:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  33  V6 Firmware 1.32 4/12/2007 8:09:17 PM  Jason Parker  
//  Added EDF timestamps and corrected vertical chart bottom-1 issues.
//  32  V6 Firmware 1.31 3/14/2007 3:35:42 PM  Jason Parker  The
//  zooming methods have been modified to ensure that any errors in time
//  calculations do not get magnified by zooming
// $
//
// **************************************************************************
#ifndef _CHARTOBJ_H
#define _CHARTOBJ_H
#define MAX_CHART_PENS 32
enum ChartMode {
	AUTO_SCROLL,
	REPLAY, REPLAY_FULLSCREEN, REPLAY_LOCATOR
};
enum UPDATE_STRIP_TYPE {
	UPDATE_NONE = 0, UPDATE_STRIP, UPDATE_FULLWIDTH
};
//**Class*********************************************************************
///
/// @brief ChartObject Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used as a 'template' for all other derived Objects.
///
//****************************************************************************
class CChartObject: public CBaseObject {
public: // make private (only public for testing)
	T_CHARTOBJECT *m_pCMMchart;	///< pointer to our CMM configuration
private:
	CDataItem *m_pChartDataItem[MAX_CHART_PENS];
	CChartQ *m_pChartQ[MAX_CHART_PENS];
	BOOL m_Initialised[MAX_CHART_PENS];
	LONGLONG m_latestDataSeen[MAX_CHART_PENS];
	LONGLONG m_lastestMessageSeen;
	CChartMessageQ *m_pMessageQ;
	BOOL m_InitialisedMessages;
	CFFConversionInfo m_convInfo[MAX_CHART_PENS];
	int m_pos1;
	int m_pos2;
	int m_GroupNumber;
	int m_enabledChartPens;
	int m_ThickestPen;
	CGrads m_grads;
	ChartMode m_mode;
	BOOL m_KeepOrigin;
	LONGLONG m_startpos;
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CChartObject *pThis, HDC hdc, QRect *pClipRect);
	//E437415
	//LPDIRECTDRAWSURFACE4	m_pDDSprivate;		///< DirectDraw private surface 	
	LPDIRECTDRAWSURFACE m_pDDSprivate;		///< DirectDraw private surface 	
	BOOL m_TSalpha;
	int m_TSinterval;
	int m_ChartSpan;
	LONGLONG m_TimePos1;
	LONGLONG m_TimePos2;
	COLORREF *m_pTScolour;
	COLORREF *m_pBackAlarmColour;
	COLORREF *m_pMessageColour;
	COLORREF m_TScolour;
	COLORREF m_MajorColour;
	COLORREF m_MinorColour;
	COLORREF m_HeavyGrey;
	LONGLONG m_LastUpdateTime;
	BOOL m_EdFstamps;
	int m_ScrollAmount;
	QRect m_drawArea;
	T_MSGLISTSER_MESSAGE m_BaseAlarmMessage;
	LONGLONG m_BaseAlarmMessageTime;
	BOOL CreateSurface();
	void CalcTimestampsRect();
	void CalcTimestampBases();
	void UpdateTimestampBases();
	void DrawGradlinesH(HDC sdc);
	void DrawGradlinesV(HDC sdc);
	void DrawTracesH(HDC sdc, BOOL IsAnUpdate);
	void DrawTracesV(HDC sdc, BOOL IsAnUpdate);
	void DrawTimestampsH(HDC sdc, BOOL showLines);
	void DrawTimestampsV(HDC sdc, BOOL LinesOnly);
	void DoMove();
	void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL); // virtual function override
	void SetNMode(); // testing only
public:
	CChartObject(CWidget *pWidget);
	~CChartObject();
	ChartSpeed m_ChartSpeed; // SPEED_FAST
	LONGLONG m_Origin100;
	int m_Tpp;
	int m_ScrollAmount2;
	int m_TSfontHeight;
	QRect m_TSrect;
	WCHAR m_longestMonthBuff[20];
	void ReleaseSurfaces() {
		if (m_pDDSprivate) {
			m_pDDSprivate->Release();
			m_pDDSprivate = NULL;
		}
	}
	BOOL CheckPosition(LONGLONG time100, int chartspan);
	UPDATE_STRIP_TYPE GetUpdateStrip(QRect *strip, int chartspan);
	BOOL GetUpdateSpan(QRect *span);
	void SetReplayMode();
	void ZoomIn(LONGLONG cursorTime);
	void ZoomOut(LONGLONG cursorTime);
	BOOL SetViewTime(LONGLONG viewTime);
	void JumpToPrev();
	void JumpToNext();
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
	BOOL GetUpdateRect(QRect *pUpdateRect, LONGLONG time100);
	// optional overrides
	LinkOrientation GetLinkOrient();
	BOOL CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2);///< calculate the link positions from the object limits
	BOOL CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2);///< baseobject version does not impose any restrictions
	void OnChar(wchar_t ch);						///< User input (keyboard or SIP)
	void OnMouseDown(UINT nFlags, QPoint &p);	///< Mouse button down (or touch screen touched) at point
	void OnMouseUp(UINT nFlags, QPoint &p);		///< Mouse button up (or touchscreen)
	void OnMouseMove(UINT nFlags, QPoint &p);	///< Dragging on screen with mouse or touchscreen
	BOOL m_bIsReplayWidget;
};
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: AlarmMarkerObject.h
/// @n Description: Alarm Marker Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  22  Stability Project 1.19.1.1 7/2/2011 4:55:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  21  Stability Project 1.19.1.0 7/1/2011 4:25:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  20  V6 Firmware 1.19 12/14/2005 2:40:33 AM  David Fulmer (Ft
//  Washington) Changed zero and span positions of alarm markers object
//  to behave like the scale object
//  19  V6 Firmware 1.18 11/22/2005 9:53:03 PM  David Fulmer (Ft
//  Washington) Fixed problem with keeping the link positions aligned for
//  multiple scale instances on multiple custom screens using the same
//  template
// $
//
// **************************************************************************
#ifndef _ALARMMARKEROBJECT_H
#define _ALARMMARKEROBJECT_H
#define MAX_FLASH_STATES	3
const int MARKER_LEFT_OFFSET = 1; //pixels left from the client rect.left
const int MARKER_TOP_OFFSET = 2; //pixels down from client rect.top
const int MARKER_HEIGHT_LIMIT_FOR_NUMPRINT = 15;
/**Alarm Configuration*/
typedef struct _alarmCfg {
	USHORT Type;  ///< Alarm Type High=0 Low=1 Deviation=2 Rate up=3 Rate Down=4
	float Level;  ///< Alarm level
	USHORT AlarmNum;									///<alarm number 0-5
	USHORT AlarmStatus;								///<alarm status
	BOOL InAlarm;
} T_ALARMCFG;
//type of triangle to find the Text Draw area (alarm number draw area)
enum {
	TriUp, TriDown, TriForward, TriBackward, TriRtUp, TriRtDown, TriRtBackward, Deviation
};
//**Class*********************************************************************
///
/// @brief Alarm Marker Object
/// 
/// This class is a simple standard drawn object for the Alarm Marker object
/// which is derived from the CBaseObject class.
///
//****************************************************************************
class CAlarmMarkerObject: public CBaseObject {
private:QString
	Array m_csAlarmNum;
	T_ALARMCFG m_AlarmConfig[V6_MAX_ALARMS];							///<max 6 alarm types, Hi,Lo,DEv,RAteUp,RateDown
	//T_ALARMCFG m_AlarmConfigDbg[V6_MAX_ALARMS];///<max 6 alarm types, Hi,Lo,DEv,RAteUp,RateDown
	int m_ActiveAlarmNums[V6_MAX_ALARMS];	///<Out of 6, save the Active ALarms Numbers
	COLORREF *m_pInAlarmNotAckedFlashCol;	//In Alarm Not Acknowledged Flash Colour
	COLORREF *m_pInAlarmAckedFlashCol;	//In Alarm Acknowledged Flash Colour
	COLORREF *m_pOutAlarmNotAckedFlashCol;	//Out of Alarm Not Acknowledged Flash Colour
	COLORREF *m_pOutAlarmAckedFlashCol;	//Out of Alarm Acknowledged Flash Colour
//this is the default colour from the attribute blocks when not flashing
	COLORREF *m_pInAlarmNotAckedInterFlashCol;	//In Alarm Not Acknowledged Flash Colour
	COLORREF *m_pInAlarmAckedInterFlashCol;	//In Alarm Acknowledged Flash Colour
	COLORREF *m_pOutAlarmNotAckedInterFlashCol;	//Out of Alarm Not Acknowledged Flash Colour
	COLORREF *m_pOutAlarmAckedInterFlashCol;	//Out of Alarm Acknowledged Flash Colour
	COLORREF m_DiInAlarmNotAckedInterFlashCol;
	COLORREF m_DiInAlarmAckedInterFlashCol;	//In Alarm Acknowledged Flash Colour
	COLORREF m_DiOutAlarmNotAckedInterFlashCol;	//Out of Alarm Not Acknowledged Flash Colour
	COLORREF m_DiOutAlarmAckedInterFlashCol;	//Out of Alarm Acknowledged Flash Colour
	COLORREF m_DiInAlarmNotAckedFlashCol;
	COLORREF m_DiInAlarmAckedFlashCol;
	COLORREF m_DiOutAlarmNotAckedFlashCol;
	COLORREF m_DiOutAlarmAckedFlashCol;
	CDataItemRef *m_pDataItemRef[V6_MAX_ALARMS + 1];	///< data item table reference, for currentValue, and 6 alarms
	T_ALARMMRKROBJECT *m_pCMMAlarmMrkr;	///< Pointer to our CMM configuration
	T_PSCALEINFO m_pScaleDetails;
	USHORT m_uTestCase;				///< Last executed test case for debugging purposes
	QRect m_rcBaseline;				///< Baseline in client coordinates
	QRect m_rcZeroGrad;				///< Grad at zero limit in client coordinates
	QRect m_rcSpanGrad;				///< Grad at span limit in client coordinates
	// Derived objects must draw themselves.
	// Called via the m_pOnDraw pointer to function.
	static void OnDraw(CAlarmMarkerObject *pThis, HDC hdc, QRect *pClipRect);
	void DrawAlarmMarker(HDC hdc, COLORREF crPenColour, int nLane, int nAlarmNum);
	void SetNumericArea(QRect &textRect);
	static BOOL IsScaleReversed(CAlarmMarkerObject *pThis) {
		return (pThis->m_BottomLimit > pThis->m_TopLimit);
	}
	void Recalculate();
	void RecalculateAlarmMarkerSize();
	void RecalculateAlarmMarkerLanes();
	void RecalculateBaseline();
	void RecalculateBaselineIndent();
	void RecalculateGrads();
	void RecalculateScaleLimits();
	virtual LinkOrientation GetLinkOrient();						///< can the Object be linked and if so, which way?
	virtual BOOL CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2);///< calculate the link positions from the object limits
	virtual BOOL CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2);///< baseobject version does not impose any restrictions
	static void SetAlarmNumPos(CAlarmMarkerObject *pThis, int AlarmNum);
	BOOL SaveAlarmMarkerObjectState(BYTE *pbySaveBuffer, int nSaveBufferByteSize);
	void RestoreAlarmMarkerObjectState();
	void Zoom(float fZero, float fSpan);
	void Save(void *pbySrc, int nSrcByteSize);
	void Restore(void *pbyDst, int nDstByteSize);
	BOOL m_bSaveOk;
	BYTE *m_pbySaveBuffer;
	int m_nSaveBufferBytesRemaining;
	BOOL m_bComputeIndents;			///< Compute indents or use precalculated indents for linking?
	BOOL m_bPrevHoriz;				///< Was scale orientation previously horizontal? (If we switch
									///< the orientation of the scale, then we definitely want to
									///< recompute the zero and span indents!)
	int m_nMarkerHeight;
	int m_nMarkerWidth;
	int m_OffsetVertex;
	int m_Shape;
	int m_nPixel;
	int m_nAlarmMarkerFontHeight;
	int m_drawvalZero;
	int m_nNumMarkers;
	int m_nLaneOffset;
	int m_nCharCellHeight;			///< Character cell height in pixels
	int m_nCharCellWidth;			///< Character cell width in pixels
	QPoint m_ptArrowTip;			///< Tip of arrow relative to top-left of character cell
	float m_fZoomSpan;
	float m_fZoomZero;
	CFFConversionInfo m_conv;
	float m_TopLimit;		///< Top Bar value set from CMM or Data Item
	float m_BottomLimit;	///< Bottom Bar value set from CMM or Data Item
	BOOL m_Orient;
	USHORT m_ActiveAlarms;
	BOOL m_bLogScale;
	BOOL m_bSetScale;
	BOOL m_bLogScaleScrDes;
	BOOL m_bInZoom;
	BOOL m_ScaleReversed;
	int m_DrawLevel;
	/// Variable used to provide an offset into the alarm data item table references
	static const USHORT ms_usALARM_DIT_REF_OFFSET;
public:
	virtual void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);///< set bounds of the object relative to the CScreen's top left corner.
	CAlarmMarkerObject(CWidget *pWidget);
	// overidden functions that must be supplied
	virtual void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	virtual void ConfigChange();								///< config changes	
	virtual void Destroy();
};
#endif

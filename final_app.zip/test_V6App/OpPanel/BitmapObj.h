/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: BitmapObj.h
/// @n Description: Bitmap Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:55:41 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:25:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 8/17/2006 1:09:34 PM  Jason Parker  
//  updated to allow proportional resize
//  3 V6 Firmware 1.2 8/10/2006 9:01:51 PM  Jason Parker  
//  latest updates for screen designer use
// $
//
// **************************************************************************
#ifndef _BITMAPOBJ_H
#define _BITMAPOBJ_H
//**Class*********************************************************************
///
/// @brief ExampleBar Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used as a 'template' for all other derived Objects.
///
//****************************************************************************
class CBitmapObject: public CBaseObject {
private:
	T_BITMAPOBJECT *m_pCMMbitmap;	///< pointer to our CMM configuration
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CBitmapObject *pThis, HDC hdc, QRect *pClipRect);
public:
	CBitmapObject(CWidget *pWidget);
	void SetUniqueID(LONGLONG idToSet) {
		m_pCMMbitmap->UniqueID = idToSet;
	}
	void SetName(QString nameToSet);
#ifdef DOCVIEW
	CDib *m_pDibshowing;		// screen designer use only
	LONGLONG m_UniqueIDshowing; // screen designer use only
#endif
	virtual float GetXfactor(QRect bounds);
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
};
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ScaleObject.cpp
/// @n Description: Scale Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  30-Oct-14 Rajanbabu M  Fixed PAR:1-3KZWBIH-Load custom screen is not working in Multi and DRG2 Recorders
//  98  Stability Project 1.93.1.3 7/2/2011 5:01:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  97  Stability Project 1.93.1.2 7/1/2011 4:38:51 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  96  Stability Project 1.93.1.1 3/17/2011 3:20:45 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  95  Stability Project 1.93.1.0 2/15/2011 3:03:52 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "CMMDefines.h"
#include "V6Config.h"
#include "FFConversionInfo.h"
#include "ScaleDrawingObject.h"
#include "OpPanelIncludes.h"
#include "MathUtils.h"
#include <float.h>
#include "StringUtils.h"	//MarkD
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
///
/// Constructor
/// 
//****************************************************************************	
CScaleObject::CScaleObject(CWidget *pWidget) : CBaseObject(pWidget) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CScaleObject::OnDraw;
	m_pScaleDrawingObject = NULL;
	m_bComputeIndents = TRUE;
	m_bPrevHoriz = FALSE;
	m_pDataItemRef = NULL;
#ifndef V6IOTEST
	m_pScaleDrawingObject = new ScaleDrawingObject(m_UpdateRequired, m_UpdateValue, m_UpdateFlash, m_FlashState,
			*m_pFlashing, m_pWidget->m_pScreen->m_pOpPanel);
#endif
}
//****************************************************************************
///
/// Destructor
/// 
//****************************************************************************	
CScaleObject::~CScaleObject() {
#ifndef V6IOTEST
	if (m_pScaleDrawingObject != NULL) {
		delete m_pScaleDrawingObject;
	}
#endif
}
//****************************************************************************
///
/// Overridable function to convert from limits of object (bounds) to scale
/// positions. Returns FALSE if can't be done.
///
///	@param [in] lim1	- top or left of Object bounds
/// @param [in] lim2	- bottom or right of Object bounds 
/// @param [out] pPos1	- link position 1 (top or left of scale)
/// @param [out] pPos2	- link position 2 (bottom or right of scale)
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CScaleObject::CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2) {
	// Save away on the stack the member variables that can be updated
	// by the Recalculate method. The CalcLinkPositions method should
	// be considered a "const" method: it doesn't update the scale object.
	BYTE SaveBuffer[250];
	if (SaveScaleObjectState(SaveBuffer, sizeof(SaveBuffer))) {
		// Call SetBounds with a rectangle derived from the passed in limits 1
		// (top or left) and 2 (bottom or right) and the other dimension of the
		// scale's current bounds. The value of the other dimension (e.g., the
		// vertical dimension for a horizontal scale) isn't important because it
		// doesn't affect where zero and span will be located.
		QRect rcBounds;
		if (m_pCMMscale->Orientation == OBJECT_HORIZONTAL)
			rcBounds.SetRect(lim1, top(), lim2, bottom());
		else
			rcBounds.SetRect(left(), lim1, right(), lim2);
		m_bComputeIndents = TRUE;
		SetBounds(rcBounds);
		// Return as link positions 1 (top or left of scale) and 2 (bottom or right
		// of scale) the limits indented by the calculated zero indent and span indent.
		int nBorderWidth = 0;
		if (m_pCMMbase->Border.BorderUsed)
			nBorderWidth = m_pCMMbase->Border.BorderWidth;
		if (m_pCMMscale->Orientation == OBJECT_HORIZONTAL) {
			*pPos1 = lim1 + m_pCMMscale->ZeroIndent + nBorderWidth;
			*pPos2 = lim2 - m_pCMMscale->SpanIndent - nBorderWidth;
		} else {
			*pPos1 = lim1 + m_pCMMscale->SpanIndent + nBorderWidth;
			*pPos2 = lim2 - m_pCMMscale->ZeroIndent - nBorderWidth;
		}
		RestoreScaleObjectState();
	}
	return TRUE;
}
//****************************************************************************
///
/// Check if the Object can be resized so that the scale positions are pos1 
/// and pos2. Object must return the new bounds required to do this in 
/// pLim1 and pLim2
///
/// @param [in] pos1	- link position to match (top or left of scale)
/// @param [in] pos2	- link position to match (bottom or right of scale)
///	@param [out] pLim1	- top or left of Object bounds
/// @param [out] pLim2	- bottom or right of Object bounds 
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CScaleObject::CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2) {
	BOOL bRet; // return result
	BOOL bHoriz = m_pCMMscale->Orientation == OBJECT_HORIZONTAL;
	// Save away on the stack the member variables that can be updated
	// by the Recalculate method. The CanSetLinkPositions method should
	// be considered a "const" method: it doesn't update the scale object.
	BYTE SaveBuffer[250];
	if (bRet = SaveScaleObjectState(SaveBuffer, sizeof(SaveBuffer))) {
		// indexOf the bounds of the scale whose distance between zero and span
		// matches the distance between zero and span that we're given and
		// position and return these bounds so that the zero and span within
		// the bounds align with the zero and span that we're given. Since the
		// scale can be as big as the widget it is contained in, we'll do a
		// binary search for these bounds using the widget's appropriate dimension
		// (width for a horizontal scale or height for a vertical scale) as one
		// end of the range. For example, we'll do a binary search between 1
		// and the width of the widget for a horizontal scale. If the widget is
		// 500 pixels wide, we'll see if a scale having a width of 250 (the half-
		// way point between 1 and 500) has a zero and span with the required
		// distance. If its distance is less than the required distance, we'll
		// see if a scale having a width of 375 (the halfway point between 250
		// and 500) has a zero and span with the required distance, etc. This
		// should require at most 10 or so probes (calls to SetBounds and its
		// call to the Recalculate method) for a widget dimension of around 1024
		// pixels (1024=2^10).
		QRect rcWidget = m_pWidget->m_WidgetClientRect;
		int nWidgetDimension = bHoriz ? _Width(rcWidget) : _Height(rcWidget);
		int nFirst = 1;
		int nLast = nWidgetDimension;
		QRect rcBounds;
		BOOL bFound = FALSE;
		int nCompareResult;
		while (!bFound && nFirst <= nLast) // keep checking until found or we cross over
		{
			// Probe a sample width or height (nmid) for the scale bounds.
			// Position the scale bounds at the widget's left or top edge.
			int nmid = (nFirst + nLast) / 2;
			if (bHoriz)
				rcBounds.SetRect(rcWidget.left, top(), rcWidget.left + nmid, bottom());
			else
				rcBounds.SetRect(left(), rcWidget.top, right(), rcWidget.top + nmid);
			SetBounds(rcBounds);
			// Determine how our distance between zero and span compares with
			// the required distance. <0 means we're less, =0 means we're the
			// same, or >0 means we're greater than the required distance.
#ifndef V6IOTEST
			if (bHoriz)
				nCompareResult = (m_pScaleDrawingObject->m_rcSpanGrad.right - m_pScaleDrawingObject->m_rcZeroGrad.left)
						- (pos2 - pos1);
			else
				nCompareResult = (m_pScaleDrawingObject->m_rcZeroGrad.bottom - m_pScaleDrawingObject->m_rcSpanGrad.top)
						- (pos2 - pos1);
#endif
			if (nCompareResult < 0)
				// We need to think bigger!
				nFirst = nmid + 1;
			else if (nCompareResult > 0)
				// We need to think smaller!
				nLast = nmid - 1;
			else
				// We need to think success!
				bFound = TRUE;
		}
		m_bComputeIndents = FALSE;
		// Return as the limits 1 (top or left of object bounds) and 2 (bottom or
		// right of object bounds) based on what we calculated for the zero indent
		// and the span indent. Prevent the zero and span grads of the scale from
		// going into any border area that the scale has.
		int nBorderWidth = 0;
		if (m_pCMMbase->Border.BorderUsed)
			nBorderWidth = m_pCMMbase->Border.BorderWidth;
		if (bHoriz) {
			*pLim1 = pos1 - m_pCMMscale->ZeroIndent - nBorderWidth;
			*pLim2 = pos2 + m_pCMMscale->SpanIndent + nBorderWidth;
			if (*pLim1 < rcWidget.left)
				if (m_pCMMscale->ZeroIndent >= rcWidget.left - *pLim1) {
					m_pCMMscale->ZeroIndent -= (USHORT) (rcWidget.left - *pLim1);
					*pLim1 = rcWidget.left;
				} else
					bRet = FALSE;
			if (*pLim2 > rcWidget.right)
				if (m_pCMMscale->SpanIndent >= *pLim2 - rcWidget.right) {
					m_pCMMscale->SpanIndent -= (USHORT) (*pLim2 - rcWidget.right);
					*pLim2 = rcWidget.right;
				} else
					bRet = FALSE;
		} else {
			*pLim1 = pos1 - m_pCMMscale->SpanIndent - nBorderWidth;
			*pLim2 = pos2 + m_pCMMscale->ZeroIndent + nBorderWidth;
			if (*pLim1 < rcWidget.top)
				if (m_pCMMscale->SpanIndent >= rcWidget.top - *pLim1) {
					m_pCMMscale->SpanIndent -= (USHORT) (rcWidget.top - *pLim1);
					*pLim1 = rcWidget.top;
				} else
					bRet = FALSE;
			if (*pLim2 > rcWidget.bottom)
				if (m_pCMMscale->ZeroIndent >= *pLim2 - rcWidget.bottom) {
					m_pCMMscale->ZeroIndent -= (USHORT) (*pLim2 - rcWidget.bottom);
					*pLim2 = rcWidget.bottom;
				} else
					bRet = FALSE;
		}
		RestoreScaleObjectState();
	}
	return bRet;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Required size and position for a new Object
///
/// @return none
/// 
//****************************************************************************
void CScaleObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CScaleObject data in CMM info block.
	m_pCMMscale = (T_SCALEOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		m_pCMMscale->ChannelInfo.Enabled = TRUE;
		m_pCMMscale->ChannelInfo.Updates = FALSE; // they don't get updated
	} else {
		// When loading a previous configuration:
		// update CMM settings (from the defaults) for this specific Object type
		m_pCMMscale->ChannelInfo.Enabled = TRUE;
		// HERE allow ChannelInfo.Updates if set (for rotating scales etc)
		// initialise any members here from loaded CMM values
		// will use zero indent and span indent loaded from CMM
		m_bComputeIndents = FALSE;
		m_bPrevHoriz = m_pCMMscale->Orientation == OBJECT_HORIZONTAL;
	}
#ifndef V6IOTEST
	m_pScaleDrawingObject->Recalculate(m_pCMMscale, m_ClientRect, m_bComputeIndents, GetBounds());// recalculate before ConfigChange ! 
#endif
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CScaleObject::ConfigChange() {
	// Data item configuration done here. 
	// example bar only has one data item reference and has the following CMM config:
	// ChannelInfo 
	//		ItemType = Pen
	//		IndexChan = 0	...index into Widget's Channel 'List'
	//		Instance = 1
	if (!m_pDataItemRef)
		m_pDataItemRef = new CDataItemRef(this); // create our single reference
	if (m_pDataItemRef) {
		// pass it to our Widget, along with our CMM config
		if (m_pWidget->GetDataItem(m_pDataItemRef, &m_pCMMscale->ChannelInfo)) {
#ifndef V6IOTEST
			m_pScaleDrawingObject->ConfigChange(m_pDataItemRef->m_pDataItem);
#endif
		}
	}
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	m_bPrevHoriz = m_pCMMscale->Orientation == OBJECT_HORIZONTAL;
}
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CScaleObject::OnDraw(CScaleObject *pThis, HDC hdc, QRect *pClipRect) {
	// Update the current clipping region. This handling will prevent the
	// grads (or anything else) from being drawn outside the scale object.
	pThis->m_pWidget->SetClipRect(hdc, &pThis->m_ClientRect);
#ifndef V6IOTEST
	pThis->m_pScaleDrawingObject->OnDraw(hdc, pClipRect);
#endif
	// Restore clipping region 
	pThis->m_pWidget->RestoreClipping(hdc);
}
void CScaleObject::Save(void *pbySrc, int nSrcByteSize) {
	if (m_nSaveBufferBytesRemaining >= nSrcByteSize) {
		memcpy(m_pbySaveBuffer, pbySrc, nSrcByteSize);
		m_pbySaveBuffer += nSrcByteSize;
		m_nSaveBufferBytesRemaining -= nSrcByteSize;
	} else {
		assert(0); // save buffer is not big enough!
		m_bSaveOk = FALSE;
	}
}
void CScaleObject::Restore(void *pbyDst, int nDstByteSize) {
	memcpy(pbyDst, m_pbySaveBuffer, nDstByteSize);
	m_pbySaveBuffer += nDstByteSize;
}
BOOL CScaleObject::SaveScaleObjectState(BYTE *pbySaveBuffer, int nSaveBufferByteSize) {
	m_bSaveOk = TRUE;
	m_pbySaveBuffer = pbySaveBuffer;
	m_nSaveBufferBytesRemaining = nSaveBufferByteSize;
#ifndef V6IOTEST
	Save(&m_ClientRect, sizeof(m_ClientRect));
	Save(&m_pScaleDrawingObject->m_bDrawMajorGrads, sizeof(m_pScaleDrawingObject->m_bDrawMajorGrads));
	Save(&m_pScaleDrawingObject->m_bDrawMinorGrads, sizeof(m_pScaleDrawingObject->m_bDrawMinorGrads));
	Save(&m_pScaleDrawingObject->m_bLabelLimits, sizeof(m_pScaleDrawingObject->m_bLabelLimits));
	Save(&m_pScaleDrawingObject->m_bLabelMajors, sizeof(m_pScaleDrawingObject->m_bLabelMajors));
	Save(&m_bPrevHoriz, sizeof(m_bPrevHoriz));
	Save(&m_pScaleDrawingObject->m_nLayout, sizeof(m_pScaleDrawingObject->m_nLayout));
	Save(&m_pScaleDrawingObject->m_nLimitLabelHeight, sizeof(m_pScaleDrawingObject->m_nLimitLabelHeight));
	Save(&m_pScaleDrawingObject->m_nMajorGradLength, sizeof(m_pScaleDrawingObject->m_nMajorGradLength));
	Save(&m_pScaleDrawingObject->m_nMajorLabelHeight, sizeof(m_pScaleDrawingObject->m_nMajorLabelHeight));
	Save(&m_pScaleDrawingObject->m_nMajorLabelTopleft, sizeof(m_pScaleDrawingObject->m_nMajorLabelTopleft));
	Save(&m_pScaleDrawingObject->m_nMinorGradLength, sizeof(m_pScaleDrawingObject->m_nMinorGradLength));
//	Save(&m_pCMMscale->SpanIndent, sizeof(m_pCMMscale->SpanIndent)); -- use calculated value for linking
//	Save(&m_pCMMscale->ZeroIndent, sizeof(m_pCMMscale->ZeroIndent)); -- use calculated value for linking
	Save(&m_pCMMbase->Bounds, sizeof(m_pCMMbase->Bounds));
	Save(&m_pScaleDrawingObject->m_rcBaseline, sizeof(m_pScaleDrawingObject->m_rcBaseline));
	Save(&m_pScaleDrawingObject->m_rcSpanGrad, sizeof(m_pScaleDrawingObject->m_rcSpanGrad));
	Save(&m_pScaleDrawingObject->m_rcSpanLabel, sizeof(m_pScaleDrawingObject->m_rcSpanLabel));
	Save(&m_pScaleDrawingObject->m_rcZeroGrad, sizeof(m_pScaleDrawingObject->m_rcZeroGrad));
	Save(&m_pScaleDrawingObject->m_rcZeroLabel, sizeof(m_pScaleDrawingObject->m_rcZeroLabel));
#endif
	m_pbySaveBuffer = pbySaveBuffer; // restore to beginning
	return m_bSaveOk;
}
void CScaleObject::RestoreScaleObjectState() {
	if (m_bSaveOk) {
		Restore(&m_ClientRect, sizeof(m_ClientRect));
		Restore(&m_pScaleDrawingObject->m_bDrawMajorGrads, sizeof(m_pScaleDrawingObject->m_bDrawMajorGrads));
		Restore(&m_pScaleDrawingObject->m_bDrawMinorGrads, sizeof(m_pScaleDrawingObject->m_bDrawMinorGrads));
		Restore(&m_pScaleDrawingObject->m_bLabelLimits, sizeof(m_pScaleDrawingObject->m_bLabelLimits));
		Restore(&m_pScaleDrawingObject->m_bLabelMajors, sizeof(m_pScaleDrawingObject->m_bLabelMajors));
		Restore(&m_bPrevHoriz, sizeof(m_bPrevHoriz));
		Restore(&m_pScaleDrawingObject->m_nLayout, sizeof(m_pScaleDrawingObject->m_nLayout));
		Restore(&m_pScaleDrawingObject->m_nLimitLabelHeight, sizeof(m_pScaleDrawingObject->m_nLimitLabelHeight));
		Restore(&m_pScaleDrawingObject->m_nMajorGradLength, sizeof(m_pScaleDrawingObject->m_nMajorGradLength));
		Restore(&m_pScaleDrawingObject->m_nMajorLabelHeight, sizeof(m_pScaleDrawingObject->m_nMajorLabelHeight));
		Restore(&m_pScaleDrawingObject->m_nMajorLabelTopleft, sizeof(m_pScaleDrawingObject->m_nMajorLabelTopleft));
		Restore(&m_pScaleDrawingObject->m_nMinorGradLength, sizeof(m_pScaleDrawingObject->m_nMinorGradLength));
//		Restore(&m_pCMMscale->SpanIndent, sizeof(m_pCMMscale->SpanIndent)); -- use calculated value for linking
//		Restore(&m_pCMMscale->ZeroIndent, sizeof(m_pCMMscale->ZeroIndent)); -- use calculated value for linking
		Restore(&m_pCMMbase->Bounds, sizeof(m_pCMMbase->Bounds));
		Restore(&m_pScaleDrawingObject->m_rcBaseline, sizeof(m_pScaleDrawingObject->m_rcBaseline));
		Restore(&m_pScaleDrawingObject->m_rcSpanGrad, sizeof(m_pScaleDrawingObject->m_rcSpanGrad));
		Restore(&m_pScaleDrawingObject->m_rcSpanLabel, sizeof(m_pScaleDrawingObject->m_rcSpanLabel));
		Restore(&m_pScaleDrawingObject->m_rcZeroGrad, sizeof(m_pScaleDrawingObject->m_rcZeroGrad));
		Restore(&m_pScaleDrawingObject->m_rcZeroLabel, sizeof(m_pScaleDrawingObject->m_rcZeroLabel));
		// Set up information for EU (linear) or power of 10 (log) to pixel conversion.
		m_pScaleDrawingObject->m_convInfo.CalcFConvInfo(m_pScaleDrawingObject->GetZero(),
				m_pScaleDrawingObject->GetSpan(),
				m_pCMMscale->Orientation == OBJECT_VERTICAL ?
						(float) m_pScaleDrawingObject->m_rcBaseline.bottom :
						(float) m_pScaleDrawingObject->m_rcBaseline.left,
				m_pCMMscale->Orientation == OBJECT_VERTICAL ?
						(float) m_pScaleDrawingObject->m_rcBaseline.top :
						(float) m_pScaleDrawingObject->m_rcBaseline.right);
	} else
		assert(0); // do not attempt restore if save failed!
}
//****************************************************************************
///
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CScaleObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	BOOL bHoriz = m_pCMMscale->Orientation == OBJECT_HORIZONTAL;
	// Don't compute the indents if the width or height isn't changing.
	// Otherwise we could change the zero and span indents when we shouldn't
	// by just selecting or moving the scale.
	QRect rcBounds(bounds); // scale's new bounds
	QRect rcOldBounds(GetBounds()); // scale's old bounds
	if (bHoriz != m_bPrevHoriz)
		m_bComputeIndents = TRUE; // force compute indents on orientation change!
	else if (m_bComputeIndents && bHoriz && rcBounds.Width() == rcOldBounds.Width()) {
		m_bComputeIndents = FALSE;
		m_pCMMscale->ZeroIndent = (USHORT) (m_pScaleDrawingObject->m_rcZeroGrad.left - m_ClientRect.left);
		m_pCMMscale->SpanIndent = (USHORT) (m_ClientRect.right - m_pScaleDrawingObject->m_rcSpanGrad.right);
	} else if (m_bComputeIndents && !bHoriz && rcBounds.Height() == rcOldBounds.Height()) {
		m_bComputeIndents = FALSE;
		m_pCMMscale->ZeroIndent = (USHORT) (m_ClientRect.bottom - m_pScaleDrawingObject->m_rcZeroGrad.bottom);
		m_pCMMscale->SpanIndent = (USHORT) (m_pScaleDrawingObject->m_rcSpanGrad.top - m_ClientRect.top);
	}
	if (pPos1 || pPos2) // force link positions to passed-in values
			{
		assert(pPos1 && pPos2); // both link positions must be set!
		m_bComputeIndents = FALSE;
		int nBorderWidth = 0;
		if (m_pCMMbase->Border.BorderUsed)
			nBorderWidth = m_pCMMbase->Border.BorderWidth;
		if (bHoriz) {
			m_pCMMscale->ZeroIndent = (USHORT) (*pPos1 - rcBounds.left - nBorderWidth);
			m_pCMMscale->SpanIndent = (USHORT) (rcBounds.right - *pPos2 - nBorderWidth);
		} else {
			m_pCMMscale->ZeroIndent = (USHORT) (rcBounds.bottom - *pPos2 - nBorderWidth);
			m_pCMMscale->SpanIndent = (USHORT) (*pPos1 - rcBounds.top - nBorderWidth);
		}
	}
	CBaseObject::SetBounds(rcBounds, pPos1, pPos2); // call the base Object version
#ifndef V6IOTEST
	m_pScaleDrawingObject->Recalculate(m_pCMMscale, m_ClientRect, m_bComputeIndents, GetBounds());
#endif
	m_bComputeIndents = TRUE;
	//static int nCount=0;
	//qDebug("Exited CScaleObject::SetBounds for %x on screen (%d,%d) bounds=(%d,%d,%d,%d) pos=(%d,%d) ZeroIndent=%d SpanIndent=%d (%d)\n", this, m_pWidget->m_pScreen->m_CMMinfo.wBlockType, m_pWidget->m_pScreen->m_CMMinfo.wInstanceID, bounds->left, bounds->top, bounds->right, bounds->bottom, pPos1 ? *pPos1 : -1, pPos2 ? *pPos2 : -1, m_pCMMscale->ZeroIndent, m_pCMMscale->SpanIndent, ++nCount);
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CScaleObject::Destroy() {
}
LinkOrientation CScaleObject::GetLinkOrient() {
	return m_pCMMscale->Orientation == OBJECT_HORIZONTAL ? LINK_HORIZONTAL : LINK_VERTICAL;
}

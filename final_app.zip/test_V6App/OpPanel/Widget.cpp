/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Op Panel
/// @n Filename: Widget.cpp 
/// @n Description: Widget class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 132 Stability Project 1.127.1.3	7/2/2011 5:02:53 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 131 Stability Project 1.127.1.2	7/1/2011 4:39:19 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 130 Stability Project 1.127.1.1	3/17/2011 3:20:55 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 129 Stability Project 1.127.1.0	2/15/2011 3:04:15 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "Widget.h"
#include "OpPanelIncludes.h"
#include "ChartObject.h"
#include "CircularChartObject.h"
#include <vector>
#include <algorithm>
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define DEF_WIDGET_BACK_COLOUR		59132///<this value is matched to the default value of the CMM db
#define MAX_WIDGET_NAME_TYPE_CAT		22///<this value is matched to the default value of the CMM db
//extern CDataItemTable Glb_datatable; // Global datatable (for now)
// Static initialisation
const USHORT CWidget::ms_usCHANNEL_OFFSET = 1001;
const USHORT CWidget::ms_usNO_FREE_SCREEN_INDEXES = 0xFFFF;
const USHORT CWidget::ms_usCHANNEL_SPARE = 0;
const USHORT CWidget::ms_usPARENT_INDEX = 0;
extern BOOL Glb_SeeRegions; ///< for testing purposes (see the update rectangle)
BYTE Glb_col = 0;
//extern BOOL Glb_RemoteConnected;
//****************************************************************************
/// CWidget Constructor
///
/// @param pParentScreen Pointer to Parent Screen 
/// 
//****************************************************************************
CWidget::CWidget(CScreen *pParentScreen) : CLayoutItem(otWidget) {
	// set up empty block info structure;
	BLOCK_INFO emptyInfo = { 0, 0, 0, NULL, 0 };
	m_CMMinfo = emptyInfo;
	m_pConfig = NULL;
	m_pReferences = NULL;
	m_WidgetClip = NULL;
	m_UpdateRgn = CreateRectRgn(0, 0, 0, 0);
	m_ClipRgn = CreateRectRgn(0, 0, 0, 0); // used for clipping objects
	m_ClipValid = FALSE;
	m_pCMMwidget = NULL;
	m_pNextWgt = NULL;
	m_pObjects = NULL;
	m_pSelectedObject = NULL;
	m_pLastSelectedObject = NULL;
	m_PermInUse = FALSE;
	m_PermValid = FALSE;
	m_CheckpointRequired = FALSE;
	m_WidgetUpdateRequired = FALSE;
	m_WidgetShowHandles = FALSE;
	m_WidgetResizeState = ResizeNone;
	SetRectEmpty(&m_WidgetClientRect);
	// keep pointer to our parent Screen
	m_pScreen = pParentScreen;
	m_InitCount = 0;
	m_CurrRotateOffset = 0;
	m_LastRotateUpdate100 = 0;
	// get a copy of all the DirectDraw pointers from OpPanel (screen's parent)
	CheckDDPointers();
}
//****************************************************************************
/// 
/// Check that the direct draw pointers a valid
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CWidget::CheckDDPointers() {
	if (m_InitCount != m_pScreen->m_pOpPanel->m_InitCount) // if a change has occurred, this will be true
			{
		// set up interface pointers 
		m_pDD = m_pScreen->m_pOpPanel->m_pDD;
		m_pDDSPrimary = m_pScreen->m_pOpPanel->m_pDDSPrimary;
		m_pDDSBackBuffer = m_pScreen->m_pOpPanel->m_pDDSBackBuffer;
		m_pDDSPermanent = m_pScreen->m_pOpPanel->m_pDDSPermanent;
		m_pDDSAlpha = m_pScreen->m_pOpPanel->m_pDDSAlpha;
		m_pDDClipper = m_pScreen->m_pOpPanel->m_pDDClipper;
		m_PermValid = FALSE; // if our surfaces have been recreated, then reload the imagaes etc.
		// need to check Objects too.
		CBaseObject *pObj = m_pObjects;
		while (pObj) {
			if (pObj->m_pCMMbase->IsAdvancedDraw) // any advance draw objects, re-setup the surface pointers
				pObj->ConfigChange();
			pObj = pObj->m_pNextObj;
		}
		m_InitCount = m_pScreen->m_pOpPanel->m_InitCount;
	}
}
//****************************************************************************
/// CWidget Destructor()
/// Clean up as Widget is deleted (Destroy function does most of the work)
/// 
/// @todo put whatever we need to do in here !!
//****************************************************************************
CWidget::~CWidget() {
	DeleteObject(m_UpdateRgn);
	DeleteObject(m_ClipRgn);
}
//****************************************************************************
/// 
/// Clean up CWidget and everything under it
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CWidget::Destroy() {
	// delete all CBaseObject derived Objects.
	while (m_pObjects) {
		CBaseObject *pObj = m_pObjects;
		RemoveObject(pObj); // remove from list
		pObj->Destroy();
		delete pObj;		// then delete the CBaseObject derived object.
	}
	// now delete our Data Item References (for all objects for this Widget)
	while (m_pReferences) {
		CDataItemRef *ptr = m_pReferences;
		m_pReferences = m_pReferences->nextRef;
		delete ptr;
	}
}
//****************************************************************************
///
/// Initialises the Widget with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Widget
/// Or will be a new defaulted block for a new Widget. 
///
/// @param[in] pConfig	- Configuration to use
/// @param[in] CMMinfo	- This is a block of CMM info
/// @param[in] bounds	- If not NULL, this gives size and position for Widget
///
/// @return none
/// 
//****************************************************************************
void CWidget::CMMInitWidget(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, QRect *bounds) {
	// keep a copy of the CMM info block passed in.
	m_CMMinfo = *CMMinfo;
	// set up pointer to WIDGET data in CMM info block.
	m_pCMMwidget = (T_WIDGET*) m_CMMinfo.pByBlock;
	m_pConfig = pConfig; // pointer to the config
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Widget.
	if (bounds) {
		SetWidgetBounds(bounds);
		// set up channel list from data in cmm
		/// @todo initialise the Widet's channel list for a new Widget only
		for (int i = 0; i < WIDGET_CHANNELLIST_SIZE; i++) {
			m_pCMMwidget->ChannelList[i] = ms_usCHANNEL_SPARE; // number channels from ms_usCHANNEL_OFFSET onwards
		}
	} else {
		// loaded previous Widget from CMM
		// set client rect from bounds and border settings...
		SetClientRect();
		if ((m_pCMMwidget->IsSelected) && (GetOpPanel()->m_EditMode == DESIGNER_MODE))
			m_WidgetShowHandles = TRUE;
		// Now we need to create the Objects for our Widget
		for (int i = 0; i < m_pCMMwidget->NumObjects; i++) {
			BLOCK_INFO objDetails;
			if (GetObjectConfig(i, &objDetails)) // Get the CMM details for Object 'i'
					{
				// found object and populated blockinfo OK. (contains pointer into CMM for Object)
				// now create a corresponding C++ Object for it.
				ObjectType eObjType = NoObject;
				CBaseObject *pObj = CreateDerivedObject(&objDetails, eObjType);
				pObj->CMMInit(&objDetails, NULL); // call virtual CMMInit in derived Object
				AppendObject(pObj);
				if (pObj->m_pCMMbase->IsPermanent) {
					m_PermInUse = TRUE; // if any object is using the permanent surface, widget needs to know.
					m_PermValid = FALSE;
				}
			}
		}
		// Object Linking:
		// created all the objects for this widget now connect up any links
		CheckObjectLinks();
	}
	// for all widgets, check these params are valid
	if (m_pCMMwidget->NumRotateChan > m_pCMMwidget->NumChannels)
		m_pCMMwidget->NumRotateChan = m_pCMMwidget->NumChannels;
	if ((m_pCMMwidget->RotateChannels) && (m_pCMMwidget->NumRotateChan == 0)) // must prevent divide by zero later.
		m_pCMMwidget->RotateChannels = FALSE;
}
//****************************************************************************
/// Check this widgets objects are linked ok.
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CWidget::CheckObjectLinks() {
	// LAYOUTITEM LinkedObj used to set up CBaseObject *m_pLinked;	
	BOOL missinglink = FALSE;
	CBaseObject *pObj = m_pObjects;
	while (pObj) {
		T_LAYOUTITEM li = pObj->m_pCMMbase->LinkedObj; // linked object ref stored in CMM
		if (li.CMM_Type != 0) {
			// object has the a valid reference to another object, so lets find it
			CBaseObject *pObj2 = indexOfObjectInstance(&li); // search all objects to find a match
			if (pObj2)
				pObj->m_pLinked = pObj2; // found it, so recreate the link
			else {
				// missing link!
				// fix CMM to match
				SetNull(pObj->m_pCMMbase->LinkedObj);				// missing
				missinglink = TRUE;
			}
		} else
			pObj->m_pLinked = NULL; // no reference, so should not be linked.
		pObj = pObj->m_pNextObj;
	}
	if (missinglink) {
		// linked objects must ALWAYS form a cyclic chain.
		pObj = m_pObjects;
		while (pObj) {
			if (pObj->m_pLinked) {
				// found a linked object - check it has a cyclic list...
				CBaseObject *pObjstart = pObj;
				CBaseObject *pObjend = pObjstart;
				do {
					pObjend = pObjend->m_pLinked;
					if (pObjend == pObjstart) // have we reached thes start?
						break;
				} while (pObjend->m_pLinked);
				if (pObjend != pObjstart) {
					// if we haven't reached the start, we have a broken link, and we have the endobject
					// (the last one in the chain fragment)
					// We need so look 'backwards' along the list, until we find a linked object that is 
					// not pointed to by any other object. 
					// Then we know this is the object that is at the start of the chain fragment.
					// We then make pObjend point to it and recreate the chain!
					BOOL foundprevious;
					do {
						foundprevious = FALSE;
						CBaseObject *pObj3 = m_pObjects;
						while (pObj3) {
							if (pObj3->m_pLinked) {
								if (pObj3->m_pLinked == pObjstart) {
									pObjstart = pObj3; // go back along link list one object
									foundprevious = TRUE;
									break;
								}
							}
							pObj3 = pObj3->m_pNextObj;
						}
					} while (foundprevious);
					// ok, so here, pObjstart is now at the start of the broken chain fragment.
					pObjend->m_pLinked = pObjstart; // fix the break!
					// and assign the CMM reference to linked object.
					pObjend->m_pCMMbase->LinkedObj = pObjstart->GetLayoutItem();
				}
			}
			pObj = pObj->m_pNextObj;
		}
	}
}
//****************************************************************************
///
///	Creates a derived Object. 
/// Keep all derived Object details here in the Widget Class.
/// (only one place to update when new derived Objects added.)
///
/// @param[in] ObjDetails- pointer to block of CMM info
///
/// @return CBaseObject pointer to derived Object or NULL if failed
/// 
//****************************************************************************
CBaseObject* CWidget::CreateDerivedObject(BLOCK_INFO *ObjDetails, ObjectType &reObjType) {
	CBaseObject *pObj = NULL;
	switch (ObjDetails->wBlockType) {
	case BLK_EXAMPLEBAR:
		pObj = new CExampleBar(this);
		reObjType = ExampleBar;
		break;
	case BLK_BAROBJECT:
		pObj = new CBarObject(this);
		reObjType = BarObject;
		break;
	case BLK_SCALEOBJECT:
		pObj = new CScaleObject(this);
		reObjType = ScaleObject;
		break;
	case BLK_PENPTRSOBJECT:
		pObj = new CPenPointersObject(this);
		reObjType = PenPointersObject;
		break;
	case BLK_ALARMMRKROBJECT:
		pObj = new CAlarmMarkerObject(this);
		reObjType = AlarmMrkrObject;
		break;
	case BLK_DIGITALOBJECT:
		pObj = new CDigitalObject(this);
		reObjType = DigitalObject;
		break;
	case BLK_TEXTOBJECT:
		pObj = new CTextObject(this);
		reObjType = TextObject;
		break;
	case BLK_CHARTOBJECT:
		pObj = new CChartObject(this);
		reObjType = ChartObject;
		break;
	case BLK_CIRCCHARTOBJECT:
#ifndef V6IOTEST
		pObj = new CCircularChartObject(this);
		reObjType = CircularChartObject;
#endif
		break;
	case BLK_BITMAPOBJECT:
#ifndef V6IOTEST
		pObj = new CBitmapObject(this);
		reObjType = BitmapObject;
#endif
		break;
	case BLK_CURSOROBJECT:
		pObj = new CCursorObject(this);
		reObjType = CursorObject;
		break;
	case BLK_BUTTONOBJECT:
#ifndef V6IOTEST
		pObj = new CButtonObject(this);
		reObjType = ButtonObject;
#endif
		break;
	case BLK_TABULAROBJECT:
#ifndef V6IOTEST
		pObj = new CTabularDisplayObject(this);
		reObjType = TabularDisplayObject;
#endif
		break;
	case BLK_TUSOBJECT:
#ifndef V6IOTEST
		pObj = new CTUSObject(this);
		reObjType = TUSObject;
#endif
		break;
		/// @todo insert all other derived Objects here
	default:
		reObjType = NoObject;
		break;
	}
	return pObj;
}
//****************************************************************************
///
/// Retrieves the BLOCK_INFO for a particular Object in the Widgets ObjectList
/// by indexing into the array of T_LAYOUTITEM's, then searching the CMM for 
/// a matching block. 
///
/// @param[in] index		- Index into ObjectList array
/// @param[in] blockInfo	- pointer to structure to populate
///
/// @return TRUE if found FALSE if not
/// 
//****************************************************************************
BOOL CWidget::GetObjectConfig(int index, BLOCK_INFO *blockInfo) const {
	if (index >= m_pCMMwidget->NumObjects) // validate index
		return FALSE;
	return m_pConfig->indexOfDataBlock(&m_pCMMwidget->ObjectList[index], blockInfo); // populate the BLOCK_INFO	
}
//****************************************************************************
///
/// Creates a new Object and appends it to list
/// 
/// @param[in] blockInfo - pointer to BLOCK_INFO in CMM for Object to add 
/// @param[in] bounds	- can be NULL
///
/// @return none
///
/// @todo - Add handling for when we run out of screen indexes
///
//****************************************************************************
void CWidget::AddNewObject(BLOCK_INFO *blockInfo, QRect *bounds) {
	// before calling this function, Object already has a CMM entry
	// now create a corresponding C++ object for it.
	// check this widget has a parent channel setup
	InitParentChannel();
	ObjectType eObjType = NoObject;
	CBaseObject *pObj = CreateDerivedObject(blockInfo, eObjType);
	pObj->CMMInit(blockInfo, bounds); // call virtual CMMInit in derived Object
	// put the type of object created into the baseObject details for the object
	pObj->m_pCMMbase->ObjectType = m_pConfig->BlockTypeToObjectType((T_BLOCKTYPE) blockInfo->wBlockType);
	// check if this is a chart object or pen ptr
	USHORT usChanType = DI_PEN;
	USHORT usChanSubType = 0;
	GetWidgetChannelType(usChanType, usChanSubType, CWidget::ms_usPARENT_INDEX);
	bool bParentIsPen = IsPenCompatibleType(usChanType);
	bool bObjIsMultiPenObj = (eObjType == ChartObject) || (eObjType == CircularChartObject)
			|| (eObjType == PenPointersObject) || (eObjType == TabularDisplayObject);
	if (!bObjIsMultiPenObj) {
		USHORT usNumOfChannels = 0;
		// setup this object with the parent type as long as it is not an alarm marker and not a pen parent
		if ((bParentIsPen) || (eObjType != AlarmMrkrObject)) {
			T_CHANNELREF *ptObjChanRef = GetObjChanRef(pObj, usNumOfChannels);
			if (ptObjChanRef != NULL) {
				for (USHORT usChanCount = 0; usChanCount < usNumOfChannels; usChanCount++) {
					// set the index of the parent
					ptObjChanRef[usChanCount].IndexChan = 0;
					if (eObjType == AlarmMrkrObject) {
						ptObjChanRef[usChanCount].ItemType = DI_ALARM;
						ptObjChanRef[usChanCount].SubType = usChanCount;
					} else {
						ptObjChanRef[usChanCount].ItemType = usChanType;
						ptObjChanRef[usChanCount].SubType = usChanSubType;
					}
				}
			}
		} else {
			// this is an alarm marker and the parent is not a pen therefore we must set it to use the first
			// available new channel
			// the num channels variable will correspond to the first free widget channel so all we need to do is
			// pair it up with the next free screen instance
			USHORT usWidgetChannelNum = m_pCMMwidget->NumChannels;
			const USHORT usSCREEN_INDEX = GetFreeScreenInstIndex(m_pScreen, CScreen::ms_usUNINITIALISED_INSTANCE);
			if (usSCREEN_INDEX != ms_usNO_FREE_SCREEN_INDEXES) {
				m_pCMMwidget->ChannelList[usWidgetChannelNum] = usSCREEN_INDEX + ms_usCHANNEL_OFFSET;
				T_CHANNELREF *ptObjChanRef = GetObjChanRef(pObj, usNumOfChannels);
				// loop through all the alarm marker channels assigning them correctly
				if (ptObjChanRef != NULL) {
					for (USHORT usChanCount = 0; usChanCount < usNumOfChannels; usChanCount++) {
						// set the index to the next free parent
						ptObjChanRef[usChanCount].IndexChan = usWidgetChannelNum;
						ptObjChanRef[usChanCount].ItemType = DI_ALARM;
						ptObjChanRef[usChanCount].SubType = usChanCount;
					}
				}
			} else {
				// run out of screen indexes - highly unlikely but generate an error to cope with it
				LOG_ERR(TRACE_OPPANEL, "RUN OUT OF FREE SCREEN INSTANCES");
			}
		}
	} else if (bObjIsMultiPenObj) {
		// the object being dropped is a chart object, pen ptr or tabular screen
		// check if there are already chart or pen pointers on this widget already
		if (!ContainsMultiPenObj()) {
			// this does not contain a chart or pen ptr object already so the widget channel list
			// will not be configured for multiple pens yet
			// check if this is the first object to be placed or all the existing objects refer to pens
			if ((m_pObjects != NULL) && (!AllWidgetChannelsArePens())) {
				// there are already some objects and some of the channels are not pens - we need to remove the non-
				// pen related items
				MakeWidgetChannelsPenOnly();
			}
			// now we need to simply bring the number of channels up to the limit for this chart object if not 
			// already at it
			// set the channels to the maximum which is the mulititrend limit of 32 - this is to prevent
			// a problem where charts are dropped on different devices e.g. mini's or multi's
			USHORT usMaxChannels = CBaseObject::ms_usMAX_MULTITREND_CHART_PENS;
			while (m_pCMMwidget->NumChannels < usMaxChannels) {
				// the number of channels variable is also the location of the
				// first free widget channel
				const USHORT usSCREEN_INDEX = GetFreeScreenInstIndex(m_pScreen, CScreen::ms_usUNINITIALISED_INSTANCE);
				if (usSCREEN_INDEX != ms_usNO_FREE_SCREEN_INDEXES) {
					m_pCMMwidget->ChannelList[m_pCMMwidget->NumChannels] = usSCREEN_INDEX + ms_usCHANNEL_OFFSET;
					++m_pCMMwidget->NumChannels;
				} else {
					// run out of screen indexes - highly unlikely but generate an error to cope with it
					LOG_ERR(TRACE_OPPANEL, "RUN OUT OF FREE SCREEN INSTANCES");
					break;
				}
			}
		} else {
			// chart or pen pointers already on the object thus the widget channel list will
			// be setup okay already so do nothing
		}
	}
	pObj->ConfigChange();
	AppendObject(pObj);
	m_pSelectedObject = pObj;
	if (pObj->m_pCMMbase->IsPermanent) {
		m_PermInUse = TRUE; // if any object is using the permanent surface, widget needs to know.
		m_PermValid = FALSE;
	}
}
//****************************************************************************
///
/// Returns the T_LAYOUTITEM of this Widget
///
/// @param none
///
/// @return T_LAYOUTITEM
/// 
//****************************************************************************
T_LAYOUTITEM CWidget::GetLayoutItem() {
	T_LAYOUTITEM ref;
	ref.CMM_Type = m_CMMinfo.wBlockType;
	ref.CMM_Inst = m_CMMinfo.wInstanceID;
	return ref;
}
//****************************************************************************
///
///	Function to check if this CWidget matches a LayoutItem reference from 
/// the CMM.
///
/// @param[in] LayoutItem - type and instance reference from CMM
///
/// @return TRUE/FALSE
/// 
//****************************************************************************
BOOL CWidget::MatchLayoutItem(T_LAYOUTITEM *LayoutItem) {
	return ((m_CMMinfo.wInstanceID == LayoutItem->CMM_Inst) && // match type and instance?
			(m_CMMinfo.wBlockType == LayoutItem->CMM_Type)); // check it's BLK_WIDGET
}
//****************************************************************************
///
///	searches list of Objects for matching CMM Object
///
/// @param[in] LayoutItem - type and instance reference from CMM
///
/// @return pointer to Object found or NULL 
/// 
//****************************************************************************
CBaseObject* CWidget::indexOfObjectInstance(T_LAYOUTITEM *LayoutItem) {
	CBaseObject *pObj = m_pObjects;
	while (pObj) {
		if (pObj->MatchLayoutItem(LayoutItem))
			return pObj;
		pObj = pObj->m_pNextObj;
	}
	return NULL; // not matched.
}
//****************************************************************************
///
/// Gets the thickness of the Widget's border
///
/// @return thickness of border (zero if not used) 
/// 
//****************************************************************************
int CWidget::GetWidgetBorder() {
	if (m_pCMMwidget->Border.BorderUsed)
		return m_pCMMwidget->Border.BorderWidth;
	return 0;
}
//****************************************************************************
///
/// Gets the bounds (bounding rectangle - position and size) of the Widget.
/// Co-ordinates are relative to the top-left of the CScreen Window.
///
/// @return QRect structure 
/// 
//****************************************************************************
QRect CWidget::GetWidgetBounds() {
	QRect temp = *(QRect*) &m_pCMMwidget->Bounds;
#ifdef DOCVIEW
	OffsetRect(&temp,GetOpPanel()->m_RecScreenOffset.x,GetOpPanel()->m_RecScreenOffset.y);
#endif
	return temp;
}
//****************************************************************************
///
/// Gets the bounds (bounding rectangle - position and size) of the Widget.
/// Co-ordinates are relative to the top-left of the CScreen Window.
///
/// @return QRect structure 
/// 
//****************************************************************************
QRect CWidget::GetWidgetBoundsActual() {
	return *(QRect*) &m_pCMMwidget->Bounds;
}
//****************************************************************************
///
/// Sets the bounds (bounding rectangle - position and size) of the Widget.
/// Co-ordinates are relative to the top-left of the CScreen Window.
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
///
/// @return none
/// 
//****************************************************************************
void CWidget::SetWidgetBounds(QRect *bounds) {
	QRect temp = *bounds;
#ifdef DOCVIEW
	OffsetRect(&temp,-GetOpPanel()->m_RecScreenOffset.x,-GetOpPanel()->m_RecScreenOffset.y);
#endif
	m_pCMMwidget->Bounds = *(T_TV_RECT*) &temp;
	SetClientRect();
}
//****************************************************************************
///
/// Sets the Widget Client rectangle (bounds less border)
///	Assumes bounds have been set correctly in advance
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CWidget::SetClientRect() {
	// set up m_WidgetClientRect (equal to bounds less border)
	m_WidgetClientRect = *(QRect*) &m_pCMMwidget->Bounds;
#ifdef DOCVIEW
	OffsetRect(&m_WidgetClientRect,GetOpPanel()->m_RecScreenOffset.x,GetOpPanel()->m_RecScreenOffset.y);
#endif
	// 'inflate' it by negative amounts (i.e. deflate). if no border then m_WidgetClientRect=Bounds
	if (m_pCMMwidget->Border.BorderUsed)
		InflateRect(&m_WidgetClientRect, -m_pCMMwidget->Border.BorderWidth, -m_pCMMwidget->Border.BorderWidth);
#ifdef DOCVIEW
	GetOpPanel()->OnBoundsChanged(this); // update Screen Designer's position/size indicators
#endif
}
//****************************************************************************
///
/// Gets the Actual (not offset) Widget Client rectangle (bounds less border)
/// Co-ordinates are relative to the top-left of the CScreen Window.
///
/// @return QRect structure 
/// 
//****************************************************************************
QRect CWidget::GetWidgetClientActual() {
	QRect temp = m_WidgetClientRect;
#ifdef DOCVIEW
	OffsetRect(&temp,-GetOpPanel()->m_RecScreenOffset.x,-GetOpPanel()->m_RecScreenOffset.y);
#endif
	return temp;
}
//****************************************************************************
///
/// Check the Handles for mouse contact
///
/// @param[in] point	- reference to Point to check against handles
///
/// @return TRUE if a hit and poulates m_WidgetResizeState
/// 
//****************************************************************************
BOOL CWidget::HitTestHandles(QPoint &point) {
	return ::HitTestHandles(GetWidgetBounds(), m_WidgetResizeState, point);
}
//****************************************************************************
///
/// Draw the Handles
///
/// @param[in] hdc	- Device Context handle to draw to
///
/// @return none
/// 
//****************************************************************************
void CWidget::DrawWidgetHandles(HDC hdc) {
	DrawHandles(hdc, GetWidgetBounds(), RGB(0, 255, 0)); // green for Widget
}
//****************************************************************************
///
/// Appends an Object into the list for the Widget
/// 
/// @param[in] pObj - pointer to CBaseObject derived Object to append 
///
/// @return none
/// 
//****************************************************************************
void CWidget::AppendObject(CBaseObject *pObj) {
	CBaseObject **ptr = &m_pObjects; // address of head of list pointer
	while (*ptr) {
		ptr = &((*ptr)->m_pNextObj); // traverse any items in list
	}
	(*ptr) = pObj; // assign onto end of list
	pObj->m_pNextObj = NULL;
}
//****************************************************************************
///
/// removes an Object from the list for the Widget (NB: DOES NOT DELETE IT)
/// 
/// @param[in] pObj - pointer to CBaseObject derived object to remove
///
/// @return TRUE if removed OK, FALSE if not found
/// 
//****************************************************************************
BOOL CWidget::RemoveObject(CBaseObject *pObj) {
	CBaseObject **ptr = &m_pObjects;
	BOOL found = FALSE;
	while (*ptr) {
		if (*ptr == pObj) {
			// found our object.
			*ptr = pObj->m_pNextObj; // remove it from list
			pObj->m_pNextObj = NULL;
			found = TRUE;
			break;
		}
		ptr = &((*ptr)->m_pNextObj);
	}
	return found;
}
//****************************************************************************
///
/// Check the object list to ensure we don't have background objects in front 
/// of foreground ones. i.e. preserve three layers background, middle and foreground.
///
///	At present, this is done during to-top, but may also be used elsewhere
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CWidget::CheckObjectOrder() {
	CBaseObject **ptr = &m_pObjects;
	CBaseObject *pbackHead = NULL;
	CBaseObject **pback = &pbackHead;
	CBaseObject *pmiddleHead = NULL;
	CBaseObject **pmiddle = &pmiddleHead;
	CBaseObject *pforeHead = NULL;
	CBaseObject **pfore = &pforeHead;
	while (*ptr) {
		CBaseObject *pObj = (*ptr);
		if (pObj->m_pCMMbase->IsBackground) {
			// put this object in the background list
			*ptr = pObj->m_pNextObj; // remove it from list
			(*pback) = pObj;
			pback = &pObj->m_pNextObj;
			pObj->m_pNextObj = NULL;
		} else if ((!pObj->m_pCMMbase->IsPermanent) && (!pObj->m_pCMMbase->IsAlphaBlend)) {
			// put this object in the middle list
			*ptr = pObj->m_pNextObj; // remove it from list
			(*pmiddle) = pObj;
			pmiddle = &pObj->m_pNextObj;
			pObj->m_pNextObj = NULL;
		} else {
			// put this object in the foreground list
			*ptr = pObj->m_pNextObj; // remove it from list
			(*pfore) = pObj;
			pfore = &pObj->m_pNextObj;
			pObj->m_pNextObj = NULL;
		}
		// already moved on to next
	}
	// ok now, reconstruct the object list
	// start with the background objects.
	ptr = &m_pObjects;
	if (pbackHead) {
		*ptr = pbackHead;
		ptr = pback;
	}
	if (pmiddleHead) {
		*ptr = pmiddleHead;
		ptr = pmiddle;
	}
	if (pforeHead) {
		*ptr = pforeHead;
		ptr = pfore;
	}
	(*ptr) = NULL; // at the end!
	// fix CMM version to match
	int obSlot = 0;
	CBaseObject *pObj = m_pObjects;
	while (pObj) {
		T_LAYOUTITEM ref = pObj->GetLayoutItem();
		m_pCMMwidget->ObjectList[obSlot] = ref; // put it in array
		obSlot++;
		pObj = pObj->m_pNextObj;
	}
	m_pCMMwidget->NumObjects = obSlot; // just ensure it has the correct number of objects.
}
//****************************************************************************
///
/// move Object to the top of the Z order (end of the list - drawn last)
/// 
/// @param[in] pObj			- pointer to CBaseObject derived object to bring to top
/// @param[in] FlagModified - mark this layout as modified (default=TRUE)
///
/// @return TRUE if completed OK, FALSE if not found
/// 
//****************************************************************************
BOOL CWidget::BringObjectToTop(CBaseObject *pObj, BOOL FlagModified) //=TRUE
		{
	if (!GetOpPanel()->m_bBringObjectOrWidgetToTop)
		return TRUE; // overruled !!
	if (pObj->m_pNextObj == NULL)
		return TRUE; // already at top !!
	CBaseObject **ptr = &m_pObjects;
	BOOL found = FALSE;
	while (*ptr) {
		if ((*ptr) == pObj) {
			// found our object.
			*ptr = pObj->m_pNextObj; // remove it from list
			pObj->m_pNextObj = NULL;
			found = TRUE;
			// continue to end of list....
		}
		ptr = &((*ptr)->m_pNextObj);
	}
	if (found) {
		(*ptr) = pObj; // append our object to end of list (top of Z order)
		CheckObjectOrder(); // this will check the list to ensure we don't have background objects in front of foreground ones
							// i.e. to top works within the three layers background, middle and foreground.
		// now sort out the CMM stuff to match..
		/*		int obSlot=0;
		 T_LAYOUTITEM ref=pObj->GetLayoutItem();
		 for(int i=0; i<m_pCMMwidget->NumObjects; i++)
		 {
		 if((m_pCMMwidget->ObjectList[i].CMM_Inst!=ref.CMM_Inst)||(m_pCMMwidget->ObjectList[i].CMM_Type!=ref.CMM_Type))
		 {
		 if(obSlot<i)						
		 m_pCMMwidget->ObjectList[obSlot]=m_pCMMwidget->ObjectList[i]; // move down one place
		 
		 obSlot++;
		 }		
		 }
		 m_pCMMwidget->ObjectList[obSlot]=ref; // put it in at end of array
		 */
		if (FlagModified)
			SetLayoutModified();
		m_PermValid = FALSE;
	}
	return found;
}
//****************************************************************************
///
/// Move Object to the bottom of the Z order (head of the list - drawn first)
/// 
/// @param[in] pObj - pointer to CBaseObject derived object to send to bottom
///
/// @return TRUE if completed OK, FALSE if not found
/// 
//****************************************************************************
BOOL CWidget::SendObjectToBottom(CBaseObject *pObj) {
	// sends selected object to bottom of the Z order (head of the list - drawn first)
	CBaseObject **ptr = &m_pObjects;
	if ((*ptr) == pObj)
		return TRUE; // already at bottom !!
	BOOL found = FALSE;
	while ((*ptr)) {
		if ((*ptr) == pObj) {
			// found our object.
			*ptr = pObj->m_pNextObj; // remove it from list
			pObj->m_pNextObj = NULL;
			found = TRUE;
			break;
		}
		ptr = &((*ptr)->m_pNextObj);
	}
	if (found) {
		// insert at head...
		pObj->m_pNextObj = m_pObjects;
		m_pObjects = pObj;
		// now sort out the CMM stuff to match..
		T_LAYOUTITEM ref = pObj->GetLayoutItem();
		int obSlot = m_pCMMwidget->NumObjects - 1;
		for (int i = m_pCMMwidget->NumObjects - 1; i >= 0; i--) {
			if ((m_pCMMwidget->ObjectList[i].CMM_Inst != ref.CMM_Inst)
					|| (m_pCMMwidget->ObjectList[i].CMM_Type != ref.CMM_Type)) {
				if (obSlot > i)
					m_pCMMwidget->ObjectList[obSlot] = m_pCMMwidget->ObjectList[i]; // move up one place
				obSlot--;
			}
		}
		m_pCMMwidget->ObjectList[obSlot] = ref; // put it in at start of the array
		SetLayoutModified();
		m_PermValid = FALSE;
	}
	return found;
}
//******************************************************

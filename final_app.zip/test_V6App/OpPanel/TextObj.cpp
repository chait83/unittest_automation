/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: TextObj.cpp
/// @n Description: Text Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  24  Stability Project 1.19.1.3 7/2/2011 5:02:05 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  23  Stability Project 1.19.1.2 7/1/2011 4:39:01 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  22  Stability Project 1.19.1.1 3/17/2011 3:20:49 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  21  Stability Project 1.19.1.0 2/15/2011 3:04:03 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
const USHORT CTextObject::ms_usMAX_TEXT_STRING_LENGTH = 256;
//****************************************************************************
/// CTextObject Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
/// 
//****************************************************************************
CTextObject::CTextObject(CWidget *pParentWidget) : CBaseObject(pParentWidget), m_pwcTempCfgTextString(NULL) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CTextObject::OnDraw;
	// set all of the objects internal settings to defaults
	m_pTextString = NULL;
	m_pDataItemRef = NULL;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
/// 
//****************************************************************************
void CTextObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CTextObject data in CMM info block.
	m_pCMMtext = (T_TEXTOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		if (m_pCMMtext->ChannelInfo.ItemType != DI_GENERAL) {
			// update CMM settings (from the defaults) for this specific Object type
			m_pCMMtext->ChannelInfo.Enabled = TRUE; // Text objects are enabled for dataitem by default.
			m_pCMMtext->ChannelInfo.Updates = FALSE; // but they don't get updated.
		} else {
			// do nothing with general items as these might need to be updated i.e. the logged in user or a AMS2750 max/min TC name
		}
	} else {
		// When loading a previous configuration:
		if (m_pCMMtext->ChannelInfo.ItemType != DI_GENERAL) {
			// initialise any members here from loaded CMM values
			m_pCMMtext->ChannelInfo.Updates = FALSE; // ensure Text Objects do not get updated.
		} else {
			// do nothing with general items as these might need to be updated i.e. the logged in user or a AMS2750 max/min TC name
		}
	}
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CTextObject::ConfigChange() {
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	// Data item configuration done here. 
	// CTextObject only has one data item reference
	BOOL refValid = FALSE;
	if (!m_pDataItemRef) {
		// for text objects, only create a reference if required
		if (m_pCMMtext->ChannelInfo.Enabled) {
			m_pDataItemRef = new CDataItemRef(this); // create our single reference
		}
	}
	if ((m_pDataItemRef) && (m_pWidget->GetDataItem(m_pDataItemRef, &m_pCMMtext->ChannelInfo))) {
		// check if this object is supposed to be updated
		if (m_pCMMtext->ChannelInfo.Updates) {
			// set the data item ref to be updated also
			m_pDataItemRef->Updates = TRUE;
		}
		refValid = TRUE;
	}
	// Now set our members based on CMM settings and data item info
	// T_BASEOBJECT CMM config to CBaseObject members:
	// set our internal members values from the Attribute block or source or CMM 
	// use foreground colour from CMM (e.g. as selected in Screen Designer) as default
	m_pForeColour = &m_pCMMbase->ForeColour;
	if (!m_pCMMbase->FixForeColour) {
		if (m_pCMMbase->AttrBlocks.ForeColourBlk)
			// use foreground colour from Attribute block
			m_pForeColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
					m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
		else if (refValid)
			m_pForeColour = m_pDataItemRef->m_pDataItem->GetColour();// use foreground colour from Data Item Table item		
	}
	// use background colour from CMM (e.g. as selected in Screen Designer) as default
	m_pBackColour = &m_pCMMbase->BackColour;
	if (!m_pCMMbase->FixBackColour) {
		if (m_pCMMbase->AttrBlocks.BackColourBlk)
			// use foreground colour from Attribute block
			m_pBackColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
					m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
		else if (refValid)
			m_pBackColour = m_pDataItemRef->m_pDataItem->GetColour();// use background colour from Data Item Table item
	}
	// T_TEXTOBJECT CMM config to CTextObject members:
	//	may be a user text string from the CMM
	if (m_pCMMtext->FixText) {
		if (m_pwcTempCfgTextString != NULL) {
			m_pWidget->m_pConfig->SetTextString(m_pwcTempCfgTextString, &m_pCMMtext->Offset);
			// release the memory
			//	delete m_pwcTempCfgTextString;
			//	m_pwcTempCfgTextString = NULL;
		}
		m_pTextString = m_pWidget->m_pConfig->GetTextString(m_pCMMtext->Offset);
	} else if (refValid) {
		if (m_pCMMtext->IsUnits)
			m_pTextString = (QString ) m_pDataItemRef->m_pDataItem->GetUnits();
		else if (m_pCMMtext->IsDescription)
			m_pTextString = (QString ) m_pDataItemRef->m_pDataItem->GetDesc();
		else
			m_pTextString = (QString ) m_pDataItemRef->m_pDataItem->GetTag();
	} else
		m_pTextString = m_pWidget->m_pConfig->GetTextString(m_pCMMtext->Offset); // default to CMM	
}
//****************************************************************************
///
/// Drawing function. 
/// This function must do all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed, and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. In both cases the function must 
/// draw *at least* as much as defined by the Clipping Rectangle. Any addtional
/// drawing that is done (outside of the ClipRect) will have no effect, but in 
/// some cases it is easier (and quicker) to simply draw everything for the 
/// Object rather than work out those parts actually required.
///
///	NB: the ClipRect pointer can be NULL indicating the draw is the result of
/// a data update. if m_UpdateRequired is set, then the complete Object should
/// be fully redrawn. If not, the Object can inspect Widgets m_UpdateRgn
/// to see if an optimised draw is possible. At least part of the Object will 
/// be contained in the region for the draw function to have been called
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CTextObject::OnDraw(CTextObject *pThis, HDC hdc, QRect *pClipRect) {
	//if(pThis->isObjectOverlapped()) 
	//	return;
	//HWND hfgWnd		= GetForegroundWindow();
	//QRect rectFG;
	//GetWindowRect(hfgWnd, &rectFG);
	//QRect rectOP;
	//pThis->GetOpPanel()->GetWindowRect(&rectOP);
	//
	//if ( _Width(rectFG) < _Width(rectOP) )	
	//{
	//	// we have found some other window on top of oppanel, so do not paint on that window
	//	if ( pThis->m_ClientRect.left < rectFG.right &&
	//		 pThis->m_ClientRect.right > rectFG.left &&
	//		 pThis->m_ClientRect.top < rectFG.bottom &&
	//		pThis->m_ClientRect.bottom > rectFG.top)
	//	{
	//		return;
	//	}
	//	 
	//	
	//}
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	// if Update Required make any updates due to data item changes then do a repaint
	if (pThis->m_UpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object, 
		// so that we can draw the same value next time if required.
		// does not really apply to text objects !!
		pThis->m_UpdateValue = FALSE;
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	} else {
		// i.e. m_UpdateRequired is FALSE - no data update here
		if (pClipRect == NULL) {
			// Optimised drawing for overlapped objects:
			// here we are drawing because of an update to some other object that overlaps.	
			// We could inspect our parent widget's update region to see how much we need to 
			// draw, setting ObjClipRect, or simply draw everything.
		}
	}
	// Optimised drawing for direct foreground:
	// here if pClipRect is null (drawing an update)
	// we could check the pThis->m_pCMMbase->IsBuffered flag.
	// For updates to a non-buffered Object (direct foreground) we can optimise our
	// drawing (just the updating parts) knowing that this object does not overlap any other,
	// (therefore the rest of the object will still be OK)
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	BOOL DrawInFlashState = FALSE;
	if (*(pThis->m_pFlashing)) // if we are flashing set our drawInFlashState.
		DrawInFlashState = pThis->m_FlashState;
	// font params
	// font Weight default to 400
	// QFont::Normal	400
	// QFont::Medium  500
	// FW_SEMIBOLD	600
	// QFont::Bold		700
	// font Face default 3
	// Tahoma			 0	
	// Times New Roman	 1	
	// Courier New		 2	
	// Tahoma			 3	
	// font Quality default 0
	// DEFAULT_QUALITY		0
	// ANTIALIASED_QUALITY	4
	// CLEARTYPE_QUALITY	5
	CFontCache *pfc = CFontCache::GetHandle();
	QFont hfont;
	if (pThis->m_pCMMtext->Wordwrap)
		hfont = pfc->GetFont(pThis->m_pCMMtext->Font.Height,
				pfc->ConvertFontWeight(static_cast<CFontCache::T_FONT_WEIGHT>(pThis->m_pCMMtext->Font.Weight)),
				pThis->m_pCMMtext->Font.Face,
				pfc->ConvertFontQuality(static_cast<CFontCache::T_FONT_QUALITY>(pThis->m_pCMMtext->Font.Quality)));
	else
		hfont = pfc->GetFont(_Height(pThis->m_ClientRect),
				pfc->ConvertFontWeight(static_cast<CFontCache::T_FONT_WEIGHT>(pThis->m_pCMMtext->Font.Weight)),
				pThis->m_pCMMtext->Font.Face,
				pfc->ConvertFontQuality(static_cast<CFontCache::T_FONT_QUALITY>(pThis->m_pCMMtext->Font.Quality))); // Objects Client Area (bounds less border)
	QFont hOldfont = (QFont) SelectObject(hdc, hfont);
	if (DrawInFlashState)
		SetTextColor(hdc, *pThis->m_pBackColour);
	else
		SetTextColor(hdc, *pThis->m_pForeColour);
	if (pThis->m_pCMMbase->IsTransparent)
		SetBkMode(hdc, TRANSPARENT); // this works like v5. Need full repaint of background to work ok.
	else {
		// DrawText does not fill the rectangle passed as ExtTextOut does.
		// could make this configurable if we wanted to not do it.
		HBRUSH hBrushback; // Create a brush for background
		if (DrawInFlashState) {
			SetBkColor(hdc, *pThis->m_pForeColour);
			hBrushback = CreateSolidBrush(*pThis->m_pForeColour);
		} else {
			SetBkColor(hdc, *pThis->m_pBackColour);
			hBrushback = CreateSolidBrush(*pThis->m_pBackColour);
		}
		FillRect(hdc, &pThis->m_ClientRect, hBrushback);
		// Delete the brush object and free all resources associated with it.
		DeleteObject(hBrushback);
	}
	// use DrawText rather than ExtTextOut here, since required for wordwrap option.
	UINT len = (UINT) wcslen(pThis->m_pTextString);
	if (len)
		DrawText(hdc, pThis->m_pTextString, len,
//			 buff, (UINT)wcslen(buff), // testing only
				&pThis->m_ClientRect,
				DT_NOPREFIX | (pThis->m_pCMMtext->Center ? DT_CENTER : DT_LEFT)
						| (pThis->m_pCMMtext->Wordwrap ? DT_WORDBREAK : DT_SINGLELINE));
	SetBkMode(hdc, OPAQUE); // restore it after possibly setting transparent above
	SelectObject(hdc, hOldfont);
	pfc->ReleaseFont(hfont);
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CTextObject::Destroy() {
	if (m_pwcTempCfgTextString != NULL) {
		// release the memory
		delete m_pwcTempCfgTextString;
		m_pwcTempCfgTextString = NULL;
	}
}
//****************************************************************************
/// QString CTextObject::GetTextString() 
/// 
/// Method that returns a pointer to an internal string that is a copy of the text string held in
/// the CMM
///
/// @return A pointer to an internal string that is a copy of the text string held in the CMM
///
//****************************************************************************
QString  CTextObject::GetTextString() {
	// allocate the memory to the buffer if necessary
	if (m_pwcTempCfgTextString == NULL) {
		m_pwcTempCfgTextString = new WCHAR[ms_usMAX_TEXT_STRING_LENGTH];
	}
	wcsncpy_s(m_pwcTempCfgTextString, ms_usMAX_TEXT_STRING_LENGTH,
			m_pWidget->m_pConfig->GetTextString(m_pCMMtext->Offset), ms_usMAX_TEXT_STRING_LENGTH);
	return m_pwcTempCfgTextString;
}
//****************************************************************************
/// 
/// Sets the internal string in the CMM
///
/// @param[in] pText	- text to set
/// @return none
///
//****************************************************************************
void CTextObject::SetTextString(QString pText) {
	// is the temporary string set? if so delete it.
	if (m_pwcTempCfgTextString != NULL) {
		// release the memory
		delete m_pwcTempCfgTextString;
		m_pwcTempCfgTextString = NULL;
	}
	m_pWidget->m_pConfig->SetTextString(pText, &m_pCMMtext->Offset);
	ConfigChange();
}

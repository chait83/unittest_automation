/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: BitmapObj.cpp
/// @n Description: Bitmap Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  8 Stability Project 1.3.1.3 7/2/2011 4:55:40 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:38:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:12 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:02:17 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "StringUtils.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// ExampleBar Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
/// 
//****************************************************************************
CBitmapObject::CBitmapObject(CWidget *pParentWidget) : CBaseObject(pParentWidget) {
	// reassign function pointer (speed issue)
m_pOnDraw = (ONDRAWCAST) & CBitmapObject::OnDraw;
// set all of the objects internal settings to defaults
#ifdef DOCVIEW  // screen designer use only
m_pDibshowing=NULL;
m_UniqueIDshowing=0;
#endif
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
/// 
//****************************************************************************
void CBitmapObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
CMMInitBase(CMMinfo);
// set up pointer to CBitmapObject data in CMM info block.
m_pCMMbitmap = (T_BITMAPOBJECT*) CMMinfo->pByBlock;
// if bounds passed in, set these here (also updates the CMM values)
// also presume that this is therefore a new Object.
if (bounds) {
	SetBoundsRelative(bounds);
	// update CMM settings (from the defaults) for this specific Object type	
} else {
	// When loading a previous configuration:
	// initialise any members here from loaded CMM values
}
m_pCMMbase->IsAdvancedDraw = TRUE;
m_pCMMbase->IsPrimaryDirect = FALSE; // can not be
m_pCMMbase->IsPermanent = TRUE; // always true for now (otherise is overlay)
m_pCMMbase->IsBackground = TRUE; // here could be foreground.
m_pCMMbase->IsBuffered = FALSE; // does not count for advanced drawn
ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CBitmapObject::ConfigChange() {
// set up our surface pointer here...
if (m_pCMMbase->IsPermanent)
	m_pDDSurf = m_pWidget->m_pDDSPermanent;
SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
// Data item configuration done here. 
// use flash atrtribute from Attribute block if set (0=default=FALSE)
m_pFlashing = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.FlashingBlk)->Flashing;
// use visible atrtribute from Attribute block if set (0=default=TRUE)
m_pVisible = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
}
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CBitmapObject::OnDraw(CBitmapObject *pThis, HDC hdc, QRect *pClipRect) {
if (!pThis->m_pVisible)
	return; // draw nothing.	
// here if permanent, and it's valid, we do not need to do any drawing, since surface is up to date.
if ((pThis->m_pCMMbase->IsPermanent) && (pThis->m_pCMMbase->IsPermValid))
	return;
// here if permanent, and not permvalid, then we need a full redraw
if ((pThis->m_pCMMbase->IsPermanent) && (!pThis->m_pCMMbase->IsPermValid)) {
	// load the bitmap onto the permanent surface.. (HDC will be NULL)
	if (pThis->m_pCMMbitmap->UniqueID) {
		WCHAR PathAndFileName[MAX_PATH];
		// build the filename
#ifdef DOCVIEW
			// for screen designer bitmaps always come from the library file
			// and once loaded we'll keep the dib in memory
			if(pThis->m_UniqueIDshowing!=pThis->m_pCMMbitmap->UniqueID)
			{
				CBitmapCollectionFile::BuildFilename(PathAndFileName);
				CBitmapCollectionFile bcf(PathAndFileName,CBitmapCollectionFile::ReadOnly);
				
				if(pThis->m_pDibshowing)
					delete pThis->m_pDibshowing;
				
				pThis->m_pDibshowing=bcf.LoadDib(pThis->m_pCMMbitmap->UniqueID);
				pThis->m_UniqueIDshowing=pThis->m_pCMMbitmap->UniqueID;
			}
			if(pThis->m_pDibshowing)
				pThis->m_pDibshowing->LoadToSurface(pThis->m_pDDSurf,pThis->m_ClientRect);
				
		
#else
		// for recorder:
		CBitmapCollectionFile::BuildFilename(PathAndFileName);
		CBitmapCollectionFile bcf(PathAndFileName, CBitmapCollectionFile::ReadOnly);
		if (CDib *pDib = bcf.LoadDib(pThis->m_pCMMbitmap->UniqueID)) {
			pDib->LoadToSurface(pThis->m_pDDSurf, pThis->m_ClientRect);
			delete pDib;
		}
#endif
	}
	if (pThis->m_pCMMbase->Border.BorderUsed) {
		HDC pshdc;
		if (pThis->m_pDDSurf->GetDC(&pshdc) == DD_OK) {
			DrawBorder(pshdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
			pThis->m_pDDSurf->ReleaseDC(pshdc);
		}
	}
	pThis->m_pCMMbase->IsPermValid = TRUE; // now valid
}
}
//****************************************************************************
///
/// Safe way to set the name of the image used in the object
///
/// @param[in] nameToSet		- pointer to string to copy
///
/// @return none
/// 
//****************************************************************************
void CBitmapObject::SetName(QString nameToSet) {
CStringUtils::SafeWcsCpy(m_pCMMbitmap->Name, nameToSet, BITMAP_VISIBLE_NAME_LENGTH);
}
//****************************************************************************
/// Get the XFactor - ratio of width to height
///
/// @param[in] bounds	- bounds to use for x factor calculation (not current bounds)
///						 these are only used as default. If an image exists
///						 it's original size will be used.
/// @return xfactor
/// 
//****************************************************************************
float CBitmapObject::GetXfactor(QRect bounds) {
float xfactor = 0.0;
#ifdef DOCVIEW
	if(m_UniqueIDshowing)
	{
		QRect imagesize=m_pDibshowing->GetDimensions();
		xfactor=imagesize.right/(float)imagesize.bottom;			
	}
	else
		xfactor=_Width(bounds)/(float)_Height(bounds);	
#else
// for recorder: this may be too slow - needs reviewing if/when designer mode is enabled on the recorder
WCHAR PathAndFileName[MAX_PATH];
CBitmapCollectionFile::BuildFilename(PathAndFileName);
CBitmapCollectionFile bcf(PathAndFileName, CBitmapCollectionFile::ReadOnly);
if (CDib *pDib = bcf.LoadDib(m_pCMMbitmap->UniqueID)) {
	QRect imagesize = pDib->GetDimensions();
	xfactor = imagesize.right / (float) imagesize.bottom;
	delete pDib;
} else
	xfactor = _Width(bounds) / (float) _Height(bounds);
#endif
return xfactor;
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CBitmapObject::Destroy() {
#ifdef DOCVIEW
	if(m_pDibshowing)
	{
		delete m_pDibshowing;
		m_pDibshowing=NULL;
	}
#endif
}

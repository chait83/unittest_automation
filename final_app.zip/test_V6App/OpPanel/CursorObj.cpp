/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CursorObj.cpp
/// @n Description: Cursor Object for Replay and Analysis
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  22  Stability Project 1.17.1.3 7/2/2011 4:56:27 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  21  Stability Project 1.17.1.2 7/1/2011 4:38:11 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  20  Stability Project 1.17.1.1 3/17/2011 3:20:19 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  19  Stability Project 1.17.1.0 2/15/2011 3:02:48 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "TimeHistory.h"
#include <float.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// CCursorObject Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
/// 
//****************************************************************************
CCursorObject::CCursorObject(CWidget *pParentWidget) : CBaseObject(pParentWidget) {
	// assign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CCursorObject::OnDraw;
	m_pChartObject = NULL;
	m_enabledReplayPens = 0;
	m_DualCursors = FALSE; // default to single cursor
	m_Cursor1Moves = TRUE; // default cursor 1 moves only
	m_Cursor2Moves = FALSE;
	m_CursorsLinked = FALSE;
	for (int p = 0; p < MAX_CHART_PENS; p++) {
		m_pChartQ[p] = NULL;
		m_pDataItemMax[p] = NULL;
		m_pDataItemMin[p] = NULL;
	}
	m_1OnleftSide = FALSE;
	m_2OnleftSide = FALSE;
	m_1OnTopSide = TRUE;
	m_2OnTopSide = TRUE;
	m_MousePos.x = 0;
	m_MousePos.y = 0;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
/// 
//****************************************************************************
void CCursorObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CCursorObject data in CMM info block.
	m_pCMMcursor = (T_CURSOROBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
	}
	// always:
	m_pCMMbase->IsTransparent = TRUE;
	m_pCMMbase->IsBuffered = TRUE;
	m_pCMMbase->IsAlphaBlend = FALSE; //for now - will be on during cursor moves
	m_pCMMbase->IsBackground = TRUE; // this is not technically correct, but allows CheckObjectOrder to work
	ConfigChange();
	// now bounds have been set - first time in set up the cursor positions
	if (m_pCMMcursor->IsVertical)
		m_Cursor1Pos = m_ClientRect.bottom - 1 - _Height(m_ClientRect) / 2;
	else
		m_Cursor1Pos = m_ClientRect.left + _Width(m_ClientRect) / 2;
	m_MousePos.x = _Width(m_ClientRect) / 2;
	m_MousePos.y = _Height(m_ClientRect) / 2;
	if (m_pCMMcursor->IsVertical)
		m_Cursor1Time = (m_ClientRect.bottom - 1 - m_Cursor1Pos) * m_pChartObject->m_Tpp + m_pChartObject->m_Origin100;
	else
		m_Cursor1Time = (m_Cursor1Pos - m_ClientRect.left) * m_pChartObject->m_Tpp + m_pChartObject->m_Origin100;
	SetActualTime1();
	// now set up cursor 2 the same (for dual cursor use)
	m_Cursor2Pos = m_Cursor1Pos;
	m_Cursor2Time = m_Cursor1Time;
	SetActualTime2();
}
int edge = 12;
//****************************************************************************
///
/// Calculates the new cursor position (after zoom, jump etc)
/// from the displaytime (later the displaytime will be calc'd from the pos)
///
/// @param[] none
///
/// @return none
/// 
//****************************************************************************
void CCursorObject::CalcNewCursorPos() {
	if (!m_DualCursors) {
		// for a single cursor, will be in the middle of the chart (approx)
		// NB: here the 
		if (m_pCMMcursor->IsVertical)
			m_Cursor1Pos = (int) (m_ClientRect.bottom - 1
					- ((m_display1Time - m_pChartObject->m_Origin100) / m_pChartObject->m_Tpp));
		else
			m_Cursor1Pos = (int) ((m_display1Time - m_pChartObject->m_Origin100) / m_pChartObject->m_Tpp)
					+ m_ClientRect.left;
		/*
		 qDebug("NEW cursor1pos %d\n",m_Cursor1Pos);	
		 LONGLONG dTime=(m_Cursor1Pos-m_ClientRect.left)*m_pChartObject->m_Tpp+m_pChartObject->m_Origin100;			
		 {
		 CTimeHistory* pTh=CTimeHistory::GetHandle();
		 TableEntry* pEntry=pTh->GetEntry(dTime);
		 if(!pEntry)
		 return;  // major problem here - no time history!
		 
		 LONGLONG diffmicro=(display1Time-pEntry->Tick100)*10000;	
		 CTVtime displaytime=pEntry->ActualTime;
		 displaytime+=diffmicro; // actual realworld time of this position.

		 LONGLONG displaytime100=displaytime.GetMicroSecs()/10000; 
		 displaytime100-=(displaytime100%m_pChartObject->m_Tpp); // on boundary
		 
		 displaytime=(displaytime100*10000);
		 WCHAR buff1[20];
		 WCHAR buff2[20];
		 
		 TimeToString(&displaytime,buff1, buff2, (m_pChartObject->m_Tpp<=50)); // see fracs if true
		 
		 qDebug("Equates to %s %s\n", buff1, buff2);
		 }
		 */
	} else {
		// for dual, the center of the zoom in/out will be in the center for the chart.
		// need to set the dual cursors accordingly.
		// if zoom in puts them out of the screen area, put them at the edges.
		BOOL updatetime1 = FALSE;
		BOOL updatetime2 = FALSE;
		if (m_pCMMcursor->IsVertical) {
			m_Cursor1Pos = (int) (m_ClientRect.bottom - 1
					- ((m_display1Time - m_pChartObject->m_Origin100) / m_pChartObject->m_Tpp));
			m_Cursor2Pos = (int) (m_ClientRect.bottom - 1
					- ((m_display2Time - m_pChartObject->m_Origin100) / m_pChartObject->m_Tpp));
			if (m_Cursor1Pos < m_ClientRect.top + edge) {
				m_Cursor1Pos = m_ClientRect.top + edge;
				updatetime1 = TRUE;
			}
			if (m_Cursor1Pos > m_ClientRect.bottom - 1 - edge) {
				m_Cursor1Pos = m_ClientRect.bottom - 1 - edge;
				updatetime1 = TRUE;
			}
			if (m_Cursor2Pos < m_ClientRect.top + edge) {
				m_Cursor2Pos = m_ClientRect.top + edge;
				updatetime2 = TRUE;
			}
			if (m_Cursor2Pos > m_ClientRect.bottom - 1 - edge) {
				m_Cursor2Pos = m_ClientRect.bottom - 1 - edge;
				updatetime2 = TRUE;
			}
			//here set up the flag directions to make it easier to see which is which
			if (m_Cursor1Pos > m_Cursor2Pos) {
				m_1OnTopSide = FALSE;
				m_2OnTopSide = TRUE;
			} else {
				m_1OnTopSide = TRUE;
				m_2OnTopSide = FALSE;
			}
			if (updatetime1) {
				m_Cursor1Time = (m_ClientRect.bottom - 1 - m_Cursor1Pos) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
				SetActualTime1();
			}
			if (updatetime2) {
				m_Cursor2Time = (m_ClientRect.bottom - 1 - m_Cursor2Pos) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
				SetActualTime2();
			}
		} else // Horizontal
		{
			m_Cursor1Pos = (int) ((m_display1Time - m_pChartObject->m_Origin100) / m_pChartObject->m_Tpp)
					+ m_ClientRect.left;
			m_Cursor2Pos = (int) ((m_display2Time - m_pChartObject->m_Origin100) / m_pChartObject->m_Tpp)
					+ m_ClientRect.left;
			if (m_Cursor1Pos < m_ClientRect.left + edge) {
				m_Cursor1Pos = m_ClientRect.left + edge;
				updatetime1 = TRUE;
			}
			if (m_Cursor1Pos > m_ClientRect.right - edge) {
				m_Cursor1Pos = m_ClientRect.right - edge;
				updatetime1 = TRUE;
			}
			if (m_Cursor2Pos < m_ClientRect.left + edge) {
				m_Cursor2Pos = m_ClientRect.left + edge;
				updatetime2 = TRUE;
			}
			if (m_Cursor2Pos > m_ClientRect.right - edge) {
				m_Cursor2Pos = m_ClientRect.right - edge;
				updatetime2 = TRUE;
			}
			if (updatetime1) {
				m_Cursor1Time = (m_Cursor1Pos - m_ClientRect.left) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
				SetActualTime1();
			}
			if (updatetime2) {
				m_Cursor2Time = (m_Cursor2Pos - m_ClientRect.left) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
				SetActualTime2();
			}
			//here set up the flag directions to make it easier to see which is which
			if (m_Cursor1Pos > m_Cursor2Pos) {
				m_1OnleftSide = FALSE;
				m_2OnleftSide = TRUE;
			} else {
				m_1OnleftSide = TRUE;
				m_2OnleftSide = FALSE;
			}
		}
	}
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CCursorObject::ConfigChange() {
	// Data item configuration done here. 
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	// Set our members based on CMM settings and data item info
	// T_CURSOROBJECT CMM config to CCursorObject members:
	// get a pointer to our associated chart object
	m_pChartObject = NULL;
	CBaseObject *pObj = m_pWidget->m_pObjects;
	while (pObj) {
		if (pObj->m_pCMMbase->ObjectType == ChartObject) {
			m_pChartObject = ((CChartObject*) pObj);
			break;
		}
		pObj = pObj->m_pNextObj;
	}
	// ok, here we need to generate our pointers to the Data items that we will set with
	// the max and min values under the cursor.
	T_CHANNELREF channelInfo;
	channelInfo.Enabled = TRUE;
	channelInfo.Updates = FALSE;
	channelInfo.Rotate = FALSE;
	channelInfo.ItemType = DI_PEN;
	channelInfo.SubType = DI_PEN_READING;	// default
	m_enabledReplayPens = 0;
	USHORT usMaxChartPens;
	T_DEV_TYPE recorderType = GetOpPanel()->m_pMainConfig->GetRecorderType();
	if (recorderType == DEV_ARISTOS_MULTIPLUS || recorderType == DEV_XS_MULTIPLUS || recorderType == DEV_SCR_MINITREND)
		usMaxChartPens = 18;	// 18 pens max for replay on multi EDF enhancements
	else
		usMaxChartPens = 8;	// for mini 8 pens max.	
	CChartQManager *CM = CChartQManager::GetHandle();
	// work through the widgets channel list, checking that the channels are enabled etc.
	for (int i = 0; i < usMaxChartPens; i++) {
		if (i < m_pWidget->m_pCMMwidget->NumChannels) {
			// complete our channel Ref info here
			channelInfo.IndexChan = i;	// use Widget's channel index
			CDataItem *pDataItem = m_pWidget->GetDataItemPtr(&channelInfo);
			if (pDataItem && pDataItem->IsEnabled())	// is the widgets data item actually enabled?
					{
				// ok, so it's a valid item. now we need to get the locations in the data item table to PUT our
				// max min chart values.
				// here the maxmin chart indexs were added for each widget/screen item that exists.
				// just select the correct index
				m_pDataItemMax[m_enabledReplayPens] = GetOpPanel()->m_pDIT->GetDataItemPtr(DI_PEN, DI_PEN_MM_REPLAY, i);
				m_pDataItemMin[m_enabledReplayPens] = GetOpPanel()->m_pDIT->GetDataItemPtr(DI_PEN, DI_PEN_MM_REPLAY,
						MAX_REPLAY_PENS + i);
				int penIndex = pDataItem->GetInstance();				// the actual pen index (pen number less 1)
				// also get a pointer to the chart queue data
				m_pChartQ[m_enabledReplayPens] = CM->AddStripChartQ(penIndex, m_pChartObject->m_ChartSpeed);
				m_enabledReplayPens++;
			}
		}
	}
	CalcTimestampsRect();
}
//****************************************************************************
///
/// Set the actual time for cursor 1 from Cursor1Time. Actual time does not 
/// change during zooming so provides a more consistant user experience
/// 
///	@param none
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::SetActualTime1() {
// set actual realworld time from cursor1
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(m_Cursor1Time);
	if (!pEntry)
		return;  // major problem here - no time history!
	LONGLONG diffmicro = (m_Cursor1Time - pEntry->Tick100) * 10000;
	CTVtime rwtime = pEntry->ActualTime;
	rwtime += diffmicro; // actual realworld time of this position.
	m_actualtime1 = rwtime.GetMicroSecs() / 10000;
	m_actualtime1 -= (m_actualtime1 % m_pChartObject->m_Tpp); // on boundary
	// correct m_Cursor1Time
//	LONGLONG correction=m_Cursor1Time;
//	m_Cursor1Time=m_actualtime1-(pEntry->ActualTime.GetMicroSecs()/10000)+pEntry->Tick100;
//
//	qDebug("Correction %I64d \n",correction-m_Cursor1Time);
	rwtime = (m_actualtime1 * 10000);
	WCHAR buff1[20];
	WCHAR buff2[20];
	TimeToString(&rwtime, buff1, buff2, (m_pChartObject->m_Tpp <= 50)); // see fracs if true
	m_display1Time = m_Cursor1Time;
	//qDebug("set actual time 1 to %s %s\n",buff1, buff2);
}
//****************************************************************************
///
/// Set the actual time for cursor 2 from Cursor2Time. Actual time does not 
/// change during zooming so provides a more consistant user experience
/// 
///	@param none
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::SetActualTime2() {
// set actual realworld time from cursor2
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(m_Cursor2Time);
	if (!pEntry)
		return;  // major problem here - no time history!
	LONGLONG diffmicro = (m_Cursor2Time - pEntry->Tick100) * 10000;
	CTVtime rwtime = pEntry->ActualTime;
	rwtime += diffmicro; // actual realworld time of this position.
	m_actualtime2 = rwtime.GetMicroSecs() / 10000;
	m_actualtime2 -= (m_actualtime2 % m_pChartObject->m_Tpp); // on boundary
	rwtime = (m_actualtime2 * 10000);
	WCHAR buff1[20];
	WCHAR buff2[20];
	TimeToString(&rwtime, buff1, buff2, (m_pChartObject->m_Tpp <= 50)); // see fracs if true
	m_display2Time = m_Cursor2Time;
	//qDebug("set actual time 2 to %s %s\n",buff1, buff2);
}
//****************************************************************************
///
/// Mouse down - update the cursor position.
///
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::UpdateCursorPos(QPoint &point) {
	m_MousePos = point;
	int diff = m_Cursor2Pos - m_Cursor1Pos;
	if (m_Cursor1Moves) {
		if (m_pCMMcursor->IsVertical) {
			m_Cursor1Pos = point.y + m_ClientRect.top;
			m_Cursor1Time = (m_ClientRect.bottom - 1 - m_Cursor1Pos) * m_pChartObject->m_Tpp
					+ m_pChartObject->m_Origin100;
		} else {
			m_Cursor1Pos = point.x - m_ClientRect.left;
			m_Cursor1Time = (m_Cursor1Pos - m_ClientRect.left) * m_pChartObject->m_Tpp + m_pChartObject->m_Origin100;
		}
		SetActualTime1();
	} else if (m_Cursor2Moves) {
		if (m_pCMMcursor->IsVertical) {
			m_Cursor2Pos = point.y + m_ClientRect.top;
			m_Cursor2Time = (m_ClientRect.bottom - 1 - m_Cursor2Pos) * m_pChartObject->m_Tpp
					+ m_pChartObject->m_Origin100;
		} else {
			m_Cursor2Pos = point.x - m_ClientRect.left;
			m_Cursor2Time = (m_Cursor2Pos - m_ClientRect.left) * m_pChartObject->m_Tpp + m_pChartObject->m_Origin100;
		}
		SetActualTime2();
	}
	if (m_CursorsLinked) {
		if (m_Cursor1Moves) {
			m_Cursor2Pos = m_Cursor1Pos + diff; // in this case cursor 1 is the main cursor
			if (m_pCMMcursor->IsVertical)
				m_Cursor2Time = (m_ClientRect.bottom - 1 - m_Cursor2Pos) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
			else
				m_Cursor2Time = (m_Cursor2Pos - m_ClientRect.left) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
			SetActualTime2();
		} else {
			m_Cursor1Pos = m_Cursor2Pos - diff; // in this case cursor 1 is the main cursor
			if (m_pCMMcursor->IsVertical)
				m_Cursor1Time = (m_ClientRect.bottom - 1 - m_Cursor1Pos) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
			else
				m_Cursor1Time = (m_Cursor1Pos - m_ClientRect.left) * m_pChartObject->m_Tpp
						+ m_pChartObject->m_Origin100;
			SetActualTime1();
		}
	}
}
//****************************************************************************
///
/// Mouse down - update the cursor position.
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::OnMouseDown(UINT nFlags, QPoint &point) {
	UpdateCursorPos(point);
	m_pCMMbase->IsAlphaBlend = TRUE;
	m_UpdateValue = TRUE; // set here to ensure we update the cursor
}
//****************************************************************************
///
/// Updates the cursor position when mouse moved (with left buttondown)
/// or when dragged on touchscreen.
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::OnMouseMove(UINT nFlags, QPoint &point) {
	UpdateCursorPos(point);
	m_UpdateValue = TRUE; // set here to ensure we update the cursor
}
//****************************************************************************
///
/// Handler for mouse/touchscreen up
///
/// @param[in] nFlags	- flags are as for MFC (see CWidget::OnMouseMove)
///	@param[in] point	- Reference	to mouse point
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::OnMouseUp(UINT nFlags, QPoint &point) {
	m_pCMMbase->IsAlphaBlend = FALSE;
	m_UpdateValue = TRUE; // set here to ensure we update the cursor
}
//****************************************************************************
///
/// Handler for keypresses
///
/// @param[in] ch	- key pressed
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::OnChar(wchar_t ch) {
	if (ch == 'z' || ch == 'Z') {
		m_pWidget->SendObjectToBottom(this);
	}
}
//****************************************************************************
///
/// Set Dual cursor mode ON or OFF
///
/// @param[in] enable	- True if Dual cursors being turned ON, False if OFF
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::SetDualCursors(BOOL enable) {
	if (m_DualCursors = enable) {
		m_Cursor2Pos = m_Cursor1Pos;
		m_Cursor2Time = m_Cursor1Time;
		SetActualTime2();
	}
	// reset all these to defaults.
	m_Cursor1Moves = TRUE;
	m_Cursor2Moves = FALSE;
	m_CursorsLinked = FALSE;
}
//****************************************************************************
///
/// Swap (toggle) the moveable cursor
///
/// @param none
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::SwapCursors() {
	if ((m_Cursor1Moves) && (m_DualCursors)) {
		m_Cursor1Moves = FALSE;
		m_Cursor2Moves = TRUE;
	} else {
		m_Cursor1Moves = TRUE;
		m_Cursor2Moves = FALSE;
	}
}
//****************************************************************************
///
///	Link or Unlink Cursors
///
/// @param[in] link -	TRUE to link, FALSE to unlink
/// 
/// @return none
/// 
//****************************************************************************	
void CCursorObject::LinkUnlinkCursors(BOOL link) {
	if (m_DualCursors)
		m_CursorsLinked = link;
}
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CCursorObject::OnDraw(CCursorObject *pThis, HDC hdc, QRect *pClipRect) {
	ReadContext rc;
	CHARTRET retval;
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	// if Update Required it will be due to mouse input for the cursor.
	if (pThis->m_UpdateRequired) {
		pThis->m_UpdateValue = FALSE; // flag we have seen the update
		pThis->m_UpdateRequired = FALSE;
	}
	// here we are going to PUT values into the dataitem table.
	// we do this each time the cursor is updated (which will be when the cursor position is moved, or the (overlapped) chart updates
	if (pThis->m_pCMMcursor->IsVertical)
		pThis->m_display1Time = (pThis->m_ClientRect.bottom - 1 - pThis->m_Cursor1Pos) * pThis->m_pChartObject->m_Tpp
				+ pThis->m_pChartObject->m_Origin100;
	else
		pThis->m_display1Time = (pThis->m_Cursor1Pos - pThis->m_ClientRect.left) * pThis->m_pChartObject->m_Tpp
				+ pThis->m_pChartObject->m_Origin100;
	if (!pThis->m_DualCursors) {
		// Single cursor 
		for (int p = 0; p < pThis->m_enabledReplayPens; p++) {
			rc.m_LocateTime = pThis->m_display1Time;
			retval = pThis->m_pChartQ[p]->GetFirstReading(&rc); // gets readings for the width of the pixel
			// If we got a valid reading for the time (allow for rounding down), set the DIT values and status accordingly			
			if (retval == DATA_OK) {
				LONGLONG diff = (pThis->m_display1Time - rc.m_LocateTime);
				if (diff < 0)
					diff = -diff;
				if (diff <= pThis->m_pChartObject->m_Tpp)
					pThis->SetValuesAndStatus(p, rc.m_max, rc.m_min);
				else
					pThis->SetStatusInvalid(p);
			} else
				pThis->SetStatusInvalid(p);
		}
	} else //DUAL CURSORS
	{
		// Here we need to calc the max and min between the cursors
		LONGLONG endtime;
		CBasicMaxMin maxmin;
		if (pThis->m_pCMMcursor->IsVertical)
			pThis->m_display2Time = (pThis->m_ClientRect.bottom - 1 - pThis->m_Cursor2Pos)
					* pThis->m_pChartObject->m_Tpp + pThis->m_pChartObject->m_Origin100;
		else
			pThis->m_display2Time = (pThis->m_Cursor2Pos - pThis->m_ClientRect.left) * pThis->m_pChartObject->m_Tpp
					+ pThis->m_pChartObject->m_Origin100;
		for (int p = 0; p < pThis->m_enabledReplayPens; p++) {
			// now get the readings between the two times, maxmin-ing as we go.
			// find the earlier time of the two cursors
			if (pThis->m_display1Time <= pThis->m_display2Time) {
				rc.m_LocateTime = pThis->m_display1Time;
				// Here setup endtime to the end of the pixel (infact start of next pixel, then test LESS THAN)
				endtime = pThis->m_display2Time + pThis->m_pChartObject->m_Tpp;
//				pThis->m_display2Time=endtime; // update cursor 2 time - here slight error, but is now exact for display purposes
			} else {
				rc.m_LocateTime = pThis->m_display2Time;
				// Here setup endtime to the end of the pixel (infact start of next pixel, then test LESS THAN)
				endtime = pThis->m_display1Time + pThis->m_pChartObject->m_Tpp;
//				pThis->m_display1Time=endtime; // update cursor 1 time - here slight error, but is now exact for display purposes
			}
			maxmin.ResetMaxMin();
			retval = pThis->m_pChartQ[p]->GetFirstReading(&rc);
			while (retval == DATA_OK && (rc.m_LocateTime < endtime)) // check LESS THAN endtime here due to +1 Tpp above
			{
				maxmin.DoMaxMinForReading(rc.m_max);
				maxmin.DoMaxMinForReading(rc.m_min);
				rc.m_LocateTime += pThis->m_pChartObject->m_Tpp;
				retval = pThis->m_pChartQ[p]->GetNextReading(&rc);
			}
			if ((maxmin.GetMin() != FLT_MAX) || (maxmin.GetMax() != -FLT_MAX)) // has a value?
				// here we have a calculated max and min to display.
				pThis->SetValuesAndStatus(p, maxmin.GetMax(), maxmin.GetMin());
			else
				pThis->SetStatusInvalid(p);
		}
	}
	// Optimised drawing for direct foreground:
	// here if pClipRect is null (drawing an update)
	// we could check the pThis->m_pCMMbase->IsBuffered flag.
	// For updates to a non-buffered Object (direct foreground) we can optimise our
	// drawing (just the updating parts) knowing that this object does not overlap any other,
	// (therefore the rest of the object will still be OK)
	pThis->m_pWidget->SetClipRect(hdc, &pThis->m_ClientRect);
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	if (pThis->m_pCMMcursor->IsVertical)
		pThis->DrawCursorV(hdc);
	else
		pThis->DrawCursorH(hdc);
	pThis->m_pWidget->RestoreClipping(hdc);
}
//****************************************************************************
/// Set the value and Status for the enabled pen 
///
/// @param[in] enabledPenIndex	- index into list of enabled pens
/// @param[in] max	- Max
/// @param[in] min	- Min
///
/// @return none
/// 
//****************************************************************************
void CCursorObject::SetValuesAndStatus(int enabledPenIndex, float max, float min) {
	T_DATAITEM_STATUS newstatusMax = DISTAT_NORMAL;
	T_DATAITEM_STATUS newstatusMin = DISTAT_NORMAL;
	if (max == FLT_MAX)
		newstatusMax = DISTAT_INPUT_OVERRANGE;
	else if (max == -FLT_MAX)
		newstatusMax = DISTAT_INPUT_UNDERRANGE;
	else if (max < m_pDataItemMax[enabledPenIndex]->GetZero())
		newstatusMax = DISTAT_UNDERRANGE;
	else if (max > m_pDataItemMax[enabledPenIndex]->GetSpan())
		newstatusMax = DISTAT_OVERRANGE;
	if (min == FLT_MAX)
		newstatusMin = DISTAT_INPUT_OVERRANGE;
	else if (min == -FLT_MAX)
		newstatusMin = DISTAT_INPUT_UNDERRANGE;
	else if (min < m_pDataItemMin[enabledPenIndex]->GetZero())
		newstatusMin = DISTAT_UNDERRANGE;
	else if (min > m_pDataItemMin[enabledPenIndex]->GetSpan())
		newstatusMin = DISTAT_OVERRANGE;
	// need to set the status before setting the values
	// ONLY set the status and value if changed
	if (m_pDataItemMax[enabledPenIndex]->GetStatus() != newstatusMax)
		m_pDataItemMax[enabledPenIndex]->SetStatus(newstatusMax);
	if (m_pDataItemMin[enabledPenIndex]->GetStatus() != newstatusMin)
		m_pDataItemMin[enabledPenIndex]->SetStatus(newstatusMin);
	if (m_pDataItemMax[enabledPenIndex]->GetFPValue() != max)
		m_pDataItemMax[enabledPenIndex]->SetValue(max);
	if (m_pDataItemMin[enabledPenIndex]->GetFPValue() != min)
		m_pDataItemMin[enabledPenIndex]->SetValue(min);
}
//****************************************************************************
/// Set the Status for the enabled pen to Invalid
///
/// @param[in] enabledPenIndex	- index into list of enabled pens
///
/// @return none
/// 
//****************************************************************************
void CCursorObject::SetStatusInvalid(int enabledPenIndex) {
	if (m_pDataItemMax[enabledPenIndex]->GetStatus() != DISTAT_INVALID)
		m_pDataItemMax[enabledPenIndex]->SetStatus(DISTAT_INVALID);
	if (m_pDataItemMin[enabledPenIndex]->GetStatus() != DISTAT_INVALID)
		m_pDataItemMin[enabledPenIndex]->SetStatus(DISTAT_INVALID);
}
//****************************************************************************
/// Calculate the timestamp rectangle used for horiz and vert timestamps
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CCursorObject::CalcTimestampsRect() {
	// create our DeviceContext for font usage..
	HDC tempHdc = CreateCompatibleDC(NULL); // compatible with our current screen.
	CFontCache *pfc = CFontCache::GetHandle();
	QFont hfont;
	T_DEV_TYPE recorderType = GetOpPanel()->m_pMainConfig->GetRecorderType();
	if (recorderType == DEV_ARISTOS_MULTIPLUS || recorderType == DEV_XS_MULTIPLUS || recorderType == DEV_SCR_MINITREND)
		m_TSfontHeight = 15; // slightly larger than chart
	else
		m_TSfontHeight = 14;
	SIZE size1;
	SIZE size2;
	SIZE longestmonthsize;
	/*
	 0	"Arial",
	 1	"Times New Roman",
	 2	"Courier New",
	 3	"Tahoma",
	 */
	if (m_TSfontHeight > 13)
		hfont = pfc->GetFont(m_TSfontHeight, QFont::Bold, 3, ANTIALIASED_QUALITY);
	else
		hfont = pfc->GetFont(m_TSfontHeight, QFont::Normal, 3, DEFAULT_QUALITY);
	QFont hOldfont = (QFont) SelectObject(tempHdc, hfont);
	QString temp1 = L"12:21:15.45";
	if (m_pChartObject->m_Tpp > 50)
		temp1 = L"12:21:15"; // no fracs
	//QString temp2=L"10 Janv. 05"; // janv. is widest month (french)
	QString temp2 = L"10 05"; // just day and year.. add month size below
	GetTextExtentPoint(tempHdc, temp1, (int) wcslen(temp1), &size1);
	GetTextExtentPoint(tempHdc, temp2, (int) wcslen(temp2), &size2);
	GetTextExtentPoint(tempHdc, m_pChartObject->m_longestMonthBuff, (int) wcslen(m_pChartObject->m_longestMonthBuff),
			&longestmonthsize);
	size2.cx += longestmonthsize.cx; // add longest month width
	if (size2.cx > size1.cx)
		size1 = size2; // get the longest in size1
	SelectObject(tempHdc, hOldfont);
	pfc->ReleaseFont(hfont);
	SetRectEmpty(&m_TSrect);
	m_TSrect.setright(size1).cx + 1;
	m_TSrect.setBottom(size1).cy * 2;
	m_bannerHeight = size1.cy;
	DeleteDC(tempHdc);
}
//****************************************************************************
/// Draw Cursor in Horizontal chart mode
///
/// @param[in] hdc	- Handle to Device Context to use (or NULL)
///
/// @return none
/// 
//****************************************************************************
void CCursorObject::DrawCursorH(HDC hdc) {
	QPoint fingerpos = m_MousePos;
	// check finger pos is on the chart area, and allow for number of cursors
	int checkoffset = m_TSrect.bottom + m_bannerHeight;
	if (m_DualCursors)
		checkoffset += m_bannerHeight * 5;
	if (fingerpos.y > m_ClientRect.bottom)
		fingerpos.y = m_ClientRect.bottom;
	else if (fingerpos.y < m_ClientRect.top + checkoffset)
		fingerpos.y = m_ClientRect.top + checkoffset;
	QPoint topflagpos = fingerpos;
	topflagpos.y -= m_bannerHeight * 3; // higher than finger position
	QPen blackpen = ::CreatePen(PS_SOLID, 0, RGB(0, 0, 0));
	QPen greypen = ::CreatePen(PS_SOLID, 0, RGB(105, 105, 105));
	QPen oldpen;
	if (m_pCMMbase->IsAlphaBlend)
		oldpen = (QPen) SelectObject(hdc, blackpen);
	else
		oldpen = (QPen) SelectObject(hdc, greypen);
	// draw cursor 1 
	MoveToEx(hdc, m_Cursor1Pos, m_ClientRect.top, NULL);
	LineTo(hdc, m_Cursor1Pos, m_ClientRect.bottom);
	MoveToEx(hdc, m_Cursor1Pos - 1, m_ClientRect.top, NULL);
	LineTo(hdc, m_Cursor1Pos - 1, m_ClientRect.bottom);
	MoveToEx(hdc, m_Cursor1Pos + 1, m_ClientRect.top, NULL);
	LineTo(hdc, m_Cursor1Pos + 1, m_ClientRect.bottom);
	// draw triangles..
	int h = -1;
	for (int t = 0; t < 9; t++) {
		if (t <= 4)
			h += 2;
		else
			h -= 2;
		MoveToEx(hdc, m_Cursor1Pos - 4 + t, m_ClientRect.top, NULL);
		LineTo(hdc, m_Cursor1Pos - 4 + t, m_ClientRect.top + h);
	if(m_Cursor1Moves)
	{
		MoveToEx(hdc,m_Cursor1Pos-2-h,fingerpos.y-4+t,NULL);
		LineTo(hdc,m_Cursor1Pos-2,f,f

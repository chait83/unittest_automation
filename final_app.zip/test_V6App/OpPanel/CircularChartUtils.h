/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CircularChartUtils.h
/// @n Description: Definition of the helper class used for calculating various
///					attributes of circular charts
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]$
//
// **************************************************************************
#ifndef _CIRCULARCHARTUTILS_H
#define _CIRCULARCHARTUTILS_H
#include "V6Config.h"
#include "ChartQueues.h"
/// Structure used to describe the number of divs of a particular type in a circular chart
typedef struct {
	int numberOfDivs;
	int divDurationInSeconds;
} T_TIME_DIVISIONS, *T_PTIME_DIVISIONS;
/// Structure used to describe all the divisions for a circular chart
typedef struct {
	T_TIME_DIVISIONS majorDivs;				// The major divs
	T_TIME_DIVISIONS minorDivs;				// The minor divs
	T_TIME_DIVISIONS subsideriesPerMinor;	// The subsidiary intervals per minor division
	UINT PointsPerChart;					// The number of points per chart
	UINT Tpp;								// The time per pixel
} T_CIRC_CHART_DIVISIONS, *T_PCIRC_CHART_DIVISIONS;
/// Enum used to indicate each circular chart duration, these values will represent all possible
/// chart durations from all possible chart duration speeds (fast/med/slow)
enum T_CIRCULAR_CHART_DURATION {
	CCD_15_MINUTES,
	CCD_30_MINUTES,
	CCD_1_HOUR,
	CCD_4_HOURS,
	CCD_8_HOURS,
	CCD_12_HOURS,
	CCD_1_DAY,
	CCD_2_DAYS,
	CCD_5_DAYS,
	CCD_1_WEEK,
	CCD_2_WEEKS,
	CCD_4_WEEKS,
	CCD_NO_OF_CHART_DURATIONS
};
//**Class*********************************************************************
/// 
/// Helper class used for calculating various attributes of circular charts
///
//****************************************************************************
class CircularChartUtils {
private:
	// Method used to retrieve the chart speed for the specified speed and speed type (fast/med/slow)
	static const int GetChartSpeedSpan(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
			T_CIRCULAR_CHART_DURATION &chartDuration, QString &chartDurationAsStr);
	// Method used to retrieve the fast chart span for the specified speed index
	static const int GetFastChartSpeedSpan(const int chartSpeedIndex, T_CIRCULAR_CHART_DURATION &chartDuration);
	// Method used to retrieve the medium chart span for the specified speed index
	static const int GetMedChartSpeedSpan(const int chartSpeedIndex, T_CIRCULAR_CHART_DURATION &chartDuration);
	// Method used to retrieve the slow chart span for the specified speed index
	static const int GetSlowChartSpeedSpan(const int chartSpeedIndex, T_CIRCULAR_CHART_DURATION &chartDuration);
	// Method used to retrieve the chart start time for the current time slot (i.e. using the time now) 
	static const CTVtime GetChartStartTimeForCurrentTimeSlot(const T_PCHARTINFO pChartInfo,
			const int chartSpanInSeconds);
	// Method used to retrieve the chart start time for the required time slot determined
	// by the passed in index(i.e. using the time now as the starting point) 
	static const CTVtime GetChartStartTimeForRequiredTimeSlot(const int index, const int chartSpanInSeconds,
			const CTVtime startTimeForRealtimeTimeSlot);
	// Method used to retrieve the chart drawing/queue properties for the specified speed 
	// and speed type (fast/med/slow)
	static const void GetChartQueueProperties(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
			UINT &pointsPerChart, UINT &tpp);
	// Method used to determine if the current year is a leap year
	static const BOOL IsLeapYear(int year);
	// Method used to calculate the day number
	static const int GetDayNumber(const int year, const int month, const int day);
	// Method used to calculate the week number
	static const int GetWeekNumber(int day, int month, int year);
	//// Method used to calculate the week number - DEPRECATED FOR NOW AS mktime is not supported in CE
	//static const int GetWeekNumber( struct tm* date );
	// Method used to calculate the time required to normalise the specified day to monday
	static const int CalculateMondayNormalisationFactor(int dayOfWeek);
public:
	// Method used to retrieve the realtime chart span for the specified speed and using the time now
	static void GetCircularChartRealtimeSpan(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
			CTVtime &startTime, CTVtime &endTime, QString &chartDurationAsStr);
	// Method used to retrieve the historical chart span for the specified speed and previous chart index
	static void GetCircularChartHistoricalSpan(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
			const int index, CTVtime &startTime, CTVtime &endTime, QString &chartDurationAsStr);
	// Method used to get the required chart time divisions
	static void GetChartTimeDivisions(const T_PCHARTINFO pChartInfo, const ChartSpeed chartSpeed,
			T_CIRC_CHART_DIVISIONS &chartDivisions);
};
#endif

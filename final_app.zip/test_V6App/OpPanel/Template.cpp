/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: Template.cpp 
/// @n Description: Template class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  22  Stability Project 1.17.1.3 7/2/2011 5:02:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  21  Stability Project 1.17.1.2 7/1/2011 4:39:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  20  Stability Project 1.17.1.1 3/17/2011 3:20:49 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  19  Stability Project 1.17.1.0 2/15/2011 3:04:03 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
// 
//
// **************************************************************************
#include "OpPanelIncludes.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define DEF_TEMPLATE_BACKCLR	51185///<Green, this is matched to CMM
//****************************************************************************
/// CTemplate Constructor
///
/// @param pParent Pointer to Parent OpPanel
/// 
//****************************************************************************
CTemplate::CTemplate(COpPanel *pParent) : CLayoutItem(otTemplate) {
	// set up empty block info structure;
	BLOCK_INFO emptyInfo = { 0, 0, 0, NULL, 0 };
	m_CMMinfo = emptyInfo;
	m_pConfig = NULL;
	m_pCMMtemplate = NULL;
	m_pNextTpt = NULL;
	SetNull(m_KeepRef);
	// keep pointer to our parent OpPanel
	m_pOpPanel = pParent;
}
//****************************************************************************
/// CTemplate Destructor
/// Clean up as Template is deleted 
/// 
/// @todo put whatever we need to do in here !!
//****************************************************************************
CTemplate::~CTemplate() {
}
//****************************************************************************
///
/// Initialises the Template with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Template
/// or will be a new defaulted block for a new Template. 
///
/// @param[in] pConfig - Configuration to use
/// @param[in] CMMinfo - CMM Template info
///
/// @return none
/// 
//****************************************************************************
void CTemplate::CMMInitTemplate(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, BOOL IsNew) {
	// keep a copy of the CMM info block passed in.
	m_CMMinfo = *CMMinfo;
	// set up pointer to T_SCRTEMPLATE data in CMM info block.
	m_pCMMtemplate = (T_SCRTEMPLATE*) m_CMMinfo.pByBlock;
	m_pConfig = pConfig; // pointer to the config
	if (IsNew) {
		// Add code here that is to be done for a Newly created Template
		/// @todo set up template number and name.
		//m_pCMMtemplate->		
	} else {
		// Add code here that is to be done for a previous Template that has been reloaded
	}
	// in all cases:
	// keep a copy here of the CMM T_LAYOUTITEM for our template.
	m_KeepRef = GetLayoutItem();
}
//****************************************************************************
///
/// Returns the number of Widgets in this template
///
/// @param none
///
/// @return USHORT Number of widgets on template
/// 
//****************************************************************************
USHORT CTemplate::GetNumWidgets() {
	return m_pCMMtemplate->NumWidgets;
}
//****************************************************************************
///
/// Returns the T_LAYOUTITEM of this template
///
/// @param none
///
/// @return T_LAYOUTITEM
/// 
//****************************************************************************
T_LAYOUTITEM CTemplate::GetLayoutItem() {
	T_LAYOUTITEM ref;
	ref.CMM_Type = m_CMMinfo.wBlockType;
	ref.CMM_Inst = m_CMMinfo.wInstanceID;
	return ref;
}
//****************************************************************************
///
///	Function to check if this CTemplate matches a LayoutItem reference from 
/// the CMM.
///
/// @param[in] LayoutItem - type and instance reference from CMM
///
/// @return TRUE/FALSE
/// 
//****************************************************************************
BOOL CTemplate::MatchLayoutItem(T_LAYOUTITEM *LayoutItem) {
	return ((m_CMMinfo.wInstanceID == LayoutItem->CMM_Inst) && // match type and instance?
			(m_CMMinfo.wBlockType == LayoutItem->CMM_Type)); // check it's BLK_SCRTEMPLATE
}
//****************************************************************************
///
/// Fills the blockInfo structure with the details of the Widget referenced
/// in the templates widgetlist in the CMM
///
/// @param[in] index	- index into array of Widgets for template in CMM
/// @param[in] blockInfo - pointer to BLOCK_INFO to populate
///
/// @return TRUE if found FALSE if not
/// 
//****************************************************************************
BOOL CTemplate::GetWidgetConfig(int index, BLOCK_INFO *blockInfo) {
	if (index >= m_pCMMtemplate->NumWidgets)
		return FALSE;
	return m_pConfig->indexOfDataBlock(&m_pCMMtemplate->WidgetList[index], blockInfo); // populate the Block_Info		
}
//****************************************************************************
///
/// Template's ConfigChange function, called after changes to properties
/// or a setup configuration change
///
/// @param none
/// @return none
/// 
//****************************************************************************	
void CTemplate::ConfigChange() {
	CLayoutItem::ConfigChange();
	CScreen *pScreen = m_pOpPanel->m_pScreens;
	while (pScreen) {
		if (pScreen->m_pTemplate == this)
			pScreen->ConfigChange();
		pScreen = pScreen->m_pNextScr;
	}
}
QString CTemplate::GetId() {
	QString sId;
	sId = QString::asprintf("Template %d - '%s'", m_pCMMtemplate->Number, m_pCMMtemplate->Name);
	return sId;
}

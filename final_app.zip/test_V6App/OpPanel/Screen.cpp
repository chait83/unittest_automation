/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Op Panel
/// @n Filename: Screen.cpp 
/// @n Description: Screen class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 176 Stability Project 1.169.2.5	8/10/2011 12:08:38 PM Hemant(HAIL) 
//		Fixed PAR # 1-L44JCV (Issue: 32 Pens in a Group)
// 175 Stability Project 1.169.2.4	7/2/2011 5:01:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 174 Stability Project 1.169.2.3	7/1/2011 4:38:51 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 173 Stability Project 1.169.2.2	6/17/2011 8:02:54 PM	Hemant(HAIL) 
//		Files updated for "Restrict pen addition limit to 32 in a group".
//		(The issue was observed in internal testing and if more than 32 pens
//		are added to a group and if that group is added to the new screen
//		then the recorder gets hanged. Even the limit of canned screens to
//		display max pens on a screen is 32)
// $
//
// 01 03Feb2014		Vellaidurai.V		Fix for PAR - 1-2C064FH Font and resolution issue
//										Changed code for Totalizer overlap and Unit display.
// 02 25Mar2014		Vellaidurai.V		Implemented USB support for Hot soak testing. System will first check for SD card, 
//										if it is not found then it will check USB.
// 03 29May2014	Prasad			Fix for 1-3DS4RDD - DPMs and Bars screen is not proper 
//									when group is having more than 8 Pens
// 04 27May2014		Shankar Rao			Fix for PAR# 1-3K9UACH - Circular screen shows partial scale
//
// 05 30Oct2014	Rajanbabu M		Fixed PAR:1-3KZWBIH-Load custom screen is not working in Multi and DRG2 Recorders
//
// 06 30Oct2014		Shankar	Rao			Fix for PAR# 1-3KK81FF - Circular chart allow 12 pens if screen is added by group
// **************************************************************************
#include "OpPanelIncludes.h"
#include "AMS2750TUSMgr.h"
#ifndef DOCVIEW
#ifndef V6IOTEST
#include "TopStatusBar.h"
#include "PenManager.h"
#include "BoardManager.h"
#include "BrdInfo.h"
#endif
#else
#include "PenManagerstub.h"
#endif
#ifndef V6IOTEST
#include "CannedScrnData.h"
#endif
#include "UISizeDefines.h"
#ifdef SHOW_CPU
	#include "cpumon.h"
#endif
#ifndef UNDER_CE
// for sndPlaySound on the desktop build
#include "Mmsystem.h"
#pragma comment( lib, "Winmm" )
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define DEF_SCR_BACK_COLOUR 28095///<blue, this value is matched to CMM db
extern BOOL Glb_SeeRegions;
extern BYTE Glb_col;
extern ChartSpeed Glb_ReplaySpeed;
extern int Glb_FontHeight;
extern CSimpleLog logstuff;
#define PCUROBJ m_pSelectedWidget->m_pSelectedObject 
const USHORT CScreen::ms_usUNINITIALISED_INSTANCE = 0xFFFF;
const USHORT CScreen::ms_usINVALID_CHANNEL_NO = 0x00FE;
const USHORT CScreen::ms_usMAX_MULTI_SCREENS = 32;
const USHORT CScreen::ms_usMAX_MINI_SCREENS = 20;
const USHORT CScreen::ms_usMAX_EZ_SCREENS = 12;
//const USHORT CScreen::ms_usMAX_NON_PROCESS_SCREENS	= 32;
const USHORT CScreen::ms_usMAX_XS_MULTI_SCREENS = 20;
const USHORT CScreen::ms_usMAX_XS_MINI_SCREENS = 12;
//****************************************************************************
/// CScreen Constructor
///
/// @param[in] pParent		- Pointer to Parent OpPanel 
/// 
//****************************************************************************
CScreen::CScreen(COpPanel *pParent) : CLayoutItem(otScreen) {
	// set up empty block info structure;
	BLOCK_INFO emptyInfo = { 0, 0, 0, NULL, 0 };
	m_CMMinfo = emptyInfo;
	// keep pointer to our parent OpPanel
	m_pOpPanel = pParent;
	m_pCMMscreen = NULL;
	m_pRealCMMscreen = NULL;
	m_pNextScr = NULL;
	m_pWidgets = NULL;
	m_pTemplate = NULL;
	m_pSelectedWidget = NULL;
	m_pLastSelectedWidget = NULL;
	m_DoneInitalDraw = FALSE;
	m_CheckpointRequired = FALSE;
	m_CannedScreenChanged = FALSE;
	m_ScreenIsMoved = FALSE;
	SetRect(&m_ScreenClientRect, 0, 0, m_pOpPanel->m_ScreenWidth, m_pOpPanel->m_ScreenHeight);
	m_hrgnUpdate = NULL; // DO NOT create a region here
}
//****************************************************************************
/// CScreen Destructor
/// Clean up as Screen is deleted (Destroy function does most of the work)
/// 
/// @todo put whatever we need to do in here !!
//****************************************************************************
CScreen::~CScreen() {
}
//****************************************************************************
/// 
/// Clean up CScreen and everything under it
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CScreen::Destroy() {
	// delete all CWidgets
	while (m_pWidgets) {
		CWidget *pWgt = m_pWidgets;
		RemoveWidget(pWgt); // remove from list
		pWgt->Destroy(); // will remove everything below each CWidget (derived Objects)
		delete pWgt;		// then delete the CWidget object.
	}
	// do not delete CTemplate associated with the CScreen. That will be done by OpPanel.
	// EXCEPT for Canned Screens and Replay screen 
	// ...when we DO delete it since it is not in the general list of templates
	// here we check for canned screen by looking at the template inst.
	// We can't check the screen type field (IsCannedScreen) since it wont be validated if the type of screen has changed
	//if(	m_pTemplate && ( m_pTemplate->GetLayoutItem().CMM_Inst >= CANNED_SCREENS_INST ) )
	if (m_pTemplate) {
		if (m_pOpPanel->m_pCannedConfig
				&& m_pTemplate->m_pConfig->GetConfigId() == m_pOpPanel->m_pCannedConfig->GetConfigId()) // it's the same as the canned screen config
						{
			// here, if a change has been made to the settings for the screen, we need to 
			// create a new template in the CMM, so delete the existing one here.
			if (m_CannedScreenChanged) {
				//m_pOpPanel->m_pCannedConfig->DeleteTemplate(&m_pTemplate->m_KeepRef); // delete template in canned screen CMM
				BLOCK_INFO templateBlockInfo;
				if (m_pOpPanel->m_pCannedConfig->indexOfDataBlock(&m_pTemplate->m_KeepRef, &templateBlockInfo)) {
					((T_SCRTEMPLATE*) templateBlockInfo.pByBlock)->Number = 0; // mark this template to be reused
				}
				m_CannedScreenChanged = FALSE;
			}
			delete m_pTemplate; // delete the c++ template
			m_pTemplate = NULL;
		} else if (m_pOpPanel->m_pReplayScrConfig
				&& m_pTemplate->m_pConfig->GetConfigId() == m_pOpPanel->m_pReplayScrConfig->GetConfigId()) // it's the same as replay config ?
						{
			delete m_pTemplate; // delete the c++ template
			m_pTemplate = NULL;
		}
	}
}
//****************************************************************************
///
/// Initialises the Screen with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Screen
/// Or will be a new defaulted block for a new Screen. 
///
/// @param[in] pConfig	- Configuration to add use
/// @param[in] CMMinfo	- block of CMM info
/// @param[in] IsNew	- flag to indicate this is a new or existing screen
///
/// @return none
/// 
//****************************************************************************
void CScreen::CMMInitScreen(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, BOOL IsNew) {
	// keep a copy of the CMM info block passed in.
	m_CMMinfo = *CMMinfo;
	// set up pointer to T_SCREEN data in CMM info block.
	m_pCMMscreen = (T_SCREEN*) m_CMMinfo.pByBlock;
	m_pRealCMMscreen = m_pCMMscreen; // keep a copy of this (really is the pointer to screen struct in CMM)
	if (IsNew) {
		///only do this for a new screen.
		// initialise the Screen's channel map to all 0xfff
		// These entries are for channels CWidget::ms_usCHANNEL_OFFSET to CWidget::ms_usCHANNEL_OFFSET + 127
		for (int i = 0; i < SCREEN_CHANNELMAP_SIZE; i++) {
			m_pCMMscreen->ChannelMap[i] = CScreen::ms_usUNINITIALISED_INSTANCE; // default value
		}
		m_pCMMscreen->NPItems = 0; // Non process screens use this variable to store number items like pen, user vars, counter to be shown on screen
		// Each entry in the map is the item instance in the Data Item Table.
		m_pCMMscreen->Enabled = TRUE; // enable a new screen
	} else {
		// when loading a previous configuration:
	}
	// in all cases:
	// here check to see if we are using groups for this screen or it is a TUS screen
	if (IsCannedScreen() && (m_pRealCMMscreen->UseGroups || (m_pRealCMMscreen->Type == TPL_AMS2750_TUS_SCREEN))) {
		REFERENCE curmode = m_pOpPanel->m_pMainConfig->GetCMMmode();
		// yes we are, so get/create memory based screen config to use (can then be changed without CMM commit)
		T_SCREEN *pMemoryScreen = CMemoryScreenBlock::GetHandle()->GetMemoryScreenBlock(m_CMMinfo.wInstanceID, curmode);
		if (m_pOpPanel->m_IsCommit) {
			// just committed layout (layout changes) - need to copy the modifiable config to the committed
			T_SCREEN *pMemModifiable = CMemoryScreenBlock::GetHandle()->GetMemoryScreenBlock(m_CMMinfo.wInstanceID,
					CONFIG_MODIFIABLE);
			*pMemoryScreen = *pMemModifiable;
		} else {
			// general operation - when there is a layout rebuild copy the first part of the CMM T_SCREEN (the settings)
			if (m_pOpPanel->m_IsSetupConfigChange == FALSE) // Doing a layout config update, could be committed or modifiable					
			{
				memcpy(pMemoryScreen, m_pRealCMMscreen,
						((UCHAR*) m_pRealCMMscreen->ChannelMap - (UCHAR*) m_pRealCMMscreen)); // copy the CMM version - there could well be changes we need					
			}
		}
		m_pCMMscreen = pMemoryScreen; // and assign pointer here
	}
	m_DoneInitalDraw = FALSE;
	// Since templates will be loaded up before Screens 
	// we can make the link to our CTemplate
	if (m_pCMMscreen->Type == TPL_REPLAY) {
		PopulateReplayScreen();
	} else if (m_pCMMscreen->Type == TPL_HOTSOAK) {
#ifndef DOCVIEW
#ifndef V6IOTEST
		PopulateHotSoakScreen();
#endif
#endif
	} else if (IsCannedScreen()) {
		// the canned screen templates are added to the cannedscreen config (not the main layout config).
		// there is always a 1:1 mapping between canned screen and it's template.
		// we ensure the template and screen have the same instance number. (+ CANNED_SCREENS_INST)
		T_LAYOUTITEM ref = GetLayoutItem(); // get our layout item ref.
		ref.CMM_Type = BLK_SCRTEMPLATE;
		ref.CMM_Inst += CANNED_SCREENS_INST; // add CANNED_SCREENS_INST to allow for searching for our template
		BLOCK_INFO templateBlockInfo;
		if (m_pOpPanel->m_pCannedConfig->indexOfDataBlock(&ref, &templateBlockInfo)
				&& ((T_SCRTEMPLATE*) templateBlockInfo.pByBlock)->Number) // check template Number not zero
				{
			// found ok.
			m_pTemplate = new CTemplate(m_pOpPanel);
			m_pTemplate->CMMInitTemplate(m_pOpPanel->m_pCannedConfig, &templateBlockInfo, LOADED_INSTANCE);
			// use what it contains...
			int numWidgets = m_pTemplate->GetNumWidgets();
			for (int i = 0; i < numWidgets; i++) {
				BLOCK_INFO blockInfo;
				if (m_pTemplate->GetWidgetConfig(i, &blockInfo)) {
					// found widget and populated blockinfo OK. (contains pointer into CMM for Widget)
					// now create a corresponding C++ Widget for it.
					// Dont forget we are using the m_pCannedConfig
					CWidget *pWidget = new CWidget(this);
					pWidget->CMMInitWidget(m_pOpPanel->m_pCannedConfig, &blockInfo, NULL); // NULL passed for bounds since already configured
					AppendWidget(pWidget);
				}
			}
		} else {
			// need to add new.. pass the screens instance, so that we get a template that has the same.
			if (m_pOpPanel->m_pCannedConfig->AddTemplate(&templateBlockInfo, ref.CMM_Inst) == CONFIG_OK) {
				// added ok, and populated templateBlockInfo with new Template's CMM details
				// now create a C++ Template Object for it.
				m_pTemplate = new CTemplate(m_pOpPanel);
				m_pTemplate->CMMInitTemplate(m_pOpPanel->m_pCannedConfig, &templateBlockInfo, NEW_INSTANCE);
				qDebug("POPULATING CANNED SCREEN %d %s\n", m_pCMMscreen->Number, m_pCMMscreen->Name);
				PopulateCannedScreen();
				// when using groups, the T_SCREEN struct (usually in the main setup) is in memory - same goes for the TUS screen
				if (!m_pRealCMMscreen->UseGroups && (m_pRealCMMscreen->Type != TPL_AMS2750_TUS_SCREEN))
					if (m_pOpPanel->m_pMainConfig->GetCMMmode() == CONFIG_COMMITTED)
						qDebug("======================= MODIFYING a COMITTED CONFIG (this is bad)\n");
				if (m_pOpPanel->m_pCannedConfig->GetCMMmode() == CONFIG_COMMITTED)
					qDebug("======================= MODIFYING a COMITTED CONFIG (this is bad too)\n");
			} else
				qDebug("Error adding template\n");
		}
	} else // for Custom (screen designed) screen:
	{	// modified by to handle non process screens
		if (m_pCMMscreen->Type != TPL_CUSTOM && m_pCMMscreen->Type < TPL_ALARM) {
			// here a user has changed the type. need use the value to find the template instance
			int templno = m_pCMMscreen->Type - TPL_LAST_CANNED;
			// now find the templno'th template 
			CTemplate *ptpl = m_pOpPanel->m_pTemplates;
			int count = 0;
			while ((count < templno) && ptpl)
				ptpl = ptpl->m_pNextTpt;
			//	NB: for this to work CMM needs to be modifiable here
			if (ptpl)
				m_pCMMscreen->Template = ptpl->GetLayoutItem(); // set the type and instance here.
			m_pCMMscreen->Type = TPL_CUSTOM; // update the type here	
			if (pConfig->GetCMMmode() == CONFIG_COMMITTED)
				qDebug("MODIFYING a COMITTED CONFIG\n");
		}
		if (!m_pTemplate) // not already set (can happen for template viewing screen)
			m_pTemplate = m_pOpPanel->indexOfTemplateInstance(&m_pCMMscreen->Template);
		if (m_pTemplate) {
			// Now for our screen we need to create the Widgets and Objects in our associated Template
			// Widgets and Objects are associated with a Template in CMM.
			// However, the C++ versions are to be linked to our CScreen.
			// (Screen could be 'new' but Template could already exist)
			int numWidgets = m_pTemplate->GetNumWidgets();
			for (int i = 0; i < numWidgets; i++) {
				BLOCK_INFO blockInfo;
				if (m_pTemplate->GetWidgetConfig(i, &blockInfo)) {
					// found widget and populated blockinfo OK. (contains pointer into CMM for Widget)
					// now create a corresponding C++ Widget for it.
					CWidget *pWidget = new CWidget(this);
					pWidget->CMMInitWidget(pConfig, &blockInfo, NULL); // NULL passed for bounds since already configured
					AppendWidget(pWidget);
				}
			}
		}
	}
	if (IsCannedScreen() && m_pCMMscreen->UseGroups) {
		// if using groups and the Main config is writable, copy back to the CMM from our memory version.
		// this ensures that we will commit the updated T_SCREEN struct and then if future changes are required
		// but then discarded or parked, we have a correct committed screen to revert back to.
		if (m_pOpPanel->m_pMainConfig->GetCMMmode() == CONFIG_MODIFIABLE) // if writeable update the CMM to match memory version
				{
			//qDebug("UPDATING THE REAL CONFIG inst %d indexes %d %d %d %d\n",m_CMMinfo.wInstanceID,m_pCMMscreen->CannedPens[0].PenIndex,m_pCMMscreen->CannedPens[1].PenIndex,m_pCMMscreen->CannedPens[2].PenIndex,m_pCMMscreen->CannedPens[3].PenIndex);
			*m_pRealCMMscreen = *m_pCMMscreen; // ensure that we update the actual CMM screen if we can
		}
		// when a setup config change has occurred, we will have updated the 'committed' memory version.
		// need now to copy that to the 'working' memory version so it will be up to date for when the working version is required
		if (m_pOpPanel->m_IsSetupConfigChange) {
			T_SCREEN *pMemModifiable = CMemoryScreenBlock::GetHandle()->GetMemoryScreenBlock(m_CMMinfo.wInstanceID,
					CONFIG_MODIFIABLE);
			*pMemModifiable = *m_pCMMscreen; // copy the new latest version.
		}
	}
}
#ifndef DOCVIEW
#ifndef V6IOTEST
//****************************************************************************
/// Rescale a rectangle for use on multitrend (by given factor)
///
/// @return none
/// 
//****************************************************************************
void ScaleRect(QRect *pRect, float factor) {
	float hfac = factor;
	float wfac = factor;
	if (factor > 1.0)
		wfac = factor + (float) 0.2; // here we increase by a larger factor in horizontal direction
	// this is so that buttons don't look crap.
	pRect->left = (long) ((pRect->left * wfac) + 0.5);
	pRect->right = (long) ((pRect->right * wfac) + 0.5);
	pRect->top = (long) ((pRect->top * hfac) + 0.5);
	pRect->bottom = (long) ((pRect->bottom * hfac) + 0.5);
}
//****************************************************************************
/// Populate the Hot Soak Screen
///
/// @return none
/// 
//****************************************************************************
void CScreen::PopulateHotSoakScreen() {
	QRect ScreenArea;
	float multifactor = 1.0;
	WCHAR buff[100];
#ifdef UNDER_CE
	T_DEV_TYPE recorderType = m_pOpPanel->m_pMainConfig->GetRecorderType();
	//E519766
	if( recorderType == DEV_ARISTOS_MULTIPLUS || recorderType == DEV_SCR_MINITREND )			
	{
		SetRect(&ScreenArea,0,MULTI_STATUS_BAR_HEIGHT,ARISTOS_MULTI_SX_X,ARISTOS_MULTI_SX_Y);		
		multifactor=1.5;		
	}
	else if( recorderType == DEV_XS_MULTIPLUS )			
	{
		SetRect(&ScreenArea,0,MINI_STATUS_BAR_HEIGHT,X_SERIES_MULTI_SX_X,X_SERIES_MULTI_SX_Y);
		//SetRect(&ScreenArea,0,MULTI_STATUS_BAR_HEIGHT,800,600);
		multifactor=1.5;		
	}
	else if ( recorderType == DEV_ARISTOS_MINITREND )				
	{
		SetRect(&ScreenArea,0,MINI_STATUS_BAR_HEIGHT,ARISTOS_MINI_QX_X,ARISTOS_MINI_QX_Y);	
		//SetRect(&ScreenArea,0,MINI_STATUS_BAR_HEIGHT,320,240);	
	}
	else
		SetRect(&ScreenArea,0,MINI_EZ_STATUS_BAR_HEIGHT,ARISTOS_MINI_EZ_X,ARISTOS_MINI_EZ_Y);	
 #else	
	T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
	if (devType == DEV_PC_MULTI) {
		SetRect(&ScreenArea, 0, MULTI_PC_STATUS_BAR_HEIGHT, ARISTOS_PC_MULTI_SX_X, ARISTOS_PC_MULTI_SX_Y);
		//SetRect(&ScreenArea,0,MULTI_STATUS_BAR_HEIGHT,800,600);
		multifactor = 1.5;
	} else if (devType == DEV_PC_MINI) {
		SetRect(&ScreenArea, 0, MINI_PC_STATUS_BAR_HEIGHT, ARISTOS_PC_MINI_QX_X, ARISTOS_PC_MINI_QX_Y);
		//SetRect(&ScreenArea,0,MULTI_STATUS_BAR_HEIGHT,800,600);
		multifactor = 1.5;
	} else
		SetRect(&ScreenArea, 0, MINI_EZ_STATUS_BAR_HEIGHT, ARISTOS_MINI_EZ_X, ARISTOS_MINI_EZ_Y);
#endif
if( m_pOpPanel->AddNewWidget(m_pOpPanel->m_pHotSoakScrConfig,&ScreenArea) )
{
	m_pSelectedWidget->m_pCMMwidget->Border.BorderUsed=0;
	m_pSelectedWidget->m_pCMMwidget->BackColour=65535; // white specified
	// now add the Object's 
	// first of all- message to be displayed over the top
	T_DEV_TYPE eDeviceType = m_pOpPanel->m_pMainConfig->GetRecorderType();
	QRect MsgRect;
#ifdef UNDER_CE
	if(multifactor>1.0)
	{
		if(eDeviceType == DEV_ARISTOS_MULTIPLUS || eDeviceType == DEV_SCR_MINITREND)
		{
			SetRect(&MsgRect,0,MULTI_STATUS_BAR_HEIGHT,ARISTOS_MULTI_SX_X,ARISTOS_MULTI_SX_Y); // multi
		}
	}
	else if ( eDeviceType == DEV_ARISTOS_MINITREND )
	{
		SetRect(&MsgRect,0,MINI_STATUS_BAR_HEIGHT,ARISTOS_MINI_QX_X,ARISTOS_MINI_QX_Y);
	}
	else
	SetRect(&MsgRect,0,MINI_EZ_STATUS_BAR_HEIGHT,ARISTOS_MINI_EZ_X,ARISTOS_MINI_EZ_Y);
#else
	if( devType == DEV_PC_MULTI)
	{
		SetRect(&MsgRect,0,MULTI_PC_STATUS_BAR_HEIGHT,ARISTOS_PC_MULTI_SX_X,ARISTOS_PC_MULTI_SX_Y); // multi
		//SetRect(&MsgRect,0,MULTI_STATUS_BAR_HEIGHT,800,600); // multi
	}
	else if( devType == DEV_PC_MINI )
	{
		SetRect(&MsgRect,0,MINI_PC_STATUS_BAR_HEIGHT,ARISTOS_PC_MINI_QX_X,ARISTOS_PC_MINI_QX_Y);
	}
	else
	SetRect(&MsgRect,0,MINI_EZ_STATUS_BAR_HEIGHT,ARISTOS_MINI_EZ_X,ARISTOS_MINI_EZ_Y);
#endif
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&MsgRect) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=RGB(255,255,255); // white
		PCUROBJ->m_pCMMbase->FixBackColour=TRUE;
		PCUROBJ->m_pCMMbase->BackColour=RGB(255,255,255);// white
		PCUROBJ->m_pCMMbase->IsBuffered=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Center=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Wordwrap=TRUE;
		if(multifactor>1.0)
		//((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Height=100;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Height=150;
		else
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Height=60;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Weight=2;// semi-bold
		((CTextObject*)PCUROBJ)->SetBounds(&MsgRect);// call this since our rect is in screen co-ords, not relative to widget (as AddNewObject expects)
		((CTextObject*)PCUROBJ)->SetTextString(L"Reconfiguring Please Wait");
		m_pOpPanel->m_HotSoakObjects[HS_MsgBox][HS_Message]=PCUROBJ;
	}
	QRect TitleRect;
	eDeviceType = m_pOpPanel->m_pMainConfig->GetRecorderType();
	const int MultiPlusTitleRectYLimit = 100;
	const int MiniTrendTitleRectYLimit = 95;
	const int EzTrendTitleRectYLimit = 45;
#ifdef UNDER_CE
	if(multifactor>1.0)
	{
		if( eDeviceType == DEV_ARISTOS_MULTIPLUS || eDeviceType == DEV_SCR_MINITREND )
		{
			SetRect(&TitleRect,0,MULTI_STATUS_BAR_HEIGHT,ARISTOS_MULTI_SX_X,MultiPlusTitleRectYLimit); // mplus
		}
		// the code below has been removed as there have been no reports of an issue with
		// the hotsoak screen on a mini.
		/*else
		 {
		 SetRect(&TitleRect,0,MINI_STATUS_BAR_HEIGHT,ARISTOS_MINI_QX_X,MiniTrendTitleRectYLimit);
		 }*/
	}
	else if ( eDeviceType == DEV_ARISTOS_MINITREND )
	{
		// the code below is the dimensions setup for the PC mini. However, as we are
		// unable to test a real mini and there have been no reports of an issue with
		// the hotsoak screen on a mini the original code has been left on the following
		// line
		SetRect(&TitleRect,1,70,200,MiniTrendTitleRectYLimit);
	}
	else
	{
		SetRect(&TitleRect,0,MINI_EZ_STATUS_BAR_HEIGHT,ARISTOS_MINI_EZ_X,EzTrendTitleRectYLimit);
	}
#else		
	T_DEV_TYPE eDevCapsDevType = pDEVICE_INFO->GetDeviceType();
	if(multifactor>1.0)
	{
		if( eDevCapsDevType == DEV_PC_MULTI )
		{
			SetRect(&TitleRect,0,MULTI_PC_STATUS_BAR_HEIGHT,ARISTOS_PC_MULTI_SX_X,MultiPlusTitleRectYLimit); // mplus
		}
		else
		{
			SetRect(&TitleRect,0,MINI_STATUS_BAR_HEIGHT,ARISTOS_MINI_QX_X,MiniTrendTitleRectYLimit);
		}
	}
	else if ( eDevCapsDevType == DEV_PC_MINI )
	{
		SetRect(&TitleRect,0,MINI_STATUS_BAR_HEIGHT,ARISTOS_MINI_QX_X,MiniTrendTitleRectYLimit);
	}
	else
	{
		SetRect(&TitleRect,0,MINI_EZ_STATUS_BAR_HEIGHT,ARISTOS_MINI_EZ_X,EzTrendTitleRectYLimit);
	}
#endif
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&TitleRect) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0; // black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Center=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		((CTextObject*)PCUROBJ)->SetBounds(&TitleRect);// call this since our rect is in screen co-ords, not relative to widget (as AddNewObject expects)
		((CTextObject*)PCUROBJ)->SetTextString(L"Factory Hot Soak");
	}
	// Get the Production Information.
	T_RECPROD sProdInfo = pSYSTEM_INFO->GetProductionInfo();
	QRect ModelRectTitle;
	//SetRect(&ModelRectTitle,1,46,58,59);		
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&ModelRectTitle,1,46,58,59);
	}
	else
	{
		SetRect(&ModelRectTitle,1,109,73,123);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&ModelRectTitle) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0; // black				
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		ScaleRect(&ModelRectTitle,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&ModelRectTitle);
		((CTextObject*)PCUROBJ)->SetTextString(L"Model No:");
	}
	QRect ModelRectValue;
	//SetRect(&ModelRectValue,60,45,320,60);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&ModelRectValue,60,45,320,60);
	}
	// Code below disabled as there are no mini trend hotsoak screen issues reported - could
	// be just a PC issue
	/*else if( ( eDeviceType == DEV_ARISTOS_MINITREND ) || ( eDeviceType == DEV_PC_MINI ) )
	 {
	 SetRect(&ModelRectValue,85,109,370,123);
	 }*/
	else
	{
		SetRect(&ModelRectValue,85,109,390,123);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&ModelRectValue) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0;		// black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Weight=2;// semi-bold
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		ScaleRect(&ModelRectValue,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&ModelRectValue);
		((CTextObject*)PCUROBJ)->SetTextString(sProdInfo.ModelNoDisplay);
	}
	QRect MFRSerialRectTitle;
	//SetRect(&MFRSerialRectTitle,1,62,73,75);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&MFRSerialRectTitle,1,62,73,75);
	}
	else
	{
		SetRect(&MFRSerialRectTitle,1,125,80,138);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&MFRSerialRectTitle) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0; // black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		ScaleRect(&MFRSerialRectTitle,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&MFRSerialRectTitle);
		((CTextObject*)PCUROBJ)->SetTextString(L"MFR Serial No:");
	}
	QRect MFRSerialRectValue;
	//SetRect(&MFRSerialRectValue,75,61,190,76);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&MFRSerialRectValue,75,61,190,76);
	}
	else
	{
		SetRect(&MFRSerialRectValue,90,125,205,138);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&MFRSerialRectValue) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0; // black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Weight=2;// semi-bold
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		ScaleRect(&MFRSerialRectValue,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&MFRSerialRectValue);
		// MANUFACTURING serial number e.g. Y669501800001 not the 6 digit serial number.
		((CTextObject*)PCUROBJ)->SetTextString(sProdInfo.mfrsSerialNo);
		//((CTextObject*)PCUROBJ)->SetTextString(L"Y669501800001");	
	}
	QRect OEMSerialRectTitle;
	//SetRect(&OEMSerialRectTitle,1,78,73,91);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&OEMSerialRectTitle,1,78,73,91);
	}
	else
	{
		SetRect(&OEMSerialRectTitle,250,125,330,138);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&OEMSerialRectTitle) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0; // black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		ScaleRect(&OEMSerialRectTitle,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&OEMSerialRectTitle);
		((CTextObject*)PCUROBJ)->SetTextString(L"OEM Serial No:");
	}
	QRect OEMSerialRectValue;
	//SetRect(&OEMSerialRectValue,75,77,135,92);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&OEMSerialRectValue,75,77,135,92);
	}
	// Code below disabled as there are no mini trend hotsoak screen issues reported - could
	// be just a PC issue
	/*else if( ( eDeviceType == DEV_ARISTOS_MINITREND ) || ( eDeviceType == DEV_PC_MINI ) )
	 {
	 SetRect(&OEMSerialRectValue,340,125,390,138);
	 }*/
	else
	{
		SetRect(&OEMSerialRectValue,340,125,430,138);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&OEMSerialRectValue) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0;		// black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Weight=2;// semi-bold
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		ScaleRect(&OEMSerialRectValue,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&OEMSerialRectValue);
		// OEM serial number i.e. 123456
		ULONG serial=pSYSTEM_INFO->GetSerialNumber();
		swprintf(buff,L"%06d",serial);
		((CTextObject*)PCUROBJ)->SetTextString(buff);
	}
	QRect FWRectTitle;
	//SetRect(&FWRectTitle,1,94,73,107);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&FWRectTitle,1,94,73,107);
	}
	else
	{
		SetRect(&FWRectTitle,1,140,80,153);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&FWRectTitle) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0; // black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		ScaleRect(&FWRectTitle,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&FWRectTitle);
		((CTextObject*)PCUROBJ)->SetTextString(L"Firmware:");
	}
	QString strReleaseType = L"Unknown";
	T_RELEASE_TYPE relType = static_cast<T_RELEASE_TYPE>(pDEVICE_INFO->GetFirmwareRelease());
	switch(relType)
	{
		case RELEASE_ALPHA:		// Alpha release, internal engineering release.
		strReleaseType = tr("Alpha");
		break;
		case RELEASE_BETA:// Beta release, release to send out for testing/demonstrations etc..
		strReleaseType = tr("Beta");
		break;
		case RELEASE_PRODUCTION:// Production/customer ready release. Promoted beta when satifactory for release to production
		strReleaseType = tr("Release");
		break;
		default:
		strReleaseType = tr("Unknown");
		break;
	}
	swprintf(buff,L"%s %s", pDEVICE_INFO->GetFirmwareVersion(), strReleaseType );
	QRect FWRectValue;
	//SetRect(&FWRectValue,75,93,190,108);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&FWRectValue,75,93,190,108);
	}
	else
	{
		SetRect(&FWRectValue,90,140,210,153);
	}
	if( m_pOpPanel->AddNewObject(m_pOpPanel->m_pHotSoakScrConfig,BLK_TEXTOBJECT,&FWRectValue) )
	{
		PCUROBJ->m_pCMMbase->FixForeColour=TRUE;
		PCUROBJ->m_pCMMbase->ForeColour=0;		// black	
		PCUROBJ->m_pCMMbase->IsBuffered=1;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->FixText=TRUE;
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Weight=2;// semi-bold
		((T_TEXTOBJECT*)PCUROBJ->m_pCMMbase)->Font.Quality=1;//anti aliased
		ScaleRect(&FWRectValue,multifactor);
		((CTextObject*)PCUROBJ)->SetBounds(&FWRectValue);
		((CTextObject*)PCUROBJ)->SetTextString(buff);
	}
	// get the format type of the card e.g. TFAT16, FAT32 etc
	/*WCHAR wcaInternalCFRawName[ MAX_PATH ];
	 memset( wcaInternalCFRawName, 0, MAX_PATH );
	 int iPathLen = MAX_PATH;
	 pDALGLB->GetPath((T_STORAGE_PATH)IDS_INTERNAL_SD, wcaInternalCFRawName, MAX_PATH, &iPathLen );
	 #if _MSC_VER < 1400 
	 wcsncat( wcaInternalCFRawName, L"VOL:", MAX_PATH - wcslen( wcaInternalCFRawName ) );
	 #else
	 wcsncat( wcaInternalCFRawName, MAX_PATH, L"VOL:", MAX_PATH - wcslen( wcaInternalCFRawName ) );
	 #endif
	 BOOL IsTFAT=FALSE;
	 switch( pDALGLB->m_MediaasprintfType )
	 {
	 case FMT_TFAT_16:
	 case FMT_TFAT_32:
	 IsTFAT=TRUE;
	 break;
	 
	 case FMT_UNKNOWN:
	 default:
	 break;
	 }*/
	QRect tfatRectTitle;
	//SetRect(&tfatRectTitle,1,110,73,123);
	if( ( eDeviceType == DEV_ARISTOS_EZTREND ) || ( eDeviceType == DEV_XS_EZTREND ) )
	{
		SetRect(&tfatRectTitle,1,110,73,123);
	}
	else
	{
		SetRect(&tfatRectTitle,1,155,80,168);
	}
	if(

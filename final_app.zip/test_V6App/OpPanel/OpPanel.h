/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: OpPanel.h 
/// @n Description: OpPanel class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  139  Stability Project 1.136.1.1  7/2/2011 4:59:19 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  138  Stability Project 1.136.1.0  7/1/2011 4:25:52 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  137  V6 Firmware 1.136  9/14/2010 11:48:09 AM  Vivek (HAIL)  
//  Revert Code merge For Replay at faster speed
//  136  V6 Firmware 1.135  9/10/2010 5:55:48 PM  Vivek (HAIL)  
//  Code meryge for Replay at fast speed
// $
//
// 01 03Feb2014		Vellaidurai.V		Fix for PAR - 1-2C064FH - Screen is not refreshed on invoking Help file.Partial help screen and Display Screen is displayed.
// 02 25Mar2014		Vellaidurai.V		Implemented USB support for Hot soak testing. System will first check for SD card, if it is not found then it will check USB.
// **************************************************************************
#ifndef _OPPANEL_H
#define _OPPANEL_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QVector>
#include "Defines.h"
#include "TVtime.h"
#include "V6ActiveModule.h"
#include "BoardManager.h"
#include "Widget.h"
#include "ControlSequencer.h"
#include "InternalMessageQueue.h"
// forward ref.
class CLayoutConfiguration;
class CSetupConfiguration;
class COpPanel;
class CTopStatusBar;
enum EditModes {
	RUN_MODE, DESIGNER_MODE
};
//align enum constants
enum AlignMode {
	Alignleft, Alignright, AlignTop, AlignBottom, AlignCenterHorizontal, AlignCenterVertical, Alignmiddle, AlignNone
};
// Are we moving an object or widget using the arrow keys?
enum SimulatedMoveMode {
	SIMULATED_MOVE_NONE, SIMULATED_MOVE_OBJECT, SIMULATED_MOVE_WIDGET
};
typedef enum // description of a paste operation for undo-redo
{
	OPERATION_INSERT_TEMPLATE_FROM_FILE,	///< user insert template from file operation
	OPERATION_PASTE,						///< user copy/paste operation
	OPERATION_DROP_ITEM						///< user drag and drop object or widget operation
} PASTE_OPERATION;
typedef enum {
	OPPANEL_MODE_STARTUP,					///< Recorder in startup mode
	OPPANEL_MODE_SHUTDOWN,					///< Recorder in shutdown mode
	OPPANEL_MODE_IN_MENUS,					///< Recorder in menus
	OPPANEL_MODE_PROCESS_SCREENS,			///< Process screeens display
	OPPANEL_MODE_NON_PROCESS_SCREENS,		///< Process NP screeens display
} T_OPPANEL_MODE;
#define HS_Message 0
#define HS_LED		1
// 0 to 9 are slots A-I and CF
enum HotSoak {
	HS_SlotA, HS_SlotB, HS_SlotC, HS_SlotD, HS_SlotE, HS_SlotF, HS_SlotG, HS_SlotH, HS_SlotI, HS_CFCard, HS_Certificate,
	HS_Running, HS_Test, HS_Elapsed, HS_CJCMax, HS_CJCMin, HS_PassFail, HS_StartStop, HS_Ship, HS_MsgBox,
	NUM_SOAK_LINES // keep this one at the end
};
enum HSTest {
	TEST_ONE, TEST_TWO
};
enum HSOperation {
	INIT, RESET, IDLE, TEST_IDLE, CONFIG_BOARD, WAIT_FOR_CONFIG, TEST_BOARD
};
enum HSStatus {
	HS_UNKNOWN, HS_NOT_FITTED, HS_FAILED, HS_OK
};
struct HotSoakData {
	CTVtime RunTime;
	CTVtime ElapsedTime;
	BOOL IsRunning;
	BOOL HasPassed;
	BOOL HasFailed;
	BYTE SlotStatus[MAXIOCARDS + 2]; // plus 2 is for CF card & Certificate
	float MaxDegF;
	float MinDegF;
	float CurrDegF;
};
// Scrolling constants (x and y extents are the same)
const int SCROLLABLE_DRAWING_SURFACE = 3000; ///< Number of pixels across and down drawing surface
const int PIXELS_PER_PAGE = 30;	///< Number of pixels for "page" scrolling
const int PIXELS_PER_LINE = 6;	///< Number of pixels for "line" scrolling
class COpPanelModule: public CV6ActiveModule {
	COpPanel *m_pOpPanel;
public:
	COpPanelModule(COpPanel *pOpPanel, T_MODULE_ID moduleId, T_MODULE_MSG_NOTIFICATION moduleNotification);
	void SignalConfigChange(USHORT datalength, BYTE *pData);
	void SignalShutdown();
	// virtual function overrides here.
	T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	/// Secondary Initialisation of the Module
	T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	/// Method called when Module goes into Normal Operation
	T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	/// Method called when Module is to prepare for Setup Config Change 
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	/// Method called when Module is to carry out Setup Change Completion
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	/// Method called when a Module is to prepare for Shutdown
	T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	/// Method called when a Module is to Shutdown
	T_V6ACTMOD_RETURN_VALUE Shutdown(void);
};
struct LinkToCmd // used to defer linking in canned screen setup
{
	CBaseObject *pLinkToInvoker; // pLinkToInvoker->LinkTo(pLinkToInvokee)
	CBaseObject *pLinkToInvokee; // pLinkToInvoker->LinkTo(pLinkToInvokee)
};
typedef QVector<LinkToCmd> CLinkToCmdArray;
// EUDC character cell attribute types
const int MAX_EUDC_FONT_SIZE = 200;	  // maximum GetNumericFont size for EUDC tables
const int ALL_BLACK_EUDC = 0xE040; // all black 64x64 EUDC symbol
typedef struct // attributes of an EUDC character cell for a particular GetNumericFont
{
	short nCellWidth;	// Width in pixels of char cell
	short nCellHeight;	// Height in pixels of char cell
	short nAboveHeight;	// Height in pixels of space above 64x64 EUDC symbol
	short nSymbolHeight;	// Height in pixels of 64x64 EUDC symbol
	short nBelowHeight;	// Height in pixels of space below 64x64 EUDC symbol
} T_EUDC_CHAR_CELL_ATTR;
class FastMutex {
	long locker;
public:
	FastMutex() : locker(1) {
	} // start off set due to SetupConfigChangeComplete() called at startup
	void Lock() {
		InterlockedIncrement(&locker);
	}
	BOOL TryLock() {
		// check if another thread already locked
		if (InterlockedIncrement(&locker) != 1) {
			InterlockedDecrement(&locker);
			return FALSE;
		} else
			return TRUE;
	}
	void Unlock() {
		InterlockedDecrement(&locker);
	}
	void Reset() {
		locker = 0;
	} // not for general use
};
//**Class*********************************************************************
///
/// @brief COpPanel 
/// 
/// This class is the top level OpPanel class
/// It is derived from either CWidget or CScrollView depending upon usage.
///
//****************************************************************************
#ifdef DOCVIEW
class COpPanel : public CScrollView  // for document-view we inherit from CScrollView
#else
class COpPanel: public CWidget	 // for V6 recorder and simple desktop app, we inherit from CWidget
#endif
{
public:
	/// Enum used to describe what type of capture operation is required
	typedef enum {
		ocmNO_CAPTURE,				///< Idle state where no capture operations are required
		ocmCAPTURE_TO_EXT_CF,		///< Capture the process screen and save to external cf
		ocmCAPTURE_TO_USB1,			///< Capture the process screen and save to usb1
		ocmCAPTURE_TO_USB2,			///< Capture the process screen and save to usb2
		ocmCAPTURE_TO_SHARE,		///< Capture the process screen and save to sharedpath
		ocmCAPTURE_TO_PRINTER		///< Not functioning yet
	} T_OPPANEL_CAPTURE_MODE;
private:
	BLOCK_INFO m_CMMinfo;			///< block of CMM info (ptr inside will point to a T_LAYOUT struct in the CMM)
	CInternalMessageQueue *m_pInternalMessageQueue;
	CControlSequencer *m_pControlSeq;
	// The following test method is used for hand-building
	// the tables in EUDC.h, which specify the character cell
	// attributes of an EUDC character at various GetNumericFont
	// sizes.
	// The tables are used by the pen pointers object to calculate
	// the position of the pen pointer arrow tip for various pen
	// pointer object Heights so that a pen pointer can be placed
	// accurately on the recorder and on the PC, both of which have
	// different EUDC character cell attributes for a particular
	// GetNumericFont size.
	static BOOL m_bCalculateEUDCAttributes;
	void CalculateEUDCAttributes();
	/// Variable indicating the required capture mode
	T_OPPANEL_CAPTURE_MODE m_eCaptureMode;
	/// String indicating the required name for the screen capture
	QString m_strCaptureName;
public:
	static T_EUDC_CHAR_CELL_ATTR m_EUDC[MAX_EUDC_FONT_SIZE];
	FastMutex m_CritSec;
	/// Accessor for the capture mode variable
	void SetCaptureMode(const T_OPPANEL_CAPTURE_MODE eCAPTURE_MODE, const QString &rstrCAPTURE_NAME);
// Operations
private:
	BOOL CMMInitLayout(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, BOOL IsNew);
	void Destroy();
	HRESULT InitDirectDraw();
	void ReleaseDDobjects();
	HRESULT FailMessage(HRESULT hRet, wchar_t *pMessage);
	void SetupDefaultClip();
	void Register();
	void BlankScreen();
	void DefaultCannedScreens();
	CScreen* indexOfScreen(int ScreenNumber);
	void AppendTemplate(CTemplate *pTpt);	///< appends CTemplate to list
	BOOL RemoveTemplate(CTemplate *pTpt);	///< removes CTemplate from list (does not delete it)
	void AppendScreen(CScreen *pScr);		///< appends CScreen to list	
	BOOL RemoveScreen(CScreen *pScr);		///< removes CScreen from list (does not delete it)
	void UnselectAll();
	QPoint m_KeepPoint;
	int m_iActivatedReplayscreen;		/// Current activates screen no for which we are displaying replay
										// CR: 3151 Replay at Faster speed	
	T_OPPANEL_MODE m_OpPanelMode;		///< Mode op panel is in, Startup, Shutdown, In Menus or process display
	LARGE_INTEGER m_JumpId;
	void InstallDeviceCertificate();
// Attributes
public:
	HWND m_OPhWnd;
	EditModes m_EditMode;
	T_LAYOUT *m_pCMMlayout;			///< pointer to T_LAYOUT struct in CMM
	CScreen *m_pScreens;
	CScreen *m_pActiveScreen;
	CScreen *m_pReplayScreen;
	CScreen *m_pHotSoakScreen;
	CTemplate *m_pTemplates;
	BOOL m_IsInitialised;
	int m_PreviousConfigID;
	COpPanelModule *m_pV6Module;	///< OpPanel is an active V6 module 
	BOOL m_IsSetupConfigChange;
	BOOL m_IsCommit;
	int m_ScreenWidth;
	int m_ScreenHeight;
	QRect m_DesktopRect;				///< Screen coordinates of OpPanel Client area
	QRect m_OutputRect;
	BOOL m_DoScreenMove;			///< move the screen (based on timeout/activity etc)
	int m_moveOffset;				///< by this amount
	ULONG m_MoveScreenTick;
	QRect m_RecScreenArea;
	QPoint m_RecScreenOffset;
	QPoint m_InitialRecScreenOffset;
	ULONG m_CurrentScreenNumber;		///< Number from 1 to nn
	CTVtime m_RotateBaseTime;
	LONG m_Inactive;
	LONG m_IsDrawing;
	static BOOL m_bStickyWidgets;	///< TRUE => In sticky widgets mode
	static BOOL m_bExpertMode;	///< TRUE => In expert edit mode (same as control key when selecting objects/widgets )
	BOOL m_bLinkMode;				///< TRUE => In link mode to link an object
	CBaseObject *m_pLinkSelectedObject;	///< Selected object on which to call LinkTo
	CLinkToCmdArray m_LinkToCmdArray;	///< Used to defer linking in canned screen setup
	SimulatedMoveMode m_eSimulatedMove;			///< Moving object or widget using arrow keys?
	CLayoutConfiguration *m_pMainConfig;
	CLayoutConfiguration *m_pTptScrConfig;
	CLayoutConfiguration *m_pCannedConfig;
	CLayoutConfiguration *m_pReplayScrConfig;
	CLayoutConfiguration *m_pHotSoakScrConfig;
	CBaseObject *m_HotSoakObjects[NUM_SOAK_LINES][2];
	CBaseObject *m_pHotSoakMedia; // text object for "SD Card" on a Hot Soak Screen 
	CBaseObject *m_pHotSoakAdditionalCheck; //text object for Certificate and IO firmware
	BOOL m_HotSoakboardsFitted[NUM_SOAK_LINES];
	CSRAMRegion *m_pHotSoakRegion;
	struct HotSoakData *m_pHotSoakData;			///< structure stored in SRAM
	CTVtime m_HotSoakBaseTime;
	CTVtime m_HotSoakConfigTime;
	HSTest m_HotSoakTest;
	HSOperation m_HotSoakOp;
	BOOL m_HotSoakConfigChangeComplete;
	ULONG m_HotSoakLastTickUpdate;
	float m_AOlevel;
	CSimpleLog m_HotSoakLog;
	int m_HotSoakCounter[MAXIOCARDS + 2];	///< general counter for each slot (plus 2 is for CF card and certificate).
	CChartObject *m_pReplayChartObject;
	CCursorObject *m_pReplayCursorObject;
	BOOL m_bBringObjectOrWidgetToTop;			///< right-click on object or widget won't
												///< bring it to top
	QString m_csWelcomeTxt;
	CDataItemManager *m_pDIT;
	//E437415
	//LPDIRECTDRAW4			m_pDD;				///< DirectDraw object
	//LPDIRECTDRAWSURFACE4	m_pDDSPrimary;		///< DirectDraw priamry surface 
	//LPDIRECTDRAWSURFACE4	m_pDDSBackBuffer;	///< DirectDraw back buffer surface
	//LPDIRECTDRAWSURFACE4	m_pDDSPermanent;	///< DirectDraw permanent surface 
	//LPDIRECTDRAWSURFACE4	m_pDDSAlpha;		///< DirectDraw surface (Alpha)
	LPDIRECTDRAW m_pDD;				///< DirectDraw object
	LPDIRECTDRAWSURFACE m_pDDSPrimary;		///< DirectDraw priamry surface 
	LPDIRECTDRAWSURFACE m_pDDSBackBuffer;	///< DirectDraw back buffer surface
	LPDIRECTDRAWSURFACE m_pDDSPermanent;	///< DirectDraw permanent surface 
	LPDIRECTDRAWSURFACE m_pDDSAlpha;		///< DirectDraw surface (Alpha)
	LPDIRECTDRAWCLIPPER m_pDDClipper;		///< DirectDraw Clipper
	LPDIRECTDRAWCLIPPER m_pDDClipperWindow;	///< DirectDraw Clipper number 2
	LPRGNDATA m_pClipList;		///< pointer to cliplist
	int m_ClipListSize;		///< size of memory block for cliplist
	int m_InitCount;		///< incremented after each initialisation
	BOOL m_ResetDDrequired;
	BOOL m_UseTransparentBlt; ///< Whether to use TransparentBlt function to draw time stamp or not? 
	BOOL m_isControlbarVisible;
	BOOL m_bIsHelpActive;	// Determine whether the help window is the active window.
protected:
	static BOOL m_bUpdatePasteCaret;			///< Used so that we don't update the
												///< paste caret when we simulate a mouse
												///< down in DeleteSelection
	static QPoint m_ptPasteCaret;				///< Paste caret position within screen
	BOOL m_bUpdateLayoutItemSelected;			///< Don't call OnLayoutItemSelected in
												///< OnLButtonDown for arrow key processing;
												///< just use already selected object or widget
	// Operations
public:
	void AlignLytItemsleft();
	void AlignLytItemsright();
	void AlignLytItemsTop();
	void AlignLytItemsBottom();
	void AlignLytItemsCenterHorizontal();
	void AlignLytItemsCenterVertical();
	void AlignLytItemsmiddle();
	void DetermineSelectedItems();				///< Determine what's selected on the active screen
	void MoveObjectOrWidget(QPoint ptOffset);	///< Move selected object or widget by given amount
	void ResizeObjectOrWidget(QPoint ptOffset);	///< Resize selected object or widget by given amount
	void SetClipListBuffer(int bytescount);
	BOOL SetConfiguration(CLayoutConfiguration *lc, BOOL firstTime = FALSE, const bool bPOST_SHOW_SCREEN_MSG = true);
	void ConfigChange();
	BOOL RotateScreen();
	void Refresh();
	void Repaint();
	CTemplate* indexOfTemplateInstance(T_LAYOUTITEM *templateRef);
	CScreen* indexOfScreenInstance(T_LAYOUTITEM *screenRef);
	CLayoutItem* indexOfItemInstance(T_LAYOUTITEM *itemRef);
	void UpdateBounds(QRect *bounds, T_LAYOUTITEM *widgetRef, T_LAYOUTITEM *objectRef = NULL, int *pPos1 = NULL,
			int *pPos2 = NULL);
	void UpdateLinks(T_LAYOUTITEM *widgetRef);
	BOOL ShowHotSoakScreen();
	void RefreshHotSoakScreen(BOOL ForceUpdate = FALSE);
	BOOL TestAnalogueInBoard(int slotNo);
	BOOL TestAnalogueOutBoard(int slotNo);
	BOOL TestDigitalIOBoard(int slotNo);
	BOOL TestRelayBoard(int slotNo);
	BOOL TestPulseBoard(int slotNo);
	BOOL TestSDCardOrUSB();
	BOOL PerformMediaRWTest(CSimpleLog *pMedia, T_STORAGE_DEVICE mediaType);
	BOOL TestCertificateAndIOFirmware();
	void ProcessSoftButton(int ButtonID, int ScreenNumber); // button ID and screen number
	int GetReplaySpeed();	// CR: 3151 Replay at Faster speed
	BOOL ShowReplayScreen();
	void ExitReplayScreen();
	CBaseObject* GetReplayObject(ObjectType obType);
	void ChartScrollEarlier(int pixels);
	void ChartScrollLater(int pixels);
	void SetChartScrollMode();
	void SetCursorUpdateMode();
	void ZoomIn();
	void ZoomOut();
	void SetDualCursorMode(BOOL enable);
	void SwapCursors();
	void LinkUnlinkCursors(BOOL link);
	void JumpToPrev();
	void JumpToNext();
	// Method that zooms in on the Y-scale for TUS screen (enables areas of interest to be focussed on)
	void ZoomInTUSYScale(const float fZERO, const float fSPAN);
	// Method that restores the original Y-scale for TUS screen
	void RestoreNormalTUSYScale();
	// functions called from screen designer to add New items etc. Also does CMM updates.
	BOOL ShowTemplate(T_LAYOUTITEM *templateRef);
	BOOL SetCurrentScreen(T_LAYOUTITEM *screenRef);
	BOOL SetCurrentScreen(int ScreenNumber);
	BOOL AddNewTemplate(CLayoutConfiguration *pConfig, T_LAYOUTITEM *templateRef = NULL);
	BOOL AddNewScreen(CLayoutConfiguration *pConfig, T_LAYOUTITEM *templateRef, T_LAYOUTITEM *screenRef = NULL);
	BOOL AddNewWidget(CLayoutConfiguration *pConfig, QRect *bounds);
	BOOL AddNewObject(CLayoutConfiguration *pConfig, T_BLOCKTYPE ObjectBlockType, QRect *bounds);
	BOOL ReorderTemplates(CLayoutItemArray &NewTemplateOrder);
	BOOL ReorderScreens(CLayoutItemArray &NewScreenOrder);
	BOOL DeleteTemplate(T_LAYOUTITEM *templateRef);
	void DeleteScreen(T_LAYOUTITEM *screenRef);
	void OnDropItem(QPoint ptTopleft, CLayoutConfiguration &Layout, T_LAYOUTITEM LayoutItem);
	BOOL AddExistingTemplate(BLOCK_INFO *CMMinfo);
	static void SafeEmptyClipboard();
	// Method that gets a delimited string containing the available template names
	const QString GetTemplateList() const;
	// Method that returns the index of the corresponding template for the passed in template ref
	const USHORT GetTemplateIndex(T_LAYOUTITEM *ptTemplateRef) const;
	// Method that rebuilds the group canned screens following group specific changes to the configuration
	void RebuildGroupCannedScreens();
	// Method that rebuilds the TUS canned screen following changes to the configuration
	void RebuildTUSScreen();
	// Method that makes the recorder enter designer mode
	void EnterDesignerMode();
	// Method that makes the recorder leave designer mode
	const bool LeaveDesignerMode();
	// Method that gets a delimited list of all the screen names
	const QString GetScreenList(const bool bINCLUDE_DISABLED = false, const bool bAPPEND_SCREEN_IDS = false) const;
	// Method that gets a bitmask indicating which screens are setup as rotating
	const ULONG GetRotatingScreensBitfield(const bool bINCLUDE_DISABLED = false) const;
	// Method that sets up the rotating screens based on the passed in bitmask
	void SetRotatingScreens(const ULONG ulROTATING_SCREEN_BITFIELD, const bool bINCLUDE_DISABLED = false);
	// Method that shows the screen list thus allowing the user to change the current screen selection
	void ShowScreenList();
	// Show Non Process Screen
	void ShowNPScreen(BOOL bHidePrevNonProcessScreen, int PrevScreenNumber);
	CWidget* GetCurrentNPS();
	// Method that determines what the required action should be after the user has selected the 
	// settings button from the top status bar
	void ChangeScreenSettings();
	// Method that shows the replay chart speed list, thus allowing the user to change the
	// selected replay charts speed
	// CR: 3151 Replay at Faster speed
	void ChangeReplayScreenSettings();
	// Method that shows the strip chart speed list, thus allowing the user to change the
	// selected charts speed
	void ChangeStripChartSpeed(USHORT usChartIndex, CWidget *pkWidget, CTopStatusBar *pkStatusBar,
			const USHORT usSCREEN_NO);
	// Method that shows the circular chart speed list, thus allowing the user to change the
	// selected charts speed
	void ChangeCircularChartSpeed(USHORT usChartIndex, CWidget *pkWidget, CTopStatusBar *pkStatusBar,
			const USHORT usSCREEN_NO);
	void SetStickyWidgetsOn(BOOL stickyOn) {
		m_bStickyWidgets = stickyOn;
	}
	;	// Accessor for setting sticky wigets ON(TRUE) OFF(FALSE)
	void SetExpertModeOn(BOOL extertOn) {
		m_bExpertMode = extertOn;
	}
	;		// Accessor for setting expert mode ON(TRUE) OFF(FALSE)
	T_OPPANEL_MODE GetMode() {
		return m_OpPanelMode;
	}
	;			///< Get op panel mode
	void SetMode(T_OPPANEL_MODE panelMode) {
		m_OpPanelMode = panelMode;
	}
	;		///< Set op panel mode
	BOOL NotifyRemoteServer(BOOL LocalControl);			///< Notify remote server of local control status
	// Method that gets the currently selected object
	CLayoutItem* GetSelectedObject();
	// Method that gets a valid active screen group number
	const T_PEN_GROUPS GetValidActiveScreenGroupNo(const bool bTHREAD_SAFE);
	// Method that gets an active screen group number even if it is not valid
	const T_PEN_GROUPS GetActiveScreenGroupNo(const bool bTHREAD_SAFE);
	BOOL GetProcessScreenCount(int &nProcessScreens, int &nNonProcessScreens);
	// Method that returns the resolution factor value for various devices.
	float getResolutionFactor();
protected:
	void BeginPasteOperation(EXTRAPASTEINFO &Extra);
	void DeleteSelection(CSelectionList &SelectionList, BOOL bDelete = TRUE);
	void EndPasteOperation(PASTE_OPERATION Operation, EXTRAPASTEINFO &Extra);
	void SetPasteCaretPosition(CSelectionList &SelectionList);
	void SetPasteContext(EXTRAPASTEINFO &Extra);
	static void StaticGetPasteScreenOption(COpPanel *pThis, QString pScreenName, BOOL &bUseSourceTemplate,
			T_LAYOUTITEM &DestinationTemplateRef) {
		pThis->GetPasteScreenOption(pScreenName, bUseSourceTemplate, DestinationTemplateRef);
	}
	// Methods to be overridden by Screen Designer
public:
	virtual void OnBoundsChanged(CLayoutItem *pLayoutItem) {
	}
	virtual void OnLayoutItemSelected(CLayoutItem *pLayoutItem);
protected:
	virtual void GetCurrentScreen(T_LAYOUTITEM *pScreenRef);
	virtual void GetPasteScreenOption(QString pScreenName, BOOL &bUseSourceTemplate,
			T_LAYOUTITEM &DestinationTemplateRef) {
	}
	virtual void OnAddScreen(T_LAYOUTITEM *pScreenRef) {
	}
	virtual void OnAddTemplate(T_LAYOUTITEM *pTemplateRef) {
	}
	virtual void OnDeleteScreen(CScreen *pScreen) {
	}
	virtual void OnDeleteTemplate(CTemplate *pTemplate) {
	}
#ifdef DOCVIEW
	// Overrides to be used by clients of OpPanel (e.g., Screen Designer).
	// Clients of OpPanel may derive from class COpPanel and override these
	// methods as they see fit.
protected:
	// DECLARE_DYNCREATE(COpPanel)
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
public:
	virtual void OnInitialUpdate();
	virtual void OnDraw(CDC* pDC){;} // overridden but does nothing
	virtual BOOL OnScrollBy(QSize sizeScroll, BOOL bDoScroll = TRUE);
	virtual CScrollBar* GetScrollBarCtrl(int nBar) const;
	void InitialiseScrolling(QPoint *pptCurrentScrollPos=NULL);
	#ifndef _DEBUG // debug version in OpPanel.cpp
		inline COpPanelDVDoc* COpPanel::GetDocument() const
			{ return reinterpret_cast<COpPanelDVDoc*>(m_pDocument); }
	#else	
		virtual void AssertValid() const;
		virtual void Dump(CDumpContext& dc) const;
		COpPanelDVDoc* GetDocument() const;
	#endif
#endif // #ifdef DOCVIEW
public:
	COpPanel(); // Construction
	virtual ~COpPanel();
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	// Generated message map functions
protected:
	//{{AFX_MSG(COpPanel)
#ifdef DOCVIEW
	int OnCreate(LPCREATESTRUCT lpCreateStruct);
#endif
	void OnEditCut();
	void OnUpdateEditCut(CCmdUI *pCmdUI);
	void OnEditCopy();
	void OnUpdateEditCopy(CCmdUI *pCmdUI);
	void OnEditPaste();
	void OnUpdateEditPaste(CCmdUI *pCmdUI);
	void OnEditClear();
	void OnUpdateEditClear(CCmdUI *pCmdUI);
	void OnToggleStickyWidgets();
	void OnUpdateToggleStickyWidgets(CCmdUI *pCmdUI);
	void OnToggleExpertMode();
	void OnUpdateToggleExpertMode(CCmdUI *pCmdUI);
	void OnLinkObject();
	void OnUpdateLinkObject(CCmdUI *pCmdUI);
	void OnUnlinkObject();
	void OnUpdateUnlinkObject(CCmdUI *pCmdUI);
	void OnLoadTemplate();
	void OnUpdateLoadTemplate(CCmdUI *pCmdUI);
	void OnSaveTemplate();
	void OnUpdateSaveTemplate(CCmdUI *pCmdUI);
	void OnLButtonDown(UINT nFlags, QPoint point);
	void OnMouseMove(UINT nFlags, QPoint point);
	void OnLButtonUp(UINT nFlags, QPoint point);
	void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
#ifndef UNDER_CE
	BOOL OnSetCursor(CWidget *pWnd, UINT nHitTest, UINT message);
#endif
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // 

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ExampleBar.cpp
/// @n Description: Derived Object example (simple bar)
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  33  Stability Project 1.28.1.3 7/2/2011 4:57:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  32  Stability Project 1.28.1.2 7/1/2011 4:38:17 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  31  Stability Project 1.28.1.1 3/17/2011 3:20:24 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  30  Stability Project 1.28.1.0 2/15/2011 3:03:03 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#pragma warning( disable : 4244) 
//extern CDataItemTable Glb_datatable; // Global datatable (for now)
//****************************************************************************
/// ExampleBar Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
/// 
//****************************************************************************
CExampleBar::CExampleBar(CWidget *pParentWidget) : CBaseObject(pParentWidget) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CExampleBar::OnDraw;
	// set all of the objects internal settings to defaults
	// set range of bar from 0 to 100 (ignoring 4% above and below)
	m_TopLimit = 100.0;
	m_BottomLimit = 0.0;
	m_CurrentValue = 0.0;
	m_pDataItemRef = NULL;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
/// 
//****************************************************************************
void CExampleBar::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CExampleBar data in CMM info block.
	m_pCMMexample = (T_EXAMPLEBAR*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		// example bar has only 1 chaanel reference, default to enabled and updating
		m_pCMMexample->ChannelInfo.Enabled = TRUE;
		m_pCMMexample->ChannelInfo.Updates = TRUE;
		m_pCMMexample->ChannelInfo.ItemType = DI_PEN;
		m_pCMMexample->ChannelInfo.SubType = 0;
		m_pCMMexample->ChannelInfo.IndexChan = 0; // use Widget's channel by default
		// set these flags for specific Object (e.g. may be advanced draw only)
		/*
		 m_pCMMbase->IsAdvancedDraw
		 m_pCMMbase->IsBuffered
		 m_pCMMbase->IsPermanent
		 m_pCMMbase->IsBackground
		 m_pCMMbase->IsPrimaryDirect
		 // etc...
		 */
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
	}
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CExampleBar::ConfigChange() {
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	// Data item configuration done here. 
	// example bar only has one data item reference and has the following CMM config:
	// ChannelInfo 
	//		ItemType = DI_PEN etc
	//		Subtype = which max min etc
	//		IndexChan = 0	...index into Widget's Channel 'List'
	if (!m_pDataItemRef)
		m_pDataItemRef = new CDataItemRef(this);	// create our single reference
	if (m_pDataItemRef) {
		// pass it to our Widget, along with our CMM config
		if (m_pWidget->GetDataItem(m_pDataItemRef, &m_pCMMexample->ChannelInfo)) {
			// T_BASEOBJECT CMM config to CBaseObject members:
			// set our internal members values from the Attribute block or source or CMM 
			if (m_pCMMbase->FixForeColour)
				// use foreground colour from CMM (e.g. as selected in Screen Designer)
				m_pForeColour = &m_pCMMbase->ForeColour;
			else {
				if (m_pCMMbase->AttrBlocks.ForeColourBlk)
					// use foreground colour from Attribute block
					m_pForeColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
							m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
				else
					// use foreground colour from Data Item Table item
					m_pForeColour = m_pDataItemRef->m_pDataItem->GetColour();
			}
			if (m_pCMMbase->FixBackColour)
				// use background colour from CMM (e.g. as selected in Screen Designer)
				m_pBackColour = &m_pCMMbase->BackColour;
			else {
				if (m_pCMMbase->AttrBlocks.BackColourBlk)
					// use foreground colour from Attribute block
					m_pBackColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
							m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
				else
					// use background colour from Data Item Table item
					m_pBackColour = m_pDataItemRef->m_pDataItem->GetColour();
			}
			// use flash atrtribute from Attribute block if set (0=default=FALSE)
			m_pFlashing =
					&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.FlashingBlk)->Flashing;
			// use visible atrtribute from Attribute block if set (0=default=TRUE)
			m_pVisible =
					&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
			// T_EXAMPLEBAR CMM config to CExampleBar members:
			if (m_pCMMexample->FixTopLimit)
				m_TopLimit = m_pCMMexample->TopLimit;
			else
				m_TopLimit = m_pDataItemRef->m_pDataItem->GetSpan();
			if (m_pCMMexample->FixBotLimit)
				m_BottomLimit = m_pCMMexample->BotLimit;
			else
				m_BottomLimit = m_pDataItemRef->m_pDataItem->GetZero();
		}
	}
}
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CExampleBar::OnDraw(CExampleBar *pThis, HDC hdc, QRect *pClipRect) {
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	// if Update Required make any updates due to data item changes/flashing then do a repaint
	if (pThis->m_UpdateRequired) {
		if (pThis->m_UpdateValue) {
			// Get latest values from Data Item Table flash
			// NB: these should always be copied to members within the Object, 
			// so that we can draw the same value next time if required.
			pThis->m_CurrentValue = pThis->m_pDataItemRef->m_pDataItem->GetFPValue();
			pThis->m_UpdateValue = FALSE;
		}
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	} else {
		// i.e. m_UpdateRequired is FALSE - no flash/data update here
		if (pClipRect == NULL) {
			// Optimised drawing for overlapped objects:
			// here we are drawing because of an update to some other object that overlaps.	
			// We could inspect our parent widget's update region to see how much we need to 
			// draw or simply draw everything.
		}
	}
	BOOL DrawInFlashState = FALSE;
	if (*(pThis->m_pFlashing)) // if we are flashing set our drawInFlashState.
		DrawInFlashState = pThis->m_FlashState;
	if (pClipRect == NULL) {
		if (pThis->m_pCMMbase->IsBuffered == FALSE) {
			// Optimised drawing for direct foreground:
			// here since pClipRect is null (drawing an update)
			// and IsBuffered flag is FALSE
			// For updates to a non-buffered Object (direct foreground) we can optimise our
			// drawing (just the updating parts) knowing that this object does not overlap any other,
			// (therefore the rest of the object will still be OK)
		}
	}
	// otherwise do our full drawing here.
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	// for our example bar we'll draw it all (rather than just the part in ObjClipRect)
	CFFConversionInfo convInfo;
	convInfo.CalcFConvInfo(pThis->m_BottomLimit, pThis->m_TopLimit, pThis->m_ClientRect.bottom - 1,
			pThis->m_ClientRect.top);
	int drawvalue = (int) (convInfo.CalcSourceToDest(pThis->m_CurrentValue) + 0.5);
	QRect valueRect, backRect;
	valueRect = backRect = pThis->m_ClientRect; // Objects Client Area (bounds less border)
	valueRect.setTop(drawvalue);
	backRect.setBottom(valueRect).top;
	// Create a brush for background part
	HBRUSH hBrushback = CreateSolidBrush(*pThis->m_pBackColour);
	// Create a brush for foreground part
	HBRUSH hBrushfore;
	if (DrawInFlashState)
		hBrushfore = CreateSolidBrush(RGB(255, 255, 0)); // yellow !!
	else
		hBrushfore = CreateSolidBrush(*pThis->m_pForeColour);
	FillRect(hdc, &backRect, hBrushback);
	FillRect(hdc, &valueRect, hBrushfore);
	// Delete the brush object and free all resources associated with it.
	DeleteObject(hBrushback);
	DeleteObject(hBrushfore);
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CExampleBar::Destroy() {
}
LinkOrientation CExampleBar::GetLinkOrient() {
	// examplebar is vertical only
	return LINK_VERTICAL;
}
BOOL CExampleBar::CanSetLinkPositions(int pos1, int pos2) {
	// examplebar is vertical only
	// otherwise we would check our orientation here and interpret pos1 and pos2 accordingly
	// apply some other restrictions here if required..
	if (pos2 - pos1 < 20)
		return FALSE;
	return TRUE;
}
#pragma warning( default : 4244)

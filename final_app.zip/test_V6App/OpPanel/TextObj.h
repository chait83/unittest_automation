/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: TextObj.h
/// @n Description: Text Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 5:02:05 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:25:53 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 11/30/2006 9:25:29 PM  Jason Parker  
//  make size of string public
//  3 V6 Firmware 1.2 5/24/2006 9:01:20 PM  Jason Parker  Add
//  flashing to text objects
// $
//
// **************************************************************************
#ifndef _TEXTOBJ_H
#define _TEXTOBJ_H
//**Class*********************************************************************
///
/// @brief Text Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used to show Text in a Widget in OpPanel
///
//****************************************************************************
class CTextObject: public CBaseObject {
private:
	CDataItemRef *m_pDataItemRef;	///< data item table reference
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CTextObject *pThis, HDC hdc, QRect *pClipRect);
	QString m_pTextString;
	/// Variable used as a temporary store for the text string when doing config changes on the object
	QString m_pwcTempCfgTextString;
public:
	/// Buffer length for the temp text string above
	static const USHORT ms_usMAX_TEXT_STRING_LENGTH;
// make this private when done testing
	T_TEXTOBJECT *m_pCMMtext;		///< pointer to our CMM configuration
	CTextObject(CWidget *pWidget);
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
	// Method that returns a pointer to an internal string that is a copy of the text string held in
	// the CMM
	QString  GetTextString();
	void SetTextString(QString pText);
};
#endif

/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CirciViewModel.h
/// @n Description: View model for the circular chart mode
// **************************************************************************
#pragma once
#define MAX_CIRCI_PENS		MAX_CHART_PENS
class CirciViewModel;
// Message type indicators used to draw the correct type, the ordering of these are
// higher for priority, so if extending order accordingly.
#define CIRCI_MESSAGE_INDICATOR_NONE		0			//No messages
#define CIRCI_MESSAGE_INDICATOR_MESSAGE		1			// Std message, mark on chart etc..
#define CIRCI_MESSAGE_INDICATOR_ALARM_OUT	2			// Alarm out message
#define CIRCI_MESSAGE_INDICATOR_ALARM_IN	3			// Alarm in message
// Circi trend reading status
typedef enum {
	CRS_NO_READING = 0,					// No reading for this slot
	CRS_READING,						// Reading avaiulable and rendered
	CRS_READING_UPDATED					// Reading available and updated (not rendered)
} T_CIRC_READING_STATUS;
// Circi trend reading
typedef struct {
	float Max;							// Max reading
	float Min;							// Min reading
	T_CIRC_READING_STATUS Status;		// Reading Status
} CIRCI_TRACE_READING;
//**Class*********************************************************************
///
/// @brief CirciTrace 
/// 
/// View model for the individual traces
///
//****************************************************************************
class CirciTrace {
public:		// Members
	int m_NumReadings;					// Number of readings in trace
	CIRCI_TRACE_READING *m_Buf;			// Readings buffer
	CDataItem *m_pChartDataItem;		// Associated data item
	CChartQ *m_pChartQ;					// Associated chart queue
	BOOL m_Initialised;					// Have trace ben intitialised
	CFFConversionInfo m_convInfo;		// Conversion info from readings to screen pixel heights
	CirciViewModel *vm;					// Ptr back to parent view model
public:		// Methods
	CirciTrace();
	~CirciTrace();
	void Reset();
	void AllocateReadings(int readings);
	void ClearReadings();
	void UpdateReading(int index, float min, float max);
	void DeleteBuffer();
	void UpdateReadingsFromQueue(int fromIndex, int toIndex);
};
// Circi control reading structure
typedef struct {
	USHORT Coverage :1;  // Does this position have data coverage in chart queues 
	USHORT Message :3;			// Message indicator, representing basic types  
	USHORT Unused :4; // Unused 
	USHORT TimeGrad :8;	// Index of Time grad to show, 0 = no grd, make sure this can accomodate MAX_CIRCI_TIME_GRADS
	LONGLONG AbsQueueTick;		// Absolute Queue tick number for start of reading
	LONGLONG AbsQueueTickEnd;	// Absolute Queue tick number for end of reading
} CIRCI_CONTROL_READING;
#define MAX_CIRCI_TIME_GRADS	200	
// Circi Time Grad types
typedef enum {
	CTT_NONE = 0,							// No timegrad
	CTT_MAJOR,								// Major timegrad
	CTT_MINOR,								// Minor timegrad
	CTT_SUB_MINOR,							// Sub Minor timegrad
} T_CIRC_TIMEGRAD_TYPE;
// Circi Time Grad
typedef struct {
	T_CIRC_TIMEGRAD_TYPE Type;				// Type of time graduation to be displayed
	float PositionInDegrees;				// Accurate position of graduation mark
	CTVtime TimeStamp;						// Timestamp of grad position							
} CIRCI_TIMEGRADS;
//**Class*********************************************************************
///
/// @brief CirciViewModel 
/// 
/// View model for the circular chart
///
//****************************************************************************
class CirciViewModel {
public:		// Members
	// Readings
	int m_NumReadings;						// Number of readings the circular chart is divided into
	float m_DegreesPerReading;				// Degrees per readings
	// Control readings
	CIRCI_CONTROL_READING *m_CtlBuf;		// Control buffer
	CIRCI_CONTROL_READING nullCtlReading;	// Provide null object for control reading
	// Trace Readings
	CirciTrace m_Trace[MAX_CIRCI_PENS];		// Individual traces	
	CirciTrace m_NullObjectTrace;			// Provide a null object trace for faster lookups
	int m_EnabledTraces;					// Number of enabled traces
	// Time Control
	CTVtime m_ChartStartTime;				// Start time of the chart
	LONGLONG m_ChartSpanUSec;				// Chart span in seconds
	CTVtime m_ChartEndTime;					// End time of Chart
	LONGLONG m_USecsPerReading;				// Number of microseconds per reading 
	LONGLONG m_TicksPerReading;				// Number of ticks per reading (or time per pixel in strip charts)
	LONGLONG m_ChartStartTimeInTicks;		// Start time of the chart in ticks		
	LONGLONG m_ChartEndTimeInTicks;			// End time of the chart in ticks	
	double m_SecsPerDegree;					// Number of seconds in 1 degree
	CIRCI_TIMEGRADS m_TimeGrads[MAX_CIRCI_TIME_GRADS];// List of time graduations (0 index unused as rogue value for in CIRCICONTROL lookup
	int m_NumGrads;											// Number of time graduations in buffer
	// Messages
	CChartMessageQ *m_pMessageQ;			// Message queue access
	BOOL m_InitialisedMessages;				// Message queue init flag
	int m_GroupNumber;						// Group number of messages to display
	// Dimensions
	int m_centreX;							// X coordiante Centre of circle 
	int m_centreY;							// Y coordiante Centre of circle 
	int m_radius;							// Overall radius
	int m_holeRadius;						// hole radius in centre of chart 
	int m_zeroRadius;						// zero point radius
	int m_spanRadius;						// span point radius
	int m_lastReadingIx;					// Last reading index updated
private:		// Methods
	void AddTimeGraduation(T_CIRC_TIMEGRAD_TYPE type, float positionInDegrees);
	// Control Buffer
	void DeleteControlBuffer();
	void AllocateControlBuffer();
	void ClearControlBuffer();
	void ClearControlBufferTimeGrads();
public:
	CirciViewModel(void);
	~CirciViewModel(void);
	void Reset();
	void FullClear();
	void Clear();
	// Inititalisations
	void SetDimensions(int centreX, int centreY, int radius, int centreHoleRadius, int underrangeLeader,
			int overrangeLeader);
	void SetDataInfo(CTVtime startTime, long timeSpanSeconds, int numReadings, int numMajor, int numMinor,
			int numSubMinor);
	void SetDimensionsFromBoundingRect(QRect *bounds, int padding);
	// helpers
	void GetCoordsFromHeightAndDegrees(float degrees, float height, int &xOut, int &yOut, bool clipToTrace);
	void GetCoordsFromHeightAndDegrees(float degrees, float height, QPoint &pt, bool clipToTRace);
	QRect GetBoundingRectFromHeight(int height);
	LONGLONG GetUsecTimeFromReadingIndex(int index);
	LONGLONG GetTicksFromTimeEntry(CTVtime targetTime, DetailedTimeEntry *pEntry);
	// Trace
	void AllocateTraceReadings(int index);
	CirciTrace* GetTrace(int index);
	// Time Control
	int GetReadingIndexByDegrees(float degrees);
	void ClearTimeGrads();
	CIRCI_TIMEGRADS* GetTimeGrad(int index);
	void UpdateTickLimits();
	// Control readings
	CIRCI_CONTROL_READING* GetControlReading(int index);
	// Updates
	int UpdateReadings(CTVtime timeToUpdateTo);
	void UpdateMessagesFromQueue(int fromIndex, int toIndex);
};

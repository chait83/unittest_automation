/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: OpPanel.cpp 
/// @n Description: OpPanel class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  456  Stability Project 1.451.1.3  7/2/2011 4:59:19 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  455  Stability Project 1.451.1.2  7/1/2011 4:38:33 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  454  Stability Project 1.451.1.1  3/17/2011 3:20:32 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  453  Stability Project 1.451.1.0  2/15/2011 3:03:35 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "OEMInfo.h"
#include "Alarms.h"
#include "PPL.h"
#include "FileList.h" // temporary
#include "CStorage.h"
#include "V6globals.h"
#include "StringUtils.h"
#include "Printer.h"
#include "MediaManager.h"
#include "AMS2750TUSMgr.h"
#ifndef DOCVIEW
#ifndef V6IOTEST
#include "ScrnDesCfgDlg.h"
#include "mainmenudlg.h"
#include "cfgcommitdlg.h"
#include "TopStatusBar.h"
#include "ConfigData.h"
#include "CfgBitFieldEditDlg.h"
#include "V6MessageBoxDlg.h"
#include "ConfigInterface.h"
#include "BoardManager.h"
#include "BrdInfo.h"
#include "MessageListDlg.h"
#include "BatchManager.h"
#endif
#endif
#ifdef SHOW_CPU
	#include "cpumon.h"
#endif
#ifdef DOCVIEW
#include "ValidateLayoutDlg.h"
#endif
#ifdef TTR6SETUP
#include <winsock2.h>
#endif
#include "EUDC.h"
#include "UISizeDefines.h"
#ifdef DOCVIEW
#include "browsedibs.h"
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// Define IS_RECORDER=1 if this is a recorder firmware build
#ifdef DOCVIEW
#define IS_RECORDER	0
#endif
#ifdef V6IOTEST
#define IS_RECORDER 0
#endif
#ifndef IS_RECORDER
#define IS_RECORDER 1
#endif
#define CANNED_SCREENS TRUE
#define MOUSE_INACTIVITY_MSEC 10000 // 10 seconds
#define StartupTimerId 827
#define LOG_FILE_NAME "\\SDMemory\\V6AppLog.txt"
FILE *fp = NULL;
HWND g_hWnd = 0;
void OpenLog() {
#if 1
	if (fp == NULL) {
		errno_t err = fopen_s(&fp, LOG_FILE_NAME, "a+");
	}
	// errno_t err = fopen_s(&fp, "\\Storage_card\\Log.txt", "w+");
	// errno_t err = fopen_s(&fp, "\\Hard Disk\\Log.txt", "w+");
	/* if (err ==0)
	 {
	 fclose(fp);
	 fp = 0;
	 }*/
#endif
}
void InfoLogBuff(unsigned char *lpstr, int length) {
#if 1
	if (fp == NULL)
		OpenLog();
	/*FILE *fp = 0;
	 errno_t err = fopen_s(&fp, LOG_FILE_NAME, "a+");*/
	//errno_t err = fopen_s(&fp, "\\Hard Disk\\Log.txt", "a+");
	if (/* err ==0 &&*/fp && lpstr) {
		//	fwrite("\r\n", sizeof(CHAR), strlen("\r\n"),fp);
		fwrite("Data: ", sizeof(CHAR), strlen("Data: "), fp);
		for (int i = 0; i < length; i++) {
			unsigned char ch = (unsigned char) lpstr[i];
			fprintf_s(fp, "0x%02X ", ch);
		}
		fwrite("\r\n", sizeof(CHAR), strlen("\r\n"), fp);
//		fwrite("\r\n", sizeof(CHAR), strlen("\r\n"),fp);
		fflush(fp);
	}
	if (fp)
		fclose(fp);
	fp = 0;
#endif
}
int Glb_BitsPerPixel = 0;
HWND Glb_hWnd = 0;
BOOL Glb_SeeRegions = FALSE;
int Glb_MouseTick = 0;
QPoint Glb_MousePos;
ChartSpeed Glb_ReplaySpeed = SPEED_FAST;
int Glb_FontHeight = 11; //default chart font height
extern qint64 SECS_TO_MICROS;
QPoint COpPanel::m_ptPasteCaret;
BOOL COpPanel::m_bUpdatePasteCaret = TRUE;
BOOL COpPanel::m_bStickyWidgets = FALSE;
BOOL COpPanel::m_bExpertMode = FALSE;
// For testing only (to build tables in EUDC.h)
BOOL COpPanel::m_bCalculateEUDCAttributes = TRUE;
UINT FULLMODESTATUS, LOCALUSERSTATUS;
QString SS_STARTUP_SECTION_STRINGS[MAX_STARTUP_SECTIONS] = { L"Initial Boot Phase", L"Hardware Initialisation",
		L"System Integrity Checks", L"Load Configurations", L"Starting Modules" };
//****************************************************************************
///
///	Called when the OpPanel should register with Control Sequencer
///
/// @param none
///
/// @return	none
/// 
//****************************************************************************
void COpPanel::Register() {
	// Register to the Module Message Manager to receive message via PostThread messages
	// now done by creating a derived object with virtual functions	
	m_pV6Module = new COpPanelModule(this, MODULE_OP_PANEL, MODULE_USE_POSTMESSAGE); // create our V6 Module class, telling it who we are..
	// need to create our internal message queue
	m_pInternalMessageQueue = new CInternalMessageQueue;
	//m_pInternalMessageQueue->InitInternalMessageQueue(50,4096,(DWORD)QThread::currentThreadId(),IMQ_USE_POST_THREAD_MESSAGE); 
	m_pInternalMessageQueue->InitInternalMessageQueue(74,
			100 + 74 * (sizeof(T_USRREQSER_USER_MESSAGE_REPLY) + sizeof(CInternalMessage)),
			(DWORD) QThread::currentThreadId(), IMQ_USE_POST_THREAD_MESSAGE);
	// here we register our internal message queue so that disk service notifications will be posted to us.
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	ds.RegisterWithQMDiskServices(USRREQSER_USER_OPPANEL, m_pInternalMessageQueue);
	Glb_hWnd = m_hWnd;
	//Initially set the flag to FALSE.
	m_UseTransparentBlt = FALSE;
}
//******************************************************
/// COpPanelModule constructor
///
/// 
//******************************************************
COpPanelModule::COpPanelModule(COpPanel *pOpPanel, T_MODULE_ID moduleId, T_MODULE_MSG_NOTIFICATION moduleNotification) : CV6ActiveModule(
		moduleId) {
	m_pOpPanel = pOpPanel;
	m_ModuleMsgManagerClient.MMMClientRegister(moduleId, moduleNotification, CAMQ_QUEUE_WRAP_DISABLED);
	// get a handle on the OEM info class and load the OEM resources
	COEMInfo *pkOEMInfo = COEMInfo::Instance();
}
//******************************************************
/// Primary Initialisation of the Module
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE COpPanelModule::PerformPrimaryInitialisation(void) {
	return V6ACTMOD_ACTION_NOT_PERFORMED;
}
//******************************************************
/// Secondary Initialisation of the Module
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE COpPanelModule::PerformSecondaryInitialisation(void) {
	return V6ACTMOD_ACTION_NOT_PERFORMED;
}
//******************************************************
/// Start normal operation after a config change or startup
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE COpPanelModule::NormalOperation() {
	return V6ACTMOD_OK;
}
//******************************************************
/// Prepare for a configuration change
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE COpPanelModule::SetupConfigChangePreparation() {
	m_pOpPanel->m_CritSec.Lock();
	InterlockedIncrement(&m_pOpPanel->m_Inactive); // to prevent drawing
	while (m_pOpPanel->m_IsDrawing)
		sleep(20);
	return V6ACTMOD_OK;
}
//******************************************************
/// Configuration change completed, use new config
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE COpPanelModule::SetupConfigChangeComplete() {
	if ((m_pOpPanel->m_IsSetupConfigChange) && (!m_pOpPanel->m_pReplayScreen)) // not if currently in replay (can happen with FTP setup upload)
			{
		CPenSetupConfig *pPenSetupCfg = pSETUP->GetPenSetupConfig();
		CGeneralSetupConfig *pkGeneralSetupCfg = pSETUP->GetGeneralSetupConfig();
		if (pPenSetupCfg->GroupsChanged() || pkGeneralSetupCfg->FurnacesChanged()) {
			m_pOpPanel->RebuildGroupCannedScreens();
		} else if (pkGeneralSetupCfg->TUSInfoChanged() && pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
			// furnace 1 has changed and this is a TUS recorder - this means we will need to update the TUS screen
			m_pOpPanel->RebuildTUSScreen();
		} else {
			m_pOpPanel->ConfigChange();
		}
	} else {
		m_pOpPanel->ConfigChange();
	}
	// This function gets called at startup WITHOUT a call to SetupConfigChangePreparation( )
	// in the meantime we need to be able to draw at startup, so Inactive starts as 0.
	InterlockedDecrement(&m_pOpPanel->m_Inactive);
	if (m_pOpPanel->m_Inactive < 0)
		m_pOpPanel->m_Inactive = 0; // to allow drawing
	// this critsec starts off set for the same reason.
	m_pOpPanel->m_CritSec.Unlock();
	if (pSYSTEM_INFO->IsInHotSoakTestMode()) {
		m_pOpPanel->m_HotSoakConfigChangeComplete = TRUE;
	}
	m_pOpPanel->m_RotateBaseTime.TimeNow();	// after setup change rotating will resume after normal rotate time delay
	m_pOpPanel->m_MoveScreenTick = GetTickCount();
	if (!m_pOpPanel->m_pReplayScreen) // only if not in replay
		m_pOpPanel->m_DoScreenMove = TRUE; // on exit show the status bar (and move the window)
	m_pOpPanel->Repaint();
	return V6ACTMOD_OK;
}
//******************************************************
/// Shutdown has been requested close down all processes
/// ready for final shutdown
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE COpPanelModule::ShutdownPreparation() {
	return V6ACTMOD_OK;
}
//******************************************************
/// Final shutdown, release all resources allocated in module
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE COpPanelModule::Shutdown(void) {
	return V6ACTMOD_OK;
}
//****************************************************************************
/// Post a message to the control sequencer to tell it the config has changed
///
/// @param[in] datalength	- Size in bytes of the data of the message
/// @param[in] pData		- Pointer to the Data to be sent with message 
/// 
/// @return none
///
//****************************************************************************
void COpPanelModule::SignalConfigChange(USHORT datalength, BYTE *pData) {
	if (MMMCLIENT_MESSAGE_POSTED
			!= m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_CONTROL_SEQUENCER, MODULE_OP_PANEL,
					MOD_CONFIG_CHANGE, datalength, pData))
		qDebug(">>>>>>NOT POSTED CONFIG CHANGE\n");
}
//****************************************************************************
/// Post a message to the control sequencer to shutdown the system
/// Or perform a firmware upgrade
///
/// @return none
//****************************************************************************
void COpPanelModule::SignalShutdown() {
	// Shutdown the system
	m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE, INFINITE, MODULE_CONTROL_SEQUENCER, MODULE_OP_PANEL,
			MOD_SYSTEM_SHUTDOWN, 0, NULL);
}
//****************************************************************************
// TOP LEVEL FUNCTIONS - To be called by Screen Designer etc.
//	
//****************************************************************************
//****************************************************************************
///
/// Build the default canned screens (will always be at least one)
///
/// @param none 
///
/// @return	none
/// 
//****************************************************************************
void COpPanel::DefaultCannedScreens() {
	InterlockedIncrement(&m_Inactive); // prevent drawing
//#ifndef DOCVIEW
#ifndef DOCVIEW
	// do not show the TUS screen in screen designer
	if ( pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		BLOCK_INFO tBlockInfo;
		if (m_pMainConfig->AddScreen(NULL, &tBlockInfo) == CONFIG_OK) {
			T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
			ptScreen->Type = TPL_AMS2750_TUS_SCREEN;
			ptScreen->Enabled = true;
			ptScreen->CannedPens[0].PenIndex = gs_usSPECIAL_TUS_PEN_START_INST;
			ptScreen->CannedPens[1].PenIndex = gs_usSPECIAL_TUS_PEN_START_INST + 1;
			ptScreen->CannedPens[0].Scale = TRUE;
			COLORREF crScreenBkgCol = QString(0, 0, 0);
			ptScreen->BackColour = static_cast<ULONG>(RGBtoRGB565(crScreenBkgCol));
			CStringUtils::SafeWcsCpy(ptScreen->Name, L"AMS2750 TUS", SCREEN_NAME_LEN);
			CScreen *pScreen = new CScreen(this);
			m_pActiveScreen = pScreen;
			pScreen->CMMInitScreen(m_pMainConfig, &tBlockInfo, NEW_INSTANCE); // configure screen and decendents
			AppendScreen(pScreen);
		}
	}
#endif
	int actualPens = pSYSTEM_INFO->GetTotalPens();
	// add 3 default screens for now
	for (int scrn = 1; scrn <= 3; scrn++) {
		BLOCK_INFO screenBlockInfo;
		if (m_pMainConfig->AddScreen(NULL, &screenBlockInfo) == CONFIG_OK) // NULL for Canned Screen
				{
			// added ok, and populated screenBlockInfo with new Screens CMM details
			// complete the other canned screen settings.
			T_SCREEN *pScrCmm = (T_SCREEN*) screenBlockInfo.pByBlock;
			int numpens = 1;
			if (scrn == 1) {
				pScrCmm->Type = TPL_CHRT_DPMS;
				numpens = 8; // default for mini.
				if (m_pMainConfig->GetRecorderType() == DEV_EZTREND)
					numpens = 6; // default for Ez
				else if (m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS
						|| m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS)
					numpens = 12; // 12 for multi canned screen with chart
				pScrCmm->IsRotate = TRUE;
			} else if (scrn == 2) {
				pScrCmm->Type = TPL_DPMS;
				numpens = 8; // default for mini.
				if (m_pMainConfig->GetRecorderType() == DEV_EZTREND)
					numpens = 6; // default for Ez
				else if (m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS
						|| m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS)
					numpens += 8;
			} else if (scrn == 3) {
				pScrCmm->Type = TPL_DPMS_BARS;
				pScrCmm->IsVert = TRUE;
				numpens = 8; // default for mini.
				if (m_pMainConfig->GetRecorderType() == DEV_EZTREND)
					numpens = 6; // default for Ez
				else if (m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS
						|| m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS)
					numpens += 8;
			}
			if (actualPens < numpens)
				numpens = actualPens; // set the screen up for what we have e.g. could be just 3 pens for Ez.
			// configure the first numpens pens
			// we look for pens that actually exist, and they are put into the 'numpens' slots that we have
			int cpi = 0;
			for (int penNumber = 0; penNumber < V6_MAX_PENS; penNumber++) {
				if (cpi < numpens) {
					if ( pSYSTEM_INFO->IsPenAvailable(penNumber, ZERO_BASED) == TRUE) {
						pScrCmm->CannedPens[cpi].PenIndex = penNumber;
						pScrCmm->CannedPens[cpi].MaxMin = 1;
						pScrCmm->CannedPens[cpi].Total = 1;
						pScrCmm->CannedPens[cpi].Scale = 1;
						cpi++; // onto next canned pen slot
					}
				} else
					break; // no more slots.
			}
			// now create a C++ Screen Object for it.
			CScreen *pScreen = new CScreen(this);
			m_pActiveScreen = pScreen;
			pScreen->CMMInitScreen(m_pMainConfig, &screenBlockInfo, NEW_INSTANCE); // configure screen and decendents
			AppendScreen(pScreen);
		}
	}
	/*
	 #else
	 // add default screens for testing
	 for(int scrn=1; scrn<=16; scrn++)
	 {
	 BLOCK_INFO screenBlockInfo;
	 if(m_pMainConfig->AddScreen(NULL, &screenBlockInfo)==CONFIG_OK) // NULL for Canned Screen
	 {
	 // added ok, and populated screenBlockInfo with new Screens CMM details
	 // complete the other canned screen settings.
	 T_SCREEN *pScrCmm=(T_SCREEN*)screenBlockInfo.pByBlock;
	 
	 
	 //pScrCmm->Type=TPL_DPMS;
	 pScrCmm->Type=TPL_DPMS_BARS;
	 pScrCmm->IsVert=TRUE;
	 int numpens=scrn;
	 
	 // configure the first n pens
	 for(int p=0; p<numpens; p++)
	 {
	 pScrCmm->CannedPens[p].PenIndex=p;
	 pScrCmm->CannedPens[p].MaxMin=1;
	 pScrCmm->CannedPens[p].Total=1;
	 pScrCmm->CannedPens[p].Scale=1;
	 }
	 
	 
	 // now create a C++ Screen Object for it.
	 CScreen *pScreen=new CScreen(this);
	 m_pActiveScreen=pScreen;
	 pScreen->CMMInitScreen(m_pMainConfig, &screenBlockInfo, NEW_INSTANCE); // configure screen and decendents
	 AppendScreen(pScreen);
	 }
	 }
	 #endif
	 */
#ifndef DOCVIEW
	// here we could do with saving the default config (not for screen designer)
	// As it stands, the canned screens get added to the default config each time
	// the app is run, until a change is made which then saves the complete config.
#endif
	InterlockedDecrement(&m_Inactive);
}
//****************************************************************************
///	Set the current layout configuration to be used in OpPanel.
///
/// @param[in] UserLogin - TRUE if Local control, FALSE if complete
///
/// @return	 - TRUE if Postmessage to RemoteDisplayServer successful,m otherwise FALSE
//****************************************************************************
BOOL COpPanel::NotifyRemoteServer(BOOL LocalControl) {
	BOOL retVal = FALSE;
	/*
	 static CWidget *hRemoteApp = indexOfWindow( NULL,_T("Remote Display") );
	 if( hRemoteApp != NULL )
	 {
	 if( LocalControl == TRUE )
	 {
	 retVal = hRemoteApp->PostMessage( LOCALUSERSTATUS,1,0 );	// User logged in for local control
	 }
	 else
	 {
	 retVal = hRemoteApp->PostMessage( LOCALUSERSTATUS,0,0 );	// User logged out
	 }
	 }
	 else
	 {
	 LOG_ERR( TRACE_OPPANEL, "Remote Display Server not found in system\n");
	 }
	 */
	return retVal;
}
//****************************************************************************
///
///	Set the current layout configuration to be used in OpPanel.
///
/// @param[in] lc			- pointer to Layout Configuration
/// @param[in] firstTime	- optional flag for first time called
/// @param[in]	const bool bPOST_SHOW_SCREEN_MSG - flag indicating if we want OpPanel to show the screen (effectively causes
///													the process screen to update
///
/// @return	T/F - indicating that layout was accepted/rejected
/// 
//****************************************************************************
BOOL COpPanel::SetConfiguration(CLayoutConfiguration *lc, BOOL firstTime /* = FALSE */,
		const bool bPOST_SHOW_SCREEN_MSG /* = true */) {
	// first check that the configuration is a good'un.
	// Otherwise, no point in making any changes
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
	layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
	BLOCK_INFO blockInfo;
	// config can be current or working. need to allow for both here
	if (lc->GetCMMmode() == CONFIG_COMMITTED)
		qDebug("XXX SetConfiguration start- main COMITTED\n");
	else
		qDebug("XXX SetConfiguration start- main WRITABLE\n");
	if (lc->indexOfDataBlock(&layoutItem, &blockInfo)) {
		// ok, found what looks like a good layout config.
		if (m_IsInitialised) {
			// already initialised, need to delete everything and start afresh.
			Destroy(); // deletes all CScreens, CTemplates, CWidgets and Objects.
		}
		// setup the global attribute colour
		if (!pDIT->ApplyLayoutConfig(reinterpret_cast<T_PLAYOUT>(blockInfo.pByBlock))) {
			qDebug("ERROR: Failed to apply layout config to the data item table");
			DebugBreak();
		}
		m_pMainConfig = lc; // keep a copy of the new configuration
		lc->m_pOpPanel = this; // and vice-versa
		// here, if the Main Config id is different from the new config id, then we have loaded a new layout, 
		// and need to destroy the canned screens we have
		if (m_pMainConfig->GetConfigId() != m_PreviousConfigID) {
			if (m_pCannedConfig) {
				m_pCannedConfig->DeleteConfig();
				delete m_pCannedConfig;
				m_pCannedConfig = NULL;
			}
			m_PreviousConfigID = m_pMainConfig->GetConfigId();
		}
		/////////////////////////// TESTING //////////////////////////////////////////////
		if (m_pCannedConfig) {
			if (m_pCannedConfig->GetCMMmode() == CONFIG_COMMITTED)
				qDebug("XXX SetConfiguration test - canned COMITTED\n");
			else
				qDebug("XXX SetConfiguration test - canned WRITABLE\n");
		} else
			qDebug("XXX SetConfiguration - canned being fully rebuilt\n");
		////////////////////////////////////////////////////////////////////////////
		// Canned screens produce CScreen's linked into the COpPanel list of screens, but the canned screen 
		// Templates are not added to the templates list. (so that they cannot be used as the basis for new non-canned screens)
		// Instead they are created in the canned screen configuration, which is separate from the main config
		// They are rebuilt at startup and when a new layout is loaded. Other changes are handled without doing a full rebuild
		BOOL initCannedScreens = FALSE;
		if (m_pCannedConfig == NULL) {
			m_pCannedConfig = new CLayoutConfiguration(CANNED_SCREENS);	// another layout config
			m_pCannedConfig->SetCMMmode(CONFIG_MODIFIABLE); // allow configuration below in CMMInitLayout
			m_pCannedConfig->CreateEmptyConfig();
			m_pCannedConfig->m_pOpPanel = this;
			initCannedScreens = TRUE;
		}
		// now (re)build our C++ hierarchy from it
		CMMInitLayout(m_pMainConfig, &blockInfo, TRUE);
		if (initCannedScreens || (m_pScreens == NULL)) {
			// first time only (or on a load new) after building the canned screen templates 
			// or if we don't have any screens at all in the layout
			if (m_pMainConfig->GetCMMmode() == CONFIG_MODIFIABLE)
				qDebug("XXX SetConfiguration canned - main WRITABLE\n");
			else {
				qDebug("XXX SetConfiguration canned - main NOT WRITABLE\n");
				m_pMainConfig->SetCMMmode(CONFIG_MODIFIABLE); // make it so
			}
			// here we have ensured modifiable
			if (m_pScreens == NULL) {
				// no screens in layout so create default canned screens
				// there are no screens, so this is a new layout. build our default canned screens.
				DefaultCannedScreens();
				// do the commit here.
				m_pCannedConfig->CommitConfig();
				m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
				// Also do this for the main config
				m_pMainConfig->CommitConfig();
				m_pMainConfig->SetCMMmode(CONFIG_COMMITTED);
#ifndef V6IOTEST
				// save the layout back to disk
				CScrnDesCfgMgr *pkCfgMgr = CScrnDesCfgMgr::Instance();
				pkCfgMgr->CommitChanges();
#endif
			} else {
				// do the commit here.
				m_pCannedConfig->CommitConfig();
				m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
				// Also do this for the main config
				m_pMainConfig->CommitConfig();
				m_pMainConfig->SetCMMmode(CONFIG_COMMITTED);
			}
#ifndef DOCVIEW
			// here we delete the hierarchy and rebuild everything from 'Current'
			// this is the correct mode of operation for the recorder (so that 'Park' config works ok)
			Destroy(); // deletes all CScreens, CTemplates, CWidgets and Objects.
			qDebug("XXX SetConfiguration - Rebuilding all again from 'current'\n");
			m_IsCommit = TRUE;
			// and rebuild again from current (committed)
			m_pMainConfig->indexOfDataBlock(&layoutItem, &blockInfo);
			CMMInitLayout(m_pMainConfig, &blockInfo, TRUE); // rebuild all using 'current'
#endif
		}
	} else {
		// did not find the layout block !!
		// stay with our current layout.
		QString strLayoutError("");
		strLayoutError = tr("Fatal Error!!! Failed to load layout.");
		pSYSTEM_INFO->AddStartupErr(strLayoutError);
		LOG_ERR( TRACE_OPPANEL, "\n:-:-:-:-:-:-:-:-:-:-:-:-:-: Invalid Layout not loaded :-:-:-:-:-:-:-:-:-:-:-:-:\n");
		return FALSE;
	}
	if (firstTime) {
#ifdef DOCVIEW
		// FOR SCREEN DESIGNER ONLY
		// here create 'dummy' Screen configuration to be used whenever a Template
		// is selected for viewing. (done here because we know that configs exist at this point in time)
		if(m_pTptScrConfig==NULL)
		{
			m_pTptScrConfig=new CLayoutConfiguration;						// another layout config
			m_pTptScrConfig->SetCMMmode(CONFIG_MODIFIABLE);
			m_pTptScrConfig->CreateCMMHolder(TEMPLATE_SCREEN_CONFIG_ID);	// created separately
			m_pTptScrConfig->CreateTemplateScreenConfig();					// with just a screen config block
		}
#endif
		// here set the first screen as visible (or first template if there are no screens)
		m_pActiveScreen = m_pScreens;
		if (m_pActiveScreen == NULL) {
			// there are no screens, so this is a new layout. build our default canned screens.
//			DefaultCannedScreens(); 
#ifndef V6IOTEST
#ifndef DOCVIEW			
			// FOR V6Target and Desktop ONLY
			m_pActiveScreen = m_pScreens;	 // make the first canned screen the active screen.
#else
			ShowTemplate(&m_pTemplates->GetLayoutItem()); // show first template (using special template screen)
#endif
#endif
		} else
			Repaint();
	}
	////////////////////////////////////////////////////////////////////////////
	if (m_pMainConfig) {
		if (m_pMainConfig->GetCMMmode() == CONFIG_COMMITTED)
			qDebug("XXX SetConfiguration end - main COMITTED\n");
		else
			qDebug("XXX SetConfiguration end - main WRITABLE\n");
	}
	qDebug("XXX SetConfiguration - all complete\n");
	////////////////////////////////////////////////////////////////////////////
#if IS_RECORDER==1
	SetCurrentScreen(m_CurrentScreenNumber);
	// only force OpPanel to update the screen under certain conditions i.e. we're not in the menu system editing things
	if (firstTime && !CTopStatusBar::Instance()->GetEditMode() && bPOST_SHOW_SCREEN_MSG) {
		::PostMessage(m_hWnd, WM_SHOW_OPPANEL, 0, 0); // may be called on a different thread
	}
#endif
	// see if there is a missing .bcf file 
	if (lc->IsMissingBCF()) {
		QString strTitle("");
		QString strMsg("");
		strTitle = tr("Missing .bcf file");
		strMsg =
				tr(
						"This layout contains Bitmap objects and requires the .bcf file saved by Screen Designer.\nCopy the file to the device and reload the Layout");
		CV6MessageBoxDlg kErrDialog(strTitle, strMsg, this);
		kErrDialog.exec();
	}
	return TRUE;
}
#ifndef DOCVIEW	
// CR: 3151 Replay at Faster speed
//****************************************************************************
////
///	Get the speed of reply screen based on real time screen for which replay screen is displayed.
///
/// @param[in] 
/// @return	int - replay chart speed of recorder.
/// 
//****************************************************************************
int COpPanel::GetReplaySpeed() {
	ChartSpeed usNewSpeed = static_cast<ChartSpeed>(pSYSTEM_INFO->GetReplayChartSpeed(m_iActivatedReplayscreen));
	int Speed = CChartQManager::GetReplayChartSpeed(usNewSpeed);
	return 20 * Speed; // Under Normal speed the charts speed was set to 20 Pixel, 						
					 // corresponds to slow speed in replay speed settings. 
}
//****************************************************************************
///
/// Sets up the replay screen 
/// 
/// @param[in] 
///
/// @return TRUE if set OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::ShowReplayScreen() {
	//E528446[
	// Fixed Issue: Replay Screen mode crashes 
	// If active screen template type is "Template 1"
	// If there are no widgets return.
	if (m_pActiveScreen && !m_pActiveScreen->m_pWidgets)
		return FALSE;
	//]
	InterlockedIncrement(&m_Inactive); // prevent drawing	
	m_CritSec.Lock();
// create Screen configuration to be used for Replay.
	if (m_pReplayScrConfig == NULL) {
		m_pReplayScrConfig = new CLayoutConfiguration();					// another layout config
		m_pReplayScrConfig->CreateCMMHolder(REPLAY_SCREEN_CONFIG_ID);	// created separately
		m_pReplayScrConfig->SetCMMmode(CONFIG_MODIFIABLE);				// default to 'working'
		m_pReplayScrConfig->CreateReplayScreenConfig();					// with just a screen config block
	}
	m_iActivatedReplayscreen = m_pActiveScreen->m_pCMMscreen->Number - 1; // CR: 3151 Replay at Faster speed
	T_LAYOUTITEM itemRef;
	itemRef.CMM_Type = BLK_SCRTEMPLATE;
	itemRef.CMM_Inst = REPLAY_SCREEN_INST;
	BLOCK_INFO blockInfo;
	if (m_pReplayScrConfig->indexOfDataBlock(&itemRef, &blockInfo)) // populate the Block_Info
			{
		// found and populated blockinfo OK.
		CTemplate *pTemplate = new CTemplate(this);
		pTemplate->CMMInitTemplate(m_pReplayScrConfig, &blockInfo, NEW_INSTANCE);
		// now do screen
		itemRef.CMM_Type = BLK_SCREEN; // modify the type. instance is the same.
		if (m_pReplayScrConfig->indexOfDataBlock(&itemRef, &blockInfo)) // populate the Block_Info
				{
			// found and populated blockinfo OK.
			// now configure the canned screen settings which will be used for the replay screen 
			// we use these same setting so that we can copy the settings from an actual canned screen 
			// (i.e. we get the same pens etc that are being used) also the horizontal/vertical setting for a chart)
			T_SCREEN *pScrCmm = (T_SCREEN*) blockInfo.pByBlock;
			pScrCmm->Template.CMM_Type = BLK_SCRTEMPLATE;
			pScrCmm->Template.CMM_Inst = REPLAY_SCREEN_INST;
			pScrCmm->IsVert = FALSE;
			Glb_ReplaySpeed = SPEED_FAST; // for now
			Glb_FontHeight = 11; // default
			USHORT totalPens = 8; // default
			if (m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS
					|| m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS) {
//					totalPens=12; // 12 for replay on multi
				totalPens = 18; // 18 for replay on multi(EDF enhancement)
			}
			if (m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS)
				Glb_FontHeight = 11 * 1.28;
			else if (m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND)
				Glb_FontHeight = 11 * 1.25;
			// E527303
			// If ReplayPens is empty then copy all CannedPens to ReplayPens to handle default condition
			// so that all pens will be visible in the Replay mode.
			if (m_pActiveScreen->m_pCMMscreen->ReplayPens[0].PenIndex == 0xffff) {
				for (int iPenIndex = 0; iPenIndex < totalPens; iPenIndex++) {
					m_pActiveScreen->m_pCMMscreen->ReplayPens[iPenIndex] =
							m_pActiveScreen->m_pCMMscreen->CannedPens[iPenIndex];
				}
			}
			if (m_pActiveScreen && m_pActiveScreen->IsCannedScreen()) {
				// is a canned screen, so use it's pens and orientation.
				pScrCmm->IsVert = m_pActiveScreen->m_pCMMscreen->IsVert; // get the orientation
				pScrCmm->UseGroups = m_pActiveScreen->m_pCMMscreen->UseGroups;
				pScrCmm->GroupIndex = m_pActiveScreen->m_pCMMscreen->GroupIndex;
				for (int p = 0; p < totalPens; p++) {
					// E527303
					//pScrCmm->CannedPens[p].PenIndex = m_pActiveScreen->m_pCMMscreen->CannedPens[p].PenIndex;
					//// re-use the DPM flag - normally for canned screens but fine here for replay
					//pScrCmm->CannedPens[p].Dpm=TRUE; // enabled as default
					pScrCmm->ReplayPens[p].PenIndex = m_pActiveScreen->m_pCMMscreen->ReplayPens[p].PenIndex;
					// re-use the DPM flag - normally for canned screens but fine here for replay
					pScrCmm->ReplayPens[p].Dpm = TRUE; // enabled as default
				}
				// here we get the chart speed (from the first chart on the screen (if there is one)) and use this as the 
				// starting point when entering replay
				if (m_pActiveScreen)
					Glb_ReplaySpeed = static_cast<ChartSpeed>( pSYSTEM_INFO->GetChartSpeed(0,
							m_pActiveScreen->m_pCMMscreen->Number - 1));
			} else {
				// not a canned screen, so just use the first n pens from the first widget 
				T_WIDGET *pCMMwgt = m_pActiveScreen->m_pWidgets->GetCMMWidget(); // default to first widget on screen
				// However, if we have clicked on a chart in a widget then use that chart to set the orientation and pens
				bool bFoundChart = false;
				USHORT usChartIndex = 0;
				// see if last object clicked was a chart.
				if (m_pActiveScreen->m_pLastSelectedWidget) {
					// use this widget for pens below
					pCMMwgt = m_pActiveScreen->m_pLastSelectedWidget->GetCMMWidget();
					CBaseObject *pBaseObject = m_pActiveScreen->m_pLastSelectedWidget->m_pLastSelectedObject;
					if (pBaseObject && pBaseObject->m_pCMMbase->ObjectType == ChartObject) {
						// take orientation and speed from this chart
						pScrCmm->IsVert = ((CChartObject*) pBaseObject)->m_pCMMchart->IsVertical;
						Glb_ReplaySpeed = ((CChartObject*) pBaseObject)->m_ChartSpeed;
						Glb_FontHeight = ((CChartObject*) pBaseObject)->m_pCMMchart->FontHeight;
						bFoundChart = TRUE;
					}
				}
				//qDebug("looking for chart\n");
				// if not already set, search for the first chart on the screen
				if (!bFoundChart) {
					CWidget *pWidget = m_pActiveScreen->m_pWidgets;
					while (pWidget && !bFoundChart) {
						CBaseObject *pBaseObject = pWidget->m_pObjects;
						while (pBaseObject) {
							// check if this is a chart object
							if (pBaseObject->m_pCMMbase->ObjectType == ChartObject) {
								// take orientation and speed from this chart
								pScrCmm->IsVert = ((CChartObject*) pBaseObject)->m_pCMMchart->IsVertical;
								Glb_ReplaySpeed = ((CChartObject*) pBaseObject)->m_ChartSpeed;
								Glb_FontHeight = ((CChartObject*) pBaseObject)->m_pCMMchart->FontHeight;
								bFoundChart = TRUE;
								// use this widget for pens below
								pCMMwgt = pWidget->GetCMMWidget();
								break;
							}
							pBaseObject = pBaseObject->m_pNextObj;
						}
						pWidget = pWidget->m_pNextWgt;
					}
				}
				// E527303[
				// If Show replay pens are seleted then get the pen index from 
				// ReplayPens otherwise get the pen list from template
				BOOL bReplayPenList = FALSE;
				if (m_pActiveScreen->m_pCMMscreen->ReplayPens[0].PenIndex != 0xffff)
					bReplayPenList = TRUE;
				//]
				if (!bFoundChart) {
					// No chart has been found, so we must make the replay screen up from a list of widgets
					CWidget *pWidget = m_pActiveScreen->m_pWidgets;
					int p = 0;
					// Run though all widgets on the screen until there are no more widgets to check or the maximum number of replay slots has been filled
					while (pWidget && p < totalPens) {
						CBaseObject *pBaseObject = pWidget->m_pObjects;
						// Run though the base object iof a widget until either a DPM or Bar is found
						while (pBaseObject) {
							if (pBaseObject->m_pCMMbase->ObjectType == DigitalObject
									|| pBaseObject->m_pCMMbase->ObjectType == BarObject) {
								// DPM or bar is found so we want to use it's pen number to add to replay
								// however we must first check that the pen is not already added to replay from aprevious widget
								pCMMwgt = pWidget->GetCMMWidget();
								BOOL penNotFound = TRUE;
								USHORT PenIndex = -1;
								if (!bReplayPenList)
									PenIndex = m_pActiveScreen->ChannelToInstance(pCMMwgt->ChannelList[0]);
								else
									PenIndex = m_pActiveScreen->m_pCMMscreen->ReplayPens[p].PenIndex;
								// Check to see if pen is currently in list
								for (int i = 0; i < p; i++) {
									//E527303
									//if( pScrCmm->CannedPens[i].Dpm == TRUE && pScrCmm->CannedPens[i].PenIndex == PenIndex)
									if (pScrCmm->ReplayPens[i].Dpm == TRUE
											&& pScrCmm->ReplayPens[i].PenIndex == PenIndex) {
										penNotFound = FALSE;
										break;
									}
								}
								// If pen is not in list add it to replay screen
								if (penNotFound) {
									// E527303
									//pScrCmm->CannedPens[p].PenIndex = PenIndex;
									//pScrCmm->CannedPens[p].Dpm = TRUE; // enabled as default
									pScrCmm->ReplayPens[p].PenIndex = PenIndex;
									pScrCmm->ReplayPens[p].Dpm = TRUE; // enabled as default
									p++;
								}
								break;
							}
							pBaseObject = pBaseObject->m_pNextObj;
						}
						pWidget = pWidget->m_pNextWgt;
					}
				} else {
					// E527303[
					// If Show replay pens are seleted then get the pen index from 
					// ReplayPens otherwise get the pen list from template
					BOOL bReplayPenList = FALSE;
					if (m_pActiveScreen->m_pCMMscreen->ReplayPens[0].PenIndex != 0xffff)
						bReplayPenList = TRUE;
					//]
					// now set up the pens from the widget we have
					for (int p = 0; p < totalPens; p++) {
						if (p < pCMMwgt->NumChannels) {
							// E527303
							//pScrCmm->CannedPens[p].PenIndex=m_pActiveScreen->ChannelToInstance(pCMMwgt->ChannelList[p]);
							//// re-use the DPM flag - normally for canned screens but fine here for replay
							//pScrCmm->CannedPens[p].Dpm=TRUE; // enabled as default
							if (!bReplayPenList)
								pScrCmm->ReplayPens[p].PenIndex = m_pActiveScreen->ChannelToInstance(
										pCMMwgt->ChannelList[p]);
							else
								pScrCmm->ReplayPens[p].PenIndex = m_pActiveScreen->m_pCMMscreen->ReplayPens[p].PenIndex;
							// re-use the DPM flag - normally for canned screens but fine here for replay
							pScrCmm->ReplayPens[p].Dpm = TRUE; // enabled as default
						}
					}
				}
				if (!bFoundChart) // otherwise find the first chartspeed for the screen and use that
					Glb_ReplaySpeed = static_cast<ChartSpeed>( pSYSTEM_INFO->GetChartSpeed(0,
							m_pActiveScreen->m_pCMMscreen->Number - 1));
				//EDF Enhancement 07: Ability to select horizontal or vertical replay display 
				//					 for screens configured as Bars or Digital
				if (!bFoundChart /*&& m_pActiveScreen->m_pTemplate->m_pCMMtemplate->StatusBar*/) //Uncomment if required
					pScrCmm->IsVert = m_pActiveScreen->m_pTemplate->m_pCMMtemplate->ReplyOrentation;
			}
			// now create a C++ Screen Object for it.
			m_pReplayScreen = new CScreen(this);
			// attach the template created above
			m_pReplayScreen->m_pTemplate = pTemplate;
			m_pActiveScreen = m_pReplayScreen; // has to be 'active' during init.
			m_pReplayScreen->CMMInitScreen(m_pReplayScrConfig, &blockInfo, NEW_INSTANCE); // screen and depenedents
			// get a pointer to the replay chart object
			m_pReplayChartObject = (CChartObject*) GetReplayObject(ChartObject);
			// and cursor object
			m_pReplayCursorObject = (CCursorObject*) GetReplayObject(CursorObject);
			BOOL dataAtJumpTime = TRUE;
			// see if the JumpId has been set up 
			if (m_JumpId.QuadPart) {
				//	WCHAR buffx[200];
				//	swprintf(buffx,L"OpPanel JUMP to %I64d (%I64d)\n ",m_JumpId.QuadPart,m_JumpId.QuadPart>>16);
				//	qDebug(buffx);
				// it has so set our chart's view appropriately
				dataAtJumpTime = m_pReplayChartObject->SetViewTime(m_JumpId.QuadPart >> 16); // lower word contains 'instance' number of message at that time
				m_JumpId.QuadPart = 0; // reset for next time
				m_Inactive--; // here decrement, since we incremented it when Jump was set up.
			}
			m_CritSec.Unlock();
			InterlockedDecrement(&m_Inactive);
			m_DoScreenMove = FALSE; // if screen was without status bar and moved, we ignore it in replay mode.
			Repaint();
			// now the screen is all up and ready do we have a jump time?
			if (!dataAtJumpTime) {
				LONGLONG oldestFast = 0;
				LONGLONG oldestMedium = 0;
				LONGLONG oldest = 0;
				CChartQManager *CM = CChartQManager::GetHandle();
				CM->GetOldestTimes(&oldestFast, &oldestMedium, &oldest);
				// not always in 'correct' order, since recycling can occur
				if (oldestFast < oldest)
					oldest = oldestFast;
				if (oldestMedium < oldest)
					oldest = oldestMedium;
				// report the oldest data that we have
				WCHAR buff[200];
				::LoadString(AfxGetResourceHandle(), IDS_JUMP_TOO_EARLY, buff, sizeof(buff) / 2);
				//swprintf(buff,L"Message time earlier than oldest chart data:\n");
				int len = (int) wcslen(buff);
				CTimeHistory *pTh = CTimeHistory::GetHandle();
				TableEntry *pEntry = pTh->GetEntry(oldest);
				if (pEntry) // major problem here if no time history!
				{
					LONGLONG diffmicro = (oldest - pEntry->Tick100) * 10000;
					QTime displaytime = pEntry->ActualTime + diffmicro;
					displaytime.TimeToStringNoFracs(&buff[len]); // append to end of buffer
					QString strTitle("");
					strTitle = tr("Jump to Message");
					CV6MessageBoxDlg kDlg(strTitle, buff, this);
					kDlg.exec();
				}
			}
			return TRUE;
		}
	}
	m_CritSec.Unlock();
	InterlockedDecrement(&m_Inactive);
	return FALSE;
}
//****************************************************************************
///
/// indexOfs a particular Object on the replay screen (e.g. Chart or Cursor)
/// 
/// @param[in] none
///
/// @return pointer to CBaseObject or NULL
/// 
//****************************************************************************
CBaseObject* COpPanel::GetReplayObject(ObjectType obType) {
	// get a pointer to a replay object
	CWidget *pWgt = m_pReplayScreen->m_pWidgets;
	while (pWgt) {
		CBaseObject *pObj = pWgt->m_pObjects;
		while (pObj) {
			if (pObj->m_pCMMbase->ObjectType == obType)
				return pObj; // found it ok.
			pObj = pObj->m_pNextObj;
		}
		pWgt = pWgt->m_pNextWgt;
	}
	return NULL;
}
//****************************************************************************
///
/// Scrolls Chart Object on the replay screen right or up 
/// 
/// @param[in] pixels - No. of pixels to scroll
///
/// @return none
/// 
//****************************************************************************
void COpPanel::ChartScrollEarlier(int pixels) {
	if (m_pReplayChartObject)
		m_pReplayChartObject->m_ScrollAmount2 -= pixels;
}
//****************************************************************************
///
/// Scrolls Chart Object on the replay screen left or down
/// 
/// @param[in] pixels - No. of pixels to scroll
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::ChartScrollLater(int pixels) {
	if (m_pReplayChartObject)
		m_pReplayChartObject->m_ScrollAmount2 += pixels;
}
//****************************************************************************
///
/// User can scroll chart in this mode
/// 
/// @param[in] none
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::SetChartScrollMode() {
	if (m_pReplayChartObject)
		m_pReplayChartObject->m_pWidget->BringObjectToTop(m_pReplayChartObject, FALSE); // don't flag layout modified
}
//****************************************************************************
///
/// User can move cursor in this mode
/// 
/// @param[in] none
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::SetCursorUpdateMode() {
	if (m_pReplayCursorObject)
		m_pReplayCursorObject->m_pWidget->BringObjectToTop(m_pReplayCursorObject, FALSE); // don't flag layout modified
}
//****************************************************************************
///
/// Zoom in
/// 
/// @param[in] none
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::ZoomIn() {
	if (m_pReplayChartObject) {
		if (m_pReplayCursorObject->m_DualCursors) {
			// find the centre pos and zoom in there
			LONGLONG centerTime = (m_pReplayCursorObject->m_Cursor1Time + m_pReplayCursorObject->m_Cursor2Time) / 2;
			m_pReplayChartObject->ZoomIn(centerTime);
		} else
			// zoom in on the single cursor pos.
			m_pReplayChartObject->ZoomIn(m_pReplayCursorObject->m_Cursor1Time);
		Repaint();
	}
}
//****************************************************************************
///
/// Zoom Out
/// 
/// @param[in] none
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::ZoomOut() {
	if (m_pReplayChartObject) {
		if (m_pReplayCursorObject->m_DualCursors) {
			// find the centre pos and zoom in there
			LONGLONG centerTime = (m_pReplayCursorObject->m_Cursor1Time + m_pReplayCursorObject->m_Cursor2Time) / 2;
			m_pReplayChartObject->ZoomOut(centerTime);
		} else
			// zoom out at the cursor pos.
			m_pReplayChartObject->ZoomOut(m_pReplayCursorObject->m_Cursor1Time);
		Repaint();
	}
}
//****************************************************************************
///
/// JumpToPrev - Jump to previous message
/// 
/// @param none
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::JumpToPrev() {
	if (m_pReplayChartObject) {
		m_pReplayChartObject->JumpToPrev();
		Repaint();
	}
}
//****************************************************************************
///
/// JumpToNext - Jump to next message
/// 
/// @param none
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::JumpToNext() {
	if (m_pReplayChartObject) {
		m_pReplayChartObject->JumpToNext();
		Repaint();
	}
}
//****************************************************************************
///
/// SetDualCursorMode
/// 
/// @param[in] enable - TRUE if Dual Cursor mode, FALSE if single
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::SetDualCursorMode(BOOL enable) {
	if (m_pReplayCursorObject) {
		m_pReplayCursorObject->SetDualCursors(enable);
		Repaint();
	}
}
//****************************************************************************
///
/// In dual cursor mode, select which is the 'moveable' cursor
/// 
/// @param[in] none
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::SwapCursors() {
	if (m_pReplayCursorObject) {
		m_pReplayCursorObject->SwapCursors();
		Repaint();
	}
}
//****************************************************************************
///
/// In dual cursor mode link or unlink the cursors
/// 
/// @param[in] link - TRUE if should now be linked, FALSE if unlinked
///
/// @return none 
/// 
//****************************************************************************
void COpPanel::LinkUnlinkCursors(BOOL link) {
	if (m_pReplayCursorObject) {
		m_pReplayCursorObject->LinkUnlinkCursors(link);
		Repaint();
	}
}
//****************************************************************************
///
/// Exits the replay screen 
/// 
/// @param none 
///
/// @return TRUE if set OK, FALSE if not found
/// 
//****************************************************************************
void COpPanel::ExitReplayScreen() {
	m_CritSec.Lock();
	m_DoScreenMove = TRUE; // on exit show the status bar (and move the window) if required
	m_MoveScreenTick = GetTickCount(); // and reset tick
	// set all pen queue's beck into 'normal' mode 
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->SetNormalMode();
	m_pReplayChartObject = NULL;
	m_pReplayCursorObject = NULL;
	if (m_pReplayScreen) {
		m_pReplayScreen->Destroy();
		delete m_pReplayScreen;
		m_pReplayScreen = NULL;
		m_pActiveScreen = NULL; // As active screen was set to replay screen we should set it to NULL after destroying replay screen
	}
	// now delete the config
	if (m_pReplayScrConfig) {
		m_pReplayScrConfig->DeleteConfig();
		delete m_pReplayScrConfig;
		m_pReplayScrConfig = NULL;
	}
	SetCurrentScreen(m_CurrentScreenNumber); // go back to the screen we were viewing
	m_CritSec.Unlock();
	// this should not be required since configchange called in setcurrentscreen
//	if(m_pActiveScreen)
//		m_pActiveScreen->ConfigChange(); // ensure this screen is fully redrawn on exit.
}
#endif
#ifndef DOCVIEW	
#ifndef V6IOTEST
BOOL G_TRUE = TRUE;
BOOL G_FALSE = FALSE;
#define CONFIG_INTERVAL (60*15) // seconds to wait before next config change
#define TEST_INTERVAL 5	 // wait this long after config change complete before starting tests
#define STARTUP_DELAY 10 // wait this long at startup before doing first test.
//****************************************************************************
///
/// Sets up the Hot Soak screen 
/// 
/// @param[in] 
///
/// @return TRUE if set OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::ShowHotSoakScreen() {
	InterlockedIncrement(&m_Inactive); // prevent drawing	
	m_CritSec.Lock();
	m_HotSoakBaseTime.TimeNow();
	m_HotSoakConfigTime.TimeNow();
	m_HotSoakLastTickUpdate = 0;
	m_HotSoakTest = TEST_TWO;
	m_HotSoakOp = INIT;
	m_HotSoakConfigChangeComplete = TRUE;
	m_AOlevel = 0.0; // start from 0 and go up in steps of 20
	for (int slot = 0; slot < MAXIOCARDS + 1; slot++) // +1 is for SD card
		m_HotSoakCounter[slot] = 0;
	m_HotSoakLog.SetLogging(L"HotSoakLog.txt", TRUE); // TRUE= do not truncate
	// log the startup/restart time
	m_HotSoakLog.LogLine(L"\r\n------------------------------------------------------");
	WCHAR bufft[50];
	m_HotSoakBaseTime.TimeToStringNoFracs(bufft);
	m_HotSoakLog.Log(L"Startup - %s", bufft);
	// set up our pointer to SRAM - get the state of the Hot Soak (may already heve been running)
	CSRAMManager *pSRAM = CSRAMManager::GetHandle();
	// Always initialise
	pSRAM->Initialise();
	// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
	CSRAMManager::regionError requestReturn = pSRAM->RequestRegion(REGION_HOTSOAK, &m_pHotSoakRegion);
	if (requestReturn != CSRAMManager::REGION_OKAY) {
		m_CritSec.Unlock();
		InterlockedDecrement(&m_Inactive);
		return FALSE;
	}
	m_pHotSoakData = (struct HotSoakData*) m_pHotSoakRegion->GetAddress();
	// Check if this is the first time the region has been used after power on
	if (m_pHotSoakRegion->GetAutoState() == SRAM_STATE_FIRSTUSE) {
		m_pHotSoakData->ElapsedTime.SetTimeSpan(0, 0, 0); // start from zero here.	
		m_pHotSoakData->IsRunning = FALSE;
		m_pHotSoakData->MaxDegF = 0.0;
		m_pHotSoakData->MinDegF = 0.0;
	}
	// always set this now (to prevent recorders that have been loaded with older firmware showing 43 hours)
	m_pHotSoakData->RunTime.SetTimeSpan(12, 0, 0); // was 48 hours less 5 (for Bob Faria) i.e. 43, now 33, Change to 12 Hrs
	m_pHotSoakRegion->SetAutoStateToNormal();	// Return to normal state
	// if not running,(and not failed) reset each of the slots status to unknown.
	if ((m_pHotSoakData->IsRunning == FALSE) && (m_pHotSoakData->HasFailed == FALSE)) {
		for (int slot = 0; slot < MAXIOCARDS + 1; slot++) // +1 is for SD card
			m_pHotSoakData->SlotStatus[slot] = HS_UNKNOWN;
		m_HotSoakLog.Log(L"Test is NOT running");
	}
	if (m_pHotSoakData->IsRunning) {
		// is running, so continue the log
		WCHAR timebuff[20];
		TimeSpanToStringHM(&m_pHotSoakData->ElapsedTime, timebuff);
		m_HotSoakLog.Log(L"Test has been running for %s", timebuff);
	}
	//	pSRAM->ReleaseRegion( REGION_TEST ); // todo required when we are finished with it?
	// create Screen configuration to be used for Hot soak.
	if (m_pHotSoakScrConfig == NULL) {
		m_pHotSoakScrConfig = new CLayoutConfiguration();					// another layout config
		m_pHotSoakScrConfig->CreateCMMHolder(HOTSOAK_SCREEN_CONFIG_ID);	// created separately
		m_pHotSoakScrConfig->SetCMMmode(CONFIG_MODIFIABLE);				// default to 'working'
		m_pHotSoakScrConfig->CreateHotSoakScreenConfig();				// with just a screen config block
		m_pHotSoakScrConfig->m_pOpPanel = this;							// Used in SetTextString
	}
	T_LAYOUTITEM itemRef;
	itemRef.CMM_Type = BLK_SCRTEMPLATE;
	itemRef.CMM_Inst = HOTSOAK_SCREEN_INST;
	BLOCK_INFO blockInfo;
	if (m_pHotSoakScrConfig->indexOfDataBlock(&itemRef, &blockInfo)) // populate the Block_Info
			{
		// found and populated blockinfo OK.
		CTemplate *pTemplate = new CTemplate(this);
		pTemplate->CMMInitTemplate(m_pHotSoakScrConfig, &blockInfo, NEW_INSTANCE);
		// now do screen
		itemRef.CMM_Type = BLK_SCREEN; // modify the type. instance is the same.
		if (m_pHotSoakScrConfig->indexOfDataBlock(&itemRef, &blockInfo)) // populate the Block_Info
				{
			// now create a C++ Screen Object for it.
			m_pHotSoakScreen = new CScreen(this);
			// attach the template created above
			m_pHotSoakScreen->m_pTemplate = pTemplate;
			m_pActiveScreen = m_pHotSoakScreen; // has to be 'active' during init.
			m_pHotSoakScreen->CMMInitScreen(m_pHotSoakScrConfig, &blockInfo, NEW_INSTANCE); // screen and depenedents
			m_pHotSoakScreen->m_DoneInitalDraw = TRUE; // set this here to ensure we get our refreshes
			m_CritSec.Unlock();
			InterlockedDecrement(&m_Inactive);
			Repaint();
			return TRUE;
		}
	}
	m_CritSec.Unlock();
	InterlockedDecrement(&m_Inactive);
	return FALSE;
}
//****************************************************************************
///
/// Refresh the Hot Soak Screen for Hot Soak Test mode 
/// 
/// @param[in] 
///
/// @return none
/// 
//****************************************************************************
void COpPanel::RefreshHotSoakScreen(BOOL ForceUpdate) //=FALSE
		{
	// ensure that objects exist (check for the last one being present)
	if (m_HotSoakObjects[HS_Ship][HS_Message] == NULL)
		return;
	// only check for updates once per second. 
	// Since this function has to cope with displaying status loaded from NV, 
	// it's easier to restrict the updates to 1 per sec and then update everything that can change.
	if (ForceUpdate || (GetTickCount() - m_HotSoakLastTickUpdate < 1000))
		return;
	m_HotSoakLastTickUpdate = GetTickCount();
	if (m_pHotSoakData->IsRunning) {
		// show running state...
		((CTextObject*) m_HotSoakObjects[HS_Running][HS_Message])->SetTextString(L"Running");
		m_HotSoakObjects[HS_Running][HS_Message]->m_pFlashing = &G_TRUE;
		m_HotSoakObjects[HS_Running][HS_Message]->m_UpdateValue = TRUE;
		((CButtonObject*) m_HotSoakObjects[HS_StartStop][HS_Message])->SetTextString(L"STOP");
		m_HotSoakObjects[HS_StartStop][HS_Message]->m_UpdateValue = TRUE;
	} else {
		// clear running state...
		((CTextObject*) m_HotSoakObjects[HS_Running][HS_Message])->SetTextString("");
		m_HotSoakObjects[HS_Running][HS_Message]->m_pFlashing = &G_FALSE;
		m_HotSoakObjects[HS_Running][HS_Message]->m_UpdateValue = TRUE;
		// not running and failed.
		if (m_pHotSoakData->HasFailed) {
			((CButtonObject*) m_HotSoakObjects[HS_StartStop][HS_Message])->SetTextString(L"RESET");
			m_HotSoakObjects[HS_StartStop][HS_Message]->m_UpdateValue = TRUE;
		} else {
			((CButtonObject*) m_HotSoakObjects[HS_StartStop][HS_Message])->SetTextString(L"START");
			m_HotSoakObjects[HS_StartStop][HS_Message]->m_UpdateValue = TRUE;
		}
	}
	if (m_pHotSoakData->IsRunning) {
		// update the elapsed time
		QTime curtime;
		curtime.TimeNow();
		m_pHotSoakData->ElapsedTime += (curtime - m_HotSoakBaseTime);
		m_HotSoakBaseTime = curtime;
		//qDebug("Elapsed time %s\n",m_pHotSoakData->ElapsedTime.TimeToStringShort());
	}
	if (m_pHotSoakData->IsRunning && (m_pHotSoakData->ElapsedTime >= m_pHotSoakData->RunTime)) {
		m_pHotSoakData->HasPassed = TRUE;
		m_pHotSoakData->IsRunning = FALSE;
		WCHAR bufft[50];
		m_HotSoakBaseTime.TimeToStringNoFracs(bufft);
		WCHAR timebuff[20];
		TimeSpanToStringHM(&m_pHotSoakData->ElapsedTime, timebuff);
		m_HotSoakLog.Log(L"TEST PASS : %s after running for %s", bufft, timebuff);
	}
	if ((!m_pHotSoakData->HasFailed) && (!m_pHotSoakData->HasPassed)) {
		// reset pass/fail - white background, no border, no text
		m_HotSoakObjects[HS_PassFail][HS_Message]->m_pCMMbase->BackColour = QString(255, 255, 255); // white 
		((CTextObject*) m_HotSoakObjects[HS_PassFail][HS_Message])->SetTextString("");
		m_HotSoakObjects[HS_PassFail][HS_Message]->m_UpdateValue = TRUE;
	}
	if (m_pHotSoakData->HasFailed) {
		((CTextObject*) m_HotSoakObjects[HS_PassFail][HS_Message])->SetTextString(L"TEST FAIL");
		m_HotSoakObjects[HS_PassFail][HS_Message]->m_pCMMbase->BackColour = QString(255, 0, 0); // red
		m_HotSoakObjects[HS_PassFail][HS_Message]->m_UpdateValue = TRUE;
	}
	if (m_pHotSoakData->HasPassed) {
		((CTextObject*) m_HotSoakObjects[HS_PassFail][HS_Message])->SetTextString(L"TEST PASS");
		m_HotSoakObjects[HS_PassFail][HS_Message]->m_pCMMbase->BackColour = QString(0, 255, 0); // green
		m_HotSoakObjects[HS_PassFail][HS_Message]->m_UpdateValue = TRUE;
	}
	WCHAR timebuff[20];
	TimeSpanToStringHM(&m_pHotSoakData->ElapsedTime, timebuff);
	((CTextObject*) m_HotSoakObjects[HS_Elapsed][HS_Message])->SetTextString(timebuff); // time only
	((CTextObject*) m_HotSoakObjects[HS_Elapsed][HS_Message])->m_UpdateValue = TRUE;
	// run the tests on the channels all the time unless failed or passed 
	if ((!m_pHotSoakData->HasFailed) && (!m_pHotSoakData->HasPassed)) {
		// here change the mode every now and then (finite state machine)
		QTime testtime;
		testtime.TimeNow();
		testtime -= m_HotSoakConfigTime;
		LONGLONG secs = testtime.GetMicroSecs() / 1000000;
		if ((secs > CONFIG_INTERVAL) || (m_HotSoakOp != IDLE)) // every Config Interval or each time when changing
				{
			switch (m_HotSoakOp) {
			case INIT: // at startup 
			{
				if (secs > STARTUP_DELAY) // wait a while before doing the inital test.
				{
					m_HotSoakConfigTime.TimeNow(); // reset timer
					m_HotSoakOp = CONFIG_BOARD;
					if (m_HotSoakTest == TEST_ONE)
						m_HotSoakTest = TEST_TWO;
					else
						m_HotSoakTest = TEST_ONE;
				}
				break;
			}
			case RESET:
			case IDLE: {
				m_HotSoakConfigTime.TimeNow(); // reset timer
				m_HotSoakOp = CONFIG_BOARD;
				if (m_HotSoakTest == TEST_ONE)
					m_HotSoakTest = TEST_TWO;
				else
					m_HotSoakTest = TEST_ONE;
				break;
			}
			case CONFIG_BOARD: {
				// have been through and configured everything
				m_HotSoakConfigChangeComplete = FALSE;
				// lock the status bar - no button presses/menu selections during cmm updates
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance(this);
				pkStatusBar->LockStatusBar(true);
				T_MOD_CFG_CHG_MSGDATA msg;
				msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
				msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
				msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_UPDATE;
				m_pV6Module->SignalConfigChange(sizeof(msg), (BYTE*) &msg);
				qDebug("posted config change....\n");
				m_HotSoakOp = WAIT_FOR_CONFIG;
				break;
			}
			case WAIT_FOR_CONFIG: {
				if (m_HotSoakConfigChangeComplete) {
					qDebug("....config change complete\n");
					// unlock the status bar.
					CTopStatusBar *pkStatusBar = CTopStatusBar::Instance(this);
					pkStatusBar->LockStatusBar(false);
					m_HotSoakConfigTime.TimeNow(); // timer reset here too.
					m_HotSoakOp = TEST_IDLE; // config complete? if so go on to test the boards (soon)
				}
				break;
			}
			case TEST_IDLE: {
				if (secs > TEST_INTERVAL)		// wait a while before doing the test.
					m_HotSoakOp = TEST_BOARD;
				break;
			}
			case TEST_BOARD: {
				m_HotSoakOp = IDLE;
				break;
			}
			default:
				break;
			}
		}
		if ((m_HotSoakOp == CONFIG_BOARD) || (m_HotSoakOp == WAIT_FOR_CONFIG)) {
			if (m_HotSoakObjects[HS_MsgBox][HS_Message]) {
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_pCMMbase->ForeColour = QString(255, 255, 0);		// yellow	
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_pCMMbase->BackColour = 0; //black;
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_pCMMbase->IsAlphaBlend = TRUE;
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_UpdateValue = TRUE;
			}
		} else if (m_HotSoakOp == TEST_IDLE) {
			if (m_HotSoakObjects[HS_MsgBox][HS_Message]) {
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_pCMMbase->ForeColour = QString(255, 255, 255); // white	
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_pCMMbase->BackColour = QString(255, 255, 255); // white	
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_pCMMbase->IsAlphaBlend = FALSE;
				m_HotSoakObjects[HS_MsgBox][HS_Message]->m_UpdateValue = TRUE;
			}
		}
		// 0 to 20 mA ramp - for AO boards
		m_AOlevel += 20;
		if (m_AOlevel >= 100) // AO level 0-100 is 0 to 20 mA
			m_AOlevel = 0;
		CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
		CSlotMap *pSlotMap = CSlotMap::GetHandle();
		// get CJC temp from first AI board fitted (if any) 
		int slotNo = 0;
		for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
			if (m_HotSoakboardsFitted[slotNo]) {
				if ((pBrdInfo->WhatBoardType(slotNo) == BOARD_AI) || (pBrdInfo->WhatBoardType(slotNo) == BOARD_EZ_AI)) {
					USHORT CJCNo;
					USHORT CJCDegCNo;
					if (pSlotMap->ObtainBoardsDICJCRef(slotNo, &CJCNo, &CJCDegCNo) == TRUE) {
						CDataItem *pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCDegCNo); // get Deg C
						if (pDataItem != NULL) {
							float val = pDataItem->GetFPValue();
							val = (float) (9.0 * val / 5.0) + 32; // convert to fahrenheit for Bob
							if (val > m_pHotSoakData->MaxDegF)
								m_pHotSoakData->MaxDegF = val;
							if ((val < m_pHotSoakData->MinDegF) || (m_pHotSoakData->MinDegF == 0.0))
								m_pHotSoakData->MinDegF = val;
							break; // breakout after first successful CJC reading
						}
					}
				}
			}
		}
		BOOL allBoardsOK = TRUE; // check all boards - they must all pass.
		for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
			if (m_HotSoakboardsFitted[slotNo]) {
				// this slot is populated.
				BOOL boardOK = TRUE;
				switch (pBrdInfo->WhatBoardType(slotNo)) {
				case BOARD_AI:
				case BOARD_EZ_AI:
					boardOK = TestAnalogueInBoard(slotNo);
					break;
				case BOARD_AO:
					boardOK = TestAnalogueOutBoard(slotNo);
					break;
				case BOARD_DIO:
					boardOK = TestDigitalIOBoard(slotNo);
					break;
				case BOARD_AR:
					boardOK = TestRelayBoard(slotNo);
					break;
				case BOARD_PI:
					boardOK = TestPulseBoard(slotNo);
					break;
				default:
					break;
				};
				allBoardsOK &= boardOK;
			} else
				m_pHotSoakData->SlotStatus[slotNo] = HS_NOT_FITTED;
		}
		// done a test of all boards - there may be multiple failures
		if (!allBoardsOK && m_pHotSoakData->IsRunning) {
			// Only if there is a failure when IsRunning do we want to flag the error and fail the test.
			m_pHotSoakData->IsRunning = FALSE;
			m_pHotSoakData->HasFailed = TRUE;
			WCHAR bufft[50];
			m_HotSoakBaseTime.TimeToStringNoFracs(bufft);
			WCHAR timebuff[20];
			TimeSpanToStringHM(&m_pHotSoakData->ElapsedTime, timebuff);
			m_HotSoakLog.Log(L"TEST FAILED : %s after running for %s", bufft, timebuff);
		}
		// in addition here, do the SD test, or test front USB for Eztrend
		BOOL boardOK = TestCFCardOrUSB(pDALGLB->IsRecorderEzTrend());
		if (!boardOK && m_pHotSoakData->IsRunning) {
			// Only if there is a failure when IsRunning do we want to flag the error and fail the test.
			m_pHotSoakData->IsRunning = FALSE;
			m_pHotSoakData->HasFailed = TRUE;
			WCHAR bufft[50];
			m_HotSoakBaseTime.TimeToStringNoFracs(bufft);
			WCHAR timebuff[20];
			TimeSpanToStringHM(&m_pHotSoakData->ElapsedTime, timebuff);
			m_HotSoakLog.Log(L"TEST FAILED : %s after running for %s", bufft, timebuff);
		}
	}
	// Always show the current slot status (also saved to NV)
	for (int slotNo = 0; slotNo < MAXIOCARDS + 1; slotNo++) // +1 for CF card
			{
		if (m_HotSoakObjects[slotNo][HS_LED]) {
			// this slot has an LED object set up so it is populated and not AO card
			if (m_pHotSoakData->SlotStatus[slotNo] == HS_OK) {
				// set LED green 
				m_HotSoakObjects[slotNo][HS_LED]->m_pCMMbase->BackColour = QString(0, 255, 0); // green
				((CTextObject*) m_HotSoakObjects[slotNo][HS_Message])->SetTextString(L"Good");
				m_HotSoakObjects[slotNo][HS_LED]->m_UpdateValue = TRUE;
				m_HotSoakObjects[slotNo][HS_Message]->m_UpdateValue = TRUE;
			} else if (m_pHotSoakData->SlotStatus[slotNo] == HS_FAILED) {
				m_HotSoakObjects[slotNo][HS_LED]->m_pCMMbase->BackColour = QString(255, 0, 0); // red
				((CTextObject*) m_HotSoakObjects[slotNo][HS_Message])->SetTextString(L"Bad");
				m_HotSoakObjects[slotNo][HS_LED]->m_UpdateValue = TRUE;
				m_HotSoakObjects[slotNo][HS_Message]->m_UpdateValue = TRUE;
			} else // unknown
			{
				m_HotSoakObjects[slotNo][HS_LED]->m_pCMMbase->BackColour = QString(0, 0, 0); // black
				((CTextObject*) m_HotSoakObjects[slotNo][HS_Message])->SetTextString(L"Unknown");
				m_HotSoakObjects[slotNo][HS_LED]->m_UpdateValue = TRUE;
				m_HotSoakObjects[slotNo][HS_Message]->m_UpdateValue = TRUE;
			}
		}
	}
	// and display the CJC max and min
	WCHAR cjcbuff[50];
	if (m_pHotSoakData->MaxDegF == 0.0)
#if _MSC_VER < 1400 
		swprintf(cjcbuff, L"Max ----", m_pHotSoakData->MaxDegF);
#else
		swprintf(cjcbuff, sizeof(cjcbuff)/sizeof(WCHAR), L"Max ----",m_pHotSoakData->MaxDegF);	
#endif
	else
#if _MSC_VER < 1400 
		swprintf(cjcbuff, L"Max %.1f", m_pHotSoakData->MaxDegF);
#else
		swprintf(cjcbuff, sizeof(cjcbuff)/sizeof(WCHAR), L"Max %.1f",m_pHotSoakData->MaxDegF);	
#endif
	((CTextObject*) m_HotSoakObjects[HS_CJCMax][HS_Message])->SetTextString(cjcbuff);
	((CTextObject*) m_HotSoakObjects[HS_CJCMax][HS_Message])->m_UpdateValue = TRUE;
	if (m_pHotSoakData->MinDegF == 0.0)
#if _MSC_VER < 1400 
		swprintf(cjcbuff, L"Min ----", m_pHotSoakData->MinDegF);
#else
		swprintf(cjcbuff, sizeof(cjcbuff)/sizeof(WCHAR), L"Min ----",m_pHotSoakData->MinDegF);	
#endif
	else
#if _MSC_VER < 1400 
		swprintf(cjcbuff, L"Min %.1f", m_pHotSoakData->MinDegF);
#else
		swprintf(cjcbuff, sizeof(cjcbuff)/sizeof(WCHAR), L"Min %.1f",m_pHotSoakData->MinDegF);		
#endif
	((CTextObject*) m_HotSoakObjects[HS_CJCMin][HS_Message])->SetTextString(cjcbuff);
	((CTextObject*) m_HotSoakObjects[HS_CJCMin][HS_Message])->m_UpdateValue = TRUE;
}
//****************************************************************************
///
/// Test an AI board
/// 
/// @param[in] slotNo - the slot number
///
/// @return T/F - result of test - TRUE is ok!
/// 
//****************************************************************************
BOOL COpPanel::TestAnalogueInBoard(int slotNo) {
	CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	CSlotMap *pSlotMap = CSlotMap::GetHandle();
	BOOL result = TRUE;
	// test here when IDLE or TEST_BOARD set.
	if ((m_HotSoakOp != IDLE) && (m_HotSoakOp != TEST_BOARD))
		return result;
	USHORT numChan = pBrdInfo->GetNoOfChannels(slotNo);
	for (int inst = 0; inst < numChan; inst++) {
		// check the data for this input.
		UCHAR sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel(slotNo, inst, ZERO_BASED);
		CDataItem *pdi = m_pDIT->GetDataItemPtr(DI_IO, 0, sysChanNo);
		float val = pdi->GetFPValue();
		if ((val > 105) || (val < 95)) {
			// not within 5% of 100 ohms.
			qDebug("AI failed - slot %d channel %d (pen %d reading %3.2f)\n", slotNo + 1, inst + 1, sysChanNo + 1, val);
			if (m_pHotSoakData->IsRunning)
				m_HotSoakLog.Log(L"AI failed - slot %d channel %d (pen %d reading %3.2f)", slotNo + 1, inst + 1,
						sysChanNo + 1, val);
			result = FALSE;
		}
	}
	// set the status of our slot here.
	if (result == FALSE)
		m_pHotSoakData->SlotStatus[slotNo] = HS_FAILED;
	else
		m_pHotSoakData->SlotStatus[slotNo] = HS_OK;
	return result;
}
#define HOTSOAKDELAY 2500
//****************************************************************************
///
/// Test an IO board
/// 
/// @param[in] slotNo - the slot number
///
/// @return T/F - result of test - TRUE is ok!
/// 
//****************************************************************************
BOOL COpPanel::TestDigitalIOBoard(int slotNo) {
	CIOSetupConfig *pIOSetupCfg = pSETUP->GetIOSetupConfig();
	CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	CSlotMap *pSlotMap = CSlotMap::GetHandle();
	USHORT numChan = pBrdInfo->GetNoOfChannels(slotNo);
	BOOL result = TRUE;
	// allow through to configure or test only.
	if ((m_HotSoakOp != CONFIG_BOARD) && (m_HotSoakOp != TEST_BOARD))
		return result;
	if (m_HotSoakTest == TEST_ONE) {
		if (m_HotSoakOp == CONFIG_BOARD) {
			qDebug("Digital IO board CONFIG FOR TEST ONE\n");
			// numChan could be 8 or 16.
			for (int inst = 0; inst < numChan; inst++) {
				T_PDIGCHANNEL pDigitalConfig = pIOSetupCfg->GetDigital(slotNo, inst, CONFIG_MODIFIABLE);
				if (pDigitalConfig) {
					pDigitalConfig->Enabled = 1;
					if ((inst < 4) || ((inst > 7) && (inst < 12)))
						pDigitalConfig->Type = 1; // output					
					else
						pDigitalConfig->Type = 0; // input					
				}
			}
		} else if (m_HotSoakOp == TEST_BOARD) {
			qDebug("Digital IO board TESTING - TEST ONE\n");
			// first Open them and check the result is correct.
			// numChan could be 8 or 16.
			int inst = 0;
			for (inst = 0; inst < numChan; inst++) {
				if ((inst < 4) || ((inst > 7) && (inst < 12))) {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL) {
						if (inst == 0) // trace the first relay
								{
							int valcurr = (int) pDataItem->GetFPValue();
							qDebug("val was %d, setting to 0\n", valcurr);
						}
						pDataItem->SetValue(0); // open - default state - check inputs come back as 0
					}
				}
			}
			sleep(HOTSOAKDELAY); // delay before reading
			qDebug("IO READING INPUTS (Should be 0): ");
			for (inst = 0; inst < numChan; inst++) {
				if ((inst < 4) || ((inst > 7) && (inst < 12)))
					;
				else {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL) {
						int val = (int) pDataItem->GetFPValue();
						qDebug("%d=%d ", inst, val);
						if (val != 0) {
							if (m_pHotSoakData->IsRunning)
								m_HotSoakLog.Log(L"IO failed - slot %d channel %d", slotNo + 1, inst + 1);
							result = FALSE;
						}
					}
				}
			}
			qDebug("\n");
			// now close them all and check the result is correct.
			// numChan could be 8 or 16.
			for (inst = 0; inst < numChan; inst++) {
				if ((inst < 4) || ((inst > 7) && (inst < 12))) {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL) {
						if (inst == 0) // trace the first relay
								{
							int valcurr = (int) pDataItem->GetFPValue();
							qDebug("val was %d, setting to 1\n", valcurr);
						}
						pDataItem->SetValue(1); // closed - (LED on) - check inputs come back as 1
					}
				}
			}
			sleep(HOTSOAKDELAY); // delay before reading
			qDebug("IO READING INPUTS (should be 1): ");
			for (inst = 0; inst < numChan; inst++) {
				if ((inst < 4) || ((inst > 7) && (inst < 12)))
					;
				else {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL) {
						int val = (int) pDataItem->GetFPValue();
						qDebug("%d=%d ", inst, val);
						if (val != 1) {
							if (m_pHotSoakData->IsRunning)
								m_HotSoakLog.Log(L"IO failed - slot %d channel %d", slotNo + 1, inst + 1);
							result = FALSE;
						}
					}
				}
			}
			qDebug("\n");
		}
	} else if (m_HotSoakTest == TEST_TWO) {
		if (m_HotSoakOp == CONFIG_BOARD) {
			qDebug("Digital IO board CONFIG FOR TEST TWO\n");
			// numChan could be 8 or 16.
			for (int inst = 0; inst < numChan; inst++) {
				T_PDIGCHANNEL pDigitalConfig = pIOSetupCfg->GetDigital(slotNo, inst, CONFIG_MODIFIABLE);
				if (pDigitalConfig) {
					if ((inst < 4) || ((inst > 7) && (inst < 12)))
						pDigitalConfig->Type = 0; // Input
					else
						pDigitalConfig->Type = 1; // output
				}
			}
		} else if (m_HotSoakOp == TEST_BOARD) {
			qDebug("Digital IO board TESTING - TEST TWO\n");
			// first Open them and check the result is correct.
			// numChan could be 8 or 16.
			int inst = 0;
			for (inst = 0; inst < numChan; inst++) {
				if (((inst > 3) && (inst < 8)) || (inst > 11)) {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL)
						pDataItem->SetValue(0); // open - default state - check inputs come back as 0
				}
			}
			sleep(HOTSOAKDELAY); // delay before reading
			qDebug("IO READING INPUTS (Should be 0): ");
			for (inst = 0; inst < numChan; inst++) {
				if (((inst > 3) && (inst < 8)) || (inst > 11))
					;
				else {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL) {
						int val = (int) pDataItem->GetFPValue();
						qDebug("%d=%d ", inst, val);
						if (val != 0) {
							if (m_pHotSoakData->IsRunning)
								m_HotSoakLog.Log(L"IO failed - slot %d channel %d", slotNo + 1, inst + 1);
							result = FALSE;
						}
					}
				}
			}
			qDebug("\n");
			// now close them all and check the result is correct.
			// numChan could be 8 or 16.
			for (inst = 0; inst < numChan; inst++) {
				if (((inst > 3) && (inst < 8)) || (inst > 11)) {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL)
						pDataItem->SetValue(1); // closed - (LED on) - check inputs come back as 1
				}
			}
			sleep(HOTSOAKDELAY); // delay before reading
			qDebug("IO READING INPUTS (should be 1): ");
			for (inst = 0; inst < numChan; inst++) {
				if (((inst > 3) && (inst < 8)) || (inst > 11))
					;
				else {
					UCHAR sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
					CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo);
					if (pDataItem != NULL) {
						int val = (int) pDataItem->GetFPValue();
						qDebug("%d=%d ", inst, val);
						if (val != 1) {
							if (m_pHotSoakData->IsRunning)
								m_HotSoakLog.Log(L"IO failed - slot %d channel %d", slotNo + 1, inst + 1);
							result = FALSE;
						}
					}
				}
			}
			qDebug("\n");
		}
	}
	// set the status of our slot here (after tests NOT config)
	if (m_HotSoakOp == TEST_BOARD) {
		if (result == FALSE)
			m_pHotSoakData->SlotStatus[slotNo] = HS_FAILED;
		else
			m_pHotSoakData->SlotStatus[slotNo] = HS_OK;
	}
	return result;
}
//****************************************************************************
///
/// Test an AO board
/// 
/// @param[in] slotNo - the slot number
///
/// @return T/F - result of test - TRUE is ok!
/// 
//****************************************************************************
BOOL COpPanel::TestAnalogueOutBoard(int slotNo) {
	CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	CSlotMap *pSlotMap = CSlotMap::GetHandle();
	USHORT numChan = pBrdInfo->GetNoOfChannels(slotNo);
	UCHAR retransmitPen = pSlotMap->GetSysChannelFromAnaOutChannel(slotNo, 0, ZERO_BASED);
	if (m_HotSoakOp == CONFIG_BOARD) {
		// retransmit pen config
		/*
		 // set up the pen scale
		 CPenSetupConfig *pPenCfg=pSETUP->GetPenSetupConfig();
		 T_PPEN pPen=pPenCfg->GetPen(retransmitPen,ZERO_BASED,CONFIG_MODIFIABLE); 
		 
		 if(pPen)
		 {
		 pPen->Enabled=1;
		 pPen->Scale.Zero=0;
		 pPen->Scale.Span=20;
		 }
		 */
		// set up the AO outputs to ALL be retransmitted from retransmitPen
		// instead now, set up with the pen of that AO channel
		CIOSetupConfig *pIOSetupCfg = pSETUP->GetIOSetupConfig();
		for (int inst = 0; inst < numChan; inst++) {
			T_PAOCHANNEL pAOChannelConfig = pIOSetupCfg->GetAnalogueOutput(slotNo, inst, CONFIG_MODIFIABLE);
			if (pAOChannelConfig) {
				pAOChannelConfig->Enabled = 1;
				//pAOChannelConfig->PenNo=retransmitPen; 
				retransmitPen = pSlotMap->GetSysChannelFromAnaOutChannel(slotNo, inst, ZERO_BASED);
				pAOChannelConfig->PenNo = retransmitPen;
				pAOChannelConfig->ZeroOutput = 1; //0-20
			}
		}
	} else if ((m_HotSoakOp == IDLE) || (m_HotSoakOp == TEST_BOARD)) // rest of the time, output the ramp
			{
		// retransmitting all from retransmitPen
		for (int inst = 0; inst < numChan; inst++) {
			UCHAR retransmitPen = pSlotMap->GetSysChannelFromAnaOutChannel(slotNo, inst, ZERO_BASED);
			CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, retransmitPen);
			if (pDataItem != NULL) {
				pDataItem->SetValue(m_AOlevel);
				pDataItem->SetStatus(DISTAT_NORMAL); // need to set the status here for it to work
			}
		}
	}
	return TRUE; // always TRUE for AO board (check LED's)
}
//****************************************************************************
///
/// Test an AR board
/// 
/// @param[in] slotNo - the slot number
///
/// @return T/F - result of test - TRUE is ok!
/// 
//****************************************************************************
BOOL COpPanel::TestRelayBoard(int slotNo) {
	CIOSetupConfig *pIOSetupCfg = pSETUP->GetIOSetupConfig();
	CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	CSlotMap *pSlotMap = CSlotMap::GetHandle();
	USHORT numChan = pBrdInfo->GetNoOfChannels(slotNo);
	BOOL result = TRUE;
	if ((m_HotSoakOp != CONFIG_BOARD) && (m_HotSoakOp != TEST_BOARD) && (m_HotSoakOp != IDLE)) // allow idle for doing relays in turn below (test1)
		return result;
	if (m_HotSoakTest == TEST_ONE) {
		if (m_HotSoakOp == CONFIG_BOARD) {
			qDebug("Alarm Board CONFIG FOR TEST ONE\n");
			// test relays 1-7 (or 1-4) with digital 8 as an input
			// endChanNo could be 4 or 8 
			for (int inst = 0; inst < 7; inst++) // 0 to 6
					{
				T_PDIGCHANNEL pDigitalConfig = pIOSetupCfg->GetDigital(slotNo, inst, CONFIG_MODIFIABLE);
				if (pDigitalConfig) {
					pDigitalConfig->Enabled = 1;
					pDigitalConfig->Type = 1; // output
				}
			}
			// and number 8 as an input
			T_PDIGCHANNEL pDigitalConfig = pIOSetupCfg->GetDigital(slotNo, 7, CONFIG_MODIFIABLE); //8
			if (pDigitalConfig) {
				pDigitalConfig->Enabled = 1;
				pDigitalConfig->Type = 0; // input
			}
		} else if (m_HotSoakOp == TEST_BOARD) {
			qDebug("Alarm Board TESTING - TEST ONE\n");
			// first Open them all and check the result is correct.
			for (int inst = 0; inst < 7; inst++) // 0 to 6
					{
				UCHAR sysChanNoRelay = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, inst, ZERO_BASED);
				CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoRelay);
				if (pDataItem != NULL)
					pDataItem->SetValue(0); // open - default state - check input comes back as 0				
			}
			sleep(HOTSOAKDELAY); // delay before reading
			qDebug("AR READING INPUT 8 (Should be 0): ");
			UCHAR sysChanNoInput = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, 7, ZERO_BASED); //8
			CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoInput);
			if (pDataItem != NULL) {
				int val = (int) pDataItem->GetFPValue();
				qDebug("%d", val);
				if (val != 0) {
					if (m_pHotSoakData->IsRunning)
						m_HotSoakLog.Log(L"AR failed - slot %d", slotNo + 1);
					result = FALSE;
				}
			}
			qDebug("\n");
			// now close them in turn and check the result is correct.
			// NB set it up here and test one on each iteration when IDLE
			m_HotSoakCounter[slotNo] = 0;
		} else if (m_HotSoakOp == IDLE) {
			if ((m_HotSoakCounter[slotNo] < numChan) && (m_HotSoakCounter[slotNo] < 7)) {
				qDebug("AR Testing relay %d\n", m_HotSoakCounter[slotNo] + 1);
				UCHAR sysChanNoRelay = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, m_HotSoakCounter[slotNo],
						ZERO_BASED);
				CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoRelay);
				if (pDataItem != NULL)
					pDataItem->SetValue(1); // closed - (LED on) - check input comes back as 1		
				sleep(HOTSOAKDELAY); // delay before reading
				qDebug("READING INPUT 8 (should be 1): ");
				UCHAR sysChanNoInput = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, 7, ZERO_BASED); // 8
				pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoInput);
				if (pDataItem != NULL) {
					int val = (int) pDataItem->GetFPValue();
					qDebug("%d=%d", m_HotSoakCounter[slotNo], val);
					if (val != 1) {
						if (m_pHotSoakData->IsRunning)
							m_HotSoakLog.Log(L"AR failed - slot %d channel %d", slotNo + 1,
									m_HotSoakCounter[slotNo] + 1);
						result = FALSE;
					}
				}
				qDebug("\n");
				// now open it again.
				pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoRelay);
				if (pDataItem != NULL)
					pDataItem->SetValue(0); // open - default state 
				m_HotSoakCounter[slotNo]++;
			} else
				return result;
		}
	} else if (m_HotSoakTest == TEST_TWO) {
		if (numChan == 4)
			return result; // no test 2 for 4 channel card
		if (m_HotSoakOp == CONFIG_BOARD) {
			qDebug("Alarm Board CONFIG FOR TEST TWO\n");
			//change the input to channel 7 and test the relay on channel 8
			// number 7 as an input
			T_PDIGCHANNEL pDigitalConfig = pIOSetupCfg->GetDigital(slotNo, 6, CONFIG_MODIFIABLE); // 7
			if (pDigitalConfig) {
				pDigitalConfig->Enabled = 1;
				pDigitalConfig->Type = 0; // input
			}
			// number 8 as an output
			pDigitalConfig = pIOSetupCfg->GetDigital(slotNo, 7, CONFIG_MODIFIABLE); // 8
			if (pDigitalConfig) {
				pDigitalConfig->Enabled = 1;
				pDigitalConfig->Type = 1; // output
			}
		} else if (m_HotSoakOp == TEST_BOARD) {
			qDebug("Alarm Board TESTING - TEST TWO\n");
			// here 8 is output, and 7 is input.	
			UCHAR sysChanNoRelay = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, 7, ZERO_BASED); //8
			CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoRelay);
			if (pDataItem != NULL)
				pDataItem->SetValue(0); // open 8 - default state - check input comes back as 0				
			sleep(HOTSOAKDELAY); // delay before reading
			qDebug("AR READING INPUT 7 (Should be 0): ");
			UCHAR sysChanNoInput = pSlotMap->GetSysChannelFromDigIOChannel(slotNo, 6, ZERO_BASED); //7
			pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoInput);
			if (pDataItem != NULL) {
				int val = (int) pDataItem->GetFPValue();
				qDebug("%d", val);
				if (val != 0) {
					if (m_pHotSoakData->IsRunning)
						m_HotSoakLog.Log(L"AR failed - slot %d", slotNo + 1);
					result = FALSE;
				}
			}
			qDebug("\n");
			// now close it again.
			pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoRelay);
			if (pDataItem != NULL)
				pDataItem->SetValue(1); // closed - (LED on) - check input comes back as 1		
			sleep(HOTSOAKDELAY); // delay before reading
			qDebug("AR READING INPUT 7 (should be 1): ");
			pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoInput);
			if (pDataItem != NULL) {
				int val = (int) pDataItem->GetFPValue();
				qDebug("%d", val);
				if (val != 1) {
					if (m_pHotSoakData->IsRunning)
						m_HotSoakLog.Log(L"AR failed - slot %d", slotNo + 1);
					result = FALSE;
				}
			}
			qDebug("\n");
			// now open it again.
			pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNoRelay);
			if (pDataItem != NULL)
				pDataItem->SetValue(0); // open - default state 
		}
	}
	if (m_HotSoakOp != CONFIG_BOARD) {
		// set the status of our slot here (when testing or idle)
		if (result == FALSE)
			m_pHotSoakData->SlotStatus[slotNo] = HS_FAILED;
		else
			m_pHotSoakData->SlotStatus[slotNo] = HS_OK;
	}
	return result;
}
//****************************************************************************
///
/// Test a PI board
/// 
/// @param[in] slotNo - the slot number
///
/// @return T/F - result of test - TRUE is ok!
/// 
//****************************************************************************
BOOL COpPanel::TestPulseBoard(int slotNo) {
	CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	CSlotMap *pSlotMap = CSlotMap::GetHandle();
	USHORT numChan = pBrdInfo->GetNoOfChannels(slotNo);
	BOOL result = TRUE;
	if (m_HotSoakOp == CONFIG_BOARD) {
		qDebug("Pulse Board CONFIG\n");
		CIOSetupConfig *pIOSetupCfg = pSETUP->GetIOSetupConfig();
		for (int inst = 0; inst < numChan; inst++) {
			T_PPULSECHANNEL pPulseConfig = pIOSetupCfg->GetPulseInput(slotNo, inst, CONFIG_MODIFIABLE);
			if (pPulseConfig) {
				pPulseConfig->Enabled = 1;
				pPulseConfig->FreqMeasure = 0; // measure frequency
			}
		}
	} else if ((m_HotSoakOp == IDLE) || (m_HotSoakOp == TEST_BOARD)) // rest of the time, check the freq is between 8 and 12 Khz
			{
		int testval = 9000; // mid point 9000Hz
		int lastval = 0;
		for (int inst = 0; inst < numChan; inst++) {
			UCHAR sysChanNo = pSlotMap->GetSysChannelFromDedicatedPulseChannel(slotNo, inst, ZERO_BASED);
			CDataItem *pDataItem = m_pDIT->GetDataItemPtr(DI_IO, DI_IO_HIPULSE, sysChanNo);
			if (pDataItem != NULL) {
				int val = (int) pDataItem->GetFPValue();
				if (abs(testval - val) > 5000) // test 4000Hz to 14000Hz - very accurate!
						{
					qDebug("%d=%d \n", inst, val);
					if (m_pHotSoakData->IsRunning)
						m_HotSoakLog.Log(L"PI failed freq check - slot %d channel %d", slotNo + 1, inst + 1);
					result = FALSE;
				}
				if (inst > 0) {
					if (abs(val - lastval) > 10) // check within 10 counts
							{
						if (m_pHotSoakData->IsRunning)
							m_HotSoakLog.Log(L"PI failed count difference - slot %d channel %d", slotNo + 1, inst + 1);
						result = FALSE;
					}
				}
				lastval = val; // save for next test
			}
		}
		// set the status of our slot here.
		if (result == FALSE)
			m_pHotSoakData->SlotStatus[slotNo] = HS_FAILED;
		else
			m_pHotSoakData->SlotStatus[slotNo] = HS_OK;
	}
	return result;
}
//****************************************************************************
///
/// Test the front CF card or USB for Eztrend
/// 
/// @param[in] IsEztrend - test USB for Eztrend
///
/// @return T/F - result of test - TRUE is ok!
/// 
//****************************************************************************
BOOL COpPanel::TestCFCardOrUSB(BOOL IsEztrend) {
	BOOL result = TRUE;
	if ((m_HotSoakOp != IDLE) && (m_HotSoakOp != TEST_BOARD)) // not really required for CF test, but it brings it in line with others.
		return result;
	WCHAR tempbuff1[100];
	WCHAR tempbuff2[100];
	m_HotSoakCounter[MAXIOCARDS]++;
	swprintf(tempbuff1, L"This is a test message logged to the front CF card or USB. Message number: %d",
			m_HotSoakCounter[MAXIOCARDS]);
	memset(tempbuff2, 0, sizeof(tempbuff2));
	int len = (int) wcslen(tempbuff1) * 2; // length convert to bytes 
	CSimpleLog *testcf;
	if (IsEztrend)
		testcf = new CSimpleLog(IDS_FIRST_USB); // USB1 
	else
		testcf = new CSimpleLog(IDS_EXTERNAL_SD); // external CF
	result = testcf->SetLogging(L"Test.txt");
	if (result)
		result = testcf->LogLine(tempbuff1);
	delete testcf;
	if (result) {
		if (IsEztrend)
			testcf = new CSimpleLog(IDS_FIRST_USB); // USB1 
		else
			testcf = new CSimpleLog(IDS_EXTERNAL_SD);
		result = testcf->SetLogging(L"Test.txt", TRUE); // TRUE= do not truncate		
		testcf->ReadLine(tempbuff2, len);
		// null terminate buffer.
		tempbuff2[len / 2] = 0;
		delete testcf;
	}
	if (result)
		result = (memcmp(tempbuff1, tempbuff2, len) == 0); // now compare (should be the same!)
	// set the status of our slot here.
	if (result == FALSE) {
		if (m_pHotSoakData->IsRunning)
			m_HotSoakLog.LogLine(L"CF/USB test failed");
		m_pHotSoakData->SlotStatus[MAXIOCARDS] = HS_FAILED;  // MAXIOCARDS for CF card
	} else
		m_pHotSoakData->SlotStatus[MAXIOCARDS] = HS_OK;
	return result;
}
BOOL toggle = FALSE;
//****************************************************************************
///
/// Process the Soft button presses 
/// 
/// @param[in] 
///
/// @return none
/// 
//****************************************************************************
void COpPanel::ProcessSoftButton(int ButtonID, int ScreenNumber) // button ID and screen number
		{
	if (ScreenNumber == HOTSOAK_SCREEN_NUMBER) {
		// specifically for Hot Soak Screen.
		if (ButtonID == SB_STARTSTOP) {
			if (m_pHotSoakData->IsRunning) // 'STOP'
			{
				m_pHotSoakData->IsRunning = FALSE;
				m_HotSoakLog.LogLine(L"Test Stopped");
			} else // not running
			{
				m_HotSoakBaseTime.TimeNow(); // update the basetime here
				if (m_pHotSoakData->HasFailed == TRUE) // 'RESET' button operation here.	
				{
					qDebug("-= RESET =-\n");
					for (int slot = 0; slot < MAXIOCARDS + 1; slot++) // +1 is for CF card
						m_pHotSoakData->SlotStatus[slot] = HS_UNKNOWN;
				} else //'START'
				{
					m_pHotSoakData->IsRunning = TRUE;
					WCHAR bufft[50];
					m_HotSoakBaseTime.TimeToStringNoFracs(bufft);
					m_HotSoakLog.Log(L"Test started running %s", bufft);
				}
				// on a change to running or reset, reset everything
				m_HotSoakOp = RESET; // set back to do a config change straight away and then a test.
				m_HotSoakConfigTime.TimeNow();
				m_pHotSoakData->HasFailed = FALSE;
				m_pHotSoakData->HasPassed = FALSE;
				m_pHotSoakData->ElapsedTime.SetTimeSpan(0, 0, 0); // reset to zero here
				m_pHotSoakData->RunTime.SetTimeSpan(12, 0, 0); // was 48 hours less 5 (for Bob Faria) i.e. 43, now 33, Change to 12 Hrs
				m_pHotSoakData->MaxDegF = 0.0;
				m_pHotSoakData->MinDegF = 0.0;
			}
			RefreshHotSoakScreen(TRUE);	// and update		
		}
		if (ButtonID == SB_SHIPPING) {
			// Build standard path for keyfile
			QString strFunctionKey;
			if (pDALGLB->IsRecorderEzTrend() == TRUE)
				strFunctionKey = QString::asprintf("%skeys", pDALGLB->GetVolumeName(SD_INTERNAL_SD, NULL, 0));
			else
				strFunctionKey = QString::asprintf("%skeys", pDALGLB->GetVolumeName(SD_EXTERNAL_SD, NULL, 0));
			// ensure keys directory exists on SD.
			CreateDirectory(strFunctionKey, NULL);
			// Add exit hot soak mode key
			strFunctionKey += L"\\exithotsoak.key";
			CStorage storage;
			if (storage.Open(strFunctionKey, QFile::WriteOnly | ) == TRUE)
				storage.Close();
			m_HotSoakLog.LogLine(L"Prepare to Ship button pressed");
			// now force a reboot.
			pDALGLB->SetShutDownMode(SHUTDOWN_MODE_RESET);
			// trigger a restart
			LPARAM lRebootParam = static_cast<LPARAM>(CTopStatusBar::slpREBOOT_PENDING);
			lRebootParam |= static_cast<LPARAM>(CTopStatusBar::slpTRIGGER_RESTART);
			// post the message to the top status bar
			::PostMessage(CTopStatusBar::Instance()->m_hWnd, WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_LOCK, lRebootParam);
		}
	} else {
		// general custom screen buttons..
		// post the message to the top status bar
		::PostMessage(CTopStatusBar::Instance()->m_hWnd, WM_OPPANEL_SOFT_BTN_CLICK, ButtonID, ScreenNumber);
	}
}
#endif
#endif
//****************************************************************************
///
/// Sets up a dummy screen so that a Template can be viewed on the OpPanel
///	For use in Screen Designer. 
/// 
/// @param[in] templateRef	- details of template to display
///
/// @return TRUE if set OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::ShowTemplate(T_LAYOUTITEM *templateRef) {
	T_LAYOUTITEM screenRef;
	screenRef.CMM_Type = BLK_SCREEN;
	screenRef.CMM_Inst = TEMPLATE_SCREEN_INST;
	CTemplate *pTemplate = indexOfTemplateInstance(templateRef);
	if (pTemplate) {
		// found template class instance, check if we already have the template being shown by the special template screen.
//		m_pCMMlayout->CurScrnOrTplt=*templateRef; //save the current template as current screen
		// if we are already showing a template as a screen (and it'a not this template) delete it all
		CScreen *pScrT = indexOfScreenInstance(&screenRef);
		if (pScrT) {
			// we do have the special template screen already configured. Is it for this template?
			if (pScrT->m_pTemplate == pTemplate) {
				// yes, it's already set for this template, so set the current screen to our special screen and all done.
				SetCurrentScreen(TEMPLATE_SCREEN_NUMBER);
				return TRUE;
			}
			// otherwise, it's not for this template, so we delete it and rebuild it afresh below..
			RemoveScreen(pScrT);		// remove from list
			pScrT->Destroy();	// will remove everything below each screen (widgets and Objects)
			delete pScrT;		// then delete the CScreen object.
		}
		// so now create the CScreen Object (and Widgets and Objects) 
		// that are on the template in the CMM
		BLOCK_INFO blockInfo;
		if (m_pTptScrConfig->indexOfDataBlock(&screenRef, &blockInfo)) // NB: different configuration
				{
			// now create a C++ Screen Object for it.
			CScreen *pScreen = new CScreen(this);
			//attach the template...
			pScreen->m_pTemplate = pTemplate;
			m_pActiveScreen = pScreen;
			pScreen->CMMInitScreen(m_pMainConfig, &blockInfo, NEW_INSTANCE); // screen and depenedents
			AppendScreen(pScreen);
			SetCurrentScreen(TEMPLATE_SCREEN_NUMBER);
			return TRUE;
		}
	}
	return FALSE;
}
//****************************************************************************
///
/// Sets the Active (visible) Screen for the OpPanel 
/// 
/// @param[in] screenRef	- details of screen to display
///
/// @return TRUE if set OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::SetCurrentScreen(T_LAYOUTITEM *screenRef) {
	CScreen *pScreen = indexOfScreenInstance(screenRef);
	if (pScreen) {
		m_pActiveScreen = pScreen;
		m_pActiveScreen->ConfigChange(); // ensure it's up to date
		Repaint();
		return TRUE;
	} else
		return FALSE;
}
//****************************************************************************
///
/// Sets the Active (visible) Screen for the OpPanel 
/// 
/// @param[in] ScreenNumber - number of screen to show (0=next -1=previous)
///
/// @return TRUE if set OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::SetCurrentScreen(int ScreenNumber) {
//qDebug("+++++ CHANGING SCREEN HERE +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
#ifndef DOCVIEW
#ifndef V6IOTEST
	// Hot soak Test mode?
	if (pSYSTEM_INFO->IsInHotSoakTestMode()) {
		if (!m_pHotSoakScreen)
			ShowHotSoakScreen();
		else
			m_pActiveScreen = m_pHotSoakScreen;
		m_CurrentScreenNumber = HOTSOAK_SCREEN_NUMBER;
		Repaint();
		// in Hot soak Test mode - no option - only get the Hot Soak process screen.
	} else
#endif
#endif
	{
		// not in Hot soak Test mode
		CScreen *pPrevScreen = m_pActiveScreen;
		BOOL bHidePrevNonProcessScreen = FALSE;
#ifndef V6IOTEST
		if (ScreenNumber == 0) {
			// select the next screen in the list...
			if (!m_pActiveScreen) // if null, make it first in list
			{
				if (m_pScreens == NULL) // no screens.
					return FALSE;
				m_pActiveScreen = m_pScreens;
			}
			bool bWrappedOnce = false;
			do {
				if (m_pActiveScreen->m_pNextScr != NULL) {
					m_pActiveScreen = m_pActiveScreen->m_pNextScr; // next in the list
				} else if (!bWrappedOnce) {
					m_pActiveScreen = m_pScreens; // wrap around to first in the list 
					bWrappedOnce = true;
				} else {
					// already wrapped once so drop out of the loop
					break;
				}
			} while (!m_pActiveScreen->m_pCMMscreen->Enabled); // ensure it's enabled
		} else if (ScreenNumber == -1) {
			// select the previous in the list...
			do {
				bool bWrappedOnce = false;
				CScreen *pScreen = m_pScreens;
				while (pScreen) {
					CScreen *pNext = pScreen->m_pNextScr; // look at the next screen
					if (pNext == NULL)			// end of the list?
					{
						if (!bWrappedOnce) {
							pNext = m_pScreens;  // wrap to head of list
							bWrappedOnce = true;
						} else {
							// already wrapped once so drop out of the loop
							break;
						}
					}
					if (pNext == m_pActiveScreen) // if the next is the active screen
							{
						m_pActiveScreen = pScreen; // we have now found the previous.
						break;
					}
					pScreen = pScreen->m_pNextScr;
				}
			} while (!m_pActiveScreen->m_pCMMscreen->Enabled); // ensure it's enabled
		} else {
			CScreen *pScreen = indexOfScreen(ScreenNumber);
			if (pScreen)
				m_pActiveScreen = pScreen;
			else
				m_pActiveScreen = m_pScreens;
			// ensure it's enabled - if not, move on to next
			bool bWrappedOnce = false;
			while (!m_pActiveScreen->m_pCMMscreen->Enabled) {
				if (m_pActiveScreen->m_pNextScr != NULL)
					m_pActiveScreen = m_pActiveScreen->m_pNextScr; // next in the list
				else if (!bWrappedOnce) {
					m_pActiveScreen = m_pScreens; // wrap around to first in the list 
					bWrappedOnce = true;
				} else {
					// already wrapped once so drop out of the loop
					break;
				}
			}
		}
		// Change oppanel mode if prev screen was non process screen and current screen is normal screen
		if (pPrevScreen && pPrevScreen->m_pCMMscreen->Type >= TPL_ALARM
				&& pPrevScreen->m_pCMMscreen->Type < TPL_NP_LAST) {
			bHidePrevNonProcessScreen = TRUE;
			if (m_pActiveScreen->m_pCMMscreen->Type < TPL_ALARM || m_pActiveScreen->m_pCMMscreen->Type > TPL_NP_LAST) {
				if (GetMode() != OPPANEL_MODE_IN_MENUS) // change only if moving from non process to process 
					SetMode(OPPANEL_MODE_PROCESS_SCREENS);
			}
		}
		// Setup the new screen number
		m_CurrentScreenNumber = m_pActiveScreen->m_pCMMscreen->Number;
		if (m_pActiveScreen->IsNonProcessScreen() == FALSE) // Only do this for normal screen
			m_pActiveScreen->ConfigChange(); // ensure it's up to date
#ifndef DOCVIEW		
		CTopStatusBar::Instance(this)->RedrawScreenNameOnBar();
		// does this screen require status bar?
		// Check here that we actually want to display this (this func gets called when entering designer mode)
		if (GetMode() == OPPANEL_MODE_PROCESS_SCREENS) {
			// for screens that have status bar turned off
			if (m_pActiveScreen->m_pCMMscreen->Enabled
					&& (m_pActiveScreen->m_pTemplate && m_pActiveScreen->m_pTemplate->m_pCMMtemplate
							&& m_pActiveScreen->m_pTemplate->m_pCMMtemplate->StatusBar == FALSE)) {
				// here if the timeout has expired, set this to false as we enter the screen
				if (m_DoScreenMove && (GetTickCount() - m_MoveScreenTick > m_pCMMlayout->StatBarTimeout * 1000)) // to millisec
					m_DoScreenMove = FALSE;
				if (pALARM_OVERVIEW->GetNumberOfAlarmsInAlarm() != 0) {
					m_DoScreenMove = TRUE; // show the status bar and move the screen down accordingly
					m_MoveScreenTick = GetTickCount(); // reset for when alarm ends
				}
				CTopStatusBar::Instance(this)->SetVisible(m_DoScreenMove);
			} else
				CTopStatusBar::Instance(this)->SetVisible(TRUE);
		}
#endif		
		// Repaint only for normal screens, For non process screens call ShowNPScreen()
		if (m_pActiveScreen->IsNonProcessScreen() == FALSE)
		{
#ifndef DOCVIEW
			if (bHidePrevNonProcessScreen) {
				CTopStatusBar *pTopBar = CTopStatusBar::Instance();
				if (pTopBar)
					pTopBar->HideNonProcessScreen(pPrevScreen->m_pCMMscreen->Number);
			}
#endif
			Repaint();
		} else {
			if (GetMode() != OPPANEL_MODE_IN_MENUS)
				ShowNPScreen(bHidePrevNonProcessScreen, m_pActiveScreen->m_pCMMscreen->Number);
		}
		// Save this to NV variable.
		COMBO_VAR4 toNV;
		toNV.ul = m_CurrentScreenNumber;
		pNV_VARS->GetBasicVarNVObject(NVV_CURRENT_SCREEN)->SetToNV(toNV);
#endif
	}
	return TRUE;
}
CWidget* COpPanel::GetCurrentNPS() {
	return CTopStatusBar::Instance()->m_pNPSDlg;
}
void COpPanel::ShowNPScreen(BOOL bHidePrevNonProcessScreen, int PrevScreenNumber) {
#ifndef DOCVIEW
	// Non process screen 
	// Stop OpPanel, and show dialog....
	//if ( m_CurrentScreenNumber != PROCESS_SCREEN_PLAYBACK )
	{
		SetMode(OPPANEL_MODE_NON_PROCESS_SCREENS);
		//::SendMessage( m_hWnd, WM_NOTIFY_REMOTE_DISP, TRUE, NULL ); commented as this does nothing
		Repaint();
	}
	//m_Visible = FALSE;
#ifndef V6IOTEST
	CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
	if (pkStatusBar) {
		if (bHidePrevNonProcessScreen)
			pkStatusBar->HideNonProcessScreen(PrevScreenNumber);
		pkStatusBar->ShowContextButton( FALSE);
		CScreen *pScreen = indexOfScreen(m_CurrentScreenNumber);
		if (pScreen) {
			pkStatusBar->ShowNonProcessScreen(pScreen->m_pCMMscreen->Type);
		} else {
			//Log ErrorMsg
			LOG_ERR( TRACE_OPPANEL, "OpPanel could not find which non process screen the user wanted to Display");
		}
		//if ( m_CurrentScreenNumber == PROCESS_SCREEN_PLAYBACK )
		//{
		//	if( PrevScreenNumber == PROCESS_SCREEN_PLAYBACK ) // if this is the first screen then active window is by default Window 1
		//		PrevScreenNumber = 1;
		//	m_CurrentScreenNumber = PrevScreenNumber; // In ExitReplayScreen m_CurrentScreenNumber refers to previous std screen.
		//}
	}
#endif
#endif
}
//****************************************************************************
// void ShowScreenList()
///
/// Method that shows the screen list thus allowing the user to change the 
/// current screen selection
///
//****************************************************************************
void COpPanel::ShowScreenList() {
#ifndef DOCVIEW
#ifndef V6IOTEST
	// lock the status bar while within this method thus preventing the user from making selections
	// from the top status bar
	CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
	pkStatusBar->LockStatusBar(true);
	QString strScreenList(GetScreenList());
	// Convert the one-based screen number of the current screen
	// to a zero-based screen index (position in screen list).
	BOOL bFound = FALSE;
	ULONG ulScreenIndex = 0;
	CScreen *pkScreen = m_pScreens;
	// loop through the screens checking their screen number
	while (pkScreen != NULL && !bFound) {
		if (pkScreen->m_pCMMscreen->Enabled) {
			if (pkScreen->m_pCMMscreen->Number == m_CurrentScreenNumber)
				bFound = TRUE;
			else
				ulScreenIndex++;
		}
		pkScreen = pkScreen->m_pNextScr;
	}
	if (!bFound)
		ulScreenIndex = 0;
	CLongBitFieldData *pkScreenListData = new CLongBitFieldData(&ulScreenIndex, 8, 0, strScreenList, bfeSingleSelList,
			0, 0, false);
	QString strChapter("");
	QString strTopic("");
	CHelpLookup::GetGeneralMenuLocation(mhpScreenList, strTopic, strChapter);
	int updateTime = 100;
	// E528446[
	// Timeout changed from 10 Sec. to 60 Sec.
	int timeout = 60000; //10000; //old
	CWidget *parent = NULL;
	parent = (CWidget*) (pkStatusBar->m_pNPSDlg == 0 ? (CWidget*) this : (CWidget*) pkStatusBar->m_pNPSDlg);
	CCfgBitFieldEditDlg kDlg(pkScreenListData, parent, strTopic, strChapter, updateTime, timeout);
	if (kDlg.exec() == IDOK) {
		// Convert the zero-based ulScreenIndex returned, which
		// represents a screen index (position in screen list),
		// to a one-based screen number.
		// Note that the following is a valid case of screen numbers:
		// Screen Index (ulScreenIndex)	Screen Number
		// ----------------------------	-------------
		//				0					1
		//				1					5
		//				2					7
		//				3					4
		pkScreen = m_pScreens;
		// loop through the screens until get to the required position
		while (pkScreen != NULL && ulScreenIndex > 0) {
			if (pkScreen->m_pCMMscreen->Enabled)
				ulScreenIndex--;
			pkScreen = pkScreen->m_pNextScr;
		}
		if ((pkScreen == NULL) || (ulScreenIndex != 0) || !SetCurrentScreen(pkScreen->m_pCMMscreen->Number)) {
			// failed to update the screen so show an error
			CV6MessageBoxDlg kDlg(L"Screen Error", L"Failed to change current screen", this);
			kDlg.exec();
		}
	}
	pkStatusBar->LockStatusBar(false);
	delete pkScreenListData;
#endif
#endif
}
//****************************************************************************
// const QString GetScreenList(	const bool bINCLUDE_DISABLED /* = false */,
//									const bool bAPPEND_SCREEN_IDS /* = false */ ) const
///
/// Method that gets a delimited list of all the screen names
///
/// @param[in]		const bool bINCLUDE_DISABLED - Flag indicating if we want to include the disabled
///					screens in the list too
/// @param[in]		const bool bAPPEND_SCREEN_IDS - Flag indicating we want the screen ID's to be
///					embedded at the end of the screen name
///
/// @return		a Delimitted list containing the screen names
///
//****************************************************************************
const QString COpPanel::GetScreenList(const bool bINCLUDE_DISABLED /* = false */,
		const bool bAPPEND_SCREEN_IDS /* = false */) const {
	QString strScreenList("");
#if IS_RECORDER == 1
	QString strScreenName("");
	CScreen *pkScreen = this->m_pScreens;
	// loop through the screen getting their names
	while (pkScreen != NULL) {
		if (bINCLUDE_DISABLED || pkScreen->GetCMMScreen()->Enabled) {
			// get the screen name nad add a delimitter
			if (!bAPPEND_SCREEN_IDS) {
				strScreenName = QString::asprintf("%s%c", pkScreen->GetCMMScreen()->Name,
						CConfigInterface::ms_wcDELIMITER);
			} else {
				strScreenName = QString::asprintf("%s%c%u%c%c", pkScreen->GetCMMScreen()->Name, g_wcEMBEDDED_INFO_DELIM,
						pkScreen->GetCMMScreen()->Number, g_wcEMBEDDED_INFO_DELIM, CConfigInterface::ms_wcDELIMITER);
			}
			// add to the list
			strScreenList += strScreenName;
		}
		// get the next screen
		pkScreen = pkScreen->m_pNextScr;
	}
#endif
	//- message screens
	//- alarm summary screen
	//- a process trend playback screen
	//- status or diagnostics screen
	return strScreenList;
}
//****************************************************************************
// const ULONG GetRotatingScreensBitfield( const bool bINCLUDE_DISABLED = false ) const
///
/// Method that gets a bitmask indicating which screens are setup as rotating
///
/// @param[in]		const bool bINCLUDE_DISABLED - Flag indicating if we want to include the disabled
///					screens in the returned bitmask
///
/// @return		A bitmask with ones representing a screen as rotating and zero as a screen not rotating - 
///				The index of the bits is based no their current order in the C++ object screen link list
///
//****************************************************************************
const ULONG COpPanel::GetRotatingScreensBitfield(const bool bINCLUDE_DISABLED /* = false */) const {
	if (m_pCMMlayout)
		return m_pCMMlayout->CycleScrBitFld; // Now we save this in the configuration, so instead of checking each screen just return this.
	ULONG ulBitfield = 0;
	ULONG ulBitmask = 0x01;
	CScreen *pkScreen = this->m_pScreens;
	// loop through the screens getting their rotating state
	while (pkScreen != NULL) {
		if (bINCLUDE_DISABLED || pkScreen->GetCMMScreen()->Enabled) {
			// check the screen is set as rotating
			if (pkScreen->GetCMMScreen()->IsRotatingScrn) {
				// set the relevant bit to 1
				ulBitfield |= ulBitmask;
			}
			// move the bitmask on
			ulBitmask <<= 1;
		}
		// get the next screen
		pkScreen = pkScreen->m_pNextScr;
	}
	return ulBitfield;
}
//****************************************************************************
// void SetRotatingScreens(	const ULONG ulROTATING_SCREEN_BITFIELD,
//								const bool bINCLUDE_DISABLED /* = false */ )
///
/// Method that sets up the rotating screens based on the passed in bitmask
///
/// @param[in]		const ULONG ulROTATING_SCREEN_BITFIELD - Bitmask indicating which screens are set
///					to rotate and which are not - The index of the bits is based on their current order 
///					in the C++ object screen link list
/// @param[in]		const bool bINCLUDE_DISABLED - Flag indicating if the passed in bitmask includes
///					disabled screens
///
//****************************************************************************
void COpPanel::SetRotatingScreens(const ULONG ulROTATING_SCREEN_BITFIELD, const bool bINCLUDE_DISABLED /* = false */) {
	m_pCMMlayout->CycleScrBitFld = ulROTATING_SCREEN_BITFIELD; //store rotate screen bit field to config...
	ULONG ulBitfield = 0;
	ULONG ulBitmask = 0x01;
	CScreen *pkScreen = this->m_pScreens;
	// loop through the screens setting their rotating state
	while (pkScreen != NULL) {
		if (bINCLUDE_DISABLED || pkScreen->GetCMMScreen()->Enabled) {
			// check the bit for this screen is set to rotating
			if ((ulROTATING_SCREEN_BITFIELD & ulBitmask) == ulBitmask) {
				// rotating so set the relevant bit to 1
				pkScreen->GetCMMScreen()->IsRotatingScrn = 1;
			} else {
				// not rotating so reset the relevant bit to 0
				pkScreen->GetCMMScreen()->IsRotatingScrn = 0;
			}
			// move the bitmask on
			ulBitmask <<= 1;
		}
		// get the next screen
		pkScreen = pkScreen->m_pNextScr;
	}
}
//****************************************************************************
// void ChangeScreenSettings( )
///
/// Method that determines what the required action should be after the user has selected the 
/// settings button from the top status bar
///
//****************************************************************************
void COpPanel::ChangeScreenSettings() {
	// determine what the user is attempting to do - for now it is only posible to change the 
	// chart speed
	ChangeChartSpeed();
}
//****************************************************************************
// void ChangeReplayScreenSettings( )
///
/// Method that shows the chart speed list, thus allowing the user to change the
///	reply chart's speed
///
//****************************************************************************
// CR: 3151 Replay at Faster speed
void COpPanel::ChangeReplayScreenSettings() {
#if IS_RECORDER == 1
	// lock the status bar while within this method thus preventing the user from making selections
	// from the top status bar
	CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
	pkStatusBar->LockStatusBar(true);
	QString strSpeedList("");
	strSpeedList = tr("Fast (10X)|Medium (3X)|Slow (X)|");
	const USHORT usSCREEN_NO = m_iActivatedReplayscreen;
	USHORT usNewSpeed = static_cast< USHORT >(pSYSTEM_INFO->GetReplayChartSpeed(usSCREEN_NO));
	CShortBitFieldData *pkChartSpeedData = new CShortBitFieldData(&usNewSpeed, 2, 0, strSpeedList, bfeSingleSelList, 0,
			0, false);
	int updateTime = 1000;
	int timeout = 10000;
	CCfgBitFieldEditDlg kDlg(pkChartSpeedData, this, L"Charts", "", updateTime, timeout);
	// popup the chart list
	if (kDlg.exec() == IDOK) {
		// set the new speed
		pSYSTEM_INFO->SetReplayChartSpeed(usSCREEN_NO, usNewSpeed);
	}
	delete pkChartSpeedData;
	pkStatusBar->LockStatusBar(false);
#endif 
}
//****************************************************************************
// void ChangeChartSpeed( )
///
/// Method that shows the chart speed list, thus allowing the user to change the
///	selected chart's speed
///
//****************************************************************************
void COpPanel::ChangeChartSpeed() {
#if IS_RECORDER == 1
	// lock the status bar while within this method thus preventing the user from making selections
	// from the top status bar
	CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
	pkStatusBar->LockStatusBar(true);
	USHORT usChartIndex = 0;
	if (m_pActiveScreen != NULL) {
		CWidget *pkWidget = m_pActiveScreen->m_pWidgets;
		bool bFoundChart = false;
		while ((pkWidget != NULL) && !bFoundChart) {
			CBaseObject *pkBaseObject = pkWidget->m_pObjects;
			while ((pkBaseObject != NULL) && !bFoundChart) {
				// check if this is a chart object
				if (pkBaseObject->GetLayoutItem().CMM_Type == BLK_CHARTOBJECT) {
					// this is a chart object therefore check if it has the same index as the current selected
					// object
					if (pkBaseObject == m_pActiveScreen->m_pLastSelectedWidget->m_pLastSelectedObject) {
						bFoundChart = true;
						CChartObject *pkChartObj = static_cast<CChartObject*>(pkBaseObject);
						const USHORT usSCREEN_NO = m_pActiveScreen->m_pCMMscreen->Number - 1;
						QString strSpeedList("");
						strSpeedList = tr("Fast|Medium|Slow|");
						// edit the speed list and insert the current chart speeds
						QString strCompleteSpeedList("");
						T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
						QString strSpeedsAvailable("");
						for (int iCount = 0; iCount < NUM_CHART_SPEEDS; iCount++) {
							// get the start of the string
							strCompleteSpeedList += CStringUtils::GetItemAtPos(strSpeedList, iCount);
							strCompleteSpeedList += " (";
							//now add the current speed setting
							// determine the number of speeds avaialble given the range - necessary because
							// of legacy issues where you could have a choice of all the speeds regalrdess of
							// whether fast/med/slow setting
							switch (iCount) {
							case SPEED_FAST: {
								strSpeedsAvailable = tr("6000mm/h|1200mm/h|600mm/h|300mm/h|120mm/h|60mm/h|");
								const USHORT usMAX_SPEEDS = CStringUtils::InstanceOfStr(strSpeedsAvailable, L"|");
								if (ptProfile->Chart.FastSpeed > usMAX_SPEEDS) {
									ptProfile->Chart.FastSpeed = 0;
								}
								// add the current speed string
								strCompleteSpeedList += CStringUtils::GetItemAtPos(strSpeedsAvailable,
										ptProfile->Chart.FastSpeed);
							}
								break;
							case SPEED_MEDIUM: {
								strSpeedsAvailable = tr("120mm/h|60mm/h|30mm/h|20mm/h|10mm/h|");
								const USHORT usMAX_SPEEDS = CStringUtils::InstanceOfStr(strSpeedsAvailable, L"|");
								if (ptProfile->Chart.MedSpeed > usMAX_SPEEDS) {
									ptProfile->Chart.MedSpeed = 0;
								}
								// add the current speed string
								strCompleteSpeedList += CStringUtils::GetItemAtPos(strSpeedsAvailable,
										ptProfile->Chart.MedSpeed);
							}
								break;
							case SPEED_SLOW: {
								strSpeedsAvailable = tr("20mm/h©3©|10mm/h©0©|5mm/h©1©|1mm/h©2©|");
								const USHORT usMAX_SPEEDS = CStringUtils::InstanceOfStr(strSpeedsAvailable, L"|");
								if (ptProfile->Chart.SlowSpeed > usMAX_SPEEDS) {
									ptProfile->Chart.SlowSpeed = 0;
								}
								// add the current speed string
								strCompleteSpeedList += CStringUtils::GetItemAtNonSequentialPos(strSpeedsAvailable,
										ptProfile->Chart.SlowSpeed);
							}
								break;
							}
							// now add the delimitter
							strCompleteSpeedList += L")|";
						}
						USHORT usNewSpeed = static_cast< USHORT >( pSYSTEM_INFO->GetChartSpeed(usChartIndex,
								usSCREEN_NO));
						CShortBitFieldData *pkChartSpeedData = new CShortBitFieldData(&usNewSpeed, 2, 0,
								strCompleteSpeedList, bfeSingleSelList, 0, 0, false);
						int updateTime = 1000;
						int timeout = 10000;
						CCfgBitFieldEditDlg kDlg(pkChartSpeedData, this, L"Charts", "", updateTime, timeout);
						// popup the chart list
						if (kDlg.exec() == IDOK) {
							// set the new speed
							pSYSTEM_INFO->SetChartSpeed(usChartIndex, usSCREEN_NO, usNewSpeed);
							pkWidget->ConfigChange(); // need to call config change on Widget here (parent of the chart)
							Repaint();
						}
						delete pkChartSpeedData;
					} else {
						// not the right chart therefore increment the chart index
						++usChartIndex;
						// break from the object loop to save time as only one chart is allowed per widget
						break;
					}
				}
				// move onto the next object
				pkBaseObject = pkBaseObject->m_pNextObj;
			}
			// move on to the next widget
			pkWidget = pkWidget->m_pNextWgt;
		}
	}
	pkStatusBar->LockStatusBar(false);
#endif
}
//****************************************************************************
/// 
/// Adds a new Screen (based on the supplied template) to the current layout
/// and sets it as the active screen.
///
/// @param[in] pConfig	  - Configuration to add to
/// @param[in] templateRef - Template type and instance to use for screen
///	@param[out] screenRef - Screen type and instance added
///
/// @return TRUE if added OK, FALSE if not found
///
//****************************************************************************
BOOL COpPanel::AddNewScreen(CLayoutConfiguration *pConfig, T_LAYOUTITEM *templateRef,
		T_LAYOUTITEM *screenRef /* = NULL */) {
	BLOCK_INFO screenBlockInfo;
	if (pConfig->AddScreen(templateRef, &screenBlockInfo) == CONFIG_OK) {
		// added ok, and populated screenBlockInfo with new Screens CMM details
		// now create a C++ Screen Object for it.
		CScreen *pScreen = new CScreen(this);
		m_pActiveScreen = pScreen;
		pScreen->CMMInitScreen(pConfig, &screenBlockInfo, NEW_INSTANCE); // screen and dependents (from template)
		AppendScreen(pScreen);
		if (screenRef) // address supplied?
			*screenRef = pConfig->BlockInfoToLayoutItem(&screenBlockInfo); // fill with T_LAYOUTITEM
		Invalidate();
		UpdateWindow();
		//Repaint();
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// 
/// Deletes a Screen from the current layout (pMAINCONFIG)
/// resetting the active screen if it is the active screen that is deleted.
///
///	@param[in] screenRef - Screen type and instance to delete
///
/// @return none
///
//****************************************************************************
void COpPanel::DeleteScreen(T_LAYOUTITEM *screenRef) {
	// are we trying to delete the Special Template Screen ?
	if (screenRef->CMM_Inst == TEMPLATE_SCREEN_INST)
		return;
	// delete the CScreen
	m_CritSec.Lock();
	BOOL bDeleteCannedScreenTemplate = FALSE;
	CScreen *pScr = indexOfScreenInstance(screenRef);
	if (pScr) {
		if (pScr->IsCannedScreen())
			bDeleteCannedScreenTemplate = TRUE;
		RemoveScreen(pScr); // remove from list
		pScr->Destroy();	// will remove everything below each screen (widgets and Objects)
		delete pScr;		// then delete the CScreen object.
	}
	m_CritSec.Unlock();
	// then delete screen from CMM
	m_pMainConfig->DeleteScreen(screenRef);
	// then delete template from CMM
	if (bDeleteCannedScreenTemplate) {
		T_LAYOUTITEM templateRef(*screenRef);
		templateRef.CMM_Type = BLK_SCRTEMPLATE;
		templateRef.CMM_Inst += CANNED_SCREENS_INST;
		m_pCannedConfig->DeleteTemplate(&templateRef, TRUE /*force*/);
//		m_pCannedConfig->CommitConfig();  // DO NOT commit here - this is up to the user (who may select discard!)
	}
}
//****************************************************************************
/// 
/// Reorders the screens in the current layout.
///
///	@param[in] NewScreenOrder - Array of screen T_LAYOUTITEMs defining new order
///
/// @return TRUE if reordered OK, FALSE if error
///
//****************************************************************************
BOOL COpPanel::ReorderScreens(CLayoutItemArray &NewScreenOrder) {
	BOOL bRet = FALSE; // assume failure
	int nNumScreens = m_pCMMlayout->NumScreens;
	if (NewScreenOrder.GetSize() == nNumScreens) {
		if (nNumScreens < 2)
			bRet = TRUE; // success!
		else {
			// Loop to find the CScreen instances corresponding to the new
			// screen order and place the CScreen pointers in an array.
			// We won't do any reordering if we can't find a screen instance.
			CScreen *ScreenList[LAYOUT_SCREENLIST_SIZE];
			int nIndex = 0;
			for (nIndex = 0; nIndex < nNumScreens; nIndex++) {
				CScreen *pScreen = indexOfScreenInstance(&NewScreenOrder[nIndex]);
				if (!pScreen)
					break; // error!
				ScreenList[nIndex] = pScreen;
			}
			// Continue only if processed all screens.
			if (nIndex == nNumScreens) {
				// Update the screen list in the CMM layout.
				for (nIndex = 0; nIndex < nNumScreens; nIndex++)
					m_pCMMlayout->ScreenList[nIndex] = NewScreenOrder[nIndex];
				// Update the screen list in OpPanel. Chain the screens
				// in the local ScreenList and set OpPanel's ptr to 1st one.
				for (nIndex = 0; nIndex < nNumScreens - 1; nIndex++)
					ScreenList[nIndex]->m_pNextScr = ScreenList[nIndex + 1];
				ScreenList[nNumScreens - 1]->m_pNextScr = NULL;
				m_pScreens = ScreenList[0];
				bRet = TRUE; // success!
			}
		}
	}
	return bRet;
}
//****************************************************************************
///
/// Adds a new Template to the current layout and shows it
///
/// @param[in] pConfig	  - Configuration to add to
/// @param[out] templateRef - Template type and instance added
///
/// @return TRUE if added OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::AddNewTemplate(CLayoutConfiguration *pConfig, T_LAYOUTITEM *templateRef /* = NULL */) {
	BLOCK_INFO templateBlockInfo;
	if (pConfig->AddTemplate(&templateBlockInfo) == CONFIG_OK) {
		// added ok, and populated templateBlockInfo with new Template's CMM details
		// now create a C++ Template Object for it.
		CTemplate *pTemplte = new CTemplate(this);
		pTemplte->CMMInitTemplate(pConfig, &templateBlockInfo, NEW_INSTANCE);
		AppendTemplate(pTemplte); // append into list.
		// now show template (may not want to do this, can be removed here)
		// need a LayoutItem for it..
		T_LAYOUTITEM layoutItem = pConfig->BlockInfoToLayoutItem(&templateBlockInfo);
		ShowTemplate(&layoutItem);
		if (templateRef)
			*templateRef = layoutItem;
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// 
/// Deletes a Template from the current layout (pMAINCONFIG)
/// resetting the active screen if it is showing the template that is deleted
/// or if the active screen is based on the deleted template
///
///	@param[in] templateRef - Template type and instance to delete
///
/// @return TRUE deleted OK, FALSE if not allowed (must always be 1 template)
///
//****************************************************************************
BOOL COpPanel::DeleteTemplate(T_LAYOUTITEM *templateRef) {
	// check number of templates !!!
	if (m_pTemplates->m_pNextTpt == NULL)
		return FALSE; // only one template so cannot delete it
	CTemplate *pTplate = indexOfTemplateInstance(templateRef);
	if (pTplate) {
		// first delete any screens using the template...
		CScreen *pScreen = m_pScreens;
		while (pScreen) {
			T_LAYOUTITEM ref = pScreen->GetLayoutItem();
			if ((pScreen->m_pTemplate == pTplate) && (ref.CMM_Inst != TEMPLATE_SCREEN_INST)) // using same template, but not the special screen !
					{
				DeleteScreen(&ref);
				pScreen = m_pScreens; // go back to start of list after each delete
			} else
				pScreen = pScreen->m_pNextScr;
		}
	}
	m_CritSec.Lock();
	if (pTplate) {
		RemoveTemplate(pTplate); // remove from list
		delete pTplate;		  // then delete the CTemplate object.
	}
	m_CritSec.Unlock();
	// then delete from CMM
	m_pMainConfig->DeleteTemplate(templateRef);
	return TRUE;
}
//****************************************************************************
/// 
/// Reorders the templates in the current layout.
///
///	@param[in] NewTemplateOrder - Array of template T_LAYOUTITEMs defining new order
///
/// @return TRUE if reordered OK, FALSE if error
///
//****************************************************************************
BOOL COpPanel::ReorderTemplates(CLayoutItemArray &NewTemplateOrder) {
	BOOL bRet = FALSE; // assume failure
	int nNumTemplates = m_pCMMlayout->NumTemplates;
	if (NewTemplateOrder.GetSize() == nNumTemplates) {
		if (nNumTemplates < 2)
			bRet = TRUE; // success!
		else {
			// Loop to find the CTemplate instances corresponding to the new
			// template order and place the CTemplate pointers in an array.
			// We won't do any reordering if we can't find a template instance.
			CTemplate *TemplateList[LAYOUT_TEMPLATELIST_SIZE];
			int nIndex = 0;
			for (nIndex = 0; nIndex < nNumTemplates; nIndex++) {
				CTemplate *pTemplate = indexOfTemplateInstance(&NewTemplateOrder[nIndex]);
				if (!pTemplate)
					break; // error!
				TemplateList[nIndex] = pTemplate;
			}
			// Continue only if processed all templates.
			if (nIndex == nNumTemplates) {
				// Update the template list in the CMM layout.
				for (nIndex = 0; nIndex < nNumTemplates; nIndex++)
					m_pCMMlayout->TemplateList[nIndex] = NewTemplateOrder[nIndex];
				// Update the template list in OpPanel. Chain the templates
				// in the local TemplateList and set OpPanel's ptr to 1st one.
				for (nIndex = 0; nIndex < nNumTemplates - 1; nIndex++)
					TemplateList[nIndex]->m_pNextTpt = TemplateList[nIndex + 1];
				TemplateList[nNumTemplates - 1]->m_pNextTpt = NULL;
				m_pTemplates = TemplateList[0];
				// Renumber the template numbers from 1..N.
				int nNumber = 0;
				CTemplate *pTemplate = m_pTemplates;
				while (pTemplate) {
					pTemplate->m_pCMMtemplate->Number = ++nNumber;
					pTemplate = pTemplate->m_pNextTpt;
				}
				bRet = TRUE; // success!
			}
		}
	}
	return bRet;
}
//****************************************************************************
///
///	Adds a new Widget to the Template of the Selected Screen
/// 
/// @param[in] pConfig - Configuration to add to
/// @param[in] bounds	- size and position of new Widget
///
/// @return TRUE if added OK, FALSE if not
///
//****************************************************************************
BOOL COpPanel::AddNewWidget(CLayoutConfiguration *pConfig, QRect *bounds) {
	BOOL bRetVal = TRUE;
	if (m_pActiveScreen && m_pActiveScreen->m_pTemplate) {
		T_LAYOUTITEM templateRef = m_pActiveScreen->m_pTemplate->GetLayoutItem();
		BLOCK_INFO widgetBlockInfo;
		if (pConfig->AddWidget(&templateRef, &widgetBlockInfo) == CONFIG_OK) {
			// added ok, and populated widgetBlockInfo with new Widgets CMM details.
			m_pActiveScreen->AddNewWidget(pConfig, &widgetBlockInfo, bounds);
			Invalidate();
			UpdateWindow();
			//Repaint();
			// here need to add the same widget to each screen that uses the same Template.
			CScreen *pScreen = m_pScreens;
			while (pScreen) {
				if (pScreen != m_pActiveScreen) {
					if (pScreen->m_pTemplate == m_pActiveScreen->m_pTemplate)	// using same template?				
						pScreen->AddNewWidget(pConfig, &widgetBlockInfo, bounds);
				}
				pScreen = pScreen->m_pNextScr;
			}
			bRetVal = TRUE;
		} else {
			// failed to create the cmm widget okay
			DebugBreak();
			bRetVal = FALSE;
		}
	} else {
		// no selected object or widget
		DebugBreak();
		bRetVal = FALSE;
	}
	return bRetVal;
}
//****************************************************************************
///
///	Adds a new object to the Seleted Widget on the Selected Screen's Template
///
/// @param[in] pConfig			- Configuration to add to
/// @param[in] ObjectBlockType	- BLK_xxx CMM block type of object to add
/// @param[in] bounds			- size and position of new Object
///
/// @return TRUE if added OK, FALSE if not
/// 
//****************************************************************************
BOOL COpPanel::AddNewObject(CLayoutConfiguration *pConfig, T_BLOCKTYPE ObjectBlockType, QRect *bounds) {
	BOOL bAdded = FALSE;
	if (m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget) {
		T_LAYOUTITEM widgetRef = m_pActiveScreen->m_pSelectedWidget->GetLayoutItem();
		BLOCK_INFO objectBlockInfo;
		if (pConfig->AddObject(&widgetRef, ObjectBlockType, &objectBlockInfo) == CONFIG_OK) {
			// added ok, and populated objectBlockInfo with new derived Objects CMM details.
			m_pActiveScreen->m_pSelectedWidget->AddNewObject(&objectBlockInfo, bounds);
			Invalidate();
			UpdateWindow();
			//Repaint();
			// here need to add the same object to each screen that uses the same Template.
			CScreen *pScreen = m_pScreens;
			while (pScreen) {
				if (pScreen != m_pActiveScreen) {
					if (pScreen->m_pTemplate == m_pActiveScreen->m_pTemplate)	// using same template?				
							{
						// find the Widget on this screen...
						CWidget *pWgt = pScreen->indexOfWidgetInstance(&widgetRef);
						if ((pWgt != NULL) && !pWgt->ObjectListFull()) {
							pWgt->AddNewObject(&objectBlockInfo, bounds);
							bAdded = TRUE;
						}
					}
				}
				pScreen = pScreen->m_pNextScr;
			}
			bAdded = TRUE;
		} else {
			// the object could not be added by the CMM
			DebugBreak();
			bAdded = FALSE;
		}
	} else {
		// the active screen or selected widget is NULL
		DebugBreak();
		bAdded = FALSE;
	}
	return bAdded;
}
//****************************************************************************
///
/// Update the client area (via bounds) of Widget or Object 
///
/// @param[in] bounds	 - size and position of Widget/Object
///	@param[in] widgetRef - widget reference to find all 
///	@param[in] objectRef - object reference to find all
/// @param[in] pPos1	 - pointer to link position 1 (top or left of scale)
///							to set if non-NULL (force link position to this value)
/// @param[in] pPos2	 - pointer to link position 2 (bottom or right of scale)
///							to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void COpPanel::UpdateBounds(QRect *bounds, T_LAYOUTITEM *widgetRef, T_LAYOUTITEM *objectRef, int *pPos1, int *pPos2) {
	CScreen *pScreen = m_pScreens;
	while (pScreen) {
		if (pScreen->m_pTemplate == m_pActiveScreen->m_pTemplate)	// using same template?				
				{
			// find the C++ Widget on this Screen...
			CWidget *pWgt = pScreen->indexOfWidgetInstance(widgetRef);
			if (pWgt) {
				if (objectRef) // doing Object or just Widget?
				{
					// now find the C++ Object on this Widget
					CBaseObject *pObj = pWgt->indexOfObjectInstance(objectRef);
					if (pObj)
						pObj->SetBounds(bounds, pPos1, pPos2); // set the object bounds (and client area)	
				} else
					pWgt->SetWidgetBounds(bounds); // adjust Widget bounds (and client area)	
			}
		}
		pScreen = pScreen->m_pNextScr;
	}
}
//****************************************************************************
///
/// Update the object links of Widget
///
///	@param[in] widgetRef - widget reference to find all 
///
/// @return none
/// 
//****************************************************************************
void COpPanel::UpdateLinks(T_LAYOUTITEM *widgetRef) {
	CScreen *pScreen = m_pScreens;
	while (pScreen) {
		if (pScreen->m_pTemplate == m_pActiveScreen->m_pTemplate)	// using same template?				
				{
			// find the C++ Widget on this Screen...
			CWidget *pWgt = pScreen->indexOfWidgetInstance(widgetRef);
			if (pWgt)
				pWgt->CheckObjectLinks(); // check linking
		}
		pScreen = pScreen->m_pNextScr;
	}
}
//****************************************************************************
///
/// Unselect all widgets and objects
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void COpPanel::UnselectAll() {
	CScreen *pScrn = m_pScreens;
	while (pScrn) {
		pScrn->UnselectAll();
		pScrn = pScrn->m_pNextScr;
	}
}
//****************************************************************************
///
/// indexOfs the given screen
/// 
/// @param[in] ScreenNumber - number of screen to find
///
/// @return pointer to screen (if found) or NULL
/// 
//****************************************************************************
CScreen* COpPanel::indexOfScreen(int ScreenNumber) {
	CScreen *pScreen = m_pScreens;
	while (pScreen) {
		if (pScreen->m_pCMMscreen->Number == ScreenNumber)
			return pScreen; // found our screen.
		pScreen = pScreen->m_pNextScr;
	}
	return NULL; // not found
}
//****************************************************************************
///
///	Refresh code... for testing at the moment.
/// 
//****************************************************************************
DWORD WINAPI RefreshThread(LPVOID lpArg) {
	COpPanel *pOpPanel = (COpPanel*) lpArg;
	while (pOpPanel->GetMode() != OPPANEL_MODE_SHUTDOWN) {
		// post a message to synchronise our refresh with paint and mouse movements etc.
		::PostMessage(pOpPanel->m_hWnd, WM_OPPANEL_REFRESH, 0, 0);
		if (pOpPanel->GetMode() == OPPANEL_MODE_PROCESS_SCREENS) {
			// Check for Op Panel Updates
			sleep(100);
		} else {
			// In menu's, startup or shutdown so we don't need as regular updates
			sleep(100);
		}
	}
	return 0;
}
//****************************************************************************
///
/// Called to perform a config change on all Screens, Widgets and Objects
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************	
void COpPanel::ConfigChange() {
	m_CritSec.Lock();
	CScreen *pScreen = m_pScreens;
	while (pScreen) {
		pScreen->ConfigChange(); // call configChange for screen - does all widgets and objects
		pScreen = pScreen->m_pNextScr;
	}
	if (m_pReplayScreen) // do replay screen too (if exists)
		m_pReplayScreen->ConfigChange();
	m_CritSec.Unlock();
}
//****************************************************************************
///
/// Check to see if a rotate is required
/// 
/// @param none
///
/// @return TRUE (if changed)
/// 
//****************************************************************************	
BOOL COpPanel::RotateScreen() {
#ifndef DOCVIEW
	// if in alarm and the alarm screen is configured, change to alarm screen
	if (m_pCMMlayout->AlarmScreen) // alarm screen flag set
	{
		if (pALARM_OVERVIEW->GetNumberOfAlarmsInAlarm() != 0) {
			// there is an active alarm
			// reset the rotate interval here (once alarm is no longer active, rotating will resume after normal rotate time delay)
			m_RotateBaseTime.TimeNow();
			// check out the alarm scren number, see if the screen is valid 
			if (m_CurrentScreenNumber != m_pCMMlayout->AlrmScrnNo) // not currently showing it
					{
				CScreen *pScreen = m_pScreens;
				while (pScreen) {
					if (pScreen->m_pCMMscreen->Number == m_pCMMlayout->AlrmScrnNo) {
						// found it. is it enabled
						if (pScreen->m_pCMMscreen->Enabled) {
							SetCurrentScreen(pScreen->m_pCMMscreen->Number); // show alarm screen
							return TRUE;
						}
						break;
					}
					pScreen = pScreen->m_pNextScr;
				}
			} else
				return FALSE; // already showing it
		}
	}
	if (m_pCMMlayout->RotateScreens) {
		// rotating screens enabled
		QTime curtime;
		curtime.TimeNow();
		if ((curtime - m_RotateBaseTime).GetSeconds() >= m_pCMMlayout->RotateTime) // seconds
				{
			// want to rotate.
			m_RotateBaseTime = curtime; // update the time here
			CScreen *pScreen = m_pActiveScreen;
			do {
				if (pScreen->m_pNextScr != NULL)
					pScreen = pScreen->m_pNextScr; // next in the list
				else
					pScreen = m_pScreens; // wrap around to first in the list 
				if ((pScreen->m_pCMMscreen->Enabled) && (pScreen->m_pCMMscreen->IsRotatingScrn)) {
					SetCurrentScreen(pScreen->m_pCMMscreen->Number);
					return TRUE;
				}
			} while (pScreen != m_pActiveScreen); // go around the list once only		
		}
	}
#endif
	return FALSE;
}
//****************************************************************************
///
/// Called to get all the Widgets on the screen to check for updates
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************	
void COpPanel::Refresh() {
	// call refresh on our active screen.
	if (!m_Inactive) // don't try and lock if inactive
	{
		if (m_CritSec.TryLock()) {
			if ((m_pActiveScreen) && (m_pActiveScreen->m_pCMMscreen->Enabled) && !m_pActiveScreen->IsNonProcessScreen())
				m_pActiveScreen->Refresh();
			else /*if ( !m_pActiveScreen->IsNonProcessScreen( ))*/ // E529380
			{
				BlankScreen();
				if (GetMode() == OPPANEL_MODE_IN_MENUS) //: as we need to rotate NPS as well we should not set base time here when showing NPS...
					m_RotateBaseTime.TimeNow();	// on exiting menu rotating will resume after normal rotate time delay
				m_DoScreenMove = TRUE; // on exit show the status bar (and move the window)
				m_MoveScreenTick = GetTickCount();
			}
#if IS_RECORDER == 1
			// update the status bar as it is a safe time to do so
			CTopStatusBar *pkStatusBar = CTopStatusBar::Instance(this);
			pkStatusBar->Update();
			// cehck if we are required to do any screen capturing to a device
			if (m_eCaptureMode != ocmNO_CAPTURE) {
				// update the media information
				CMediaManager *pkMediaManager = CMediaManager::GetHandle();
				CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();
				CaptureBitmap(this, m_strCaptureName, false);
				if (m_eCaptureMode == ocmCAPTURE_TO_EXT_CF) {
					pkMediaManager->CheckDevice(IDS_EXTERNAL_SD, false);
				} else if (m_eCaptureMode == ocmCAPTURE_TO_USB1) {
					pkMediaManager->CheckDevice(IDS_FIRST_USB, false);
				} else if (m_eCaptureMode == ocmCAPTURE_TO_USB2) {
					pkMediaManager->CheckDevice(IDS_SECOND_USB, false);
				} else {
					pkMediaManager->CheckDevice(IDS_SHARE, false);
				}
				// reset the capture mode
				m_eCaptureMode = ocmNO_CAPTURE;
			}
#endif
			m_CritSec.Unlock();
		}
	}
}
//****************************************************************************
///
/// Called to repaint the entire current screen
/// 
/// @param none
///
/// @return none
/// 
//****************************************************************************	
void COpPanel::Repaint() {
	::PostMessage(m_hWnd, WM_OPPANEL_REPAINT, 0, 0); // may be called on a different thread
}
//****************************************************************************
///
///	Destroys the OpPanel's Screens and Templates and everything underneath
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void COpPanel::Destroy() {
	m_CritSec.Lock();
	// delete all CScreens
	while (m_pScreens) {
		CScreen *pScreen = m_pScreens;
		RemoveScreen(pScreen);	// remove from list
		pScreen->Destroy();	// will remove everything below each screen (widgets and Objects)
		delete pScreen;		// then delete the CScreen object.
	}
	// same for CTemplates
	while (m_pTemplates) {
		CTemplate *pTemplate = m_pTemplates;
		RemoveTemplate(pTemplate); // remove from list
//		pTemplate->Destroy(); no destroy for template,
		delete pTemplate;
	}
	// reset member variables here
	m_pCMMlayout = NULL;
	m_pActiveScreen = NULL;
	m_IsInitialised = FALSE;
	m_CritSec.Unlock();
}
//****************************************************************************
///
///	Creates a tree of C++ Objects to correspond with Layout loaded into CMM
///
/// @param[in] pConfig	- Configuration to use
/// @param[in] CMMinfo	- pointer to layout block in CMM
/// @param[in] IsNew	- flag to indicate a new/loaded layout
///
/// @return TRUE FALSE
/// 
//****************************************************************************
BOOL COpPanel::CMMInitLayout(CLayoutConfiguration *pConfig, BLOCK_INFO *CMMinfo, BOOL IsNew) {
	if (CMMinfo->wBlockType != BLK_LAYOUT)
		return FALSE;
	InterlockedIncrement(&m_Inactive); // prevent drawing
	/// keep a copy of the CMM info block passed in.
	m_CMMinfo = *CMMinfo;
	// set up pointer to layout data in CMM info block.
	m_pCMMlayout = (T_LAYOUT*) CMMinfo->pByBlock;
	if (IsNew) {
		// Add code here that is to be done for a Newly created layout
		// (most defaults set in CreateDefaultConfig)
	} else {
		// Add code here that is to be done for a previous layout that has been reloaded
	}
	// Then always do the following code (for both new and previous layouts)
	// create the CTemplates from the Templates in the CMM.
	// the TemplateList entries have already been verified by the LayoutConfig class.
	for (int tem = 0; tem < m_pCMMlayout->NumTemplates; tem++) {
		BLOCK_INFO blockInfo;
		if (pConfig->indexOfDataBlock(&m_pCMMlayout->TemplateList[tem], &blockInfo)) // populate the Block_Info
				{
			// found and populated blockinfo OK.
			// now create a C++ Template object for it.
			CTemplate *pTemplte = new CTemplate(this);
			pTemplte->CMMInitTemplate(pConfig, &blockInfo, LOADED_INSTANCE);
			AppendTemplate(pTemplte); // append into list.
		} else
			pConfig->ClearLayoutItem(&m_pCMMlayout->TemplateList[tem]); // clear any not found (should not happen)	
	}
	// now add CScreens to match those in the CMM
	// the ScreenList entries have already been verified by the LayoutConfig class.
	for (int scr = 0; scr < m_pCMMlayout->NumScreens; scr++) {
		BLOCK_INFO blockInfo;
		if (pConfig->indexOfDataBlock(&m_pCMMlayout->ScreenList[scr], &blockInfo)) // populate the Block_Info
				{
			// found and populated blockinfo OK.
			// now create a C++ Screen Object for it.
			CScreen *pScreen = new CScreen(this);
			m_pActiveScreen = pScreen;
			pScreen->CMMInitScreen(pConfig, &blockInfo, LOADED_INSTANCE); // screen and depenedents
			AppendScreen(pScreen);
			// TESTING oNLY
//			if(scr%2==0)
//				pScreen->m_pCMMscreen->IsRotatingScrn=TRUE;
		} else
			pConfig->ClearLayoutItem(&m_pCMMlayout->ScreenList[scr]); // clear any not found (should not happen)
	}
	m_IsInitialised = TRUE;
	m_IsCommit = FALSE;
	InterlockedDecrement(&m_Inactive);
	return TRUE;
}
//****************************************************************************
///
/// Appends a Template to the end of the list for the OpPanel
/// 
/// @param[in] pTemplate - pointer to CTemplate Object to append 
///
/// @return none
/// 
//****************************************************************************
void COpPanel::AppendTemplate(CTemplate *pTemplate) {
	CTemplate **pTpt = &m_pTemplates; // address of head of list pointer
	while (*pTpt) {
		pTpt = &((*pTpt)->m_pNextTpt); // traverse any items in list
	}
	(*pTpt) = pTemplate; // assign onto end of list
	pTemplate->m_pNextTpt = NULL;
}
//****************************************************************************
///
/// removes a Template from the list for the OpPanel (NB: DOES NOT DELETE IT)
/// 
/// @param[in] pTemplate - pointer to CTemplate to remove
///
/// @return TRUE if removed OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::RemoveTemplate(CTemplate *pTemplate) {
	T_LAYOUTITEM screenRef;
	screenRef.CMM_Type = BLK_SCREEN;
	screenRef.CMM_Inst = TEMPLATE_SCREEN_INST;
	// see if we are showing this template. If so, need to remove the screen showing it.	
	CScreen *pScrT = indexOfScreenInstance(&screenRef);
	if (pScrT) {
		// we do have the special template screen already configured. Is it for this template?
		if (pScrT->m_pTemplate == pTemplate) {
			// yes, it's set for this template, so remove the screen
			RemoveScreen(pScrT); // remove from list (will reset m_pActiveScreen if required)
			pScrT->Destroy();	// will remove everything below each screen (widgets and Objects)
			delete pScrT;		// then delete the CScreen object.
		}
	}
	// now remove the template from the list	
	CTemplate **pTpt = &m_pTemplates;
	BOOL found = FALSE;
	while (*pTpt) {
		if (*pTpt == pTemplate) {
			// found our template.
			*pTpt = pTemplate->m_pNextTpt; // remove it from list
			pTemplate->m_pNextTpt = NULL;
			found = TRUE;
			break;
		}
		pTpt = &((*pTpt)->m_pNextTpt);
	}
	return found;
}
//****************************************************************************
///
/// Appends a Screen into the list for the OpPanel
/// 
/// @param[in] pScreen - pointer to CScreen to append 
///
/// @return none
/// 
//****************************************************************************
void COpPanel::AppendScreen(CScreen *pScreen) {
	CScreen **pScr = &m_pScreens; // address of head of list pointer
	while (*pScr)
		pScr = &((*pScr)->m_pNextScr); // traverse any items in list
	(*pScr) = pScreen; // assign onto end of list
	pScreen->m_pNextScr = NULL;
}
//****************************************************************************
///
/// removes a Screen from the list for the OpPanel (NB: DOES NOT DELETE IT)
/// 
/// @param[in] pScreen - pointer to CScreen to remove
///
/// @return TRUE if removed OK, FALSE if not found
/// 
//****************************************************************************
BOOL COpPanel::RemoveScreen(CScreen *pScreen) {
	CScreen **pScr = &m_pScreens;
	BOOL found = FALSE;
	while (*pScr) {
		if (*pScr == pScreen) {
			// found our screen.
			*pScr = pScreen->m_pNextScr; // remove it from list
			pScreen->m_pNextScr = NULL;
			found = TRUE;
			break;
		}
		pScr = &((*pScr)->m_pNextScr);
	}
	// reset the active screen here if required
	if (m_pActiveScreen == pScreen)
		m_pActiveScreen = m_pScreens; // could be NULL if last removed
	return found;
}
//****************************************************************************
///
///	searches list of CTemplates for matching CMM Template
///
/// @param[in] templateRef - Template type and instance to find
/// 
/// 
//****************************************************************************
CTemplate* COpPanel::indexOfTemplateInstance(T_LAYOUTITEM *templateRef) {
	CTemplate *pTpt = m_pTemplates;
	while (pTpt) {
		if (pTpt->MatchLayoutItem(templateRef))
			return pTpt;
		pTpt = pTpt->m_pNextTpt;
	}
	return NULL; // not matched.
}
//****************************************************************************
///
///	searches list of CScreens for matching CMM Screen
///
/// @param[in] screenRef - Screen type and instance to find
/// 
/// 
//****************************************************************************
CScreen* COpPanel::indexOfScreenInstance(T_LAYOUTITEM *screenRef) {
	CScreen *pScr = m_pScreens;
	while (pScr) {
		if (pScr->MatchLayoutItem(screenRef))
			return pScr;
		pScr = pScr->m_pNextScr;
	}
	return NULL; // not matched.
}
//****************************************************************************
///
///	searches CLayoutItems for matching CMM item.
/// searches m_pActiveScreen for a widget, m_pSelectedWidget for an object.
///
/// @param[in] itemRef - Item type and instance to find
/// 
/// 
//****************************************************************************
CLayoutItem* COpPanel::indexOfItemInstance(T_LAYOUTITEM *itemRef) {
	CLayoutItem *pItem = NULL; // assume not found
	switch (itemRef->CMM_Type) {
	case BLK_SCRTEMPLATE: {
		pItem = indexOfTemplateInstance(itemRef);
		break;
	}
	case BLK_SCREEN: {
		pItem = indexOfScreenInstance(itemRef);
		break;
	}
	case BLK_WIDGET: {
		if (m_pActiveScreen)
			pItem = m_pActiveScreen->indexOfWidgetInstance(itemRef);
		break;
	}
	default: // BLK_BASEOBJECT:
	{
		if (m_pMainConfig->BlockTypeToObjectType((T_BLOCKTYPE) itemRef->CMM_Type) != NoObject)
			if (m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget)
				pItem = m_pActiveScreen->m_pSelectedWidget->indexOfObjectInstance(itemRef);
		break;
	}
	}
	return pItem;
}
//****************************************************************************
///
///	Blank screen with options diagnostics when used at startup
///
/// @param[in] showDiag	- shows diagnostics
///
/// @returns none
/// 
//****************************************************************************
void COpPanel::BlankScreen() {
	if (m_Inactive || (m_pDD == NULL))
		return;
	if (InterlockedIncrement(&m_IsDrawing) > 1) {
		InterlockedDecrement(&m_IsDrawing);
		return;
	}
	GetClientRect(&m_DesktopRect);
#ifndef UNDER_CE // required only for desktop builds		
	ClientToScreen(&m_DesktopRect); // convert to screen co-ords
#endif	
	HRGN hrgnUpdate = CreateRectRgnIndirect(&m_DesktopRect); // whole screen 
	// get'window'cliplist from ddClipperWindow
	DWORD listbytes = 0;
	;
	HRGN hWindowRgn;
	//m_pDDClipperWindow->GetClipList(NULL,NULL,&listbytes);
	m_pDDClipper->GetClipList(NULL, NULL, &listbytes);
	// here we have the window cliplist. This will take account of overlapping windows 
	// for desktop and dialog boxes for recorder. 
	if (listbytes) {
		SetClipListBuffer(listbytes);
		//m_pDDClipperWindow->GetClipList(NULL,m_pClipList,&listbytes);
		m_pDDClipper->GetClipList(NULL, m_pClipList, &listbytes);
		hWindowRgn = ExtCreateRegion(NULL, listbytes, m_pClipList);
		// now do intersection with hrgnUpdate
		int res = CombineRgn(hrgnUpdate, hrgnUpdate, hWindowRgn, RGN_AND);
		DeleteObject(hWindowRgn);
		if (res <= NULLREGION) {
			// nothing (on the background) visible
			DeleteObject(hrgnUpdate);
			InterlockedDecrement(&m_IsDrawing);
			return;
		}
	} else {
		// nothing (on the backgound) is visible
		DeleteObject(hrgnUpdate);
		InterlockedDecrement(&m_IsDrawing);
		return;
	}
	// so here something on the background is visible
	listbytes = GetRegionData(hrgnUpdate, 0, NULL);
	if (listbytes) {
		SetClipListBuffer(listbytes);
		GetRegionData(hrgnUpdate, listbytes, m_pClipList);
		HRESULT hr = m_pDDClipper->SetClipList(m_pClipList, 0);
	}
	// desktop rect already configured choose a colour and blt in the background
	DDBLTFX ddbltfx;
	memset(&ddbltfx, 0, sizeof(ddbltfx));
	ddbltfx.dwSize = sizeof(ddbltfx);
	//COLORREF colour=QString (255,127,0); //orange
	//COLORREF colour=QString (97,255,175); //mint
	//COLORREF colour=QString (0,150,187); // blue
	COLORREF colour = QString(32, 32, 96); // dark blue
	// for desktop, FILLCOLOUR Macro will be expanded to convert 16 bit colour to 32 bit RGB888
	ddbltfx.dwFillColor = FILLCOLOURFROMRGB(colour);
	QRect screenRect;
	GetClientRect(&screenRect);
#ifdef UNDER_CE
	HRESULT hres = m_pDDSBackBuffer->Blt(&screenRect, NULL, NULL, DDBLT_COLORFILL | DDABLT_WAITNOTBUSY , &ddbltfx); // back buffer
#else
	HRESULT hres = m_pDDSBackBuffer->Blt(&screenRect, NULL, NULL, DDBLT_COLORFILL | DDBLT_WAIT, &ddbltfx); // back buffer
#endif
	HDC hdc;
	// HRESULT hres;
	hres = m_pDDSBackBuffer->GetDC(&hdc);
	if (!FAILED(hres)) {
		QRect rect = { 2, 2, 320, 18 };
		SetTextColor(hdc, QString(255, 255, 255));
		SetBkMode(hdc, TRANSPARENT);
#ifndef DOCVIEW
#ifndef V6IOTEST
		// If we are not in menu's then we want to display something
		if ((GetMode() == OPPANEL_MODE_STARTUP) || (GetMode() == OPPANEL_MODE_SHUTDOWN)) {
			Glb_MouseOn = FALSE;
			GetCursorPos(&Glb_MousePos);
			ScreenToClient(&Glb_MousePos);
			CFontCache *pfc = CFontCache::GetHandle();
			USHORT usLang = 0xFFFF;
			int iFlagID = NULL;
			//Set up the required fonts
			QFont hfont;
			QFont titleFont;
			hfont = pfc->GetFont(_Height(rect), QFont::Normal, 3, NONANTIALIASED_QUALITY);
			titleFont = pfc->GetFont(22, QFont::Medium, 3, ANTIALIASED_QUALITY);
			//Default font
			QFont hOldfont = (QFont) SelectObject(hdc, hfont);
			//COLORREF GreenTxt = QString (15,180,15);
			COLORREF BlueText = QString(15, 15, 180);
			COLORREF TitleBlue = QString(220, 220, 245);
			COLORREF MainBlue = QString(239, 247, 255);
			COLORREF ErrorBlue = QString(180, 180, 255);
			COLORREF BlackText = QString(15, 15, 15);
			//we need to draw the User information startup screen
			//Use mini trend screen size as default
			int BoxHeight = 240;
			int BoxWidth = 320;
			/*		int BoxHeight = 272;
			 int BoxWidth = 480;*/
			int iSection = 0;
			//centre the box horizontally and vertically, regardless of if it's on a mini or multi
			QRect DiagOrigin = { (screenRect.right / 2) - (BoxWidth / 2), (screenRect.bottom / 2) - (BoxHeight / 2),
					(screenRect.right / 2) + (BoxWidth / 2), (screenRect.bottom / 2) + (BoxHeight / 2) };
			// set up a few defaults
			int TtlBarHt = 30;
			int IconHeight = 50;
			int TxtLnHt = 16;
			int TxtLnSp = 6;
			int TxtLnInd = 80;
			int ErrBoxTop = TtlBarHt + IconHeight + (3 * (TxtLnHt + TxtLnSp)) + 5;
			int ErrBoxHeight = 90;
			int ErrBoxInd = 10;
			USHORT ErrCount = 0;
			int LightMargin = 10;
			int LightSep = 0;
			//int LightHt = 40;
			//int LightWidth = (BoxWidth - (LightMargin*2) - (LightSep*(MAX_STARTUP_SECTIONS-1)))/MAX_STARTUP_SECTIONS;
			//select the font for the title section (MOTD)
			SelectObject(hdc, hfont);
			//Create titlebar area
			QRect BkBox = { DiagOrigin.left, DiagOrigin.top, DiagOrigin.right, DiagOrigin.top + TtlBarHt };
			HBRUSH hBr = CreateSolidBrush(TitleBlue);
			FillRect(hdc, &BkBox, hBr);
			DeleteObject(hBr);
			// draw main part of display box
			BkBox.setBottom(DiagOrigin).bottom;
			BkBox.setTop(TtlBarHt);
			hBr = CreateSolidBrush(MainBlue);
			FillRect(hdc, &BkBox, hBr);
			DeleteObject(hBr);
			//initialise text for main information area
			QString csTxt = "";
			QString csTxtLn2 = "";
			QString csTxtLn1 = "";
			QString csErr[6];
			QString ErrList;
			//txtRect will be the generic re-used box for drawing text
			QRect TxtRect;
			if (GetMode() == OPPANEL_MODE_STARTUP) {
				//get the text strings once the globals are created
				m_csWelcomeTxt = tr("Starting Recorder");
				if (pGlbSysInfo) {
					//GetLanguage
					usLang = pGlbSysInfo->GetValidLanguage();
					switch (static_cast<T_LANGUAGES>(usLang)) {
					case lngEnglish:
						iFlagID = IDB_START_LANG_UKENG;
						break;
					case lngEngUS:
						iFlagID = IDB_START_LANG_USENG;
						break;
					case lngFra:
						iFlagID = IDB_START_LANG_FRANCE;
						break;
					case lngGer:
						iFlagID = IDB_START_LANG_GERMANY;
						break;
					case lngIta:
						iFlagID = IDB_START_LANG_ITALY;
						break;
					case lngSpa:
						iFlagID = IDB_START_LANG_SPAIN;
						break;
					case lngBraz:
						iFlagID = IDB_START_LANG_BRAZPOR;
						break;
					case lngPol:
						iFlagID = IDB_START_LANG_POLAND;
						break;
					case lngHung:
						iFlagID = IDB_START_LANG_HUNGARY;
						break;
					case lngSlo:
						iFlagID = IDB_START_LANG_SLOVAKIA;
						break;
					case lngCze:
						iFlagID = IDB_START_LANG_CZECH;
						break;
					case lngTurk:
						iFlagID = IDB_START_LANG_TURK;
						break;
					case lngRom:
						iFlagID = IDB_START_LANG_ROMANIA;
						break;
					case lngRus:
						iFlagID = IDB_START_LANG_RUSSIA;
						break;
					case lngPor:
						iFlagID = IDB_START_LANG_PORTUGAL;
						break;
					case lngGrk:
						iFlagID = IDB_START_LANG_GREECE;
						break;
					case lngBulg:
						iFlagID = IDB_START_LANG_BULGARIA;
						break;
#if LangChinese == 1
					case lngChin:
						iFlagID = IDB_START_LANG_CHINESE;
						break;
#endif
#if LangJapanese == 1
					case lngJap:
						iFlagID = IDB_START_LANG_JAPANESE;
						break;
#endif
#if LangKorean == 1
					case lngKor:
						iFlagID = IDB_START_LANG_KORIAN;
						break;
#endif
					case 0xFFFF:
					default:
						//display nothing
						break;
					}
					ErrList = pGlbSysInfo->GetStartupErrList();
					ErrCount = CStringUtils::InstanceOfStr(ErrList, L"|");
					if (ErrCount > 0) {
						for (int i = 0; i < ErrCount && i < 6; i++) {
							csErr[i] = CStringUtils::GetItemAtPos(ErrList, i);
						}
					}
					iSection = pGlbSysInfo->GetStartupSection();
					csTxt = SS_STARTUP_SECTION_STRINGS[iSection];
					csTxtLn1 = pGlbSysInfo->GetStartupAction();
					csTxtLn2 = pGlbSysInfo->GetStartupSubAction();
					//TxtRect.setleft(DiagOrigin).left+50;
					//TxtRect.setright(DiagOrigin).right;
					//TxtRect.setTop(DiagOrigin).top+TtlBarHt+IconHeight+(3*TxtLnSp)+(2*TxtLnHt);
					//TxtRect.setBottom(TxtRect).top + TxtLnHt;
				} else {
					csTxt = SS_STARTUP_SECTION_STRINGS[SS_INITIAL_BOOT];
					csTxtLn1 = SS_STARTUP_SECTION_STRINGS[SS_INIT_HW];
				}
				//Draw the icons
				CBitmap StageBitmap[MAX_STARTUP_SECTIONS];
				CBitmap LangBitmap;
				CDC cdc;
				cdc.Attach(hdc);
				CDC dcMem;
				dcMem.CreateCompatibleDC(&cdc);
				//draw language icon
				if (iFlagID != NULL) {
					LangBitmap.LoadBitmap(iFlagID);
					BITMAP bmpInfo;
					LangBitmap.GetBitmap(&bmpInfo);
					if (bmpInfo.bmHeight <= TtlBarHt)
						BkBox.setTop(DiagOrigin).top + ((TtlBarHt - bmpInfo.bmHeight) / 2);
					else
						BkBox.setTop(DiagOrigin).top;
					BkBox.setleft(DiagOrigin).left + (BoxWidth - (bmpInfo.bmWidth + 1));
					// Select the bitmap into the in-memory DC.
					CBitmap *pOldBitmap = dcMem.SelectObject(&LangBitmap);
					// Copy the bits from the in-memory DC into the on-screen DC to actually do the painting.
					cdc.BitBlt(BkBox.left, BkBox.top, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY);
					// Restore the original bitmap.
					dcMem.SelectObject(pOldBitmap);
				}
				BkBox.setTop(DiagOrigin).top + TtlBarHt + 3;
				for (int i = 0; i < MAX_STARTUP_SECTIONS; i++) {
					int ofset;
//					BkBox.setleft(DiagOrigin).left+((LightWidth+LightSep)*i)+LightMargin;
					if (i < iSection)
						ofset = 1;
					else if (i > iSection)
						ofset = 2;
					else
						ofset = 0;
					if (StageBitmap[i].LoadBitmap(IDB_START_STARTUP_DOING + (i * 3) + ofset)) {
						BITMAP bmpInfo;
						StageBitmap[i].GetBitmap(&bmpInfo);
						LightSep = (BoxWidth - (LightMargin * 2) - (bmpInfo.bmWidth * MAX_STARTUP_SECTIONS))
								/ (MAX_STARTUP_SECTIONS - 1);
						BkBox.setleft(DiagOrigin).left + ((bmpInfo.bmWidth + LightSep) * i) + LightMargin;
						// Select the bitmap into the in-memory DC.
						CBitmap *pOldBitmap = dcMem.SelectObject(&StageBitmap[i]);
						// Copy the bits from the in-memory DC into the on-screen DC to actually do the painting.
						cdc.BitBlt(BkBox.left, BkBox.top, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY);
						// Restore the original bitmap.
						dcMem.SelectObject(pOldBitmap);
					}
				}
				cdc.Detach();
				dcMem.DeleteDC();
				if (ErrCount > 0) {
					///@todo draw the persistant information box. e.g. messages which should stay on for 
					//more than a fraction of a second
					BkBox.setleft(DiagOrigin).left + ErrBoxInd;
					BkBox.setTop(DiagOrigin).top + ErrBoxTop;
					BkBox.setright(DiagOrigin).right - ErrBoxInd;
					BkBox.setBottom(DiagOrigin).bottom - ErrBoxInd;
					hBr = CreateSolidBrush(ErrorBlue);
					FillRect(hdc, &BkBox, hBr);
					DeleteObject(hBr);
					TxtRect.setTop(BkBox).top;
					TxtRect.setBottom(TxtRect).top + TxtLnHt;
					TxtRect.setleft(BkBox).left + 5;
					TxtRect.setright(BkBox).right - 5;
					//reset to default font with a dark text
					SetTextColor(hdc, BlackText);
					SelectObject(hdc, hfont);
					for (int i = 0; i < ErrCount && i < 6; i++) {
						DrawText(hdc, csErr[i], -1, &TxtRect, DT_SINGLELINE | DT_LEFT);
						TxtRect.setTop(TxtLnHt);
						TxtRect.setBottom(TxtLnHt);
					}
				}
			}
			else if (GetMode() == OPPANEL_MODE_SHUTDOWN) {
				/// @todo AK, when we revamp the startup sequence we need to include the shutdown in that
				/// this is a temporary user of the blankscreen to allow user feedback in shutdown
				//int shrinkBy=10;
				//screenRect.setLeft(shrinkBy);
				//screenRect.setRight(shrinkBy);
				//screenRect.setTop(shrinkBy);
				//screenRect.setBottom(shrinkBy);
				m_csWelcomeTxt = tr("Recorder Shutdown");
				csTxt = tr("The system is shutting down");
				csTxtLn1 = pGlbSysInfo->GetStartupAction();
				csTxtLn2 = pGlbSysInfo->GetStartupSubAction();
			}
			// Draw the MOTD text
			TxtRect.setTop(DiagOrigin).top;
			TxtRect.setBottom(DiagOrigin).top + TtlBarHt;
			TxtRect.setleft(DiagOrigin).left + 20;
			TxtRect.setright(DiagOrigin).right;
			SetTextColor(hdc, BlueText);
			SelectObject(hdc, titleFont);
			DrawText(hdc, m_csWelcomeTxt, -1, &TxtRect, DT_SINGLELINE | DT_LEFT | DT_VCENTER);
			//reset to default font with a dark text
			SetTextColor(hdc, BlackText);
			SelectObject(hdc, hfont);
			//draw the three main text display boxes
			TxtRect.setleft(DiagOrigin).left + 50;
			TxtRect.setright(DiagOrigin).right;
			TxtRect.setTop(DiagOrigin).top + TtlBarHt + IconHeight + TxtLnSp;
			TxtRect.setBottom(TxtRect).top + TxtLnHt;
			//text 1
			DrawText(hdc, csTxt, -1, &TxtRect, DT_SINGLELINE | DT_LEFT);
			TxtRect.setTop(TxtLnHt) + TxtLnSp;
			TxtRect.setBottom(TxtRect).top + TxtLnHt;
			//Text 2
			DrawText(hdc, csTxtLn1, -1, &TxtRect, DT_SINGLELINE | DT_LEFT);
			TxtRect.setTop(TxtLnHt) + TxtLnSp;
			TxtRect.setBottom(TxtRect).top + TxtLnHt;
			//Text 3
			DrawText(hdc, csTxtLn2, -1, &TxtRect, DT_SINGLELINE | DT_LEFT);
#ifdef SHOW_CPU			
			TxtRect.setTop(TxtLnHt)+TxtLnSp;
			TxtRect.setBottom(TxtRect).top + TxtLnHt;
			//Text4
			float cpuUsage = GetCurrentCPUUtilization();
			QString csTxt2 ;
			csTxt2 = QString::asprintf("CPU: %.02f%s", cpuUsage,L"%");
			DrawText(hdc, csTxt2,-1,&TxtRect,DT_SINGLELINE|DT_LEFT);
#endif
			pfc->ReleaseFont(titleFont);
			SelectObject(hdc, hOldfont);
			pfc->ReleaseFont(hfont);
		} else if (GetMode() == OPPANEL_MODE_PROCESS_SCREENS) {
			// Here the mode is OPPANEL_MODE_PROCESS_SCREENS - would not be in this function UNLESS there was a problem
			// with the active screen (i.e. there are no screens enabled)
			Glb_MouseOn = FALSE;
			GetCursorPos(&Glb_MousePos);
			ScreenToClient(&Glb_MousePos);
			CFontCache *pfc = CFontCache::GetHandle();
			USHORT usLang = 0xFFFF;
			int iFlagID = NULL;
			//Set up the required fonts
			QFont hfont;
			QFont titleFont;
			hfont = pfc->GetFont(_Height(rect), QFont::Normal, 3, NONANTIALIASED_QUALITY);
			titleFont = pfc->GetFont(20, QFont::Medium, 3, ANTIALIASED_QUALITY);
			//Default font
			QFont hOldfont = (QFont) SelectObject(hdc, hfont);
			COLORREF BlueText = QString(15, 15, 180);
			COLORREF TitleBlue = QString(220, 220, 245);
			COLORREF MainBlue = QString(239, 247, 255);
			COLORREF ErrorBlue = QString(180, 180, 255);
			COLORREF BlackText = QString(15, 15, 15);
			//Use mini trend screen size as default
			int BoxHeight = 240;
			int BoxWidth = 320;
			/*		int BoxHeight = 272;
			 int BoxWidth = 480;*/
			int iSection = 0;
			//centre the box horizontally and vertically, regardless of if it's on a mini or multi
			QRect DiagOrigin = { (screenRect.right / 2) - (BoxWidth / 3), (screenRect.bottom / 2) - (BoxHeight / 4),
					(screenRect.right / 2) + (BoxWidth / 3), (screenRect.bottom / 2) + (BoxHeight / 4) };
			// set up a few defaults
			int TtlBarHt = 30;
			int IconHeight = 50;
			int TxtLnHt = 14;
			int TxtLnSp = 6;
			int TxtLnInd = 80;
			int ErrBoxTop = TtlBarHt + IconHeight + (3 * (TxtLnHt + TxtLnSp)) + 5;
			int ErrBoxHeight = 90;
			int ErrBoxInd = 10;
			USHORT ErrCount = 0;
			int LightMargin = 10;
			int LightSep = 0;
			//select the font for the title section (MOTD)
			SelectObject(hdc, hfont);
			//Create titlebar area
			QRect BkBox = { DiagOrigin.left, DiagOrigin.top, DiagOrigin.right, DiagOrigin.top + TtlBarHt };
			HBRUSH hBr = CreateSolidBrush(TitleBlue);
			FillRect(hdc, &BkBox, hBr);
			DeleteObject(hBr);
			// draw main part of display box
			BkBox.setBottom(DiagOrigin).bottom;
			BkBox.setTop(TtlBarHt);
			hBr = CreateSolidBrush(MainBlue);
			FillRect(hdc, &BkBox, hBr);
			DeleteObject(hBr);
			QString strWelcomeTxt("");
			strWelcomeTxt = tr("No Screens Enabled");
			QRect TxtRect;
			// Draw the MOTD text
			TxtRect.setTop(DiagOrigin).top;
			TxtRect.setBottom(DiagOrigin).top + TtlBarHt;
			TxtRect.setleft(DiagOrigin).left + 20;
			TxtRect.setright(DiagOrigin).right;
			SetTextColor(hdc, BlueText);
			SelectObject(hdc, titleFont);
			DrawText(hdc, strWelcomeTxt, -1, &TxtRect, DT_SINGLELINE | DT_LEFT | DT_VCENTER);
			SetTextColor(hdc, BlackText);
			SelectObject(hdc, hfont);
			QString csTxt("");
			csTxt = tr("Please enable some screens!!!");
			//draw the three main text display boxes
			TxtRect.setleft(DiagOrigin).left + 30;
			TxtRect.setright(DiagOrigin).right;
			TxtRect.setTop(DiagOrigin).top + TtlBarHt + (TxtLnHt * 2);
			TxtRect.setBottom(TxtRect).top + TxtLnHt;
			//text 1
			DrawText(hdc, csTxt, -1, &TxtRect, DT_SINGLELINE | DT_LEFT);
			pfc->ReleaseFont(titleFont);
			SelectObject(hdc, hOldfont);
			pfc->ReleaseFont(hfont);
		} else // OPPANEL_MODE_IN_MENUS
		{
			Glb_MouseOn = TRUE;
		}
#endif
#endif
		SetBkMode(hdc, OPAQUE);
		m_pDDSBackBuffer->ReleaseDC(hdc);
		// this blt is done in conjunction with our directdraw clipper
		// so will avoid any dialogs/menus etc.
		//CURSOR_OFF;
		//E437415
		//DDBLT_WAIT flag is no longer supported for windows embedded ce 6.0
		//Use DDBLT_WAITNOTBUSY instead of DDBLT_WAIT in following statement
		//E529380 should do above changes only for CE compilation.
#ifdef UNDER_CE
		hres = m_pDDSPrimary->Blt(&m_DesktopRect, m_pDDSBackBuffer, &screenRect, DDBLT_WAITNOTBUSY | DDBLT_WAITVSYNC, NULL);		
#else
		hres = m_pDDSPrimary->Blt(&m_DesktopRect, m_pDDSBackBuffer, &screenRect, DDBLT_WAIT, NULL);
#endif
		//CURSOR_ON;
	}
	InterlockedDecrement(&m_IsDrawing);
	DeleteObject(hrgnUpdate);
}
//void COpPanel::BlankScreen()
//{
//	static BYTE phase = 0;
//	HRESULT hres = S_OK;
//	HDC hdc;
//	//QRect rc;
//	SIZE size;
//	int nMsg;
//	DDBLTFX ddbltfx;
//	//QRect DesktopRect;
//	GetClientRect(&m_DesktopRect);	
//
//	HRGN hrgnUpdate=CreateRectRgnIndirect(&m_DesktopRect); // whole screen 
//
//	// get'window'cliplist from ddClipperWindow
//
//	DWORD listbytes = 0;
//	HRGN hWindowRgn;
//	m_pDDClipperWindow->GetClipList(NULL,NULL,&listbytes);
//
//	// here we have the window cliplist. This will take account of overlapping windows 
//	// for desktop and dialog boxes for recorder. 
//
//	if(listbytes) 
//	{ 
//		SetClipListBuffer(listbytes);
//		m_pDDClipperWindow->GetClipList(NULL,m_pClipList,&listbytes);
//		hWindowRgn=ExtCreateRegion(NULL,listbytes,m_pClipList);
//
//		// now do intersection with hrgnUpdate
//		int res=CombineRgn(hrgnUpdate,hrgnUpdate,hWindowRgn,RGN_AND);
//		DeleteObject(hWindowRgn);
//		if(res<=NULLREGION)
//		{
//			// nothing (on the background) visible
//			DeleteObject(hrgnUpdate);
//			return; 
//		}
//	}
//	else
//	{
//		// nothing (on the backgound) is visible
//		DeleteObject(hrgnUpdate);
//		return; 
//	}
//
//
//	// so here something on the background is visible
//	listbytes=GetRegionData(hrgnUpdate,0,NULL);
//	if(listbytes)
//	{
//		//SetClipListBuffer(listbytes);
//		GetRegionData(hrgnUpdate,listbytes,m_pClipList);
//		HRESULT hr=m_pDDClipper->SetClipList(m_pClipList,0);
//	}
//
//	// desktop rect already configured choose a colour and blt in the background
//	ddbltfx.dwSize = sizeof(ddbltfx); 
//	//COLORREF colour=QString (255,127,0); //orange
//	//COLORREF colour=QString (97,255,175); //mint
//	//COLORREF colour=QString (0,150,187); // blue
//	COLORREF colour = QString (32,32,96); // dark blue
//
//	// for desktop, FILLCOLOUR Macro will be expanded to convert 16 bit colour to 32 bit RGB888
//	ddbltfx.dwFillColor = FILLCOLOURFROMRGB(colour); 
//	
//	QRect screenRect;
//	GetClientRect(&screenRect);
//	
//	hres= m_pDDSBackBuffer->Blt(&screenRect, NULL, NULL, DDBLT_COLORFILL, &ddbltfx); // back buffer
//
// 
//  hres = m_pDDSBackBuffer->GetDC(&hdc);
//
//	if(!FAILED(hres))
//	{  
//
//		QRect rect={2,2,320,16};
//
//		SetTextColor(hdc,QString (255,255,255)); 
//
//		SetBkMode(hdc,TRANSPARENT);
//
//		//Glb_MouseOn=FALSE;
//		//GetCursorPos(&Glb_MousePos);
//		//ScreenToClient(&Glb_MousePos);
//
//		/*CFontCache *pfc=CFontCache::GetHandle();*/
//
//		USHORT usLang = 0xFFFF;
//		int iFlagID = NULL;
//		//Set up the required fonts
//		QFont hfont;
//		QFont titleFont;
//		//hfont=pfc->GetFont(_Height(rect),QFont::Normal,3,NONANTIALIASED_QUALITY);
//		//titleFont = pfc->GetFont(20,QFont::Medium,3,ANTIALIASED_QUALITY);
//		////Default font
//		//QFont hOldfont=(QFont)SelectObject (hdc, hfont);
//
//		//COLORREF GreenTxt = QString (15,180,15);
//		COLORREF BlueText = QString (15,15,180);
//		COLORREF TitleBlue = QString (220,220,245);
//		COLORREF MainBlue = QString (239,247,255);
//		COLORREF ErrorBlue = QString (180,180,255);
//		COLORREF BlackText = QString (15,15,15);
//
//
//		//we need to draw the User information startup screen
//		//Use mini trend screen size as default
//		int BoxHeight = 240;
//		int BoxWidth = 320;
//		int iSection = 0;
//		//centre the box horizontally and vertically, regardless of if it's on a mini or multi
//		QRect DiagOrigin = {(screenRect.right/2)-(BoxWidth/2),
//			(screenRect.bottom/2)-(BoxHeight/2),
//			(screenRect.right/2)+(BoxWidth/2),
//			(screenRect.bottom/2)+(BoxHeight/2)};
//		// set up a few defaults
//		int TtlBarHt = 30;
//		int IconHeight = 50;
//		int TxtLnHt = 14;
//		int TxtLnSp = 6;
//		int TxtLnInd = 80;
//		int ErrBoxTop = TtlBarHt+IconHeight+(3*(TxtLnHt+TxtLnSp))+5;
//		int ErrBoxHeight = 90;
//		int ErrBoxInd = 10;
//		USHORT ErrCount = 0;
//
//
//		int LightMargin = 10;
//		int LightSep = 0;
//		//int LightHt = 40;
//
//		//int LightWidth = (BoxWidth - (LightMargin*2) - (LightSep*(MAX_STARTUP_SECTIONS-1)))/MAX_STARTUP_SECTIONS;
//
//		//select the font for the title section (MOTD)
//		SelectObject (hdc, hfont);
//		//Create titlebar area
//		QRect BkBox={DiagOrigin.left,DiagOrigin.top,DiagOrigin.right,DiagOrigin.top+TtlBarHt};
//		HBRUSH hBr = CreateSolidBrush(TitleBlue);
//
//		FillRect(hdc,&BkBox,hBr);
//
//		DeleteObject(hBr);
//		// draw main part of display box
//		BkBox.setBottom(DiagOrigin).bottom;
//		BkBox.setTop(TtlBarHt);
//		hBr = CreateSolidBrush(MainBlue);
//
//		FillRect(hdc,&BkBox,hBr);
//
//		DeleteObject(hBr);
//		//initialise text for main information area
//		QString csTxt = QString ::fromWCharArray("");
//		QString csTxtLn2 = QString ::fromWCharArray("");
//		QString csTxtLn1 = QString ::fromWCharArray("");
//		QString csErr[6];
//		QString ErrList;
//
//
//		//txtRect will be the generic re-used box for drawing text
//		QRect TxtRect;
//
//		////get the text strings once the globals are created
//		//m_csWelcomeTxt = tr("Starting Recorder");
//
//		//iFlagID = IDB_START_LANG_UKENG;
//
//		//ErrList = pGlbSysInfo->GetStartupErrList();
//		ErrCount = 0 ;//CStringUtils::InstanceOfStr( ErrList, L"|" );
//		if (ErrCount > 0)
//		{
//			for (int i=0;i<ErrCount && i<6;i++)
//			{
//				//csErr[i] = CStringUtils::GetItemAtPos( ErrList, i );
//			}
//		}
//
//		csTxtLn1 = QString ::fromWCharArray("");
//
//		csTxtLn2 = QString ::fromWCharArray("");
//
//		//TxtRect.setleft(DiagOrigin).left+50;
//		//TxtRect.setright(DiagOrigin).right;
//		//TxtRect.setTop(DiagOrigin).top+TtlBarHt+IconHeight+(3*TxtLnSp)+(2*TxtLnHt);
//		//TxtRect.setBottom(TxtRect).top + TxtLnHt;
//
//
//
//		////Draw the icons
//		//CBitmap StageBitmap[MAX_STARTUP_SECTIONS];
//		//CBitmap LangBitmap;
//
//		//CDC cdc;
//		//cdc.Attach(hdc);
//		//CDC dcMem;
//		//dcMem.CreateCompatibleDC(&cdc);
//
//
//		////draw language icon
//		//if (iFlagID != NULL)
//		//{
//		//LangBitmap.LoadBitmap(0);
//		//BITMAP bmpInfo;
//		//LangBitmap.GetBitmap(&bmpInfo);
//
//		//if (bmpInfo.bmHeight <= TtlBarHt)
//		//	BkBox.setTop(DiagOrigin).top + ((TtlBarHt - bmpInfo.bmHeight)/2);
//		//else 
//		//	BkBox.setTop(DiagOrigin).top;
//		//BkBox.setleft(DiagOrigin).left + (BoxWidth - (bmpInfo.bmWidth +1));
//		//// Select the bitmap into the in-memory DC.
//		//CBitmap *pOldBitmap=dcMem.SelectObject(&LangBitmap);
//
//		//// Copy the bits from the in-memory DC into the on-screen DC to actually do the painting.
//
//		//cdc.BitBlt(BkBox.left, BkBox.top, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY);
//		//
//		//// Restore the original bitmap.
//		//dcMem.SelectObject(pOldBitmap); 
//
//		//}
//		//BkBox.setTop(DiagOrigin).top+TtlBarHt+3;
//		//for (int i=0;i<MAX_STARTUP_SECTIONS;i++)
//		//{
//		//	int ofset;
//		//	if (i<iSection)
//		//		ofset = 1;
//		//	else if(i>iSection)
//		//		ofset = 2;
//		//	else
//		//		ofset = 0;
//		//	if (StageBitmap[i].LoadBitmap(IDB_START_STARTUP_DOING + (i*3) + ofset))
//		//	{
//		//		BITMAP bmpInfo;
//		//		StageBitmap[i].GetBitmap(&bmpInfo);
//		//		LightSep = (BoxWidth - (LightMargin*2) - (bmpInfo.bmWidth*MAX_STARTUP_SECTIONS))/(MAX_STARTUP_SECTIONS-1);
//		//		BkBox.setleft(DiagOrigin).left+((bmpInfo.bmWidth+LightSep)*i)+LightMargin;
//
//		//		// Select the bitmap into the in-memory DC.
//		//		CBitmap *pOldBitmap=dcMem.SelectObject(&StageBitmap[i]);
//
//		//		// Copy the bits from the in-memory DC into the on-screen DC to actually do the painting.
//
//		//		cdc.BitBlt(BkBox.left, BkBox.top, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMem, 0, 0, SRCCOPY);
//		//		
//		//		// Restore the original bitmap.
//		//		dcMem.SelectObject(pOldBitmap); 
//
//		//	}
//		//}
//		//cdc.Detach();
//		//dcMem.DeleteDC();
//
//
//		if (ErrCount > 0)
//		{
//			///@todo draw the persistant information box. e.g. messages which should stay on for 
//			//more than a fraction of a second
//			BkBox.setleft(DiagOrigin).left+ErrBoxInd;
//			BkBox.setTop(DiagOrigin).top+ErrBoxTop;
//			BkBox.setright(DiagOrigin).right-ErrBoxInd;
//			BkBox.setBottom(DiagOrigin).bottom-ErrBoxInd;
//
//			hBr = CreateSolidBrush(ErrorBlue);
//			FillRect(hdc,&BkBox,hBr);
//			DeleteObject(hBr);
//
//			TxtRect.setTop(BkBox).top;
//			TxtRect.setBottom(TxtRect).top + TxtLnHt;
//			TxtRect.setleft(BkBox).left + 5;
//			TxtRect.setright(BkBox).right - 5;
//
//			//reset to default font with a dark text
//			SetTextColor(hdc,BlackText); 
//			SelectObject (hdc, hfont);
//
//
//			for (int i=0;i<ErrCount && i< 6;i++)
//			{
//				DrawText(hdc, csErr[i],-1,&TxtRect,DT_SINGLELINE|DT_LEFT);
//				TxtRect.setTop(TxtLnHt);
//				TxtRect.setBottom(TxtLnHt);
//			}
//		}
//
//
//		// Draw the MOTD text
//		TxtRect.setTop(DiagOrigin).top;
//		TxtRect.setBottom(DiagOrigin).top +TtlBarHt;
//		TxtRect.setleft(DiagOrigin).left +20;
//		TxtRect.setright(DiagOrigin).right;
//
//		SetTextColor(hdc,BlueText);
//		SelectObject (hdc, titleFont);
//
//		DrawText(hdc, L"Welcome",-1,&TxtRect,DT_SINGLELINE|DT_LEFT|DT_VCENTER);
//
//		//reset to default font with a dark text
//		SetTextColor(hdc,BlackText); 
//		SelectObject (hdc, hfont);
//
//
//
//		//draw the three main text display boxes
//		TxtRect.setleft(DiagOrigin).left+50;
//		TxtRect.setright(DiagOrigin).right;
//		TxtRect.setTop(DiagOrigin).top+TtlBarHt+IconHeight+TxtLnSp;
//		TxtRect.setBottom(TxtRect).top + TxtLnHt;
//		//text 1
//		DrawText(hdc, csTxt,-1,&TxtRect,DT_SINGLELINE|DT_LEFT);
//
//		TxtRect.setTop(TxtLnHt)+TxtLnSp;
//		TxtRect.setBottom(TxtRect).top + TxtLnHt;
//		//Text 2
//		DrawText(hdc, csTxtLn1,-1,&TxtRect,DT_SINGLELINE|DT_LEFT);
//
//		TxtRect.setTop(TxtLnHt)+TxtLnSp;
//		TxtRect.setBottom(TxtRect).top + TxtLnHt;
//		//Text 3
//		DrawText(hdc, csTxtLn2,-1,&TxtRect,DT_SINGLELINE|DT_LEFT);
//
//		//pfc->ReleaseFont(titleFont);
//		//SelectObject (hdc, hOldfont);
//		//pfc->ReleaseFont(hfont);
//
//		SetBkMode(hdc,OPAQUE);
//		m_pDDSBackBuffer->ReleaseDC(hdc);
//
//
//		// this blt is done in conjunction with our directdraw clipper
//		// so will avoid any dialogs/menus etc.
//		//CURSOR_OFF;
//		//E437415
//		//DDBLT_WAIT flag is no longer supported for windows embedded ce 6.0
//		//Use DDBLT_WAITNOTBUSY instead of DDBLT_WAIT in following statement
//		//E519766
//		hres = m_pDDSPrimary->Blt(&m_DesktopRect, m_pDDSBackBuffer, &screenRect, DDBLT_WAITNOTBUSY, NULL);		
//
//		//CURSOR_ON;
//	}
//}
//
//
//****************************************************************************
///
///	Move selected object or widget by given amount
///
/// @param[in] ptOffset	- x and y offsets to move object or widget
///
//****************************************************************************
void COpPanel::MoveObjectOrWidget(QPoint ptOffset) {
	if (m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget) {
		// Move selected object or widget by given amount.
		QPoint pt; // will be ptOffset away from starting point
		if (m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject) {
			QRect rcObject(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->GetBounds());
			pt = rcObject.CenterPoint();
		} else {
			QRect rcWidget(m_pActiveScreen->m_pSelectedWidget->GetWidgetBounds());
			pt = rcWidget.CenterPoint();
		}
		// Simulate the user dragging the object or widget to move it.
		// If the user wishes to move a widget, then we have to make sure
		// that the LButtonDown on the widget doesn't select an object
		// inside the widget, else the object would be moved instead of
		// the widget. We also have to prevent a handle of an object or
		// widget that is being moved from being hit.
		m_bUpdateLayoutItemSelected = FALSE;
		BOOL bOldStickyWidgets = m_bStickyWidgets;
		m_bStickyWidgets = FALSE;
		if (m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject)
			m_eSimulatedMove = SIMULATED_MOVE_OBJECT;
		else
			m_eSimulatedMove = SIMULATED_MOVE_WIDGET;
		// Pass the Ctrl key state to OnLButtonDown/OnMouseMove/
		// OnLButtonUp for completeness (used just by OnLButtonDown
		// for now). Holding the Ctrl key down will move the widget
		// regardless if an object in the widget is selected.
		UINT uKeys = 0;
		if (::GetKeyState(VK_CONTROL) < 0 || m_bExpertMode == FALSE) // Ctrl key down or not in expert mode
			uKeys = MK_CONTROL;
		OnLButtonDown(MK_LBUTTON | uKeys, pt);
		m_eSimulatedMove = SIMULATED_MOVE_NONE;
		m_bUpdateLayoutItemSelected = TRUE;
		pt.Offset(ptOffset);
		OnMouseMove(MK_LBUTTON | uKeys, pt);
		OnLButtonUp(uKeys, pt); // handles checkpoint
		m_bStickyWidgets = bOldStickyWidgets;
	}
}
//****************************************************************************
///
///	Resize selected object or widget by given amount
///
/// @param[in] ptOffset	- x and y offsets to resize object or widget
///
//****************************************************************************
void COpPanel::ResizeObjectOrWidget(QPoint ptOffset) {
	if (m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget) {
		// Resize selected object or widget by given amount.
		QPoint pt; // drag the Bottomright point to resize
		if (m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject) {
			QRect rcObject(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->GetBounds());
			pt = rcObject.Bottomright();
		} else {
			QRect rcWidget(m_pActiveScreen->m_pSelectedWidget->GetWidgetBounds());
			pt = rcWidget.Bottomright();
		}
		// Don't use the extreme Bottomright point because
		// if we used it to resize an object to the widget's
		// edge, then the point will no longer be in the
		// widget's bounds and the widget becomes unselected
		// in CScreen::OnMouseDown (see the PtInRect test).
		pt.Offset(-1, -1);
		// Simulate the user dragging the object's or
		// widget's Bottomright point (handle) to resize it.
		m_bUpdateLayoutItemSelected = FALSE;
		BOOL bOldStickyWidgets = m_bStickyWidgets;
		m_bStickyWidgets = FALSE;
		// Pass the Ctrl key state to OnLButtonDown/OnMouseMove/
		// OnLButtonUp for completeness (used just by OnLButtonDown
		// for now). Holding the Ctrl key down will resize the widget
		// regardless if an object in the widget is selected.
		UINT uKeys = 0;
		if (::GetKeyState(VK_CONTROL) < 0) // Ctrl key down or not in expert mode
			uKeys = MK_CONTROL;
		OnLButtonDown(MK_LBUTTON | uKeys, pt);
		m_bUpdateLayoutItemSelected = TRUE;
		pt.Offset(ptOffset);
		OnMouseMove(MK_LBUTTON | uKeys, pt);
		OnLButtonUp(uKeys, pt); // handles checkpoint
		m_bStickyWidgets = bOldStickyWidgets;
	}
}
T_MESSAGE_FILTER GetMsgType(USHORT msgType) {
	T_MESSAGE_FILTER msg = mfAll;
	switch (msgType) {
	case 0:
		msg = mfAll;
		break;
	case 1:
		msg = mfAlarm;
		break;
	case 2:
		msg = mfSystem;
		break;
	case 3:
		msg = mfDiagnostic;
		break;
	case 4:
		msg = mfSecurity;
		break;
	case 5:
		msg = mfUser;
		break;
	}
	return msg;
	/*mfAlarm			= 0x01,
	 mfSystem		= 0x02,
	 mfDiagnostic	= 0x04,
	 mfSecurity		= 0x08,
	 mfUser			= 0x10,
	 mfSMTP			= 0x20,
	 mfFTP			= 0x40,
	 mfP2P			= 0x80,*/
}
//****************************************************************************
///
///	Window Procedure Callback for for OpPanel Window
/// If the message is handled the function can return at that point, or drop
/// through to where OnWndMsg will be called (message map entries) and if still
/// not handled will call DefWindowProc.
///
/// @param[in] message	- windows message to process
/// @param[in] wParam	- parameter 1
/// @param[in] lParam	- parameter 2
///
/// @return 0/1 depending upon message processing
/// 
//****************************************************************************
LRESULT COpPanel::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	static int nWidgetCount = 0;
	switch (message) {
	case WM_APP + 46: {
		UCHAR *pBuff = (UCHAR*) wParam;
		InfoLogBuff(pBuff, (int) lParam);
		delete[] pBuff;
		break;
	}
	case WM_ERASEBKGND: // if you move a dialog over our widgets, you get these occurring.							
		return 1; // say we handled it! 
	case WM_PAINT: {
		//OutputDebugString(L"WM_Paint received\n");
		// NB: WM_PAINT on receivd for a full screen repaint.
		// Refresh is done separately.
		QRect updaterect;
		if (GetUpdateRect(&updaterect, FALSE)) {
#ifndef V6IOTEST
#ifndef DOCVIEW // Recorder
			/*		updaterect.setTop(32);
			 updaterect.setBottom(240);
			 updaterect.setright(320);*/
			// If the recorder is in process screen then upodate the current screen, otherwise show the BlankScreen
			if (GetMode() == OPPANEL_MODE_PROCESS_SCREENS) {
				if (m_CritSec.TryLock()) {
					if ((m_pActiveScreen) && (m_pActiveScreen->m_pCMMscreen->Enabled)
							&& !m_pActiveScreen->IsNonProcessScreen())
						m_pActiveScreen->DrawScreen(&updaterect);
					m_CritSec.Unlock();
				}
			} else if (GetMode() == OPPANEL_MODE_NON_PROCESS_SCREENS) {
				BlankScreen();
				// :, some times when dialogs are destryed Repaint is called so we need to repaint non process screen if it is not already displayed
				QRect rc;
				GetClientRect(&rc);
				if ((rc.Width() == updaterect.right - updaterect.left) && (rc.Height() == updaterect.bottom)) {
					CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
					// Display non process screen if it is not already displyed....
					if (pkStatusBar)
						pkStatusBar->RepaintNonProcessScreen(m_pActiveScreen->m_pCMMscreen->Type);
				}
			} else {
				BlankScreen();
				m_RotateBaseTime.TimeNow();	// on exiting menu rotating will resume after normal rotate time delay
				m_DoScreenMove = TRUE; // on exit show the status bar (and move the window)
				m_MoveScreenTick = GetTickCount();
			}
#else // Screen desinger
									
				if(m_CritSec.TryLock())
				{
					if(m_pActiveScreen)
						m_pActiveScreen->DrawScreen(&updaterect);
					m_CritSec.Unlock();	
				}
#endif
#endif
		}
		// Call test method to calculate EUDC attributes.
		//if(m_bCalculateEUDCAttributes)
		//{
		//	CalculateEUDCAttributes();
		//	m_bCalculateEUDCAttributes=FALSE;
		//}
		// do default processing (validates the update region)
		//LRESULT val = DefWindowProc(message,wParam, lParam);
		//return val;
		return DefWindowProc(message, wParam, lParam);
	}
		/*
		 case WM_OPPANEL_REFRESH:
		 {
		 MSG msg;
		 while(::PeekMessage(&msg,m_hWnd,WM_OPPANEL_REFRESH,WM_OPPANEL_REFRESH,PM_REMOVE));
		 
		 
		 while(::PeekMessage(&msg,m_hWnd,WM_KEYDOWN,WM_KEYDOWN,PM_REMOVE)||
		 ::PeekMessage(&msg,m_hWnd,WM_MOUSEFIRST,WM_MOUSELAST,PM_REMOVE))
		 {
		 TranslateMessage(&msg);
		 DispatchMessage(&msg);
		 }
		 // do refresh here
		 return 0;
		 }
		 */
#ifndef DOCVIEW
#ifndef V6IOTEST
	case WM_TIMER: {
		if (wParam != StartupTimerId)
			KillTimer(wParam);
		else {
			if (GetMode() == OPPANEL_MODE_PROCESS_SCREENS || GetMode() == OPPANEL_MODE_NON_PROCESS_SCREENS) {
				if (pSYSTEM_INFO->IsInHotSoakTestMode()) {
#ifdef _DEBUG
						// These should not be set for hotsoak
						if((m_pCMMlayout->RotateScreens)||(m_pCMMlayout->RotateTime!=10)||(m_pCMMlayout->ManIntervTime!=20))						
							qDebug("LAYOUT CORRUPTION!\n");						
#endif												
					RefreshHotSoakScreen();
				}
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance(this);
				if ((!pkStatusBar->IsControlBarInUse()) && // don't rotate screens while pop up status control is visible				
						(!pkStatusBar->IsMenuSystemInUse()) && // don't rotate screens while in the menu system (prob not required)
						(m_EditMode == RUN_MODE) &&				 // don't rotate screens in designer mode
						(m_pReplayScreen == NULL))				 // don't rotate screens in replay mode  
						{
					if (RotateScreen())	// rotate screen if time to do so (or alarm screen if active)
						;
					else {
						// if the current screen has no status bar and the timer has expired we remove the status bar
						// we do not want to do this in replay mode or whilst pop-up status control is visible
						// Elsewhere (in SetCurrentScreen) the status bar is shown hidden abruptly (on a change of screen) but here
						// we are viewing the screen and it slides the status bar in and out.
						if (m_pActiveScreen && m_pActiveScreen->m_pCMMscreen->Enabled && m_pActiveScreen->m_pTemplate
								&& (m_pActiveScreen->m_pTemplate->m_pCMMtemplate->StatusBar == FALSE)) {
							// if we are not showing the status bar and we get an alarm
							if (pALARM_OVERVIEW->GetNumberOfAlarmsInAlarm() != 0) {
								if (m_DoScreenMove == FALSE) {
									// show the status bar and move the screen down accordingly
									m_DoScreenMove = TRUE;
									CTopStatusBar::Instance(this)->SetVisibleSlide(TRUE);
									Repaint();
								}
								m_MoveScreenTick = GetTickCount(); // reset for when alarm ends
							} else if (m_DoScreenMove
									&& (GetTickCount() - m_MoveScreenTick > m_pCMMlayout->StatBarTimeout * 1000)) // to millisec
									{
								m_DoScreenMove = FALSE;
								if (!m_pActiveScreen->IsNonProcessScreen()) {
									//Do not draw non process screens
									m_pActiveScreen->ConfigChange(); // to ensure perm surfaces get updated etc
									// here repaint all in new position
									if (m_CritSec.TryLock()) {
										m_pActiveScreen->DrawScreen(&m_pActiveScreen->m_ScreenClientRect); // whole screen redraw at new position
										m_CritSec.Unlock();
									}
								}
								CTopStatusBar::Instance(this)->SetVisibleSlide(FALSE); // repaints as it goes																
							}
						}
					}
				} else {
					m_RotateBaseTime.TimeNow(); // reset the rotate time here
					// and apply manual interval timeout before rotate
					if (m_pCMMlayout)
						m_RotateBaseTime += SECS_TO_MICROS * (m_pCMMlayout->ManIntervTime - m_pCMMlayout->RotateTime); // will be ManIntervTime secs before a rotate
					m_MoveScreenTick = GetTickCount(); //reset
				}
				Refresh();			// Refresh OpPanel process screens
				if (GetTickCount() - Glb_MouseTick > MOUSE_INACTIVITY_MSEC)
					Glb_MouseOn = FALSE;
			} else {
				BlankScreen();	// Not in process screens show blank		
				m_RotateBaseTime.TimeNow();	// on exiting menu rotating will resume after normal rotate time delay
				m_DoScreenMove = TRUE; // on exit show the status bar (and move the window)
				m_MoveScreenTick = GetTickCount();
			}
			// m_IsDrawing flag should NOT be set here!
			if ((m_IsDrawing) || (m_ResetDDrequired)) {
				// we need to reset everything here
				Destroy(); // deletes screens, templates, objects etc. (including any private surfaces)
				ReleaseDDobjects();
				InitDirectDraw(); // then re-initialise everything
				SetConfiguration(m_pMainConfig); // then recreate screens again
				m_IsDrawing = 0;
				m_Inactive = 0;
				m_CritSec.Reset(); // and reset lock too.
				CChartQManager *CM = CChartQManager::GetHandle();
				CM->Unlock(); // ensure this is unlocked too otherwise data processing gets blocked
			}
		}
		return 1;
	}
#endif
#endif
	case WM_INIT_OPPANEL: {
		// this message is received from the Control Sequencer when it is ready for the OpPanel to register with it.
		Register();
		g_hWnd = this->m_hWnd;
#if IS_RECORDER==1
		CTopStatusBar::Instance(this);		// Initialise the Status Bar dialog singleton
#endif
		// Retreive last screen number from NV
		m_CurrentScreenNumber = pNV_VARS->GetBasicVarNVObject(NVV_CURRENT_SCREEN)->GetFromNV()->value.ul;
		if (m_CurrentScreenNumber == 0) {
			// Screen number was 0, NV set for first time
			m_CurrentScreenNumber = 1;
		}
		m_pControlSeq = (CControlSequencer*) wParam;
		if (pDALGLB->GetDeviceType() == DEV_ARISTOS_MULTIPLUS)
			Glb_FontHeight = 11 * 1.28;
		else if ( pDALGLB->GetDeviceType() == DEV_ARISTOS_MINITREND)
			Glb_FontHeight = 11 * 1.25;
		return 0;
	}
	case WM_OPPANEL_UPDATE_TUS_SCRN: {
		RebuildTUSScreen();
		return 0;
	}
	case WM_OPPANEL_ZOOM_IN_VIEW_TUS_SCRN: {
		// we need to zoom into the passed in zero and span
		ZoomInTUSYScale((float) (wParam), (float) (lParam));
		return 0;
	}
	case WM_OPPANEL_NORMAL_VIEW_TUS_SCRN: {
		// we need to return back to the normal zoom level
		RestoreNormalTUSYScale();
		return 0;
	}
	case WM_OPPANEL_SETCONFIGURATION: {
		// here a new layout has been loaded up into the system layout config or a change has been made	
		SetConfiguration((CLayoutConfiguration*) wParam, (BOOL) lParam);
		m_pV6Module->SetupConfigChangeComplete();
#ifndef DOCVIEW
#ifndef V6IOTEST
		CTopStatusBar::Instance(this)->MoveStatusBar();
#endif
#endif
		return 0;
	}
	case WM_OPPANEL_CONFIGCHANGECOMPLETE: {
		m_IsSetupConfigChange = TRUE;
		m_pV6Module->SetupConfigChangeComplete();
		m_IsSetupConfigChange = FALSE;
		return 0;
	}
	case WM_OPPANEL_SETCFGN_DESMODE: {
		// here we have entered/left designer mode and want to synchronise with drawing.
		SetConfiguration((CLayoutConfiguration*) wParam, (BOOL) lParam);
		return 0;
	}
	case WM_SHOW_OPPANEL: {
		if (m_pActiveScreen)
			SetMode(OPPANEL_MODE_PROCESS_SCREENS);
#ifdef UNDER_CE	
			CURSOR_OFF;
			SetWindowPos(&wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW);
#endif
#if IS_RECORDER==1
//			SetCurrentScreen( m_CurrentScreenNumber ); 
		CTopStatusBar::Instance(this)->ShowStatusBar();
#endif
		Invalidate();
		UpdateWindow();
		return 0;
	}
	case WM_OPPANEL_REPAINT: {
		Invalidate();
		UpdateWindow();
		return 0;
	}
	case WM_OPPANEL_PAUSE_CHARTS: {
		CChartQManager *CM = CChartQManager::GetHandle();
		CM->PauseCharts(static_cast< USHORT >(wParam));
		return 0;
	}
	case WM_OPPANEL_STOP_CHARTS: {
		CChartQManager *CM = CChartQManager::GetHandle();
		//added by nilesh for Displaying Chart Start/Stop Messages
		//[
		if (m_pCMMlayout->ShowStrtStopMsg)
			CM->StopCharts();
		else
			CM->StopCharts( FALSE);
		//]
		return 0;
	}
	case WM_OPPANEL_RESUME_CHARTS: {
		// resume - for either stopped or paused
		CChartQManager *CM = CChartQManager::GetHandle();
		CM->ResumeCharts(static_cast< USHORT >(wParam));
		return 0;
	}
	case WM_OPPANEL_CLEAR_CHARTS: {
		CChartQManager *CM = CChartQManager::GetHandle();
		CM->EmptyQueues();
		ConfigChange(); // to reset the widget background
		Invalidate(); // force a repaint of everything
		UpdateWindow();
		return 0;
	}
#ifndef DOCVIEW
#ifndef V6IOTEST
	case WM_OPPANEL_CLEARMESSAGELIST: {
		// now set the on-going tick point for which we should no longer retrieve earlier 
		// messages from
		LONGLONG llOldestMessageTime = 0;
		CChartQManager *pkCM = CChartQManager::GetHandle();
		// if stopped, all messages are added at same tick for display purposes
		if (pkCM->IsChartsStopped()) {
			llOldestMessageTime = pkCM->GetStoppedTime() - 1;
		} else {
			llOldestMessageTime = pSYSTIMER->GetOnGoingProcessTick() - 1;
		}
		USHORT msgTye = (USHORT) wParam; // 
		T_MESSAGE_FILTER msg_t = GetMsgType(msgTye);
		// clear the message list
		CMessageListDlg::ClearMessageList(llOldestMessageTime, msg_t);
		// check if the message list window is on display
		if (CMessageListDlg::ms_pkThisWindow != NULL) {
			::SendMessage(CMessageListDlg::ms_pkThisWindow->m_hWnd, WM_MSGLISTDLG_CLEARMSGLIST, NULL, NULL);
		}
		// 
		// This msg says cleared all messages on an event.... 
		// we need to add string that says specific types of msgs are cleared...
		// as we have modified event effects to allow all msgs of specfied type...
		QString strMessage("");
		strMessage = tr("All message lists cleared by an event");
		LOG_USER_MESSAGE(MSGLISTSER_USER_GROUP_CLEAR_MESSAGE_LIST, strMessage);
		return 0;
	}
#endif
#endif
	case WM_OPPANEL_PREFILL_CHARTS: {
		CChartQManager *CM = CChartQManager::GetHandle();
		CM->PrefillQueues();
		ConfigChange(); // to reset the widget background
		Invalidate(); // force a repaint of everything
		UpdateWindow();
		return 0;
	}
	case WM_OPPANEL_RECONFIGCHARTS: {
		CChartQManager *CM = CChartQManager::GetHandle();
		CM->ReadyCharts(); // ready to reconfigure
		ConfigChange();
		Invalidate(); // must repaint after a config change
		UpdateWindow();
		//added by nilesh for Displaying Chart Start/Stop Messages
		//[
		if (m_pCMMlayout->ShowStrtStopMsg)
			CM->DoneCharts(); // done the reconfigure
		else
			CM->DoneCharts(FALSE); // done the reconfigure
		//]
		return 0;
	}
	case WM_INTERNAL_MESSAGE_AVIALABLE: {
		CChartQManager *CM = CChartQManager::GetHandle();
		const CInternalMessage *pkMsg = m_pInternalMessageQueue->ReadInternalMessage();
		if (pkMsg != NULL) {
			CM->DataUpdate(pkMsg);
		}
		m_pInternalMessageQueue->RemoveInternalMessage();
		return 0;
	}
	case WM_OPPANEL_SHOW_SCREENLIST:
		// show the screen list
		ShowScreenList();
		return 0;
	case WM_OPPANEL_SHOW_PRINT_ERROR: {
		if ( pDALGLB->IsRecorderPCorEmbedded()) {
			// show the restart dialog
			QString strTitle("");
			QString strMessage("");
			strTitle = tr("Print Error");
			QString strPortName("");
			CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
			T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
			strPortName = ptGeneralData->Printer.deviceName;
			// show the relevant message depending on whether the printer is local or networked
			if (strPortName.indexOf(L"\\\\") == -1) {
				strMessage = tr("Please check the printer is connected and the settings are correct.");
			} else {
				strMessage =
						tr(
								"Please check the printer is connected and the printer and network admin settings are correct.");
			}
			ShowErrorDialog(strTitle, strMessage, this);
		}
		return 0L;
	}
	case WM_DELETE_SCREEN: {
		// delete the screen of the index number indicated by wParam
		const USHORT usDELETED_SCREEN_INDEX = static_cast< USHORT >(wParam);
		USHORT usScreenCount = 0;
		CScreen *pkScreen = this->m_pScreens;
		// loop through the screens until we find the nth one
		while ((pkScreen != NULL) && (usScreenCount != usDELETED_SCREEN_INDEX)) {
			// get the next screen and move on the count
			pkScreen = pkScreen->m_pNextScr;
			++usScreenCount;
		}
		// check a screen was found
		if (pkScreen != NULL) {
			// screen found okay
			T_LAYOUTITEM ptDeleteScreenLytData = pkScreen->GetLayoutItem();
			// only delete the screen if it is not the TUS screen
			if (pkScreen->m_pCMMscreen->Type != TPL_AMS2750_TUS_SCREEN) {
				DeleteScreen(&ptDeleteScreenLytData); // from the MAIN config
			}
			Invalidate();
			UpdateWindow();
		} else {
			// should not happen so trace an error message out
			LOG_ERR( TRACE_OPPANEL, "OpPanel could not find which screen the user wanted to delete");
		}
		return 0L;
	}
	case WM_CHANGE_SCREEN_SETTINGS: {
		// see what the required action should be
		ChangeScreenSettings();
	}
		return 0;
		// CR: 3151 Replay at Faster speed
	case WM_CHANGE_REPLAY_SCREEN_SETTINGS: {
		// see what the required action should be
		ChangeReplayScreenSettings();
	}
		return 0;
#ifndef DOCVIEW
#ifndef V6IOTEST
		//Added by Abhijeet (E519766) to handle SHOW REPLAY SCREEN message
	case WM_SHOW_REPLAY_SCREEN: {
		CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, (WPARAM) (WPARAM) TOPBAR_MODE_REPLAY, NULL);
	}
		return 0;
		//Added by Abhijeet (E519766) to handle EXIT REPLAY SCREEN message
	case WM_EXIT_REPLAY_SCREEN: {
		//added by nilesh for screen change issue
		//[
		if (m_pReplayScreen) {
			CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
			pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, (WPARAM) TOPBAR_MODE_NORMAL, NULL);
			ExitReplayScreen(); // tell OpPanel to exit replay
		}
		//added by nilesh for screen change issue
		//[
		if (!m_pReplayScreen) // only if not in replay
			m_DoScreenMove = TRUE; // want to see status bar and move screen on a change
		//]
		//]
		//ExitReplayScreen();
	}
		return 0;
	case WM_OPPANEL_JUMP_TO_REPLAY: {
		// wParam and lParam contain the messageID of the message to jump to. keep for later
		m_JumpId.HighPart = (LONG) wParam;
		m_JumpId.LowPart = (DWORD) lParam;
		m_Inactive++; // increment here to prevent a repainting when the message list dialog is closed
					  // that way we will paint when in replay mode only.
		// here we need to tell the top status bar about replay mode
		CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, (WPARAM) TOPBAR_MODE_REPLAY, NULL);
		break;
	}
#endif
#endif
	case WM_DESTROY: {
		// Clean up and close the app
#ifndef DOCVIEW			
		PostQuitMessage(0);
#endif
		return 0L;
	}
	case WM_CLOSE: {
#ifndef DOCVIEW	
#ifndef V6IOTEST		
		// Closedown the status Bar
		CTopStatusBar::Instance(this)->KillStatusBar();
		SetMode(OPPANEL_MODE_SHUTDOWN);	// Indicate Op Panel is now in shutdown mode
		BlankScreen();						// Set to the blank shutdown screen
		// Signal a shutdown on control sequencer
		m_pV6Module->SignalShutdown();
#endif
#endif			
		break;
	}
	case WM_ACTIVATE:
		return DefWindowProc(message, wParam, lParam);
	case WM_OPPANEL_SCREEN_NEXT: {
		m_RotateBaseTime.TimeNow(); // reset the rotate time here
		// and apply manual interval timeout before rotate
		if (m_pCMMlayout)
			m_RotateBaseTime += SECS_TO_MICROS * (m_pCMMlayout->ManIntervTime - m_pCMMlayout->RotateTime); // will be ManIntervTime secs before a rotate
		m_DoScreenMove = TRUE; // want to see status bar and move screen on a change
		m_MoveScreenTick = GetTickCount(); //reset
#ifndef DOCVIEW	
#ifndef V6IOTEST
		CTopStatusControl *pWnd = (CTopStatusControl*) lParam;
		SetCurrentScreen(0); // next screen 
		if (GetMode() == OPPANEL_MODE_NON_PROCESS_SCREENS && pWnd != NULL) {
			if (pWnd->IsWindowVisible())
				pWnd->SetForegroundWindow();
		}
#endif
#endif
		return 0;
	}
	case WM_OPPANEL_SCREEN_PREV: {
		m_RotateBaseTime.TimeNow(); // reset the rotate time here
		// and apply manual interval timeout before rotate
		if (m_pCMMlayout)
			m_RotateBaseTime += SECS_TO_MICROS * (m_pCMMlayout->ManIntervTime - m_pCMMlayout->RotateTime); // will be ManIntervTime secs before a rotate
		m_DoScreenMove = TRUE; // want to see status bar and move screen on a change
		m_MoveScreenTick = GetTickCount(); //reset
#ifndef DOCVIEW	
#ifndef V6IOTEST
		CTopStatusControl *pWnd = (CTopStatusControl*) lParam;
		SetCurrentScreen(-1); // previous screen 
		if (GetMode() == OPPANEL_MODE_NON_PROCESS_SCREENS && pWnd != NULL) {
			if (pWnd->IsWindowVisible())
				pWnd->SetForegroundWindow();
		}
#endif
#endif
		return 0;
	}
#ifndef DOCVIEW
#ifndef V6IOTEST
	case WM_OPPANEL_SET_TO_SCREEN_NO: {
		//added by nilesh for screen change issue
		//[
		if (m_pReplayScreen) {
			CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
			pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, (WPARAM) TOPBAR_MODE_NORMAL, NULL);
			ExitReplayScreen(); // tell OpPanel to exit replay
		}
		//]
		// change screen to a specific number - could be triggered by an event
		m_RotateBaseTime.TimeNow(); //will resume after normal rotate time delay
		//added by nilesh for screen change issue
		//[
		if (!m_pReplayScreen) // only if not in replay
			m_DoScreenMove = TRUE; // want to see status bar and move screen on a change
		//]
		m_MoveScreenTick = GetTickCount(); //reset
		SetCurrentScreen(static_cast< USHORT >(wParam));
		return 0;
	}
	case WM_OPPANEL_PRINT_SCREEN: {
		// only do an automated print screen if the menu system isn't in use
		CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
		if (!pkStatusBar->IsMenuSystemInUse()) {
			QString strTitle("");
			if (m_pActiveScreen != NULL) {
				strTitle = m_pActiveScreen->m_pCMMscreen->Name;
			}
			// check if we are supposed to be printing or saving a screenshot
			if (wParam == pcePRINTER) {
				CPrinter kPrinter;
				kPrinter.OnPrintScreen(strTitle, false);
			} else {
				// update the media information
				CMediaManager *pkMediaManager = CMediaManager::GetHandle();
				CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();
				// now add the path
				WCHAR wcaPath[ MAX_PATH] = { 0 };
				const T_STORAGE_DEVICE eSTORAGE_DEV = pkDeviceStatus->LogDeviceToStorageDevice(
						static_cast<T_LOG_DEVICE>(lParam));
				if (pkMediaManager->IsDeviceInserted(eSTORAGE_DEV)) {
					pDALGLB->BuildPath(eSTORAGE_DEV, IDS_ROOT, strTitle, wcaPath, MAX_PATH);
					QString strPath = wcaPath;
					// add the date and time to the bitmap name
					// this is the save dialog so make up the default name and date
					QTime kTime;
					kTime.TimeNow();
					strTitle = L" " + kTime.TimeToStringShort() + L".bmp";
					strTitle.Replace(L":", L"-");
					strPath += strTitle;
					CaptureBitmap(this, strPath, false);
					// update the free space
					pkMediaManager->CheckDevice(eSTORAGE_DEV, false);
				} else {
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							"FILE ERROR: Unable to save screenshot - external media missing");
				}
			}
		} else {
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING,
					L"The system could not print the screen because the menu system is in use");
		}
		return 0;
	}
	case WM_OPPANEL_FORCE_REBOOT: {
		// we need to force an update of the status bar - this will usually be following a config
		// change that requires a reboot
		// Notify the user that a shutdown is required
		sleep(1000);
		CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
		LPARAM lRebootParam = static_cast<LPARAM>(CTopStatusBar::slpREBOOT_PENDING);
		lRebootParam |= static_cast<LPARAM>(CTopStatusBar::slpTRIGGER_RESTART);
		// send the message to the top status bar
		::SendMessage(pkStatusBar->m_hWnd, WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_LOCK, lRebootParam);
		sleep(1000);
		pkStatusBar->Update();
	}
		break;
	case WM_SOFTBUTTON: {
		ProcessSoftButton((int) wParam, (int) lParam); // button ID and screen number
		return 0;
	}
#endif
#endif
	case WM_NOTIFY_REMOTE_DISP:
		NotifyRemoteServer((BOOL) wParam);
		break;
	case WM_LBUTTONDOWN: {
		//qDebug("In WindProc\n");
		break;// NB: here we are not returning,to allow message map handlers to be called below
	}
	case WM_RBUTTONDOWN: {
#ifndef DOCVIEW
		if ( pDALGLB != NULL) {
			pDALGLB->RegisterUserActivity();
		}
		if ((m_EditMode == DESIGNER_MODE) && m_pActiveScreen && (m_Inactive == 0)
				&& (m_pActiveScreen->m_pSelectedWidget) && (m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject)) {
			m_pActiveScreen->m_pSelectedWidget->SendObjectToBottom(
					m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject);
			Invalidate();
			UpdateWindow();
		}
#endif
		break; // NB: here we are not returning,to allow message map handlers to be called below
	}
#ifndef UNDER_CE
		// desktop case only - restrict minimum size of window.
	case WM_GETMINMAXINFO: {
		// set minimum size for complete window, 100,100
		MINMAXINFO *pMinMax = (MINMAXINFO*) lParam;
		pMinMax->ptMinTrackSize.x = 100;
		pMinMax->ptMinTrackSize.y = 100;
		return 0;
	}
		// desktop case only - resizing
	case WM_SIZE: {
		qDebug("WM_SIZE wparam %d lparam %d \n", wParam, lParam);
		if (lParam == 0) // catch any empty ones.
			break;
		// wait until any drawing is complete..
		while (m_IsDrawing)
			sleep(100);
		// then 
		ReleaseDDobjects();
		// Check to see if we are losing our window...
		if (wParam == SIZE_MAXHIDE || wParam == SIZE_MINIMIZED) {
			qDebug("minimised\n");
			return 0;
		}
		// for anything else we need to reinit our DDraw stuff.
		GetClientRect(&m_DesktopRect);
		ClientToScreen(&m_DesktopRect); // convert to screen co-ords
		// keep m_ScreenWidth and m_ScreenHeight to be the actual screen size.
#ifdef DOCVIEW
			// set up the recorder screen area and offsets
			
			if( m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS )			
				SetRect(&m_RecScreenArea,0,0,ARISTOS_MULTI_SX_X,ARISTOS_MULTI_SX_Y);			
			if( m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS )			
				SetRect(&m_RecScreenArea,0,0,X_SERIES_MULTI_SX_X,X_SERIES_MULTI_SX_Y);			
			else if ( m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND )				
				SetRect(&m_RecScreenArea,0,0,ARISTOS_MINI_QX_X,ARISTOS_MINI_QX_Y);
			else if ( m_pMainConfig->GetRecorderType() == DEV_EZTREND || m_pMainConfig->GetRecorderType() == DEV_XS_MINITREND)				
				SetRect(&m_RecScreenArea,0,0,ARISTOS_MINI_EZ_X,ARISTOS_MINI_EZ_Y);
			
			
			
			// position the recorder screen area in the middle...
			// ...but only if we haven't scrolled yet
			CScrollBar *phorz=GetScrollBarCtrl(SB_HORZ);
			CScrollBar *pvert=GetScrollBarCtrl(SB_VERT);
			if(phorz->GetScrollPos()==0 && pvert->GetScrollPos()==0)
			{
				int diffx=_Width(m_DesktopRect)-_Width(m_RecScreenArea);
				int diffy=_Height(m_DesktopRect)-_Height(m_RecScreenArea);
				m_RecScreenOffset.x=diffx/2;
				m_RecScreenOffset.y=diffy/2;
				if(m_RecScreenOffset.x<0)
					m_RecScreenOffset.x=0;
				if(m_RecScreenOffset.y<0)
					m_RecScreenOffset.y=0;
				m_InitialRecScreenOffset=m_RecScreenOffset;
			}
			
			
			OffsetRect(&m_RecScreenArea,m_RecScreenOffset.x,m_RecScreenOffset.y);

#endif
		InitDirectDraw(); // then re-initialise everything
		ConfigChange();
	}
		break;
		// desktop case only - window has moved
	case WM_MOVE: {
		GetClientRect(&m_DesktopRect);
		ClientToScreen(&m_DesktopRect); // convert to screen co-ords
#if IS_RECORDER==1
		if (m_pActiveScreen)
			CTopStatusBar::Instance(this)->MoveStatusBar();
#endif
		return 0;
	}
#endif
	case WM_KEYDOWN: {
		// Handle any non-accelerated key commands
		if ( pDALGLB != NULL) {
			pDALGLB->RegisterUserActivity();
		}
/////////// GENERAL KEY PRESSES (ALL MODES) HERE ////////////////////////////////
		switch (wParam) {
		case 'C': // Toggle see clipping/update regions
		{
			if (V6_RELEASE != RELEASE_PRODUCTION) // in non-production builds only
					{
				Glb_SeeRegions = !Glb_SeeRegions;
				return 0;
			}
			break;
		}
#ifdef DOCVIEW
				case 'G':
				{
			//		CBrowseDibsDlg bdlg(NULL,FALSE);
			//		bdlg.exec();
/*				
					// test colours here...
					int totdiff=0; 
					for(int r=0; r<255; r+=5)
						for(int g=0; g<255; g+=5)
							for(int b=0; b<255; b+=5)
							{
								COLORREF rgb=QString (r,g,b);
								USHORT rgb565=RGBtoRGB565(rgb);
								COLORREF result=RGB565toRGB(rgb565);
								if(result!=rgb)
								{
									BYTE resred=GetRValue(result);
									BYTE resgreen=GetGValue(result);
									BYTE resblue=GetBValue(result);
									int diffr=abs(resred-r);
									int diffg=abs(resgreen-g);
									int diffb=abs(resblue-b);
									qDebug("diff %d %d %d \n",diffr,diffg,diffb);
									totdiff+=(diffr+diffg+diffb);
								}
							}
						qDebug("Total diff %d\n",totdiff);
*/

					return 0;
				}
#endif
#ifndef DOCVIEW			
// NOT FOR SCREEN DESIGNER...
		case VK_ESCAPE: {
			if (V6_RELEASE != RELEASE_PRODUCTION) {
				// Only allow escape key to fucntion in non-production builds
				PostMessage(WM_CLOSE, 0, 0);
				return 0L;
			}
			break;
		}
		case 'Y': {
			if (V6_RELEASE != RELEASE_PRODUCTION) // in non-production builds only
					{
				WCHAR buffy[200];
				swprintf(buffy, L"Inactive flag=%d\n drawing flag=%d\n DD inits=%d", m_Inactive, m_IsDrawing,
						m_InitCount);
				CV6MessageBoxDlg kDlg(L" mode info", buffy, this);
				kDlg.exec();
				return 0;
			}
			break;
		}
			/*
			 case 'S':
			 {
			 m_pControlSeq->TrainingStop();
			 
			 
			 return 0;
			 }
			 case 'G':
			 {
			 m_pControlSeq->TrainingReStart();
			 
			 return 0;
			 }				
			 */
			/*				
			 case 'Z':
			 {
			 Destroy(); // deletes screens, templates, objects etc. (including any private surfaces)
			 ReleaseDDobjects(); 
			 InitDirectDraw(); // then re-initialise everything
			 SetConfiguration(m_pMainConfig); // then recreate screens again
			 m_IsDrawing=0; // reset it here.
			 m_Inactive=0;
			 m_CritSec.Reset(); // and reset lock too.
			 return 0;
			 }
			 */
			/*
			 case 'S':
			 {					  
			 
			 int baseobjectsize=sizeof(CBaseObject)+sizeof(T_BASEOBJECT);
			 int digitalsize=sizeof(CDigitalObject)+sizeof(T_DIGITALOBJECT);
			 int textsize=sizeof(CTextObject)+sizeof(T_TEXTOBJECT);
			 int barsize=sizeof(CBarObject)+sizeof(T_BAROBJECT);
			 int chartsize=sizeof(CChartObject)+sizeof(T_CHARTOBJECT);
			 int alarmsize=sizeof(CAlarmMarkerObject)+sizeof(T_ALARMMRKROBJECT);
			 int penpointersize=sizeof(CPenPointersObject)+sizeof(T_PENPTRSOBJECT);
			 int scalesize=sizeof(CScaleObject)+sizeof(T_SCALEOBJECT);
			 
			 int widgetsize=sizeof(CWidget)+sizeof(T_WIDGET);
			 int templatesize=sizeof(CTemplate)+sizeof(T_SCRTEMPLATE);
			 int screensize=sizeof(CScreen)+sizeof(T_SCREEN);
			 int totdpm=(textsize*5)+(digitalsize*4)+widgetsize;
			 int totscreen=totdpm*32+screensize;
			 int totlay=totscreen*16;
			 qDebug("totlay %d\n",totlay);
			 return 0;
			 }
			 
			 */
#endif	// not for screen designer
		default:
			break;
		}
/////////// DESIGNER MODE ONLY KEYPRESSES HERE ////////////////////////////////
#ifdef DOCVIEW  // for now remove these kepresses from recorder until designer mode is fully implemented.
			if(m_EditMode==DESIGNER_MODE)
			{
				switch (wParam)
				{
				
					case 'W': // 'new Widget'
					{
						QRect r={20,20,60,60};
						if(AddNewWidget(m_pMainConfig,&r))
						{
#ifdef DOCVIEW
							GetDocument()->Checkpoint(_T("Add Widget"));
#endif
						}

					}
					return 0;	

					case VK_F8: // example bar
					{
						QRect r2={5,5,15,30};
						AddNewObject(m_pMainConfig,BLK_EXAMPLEBAR,&r2);
					}
					return 0;

					case VK_BACK:
					case VK_DELETE:
					{
						OnEditClear();
						return 0;
					}

					case 'B': // Bar
					{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_BAROBJECT,&r3);
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Bar"));
#endif
					}
					return 0;
					case 'D': // Digital
					{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_DIGITALOBJECT,&r3);
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Digital"));
#endif
					}
					return 0;

					case 'X': // teXt
					{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_TEXTOBJECT,&r3);
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Text"));
#endif
					}
					return 0;

					case 'E': // scalE
					{
						QRect r3={20,5,100,30};
						AddNewObject(m_pMainConfig,BLK_SCALEOBJECT,&r3);
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Scale"));
#endif
					}
					return 0;

					case 'I': // pen poInters
					{
						QRect r3={20,5,100,30};
						AddNewObject(m_pMainConfig,BLK_PENPTRSOBJECT,&r3);
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Pen Pointers"));
#endif
					}
					return 0;
					case 'M': // Alarm Marker
					{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_ALARMMRKROBJECT,&r3);
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Alarm Marker"));
#endif
					}
					return 0;

					case 191: // Chart object '/'
					{
						QRect r2={5,5,205,105};
						AddNewObject(m_pMainConfig,BLK_CHARTOBJECT,&r2);
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Chart"));
#endif						
						return 0;
					}

					case 'Z':
					{
/*
						// now prompt the user to select the bitmap....
						wchar_t szFilter[] = L"Bitmap Files (*.bmp)|*.bmp|Bitmap Files (*.dib)|*.dib||";
					 
						QString str;
						{
							CFileDialog cfd(TRUE,L".bmp",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szFilter);
							cfd.m_ofn.lpstrTitle=L"Load Bitmap";
							
							if(cfd.exec()==IDOK)
							{	
								str=cfd.GetPathName();
							}
							else
								return 0;
						
						}
						CDib *pDib=new CDib((QString )(LPCWSTR)str);
						// On screen designer, this will build the path of SDLib.bcf
						// On recorder this will build path of DefaultLayoutConfig.bcf
						WCHAR PathAndFileName[MAX_PATH];
						CBitmapCollectionFile::BuildFilename(PathAndFileName);
						{					
							CBitmapCollectionFile bcf(PathAndFileName,CBitmapCollectionFile::ReadOnlyWrite);						
							//bcf.AddDib(&pDib,m_pMainConfig->GetRecorderType(),_Width(r3),_Height(r3));
							bcf.AddDib(&pDib,m_pMainConfig->GetRecorderType());
						}
*/						
						QRect r3={20,5,80,45};
						AddNewObject(m_pMainConfig,BLK_BITMAPOBJECT,&r3);
						CBitmapObject* pSelectedObj=(CBitmapObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
//						pSelectedObj->SetUniqueID(pDib->GetBCFHeader()->UniqueID); // tie up the ID
//						pSelectedObj->SetName(pDib->GetBCFHeader()->Name);
						
						T_BITMAPOBJECT* pbase=(T_BITMAPOBJECT*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->m_pCMMbase;
						
						pbase->Base.Border.BorderUsed=TRUE;
						pbase->Base.Border.BorderWidth=1;
						pSelectedObj->ConfigChange();
						
						m_pActiveScreen->m_pSelectedWidget->m_PermValid=FALSE;
						Invalidate();
						UpdateWindow();
//						delete pDib;
						return 0;
					}

					case 'N': // buttoN
					{
						{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_BUTTONOBJECT,&r3);
						CButtonObject* pSelectedObj=(CButtonObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
						pSelectedObj->m_ButtonID = SB_CUSTOM;
						pSelectedObj->SetTextString(L"Default1");
						pSelectedObj->ConfigChange();
						}
/*
						{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_BUTTONOBJECT,&r3);
						CButtonObject* pSelectedObj=(CButtonObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
						pSelectedObj->SetTextString(L"Default2");
						pSelectedObj->m_pCMMbutton->Style=0; 
						pSelectedObj->ConfigChange();
						}

						{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_BUTTONOBJECT,&r3);
						CButtonObject* pSelectedObj=(CButtonObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
						pSelectedObj->SetTextString(L"Test Pass");
						pSelectedObj->m_pCMMbase->BackColour=QString (50,240,0);
						pSelectedObj->ConfigChange();
						}
						{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_BUTTONOBJECT,&r3);
						CButtonObject* pSelectedObj=(CButtonObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
						pSelectedObj->SetTextString(L"START");
						pSelectedObj->m_pCMMbase->BackColour=QString (0,100,240);
						pSelectedObj->ConfigChange();
						}
						{
						QRect r3={20,5,35,30};	
						AddNewObject(m_pMainConfig,BLK_BUTTONOBJECT,&r3);
						CButtonObject* pSelectedObj=(CButtonObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
						pSelectedObj->SetTextString(L"STOP");
						pSelectedObj->m_pCMMbase->BackColour=QString (0,100,240);
						pSelectedObj->ConfigChange();
						}
						{
						QRect r3={20,5,35,30};
						AddNewObject(m_pMainConfig,BLK_BUTTONOBJECT,&r3);
						CButtonObject* pSelectedObj=(CButtonObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
						pSelectedObj->SetTextString(L"Prepare for Ship");
						pSelectedObj->m_pCMMbase->BackColour=QString (0,100,240);
						pSelectedObj->ConfigChange();
						}
*/
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Button"));
#endif
					}
					return 0;
					case 'Q': // buttoN
					{
						{
							QRect r2={5,5,205,105};
							AddNewObject(m_pMainConfig,BLK_TABULAROBJECT,&r2);
							CTabularDisplayObject* pSelectedObj=(CTabularDisplayObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
							pSelectedObj->ConfigChange();
						}
#ifdef DOCVIEW
						GetDocument()->Checkpoint(_T("Add Tabular Display"));
#endif
					}
					return 0;
				
					case VK_LEFT:
					case VK_UP:
					case VK_RIGHT:
					case VK_DOWN:
					{
						QPoint ptOffset;
						switch(wParam)
						{
							case VK_LEFT:	ptOffset.x=-1; ptOffset.y= 0; break;
							case VK_UP:		ptOffset.x= 0; ptOffset.y=-1; break;
							case VK_RIGHT:	ptOffset.x= 1; ptOffset.y= 0; break;
							case VK_DOWN:	ptOffset.x= 0; ptOffset.y= 1; break;
						}
						if(::GetKeyState(VK_SHIFT) >= 0)
							MoveObjectOrWidget(ptOffset); // Shift key NOT down
						else
							ResizeObjectOrWidget(ptOffset); // Shift key down
					}
					return 0;

			
// align objects on a Widget
					case 0x6B: // align right numpad +
					{
						AlignLytItemsright();
						return 0;
					}
					case 0x6D: // align left , numpad -
					{
						AlignLytItemsleft();
						return 0;
					}
					case 0x6A: // align Top , numpad *
					{
						AlignLytItemsTop();
						return 0;
					}
					case 0x6F: // align Bottom , numpad /
					{
						AlignLytItemsBottom();
						return 0;
					}
					case 'J': // align CenterHorizontal 
					{
						AlignLytItemsCenterHorizontal();
						return 0;
					}
					case 'V': // align CenterVertical 
					{
						AlignLytItemsCenterVertical();
						return 0;
					}

		
					// these all affect individual objects/widgets selected		
					case 'U': // bUffered 
					case 'P': // primary
					case 'H': // alpha
					case 'T': // transparent
					case 'O': // opaque
					case 'R': // border on/off
					case 190: // '>' update rate / chart font height (with shift) / border width for widget
					case 188: // '<' update rate / chart font height (with shift) / border width for widget
					case 'F': // flash on/off
					case 219: // flash faster
					case 221: // flash slower
					case 'K': // linK object.
					case '7':
					case '8':
					case '9':
					case '0':
					{
						if((m_pActiveScreen) && (m_pActiveScreen->m_pSelectedWidget))
						{
							if(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject)
							{
								T_BASEOBJECT *pbase=m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->m_pCMMbase;
								if(wParam=='K')
								{
									CBaseObject* pSelectedObj=m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
									CBaseObject* pObjToBeLinked=m_pActiveScreen->m_pSelectedWidget->m_pObjects;
									if(pObjToBeLinked!=pSelectedObj)
									{
										// ok to link
										if(pSelectedObj->LinkTo(pObjToBeLinked))
										{
											//qDebug("\n>>>>>>>>>>>>>>>>>>>>>>>> Object Linked OK <<<<<<<<<<<<<<<<<<<<<<<\n");
										}
										else
										{
											LOG_ERR( TRACE_OPPANEL, "\n !!!!!! Object Linked error !!!!!!!!\n");
										}
									}
								}
								if(wParam=='U')							
									pbase->IsBuffered=TRUE;
								if(wParam=='P')							
								{
									pbase->IsBuffered=FALSE;
									pbase->IsAlphaBlend=FALSE;
									pbase->IsTransparent=FALSE;
								}
								if(wParam=='H')
								{
									pbase->IsAlphaBlend=TRUE;
									pbase->IsBuffered=TRUE;
								}
								if(wParam=='T')
								{
									pbase->IsTransparent=TRUE;
									pbase->IsBuffered=TRUE;
								}
			  
								if(wParam=='O')
								{
									pbase->IsTransparent=FALSE;
									pbase->IsBuffered=TRUE;
								}
								if(wParam=='R')
								{
									pbase->Border.BorderUsed=!pbase->Border.BorderUsed; // toggle on/off
									pbase->Border.BorderWidth=1; // set this to something reasonable.
									// used to setbounds here, now do configchange (should call setbounds within)				
									ConfigChange();
								}
								
									
								if(wParam==190)
								{
									if(::GetKeyState(VK_SHIFT) >= 0) 
									{
										// WITHOUT SHIFT KEY
										if(pbase->UpdateRate100<=1)
											pbase->UpdateRate100=5;
										else
											pbase->UpdateRate100+=5;
										ConfigChange();	
									}
									else
									{
										//WITH SHIFT KEY
										if(pbase->ObjectType==ChartObject)
										{	
											CChartObject *pco=(CChartObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
											if(pco->m_pCMMchart->FontHeight<25)
												pco->m_pCMMchart->FontHeight+=1;
											else
												pco->m_pCMMchart->FontHeight=25;
											ConfigChange();	
										}
									}
						
								}
							
								if(wParam==188)
								{
									if(::GetKeyState(VK_SHIFT) >= 0) 
									{																
										if(pbase->UpdateRate100<=5)
											pbase->UpdateRate100=1;
										else
											pbase->UpdateRate100-=5;
										ConfigChange();	
									}
									else
									{
										if(pbase->ObjectType==ChartObject)
										{	
											CChartObject *pco=(CChartObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
											
											if(pco->m_pCMMchart->FontHeight>11)
												pco->m_pCMMchart->FontHeight-=1;
											else
												pco->m_pCMMchart->FontHeight=11;
											ConfigChange();	
										}
									}
	
								}
						
							
						
								if(wParam=='F')
								{
											
									m_pDIT->attribBlockPtr(1)->Flashing=TRUE; // make attrbute block 1 have flashing ON
									if(pbase->AttrBlocks.FlashingBlk==1)
										pbase->AttrBlocks.FlashingBlk=0; // use attribute block 0 for flashing (default)
									else
										pbase->AttrBlocks.FlashingBlk=1; // use attribute block 1 for flashing
									m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->ConfigChange();	
								}
								if(wParam==219)
								{									
									if(pbase->FlashRate100>1) // set this to something reasonable.
									{
										pbase->FlashRate100--; 
										m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->ConfigChange();	
									}																		
								}
								if(wParam==221)
								{								
									if(pbase->FlashRate100<200) // set this to something reasonable.
									{
										pbase->FlashRate100++; 
										m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->ConfigChange();	
									}							
								}
				
								if(wParam=='7')
								{
									if(pbase->ObjectType==TextObject)
									{	
										CTextObject *pto=(CTextObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
										
										pto->m_pCMMtext->Wordwrap=!pto->m_pCMMtext->Wordwrap;
										pto->ConfigChange();
									}
								}
								if(wParam=='8')
								{
									if(pbase->ObjectType==TextObject)
									{	
										CTextObject *pto=(CTextObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
										
										pto->m_pCMMtext->Center=!pto->m_pCMMtext->Center;
										pto->ConfigChange();
									}
								}

								if(wParam=='9')
								{
									if(pbase->ObjectType==TextObject)
									{	
										CTextObject *pto=(CTextObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
										if(pto->m_pCMMtext->Font.Height>5)
											pto->m_pCMMtext->Font.Height--;
										pto->ConfigChange();
									}
								}
								if(wParam=='0')
								{
									if(pbase->ObjectType==TextObject)
									{	
										CTextObject *pto=(CTextObject*)m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
										
										if(pto->m_pCMMtext->Font.Height<600)
											pto->m_pCMMtext->Font.Height++;
										pto->ConfigChange();
									}
								}
								
					
							}
							else // selected Widget
							{
								T_WIDGET *pwgt=m_pActiveScreen->m_pSelectedWidget->m_pCMMwidget;
								// widget selected only
								if(wParam=='R')
								{
									pwgt->Border.BorderUsed=!pwgt->Border.BorderUsed; // toggle on/off
									pwgt->Border.BorderWidth=1; // set this to something reasonable.
									m_pActiveScreen->m_pSelectedWidget->SetWidgetBounds(&m_pActiveScreen->m_pSelectedWidget->GetWidgetBounds()); // do this recalc
								}
								if(wParam==190)
								{
									if(pwgt->Border.BorderWidth<10) // set this to something reasonable.
									{
										pwgt->Border.BorderWidth++; 
										m_pActiveScreen->m_pSelectedWidget->SetWidgetBounds(&m_pActiveScreen->m_pSelectedWidget->GetWidgetBounds()); // do this recalc
									}
								}
								if(wParam==188)
								{
									if(pwgt->Border.BorderWidth>1) // set this to something reasonable.
									{
										pwgt->Border.BorderWidth--; 
										m_pActiveScreen->m_pSelectedWidget->SetWidgetBounds(&m_pActiveScreen->m_pSelectedWidget->GetWidgetBounds()); // do this recalc
									}
								}
							}
						}
						Invalidate();
						UpdateWindow();
						return 0;					
					}
					
						
					default:
						break;
				}
			
			} // endof designer mode keypresses
#endif // for now remove these kepresses from recorder until designer mode is fully implemented.
	}
		break;
	case WM_SETFOCUS: {
		//qDebug("----------------------------------------------------------------SETFOCUS\n");
		break;
	}
	case WM_KILLFOCUS: {
		//qDebug("-------------------------------------------------------------------------KILLFOCUS\n");
		//::SetActiveWindow(m_hWnd);
		//::SetFocus(m_hWnd);
		break;
	}
		/*
		 // now not required. was here to turn off cursor for recorder, but now done before primary operations		
		 case WM_SETCURSOR:
		 {
		 #ifdef UNDER_CE	
		 
		 SetCursor(NULL); // turn off cursor
		 return TRUE;
		 #else
		 return DefWindowProc(message, wParam, lParam);
		 #endif
		 }
		 */
	default: {
		if (message == FULLMODESTATUS) {
			// Message receieved from RemoteDisplayServer.exe to indicate user
			// has wParam==1 User full control via web browser, wParam==0 user in view mode only
			if (wParam == 0) {
				LOG_INFO( TRACE_OPPANEL, "REMOTEDISPLAYSERVER : User into VIEW ONLY mode\n");
			} else {
				LOG_INFO( TRACE_OPPANEL, "REMOTEDISPLAYSERVER : User into FULL CONTROL mode %d\n");
			}
		}
	}
		break;
	}
	// might want to do this for DOCVIEW version, but seems fine without it
	// return CScrollView::WindowProc(message, wParam, lParam);
	// if we get here, call the message handler and then maybe DefWindowProc
	LRESULT lResult = 0;
	if (!OnWndMsg(message, wParam, lParam, &lResult))
		lResult = DefWindowProc(message, wParam, lParam);
	return lResult;
}
//****************************************************************************
///
///	Displays error in Trace window, then exits.	
///
/// @return error code
/// 
//****************************************************************************
HRESULT COpPanel::FailMessage(HRESULT hRet, wchar_t *pMessage) {
	wchar_t szBuff[128];
	swprintf(szBuff, L"%s\ncode=%x\n", pMessage, hRet);
	ReleaseDDobjects();
	OutputDebugString(szBuff);
	DestroyWindow();
	V6CriticalMessageBox(NULL, szBuff, L"DX Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
	return hRet;
}
//****************************************************************************
///
///	Sets up the default clip list in the m_cliplist buffer
///
/// @return none
/// 
//****************************************************************************
void COpPanel::SetupDefaultClip() {
	// allocate mem block (if not already)
	SetClipListBuffer(sizeof(RGNDATAHEADER) + sizeof(QRect));
	// put clipping back to initial state...
	// this is the QRect we want to clip to: the whole display area
	// now fill out all the structure fields
	memcpy(m_pClipList->Buffer, &m_DesktopRect, sizeof(QRect)); // copy the actual clip region
	m_pClipList->rdh.dwSize = sizeof(RGNDATAHEADER); // size of header structure
	m_pClipList->rdh.iType = RDH_RECTANGLES; // type of clip region
	m_pClipList->rdh.nCount = 1; // number of clip regions
	m_pClipList->rdh.nRgnSize = sizeof(QRect);  // size of lpClipList->Buffer
	m_pClipList->rdh.rcBound = m_DesktopRect;  // the bounding QRect
}
//****************************************************************************
///
///	Sets up the clip list buffer ready to recieve a clip list
///
/// @return none
/// 
//****************************************************************************
void COpPanel::SetClipListBuffer(int bytescount) {
	if (bytescount > 10000)
		DebugBreak();
	if (!m_pClipList) {
		// no cliplist memory, so allocate some here
		m_pClipList = (LPRGNDATA) malloc(bytescount);
		m_ClipListSize = bytescount;
		return;
	}
	if (bytescount > m_ClipListSize) {
		qDebug("Allocatiing ClipListBuffer %d\n", bytescount);
		// allocate a bigger buffer
		free(m_pClipList);
		m_pClipList = (LPRGNDATA) malloc(bytescount);
		m_ClipListSize = bytescount;
		return;
	}
	// otherwise, existing buffer will suffice
	return;
}
//****************************************************************************
///
/// Initialises DirectDraw
///
/// @return HRESULT - DD_OK if ok, else error code
/// 
//****************************************************************************
HRESULT COpPanel::InitDirectDraw() {
#ifndef TTR6SETUP
	//E437415
	DDSURFACEDESC ddsd;
	HRESULT hRet;
	LPDIRECTDRAW pDD;
	// Create the main DirectDraw object
	hRet = DirectDrawCreate(NULL, &pDD, NULL);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"DirectDrawCreate FAILED");
	// Fetch DirectDraw4 interface
	hRet = pDD->QueryInterface(IID_IDirectDraw, (LPVOID*) &m_pDD);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"QueryInterface FAILED");
	pDD->Release();
	pDD = NULL;
#ifdef UNDER_CE	
	// Set exclusive mode
	//E437415
	////DDSCL_EXCLUSIVE flag is no longer supported for windows embedded ce 6.0 and later
	 //hRet = m_pDD->SetCooperativeLevel(m_hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);
	//E519766
	//hRet = m_pDD->SetCooperativeLevel(m_hWnd,DDSCL_FULLSCREEN);
	hRet = m_pDD->SetCooperativeLevel(m_hWnd,DDSCL_NORMAL);
	if (hRet != DD_OK)
		return FailMessage( hRet, L"SetCooperativeLevel FAILED");
#else
	// set windowed mode
	hRet = m_pDD->SetCooperativeLevel(m_hWnd, DDSCL_NORMAL);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"SetCooperativeLevel FAILED");
#endif
	// Create the primary surface with 0 back buffers (since no flipping required)
	memset(&ddsd, 0, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS;
	//E437415
	////DDSCAPS_LOCALVIDMEM flag is no longer supported for windows embedded ce 6.0 or later
	//ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE|DDSCAPS_VIDEOMEMORY|DDSCAPS_LOCALVIDMEM; 
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_VIDEOMEMORY;
	ddsd.dwHeight = m_ScreenHeight;
	ddsd.dwWidth = m_ScreenWidth;
	hRet = m_pDD->CreateSurface(&ddsd, &m_pDDSPrimary, NULL);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"CreateSurface (1) FAILED");
	// Create surfaces
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	//E437415
	//DDSCAPS_OFFSCREENPLAIN Flag is no longer supported for windows embedded ce 6.0 and later
	//ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN|DDSCAPS_SYSTEMMEMORY; // put into system memory
	ddsd.ddsCaps.dwCaps = DDSCAPS_SYSTEMMEMORY; // put into system memory
	// use back buffer for building output
	hRet = m_pDD->CreateSurface(&ddsd, &m_pDDSBackBuffer, NULL);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"CreateSurface (2) FAILED");
	hRet = m_pDD->CreateSurface(&ddsd, &m_pDDSPermanent, NULL);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"CreateSurface (3) FAILED");
	hRet = m_pDD->CreateSurface(&ddsd, &m_pDDSAlpha, NULL);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"CreateSurface (4) FAILED");
	hRet = m_pDD->CreateClipper(0, &m_pDDClipper, NULL);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"CreateClipper FAILED");
	//hRet=m_pDD->CreateClipper(0, &m_pDDClipperWindow, NULL);
	//if (hRet != DD_OK)
	//	return FailMessage( hRet, L"CreateClipperWindow FAILED");
	//
	//m_pDDClipperWindow->SetHWnd(0, m_hWnd); //set up a clipper for the Window
	//
	m_pDDClipper->SetHWnd(0, m_hWnd); //set up a clipper for the Window
	SetupDefaultClip();
	m_pDDClipper->SetClipList(m_pClipList, 0);
	m_pDDSPrimary->SetClipper(m_pDDClipper);
	memset(&ddsd, 0, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	hRet = m_pDDSPrimary->GetSurfaceDesc(&ddsd);
	if (hRet != DD_OK)
		return FailMessage(hRet, L"GetSurfaceDesc FAILED");
	Glb_BitsPerPixel = ddsd.ddpfPixelasprintf.dwRGBBitCount;
	m_InitCount++; // increment after every (re)initialise
	m_ResetDDrequired = FALSE; // reset 
#endif
	return DD_OK;
}
//****************************************************************************
///
/// Finished with all DirectDraw objects we use, release them
///
/// @return none
/// 
//****************************************************************************
void COpPanel::ReleaseDDobjects() {
	if (m_pDDClipper) {
		m_pDDClipper->Release();
		m_pDDClipper = NULL;
	}
	if (m_pClipList) {
		free(m_pClipList); // was malloc'd		
		m_pClipList = NULL;
		m_ClipListSize = 0;
	}
	if (m_pDDClipperWindow) {
		m_pDDClipperWindow->Release();
		m_pDDClipperWindow = NULL;
	}
	if (m_pDDSBackBuffer) {
		m_pDDSBackBuffer->Release();
		m_pDDSBackBuffer = NULL;
	}
	if (m_pDDSPrimary) {
		m_pDDSPrimary->Release();
		m_pDDSPrimary = NULL;
	}
	if (m_pDDSAlpha) {
		m_pDDSAlpha->Release();
		m_pDDSAlpha = NULL;
	}
	if (m_pDDSPermanent) {
		m_pDDSPermanent->Release();
		m_pDDSPermanent = NULL;
	}
	CScreen *pScreen = m_pScreens;
	while (pScreen) {
		CWidget *pWidget = pScreen->m_pWidgets;
		while (pWidget) {
			CBaseObject *pObject = pWidget->m_pObjects;
			while (pObject) {
				if (pObject->m_CMMinfo.wBlockType == BLK_CHARTOBJECT) {
					CChartObject *pObj = (CChartObject*) pObject;
					pObj->ReleaseSurfaces();
				}
				pObject = pObject->m_pNextObj;
			}
			pWidget = pWidget->m_pNextWgt;
		}
		pScreen = pScreen->m_pNextScr;
	}
	if (m_pDD) {
		m_pDD->Release();
		m_pDD = NULL;
	}
}
//****************************************************************************
///
///	Constructor
///
//****************************************************************************
COpPanel::COpPanel() : m_pInternalMessageQueue(NULL), m_eCaptureMode(ocmNO_CAPTURE), m_strCaptureName("") {
	// Interprocess messages to communicate with RemoteDisplayServer.exe
	FULLMODESTATUS = RegisterWindowMessage(TEXT("REMOTE_USER_LOGIN_STATUS"));
	LOCALUSERSTATUS = RegisterWindowMessage(TEXT("LOCAL_USER_LOGIN_STATUS"));
	SetMode(OPPANEL_MODE_STARTUP);
	/// set up empty block info structure;
	BLOCK_INFO emptyInfo = { 0, 0, 0, NULL, 0 };
	m_CMMinfo = emptyInfo;
	m_pCMMlayout = NULL;
	m_pControlSeq = NULL;
	m_EditMode = RUN_MODE;
	m_JumpId.QuadPart = 0;
	m_pScreens = NULL;
	m_pActiveScreen = NULL;
	m_pTemplates = NULL;
	m_IsInitialised = FALSE;
	m_pMainConfig = NULL;
	m_PreviousConfigID = 0;
	m_RotateBaseTime.TimeNow();
	m_IsSetupConfigChange = FALSE;
	m_IsCommit = FALSE;
	m_pTptScrConfig = NULL;
	m_pCannedConfig = NULL;
	m_pReplayScrConfig = NULL;
	m_pReplayScreen = NULL;
	m_pReplayChartObject = NULL;
	m_pReplayCursorObject = NULL;
	m_pHotSoakScrConfig = NULL;
	m_pHotSoakScreen = NULL;
	m_pHotSoakRegion = NULL;
	m_pHotSoakData = NULL;
	m_iActivatedReplayscreen = 0;	// CR: 3151 Replay at Faster speed
	for (int n = 0; n < NUM_SOAK_LINES; n++) {
		m_HotSoakObjects[n][HS_Message] = NULL;
		m_HotSoakObjects[n][HS_LED] = NULL;
		m_HotSoakboardsFitted[n] = FALSE;
	}
	// init the recorder screen area and offsets (for DOCVIEW use)
	SetRect(&m_RecScreenArea, 0, 0, 0, 0);
	m_RecScreenOffset.x = 0;
	m_RecScreenOffset.y = 0;
	m_csWelcomeTxt = L"welcome";
#ifdef DOCVIEW
	InitialiseScrolling();
#endif
	m_Inactive = 0; // active!
	m_IsDrawing = 0;
	m_bLinkMode = FALSE;
	m_pLinkSelectedObject = NULL;
	m_bUpdateLayoutItemSelected = TRUE;
	m_bBringObjectOrWidgetToTop = TRUE;
	m_eSimulatedMove = SIMULATED_MOVE_NONE;
	m_pDD = NULL;				// DirectDraw object
	m_pDDSPrimary = NULL;		// DirectDraw priamry surface 
	m_pDDSBackBuffer = NULL;	// DirectDraw back buffer surface
	m_pDDSPermanent = NULL;	// DirectDraw permanent surface 
	m_pDDSAlpha = NULL;		// DirectDraw surface (Alpha)
	m_pDDClipper = NULL;		// DirectDraw Clipper
	m_pDDClipperWindow = NULL; // DirectDraw Clipper 2
	m_pClipList = NULL;
	m_ClipListSize = 0;
	m_InitCount = 0;
	m_ResetDDrequired = FALSE;
	m_pV6Module = NULL;
	m_ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	m_ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	//m_ScreenWidth= 320;
	//  m_ScreenHeight= 240;
	m_pDIT = CDataItemManager::GetHandle(); // get our pointer to the Data Item table manager singleton
#ifndef DOCVIEW // don't do this next section for DocView version
	// register our window class
	WNDCLASS wndcls;
	memset(&wndcls, 0, sizeof(WNDCLASS));  // start with NULL
										 // defaults
	wndcls.style = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
	// you can specify your own window procedure
	wndcls.lpfnWndProc = ::DefWindowProc;
	wndcls.hInstance = AfxGetInstanceHandle();
	wndcls.hIcon = NULL; //LoadIcon(IDR_MAINFRAME); // or load a different icon
	wndcls.hCursor = ::LoadCursorW(NULL, IDC_ARROW);
	wndcls.hbrBackground = NULL; //(HBRUSH) (COLOR_WINDOW+1);
	wndcls.lpszMenuName = NULL;
	// Specify your own class name for using indexOfWindow later
	wndcls.lpszClassName = L"OpPanel";
	// Register the new class and exit if it fails
	if (!AfxRegisterClass(&wndcls)) {
		LOG_ERR( TRACE_OPPANEL, "Class Registration Failed\n");
		return;
	}
#ifdef UNDER_CE
	//HWND TaskBar = ::indexOfWindow(TEXT("HHTaskBar"), NULL );
 //  if( TaskBar != NULL )
 //  {
	//	::setEnabled( TaskBar, FALSE );
	//	::ShowWindow(TaskBar, SW_HIDE);
 //  }
#endif
#ifdef UNDER_CE
	if(!CreateEx(0,//WS_EX_TOPMOST, 
					 L"OpPanel", L"X Series",
					 WS_POPUP,
					 0, 
					 0, 
					 m_ScreenWidth, 
					 m_ScreenHeight, 
					 NULL, 
					 NULL))
	 
#else
	//E519766
	/*int iWidth = 320;
	 int iHeight = 240;*/
	int iWidth = ARISTOS_MINI_QX_X;
	int iHeight = ARISTOS_MINI_QX_Y;
	// change the resoultion if a multi
	if (CDeviceAbstraction::ms_eDesktopDeviceType == DEV_PC_MULTI) {
		/*iWidth = 800;
		 iHeight = 600;*/
		iWidth = ARISTOS_PC_MULTI_SX_X;
		iHeight = ARISTOS_PC_MULTI_SX_Y;
	} else if (CDeviceAbstraction::ms_eDesktopDeviceType == DEV_PC_MINI) {
		/*iWidth = 800;
		 iHeight = 600;*/
		iWidth = ARISTOS_PC_MINI_QX_X;
		iHeight = ARISTOS_PC_MINI_QX_Y;
	} else if (CDeviceAbstraction::ms_eDesktopDeviceType == DEV_PC_EZTREND) {
		iWidth = ARISTOS_MINI_EZ_X;
		iHeight = ARISTOS_MINI_EZ_Y;
	}
	if (!CreateEx(
			WS_EX_APPWINDOW, //WS_EX_WINDOWEDGE,						// unlikely to be the final choice here!
			L"OpPanel", L"Recorder Simulation",
			WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME | WS_MINIMIZEBOX, // WS_OVERLAPPEDWINDOW less maximize box
			20, 40, 40, 40, NULL, NULL))
#endif //UNDER_CE
			{
		LOG_ERR( TRACE_OPPANEL, "Window Creation Failed\n");
		return;
	}
	// worked ok, so continue 
//***E519766
#ifdef UNDER_CE	
		
		SetCursor(NULL); // turn off cursor for now
		//set up our top level Rectangle
		SetRect(&m_DesktopRect,0,0,m_ScreenWidth,m_ScreenHeight);
		
		InitDirectDraw(); // initialise everything
		
#else
	// this section allows us to calculate the overall size of the window in order to get a specified client area.
	QRect tempRect = { 20, 40, 0, 0 }; // need to supply client area but get window size returned.
	tempRect.setright(tempRect).left + iWidth;
	tempRect.setBottom(tempRect).top + iHeight;
	AdjustWindowRectEx(&tempRect, GetWindowLong(m_hWnd, GWL_STYLE), GetMenu() != NULL,
			GetWindowLong(m_hWnd, GWL_EXSTYLE));
	move(&tempRect, FALSE);
	// set up our top level Rectangle
	// for the desktop, we keep m_DesktopRect up to date as the window is resized
	GetClientRect(&m_DesktopRect);
	ClientToScreen(&m_DesktopRect);
#endif //UNDER_CE
//	do not show the window here straight away (causes message boxes that appear during init to be hidden) JLP
//	wait until the layoutconfiguration has been set (and we have something to display)
	/*	
	 DWORD dwThreadID;
	 HANDLE hThread = CreateThread (NULL, 0, RefreshThread, (LPVOID)this, 0, &dwThreadID);
	 qDebug("OpPanel Refresh Thread ID: %u\n", dwThreadID );
	 CloseHandle (hThread);
	 */
	m_DoScreenMove = TRUE; // start off with the status bar showing and screen moved if applicable
	m_MoveScreenTick = GetTickCount();
#ifdef UNDER_CE
	// Check _Height(m_DesktopRect)
	m_moveOffset=(_Height(m_DesktopRect)==ARISTOS_MULTI_SX_Y ) ? MULTI_STATUS_BAR_HEIGHT : MINI_STATUS_BAR_HEIGHT;	
//	m_moveOffset = 	MULTI_STATUS_BAR_HEIGHT	;
	if ( pDEVICE_INFO->GetDeviceType() == DEV_EZTREND || pDEVICE_INFO->GetDeviceType() == DEV_XS_MINITREND )
		m_moveOffset = MINI_EZ_STATUS_BAR_HEIGHT;
	#else
	if (CDeviceAbstraction::ms_eDesktopDeviceType == DEV_XS_MULTIPLUS)
		m_moveOffset = MULTI_XS_STATUS_BAR_HEIGHT;
	else if (CDeviceAbstraction::ms_eDesktopDeviceType == DEV_PC_MULTI)
		m_moveOffset = MULTI_PC_STATUS_BAR_HEIGHT;
	else if (CDeviceAbstraction::ms_eDesktopDeviceType == DEV_PC_MINI)
		m_moveOffset = MINI_PC_STATUS_BAR_HEIGHT;
#endif
	SetTimer(StartupTimerId, 100, NULL);
#ifdef SHOW_CPU
	CalibrateCPUMon();
  StartCPUMonitor();
#endif
	ShowWindow (SW_SHOW);
	UpdateWindow();
#endif //DOCVIEW
}
//****************************************************************************
///
///	Destructor
///
//****************************************************************************
COpPanel::~COpPanel() {
#ifdef UNDER_CE
	HWND TaskBar = ::indexOfWindow(TEXT("HHTaskBar"), NULL );
  if( TaskBar != NULL )
  {
		::setEnabled( TaskBar, TRUE );
		::ShowWindow(TaskBar, SW_SHOW);
  }
#endif
#ifdef SHOW_CPU
  StopCPUMonitor();
#endif
	Destroy(); // deletes all CScreens, CTemplates, CWidgets and Objects.
	ReleaseDDobjects();
	// delete the 'special' template screen config
	if (m_pTptScrConfig) {
		m_pTptScrConfig->DeleteConfig();
		delete m_pTptScrConfig;
		m_pTptScrConfig = NULL;
	}
	// delete replay screen config
	if (m_pReplayScrConfig) {
		m_pReplayScrConfig->DeleteConfig();
		delete m_pReplayScrConfig;
		m_pReplayScrConfig = NULL;
	}
	// delete canned screen config
	if (m_pCannedConfig) {
		m_pCannedConfig->DeleteConfig();
		delete m_pCannedConfig;
		m_pCannedConfig = NULL;
	}
	CMemoryScreenBlock::GetHandle()->CleanUp();
	if (m_pHotSoakScrConfig) {
		WCHAR bufft[50];
		m_HotSoakBaseTime.TimeNow();
		m_HotSoakBaseTime.TimeToStringNoFracs(bufft);
		m_HotSoakLog.Log(L"Shutdown - %s", bufft);
		m_HotSoakLog.LogLine(L"------------------------------------------------------\r\n");
		m_HotSoakLog.SetLoggingOff();
		m_pHotSoakScrConfig->DeleteConfig();
		delete m_pHotSoakScrConfig;
		m_pHotSoakScrConfig = NULL;
		delete m_pHotSoakScreen->m_pTemplate;
		m_pHotSoakScreen->m_pTemplate = NULL;
		m_pHotSoakScreen->Destroy();
		delete m_pHotSoakScreen;
	}
#ifndef DOCVIEW
// delete our active module
	if (NULL != m_pV6Module) {
		delete m_pV6Module;
		m_pV6Module = NULL;
	}
#ifndef UNDER_CE
	HANDLE hEvent = NULL;
	///@todo MM need to move event name to a shared header file
	hEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, L"timesvc\\timeset");
	if (NULL != hEvent) {
		//No need to close the mutex in Qt
	}
#endif // UNDER_CE
	// this will be done elsewhere in Screen Designer
	CFontCache *pfc = CFontCache::GetHandle();
	pfc->CleanUp();  // remove singleton	
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->CleanUp();  // remove singleton	
#endif
	delete m_pInternalMessageQueue;
}
/////////////////////////////////////////////////////////////////////////////
// COpPanel message map etc
#ifdef DOCVIEW
	// IMPLEMENT_DYNCREATE(COpPanel, CScrollView)
	BEGIN_MESSAGE_MAP(COpPanel, CScrollView)
	ON_WM_CREATE()
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
#else
BEGIN_MESSAGE_MAP(COpPanel, CWidget)
#endif
//{{AFX_MSG_MAP(COpPanel)
ON_COMMAND(ID_EDIT_CUT, OnEditCut)
ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
ON_COMMAND(ID_EDIT_CLEAR, OnEditClear)
ON_UPDATE_COMMAND_UI(ID_EDIT_CLEAR, OnUpdateEditClear)
ON_COMMAND(ID_STICKY_WIDGETS, OnToggleStickyWidgets)
ON_UPDATE_COMMAND_UI(ID_STICKY_WIDGETS, OnUpdateToggleStickyWidgets)
ON_COMMAND(ID_EXPERT_MODE, OnToggleExpertMode)
ON_UPDATE_COMMAND_UI(ID_EXPERT_MODE, OnUpdateToggleExpertMode)
ON_COMMAND(ID_LINK_OBJECT, OnLinkObject)
ON_UPDATE_COMMAND_UI(ID_LINK_OBJECT, OnUpdateLinkObject)
ON_COMMAND(ID_UNLINK_OBJECT, OnUnlinkObject)
ON_UPDATE_COMMAND_UI(ID_UNLINK_OBJECT, OnUpdateUnlinkObject)
ON_COMMAND(ID_LOAD_TEMPLATE, OnLoadTemplate)
ON_UPDATE_COMMAND_UI(ID_LOAD_TEMPLATE, OnUpdateLoadTemplate)
ON_COMMAND(ID_SAVE_TEMPLATE, OnSaveTemplate)
ON_UPDATE_COMMAND_UI(ID_SAVE_TEMPLATE, OnUpdateSaveTemplate)
ON_WM_LBUTTONDOWN()
ON_WM_MOUSEMOVE()
ON_WM_LBUTTONUP()
ON_WM_CHAR()
ON_WM_SETCURSOR()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// COpPanel message handlers
//****************************************************************************
///
/// Handler for mouse/touchscreen button down
///
/// @param[in] nFlags	- Mouse button flags 
/// @param[in] point	- mouse position
/// 
/// @return none
/// 
//****************************************************************************	
void COpPanel::OnLButtonDown(UINT nFlags, QPoint point)
{
	// if we have a moved screen, update the position to suit
	if(m_pActiveScreen && m_pActiveScreen->m_ScreenIsMoved)
	point.y-=m_moveOffset;
	if( pDALGLB != NULL )
	pDALGLB->RegisterUserActivity();
	Glb_MouseTick=GetTickCount();
	// pass on to active Screen
	if(m_pActiveScreen && (m_Inactive==0))
	{
		if(m_EditMode==DESIGNER_MODE)
		{
			m_pActiveScreen->OnMouseDown(nFlags, point);
#ifdef DOCVIEW
			if(m_bUpdatePasteCaret)
			{
				m_ptPasteCaret=point;
				m_ptPasteCaret.Offset(-m_RecScreenOffset.x,-m_RecScreenOffset.y); // remove the offset
			}
			if(m_bUpdateLayoutItemSelected)
			if(m_pActiveScreen->m_pSelectedWidget)
			if(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject)
			OnLayoutItemSelected(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject);
			else
			OnLayoutItemSelected(m_pActiveScreen->m_pSelectedWidget);
			else
			{
				OnLayoutItemSelected(m_pActiveScreen);
			}
#endif
		}
		else
		{
			m_pActiveScreen->OnMouseDownRuntime(nFlags, point);
#if IS_RECORDER==1
			if (pSYSTEM_INFO->IsInHotSoakTestMode() == FALSE)
			{
				// check we have clicked on something before showing context button
				if((m_pActiveScreen->m_pLastSelectedWidget)&&(m_pActiveScreen->m_pLastSelectedWidget->m_pLastSelectedObject))
				{
					CTopStatusBar::Instance(this)->ShowContextButton(TRUE);
				}
				else // if we are clicking anywhere then show only hot buttons...
				CTopStatusBar::Instance(this)->ShowContextButton(TRUE, TRUE);
			}
#endif
		}
	}
	SetFocus();
	m_KeepPoint=point;
}
//****************************************************************************
///
/// Mouse/touchscreen Move handler
///
/// @param[in] nFlags	- Mouse button flags 
/// @param[in] point	- mouse position
/// 
/// @return none
/// 
//****************************************************************************	
void COpPanel::OnMouseMove(UINT nFlags, QPoint point) {
	// if we have a moved screen, update the position to suit
	if (m_pActiveScreen && m_pActiveScreen->m_ScreenIsMoved)
		point.y -= m_moveOffset;
	// under CE we receive mouse move messages at startup when not actually required.
	if (!Glb_MouseOn) {
		// mouse pointer not 'on' at present, 
		// check to see if the position of the mouse has changed (or is it unnecessary)
		if (point == Glb_MousePos)
			return;
		Glb_MouseOn = TRUE; // mouse has really moved, so turn mouse pointer on.
	}
	Glb_MouseTick = GetTickCount(); // reset the mouse off timer here
	Glb_MousePos = point; // and keep the new point to compare with
	if ( pDALGLB != NULL) {
		pDALGLB->RegisterUserActivity();
	}
	// pass on to active Screen
	if (nFlags & MK_LBUTTON) // leftbutton down
			{
		if (point == m_KeepPoint)
			return;
		m_KeepPoint = point;
		if (m_pActiveScreen && (m_Inactive == 0)) {
			if (m_EditMode == DESIGNER_MODE) {
#ifdef DOCVIEW 
				m_pActiveScreen->OnMouseMove(nFlags, point);
				SetLayoutModified();
#else
#ifdef _DEBUG
				// for now, remove designer mode "move objects" capability for the recorder (unless debug)
				m_pActiveScreen->OnMouseMove(nFlags, point);
				SetLayoutModified();
#endif
#endif
			} else
				m_pActiveScreen->OnMouseMoveRuntime(nFlags, point);
		}
	}
}
//****************************************************************************
///
/// Handler for mouse/touchscreen up
///
/// @param[in] nFlags	- Mouse button flags 
/// @param[in] point	- mouse position
/// 
/// @return none
/// 
//****************************************************************************	
void COpPanel::OnLButtonUp(UINT nFlags, QPoint point) {
	// if we have a moved screen, update the position to suit
	if (m_pActiveScreen && m_pActiveScreen->m_ScreenIsMoved)
		point.y -= m_moveOffset;
	// pass on to active Screen	
	if (m_pActiveScreen && (m_Inactive == 0)) {
		if (m_EditMode == DESIGNER_MODE)
			m_pActiveScreen->OnMouseUp(nFlags, point);
		else
			m_pActiveScreen->OnMouseUpRuntime(nFlags, point);
	}
	m_KeepPoint.x = -1000;
	if (m_EditMode == RUN_MODE)
		Glb_MouseOn = FALSE; // leave it on for designer mode
}
//****************************************************************************
///
/// Handler for keypresses (run mode only - pass to screen, and onto object)
///
/// @param[in] nChar	- character
/// @param[in] nRepCnt - repeat count
/// @param[in] nFlags	- flags 
/// 
/// @return none
/// 
//****************************************************************************	
void COpPanel::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) {
	if ( pDALGLB != NULL)
		pDALGLB->RegisterUserActivity();
	if ((m_EditMode == RUN_MODE) && m_pActiveScreen && (m_Inactive == 0))
		m_pActiveScreen->OnChar(nChar);
}
#ifdef DOCVIEW
//****************************************************************************
///
/// OnCreate Update handler - set the configuration from the document
///
/// @param [in] lpCreateStruct - creation structure
/// 
/// @return error code
/// 
//****************************************************************************	
int COpPanel::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	int nRet = CScrollView::OnCreate(lpCreateStruct);
	if (nRet == 0)
	{
		InitDirectDraw(); 
		COpPanelDVDoc* pDoc = GetDocument();
		pDoc->lc->SetCMMmode(CONFIG_MODIFIABLE); // use 'working' always for screen designer
		m_EditMode=DESIGNER_MODE;
	}
	m_CritSec.Unlock(); // gets created locked. (don't ask why)
	return nRet;
}

//****************************************************************************
///
/// OnInitial Update handler 
///
/// @param none
/// 
/// @return none
/// 
//****************************************************************************	
void COpPanel::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
}

void COpPanel::InitialiseScrolling(QPoint *pptCurrentScrollPos/*=NULL*/)
{
	SetScrollSizes(MM_TEXT, QSize(SCROLLABLE_DRAWING_SURFACE, SCROLLABLE_DRAWING_SURFACE), QSize(PIXELS_PER_PAGE, PIXELS_PER_PAGE), QSize(PIXELS_PER_LINE, PIXELS_PER_LINE));
	if(pptCurrentScrollPos)
	{
		OnHScroll(SB_THUMBTRACK, pptCurrentScrollPos->x, GetScrollBarCtrl(SB_HORZ));
		OnVScroll(SB_THUMBTRACK, pptCurrentScrollPos->y, GetScrollBarCtrl(SB_VERT));
	}
}

//****************************************************************************
///
/// OnScrollBy handler - handles scrolling. This method is called by
/// CScrollView's OnHScroll, OnVScroll, and OnMouseWheel handlers and
/// by the auto-scroll handler _AFX_MOUSEANCHORWND::OnTimer. OnHScroll
/// is called when the user moves the thumb on the horizontal scroll bar.
/// OnVScroll is called when the user moves the thumb on the vertical
/// scroll bar. OnMouseWheel is called when the user scrolls by spinning
/// the mouse wheel. The auto-scroll handler is called periodically via
/// a timer event after the user has pressed down on the mouse wheel.
/// When we're auto-scrolling, there's an "anchor" window present along
/// with a direction cursor. The distance between the anchor window and
/// the direction cursor determines how fast we scroll.
///
//****************************************************************************	
BOOL COpPanel::OnScrollBy(QSize sizeScroll, BOOL bDoScroll /*= TRUE*/)
{
	BOOL bRet=CScrollView::OnScrollBy(sizeScroll, bDoScroll);
	if(bRet)
	{
		if( m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MULTIPLUS )			
			SetRect(&m_RecScreenArea,0,0,ARISTOS_MULTI_SX_X,ARISTOS_MULTI_SX_Y);	
		else if ( m_pMainConfig->GetRecorderType() == DEV_XS_MULTIPLUS )				
			SetRect(&m_RecScreenArea,0,0,X_SERIES_MULTI_SX_X, X_SERIES_MULTI_SX_Y);
		else if ( m_pMainConfig->GetRecorderType() == DEV_ARISTOS_MINITREND )				
			SetRect(&m_RecScreenArea,0,0,ARISTOS_MINI_QX_X,ARISTOS_MINI_QX_Y);
		else if ( m_pMainConfig->GetRecorderType() == DEV_EZTREND || m_pMainConfig->GetRecorderType() == DEV_XS_MINITREND)				
			SetRect(&m_RecScreenArea,0,0,ARISTOS_MINI_EZ_X,ARISTOS_MINI_EZ_Y);

		BOOL bHasHorzBar, bHasVertBar;
		CheckScrollBars(bHasHorzBar, bHasVertBar);
		if(bHasHorzBar)
			m_RecScreenOffset.x=m_InitialRecScreenOffset.x-GetScrollBarCtrl(SB_HORZ)->GetScrollPos();
		if(bHasVertBar)
			m_RecScreenOffset.y=m_InitialRecScreenOffset.y-GetScrollBarCtrl(SB_VERT)->GetScrollPos();
		OffsetRect(&m_RecScreenArea,m_RecScreenOffset.x,m_RecScreenOffset.y);
		ConfigChange();
	}
	return bRet;
}

CScrollBar* COpPanel::GetScrollBarCtrl(int nBar) const
{
#ifndef V6IOTEST
	SEC2DTabWnd* pTabWnd = (SEC2DTabWnd*)GetParentTabWnd(this);
	if (pTabWnd->IsKindOf(RUNTIME_CLASS(SECTabWnd)))
		return pTabWnd->GetScrollBar(nBar, this);
	else
		return CScrollView::GetScrollBarCtrl(nBar);
#else
	return NULL;
#endif
}

// COpPanel printing - Visual studio added these - will probably need them later 
BOOL COpPanel::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}
void COpPanel::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}
void COpPanel::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

// COpPanel diagnostics

#ifdef _DEBUG
void COpPanel::AssertValid() const
{
	CScrollView::AssertValid();
}
void COpPanel::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

COpPanelDVDoc* COpPanel::GetDocument() const // non-debug version is inline
{
	assert(m_pDocument->IsKindOf(RUNTIME_CLASS(COpPanelDVDoc)));
	return (COpPanelDVDoc*)m_pDocument;
	return NULL;
}
#endif //_DEBUG
#endif // DOCVIEW
//****************************************************************************
///
/// OnLayoutItemSelected handler 
///
/// @param[in] pLayoutItem	- pointer to LayoutItem
/// 
/// @return none
/// 
//****************************************************************************	
void COpPanel::OnLayoutItemSelected(CLayoutItem *pLayoutItem) {
	if (pLayoutItem) {
		//pLayoutItem->DeletePropMem();
		//pLayoutItem->InitItemProp();
	}
}
#ifdef DOCVIEW
void COpPanel::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView)
{
	static int nCount = 0;
	qDebug("In COpPanel::OnActivateView, bActivate=%d, pActivateView=%x, pDeactiveView=%x (%d)\n", bActivate, pActivateView, pDeactiveView, ++nCount);
	CScrollView::OnActivateView(bActivate, pActivateView, pDeactiveView);
	if(bActivate && m_pActiveScreen)
		if(m_pActiveScreen->m_pSelectedWidget)
			if(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject)
				OnLayoutItemSelected(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject);
			else
				OnLayoutItemSelected(m_pActiveScreen->m_pSelectedWidget);
		else
			OnLayoutItemSelected(m_pActiveScreen);
	else
		OnLayoutItemSelected(NULL);
}
#endif
void COpPanel::SafeEmptyClipboard() {
	// Clear the clipboard contents if there are ScrDes items present on it.
	if (IsClipboardasprintfAvailable(cfLayout) && ::OpenClipboard(NULL)) {
		EmptyClipboard();
		CloseClipboard();
	}
}
void COpPanel::OnEditCut() {
	BOOL bSelectedWidget = m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	BOOL bSelectedObject = bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	// Don't allow a cut of an object or widget on a standard screen but the user
	// can cut the entire standard screen if he wants to.
	if ((bSelectedObject || bSelectedWidget) && m_pActiveScreen->IsCannedScreen())
		return;
	CSelectionList SelectionList;
	if (bSelectedObject)
		SelectionList.prepend(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->GetLayoutItem());
	else if (bSelectedWidget)
		SelectionList.prepend(m_pActiveScreen->m_pSelectedWidget->GetLayoutItem());
	else if (m_pActiveScreen->GetLayoutItem().CMM_Inst == TEMPLATE_SCREEN_INST)
		SelectionList.prepend(m_pActiveScreen->m_pTemplate->GetLayoutItem());
	else
		SelectionList.prepend(m_pActiveScreen->GetLayoutItem());
	CMemFile file;
	CDataItem ar(&file, CDataItem::store);
	m_pMainConfig->CopySelection(SelectionList, ar, TRUE /* use clipboard */);
	SetPasteCaretPosition(SelectionList);
	DeleteSelection(SelectionList, FALSE /* cut, not delete */);
}
void COpPanel::OnUpdateEditCut(CCmdUI *pCmdUI) {
	// Always allow a cut, because now we can cut a template or screen,
	// in addition to a widget or object. The old check for a widget or
	// object only is commented-out below.
	//BOOL bSelectedWidget=m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	//BOOL bSelectedObject=bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	//pCmdUI->Enable(bSelectedWidget || bSelectedObject);
	pCmdUI->Enable(TRUE);
}
void COpPanel::OnEditCopy() {
	BOOL bSelectedWidget = m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	BOOL bSelectedObject = bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	BOOL bSelectedScreen = FALSE; // set TRUE if copying an entire screen
	CSelectionList SelectionList;
	if (bSelectedObject) {
		SelectionList.prepend(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->GetLayoutItem());
	} else if (bSelectedWidget) {
		SelectionList.prepend(m_pActiveScreen->m_pSelectedWidget->GetLayoutItem());
	} else if (m_pActiveScreen->GetLayoutItem().CMM_Inst == TEMPLATE_SCREEN_INST) {
		SelectionList.prepend(m_pActiveScreen->m_pTemplate->GetLayoutItem());
	} else {
		bSelectedScreen = TRUE;
		SelectionList.prepend(m_pActiveScreen->GetLayoutItem());
	}
	CMemFile file;
	CDataItem ar(&file, CDataItem::store);
	// The template used for a standard screen and the objects and widgets
	// on that standard screen are in m_pCannedConfig. Only the screen itself
	// (BLK_SCREEN, T_SCREEN) is in m_pMainConfig.
	// Item Being Copied		For Standard Screen		For Custom Screen
	// -----------------		-------------------		-----------------
	//
	// Object					Use	m_pCannedConfig		Use m_pMainConfig
	// Widget					Use	m_pCannedConfig		Use m_pMainConfig
	// Template					Use	m_pCannedConfig		Use m_pMainConfig
	// Screen					Use m_pMainConfig!!		Use m_pMainConfig
	if (m_pActiveScreen->IsCannedScreen())
		if (bSelectedScreen) // copying an entire standard screen
			m_pMainConfig->CopySelection(SelectionList, ar, TRUE /* use clipboard */);
		else
			// copying an object, widget, or template for a standard screen
			m_pCannedConfig->CopySelection(SelectionList, ar, TRUE /* use clipboard */);
	else
		// copying an object, widget, template, or screen for a custom screen
		m_pMainConfig->CopySelection(SelectionList, ar, TRUE /* use clipboard */);
	SetPasteCaretPosition(SelectionList);
	// Offset the paste caret for the first paste. This statement
	// is outside SetPasteCaretPosition because we don't want to
	// offset the paste caret for a cut (OnEditCut doesn't perform
	// this offset) because we want a cut followed by a paste to
	// put the selection cut back into its original position, while
	// we want a copy followed by a paste to offset the selection
	// pasted.
	m_ptPasteCaret.Offset(20, 20);
}
void COpPanel::OnUpdateEditCopy(CCmdUI *pCmdUI) {
	// Always allow a copy, because now we can copy a template or screen,
	// in addition to a widget or object. The old check for a widget or
	// object only is commented-out below.
	//BOOL bSelectedWidget=m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	//BOOL bSelectedObject=bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	//pCmdUI->Enable(bSelectedWidget || bSelectedObject);
	pCmdUI->Enable(TRUE);
}
void COpPanel::OnLoadTemplate() {
	QString strTemplateFilter("");
	QString strFilter("");
	strTemplateFilter = tr("Template Files");
	strFilter = strTemplateFilter + L" (*.";
	strTemplateFilter = tr("tpl");
	strFilter += strTemplateFilter + L")|*." + strTemplateFilter + L"|";
	CFileDialog dlg(TRUE, L"." + strTemplateFilter, NULL, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, strFilter, NULL);
	dlg.m_ofn.lpstrTitle = _T("Insert Template");
	// Launch file open dialog.
	if (dlg.exec() == IDCANCEL)
		return;
	CStorage file(dlg.GetPathName(), QFile::ReadOnly);
	EXTRAPASTEINFO Extra;
	BeginPasteOperation(Extra);
	BOOL bOk = m_pMainConfig->InsertTemplateFromFile(file, &Extra);
	EndPasteOperation(OPERATION_INSERT_TEMPLATE_FROM_FILE, Extra);
}
void COpPanel::OnUpdateLoadTemplate(CCmdUI *pCmdUI) {
	T_LAYOUTITEM screenRef = m_pActiveScreen->GetLayoutItem();
	pCmdUI->Enable(screenRef.CMM_Type == BLK_SCREEN && screenRef.CMM_Inst == TEMPLATE_SCREEN_INST);
}
void COpPanel::OnSaveTemplate() {
#ifdef DOCVIEW // validate the template only if OpPanel running within Screen Designer
	CProblemArray ProblemArray;
	BOOL bIsValid=m_pMainConfig->IsValidToRun(ProblemArray, &m_pActiveScreen->m_pTemplate->GetLayoutItem());
	if(!bIsValid) // give user a chance to abort
	{
		CValidateLayoutSaveDlg dlg(ProblemArray);
		if (dlg.exec() == IDCANCEL)
			return; // don't even attempt to save
	}
#else
	BOOL bIsValid = TRUE;
#endif
	QString sFilter;
	sFilter = QString::asprintf(_T("Template Files (*%s)|*%s||"), FILE_EXT_TEMPLT, FILE_EXT_TEMPLT);
	// Construct the Save As dialog.
	CFileDialog dlg(
	FALSE,									// File Save As dialog box
			FILE_EXT_TEMPLT,						// Default filename extension
			NULL,									// Initial filename
			OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,	// Flags
			sFilter,								// Filters
			NULL									// Parent window
			);
	// Launch the Save As dialog.
	if (dlg.exec() == IDOK)
		m_pMainConfig->SaveTemplate(&m_pActiveScreen->m_pTemplate->GetLayoutItem(), dlg.GetPathName(), bIsValid);
}
void COpPanel::OnUpdateSaveTemplate(CCmdUI *pCmdUI) {
	T_LAYOUTITEM screenRef = m_pActiveScreen->GetLayoutItem();
	pCmdUI->Enable(screenRef.CMM_Type == BLK_SCREEN && screenRef.CMM_Inst == TEMPLATE_SCREEN_INST);
}
void COpPanel::DetermineSelectedItems() {
	// Determine the topmost widget or object selected on the active
	// screen. Note that if an object's IsSelected flag is set TRUE,
	// then the IsSelected flag for the widget it is contained in is
	// set FALSE. Traverse the widget and object lists from bottom to
	// top in the Z-order. Set m_pSelectedWidget and m_pSelectedObject.
	if (m_pActiveScreen) {
		BOOL bFound = FALSE;
		m_pActiveScreen->m_pSelectedWidget = NULL;
		CWidget *pWgt = m_pActiveScreen->m_pWidgets;
		while (pWgt && !bFound) {
			if (pWgt->m_pCMMwidget->IsSelected) // assumes at most one selected widget on screen
			{
				m_pActiveScreen->m_pSelectedWidget = pWgt;
				m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject = NULL;
				bFound = TRUE; // exit method
			} else // widget not selected, see if object in it is selected
			{
				bFound = FALSE;
				CBaseObject *pObj = pWgt->m_pObjects;
				while (pObj && !bFound)
					if (pObj->m_pCMMbase->IsSelected) // assumes at most one selected object in widget
					{
						m_pActiveScreen->m_pSelectedWidget = pWgt;
						m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject = pObj;
						bFound = TRUE; // exit widget
					} else
						pObj = pObj->m_pNextObj;
				bFound = FALSE; // continue checking other widgets
				pWgt = pWgt->m_pNextWgt;
			}
		}
	}
}
void COpPanel::OnEditPaste() {
	if (IsClipboardasprintfAvailable(cfLayout)) {
		OpenClipboard();
		HANDLE hData = GetClipboardData(cfLayout);
		if (hData) {
			SIZE_T size = GlobalSize(hData);
			LPVOID pData = GlobalLock(hData);
			if (pData) {
				CMemFile file;
				file.Attach((BYTE*) pData, (UINT) size);
				EXTRAPASTEINFO Extra;
				BeginPasteOperation(Extra);
				CDataItem ar(&file, CDataItem::load);
				m_pMainConfig->PasteSelection(ar, &Extra, this);
				EndPasteOperation(OPERATION_PASTE, Extra);
				GlobalUnlock(hData);
			}
		}
		CloseClipboard();
	}
}
void COpPanel::OnUpdateEditPaste(CCmdUI *pCmdUI) {
	// Check if this window (OpPanel) has the focus for a
	// paste. If it does, then allow a paste only if our
	// registered format is on the clipboard. If this window
	// does not have the focus, then enable the paste so that
	// the user can paste into other windows (for example,
	// the File Browser or status bar in Screen Designer).
	CWidget *pWnd = GetFocus();
	if (pWnd == this) {
		// Enable paste only if registered format on clipboard.
		BOOL bEnable = ::IsClipboardasprintfAvailable(cfLayout);
		pCmdUI->Enable(bEnable);
	} else
		pCmdUI->Enable(TRUE);
}
void COpPanel::GetCurrentScreen(T_LAYOUTITEM *pScreenRef) {
	if (m_pActiveScreen)
		if (m_pActiveScreen->GetLayoutItem().CMM_Inst == TEMPLATE_SCREEN_INST)
			*pScreenRef = m_pActiveScreen->m_pTemplate->GetLayoutItem();
		else
			*pScreenRef = m_pActiveScreen->GetLayoutItem();
	else
		SetNull(*pScreenRef);
}
void COpPanel::DeleteSelection(CSelectionList &SelectionList, BOOL bDelete /* = TRUE */) // bDelete==FALSE for cut
		{
	//T_LAYOUTITEM LayoutItem; // next layout item (object, widget, template, or screen) to select after delete
	QString sCheckpoint;	  // fill in with checkpoint description
	if (SelectionList.size() > 1)
		sCheckpoint = bDelete ? _T("Delete Selection") : _T("Cut Selection");
#ifdef DOCVIEW
	GetDocument()->BeginCheckpoint();
#endif
	POSITION pos = SelectionList.GetHeadPosition();
	while (pos) {
		T_LAYOUTITEM Item = SelectionList.GetNext(pos);
		switch (Item.CMM_Type) {
		// TODO: Add GetLayoutItem method to CLayoutItem class and remove this
		// method from the CBaseObject, CWidget, CTemplate, and CScreen classes.
		case BLK_SCRTEMPLATE: {
			OnDeleteTemplate(indexOfTemplateInstance(&Item)); // let Screen Designer update its UI
			if (SelectionList.size() == 1)
				sCheckpoint = bDelete ? _T("Delete Template") : _T("Cut Template");
			break;
		}
		case BLK_SCREEN: {
			OnDeleteScreen(indexOfScreenInstance(&Item)); // let Screen Designer update its UI
			if (SelectionList.size() == 1)
				sCheckpoint = bDelete ? _T("Delete Screen") : _T("Cut Screen");
			break;
		}
		case BLK_WIDGET: {
			// Delete the objects in the widget.
			BLOCK_INFO blockInfo;
			if (m_pMainConfig->indexOfDataBlock(&Item, &blockInfo)) {
				T_WIDGET *pWgt = (T_WIDGET*) blockInfo.pByBlock;
				for (int nObj = 0; nObj < pWgt->NumObjects; nObj++)
					m_pMainConfig->DeleteObject(&pWgt->ObjectList[nObj]);
				// Delete the widget itself.
				m_pMainConfig->DeleteWidget(&Item);
				if (SelectionList.size() == 1)
					sCheckpoint = bDelete ? _T("Delete Widget") : _T("Cut Widget");
			}
			break;
		}
		default: // delete an object
		{
			if (m_pMainConfig->BlockTypeToObjectType((T_BLOCKTYPE) Item.CMM_Type) != NoObject) {
				m_pMainConfig->DeleteObject(&Item);
				if (SelectionList.size() == 1)
					sCheckpoint = bDelete ? _T("Delete Object") : _T("Cut Object");
			}
			break;
		}
		}
	}
	// Destroy and rebuild our C++ hierarchy.
	m_pMainConfig->ValidateConfiguration();
	SetConfiguration(m_pMainConfig);
	// Get the current template or screen that should be shown.
	// We may have deleted a template or screen in Screen Designer,
	// in which case Screen Designer has set another template or
	// screen tab active. Show the correct template or screen in
	// that tab.
	T_LAYOUTITEM screenRef;
	GetCurrentScreen(&screenRef);
	// GetCurrentScreen can return a NULL screen ref. This is
	// the case when the last screen is deleted. Screen Designer
	// shows a "No Screens Configured" tab (not an OpPanel screen).
	// If screenRef is NULL, then don't display an OpPanel screen.
	if (!IsNull(screenRef))
		if (screenRef.CMM_Type == BLK_SCRTEMPLATE)
			ShowTemplate(&screenRef); // display a template
		else
			SetCurrentScreen(&screenRef); // display a screen
	// Just select the active screen after deleting the selection list so
	// that the Properties window always shows something after a delete.
	// Consider incorporating the commented-out code below for improved
	// selection handling.
#ifdef DOCVIEW
	OnLayoutItemSelected(m_pActiveScreen);
	GetDocument()->EndCheckpoint(sCheckpoint);
#endif
	/*******************************************************************************
	 * DETERMINE NEXT LAYOUT ITEM TO SELECT AND SELECT IT *
	 *******************************************************************************
	 // Determine next layout item to select...
	 CWidget *pSelWgt=m_pActiveScreen->m_pSelectedWidget;
	 CBaseObject *pSelObj=pSelWgt->m_pSelectedObject;
	 T_LAYOUTITEM widgetRef=pSelWgt->GetLayoutItem();
	 if(pSelObj) // delete object
	 {
	 // Determine the next layout item to select after deleting this object.
	 // Just select the next object in the object list or wrap to the beginning
	 // of the list if we're at the end (make sure we don't select this object
	 // again!) or select the widget we're in if there are no objects to select.
	 if(pSelObj->m_pNextObj)
	 LayoutItem=pSelObj->m_pNextObj->GetLayoutItem();
	 else if(pSelWgt->m_pObjects && pSelWgt->m_pObjects != pSelObj)
	 LayoutItem=pSelWgt->m_pObjects->GetLayoutItem();
	 else
	 LayoutItem=pSelWgt->GetLayoutItem();
	 }
	 else // delete widget
	 {
	 // Determine the next layout item to select after deleting this widget.
	 // Just select the next widget in the widget list or wrap to the beginning
	 // of the list if we're at the end (make sure we don't select this widget
	 // again!) or select the template or screen we're in if there are no widgets
	 // to select.
	 if(pSelWgt->m_pNextWgt)
	 LayoutItem=pSelWgt->m_pNextWgt->GetLayoutItem();
	 else if(pSelWgt->m_pScreen->m_pWidgets && pSelWgt->m_pScreen->m_pWidgets != pSelWgt)
	 LayoutItem=pSelWgt->m_pScreen->m_pWidgets->GetLayoutItem();
	 else
	 LayoutItem=pSelWgt->m_pScreen->GetLayoutItem();
	 }
	 // Select layout item...
	 // At this point, m_pActiveScreen has been set immediately above.
	 // If we need to "select" the active screen as the next layout item
	 // after a widget has been deleted, then LayoutItem's CMM_Type will
	 // always be BLK_SCREEN (for "selecting" a screen or a template).
	 switch(LayoutItem.CMM_Type)
	 {
	 case BLK_SCREEN: // m_pActiveScreen is either a screen or template
	 {
	 #ifdef DOCVIEW
	 OnLayoutItemSelected(m_pActiveScreen);
	 #endif
	 SetFocus();
	 break;
	 }
	 case BLK_WIDGET:
	 {
	 CWidget *pWidget=m_pActiveScreen->indexOfWidgetInstance(&LayoutItem);
	 m_pActiveScreen->BringWidgetToTop(pWidget);
	 QRect rc(pWidget->GetWidgetBounds());
	 m_bUpdatePasteCaret=FALSE;
	 OnLButtonDown(MK_LBUTTON, rc.Topleft());
	 OnLButtonUp(0, rc.Topleft());
	 m_bUpdatePasteCaret=TRUE;
	 break;
	 }
	 default: // an object
	 {
	 if(m_pConfig->BlockTypeToObjectType((T_BLOCKTYPE)LayoutItem.CMM_Type)!=NoObject)
	 {
	 CWidget *pWidget=m_pActiveScreen->indexOfWidgetInstance(&widgetRef);
	 CBaseObject* pObject=pWidget->indexOfObjectInstance(&LayoutItem);
	 pWidget->BringObjectToTop(pObject);
	 QRect rc(pObject->GetBounds());
	 m_bUpdatePasteCaret=FALSE;
	 OnLButtonDown(MK_LBUTTON, rc.Topleft());
	 OnLButtonUp(0, rc.Topleft());
	 m_bUpdatePasteCaret=TRUE;
	 }
	 else
	 assert(0); // should never happen!
	 break;
	 }
	 } // end, switch(LayoutItem.CMM_Type)
	 *******************************************************************************/
}
void COpPanel::OnEditClear() {
	BOOL bSelectedWidget = m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	BOOL bSelectedObject = bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	// Don't allow a delete of an object or widget on a standard screen but the user
	// can delete the entire standard screen if he wants to.
	if ((bSelectedObject || bSelectedWidget) && m_pActiveScreen->IsCannedScreen())
		return;
	CSelectionList SelectionList;
	if (bSelectedObject) {
		SelectionList.prepend(m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->GetLayoutItem());
		// delete the object channel list references
		m_pActiveScreen->m_pSelectedWidget->DeleteSelObjChanRef();
	} else if (bSelectedWidget) {
		SelectionList.prepend(m_pActiveScreen->m_pSelectedWidget->GetLayoutItem());
		m_pActiveScreen->m_pSelectedWidget->DeleteWidgetChanRef();
	} else if (m_pActiveScreen->GetLayoutItem().CMM_Inst == TEMPLATE_SCREEN_INST) {
		SelectionList.prepend(m_pActiveScreen->m_pTemplate->GetLayoutItem());
	} else {
		SelectionList.prepend(m_pActiveScreen->GetLayoutItem());
	}
	DeleteSelection(SelectionList);
}
void COpPanel::OnUpdateEditClear(CCmdUI *pCmdUI) {
	// Always allow a delete, because now we can delete a template or screen,
	// in addition to a widget or object. The old check for a widget or
	// object only is commented-out below.
	//BOOL bSelectedWidget=m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	//BOOL bSelectedObject=bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	//pCmdUI->Enable(bSelectedWidget || bSelectedObject);
	pCmdUI->Enable(TRUE);
}
#ifndef UNDER_CE
BOOL COpPanel::OnSetCursor(CWidget *pWnd, UINT nHitTest, UINT message) {
	if (nHitTest != HTCLIENT)
#ifdef DOCVIEW
		return CScrollView::OnSetCursor(pWnd, nHitTest, message);
#else
		return CWidget::OnSetCursor(pWnd, nHitTest, message);
#endif
	if (m_bLinkMode)
		::SetCursor(AfxGetApp()->LoadCursor(L"SCD_LINK_CURSOR"));
	else
		::SetCursor (AfxGetApp() -> LoadStandardCursor(IDC_ARROW));
returnTRUE	;
}
#endif
void COpPanel::OnToggleStickyWidgets() {
	m_bStickyWidgets = !m_bStickyWidgets;
}
void COpPanel::OnUpdateToggleStickyWidgets(CCmdUI *pCmdUI) {
	pCmdUI->SetCheck(m_bStickyWidgets);
}
void COpPanel::OnToggleExpertMode() {
	m_bExpertMode = !m_bExpertMode;
}
void COpPanel::OnUpdateToggleExpertMode(CCmdUI *pCmdUI) {
	pCmdUI->SetCheck(m_bExpertMode);
}
void COpPanel::OnLinkObject() {
	if (m_bLinkMode) // just cancel link mode
	{
		m_bLinkMode = FALSE;
		m_pLinkSelectedObject = NULL;
	} else // not in link mode, so do the link
	{
		BOOL bSelectedWidget = m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
		BOOL bSelectedObject = bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
		if (bSelectedObject) {
			m_bLinkMode = TRUE;
			m_pLinkSelectedObject = m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
		}
	}
}
void COpPanel::OnUpdateLinkObject(CCmdUI *pCmdUI) {
	BOOL bSelectedWidget = m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	BOOL bSelectedObject = bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	pCmdUI->Enable(
			bSelectedObject && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->GetLinkOrient() != LINK_NONE);
	pCmdUI->SetCheck(m_bLinkMode);
}
void COpPanel::OnUnlinkObject() {
	if (m_bLinkMode) // just cancel link mode
	{
		m_bLinkMode = FALSE;
		m_pLinkSelectedObject = NULL;
	} else // not in link mode, so do the unlink
	{
		BOOL bSelectedWidget = m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
		BOOL bSelectedObject = bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
		if (bSelectedObject)
			m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->Unlink();
		if (bSelectedWidget)
			UpdateLinks(&m_pActiveScreen->m_pSelectedWidget->GetLayoutItem()); // check/update the links for widget on all templates like this one.
	}
}
void COpPanel::OnUpdateUnlinkObject(CCmdUI *pCmdUI) {
	BOOL bSelectedWidget = m_pActiveScreen && m_pActiveScreen->m_pSelectedWidget;
	BOOL bSelectedObject = bSelectedWidget && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
	pCmdUI->Enable(bSelectedObject && m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->m_pLinked);
}
void COpPanel::OnDropItem(QPoint ptTopleft, CLayoutConfiguration &Layout, T_LAYOUTITEM LayoutItem) {
	// Make the point passed in relative to recorder screen area.
	ptTopleft.Offset(-m_RecScreenOffset.x, -m_RecScreenOffset.y);
	// Do not allow drop onto a canned screen.
	if (m_pActiveScreen && m_pActiveScreen->IsCannedScreen())
		return;
	// Allow drop of an object only over a widget. The widget doesn't have to
	// be selected. Just return if not over a widget. We need to check all
	// widgets on the active screen because the head of the widget list is the
	// bottom-most widget on the screen. Need to consider overlapping widgets.
	T_LAYOUTITEM ReceivingWgtRef;
	SetNull(ReceivingWgtRef);
	if (Layout.BlockTypeToObjectType((T_BLOCKTYPE) LayoutItem.CMM_Type) != NoObject)
		if (m_pActiveScreen) {
			CWidget *pReceivingWgt = NULL;
			CWidget *pWgt = m_pActiveScreen->m_pWidgets;
			while (pWgt) {
				QRect rcBounds = pWgt->GetWidgetBoundsActual();
				if (rcBounds.PtInRect(ptTopleft))
					pReceivingWgt = pWgt;
				pWgt = pWgt->m_pNextWgt;
			}
			if (pReceivingWgt) {
				// Need to keep T_LAYOUTITEM reference and not a pointer
				// to the receiving widget, because the entire C++ class
				// hierarchy is re-built on a paste.
				ReceivingWgtRef = pReceivingWgt->GetLayoutItem();
				// Unselect the currently selected widget if it is different
				// than the receiving widget else the call to indexOfItemInstance
				// in the call to OnLayoutItemSelect in EndPasteOperation will
				// return NULL and the Properties window won't be updated
				// correctly and multiple widgets will have objects selected in
				// them!
				if (m_pActiveScreen->m_pSelectedWidget && m_pActiveScreen->m_pSelectedWidget != pReceivingWgt) {
					m_pActiveScreen->m_pSelectedWidget->m_WidgetShowHandles = FALSE;
					m_pActiveScreen->m_pSelectedWidget->m_pCMMwidget->IsSelected = FALSE;
					CBaseObject *pObj = m_pActiveScreen->m_pSelectedWidget->m_pObjects;
					while (pObj) {
						pObj->m_ShowHandles = FALSE;
						pObj->m_pCMMbase->IsSelected = FALSE;
						pObj = pObj->m_pNextObj;
					}
				}
				// Select the widget because it might not be selected
				// and that would prevent the object from being pasted.
				m_pActiveScreen->m_pSelectedWidget = pReceivingWgt;
			} else
				return;
		} else
			return;
	m_ptPasteCaret = ptTopleft;
	CSelectionList SelectionList;
	SelectionList.prepend(LayoutItem);
	CMemFile file;
	CDataItem store(&file, CDataItem::store);
	Layout.CopySelection(SelectionList, store);
	store.Close();
	file.seek(0);
	EXTRAPASTEINFO Extra;
	BeginPasteOperation(Extra);
	CDataItem load(&file, CDataItem::load);
	m_pMainConfig->PasteSelection(load, &Extra, this);
	EndPasteOperation(OPERATION_DROP_ITEM, Extra);
	SetFocus();
}
void COpPanel::BeginPasteOperation(EXTRAPASTEINFO &Extra) {
	SetPasteContext(Extra);
#ifdef DOCVIEW
		GetDocument()->BeginCheckpoint();
#endif
}
void COpPanel::EndPasteOperation(PASTE_OPERATION Operation, EXTRAPASTEINFO &Extra) {
	m_ptPasteCaret = Extra.ptPasteCaret;
	// All CMM blocks have been created to represent the pasted
	// layout items. Now destroy and rebuild our C++ hierarchy.
	SetConfiguration(m_pMainConfig);
	// Add the template/screen worksheets in Screen Designer now that the
	// configuration has been committed. If we didn't paste templates
	// or screens, then that means we'll stay on the same worksheet tab.
	if (Extra.TemplatesPasted.GetSize() > 0)
		for (int nTemplate = 0; nTemplate < Extra.TemplatesPasted.GetSize(); nTemplate++)
			OnAddTemplate(&Extra.TemplatesPasted[nTemplate]);
	if (Extra.ScreensPasted.GetSize() > 0)
		for (int nScreen = 0; nScreen < Extra.ScreensPasted.GetSize(); nScreen++)
			OnAddScreen(&Extra.ScreensPasted[nScreen]);
	if (Extra.TemplatesPasted.GetSize() == 0 && Extra.ScreensPasted.GetSize() == 0) {
		// Get what template or screen we were on so we can re-display it now
		// that we've completed the paste and we've destroyed and rebuilt our
		// C++ hierarchy. We'll revert to this screen only if we're not pasting
		// templates/screens, which sets the active screen for us.
		if (Extra.ActiveScreenRef.CMM_Type == BLK_SCRTEMPLATE)
			ShowTemplate(&Extra.ActiveScreenRef); // re-display template
		else
			SetCurrentScreen(&Extra.ActiveScreenRef); // re-display screen
	}
#ifdef DOCVIEW
	if(CLayoutConfiguration::m_bCopySingleSel && Extra.bSelectAfterPaste)
	{
		DetermineSelectedItems();
		OnLayoutItemSelected(indexOfItemInstance(&CLayoutConfiguration::m_LastPastedItemRef));
	}
	// Set up the description string for the checkpoint to follow.
	QString sPasteDesc;
	switch(Operation)
	{
		case OPERATION_INSERT_TEMPLATE_FROM_FILE: sPasteDesc=_T("Insert Template From File"); break;
		case OPERATION_PASTE: // user copy/paste operation
		{
			switch(CLayoutConfiguration::m_PasteDesc)
			{
				case PASTE_OBJECT:  sPasteDesc=_T("Paste Object");	break;
				case PASTE_WIDGET:  sPasteDesc=_T("Paste Widget");	break;
				case PASTE_TEMPLATE: sPasteDesc=_T("Paste Template");	break;
				case PASTE_SCREEN:  sPasteDesc=_T("Paste Screen");	break;
				case PASTE_SELECTION: sPasteDesc=_T("Paste Selection");	break;
				default:
				{
					assert(0); // not handled!
					sPasteDesc=_T("Paste Item(s)");
					break;
				}
			}
			break;
		} // end, case OPERATION_PASTE
		case OPERATION_DROP_ITEM: // user drag and drop object or widget operation
		{
			switch(CLayoutConfiguration::m_PasteDesc)
			{
				case PASTE_OBJECT: sPasteDesc=_T("Drop Object"); break;
				case PASTE_WIDGET: sPasteDesc=_T("Drop Widget"); break;
				default:
				{
					assert(0); // not handled!
					sPasteDesc=_T("Drop Item");
					break;
				}
			}
			break;
		} // end, case OPERATION_DROP_ITEM
		default:
		{
			assert(0); // not handled!
			sPasteDesc=_T("Paste Item(s)");
			break;
		}
	} // end, switch(Operation)
	GetDocument()->EndCheckpoint(sPasteDesc);
#endif
}
void COpPanel::SetPasteContext(EXTRAPASTEINFO &Extra) {
	Extra.bSelectAfterPaste = TRUE;
	Extra.ActiveScreenRef = m_pActiveScreen->GetLayoutItem();
	if (Extra.ActiveScreenRef.CMM_Type == BLK_SCREEN && Extra.ActiveScreenRef.CMM_Inst == TEMPLATE_SCREEN_INST)
		Extra.ActiveScreenRef = m_pActiveScreen->m_pTemplate->GetLayoutItem();
	Extra.rcActiveScreenClient = m_pActiveScreen->m_ScreenClientRect;
	// update screen area with offsets
	Extra.rcActiveScreenClient.OffsetRect(-m_RecScreenOffset.x, -m_RecScreenOffset.y);
	if (m_pActiveScreen->m_pSelectedWidget) {
		Extra.SelectedWidgetRef = m_pActiveScreen->m_pSelectedWidget->GetLayoutItem();
		Extra.rcSelectedWidgetClient = m_pActiveScreen->m_pSelectedWidget->GetWidgetClientActual();
		if (m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject)
			Extra.SelectedObjectRef = m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject->GetLayoutItem();
		else
			SetNull(Extra.SelectedObjectRef);
	} else {
		SetNull(Extra.SelectedWidgetRef);
		Extra.rcSelectedWidgetClient.SetRectEmpty();
	}
	Extra.ptPasteCaret = m_ptPasteCaret;
	Extra.pOpPanel = this;
Extra.pGetPasteScreenOption=(GETPASTESCREENOPTIONCAST)&COpPanel::StaticGetPasteScreenOption;
}
void COpPanel::SetPasteCaretPosition(CSelectionList &SelectionList) {
// Compute the bounding rectangle of all selected items
// and set the paste caret to the top left of this rect
// offset by the cascade amount to set up for a paste.
BOOL bOnlyObjectsAndWidgets = TRUE;
QRect rcUnion;
rcUnion.SetRectEmpty();
POSITION pos = SelectionList.GetHeadPosition();
while (pos) {
	T_LAYOUTITEM Item = SelectionList.GetNext(pos);
	BLOCK_INFO blockInfo;
	CLayoutConfiguration::m_pCopyLayout->indexOfDataBlock(&Item, &blockInfo);
	if (Item.CMM_Type == BLK_WIDGET) {
		T_WIDGET *pWgt = (T_WIDGET*) blockInfo.pByBlock;
		rcUnion.UnionRect(rcUnion, (LPCRECT) & pWgt->Bounds);
	} else if (CLayoutConfiguration::m_pCopyLayout->BlockTypeToObjectType((T_BLOCKTYPE) Item.CMM_Type) != NoObject) {
		T_BASEOBJECT *pObj = (T_BASEOBJECT*) blockInfo.pByBlock;
		rcUnion.UnionRect(rcUnion, (LPCRECT) & pObj->Bounds);
	} else {
		bOnlyObjectsAndWidgets = FALSE;
		break;
	}
}
if (bOnlyObjectsAndWidgets)
	m_ptPasteCaret = rcUnion.Topleft();
}
void COpPanel::AlignLytItemsleft() {
m_pActiveScreen->m_pSelectedWidget->AlignItems(Alignleft);
}
void COpPanel::AlignLytItemsright() {
m_pActiveScreen->m_pSelectedWidget->AlignItems(Alignright);
}
void COpPanel::AlignLytItemsTop() {
m_pActiveScreen->m_pSelectedWidget->AlignItems(AlignTop);
}
void COpPanel::AlignLytItemsBottom() {
m_pActiveScreen->m_pSelectedWidget->AlignItems(AlignBottom);
}
void COpPanel::AlignLytItemsCenterHorizontal() {
m_pActiveScreen->m_pSelectedWidget->AlignItems(AlignCenterHorizontal);
}
void COpPanel::AlignLytItemsCenterVertical() {
m_pActiveScreen->m_pSelectedWidget->AlignItems(AlignCenterVertical);
}
void COpPanel::AlignLytItemsmiddle() {
m_pActiveScreen->m_pSelectedWidget->AlignItems(Alignmiddle);
}
//****************************************************************************
// const QString GetTemplateList( ) const
///
/// Method that gets a delimited string containing the available template names
///
/// @return	The delimitted template list
///
//****************************************************************************
const QString COpPanel::GetTemplateList() const {
QString strTemplateNameList("");
QString strTemplateName("");
CTemplate *pkTemplates = m_pTemplates;
while (pkTemplates != NULL) {
	// extract the template name
	T_SCRTEMPLATE *ptCMMTemplate = pkTemplates->m_pCMMtemplate;
	strTemplateName = QString::asprintf("%s", ptCMMTemplate->Name);
	// now add to our list including the delimitter
	strTemplateNameList += strTemplateName + L"|";
	pkTemplates = pkTemplates->m_pNextTpt;
}
return strTemplateNameList;
}
//****************************************************************************
// const USHORT GetTemplateIndex( T_LAYOUTITEM *ptTemplateRef ) const
///
/// Method that returns the index of the corresponding template for the passed in template ref
///
/// @return	The index of the template
///
//****************************************************************************
const USHORT COpPanel::GetTemplateIndex(T_LAYOUTITEM *ptTemplateRef) const {
USHORT usIndex = 0;
CTemplate *pkTemplates = m_pTemplates;
while (pkTemplates != NULL) {
	// see if this is a match
	if (pkTemplates->MatchLayoutItem(ptTemplateRef)) {
		// found a match so break out of the loop - the index variable should reflect this templates
		// index number by we need to off set it by the number of canned screens
		usIndex += TPL_LAST_CANNED;
		break;
	}
	pkTemplates = pkTemplates->m_pNextTpt;
	// not this template so increment the index
	usIndex++;
}
return usIndex;
}
//****************************************************************************
/// Rebuilds all canned screens using groups 
///
/// @param none
/// 
/// @return none
///
//****************************************************************************
void COpPanel::RebuildGroupCannedScreens() {
if (m_IsInitialised) // only once the recorder is up and running
{
	CPenSetupConfig *pPenSetupCfg = pSETUP->GetPenSetupConfig();
	CGeneralSetupConfig *pkGenSetupCfg = pSETUP->GetGeneralSetupConfig();
	CScreen *pScreen = m_pScreens;
	// for all canned screens showing a group, mark as having changed (will all be rebuilt)
	while (pScreen) {
		if ((pScreen->IsCannedScreen() && pScreen->m_pCMMscreen->UseGroups)
				|| (pkGenSetupCfg->TUSInfoChanged() && pSYSTEM_INFO->FWOptionTUSModeAvailable()
						&& (pScreen->m_pCMMscreen->Type == TPL_AMS2750_TUS_SCREEN))) {
			// changed or unused (no pens in that group) or furnace information changed
			if (pPenSetupCfg->GroupChangedFlag(pScreen->m_pCMMscreen->GroupIndex + 1)
					|| pkGenSetupCfg->FurnaceChanged(pScreen->m_pCMMscreen->GroupIndex)
					|| (pScreen->m_pCMMscreen->Type == TPL_AMS2750_TUS_SCREEN))
					{
				pScreen->m_CannedScreenChanged = TRUE; // flag the canned screens that need to be rebuilt due to group changes	
			}
		}
		pScreen = pScreen->m_pNextScr;
	}
	// Here we are calling set configuration - and we'll be modifying the decoy setup for the screens
	// above that are displaying a group. 
	qDebug(">----------------------------- RebuildGroupCannedScreens\n");
	m_pCannedConfig->SetCMMmode(CONFIG_MODIFIABLE);
	SetConfiguration(m_pMainConfig, FALSE);
	// commit any changes
	m_pCannedConfig->CommitConfig();
	m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
	// and rebuild from committed
	SetConfiguration(m_pMainConfig, TRUE);
}
}
//****************************************************************************
/// Rebuilds the TUS screen
///
/// @param none
/// 
/// @return none
///
//****************************************************************************
void COpPanel::RebuildTUSScreen() {
if (m_IsInitialised) // only once the recorder is up and running
{
	CScreen *pScreen = m_pScreens;
	// find the TUS screen and mark as changed
	while (pScreen != NULL) {
		if (pScreen->IsCannedScreen() && (pScreen->m_pCMMscreen->Type == TPL_AMS2750_TUS_SCREEN)) {
			pScreen->m_CannedScreenChanged = TRUE; // flag the canned screens that need to be rebuilt due to group changes	
			break;
		}
		pScreen = pScreen->m_pNextScr;
	}
	// Here we are calling set configuration - and we'll be modifying the decoy setup for the screens
	// above that are displaying a group. 
	qDebug(">----------------------------- RebuildTUSScreen\n");
	m_pCannedConfig->SetCMMmode(CONFIG_MODIFIABLE);
	SetConfiguration(m_pMainConfig, FALSE);
	// commit any changes
	m_pCannedConfig->CommitConfig();
	m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
	// and rebuild from committed
	bool bUpdateOpPanelProcessScreen = true;
#ifndef DOCVIEW
#ifndef V6IOTEST
	// check if the screen is visible as if it isn't then we don't want to update the display
	if (CTopStatusBar::Instance()->IsMenuSystemInUse()) {
		bUpdateOpPanelProcessScreen = false;
	}
#endif
#endif
	SetConfiguration(m_pMainConfig, TRUE, bUpdateOpPanelProcessScreen);
}
}
#if IS_RECORDER==1
//****************************************************************************
// void EnterDesignerMode()
///
/// Method that makes the recorder enter designer mode
///
//****************************************************************************
void COpPanel::EnterDesignerMode() {
if (m_EditMode != DESIGNER_MODE) {
	m_EditMode = DESIGNER_MODE;
	m_pMainConfig->SetCMMmode(CONFIG_MODIFIABLE); // use working for the time being.
	m_pCannedConfig->SetCMMmode(CONFIG_MODIFIABLE); // use working for the time being.
	SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, FALSE);
}
}
//****************************************************************************
// const bool LeaveDesignerMode()
///
/// Method that makes the recorder leave designer mode
///
/// @return		True if the user confirmed they wished to leave designer mode
///
//****************************************************************************
const bool COpPanel::LeaveDesignerMode() {
bool bLeaveDesignerMode = false;
if (m_EditMode == DESIGNER_MODE) {
	if (GetLayoutModified()) {
		CCfgCommitDlg kCommitDlg(mhpLayoutEditSetup, 0, 0, 0, this);
		if (kCommitDlg.exec() == IDOK) {
			// CHANGING TO RUN MODE
			m_EditMode = RUN_MODE;
			if (kCommitDlg.CommitSelected()) {
				// the user must have selected to commit the changes
				// ensure everything that needs to be is configured in working before we change it
				SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, FALSE);
				m_pCannedConfig->CommitConfig();
				m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
				m_pMainConfig->CheckCustomScreens(m_pCMMlayout);
				m_pMainConfig->SetCMMmode(CONFIG_COMMITTED); // use comitted from now on..
				m_IsCommit = TRUE;
				CommitLayoutChanges(); // posts the message, and we hear about it via active module. Also sets configuration
				//	SetConfiguration(m_pMainConfig,TRUE); // DO NOT CALL THIS HERE (gets done above in CommitLayoutChanges)
			} else if (kCommitDlg.DiscardSelected()) {
				// the user has selected to discard the changes therefore restore the current configuration					
				DiscardLayoutChanges();
				m_pCannedConfig->DiscardConfigurationChanges();
				// reset the instance nos for these layouts on a discard.
				m_pMainConfig->ResetInstNos();
				m_pCannedConfig->ResetInstNos(CANNED_SCREENS);
				// re-set up all our CMM pointers in working
				SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, FALSE);
				m_pMainConfig->SetCMMmode(CONFIG_COMMITTED); // use comitted from now on..
				m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
				m_IsCommit = TRUE;
				// re-set up all our CMM pointers to comitted
				SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, TRUE);
			} else {
				// the user must have selected park 
				// ensure everything that needs to be is configured in working before we change it
				SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, FALSE);
				m_pMainConfig->SetCMMmode(CONFIG_COMMITTED); // use comitted from now on..
				m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
				// re-set up all our CMM pointers to comitted
				SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, TRUE);
			}
			// the user must have selected an option which requires us to leave designer mode
			bLeaveDesignerMode = true;
		} else {
			// the user must have selected the bak button therefore do not leave designer mode
			bLeaveDesignerMode = false;
			// if going back to the display, ensure it's showing the updated stuff
			// ensure everything that needs to be is configured in working before we change it
			SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, FALSE);
		}
	} else {
		m_EditMode = RUN_MODE;
		// no changes so leave designer mode
		m_pMainConfig->SetCMMmode(CONFIG_COMMITTED); // use comitted from now on..
		m_pCannedConfig->SetCMMmode(CONFIG_COMMITTED);
		// re-set up all our CMM pointers to comitted
		SendMessage(WM_OPPANEL_SETCFGN_DESMODE, (WPARAM) m_pMainConfig, TRUE);
		bLeaveDesignerMode = true;
	}
} else {
	bLeaveDesignerMode = true;
}
return bLeaveDesignerMode;
}
#endif
void COpPanel::CalculateEUDCAttributes() {
HDC hdc = ::GetDC(HWND_DESKTOP);
// Set up for black text on white background.
COLORREF black = QString(0, 0, 0);
COLORREF white = QString(255, 255, 255);
COLORREF crOldTextColor = SetTextColor(hdc, black);
COLORREF crOldBkColor = SetBkColor(hdc, white);
QFont hOldFont = (QFont) GetCurrentObject(hdc, OBJ_FONT);
WCHAR AllBlackSymbol[2] = { ALL_BLACK_EUDC, 0 /* terminator */};
//QRect rc(0,0,800,600); // where to place the all black 64x64 EUDC symbol
QRect rc(0, 0, ARISTOS_MULTI_SX_X, ARISTOS_MULTI_SX_Y); // where to place the all black 64x64 EUDC symbol
CFontCache *pfc = CFontCache::GetHandle();
for (int nFontSize = 1; nFontSize < MAX_EUDC_FONT_SIZE; nFontSize++) {
	int yoffset;
	QFont hfont = pfc->GetNumericFont(nFontSize, &yoffset);
	SelectObject(hdc, hfont);
	// Draw the all black 64x64 EUDC symbol.
	DrawText(hdc, AllBlackSymbol, 1 /*#words*/, rc, DT_NOCLIP | DT_LEFT | DT_TOP);
	QSize size;
	GetTextExtentPoint32(hdc, AllBlackSymbol, 1 /*#words*/, &size);
	BOOL bAboveHeightDone = FALSE; // Are we done computing the above height?
	short nAboveHeight = 0;
	short nBelowHeight = 0;
	for (int nPixel = 0; nPixel < size.cy; nPixel++) {
		COLORREF pixel = GetPixel(hdc, 0, nPixel);
		// Compute above height and below height.
		if (pixel == white)
			if (!bAboveHeightDone)
				nAboveHeight++;
			else
				nBelowHeight++;
		else
			// any other colour signifies EUDC symbol itself
			bAboveHeightDone = TRUE;
	}
	// Trace nCellWidth, nCellHeight, nAboveHeight, nSymbolHeight, nBelowHeight.
	qDebug("%3d, %3d, %3d, %3d, %3d,\n", size.cx /* nCellWidth  */, size.cy /* nCellHeight  */,
			nAboveHeight /* nAboveHeight */, size.cy - (nAboveHeight + nBelowHeight) /* nSymbolHeight */,
			nBelowHeight /* nBelowHeight */);
	pfc->ReleaseFont(hfont);
}
SetTextColor(hdc, crOldTextColor);
SetBkColor(hdc, crOldBkColor);
SelectObject(hdc, hOldFont);
::ReleaseDC(HWND_DESKTOP, hdc);
}
//****************************************************************************
// CLayoutItem *GetSelectedObject()
///
/// Method that gets the currently selected object
///
/// @return		A pointer to the selected object or NULL is there isn't one
///
//****************************************************************************
CLayoutItem* COpPanel::GetSelectedObject() {
CLayoutItem *pkSelectedItem = NULL;
// check if there is an active screen
if (m_pActiveScreen != NULL) {
	// there is an active screen, so check for an active widget
	if (m_pActiveScreen->m_pSelectedWidget != NULL) {
		// there is a widget selected so check for an active object
		if (m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject != NULL) {
			// there is a selected object so use this
			pkSelectedItem = m_pActiveScreen->m_pSelectedWidget->m_pSelectedObject;
		} else {
			// no selected object so use the widget
			pkSelectedItem = m_pActiveScreen->m_pSelectedWidget;
		}
	} else {
		// no other object selected so just return the screen
		pkSelectedItem = m_pActiveScreen;
	}
} else {
	// no object selected so return NULL
	pkSelectedItem = NULL;
}
return pkSelectedItem;
}
#ifndef DOCVIEW
#ifndef V6IOTEST
//****************************************************************************
// const T_PEN_GROUPS GetValidActiveScreenGroupNo( const bool bTHREAD_SAFE )
///
/// Method that gets the valid active screen group number
///
/// @param[in]		const bool bTHREAD_SAFE - Flag indicating if the operation is already thread
///					safe or it needs to use a critical section 
///
/// @return		The group number of the screen - the group must be valid, batch FW option enabled 
///				and there are enabled pens in the group
///
//****************************************************************************
const T_PEN_GROUPS COpPanel::GetValidActiveScreenGroupNo(const bool bTHREAD_SAFE) {
T_PEN_GROUPS ePEN_GROUP = PEN_GROUP_ALL;
CPenManager *pkPenManager = CPenManager::GetHandle();
CBatchManager *pkBatchMgr = CBatchManager::Instance();
// get the critical section if necessary
if (!bTHREAD_SAFE) {
	m_CritSec.Lock();
}
// check all the requirements are satisfied for the sceen to be group specific
if ( pSYSTEM_INFO->FWOptionBatchAvailable() && (m_pActiveScreen != NULL)
		&& (m_pActiveScreen->m_pCMMscreen->UseGroups == TRUE)
		&& (pkPenManager->IsGroupUsed(static_cast<T_PEN_GROUPS>(m_pActiveScreen->m_pCMMscreen->GroupIndex + 1)))) {
	// this is batch/group specific so set the group number
	ePEN_GROUP = static_cast<T_PEN_GROUPS>(m_pActiveScreen->m_pCMMscreen->GroupIndex + 1);
}
// unlock the critical section now we are finished with it
if (!bTHREAD_SAFE) {
	m_CritSec.Unlock();
}
return ePEN_GROUP;
}
//****************************************************************************
// const T_PEN_GROUPS GetActiveScreenGroupNo( const bool bTHREAD_SAFE )
///
/// Method that gets the active screen group number even if it is not valid
///
/// @param[in]		const bool bTHREAD_SAFE - Flag indicating if the operation is already thread
///					safe or it needs to use a critical section 
///
/// @return		The group number of the screen
///
//****************************************************************************
const T_PEN_GROUPS COpPanel::GetActiveScreenGroupNo(const bool bTHREAD_SAFE) {
T_PEN_GROUPS ePEN_GROUP = PEN_GROUP_ALL;
// get the critical section if necessary
if (!bTHREAD_SAFE) {
	m_CritSec.Lock();
}
// check all the requirements are satisfied for the sceen to be group specific
if ((m_pActiveScreen != NULL) && m_pActiveScreen->IsNonProcessScreen() == FALSE && // Few non process screens use Pen groups. Don't flash Batch Name as Batch may not be running at all
		(m_pActiveScreen->m_pCMMscreen->UseGroups == TRUE)) {
	// this is batch/group specific so set the group number
	ePEN_GROUP = static_cast<T_PEN_GROUPS>(m_pActiveScreen->m_pCMMscreen->GroupIndex + 1);
}
// unlock the critical section now we are finished with it
if (!bTHREAD_SAFE) {
	m_CritSec.Unlock();
}
return ePEN_GROUP;
}
#endif
#endif
//****************************************************************************
// void SetCaptureMode(	const T_OPPANEL_CAPTURE_MODE eCAPTURE_MODE, 
//							const QString &rstrCAPTURE_NAME )
///
/// Accessor for the capture mode variables
///
/// @param[in]	const T_OPPANEL_CAPTURE_MODE eCAPTURE_MODE - The required capture mode i.e. ext cf, usb1, printer etc 
/// @param[in]	const QString &rstrCAPTURE_NAME - The name/title for the capture file/printout
///
//****************************************************************************
void COpPanel::SetCaptureMode(const T_OPPANEL_CAPTURE_MODE eCAPTURE_MODE, const QString &rstrCAPTURE_NAME) {
m_eCaptureMode = eCAPTURE_MODE;
m_strCaptureName = rstrCAPTURE_NAME;
}
//****************************************************************************
///
/// Method that zooms in on the Y-scale for TUS screen (enables areas of interest to be focussed on)
///
/// @param[in]	const float fZERO - The new required zero
/// @param[in]	const float fSPAN - The new required span
///
//****************************************************************************
void COpPanel::ZoomInTUSYScale(const float fZERO, const float fSPAN) {
CDataItemPen *pkPen = reinterpret_cast<CDataItemPen*>( pDIT->GetDataItemPtr(DI_PEN, 0, gs_usSPECIAL_TUS_PEN_START_INST));
pkPen->SetZeroAndSpan(fZERO, fSPAN);
// update the scale information structure also
T_PSCALEINFO ptScaleInfo = pkPen->GetScaleInfo();
ptScaleInfo->Span = fSPAN;
ptScaleInfo->Zero = fZERO;
pkPen = reinterpret_cast<CDataItemPen*>( pDIT->GetDataItemPtr(DI_PEN, 0, gs_usSPECIAL_TUS_PEN_START_INST + 1));
pkPen->SetZeroAndSpan(fZERO, fSPAN);
// update the scale information structure also
ptScaleInfo = pkPen->GetScaleInfo();
ptScaleInfo->Span = fSPAN;
ptScaleInfo->Zero = fZERO;
// now rebuild the TUS screen
RebuildTUSScreen();
}
//****************************************************************************
///
/// Method that restores the original Y-scale for TUS screen
///
//****************************************************************************
void COpPanel::RestoreNormalTUSYScale() {
// we need to get the original zero and span from the configuration and restore it
CPenSetupConfig *pkPenSetupCfg = pSETUP->GetPenSetupConfig();
T_PPEN ptPen = pkPenSetupCfg->GetPen(gs_usSPECIAL_TUS_PEN_START_INST, ZERO_BASED, CONFIG_COMMITTED);
CDataItemPen *pkPen = reinterpret_cast<CDataItemPen*>( pDIT->GetDataItemPtr(DI_PEN, 0, gs_usSPECIAL_TUS_PEN_START_INST));
pkPen->SetZeroAndSpan(ptPen->Scale.Zero, ptPen->Scale.Span);
// update the scale information structure also
T_PSCALEINFO ptScaleInfo = pkPen->GetScaleInfo();
ptScaleInfo->Span = ptPen->Scale.Span;
ptScaleInfo->Zero = ptPen->Scale.Zero;
ZoomInTUSYScale(ptPen->Scale.Zero, ptPen->Scale.Span);
}
// Return number of screens, excluding non process screens
BOOL COpPanel::GetProcessScreenCount(int &nProcessScreens, int &nNonProcessScreens) {
CScreen *pScreen = m_pScreens;
nProcessScreens = 0;
nNonProcessScreens = 0;
while (pScreen != NULL) {
	if (!pScreen->IsNonProcessScreen())
		nProcessScreens++;
	else
		nNonProcessScreens++;
	pScreen = pScreen->m_pNextScr;
}
return TRUE;
}

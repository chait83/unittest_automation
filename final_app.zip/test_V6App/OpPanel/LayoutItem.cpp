/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: LayoutItem.cpp 
/// @n Description: Layout item class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Stability Project 1.7.1.3 7/2/2011 4:58:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:25 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:26 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:03:12 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "CMMDefines.h"
#include "LayoutItem.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
CLayoutItem::CLayoutItem(const T_ITEM_TYPE eITEM_TYPE /* = ptObject */) : m_eITEM_TYPE(eITEM_TYPE) {
}
CLayoutItem::~CLayoutItem() {
}

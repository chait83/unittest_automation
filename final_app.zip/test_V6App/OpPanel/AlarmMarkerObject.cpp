/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: AlarmMarkerObject.cpp
/// @n Description: Alarm Marker Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  51  Stability Project 1.46.1.3 7/2/2011 4:55:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  50  Stability Project 1.46.1.2 7/1/2011 4:37:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  49  Stability Project 1.46.1.1 3/17/2011 3:20:07 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  48  Stability Project 1.46.1.0 2/15/2011 3:02:04 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include <float.h>
#include <math.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#pragma warning( disable : 4244)
const USHORT CAlarmMarkerObject::ms_usALARM_DIT_REF_OFFSET = 1;
CAlarmMarkerObject::CAlarmMarkerObject(CWidget *pWidget) : CBaseObject(pWidget) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CAlarmMarkerObject::OnDraw;
	// set all of the object's internal settings to defaults
	m_DiInAlarmNotAckedInterFlashCol = RGB565(255, 255, 0); // yellow
	m_DiInAlarmAckedInterFlashCol = RGB565(255, 255, 0); // yellow
	m_DiOutAlarmNotAckedInterFlashCol = RGB565(255, 255, 0); // yellow
	m_DiOutAlarmAckedInterFlashCol = RGB565(255, 255, 0); // yellow
	m_pInAlarmNotAckedInterFlashCol = &m_DiInAlarmNotAckedInterFlashCol;
	m_pInAlarmAckedInterFlashCol = &m_DiInAlarmAckedInterFlashCol;	//In Alarm Acknowledged Flash Colour
	m_pOutAlarmNotAckedInterFlashCol = &m_DiOutAlarmNotAckedInterFlashCol;	//Out of Alarm Not Acknowledged Flash Colour
	m_pOutAlarmAckedInterFlashCol = &m_DiOutAlarmAckedInterFlashCol;	//Out of Alarm Acknowledged Flash Colour
	m_DiInAlarmNotAckedFlashCol = RGB565(255, 0, 0); // red, get the default from attribute block default
	m_DiInAlarmAckedFlashCol = RGB565(255, 0, 0);
	m_DiOutAlarmNotAckedFlashCol = RGB565(255, 0, 0);
	m_DiOutAlarmAckedFlashCol = RGB565(255, 0, 0);
	m_pInAlarmNotAckedFlashCol = &m_DiInAlarmNotAckedFlashCol;
	m_pInAlarmAckedFlashCol = &m_DiInAlarmAckedFlashCol;
	m_pOutAlarmNotAckedFlashCol = &m_DiOutAlarmNotAckedFlashCol;
	m_pOutAlarmAckedFlashCol = &m_DiOutAlarmAckedFlashCol;
	m_bLogScale = FALSE;
	m_bLogScaleScrDes = FALSE;
	m_bSetScale = FALSE;
	m_bInZoom = FALSE;
	m_ScaleReversed = FALSE;
	m_drawvalZero = 0;
	m_uTestCase = 0;
	m_TopLimit = 100.0;
	m_BottomLimit = 0.0;
	m_fZoomSpan = 100.0;
	m_fZoomZero = 0.0;
	for (int i = 0; i < (ms_usALARM_DIT_REF_OFFSET + V6_MAX_ALARMS); i++) {
		m_pDataItemRef[i] = NULL;
	}
	QString sAlarmNumber;
	m_csAlarmNum.clear();
	for (int j = 0; j < V6_MAX_ALARMS; j++) {
		sAlarmNumber = QString::asprintf("%d", j + 1);
		m_csAlarmNum.Add(sAlarmNumber);
	}
	memset(m_AlarmConfig, 0, sizeof(T_ALARMCFG) * V6_MAX_ALARMS);
//	memset(m_AlarmConfigDbg,0,sizeof(T_ALARMCFG)*V6_MAX_ALARMS);
	memset(m_ActiveAlarmNums, -1, sizeof(int) * V6_MAX_ALARMS);
//	m_AlarmConfigDbg[0].AlarmNum=0;
//	m_AlarmConfigDbg[1].AlarmNum=1;
//	m_AlarmConfigDbg[2].AlarmNum=2;
//	m_AlarmConfigDbg[3].AlarmNum=3;
//	m_AlarmConfigDbg[4].AlarmNum=4;
//	m_AlarmConfigDbg[5].AlarmNum=5;
	//these status entries correspond to the combobox entries in screen designer
	//to get to the numbers assigned by enum definitions, you need to add 7 to the
	//numbers you get from combo box entries
//	m_AlarmConfigDbg[0].AlarmStatus=1;
//	m_AlarmConfigDbg[1].AlarmStatus=2;
//	m_AlarmConfigDbg[2].AlarmStatus=3;
//	m_AlarmConfigDbg[3].AlarmStatus=1;
//	m_AlarmConfigDbg[4].AlarmStatus=4;
//	m_AlarmConfigDbg[5].AlarmStatus=2;
//	m_AlarmConfigDbg[0].InAlarm=TRUE;
//	m_AlarmConfigDbg[1].InAlarm=TRUE;
//	m_AlarmConfigDbg[2].InAlarm=TRUE;
//	m_AlarmConfigDbg[3].InAlarm=FALSE;
//	m_AlarmConfigDbg[4].InAlarm=TRUE;
//	m_AlarmConfigDbg[5].InAlarm=TRUE;
//	m_AlarmConfigDbg[0].Level=20;
//	m_AlarmConfigDbg[1].Level=40;
//	m_AlarmConfigDbg[2].Level=60;
//	m_AlarmConfigDbg[3].Level=80;
//	m_AlarmConfigDbg[4].Level=10;
//	m_AlarmConfigDbg[5].Level=0;
//	m_AlarmConfigDbg[0].Type=ALARM_TYPE_HIGH;
//	m_AlarmConfigDbg[1].Type=ALARM_TYPE_HIGH;
//	m_AlarmConfigDbg[2].Type=ALARM_TYPE_HIGH;
//	m_AlarmConfigDbg[3].Type=ALARM_TYPE_HIGH;
//	m_AlarmConfigDbg[4].Type=ALARM_TYPE_LOW;
//	m_AlarmConfigDbg[5].Type=ALARM_TYPE_LOW;
	m_DrawLevel = 0;
	m_nAlarmMarkerFontHeight = 0;
	m_nNumMarkers = V6_MAX_ALARMS;
	m_Orient = OBJECT_HORIZONTAL;
	m_ActiveAlarms = 0;
	m_bComputeIndents = TRUE;
	m_bPrevHoriz = FALSE;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Required size and position for a new Object
///
/// @return none
/// 
//****************************************************************************
void CAlarmMarkerObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CAlarmMarkerObject data in CMM info block.
	m_pCMMAlarmMrkr = (T_ALARMMRKROBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		// AlarmMarker has 6 channel references, (0 to 5)	
		for (int i = 0; i < V6_MAX_ALARMS; i++) {
			m_pCMMAlarmMrkr->ChannelInfo[i].Enabled = TRUE;
			m_pCMMAlarmMrkr->ChannelInfo[i].Updates = TRUE;
			m_pCMMAlarmMrkr->ChannelInfo[i].ItemType = DI_ALARM;
			m_pCMMAlarmMrkr->ChannelInfo[i].SubType = i; // Alarm Numbers(0-5)
			m_pCMMAlarmMrkr->ChannelInfo[i].IndexChan = 0; // use Widget's channel by default
		}
		// set these flags for specific Object (e.g. may be advanced draw only)
		/*
		 m_pCMMbase->IsAdvancedDraw
		 m_pCMMbase->IsBuffered
		 m_pCMMbase->IsPermanent
		 m_pCMMbase->IsBackground
		 m_pCMMbase->IsPrimaryDirect
		 // etc...
		 */
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
		// will use zero indent and span indent loaded from CMM
		m_bComputeIndents = FALSE;
		m_bPrevHoriz = m_pCMMAlarmMrkr->Orientation == OBJECT_HORIZONTAL;
	}
	Recalculate();
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CAlarmMarkerObject::ConfigChange() {
	// Data item configuration done here. 
	// example bar only has one data item reference and has the following CMM config:
	// ChannelInfo 
	//		ItemType = Pen
	//		IndexChan = 0	...index into Widget's Channel 'List'
	//		Instance = 1
	if (!m_pDataItemRef[0])
		m_pDataItemRef[0] = new CDataItemRef(this); // create our Pen reference (always)
	// get the pen data item reference
	if (m_pDataItemRef[0]) {
		// pass it to our Widget
		T_CHANNELREF tChanRef;
		tChanRef.Enabled = true;
		tChanRef.IndexChan = m_pCMMAlarmMrkr->ChannelInfo[0].IndexChan;
		tChanRef.ItemType = DI_PEN;
		tChanRef.Rotate = 1;
		tChanRef.SubType = 0;
		tChanRef.Updates = 1;
		m_pWidget->GetDataItem(m_pDataItemRef[0], &tChanRef);
	}
	int alarmCount;
	int ActiveAlarmIndex = 0;
	BOOL bAlarmEnabled;
	memset(m_ActiveAlarmNums, -1, sizeof(int) * V6_MAX_ALARMS);
	// create alarm ref if enabled only.
	m_ActiveAlarms = 0;
	for (alarmCount = 0; alarmCount < V6_MAX_ALARMS; alarmCount++) {
		if (!m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]) {
			if (m_pCMMAlarmMrkr->ChannelInfo[alarmCount].Enabled) {
				m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET] = new CDataItemRef(this); // create our single reference
				if (m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET])
					m_pWidget->GetDataItem(m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET],
							&m_pCMMAlarmMrkr->ChannelInfo[alarmCount]);
			} else {
				// reset the data item ref
				if (m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET] != NULL) {
					m_pWidget->DeleteDataItem(m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]);
					m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET] = NULL;
				}
			}
		} else if (m_pCMMAlarmMrkr->ChannelInfo[alarmCount].Enabled == FALSE) {
			// reset the data item ref
			if (m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET] != NULL) {
				m_pWidget->DeleteDataItem(m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]);
				m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET] = NULL;
			}
			m_AlarmConfig[alarmCount].AlarmStatus = DISTAT_INVALID;
		} else
			// get the data item pointer again
			m_pWidget->GetDataItem(m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET],
					&m_pCMMAlarmMrkr->ChannelInfo[alarmCount]);
		if (m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET] != NULL) {
#ifdef DOCVIEW
			bAlarmEnabled=true;
#else
			bAlarmEnabled = m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->IsEnabled();
#endif
			if (bAlarmEnabled) //m_pDataItemRef[ alarmCount + ms_usALARM_DIT_REF_OFFSET ]->m_pDataItem->IsEnabled() ) )
			{
				m_AlarmConfig[alarmCount].Type =
						m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetAlarmType();
				m_AlarmConfig[alarmCount].Level =
						m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetFPValue();
#ifndef DOCVIEW
				m_AlarmConfig[alarmCount].AlarmStatus =
						m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus();
#else
				m_AlarmConfig[ alarmCount ].AlarmStatus = DISTAT_OUT_OF_ALARM;
	#endif
				m_AlarmConfig[alarmCount].InAlarm =
						((m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus()
								== DISTAT_IN_ALARM_NOT_ACKED)
								|| (m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus()
										== DISTAT_IN_ALARM_ACKED)
								|| (m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus()
										== DISTAT_OUT_OF_ALARM_NOT_ACKED));
				if (m_AlarmConfig[alarmCount].AlarmStatus != DISTAT_NORMAL) {
					if (m_pCMMAlarmMrkr->HideInactiveAl) //Out of alarm, acknowledged
					{
						if (m_AlarmConfig[alarmCount].AlarmStatus != DISTAT_OUT_OF_ALARM) {
							m_ActiveAlarms++;
							m_ActiveAlarmNums[ActiveAlarmIndex++] = alarmCount;
						}
					} else {
						m_ActiveAlarms++;
						m_ActiveAlarmNums[ActiveAlarmIndex++] = alarmCount;
					}
				}
				if (m_AlarmConfig[alarmCount].InAlarm)
					m_pFlashing = &m_AlarmConfig[alarmCount].InAlarm; // m_InAlarm will get set when alarm is active.
			}
		}
	}
	//get BGCol which is the interflash colour from attribute blocks
	//Outof Acknowledged Alarm does not have flashing ON/OFF option. IT does not flash
	//but the display will have the interflashColour
	m_pInAlarmNotAckedInterFlashCol =
			&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_IN_NOT_ACK)->BGCol;
	m_pInAlarmAckedInterFlashCol =
			&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_IN_ACK)->BGCol;
	m_pOutAlarmNotAckedInterFlashCol = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
			ATTRIB_ALARM_OUT_NOT_ACK)->BGCol;
	m_pOutAlarmAckedInterFlashCol = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_OUT)->BGCol;
	//then based on user selection get the FGCol or user selected colour for flashing
	if (m_pCMMAlarmMrkr->FlashClrSelect)	//use custom colour
	{
		m_pInAlarmNotAckedFlashCol = &m_pCMMAlarmMrkr->InAlNoAckFlCol;
		m_pInAlarmAckedFlashCol = &m_pCMMAlarmMrkr->InAlAckFlCol;
		m_pOutAlarmNotAckedFlashCol = &m_pCMMAlarmMrkr->OutAlNoAckFlCol;
		m_pOutAlarmAckedFlashCol = &m_pCMMAlarmMrkr->OutAlFlCol;
	} else {
		//get colours from Attribute blocks
		//get FGCol which is the flash colour
		m_pInAlarmNotAckedFlashCol =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_IN_NOT_ACK)->FGCol;
		m_pInAlarmAckedFlashCol = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_IN_ACK)->FGCol;
		m_pOutAlarmNotAckedFlashCol = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
				ATTRIB_ALARM_OUT_NOT_ACK)->FGCol;
		m_pOutAlarmAckedFlashCol = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_OUT)->FGCol;
	}
	if (m_pDataItemRef[0]) {
		// pass it to our Widget, along with our CMM config
		T_CHANNELREF tChanRef;
		tChanRef.Enabled = true;
		tChanRef.IndexChan = m_pCMMAlarmMrkr->ChannelInfo[0].IndexChan;
		tChanRef.ItemType = DI_PEN;
		tChanRef.Rotate = 1;
		tChanRef.SubType = 0;
		tChanRef.Updates = 1;
		if (m_pWidget->GetDataItem(m_pDataItemRef[0], &tChanRef)) {
			// worked OK. Now set our members based on CMM settings and data item info
			T_PSCALEINFO ScaleDetails = m_pDataItemRef[0]->m_pDataItem->GetScaleInfo();
			m_bLogScale = ScaleDetails->LogScale;
			//DataItemGeneral generalDetails=m_pDataItemRef->m_pDataItem->GetGeneral(1);
			//ScaleDetails scaleDetails=m_pDataItemRef->m_pDataItem->GetScaleDetails(1);
			// T_BASEOBJECT CMM config to CBaseObject members:
			// set our internal members values from the source or CMM
			// we're using pen colour as foreground (text) colour and transparent
			// T_ALARMMRKROBJECT CMM config to CAlarmMarker Object members:
			if (!m_bSetScale)			///@todo, remove this check after testing, all scale params set here
			{
				if (!m_bInZoom)		///@todo, in zoom mode get the zoomZero and zoomSpan from whereever it is being set
									///here, it is set from the Screen Designer or DIT
				{
					if (m_bLogScale) {
						m_TopLimit = (float) (ScaleDetails->StartDecade + ScaleDetails->NumDecades);
						m_BottomLimit = ScaleDetails->StartDecade;
					} else {
						m_TopLimit = m_pDataItemRef[0]->m_pDataItem->GetSpan();
						m_BottomLimit = m_pDataItemRef[0]->m_pDataItem->GetZero();
					}
				} else//////@todo, get the value of m_fZoomSpan and m_fZoomZero from screen designer, radio button choice , or menu or something
				{
					m_TopLimit = m_fZoomSpan;				//this could be log scale Num Decades or linear scale Span
					m_BottomLimit = m_fZoomZero;			//this could be log scale Start Decade or linear scale Zero
				}
			} else///@todo, remove this whole else clause after testing. Is the scale type(lin/log), zoom mode set in SCr Designer?
			{
				m_bLogScale = m_bLogScaleScrDes;
			}
		}
	}
	if (m_pCMMbase->FixForeColour)
		// Use foreground colour from CMM (e.g. as selected in Screen Designer).
		m_pForeColour = &m_pCMMbase->ForeColour;
	else if (m_pCMMbase->AttrBlocks.ForeColourBlk)
		// Use foreground colour from Attribute block.
		m_pForeColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
	if (m_pCMMbase->FixBackColour)
		// Use background colour from CMM (e.g. as selected in Screen Designer).
		m_pBackColour = &m_pCMMbase->BackColour;
	else if (m_pCMMbase->AttrBlocks.BackColourBlk)
		// Use background colour from Attribute block.
		m_pBackColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
//	Recalculate();
	m_bPrevHoriz = m_pCMMAlarmMrkr->Orientation == OBJECT_HORIZONTAL;
}
void CAlarmMarkerObject::Recalculate() {
	RecalculateAlarmMarkerSize();
	RecalculateScaleLimits();
	RecalculateAlarmMarkerLanes();
}
void CAlarmMarkerObject::OnDraw(CAlarmMarkerObject *pThis, HDC hdc, QRect *pClipRect) {
	//if ( pThis->isObjectOverlapped() )
	//{
	//	return;
	//}
	CDC *pDC = CDC::FromHandle(hdc);
	int alarmCount;
	// if Update Required make any updates due to data item changes/flashing then do a repaint
	if (pThis->m_UpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object.
		if (pThis->m_UpdateValue) {
			pThis->m_ActiveAlarms = 0;
			int ActiveAlarmIndex = 0;
			BOOL bAlarmEnabled;
			for (alarmCount = 0; alarmCount < V6_MAX_ALARMS; alarmCount++) {
				if (pThis->m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET] != NULL) // using the associated alarm?			
				{
#ifdef DOCVIEW
					bAlarmEnabled=true;
#else
					bAlarmEnabled =
							pThis->m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->IsEnabled();
#endif
					if (bAlarmEnabled) //pThis->m_pDataItemRef[ alarmCount + ms_usALARM_DIT_REF_OFFSET ]->m_pDataItem->IsEnabled())
					{
						pThis->m_AlarmConfig[alarmCount].AlarmStatus = pThis->m_pDataItemRef[alarmCount
								+ ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus();
						pThis->m_AlarmConfig[alarmCount].InAlarm =
								((pThis->m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus()
										== DISTAT_IN_ALARM_NOT_ACKED)
										|| (pThis->m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus()
												== DISTAT_IN_ALARM_ACKED)
										|| (pThis->m_pDataItemRef[alarmCount + ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetStatus()
												== DISTAT_OUT_OF_ALARM_NOT_ACKED));
						if (pThis->m_AlarmConfig[alarmCount].AlarmStatus != DISTAT_NORMAL) // Normal is status when not in use.
								{
							// get the latest level for this alarm marker (may be updated)
							pThis->m_AlarmConfig[alarmCount].Level = pThis->m_pDataItemRef[alarmCount
									+ ms_usALARM_DIT_REF_OFFSET]->m_pDataItem->GetFPValue();
							if (pThis->m_pCMMAlarmMrkr->HideInactiveAl) //Out of alarm, acknowledged
							{
								if (pThis->m_AlarmConfig[alarmCount].AlarmStatus != DISTAT_OUT_OF_ALARM) {
									pThis->m_ActiveAlarms++;
									pThis->m_ActiveAlarmNums[ActiveAlarmIndex++] = alarmCount;
								}
							} else {
								pThis->m_ActiveAlarms++;
								pThis->m_ActiveAlarmNums[ActiveAlarmIndex++] = alarmCount;
							}
						}
						if (pThis->m_AlarmConfig[alarmCount].InAlarm)
							pThis->m_pFlashing = &pThis->m_AlarmConfig[alarmCount].InAlarm; // m_InAlarm will get set when alarm is active.
					}
				}
			}
			pThis->m_UpdateValue = FALSE;
		}
		// also handle and flashing updates here
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	}
	BOOL DrawInFlashState = FALSE;
	if (*(pThis->m_pFlashing)) // if we are flashing set our drawInFlashState.
		DrawInFlashState = pThis->m_FlashState;
	// Draw border if required.
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	pThis->m_ScaleReversed = IsScaleReversed(pThis);
	// Update the current clipping region. This handling will prevent
	// anything from being drawn outside the Alarm Marker object.
	pThis->m_pWidget->SetClipRect(hdc, &pThis->m_ClientRect);
	int nOldBkMode = pDC->GetBkMode();
	int nOldBkColour = pDC->GetBkColor();
	COLORREF crOldTextColour = pDC->GetTextColor();
	if (!pThis->m_pCMMbase->IsTransparent) {
		// Create a brush for background
		HBRUSH hBrushback = CreateSolidBrush(*pThis->m_pBackColour);
		FillRect(hdc, &pThis->m_ClientRect, hBrushback);
		// Delete the brush object and free all resources associated with it.
		DeleteObject(hBrushback);
	}
	pThis->m_Orient = pThis->m_pCMMAlarmMrkr->Orientation;	//0-horiz, 1-vert
	// End-user defined character for an Alarm Marker always drawn transparently.
	//the position of alarms s determined by the lavel
	//the lane spacing down(in case of horiz orentation)
	//and the lane spacing across(in case of vertical orintation)
	//is detemined by the numner of Acive alarms(m_ActiveAlarms)
	//we know how many alrams are active, scan thru alla the 6 to check whch ones are ative
	pThis->m_nPixel = (int) pThis->m_ClientRect.left + MARKER_LEFT_OFFSET;	//to begin with the left most position
	int nLane = 0;
	int iStatus;
	//at this point you have only alarms that are to be displayed
	for (alarmCount = 0; alarmCount < pThis->m_ActiveAlarms; alarmCount++) {
		iStatus = pThis->m_AlarmConfig[pThis->m_ActiveAlarmNums[alarmCount]].AlarmStatus;
		if (pThis->m_pLinked) {
			SetAlarmNumPos(pThis, pThis->m_ActiveAlarmNums[alarmCount]);
			pThis->m_nPixel = pThis->m_DrawLevel;
		}
		switch (iStatus) {
		case DISTAT_IN_ALARM_NOT_ACKED:
			if (pThis->m_pCMMAlarmMrkr->InAlNotAckFlsh)	//user sets flashing on
			{
				if (DrawInFlashState)	//check if it is draw in flashing state
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmNotAckedFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
				else
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmNotAckedInterFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
			} else	//set the colour to FGCol all the time in case of Alarms if any of the alarms is in flash state
			{
				if (*(pThis->m_pFlashing))
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmNotAckedFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
				else
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmNotAckedInterFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
			}
			break;
		case DISTAT_IN_ALARM_ACKED:
			if (pThis->m_pCMMAlarmMrkr->InAlAckedFlsh)	//user sets flashing on
			{
				if (DrawInFlashState)
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmAckedFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
				else
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmAckedInterFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
			} else {
				if (*(pThis->m_pFlashing))
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmAckedFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
				else
					pThis->DrawAlarmMarker(hdc, *pThis->m_pInAlarmAckedInterFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
			}
			break;
		case DISTAT_OUT_OF_ALARM_NOT_ACKED:
			if (pThis->m_pCMMAlarmMrkr->OutAlNoAckFlsh) {
				if (DrawInFlashState)
					pThis->DrawAlarmMarker(hdc, *pThis->m_pOutAlarmNotAckedFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
				else
					pThis->DrawAlarmMarker(hdc, *pThis->m_pOutAlarmNotAckedInterFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
			} else {
				if (*(pThis->m_pFlashing))
					pThis->DrawAlarmMarker(hdc, *pThis->m_pOutAlarmNotAckedFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
				else
					pThis->DrawAlarmMarker(hdc, *pThis->m_pOutAlarmNotAckedInterFlashCol, nLane,
							pThis->m_ActiveAlarmNums[alarmCount]);
			}
			break;
		case DISTAT_INVALID:
		case DISTAT_OUT_OF_ALARM:
			//	if(*(pThis->m_pFlashing)) ///@todo, not sure what check should be used for the colour
			pThis->DrawAlarmMarker(hdc, *pThis->m_pOutAlarmAckedFlashCol, nLane, pThis->m_ActiveAlarmNums[alarmCount]);
			//	else
			//		pThis->DrawAlarmMarker(hdc, *pThis->m_pOutAlarmAckedInterFlashCol, nLane,pThis->m_ActiveAlarmNums[alarmCount]);
			break;
		default:
			break;
		}
		if (!pThis->m_pLinked) {
			pThis->m_nPixel = pThis->m_nPixel + pThis->m_nCharCellWidth + MARKER_LEFT_OFFSET;
			//char can be drawn 2 pixels to the right(horiz) or 2 pixels down(vertical)
			if ((pThis->m_nPixel + pThis->m_nCharCellWidth) > (pThis->m_ClientRect.right - MARKER_LEFT_OFFSET))	//move to next Lane
					{
				nLane += 1;		//go to next lane, reset the postion to the beginning of next lane
				pThis->m_nPixel = (int) pThis->m_ClientRect.left + MARKER_LEFT_OFFSET;//to begin with the left most position
			}
		} else {
			nLane++;
		}
	}
	// Restore GDI objects after drawing Alarm MArkers
	pDC->SetBkMode(nOldBkMode);
	pDC->SetBkColor(nOldBkColour);
	pDC->SetTextColor(crOldTextColour);
	// Restore clipping region 
	pThis->m_pWidget->RestoreClipping(hdc);
}
void CAlarmMarkerObject::DrawAlarmMarker(HDC hdc, COLORREF crPenColour, int nLane, int nAlarmNum) {
	CDC *pDC = CDC::FromHandle(hdc);
	// Set up for drawing the Alarm MArker character.
	if (m_pCMMbase->IsTransparent)
		pDC->SetBkMode(TRANSPARENT);
	else
		pDC->SetBkColor(*m_pBackColour);
	BOOL bHoriz = m_pCMMAlarmMrkr->Orientation == OBJECT_HORIZONTAL;
	// Set up for drawing the AlarmMarker character.
	pDC->SetTextColor(crPenColour);
	WCHAR AlarmMarkerText[2];
	QSize size;
	QRect rc, TextRect;
	m_OffsetVertex = 0;
	switch (m_AlarmConfig[nAlarmNum].Type) {
	case ALARM_TYPE_HIGH:
		//first assume that scale is straight, linked or not linked condition
		AlarmMarkerText[0] = g_wcALARM_MKR_HI;
		m_Shape = TriUp;
		if (m_pLinked)		//if linked, deal with scale straight or reversed. Need to flip the symbols
		{
			if (m_ScaleReversed) {
				if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL) {
					AlarmMarkerText[0] = g_wcALARM_MKR_LO;
					m_Shape = TriDown;
					m_OffsetVertex = -m_nCharCellHeight + (m_nCharCellHeight / 6);
				} else {
					AlarmMarkerText[0] = g_wcTRI_BACKWARD;
					m_Shape = TriBackward;
					m_OffsetVertex = m_nCharCellWidth - (m_nCharCellWidth / 8);
				}
			} else {
				if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL) {
					m_Shape = TriUp;
					m_OffsetVertex = -(m_nCharCellHeight / 6);		//was m_nCharCellHeight
				} else {
					AlarmMarkerText[0] = g_wcTRI_FORWARD;
					m_Shape = TriForward;
				}
			}
		}
		break;
	case ALARM_TYPE_LOW:
		AlarmMarkerText[0] = g_wcALARM_MKR_LO;
		m_Shape = TriDown;
		if (m_pLinked) {
			if (m_ScaleReversed) {
				if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL) {
					AlarmMarkerText[0] = g_wcALARM_MKR_HI;
					m_Shape = TriUp;
					m_OffsetVertex = -(m_nCharCellHeight / 6);
				} else {
					AlarmMarkerText[0] = g_wcTRI_FORWARD;
					m_Shape = TriForward;
				}
			} else {
				if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL) {
					m_OffsetVertex = -m_nCharCellHeight + (m_nCharCellHeight / 6);
				} else {
					AlarmMarkerText[0] = g_wcTRI_BACKWARD;
					m_Shape = TriBackward;
					m_OffsetVertex = m_nCharCellWidth - (m_nCharCellWidth / 8);
				}
			}
		}
		break;
	case ALARM_TYPE_RATEUP:
		AlarmMarkerText[0] = g_wcALARM_MKR_RT_UP;
		m_Shape = TriRtUp;
		if (m_pLinked) {
			m_nPixel = m_drawvalZero;
			if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL)
				m_OffsetVertex = -m_nCharCellHeight / 8;
		}
		break;
	case ALARM_TYPE_RATEDOWN:
		AlarmMarkerText[0] = g_wcALARM_MKR_RT_DW;
		m_Shape = TriRtBackward;
		if (m_pLinked) {
			if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL) {
				m_nPixel = m_drawvalZero;
				m_OffsetVertex = m_nCharCellHeight - (m_nCharCellHeight / 3);
			} else
				m_nPixel = m_drawvalZero + m_nCharCellWidth + 2;	//leave a 2 pixel gap in between RateUp and RateDown
		}
		break;
	case ALARM_TYPE_DEVIATION:
		AlarmMarkerText[0] = g_wcALARM_MKR_DEV;
		m_Shape = Deviation;
		if (m_pLinked) {
			if (m_ScaleReversed) {
				if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL) {
					m_OffsetVertex = -m_nCharCellHeight + (m_nCharCellHeight / 8);		//was m_nCharCellHeight
				} else
					m_OffsetVertex = m_nCharCellWidth;
			} else {
				if (m_pCMMAlarmMrkr->Orientation == OBJECT_VERTICAL)
					m_OffsetVertex = -(m_nCharCellHeight / 10);		//was m_nCharCellHeight
			}
		}
		break;
	default:
		break;
	}
////////////////
	AlarmMarkerText[1] = 0; // terminator
	CFontCache *pfc;
	QFont hfont;
	QFont hOldfont;
	pfc = CFontCache::GetHandle();
	int yoffset = 0;
	hfont = pfc->GetNumericFont(m_nAlarmMarkerFontHeight, &yoffset);
	hOldfont = (QFont) pDC->SelectObject(hfont);
	//the GetTextExtentPoint call must be called after selecting the font
	GetTextExtentPoint(hdc, AlarmMarkerText, 1, &size);
	//assume that not linked condition
	rc.setleft(m_nPixel);
	rc.setBottom(m_ClientRect).top + m_ptArrowTip.y + (nLane * m_nLaneOffset);
	rc.setright(rc).left + m_nCharCellWidth;
	rc.setTop(rc).bottom - m_nCharCellHeight;
	if (m_pLinked) {
		if (bHoriz) {
			rc.setleft(m_nPixel) - m_OffsetVertex;
			rc.setBottom(m_ClientRect).top + m_ptArrowTip.y + (nLane * m_nLaneOffset);
			//rc.setTop(rc).bottom-m_nCharCellHeight-(m_ptArrowTip.y/8);
			rc.setTop(rc).bottom - m_nCharCellHeight;
			rc.setright(rc).left + m_nCharCellWidth;
			// Constrain the alarm marker to be inside the object's client rectangle.
			// This might lead to inaccuracies at the extremities of the range (scale),
			// but that was deemed to be acceptable.
			if (m_Shape == TriBackward && m_DrawLevel - m_nMarkerWidth < m_ClientRect.left)
				rc.OffsetRect(m_ClientRect.left - (m_DrawLevel - m_nMarkerWidth), 0); // shift right (+) into object
			else if (m_Shape == TriForward && m_DrawLevel + m_nMarkerWidth > m_ClientRect.right)
				rc.OffsetRect(m_ClientRect.right - (m_DrawLevel + m_nMarkerWidth), 0); // shift left (-) into object
		} else {
			rc.setleft(m_ClientRect).left + (nLane * m_nLaneOffset);
			rc.setBottom(m_nPixel) - m_OffsetVertex;
			rc.setTop(rc).bottom - m_nCharCellHeight;
			rc.setright(rc).left + m_nCharCellWidth;
			// Constrain the alarm marker to be inside the object's client rectangle.
			// This might lead to inaccuracies at the extremities of the range (scale),
			// but that was deemed to be acceptable.
			if (m_Shape == TriDown && m_DrawLevel + m_nMarkerHeight > m_ClientRect.bottom)
				rc.OffsetRect(0, m_ClientRect.bottom - (m_DrawLevel + m_nMarkerHeight)); // shift up (-) into object
			else if (m_Shape == TriUp && m_DrawLevel - m_nMarkerHeight < m_ClientRect.top)
				rc.OffsetRect(0, m_ClientRect.top - (m_DrawLevel - m_nMarkerHeight)); // shift down (+) into object
		}
	}
	//qDebug("rc={%d,%d,%d,%d}\n", rc.left, rc.top, rc.right, rc.bottom);
	//qDebug("m_pCMMAlarmMrkr->Height=%d m_nMarkerHeight=%d m_nMarkerWidth=%d m_OffsetVertex=%d m_nPixel=%d m_nAlarmMarkerFontHeight=%d\n", m_pCMMAlarmMrkr->Height, m_nMarkerHeight, m_nMarkerWidth, m_OffsetVertex, m_nPixel, m_nAlarmMarkerFontHeight);
	//qDebug("m_DrawLevel=%d m_drawvalZero=%d m_nCharCellHeight=%d m_nCharCellWidth=%d m_ptArrowTip.x=%d m_ptArrowTip.y=%d\n\n", m_DrawLevel, m_drawvalZero, m_nCharCellHeight, m_nCharCellWidth, m_ptArrowTip.x, m_ptArrowTip.y);
	// Begin testing support - draw a hollow, white rectangle around alarm marker rectangle
	//QBrush brush;
	//brush.CreateStockObject(HOLLOW_BRUSH);
	//QBrush *pOldBrush=pDC->SelectObject(&brush);
	//CPen pen;
	//pen.CreateStockObject(WHITE_PEN);
	//CPen *pOldPen=pDC->SelectObject(&pen);
	//pDC->Rectangle(rc);
	//pDC->SelectObject(pOldBrush);
	//pDC->SelectObject(pOldPen);
	// End testing support - draw a hollow, white rectangle around alarm marker rectangle
	pDC->DrawText(AlarmMarkerText, rc, DT_NOCLIP);
	pDC->SelectObject(hOldfont);
	pfc->ReleaseFont(hfont);
	// Set text colour white to draw pen number.
	// Set up for drawing the pen number.
	if (m_pCMMAlarmMrkr->Height > MARKER_HEIGHT_LIMIT_FOR_NUMPRINT) {
		pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(255, 255, 255));
		pfc = CFontCache::GetHandle();
		yoffset = 0;
		TextRect = rc;
		SetNumericArea(TextRect);
		hfont = pfc->GetNumericFont(
				(int) (m_nAlarmMarkerFontHeight * (m_pCMMAlarmMrkr->Orientation == OBJECT_HORIZONTAL ? 0.55 : 0.65)),
				&yoffset);
		hOldfont = (QFont) pDC->SelectObject(hfont);
		pDC->DrawText(m_csAlarmNum.at(nAlarmNum), TextRect, DT_NOCLIP);
		pDC->SelectObject(hOldfont);
		pfc->ReleaseFont(hfont);
	}
}
//****************************************************************************
///
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CAlarmMarkerObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
BOOL bHoriz=m_pCMMAlarmMrkr->Orientationon

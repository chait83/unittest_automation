/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CircularChartObject.h
/// @n Description: Circi Chart Object
// **************************************************************************
#ifndef _CIRCULARCHARTOBJ_H
#define _CIRCULARCHARTOBJ_H
#include "CirciViewModel.h"
#include "ScaleDrawingObject.h"
#define MAX_CIRCI_SCALES		1			// Maximum number of circi scales
//**Class*********************************************************************
///
/// @brief CCircularChartScaleObject Object
/// 
/// Encapsulates the scale primative for use in multiple sections around chart
///
//****************************************************************************
class CCircularChartScaleObject {
public:	// Members
	int m_Instance;					// Instance of sale 0 to MAX_CIRCI_SCALES
	bool m_Enabled;					// Enabled flag, only draw if enabled
	// Scale Object
	T_SCALEOBJECT m_Settings;		// Scale Object settings
	ScaleDrawingObject *m_pObj;		// Scale Object instance
	QRect m_Rect;					// Scale working Rect
	CDataItem *m_pChartDataItem;	// Pointer to data item
	// Required by ScaleObject interface but not used in Circi
	BOOL m_UpdateRequired;
	BOOL m_UpdateValue;
	BOOL m_UpdateFlash;
	BOOL m_FlashState;
public: // Methods
	CCircularChartScaleObject();
	~CCircularChartScaleObject();
	void Config(CDataItem *pDataItem, bool enabled);
	void SetRect(int centreX, int centreY, int radius, int holeRadius);
	void ReCalc();
	void Draw(HDC hdc, QRect *pClipRect);
	bool IsMaster() {
		return m_Instance == 0;
	}
};
// Update status results
enum CIRCULAR_UPDATE_STRIP_TYPE {
	UPDATE_CIRC_NONE = 0, UPDATE_CIRC_STRIP, UPDATE_CIRC_FULLWIDTH
};
//**Class*********************************************************************
///
/// @brief CircularChartObject Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used as a 'template' for all other derived Objects.
///
//****************************************************************************
class CCircularChartObject: public CBaseObject {
public:
	T_CIRCCHARTOBJECT *m_pCMMchart;			// pointer to our CMM configuration
	BOOL m_bShowingRealtime;				// External setting for showing realtime or peekview
	ChartSpeed m_ChartSpeed;				// Chart speed
private:
	BOOL m_RealtimeMode;					// Current mode being used, Realtime or Peek View
	CirciViewModel *vm;						// Pointer to circular view model
	QString m_ChartDurationAsStr;			// Chart duration as a string for quick redraw
	int m_enabledChartPens;					// Number of enabled Pen in chart
	CGrads m_grads;							// Graduation for chart background gradlines
	int m_TSfontHeight;						// Pre-calculated font height
	QRect m_TSrect;							// Pre-calculated time stamp bounding rect
	CCircularChartScaleObject m_Scale[MAX_CIRCI_SCALES];	// Scale instances
	bool m_FullDraw;						// Perform a full draw on the circular chart
	bool m_LeadingDraw;						// Perform only a leading draw (update readings in current point)
	LONGLONG m_LastUpdateTime;				// Last chart update/redraw time	
	LONGLONG m_LastTimeChangeValue;			// Indicator for last time change
private: // methods
	static void OnDraw(CCircularChartObject *pThis, HDC hdc, QRect *pClipRect);
	void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);
	void CalcTimestampsRect();
	void ValidatePositions(int &startPosition, int &endPosition);
	bool FullUpdateRequired();
	// Circular primatives
	void GenericDrawCircle(HDC sdc, int radius, int centreX, int centreY, COLORREF penColour, COLORREF fillColour);
	void DrawCircle(HDC sdc, int radius, COLORREF penColour, COLORREF fillColour);
	void DrawSegmentingLine(HDC sdc, float degrees, COLORREF colour, int width);
	void DrawBlankChart(HDC sdc);
	void DrawTraceElement(HDC sdc, float fromDegrees, float toDegrees, int fromHeight, int toHeight);
	void DrawFromTimeGradEntry(HDC sdc, int timeGradIndex);
	void DrawCirciTimeStamp(HDC sdc, CIRCI_TIMEGRADS *pTimeGrad);
	// Circular Drawing
	void DrawTraces(HDC sdc, int startPosition, int endPosition);
	void DrawMessages(HDC sdc, int startPosition, int endPosition);
	void DrawTimeGrads(HDC sdc, int startPosition, int endPosition);
	void DrawCirciDetails(HDC sdc);
	void DrawMessageMark(HDC sdc, int indexToDraw);
public:
	CCircularChartObject(CWidget *pWidget);
	~CCircularChartObject();
	// overidden functions that must be supplied
	void ReleaseSurfaces() {
	}
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);
	void ConfigChange();
	void Destroy();
	BOOL GetUpdateRect(QRect *pUpdateRect, LONGLONG time100);
	// Chart peek/realtime view controls
	void SetCircularChartMode(const BOOL showRealtime) {
		m_bShowingRealtime = showRealtime;
	}
	const BOOL IsShowingRealtimeData() const {
		return m_bShowingRealtime;
	}
};
#endif // _CIRCULARCHARTOBJ_H

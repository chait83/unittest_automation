/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CirciViewModel.h
/// @n Description: View model for the circular chart mode
// **************************************************************************
#include "OpPanelIncludes.h"
#include <float.h>
#include <math.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#pragma warning( disable : 4244)
#define PI				3.14159265358979		// PI to float resolution
#define DEGRESS_360		360						// 360 degree 
#define DEGRESS_180		180						// 180 degree 
//****************************************************************************
/// Circi View Model Constructor
//****************************************************************************
CirciViewModel::CirciViewModel() {
	m_CtlBuf = NULL;
	m_pMessageQ = NULL;
	m_pMessageQ = NULL;
	m_InitialisedMessages = FALSE;
	m_GroupNumber = 0;
	Reset();
	// Assign the parent VM to the trace VMs
	for (int p = 0; p < MAX_CIRCI_PENS; p++) {
		m_Trace[p].vm = this;
	}
	// Dummy dimensions
	SetDimensions(384, 384, 300, 20, 10, 10);
}
//****************************************************************************
/// Destructor
//****************************************************************************
CirciViewModel::~CirciViewModel() {
	DeleteControlBuffer();
}
//****************************************************************************
/// Reset
//****************************************************************************
void CirciViewModel::Reset() {
	ClearTimeGrads();
	DeleteControlBuffer();
}
//****************************************************************************
/// Clear down all trace data but leave time (control) allocation intact
///	
/// @return none
//****************************************************************************
void CirciViewModel::Clear() {
	for (int p = 0; p < MAX_CIRCI_PENS; p++) {
		m_Trace[p].ClearReadings();
	}
	m_lastReadingIx = 0;
}
//****************************************************************************
/// Set the position and dimensions of the circular chart
///	
/// @param[in] centreX	- Pixel X coordinate of circle centre
/// @param[in] centreY	- Pixel Y coordinate of circle centre
/// @param[in] radius	- Radius of circle in pixels
/// @param[in] centreHoleRadius	- Radius of centre hole of circular charts
/// @param[in] underrangeLeader	- distance in pixels between centre hole and zero grad (underrange area)
/// @param[in] overrangeLeader	- distance in pixels between outer radius and span (overrange area)
///
/// @return none
//****************************************************************************
void CirciViewModel::SetDimensions(int centreX, int centreY, int radius, int centreHoleRadius, int underrangeLeader,
		int overrangeLeader) {
	m_centreX = centreX;
	m_centreY = centreY;
	m_radius = radius;
	m_holeRadius = centreHoleRadius;
	m_zeroRadius = centreHoleRadius + underrangeLeader;
	m_spanRadius = radius - overrangeLeader;
}
//****************************************************************************
/// Set the position and dimensions from a bounding rect
///	
/// @param[in] *bounds			- Ptr to QRect structure of bounds to fit into
/// @param[in] padding			- padding in pixels between edge and radious of outer circle
///
/// @return none
//****************************************************************************
void CirciViewModel::SetDimensionsFromBoundingRect(QRect *bounds, int padding) {
	int width = (bounds->right - bounds->left);				// Width of rect
	int height = (bounds->bottom - bounds->top);			// Height of rect
	int maxRadius = (width > height) ? height : width;		// Max radious to fit
	maxRadius /= 2;
	int centreX = (width / 2) + bounds->left;				// Centre of rect X
	int centreY = (height / 2) + bounds->top;				// Centre of rect Y
	// Set the dimensions
	SetDimensions(centreX, centreY, maxRadius - padding, 15, 8, 8);
}
//****************************************************************************
/// Get corrdinates around circle from degrees and height
///	
/// @param[in] degrees	- Degrees around circle 0 - 360
/// @param[in] height	- Height of point in pixels
/// @param[out] xOut	- x coordinate out
/// @param[out] yOut	- y coordinate out
/// @param[in] clipToTrace	- Clip to trace area flag
///
/// @return none
/// 
//****************************************************************************
void CirciViewModel::GetCoordsFromHeightAndDegrees(float degrees, float height, int &xOut, int &yOut,
		bool clipToTrace) {
	// Do we ned to clip to trace area?
	if (clipToTrace) {
		// Yes check bounds and adjust as necessary
		if (height >= m_radius) {
			height = m_radius - 1;
		} else if (height <= m_holeRadius) {
			height = m_holeRadius + 1;
		}
	}
	// Calculate the screen coords
	xOut = (int) (cos((degrees * (PI / DEGRESS_180)) - (PI / 2)) * height) + m_centreX;
	yOut = (int) (sin((degrees * (PI / DEGRESS_180)) - (PI / 2)) * height) + m_centreY;
}
//****************************************************************************
/// Get corrdinates around circle from degrees and height
///	
/// @param[in] degrees		- Degrees around circle 0 - 360
/// @param[in] height		- Height of point in pixels
/// @param[out] pt			- x coordinates out as QPoint
/// @param[in] clipToTrace	- Clip to trace area flag
///
/// @return none
/// 
//****************************************************************************
void CirciViewModel::GetCoordsFromHeightAndDegrees(float degrees, float height, QPoint &pt, bool clipToTRace) {
	int x, y;
	GetCoordsFromHeightAndDegrees(degrees, height, x, y, clipToTRace);
	pt.x = x;
	pt.y = y;
}
//****************************************************************************
/// Get rectangle coords around circle of height in pixels from centre
///	
/// @param[in] height	- Height of point in pixels
///
/// @return QRect structure with bounding rectagle coords from centre
/// 
//****************************************************************************
QRect CirciViewModel::GetBoundingRectFromHeight(int height) {
	QRect r;
	r.setleft(m_centreX) - height;
	r.setTop(m_centreY) - height;
	r.setright(m_centreX) + height;
	r.setBottom(m_centreY) + height;
	return r;
}
//****************************************************************************
/// Allocate control buffer 
///
/// @return - nothing
//****************************************************************************
void CirciViewModel::AllocateControlBuffer() {
	// Setup the control readings
	DeleteControlBuffer();
	m_CtlBuf = new CIRCI_CONTROL_READING[m_NumReadings];
	ClearControlBuffer();
}
//****************************************************************************
/// Delete control buffer if allocated
///
/// @return - nothing
//****************************************************************************
void CirciViewModel::DeleteControlBuffer() {
	if (m_CtlBuf != NULL) {
		delete[] m_CtlBuf;
	}
	m_CtlBuf = NULL;
}
//****************************************************************************
/// Cleardown control buffer to defaults
///
/// @return - nothing
//****************************************************************************
void CirciViewModel::ClearControlBuffer() {
	if (m_CtlBuf != NULL) {
		for (int i = 0; i < m_NumReadings; i++) {
			memset(&m_CtlBuf[i], 0, sizeof(CIRCI_CONTROL_READING));
		}
		memset(&nullCtlReading, 0, sizeof(CIRCI_CONTROL_READING));
	}
	m_lastReadingIx = 0;
}
//****************************************************************************
/// Get a pointer to the relevant control reading
///
/// @return - Required control reading, or NULL pattern object
//****************************************************************************
CIRCI_CONTROL_READING* CirciViewModel::GetControlReading(int index) {
	CIRCI_CONTROL_READING *ctrlReading = &nullCtlReading;
	if (m_CtlBuf != NULL) {
		if (index < 0 || index >= m_NumReadings) {
			qDebug("CIRCI ERROR: Control reading requested for invalid index %d", index);
		} else {
			ctrlReading = &m_CtlBuf[index];
		}
	}
	return ctrlReading;
}
//****************************************************************************
/// Cleardown control buffer Time grad lookups
///
/// @return - nothing
//****************************************************************************
void CirciViewModel::ClearControlBufferTimeGrads() {
	if (m_CtlBuf != NULL) {
		for (int i = 0; i < m_NumReadings; i++) {
			m_CtlBuf[i].TimeGrad = 0;
		}
	}
}
//****************************************************************************
/// Cleardown time graduations
///
/// @return - nothing
//****************************************************************************
void CirciViewModel::ClearTimeGrads() {
	for (int i = 0; i < MAX_CIRCI_TIME_GRADS; i++) {
		m_TimeGrads[i].Type = CTT_NONE;
		m_TimeGrads[i].PositionInDegrees = CTT_NONE;
	}
	m_NumGrads = 1;
}
//****************************************************************************
/// Get a time graduation
///	
/// @param[in] index	- index of time graduation to retreive
///
/// @return - ptr to time grad entry
//****************************************************************************
CIRCI_TIMEGRADS* CirciViewModel::GetTimeGrad(int index) {
	if (index > m_NumGrads) {
		index = 0;
	}
	return &m_TimeGrads[index];
}
//****************************************************************************
/// Add a time graduation
///	
/// @param[in] type	- T_CIRC_TIMEGRAD_TYPE of the type of graduation to add
/// @param[in] positionInDegrees	- position in degrees of time graduation
///
/// @return - nothing
//****************************************************************************
void CirciViewModel::AddTimeGraduation(T_CIRC_TIMEGRAD_TYPE type, float positionInDegrees) {
	// Make sure we don't exceed time graduations
	if (m_NumGrads < MAX_CIRCI_TIME_GRADS) {
		// Assign Time Graduation type and position
		m_TimeGrads[m_NumGrads].Type = type;
		m_TimeGrads[m_NumGrads].PositionInDegrees = positionInDegrees;
		// Calculate the time of the timestamp for the graduation
		LONGLONG offsetTime = m_ChartStartTime.GetMicroSecs();
		offsetTime += (LONGLONG) SEC_TO_USEC((double )positionInDegrees * m_SecsPerDegree);
		// Round the timestamp up if < 0.5 seconds short, for rounding errors on long timespans
		LONGLONG roundDiff = USEC_IN_A_SEC - (offsetTime % USEC_IN_A_SEC);
		if (roundDiff < (USEC_IN_A_SEC / 2)) {
			offsetTime += roundDiff;
		}
		// Assign timestamp
		m_TimeGrads[m_NumGrads].TimeStamp = offsetTime;
		// Set time graduation lookup in relevant control position
		m_CtlBuf[GetReadingIndexByDegrees(positionInDegrees)].TimeGrad = m_NumGrads;
		m_NumGrads++;
	} else {
		qDebug("CIRCI ERROR: Time Grads exceeded allocation %d", MAX_CIRCI_TIME_GRADS);
	}
}
//****************************************************************************
/// Update start and end tick times
///	
/// @return - nothing
//****************************************************************************
void CirciViewModel::UpdateTickLimits() {
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	// Get start time in ticks
	DetailedTimeEntry tEntry = pTh->GetDetailedTimeEntry(m_ChartStartTime);
	m_ChartStartTimeInTicks = GetTicksFromTimeEntry(m_ChartStartTime, &tEntry);
	// Get end time in ticks
	tEntry = pTh->GetDetailedTimeEntry(m_ChartEndTime);
	m_ChartEndTimeInTicks = GetTicksFromTimeEntry(m_ChartEndTime, &tEntry);
}
//****************************************************************************
/// Setup time graduations for Major, Minor and Sub minor
///	
/// @param[in] startTime		- Start time of chart
/// @param[in] timeSpanSeconds	- time span of chart in seconds
/// @param[in] numMajor			- Number of major divisions
/// @param[in] numMinor			- Number of minor divisions per major division
/// @param[in] numSubMinor		- Number of sub minor divisions per minor division
///
/// @return - Nothing
//****************************************************************************
void CirciViewModel::SetDataInfo(CTVtime startTime, long timeSpanSeconds, int numReadings, int numMajor, int numMinor,
		int numSubMinor) {
	// Allocate readings
	m_NumReadings = numReadings;
	m_DegreesPerReading = (float) DEGRESS_360 / numReadings;
	// Allocate control buffer
	AllocateControlBuffer();
	// Assign start time and span of chart
	m_ChartStartTime = startTime;
	m_ChartSpanUSec = SEC_TO_USEC((LONGLONG )timeSpanSeconds);
	m_ChartEndTime = m_ChartStartTime.GetMicroSecs() + m_ChartSpanUSec;
	m_SecsPerDegree = (double) timeSpanSeconds / (double) DEGRESS_360;
	m_USecsPerReading = m_ChartSpanUSec / numReadings;
	m_TicksPerReading = CONVERT_MICROS_TO_100(m_USecsPerReading);
	m_lastReadingIx = 0;
	// Update start and end tick times
	UpdateTickLimits();
	// Calculate the converage in degrees of each graduation.
	float majCoverage = (float) DEGRESS_360 / numMajor;
	float minCoverage = majCoverage / numMinor;
	float subCoverage = minCoverage / numSubMinor;
	float majPos = 0;
	// Cleardown exisiting time grad lookups in control buffer
	ClearControlBufferTimeGrads();
	// Cleardown the current time grads
	ClearTimeGrads();
	// Itterate through Major time grads
	for (int maj = 0; maj < numMajor; maj++) {
		AddTimeGraduation(CTT_MAJOR, majPos);
		float minPos = majPos;
		float subPos = minPos;
		// Itterate through minor time grads for each major
		for (int min = 1; min < numMinor; min++) {
			subPos = minPos;
			// Itterate through sub minor for each minor
			for (int sub = 1; sub < numSubMinor; sub++) {
				subPos += subCoverage;
				AddTimeGraduation(CTT_SUB_MINOR, subPos);
			}
			minPos += minCoverage;
			AddTimeGraduation(CTT_MINOR, minPos);
		}
		subPos = minPos;
		// Complete the last set of sub minors 
		for (int sub = 1; sub < numSubMinor; sub++) {
			subPos += subCoverage;
			AddTimeGraduation(CTT_SUB_MINOR, subPos);
		}
		majPos += majCoverage;
	}
}
//****************************************************************************
/// Get the absolute time in USec from an index entry 
///	
/// @param[in] index	- Reading index to get the USEC time from
///
/// @return - absolute time of reading in USec
//****************************************************************************
LONGLONG CirciViewModel::GetUsecTimeFromReadingIndex(int index) {
	return m_ChartStartTime.GetMicroSecs() + (m_USecsPerReading * index);
}
//****************************************************************************
/// Get the absolute time in ticks from a realtime and time history entry
///	
/// @param[in] targetTime	- Target time to get in ticks
/// @param[in] pEntry		- ptr to time history entry
///
/// @return - time in ticks of realtime entry
//****************************************************************************
LONGLONG CirciViewModel::GetTicksFromTimeEntry(CTVtime targetTime, DetailedTimeEntry *pEntry) {
	LONGLONG diff100toTimeRequired = CONVERT_MICROS_TO_100(
			(targetTime.GetMicroSecs() - pEntry->ActualTime.GetMicroSecs()));
	return pEntry->StartTick100 + diff100toTimeRequired;
}
//****************************************************************************
/// Update the readings to the required position 
///	
/// @param[in] timeToUpdateTo	- time we need to update to
///
/// @return - number fo reading to update
//****************************************************************************
int CirciViewModel::UpdateReadings(CTVtime timeToUpdateTo) {
	// Get a handle on the time history table
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	// Get the last time we uopdated something
	CTVtime lastTime(GetUsecTimeFromReadingIndex(m_lastReadingIx));
	// If this is prior to our last update, ignore
	if (timeToUpdateTo < lastTime) {
		return 0;
	}
	// How many readiungs do we need to update?
	int numReadingsToUpdate = (timeToUpdateTo.GetMicroSecs() - lastTime.GetMicroSecs()) / m_USecsPerReading;
	// Get the end index we need to update to
	int toReadingIx = m_lastReadingIx + numReadingsToUpdate;
	// Has this exceed our current chart?
	if (toReadingIx >= m_NumReadings) {
		// Yes, We need a new chart, however this is not the place to make that decision, so finish
		// the population of this chart first.
		toReadingIx = m_NumReadings - 1;
	}
	CIRCI_CONTROL_READING *cr;
	CTVtime startReadingTime, endReadingTime;
	// Run through all readings to be updated including the latest
	for (int i = m_lastReadingIx; i <= toReadingIx; i++) {
		// Calculate start and end time of the readings
		startReadingTime = GetUsecTimeFromReadingIndex(i);
		endReadingTime = startReadingTime + m_USecsPerReading;
		// Get the associated control reading
		cr = GetControlReading(i);
		// Is there a time calculated for this already?
		if (cr->AbsQueueTick == 0) {
			// No, we need to calculate the tick time from the realtime
			// so get entry in time table to reconcile real time with tick time
			DetailedTimeEntry pEntry = pTh->GetDetailedTimeEntry(startReadingTime);
			// Get the end time as the point could span multiple time slots
			DetailedTimeEntry pEntryEnd = pTh->GetDetailedTimeEntry(endReadingTime);
			// We have a reading that spans a time history entry (i.e start of reading coverage uses one time history and the end uses another)
			// the safe approach is to show the latest data rather then the earliest as this reading slot
			if (pEntry.EndTick100 != pEntryEnd.EndTick100) {
				// Entry is the end entry and start reading time must be moved forward to the start reading time entry
				pEntry = pEntryEnd;
				// Is the next time entry after the current start reading time
				if (pEntryEnd.ActualTime > startReadingTime) {
					// Yes, make sure we use this time, it must also be before end time otherwise 
					// we would not get two entries being different
					startReadingTime = pEntryEnd.ActualTime;
				}
			}
			// Is this entry valid for the reading we are trying to resolve?
			if (pEntry.ActualTime <= endReadingTime) {
				// Yes, we can use this to calculate the position in ticks.
				// Calculate the tick difference between the time entry and the time we need
				LONGLONG diff100toTimeRequired = CONVERT_MICROS_TO_100(
						(startReadingTime.GetMicroSecs() - pEntry.ActualTime.GetMicroSecs()));
				LONGLONG targetEntry = pEntry.StartTick100 + diff100toTimeRequired;
				// Is the calculated entry within the current tick coverage?
				if (pEntry.EndTick100 == 0 || targetEntry <= pEntry.EndTick100) {
					// Yes, this is a valid reading.
					cr->Coverage = true;
					// Save calculated time
					cr->AbsQueueTick = targetEntry;
					// Calculate the end time of the reading
					cr->AbsQueueTickEnd = targetEntry + m_TicksPerReading;
					// Does the reading span over a time change/reset
					if (pEntry.EndTick100 != 0 && cr->AbsQueueTickEnd > pEntry.EndTick100) {
						// Yes, cap the span to this reading
						cr->AbsQueueTickEnd = pEntry.EndTick100;
					}
				}
			}
		}
		if (cr->AbsQueueTick == 0) {
			// No, time history does not go back this far, no data available so
			// indicate there is no coverage for this reading 
			cr->Coverage = false;
		}
	}
	// Get chart Q handle and lock queues for updates
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->WaitLock(4);
	// Update Pen traces
	for (int p = 0; p < m_EnabledTraces; p++) {
		GetTrace(p)->UpdateReadingsFromQueue(m_lastReadingIx, toReadingIx);
	}
	// Update Messages
	UpdateMessagesFromQueue(m_lastReadingIx, toReadingIx);
	CM->Unlock();
	// Update current reading position
	m_lastReadingIx = m_lastReadingIx + numReadingsToUpdate;
	return numReadingsToUpdate;
}
//****************************************************************************
/// Update messages from the queue
///	
/// @param[in] fromIndex - From index to update
/// @param[in] toIndex	 - To index to update
///
/// @return - nothing
//****************************************************************************
void CirciViewModel::UpdateMessagesFromQueue(int fromIndex, int toIndex) {
	if (m_pMessageQ) {
		ReadMessageContext rmc;
		// Control reading for determining target tick time required
		CIRCI_CONTROL_READING *cr;
		// Itterate theough all indexes required to update
		for (int i = fromIndex; i <= toIndex; i++) {
			// Get control reading
			cr = GetControlReading(i);
			// Is there coverage at this point?
			if (cr->Coverage) {
				rmc.m_LocateTime = cr->AbsQueueTick;
				rmc.m_ReqTpp = m_TicksPerReading;
				rmc.m_GroupNumber = m_GroupNumber;
				// Get the first message for the timeslot
				MESSRET retval = m_pMessageQ->GetFirstMessage(&rmc);
				// While we have at least one valid message
				while (retval == MESSAGE_OK) {
					// Is the message in our timeslot?
					if (rmc.m_LocateTime <= cr->AbsQueueTickEnd) {
						// Yes, lets defualt to the lowest priority indicator
						int messIndicator = CIRCI_MESSAGE_INDICATOR_MESSAGE;
						// Is this an alarm in message
						if (rmc.m_pCurMessage->message.messageType == MSGLISTSER_ALARM_INTO) {
							// Yes, regsiter alarm in
							messIndicator = CIRCI_MESSAGE_INDICATOR_ALARM_IN;
						}
						// Or is it an alarm out indicator
						else if (rmc.m_pCurMessage->message.messageType < MSGLISTSER_ALARM_MGS_TYPE_LAST) {
							// Yes, register alarm out
							messIndicator = CIRCI_MESSAGE_INDICATOR_ALARM_OUT;
						}
						// Only update message type with a higher priority message
						if (messIndicator > cr->Message) {
							// Assign message
							cr->Message = messIndicator;
						}
					} else {
						// No longer time within this reading
						break;
					}
					// Check and get next message for this timeslot 
					retval = m_pMessageQ->GetNextMessage(&rmc);
				}
			}
		}
	}
}
//****************************************************************************
/// Get the reading index by degrees
///	
/// @param[in] degrees	- Degrees to get reaing from
///
/// @return Index of control or trace reading
//****************************************************************************
int CirciViewModel::GetReadingIndexByDegrees(float degrees) {
	int index = 0;
	// limit check
	if (degrees < 0.0 || degrees > DEGRESS_360) {
		qDebug("CIRCI ERROR: GetReadingIndexByDegrees() ouside 0-360 %f", degrees);
		return 0;
	}
	// Get index
	index = (int) (degrees * m_DegreesPerReading);
	// Make sure we don't overrun
	index %= m_NumReadings;
	return index;
}
//****************************************************************************
/// Set the data reading information
///	
/// @param[in] index	- Trace index
///
/// @return none
//****************************************************************************
void CirciViewModel::AllocateTraceReadings(int index) {
	CirciTrace *pTrace = GetTrace(index);
	pTrace->AllocateReadings(m_NumReadings);
}
//****************************************************************************
/// GetTrace pointer
///	
/// @param[in] index	- Trace index
///
/// @return Pointer to trace index, or null object pattern if outside bounds
//****************************************************************************
CirciTrace* CirciViewModel::GetTrace(int index) {
	if (index < 0 || index >= MAX_CIRCI_PENS) {
		// Conform to null onject pattern to avoid constant null checks.
		return &m_NullObjectTrace;
	}
	return &m_Trace[index];
}
//====================================================================================
/// CirciTrace class
//====================================================================================
//****************************************************************************
/// Constructor
//****************************************************************************
CirciTrace::CirciTrace() {
	// Make sure no false allocation detected in Reset 
	m_Buf = NULL;
	// Reset trace to defaults
	Reset();
}
//****************************************************************************
/// Destructor
//****************************************************************************
CirciTrace::~CirciTrace() {
	DeleteBuffer();
}
//****************************************************************************
/// Reset the trace details and clear trace buffer
///
/// @return - nothing
//****************************************************************************
void CirciTrace::Reset() {
	m_pChartDataItem = NULL;
	m_pChartQ = NULL;
	m_Initialised = false;
	DeleteBuffer();
}
//****************************************************************************
/// Allocate buffer with a nunber of readings
///	
/// @param[in] readings	- Number of trace readings to allocate
///
/// @return - nothing
//****************************************************************************
void CirciTrace::AllocateReadings(int readings) {
	DeleteBuffer();
	m_NumReadings = readings;
	m_Buf = new CIRCI_TRACE_READING[readings];
	ClearReadings();
}
//****************************************************************************
/// Cleardown buffer to defaults
///
/// @return - nothing
//****************************************************************************
void CirciTrace::ClearReadings() {
	if (m_Buf != NULL) {
		for (int i = 0; i < m_NumReadings; i++) {
			memset(&m_Buf[i], 0, sizeof(CIRCI_TRACE_READING));
		}
	}
}
//****************************************************************************
/// Update the readings to the required position 
///	
/// @param[in] fromIndex - From index to update
/// @param[in] toIndex	 - To index to update
///
/// @return - nothing
//****************************************************************************
void CirciTrace::UpdateReadingsFromQueue(int fromIndex, int toIndex) {
	if (m_pChartQ) {
		// Read context for access to chart queue
		ReadContext rc;
		memset(&rc, 0, sizeof(ReadContext));
		// Control reading for determining target tick time required
		CIRCI_CONTROL_READING *cr;
		// Itterate theough all indexes required to update
		for (int i = fromIndex; i <= toIndex; i++) {
			// Get control reading
			cr = vm->GetControlReading(i);
			// Is there coverage at this point?
			if (cr->Coverage) {
				// Yes, setup to locate the data
				rc.m_LocateTime = cr->AbsQueueTick;
				rc.m_RecTpp = vm->m_TicksPerReading;
				// Read there queue
				CHARTRET locateResult;
				locateResult = m_pChartQ->GetFirstReadingCirci(&rc);
				// Is the result valid and the time of the reading returned valid for current reading use?
				if (locateResult == DATA_OK && (rc.m_LocateTime < cr->AbsQueueTickEnd)) {
					// Yes, update the reading.
					UpdateReading(i, rc.m_min, rc.m_max);
					//qDebug("%d - %d: %d (%f - %f)\n",toIndex-fromIndex, i, (int)rc.m_LocateTime, rc.m_min, rc.m_max );
				}
			}
		}
	}
}
//****************************************************************************
/// Update Reading
///
/// @param[in] index	- index, 
/// @param[in] min		- Number of trace readings to allocate
/// @param[in] max		- Number of trace readings to allocate
///
/// @return - nothing
//****************************************************************************
void CirciTrace::UpdateReading(int index, float min, float max) {
	// Check we are within bounds
	if (index < 0 || index >= m_NumReadings) {
		// No, exit
		qDebug("CIRCI ERROR: Trace reading index exceeded, Max = %d, attepmted = %d", m_NumReadings, index);
		return;
	}
	CIRCI_TRACE_READING *pThis = &m_Buf[index];
	// Is this the first time reading updated?
	if (m_Buf[index].Status == CRS_NO_READING) {
		// Yes, is this not the first reading, i.e. has a previous reading
		if (index > 0) {
			// Get ptr to previous reading
			CIRCI_TRACE_READING *pPrev = &m_Buf[index - 1];
			// Is there a valid previous reading?
			if (pPrev->Status > CRS_NO_READING) {
				// Yes, so make sure the new max and min align with top or bottom
				// if new min is greater then previous max, make new min=previous max to make sure they join
				min = (min > pPrev->Max) ? pPrev->Max : min;
				// if new max is smaller then previous min, make new max=previous min to make sure they join
				max = (max < pPrev->Min) ? pPrev->Min : max;
			}
		}
	} else {
		// We've already set max and min, but might need to build up multiple readings for this reading position
		// Do a max/min on the exiting values to build up the complete max/min picture
		max = (pThis->Max > max) ? pThis->Max : max;
		min = (pThis->Min < min) ? pThis->Min : min;
	}
	// Add reading details
	pThis->Status = CRS_READING_UPDATED;
	pThis->Max = max;
	pThis->Min = min;
}
//****************************************************************************
/// Delete reading buffer if allocated
///
/// @return - nothing
//****************************************************************************
void CirciTrace::DeleteBuffer() {
	if (m_Buf != NULL) {
		delete[] m_Buf;
	}
	m_Buf = NULL;
	m_NumReadings = 0;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: TabularDisplayObject.cpp
/// @n Description: Tabular Display Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.0.1.4 7/2/2011 5:01:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.0.1.3 7/1/2011 4:39:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.0.1.2 3/17/2011 3:20:49 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  3 Stability Project 1.0.1.1 2/15/2011 3:04:02 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $ 1-YVI2O0 In Tabular Screen Empty space available at bottom of the Screen which 
// is not used for display. (Kranti)
//		PSR - Reverted the above 1-YVI2O0 changes
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include <float.h>
#include "MathUtils.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// Statics Initialisation
const USHORT CTabularDisplayObject::ms_usQX_NO_OF_PEN_COLS = 6;
const USHORT CTabularDisplayObject::ms_usSX_NO_OF_PEN_COLS = 12;
float CTabularDisplayObject::m_fResFactor = 0;
//****************************************************************************
///
/// Constructor
///
/// @param[in/out] CWidget *pWidget - Pointer to the parent widget
/// 
//****************************************************************************
CTabularDisplayObject::CTabularDisplayObject(CWidget *pWidget) : CBaseObject(pWidget), m_usNoOfCols(0), m_usNoOfSetsOfSingleReadings(
		0), m_usNoOfRowsPerSetOfReadings(0) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CTabularDisplayObject::OnDraw;
	// set all of the object's internal settings to defaults
	m_bInAlarm = FALSE;
	m_pFlashing = &m_bInAlarm;
	for (int nLane = 0; nLane < MAX_TABULAR_PENS; nLane++) {
		m_pDataItemRef[nLane] = NULL;
		m_bCurrentAlarm[nLane] = FALSE;
	}
	m_crInnerBorderColour = RGB(127, 127, 127);
	m_crCellBackGndColour = RGB(255, 255, 255);
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Required size and position for a new Object
///
/// @return none
/// 
//****************************************************************************
void CTabularDisplayObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CTabularDisplayObject data in CMM info block.
	m_pCMMTabDisp = (T_TABULAROBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		// set these flags for specific Object (e.g. may be advanced draw only)
		/*
		 m_pCMMbase->IsAdvancedDraw
		 m_pCMMbase->IsPermanent
		 m_pCMMbase->IsB#include "BitmapObj.h"ackground
		 m_pCMMbase->IsPrimaryDirect
		 // etc...
		 */
		m_pCMMbase->IsBuffered = TRUE;
	} else {
		// When loading a previous configuration:
	}
	ConfigChange();
	getResFactorFromOpPanel();
}
//****************************************************************************
///
/// compare function to pass to qsort in SetBounds method to sort
/// the data item references by pen number. The arguments arg1 and arg2 point
/// to a CDataItemRef pointer each, which represent the two pens to compare.
///
/// @param[in] arg1	- Pointer to first data item reference pointer
/// @param[in] arg2	- Pointer to second data item reference pointer
///
/// @return <0 for Pen1<Pen2; ==0 for Pen1==Pen2 or >0 for Pen1>Pen2
/// 
//****************************************************************************
int CTabularDisplayObject::CompareDataItemRefs(const void *arg1, const void *arg2) {
	CDataItemRef **pPen1 = (CDataItemRef**) arg1;
	CDataItemRef **pPen2 = (CDataItemRef**) arg2;
	return GetPenNumber(*pPen1) - GetPenNumber(*pPen2);
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CTabularDisplayObject::ConfigChange() {
	// Data item configuration done here. 
	T_CHANNELREF channelInfo;
	channelInfo.Enabled = TRUE;
	channelInfo.Updates = TRUE;
	channelInfo.Rotate = 1; // always set here, if set for the widget will rotate (not applicable to this object though)
	channelInfo.ItemType = DI_PEN;
	channelInfo.SubType = 0;
	int nIndex = 0;
	// Loop over the pen channels in the widget and maintain in the widget
	// data item references for those pens that are enabled. Remove from the
	// widget any data item references for disabled pens. After the loop we
	// we will thus have an array of size MAX_TABULAR_PENS of data item
	// reference pointers. We will move all non-NULL pointers up in the array.
	for (nIndex = 0; nIndex < MAX_TABULAR_PENS; nIndex++) {
		if (nIndex < m_pWidget->m_pCMMwidget->NumChannels) {
			if (m_pDataItemRef[nIndex] == NULL) {
				m_pDataItemRef[nIndex] = new CDataItemRef(this); // create our pen reference
			}
			if (m_pDataItemRef[nIndex] != NULL) {
				channelInfo.IndexChan = nIndex; // use widget's channel index
				m_pWidget->GetDataItem(m_pDataItemRef[nIndex], &channelInfo);
				if (!m_pDataItemRef[nIndex]->m_pDataItem->IsEnabled()) // is the data item actually enabled?
				{
					// delete it now as we don't want this to continually get added to the widget link list
					// thus causing a gradual decline in memory
					m_pWidget->DeleteDataItem(m_pDataItemRef[nIndex]);
					m_pDataItemRef[nIndex] = NULL;
				}
			}
		} else {
			if (m_pDataItemRef[nIndex] != NULL) // already configured this reference?
			{
				// delete it now as we don't want this to continually get added to the widget link list
				// thus causing a gradual decline in memory
				m_pWidget->DeleteDataItem(m_pDataItemRef[nIndex]);
				m_pDataItemRef[nIndex] = NULL;
			}
		}
	}
	// Determine the number of enabled pen channels (m_nNumPens) in the widget. Move all the
	// enabled data item references to be at m_pDataItemRef[0] to m_pDataItemRef[m_nNumPens-1]
	// so that the rest of the code doesn't have to worry about testing for NULL data item refs.
	m_nNumPens = 0;
	for (nIndex = 0; (nIndex < m_pWidget->m_pCMMwidget->NumChannels) && (nIndex < MAX_TABULAR_PENS); nIndex++) {
		if (m_pDataItemRef[nIndex] != NULL) // have an enabled pen reference
		{
			if (m_nNumPens != nIndex) {
				m_pDataItemRef[m_nNumPens] = m_pDataItemRef[nIndex];
				m_pDataItemRef[nIndex] = NULL;
			}
			m_nNumPens++;
		}
	}
	// Set our members based on CMM settings and data item info
	// T_BASEOBJECT CMM config to CBaseObject members:
	if (m_pCMMbase->FixForeColour) {
		// Use foreground colour from CMM (e.g. as selected in Screen Designer).
		m_pForeColour = &m_pCMMbase->ForeColour;
	} else if (m_pCMMbase->AttrBlocks.ForeColourBlk) {
		// Use foreground colour from Attribute block.
		m_pForeColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
	} else {
		// set the forecolour to the cmm base object colour as we have to make the time appear and that isn't
		// pen related
		m_pForeColour = &m_pCMMbase->ForeColour;
	}
	if (m_pCMMbase->FixBackColour) {
		// Use background colour from CMM (e.g. as selected in Screen Designer).
		m_pBackColour = &m_pCMMbase->BackColour;
	} else if (m_pCMMbase->AttrBlocks.BackColourBlk) {
		// Use background colour from Attribute block.
		m_pBackColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
	}
	// make the cell colour the same as the backgrounds colour for now
	m_crCellBackGndColour = *m_pBackColour;
	// Use visible attribute from Attribute block if set (1=default=TRUE).
	m_pVisible = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
	// T_TABULAROBJECT CMM config to CTabularDisplayObject members - currently these capabilities aren't 
	// used/implemented
	if (m_pCMMTabDisp->FlshFGonAlarm) {
		if (m_pCMMTabDisp->FixFGAlarmCol) {
			m_pForeAlarmColour = &m_pCMMTabDisp->FGAlarmCol;
		} else {
			m_pForeAlarmColour =
					&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_OVERVIEW)->FGCol;
		}
	} else {
		m_pForeAlarmColour = NULL; // not used
	}
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	// set up the initial (current) status and value for the pens
	m_bInAlarm = FALSE;
	for (int nLane = 0; nLane < m_nNumPens; nLane++) {
		if (m_bCurrentAlarm[nLane] = m_pDataItemRef[nLane]->m_pDataItem->GetAlarmStatus() > 0) {
			m_bInAlarm = TRUE;
		}
		// get the scale information
		m_patScaleInfo[nLane] = m_pDataItemRef[nLane]->m_pDataItem->GetScaleInfo();
		CMathUtils::InitNumberasprintf(m_patScaleInfo[nLane]->NumF, m_awcasprintfStr[nLane],
				sizeof(m_awcasprintfStr[nLane]), m_patScaleInfo[nLane]);
	}
	// determine the rect sizes
	DetermineRectSizes();
}
//****************************************************************************
///
/// This function will setup the correct row/column/cell sizes for the tabular display
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CTabularDisplayObject::DetermineRectSizes() {
	// make sure num pens is not 0
	int iNumPens = m_nNumPens;
	if (iNumPens <= 0) {
		iNumPens = 1;
	}
	float nResFactor = 1;
	T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
	// check if this is a minitrend 
	if ( pDEVICE_INFO->IsRecorderMini()) {
		nResFactor = 2;
		m_usNoOfRowsPerSetOfReadings = (iNumPens + (ms_usQX_NO_OF_PEN_COLS - 1)) / ms_usQX_NO_OF_PEN_COLS;
		m_usNoOfCols = ms_usQX_NO_OF_PEN_COLS + 1;
		// QX and QXe recorders may have between 1 and 3 rows of readings per time slice
		switch (m_usNoOfRowsPerSetOfReadings) {
		case 1:
			m_iInnerDataRowStartPos = 2 * nResFactor;
			m_iInnerDataRowHeight = 24 * nResFactor;
			m_iDifferentReadingsSeperation = 1 * nResFactor;
			m_iInnerDataRowEndPos = 3 * nResFactor;
			m_iInnerDataRowHorizBorder = 1 * nResFactor;
			m_usNoOfSetsOfSingleReadings = 8 /** nResFactor*/;
			break;
		case 2:
			m_iInnerDataRowStartPos = 2 * nResFactor;
			m_iInnerDataRowHeight = 24 * nResFactor;
			m_iDifferentReadingsSeperation = 2 * nResFactor;
			m_iInnerDataRowEndPos = 2 * nResFactor;
			m_iInnerDataRowHorizBorder = 1 * nResFactor;
			m_usNoOfSetsOfSingleReadings = 4 /** nResFactor*/;
			break;
		case 3:
			m_iInnerDataRowStartPos = 2 * nResFactor;
			m_iInnerDataRowHeight = 22 * nResFactor;
			m_iDifferentReadingsSeperation = 1 * nResFactor;
			m_iInnerDataRowEndPos = 2 * nResFactor;
			m_iInnerDataRowHorizBorder = 1 * nResFactor;
			m_usNoOfSetsOfSingleReadings = 3 /** nResFactor*/;
			break;
		default:
			// should never happen
#ifdef _DEBUG
				DebugBreak();
#endif
			break;
		}
	} else if ( pDEVICE_INFO->IsRecorderEzTrend()) {
		nResFactor = 1;
		m_usNoOfRowsPerSetOfReadings = (iNumPens + (ms_usQX_NO_OF_PEN_COLS - 1)) / ms_usQX_NO_OF_PEN_COLS;
		m_usNoOfCols = ms_usQX_NO_OF_PEN_COLS + 1;
		// QX and QXe recorders may have between 1 and 3 rows of readings per time slice
		switch (m_usNoOfRowsPerSetOfReadings) {
		case 1:
			m_iInnerDataRowStartPos = 2;
			m_iInnerDataRowHeight = 24;
			m_iDifferentReadingsSeperation = 1;
			m_iInnerDataRowEndPos = 3;
			m_iInnerDataRowHorizBorder = 1;
			m_usNoOfSetsOfSingleReadings = 8;
			break;
		case 2:
			m_iInnerDataRowStartPos = 2;
			m_iInnerDataRowHeight = 24;
			m_iDifferentReadingsSeperation = 2;
			m_iInnerDataRowEndPos = 2;
			m_iInnerDataRowHorizBorder = 1;
			m_usNoOfSetsOfSingleReadings = 4;
			break;
		case 3:
			m_iInnerDataRowStartPos = 2;
			m_iInnerDataRowHeight = 22;
			m_iDifferentReadingsSeperation = 1;
			m_iInnerDataRowEndPos = 2;
			m_iInnerDataRowHorizBorder = 1;
			m_usNoOfSetsOfSingleReadings = 3;
			break;
		default:
			// should never happen
#ifdef _DEBUG
				DebugBreak();
#endif
			break;
		}
	} else {
		nResFactor = 1.28;
		m_usNoOfRowsPerSetOfReadings = (iNumPens + (ms_usSX_NO_OF_PEN_COLS - 1)) / ms_usSX_NO_OF_PEN_COLS;
		m_usNoOfCols = ms_usSX_NO_OF_PEN_COLS + 1;
		// SX recorders may have between 1 and 2 rows of readings per time slice
		switch (m_usNoOfRowsPerSetOfReadings) {
		case 1:
			m_iInnerDataRowStartPos = 4 * nResFactor;
			m_iInnerDataRowHeight = 26 * nResFactor;
			m_iDifferentReadingsSeperation = 1 * nResFactor;
			m_iInnerDataRowEndPos = 4 * nResFactor; //PSR - Reverted the 1-YVI2O0 changes
			m_iInnerDataRowHorizBorder = 2 * nResFactor;
			m_usNoOfSetsOfSingleReadings = 20 /** nResFactor*/;
			break;
		case 2:
			m_iInnerDataRowStartPos = 3 * nResFactor;
			m_iInnerDataRowHeight = 26 * nResFactor;
			m_iDifferentReadingsSeperation = 2 * nResFactor;
			m_iInnerDataRowEndPos = 4 * nResFactor; //PSR - Reverted the 1-YVI2O0 changes
			m_iInnerDataRowHorizBorder = 3 * nResFactor;
			m_usNoOfSetsOfSingleReadings = 10 /** nResFactor*/;
			break;
		case 3:
			m_iInnerDataRowStartPos = 4 * nResFactor;
			m_iInnerDataRowHeight = 25 * nResFactor;
			m_iDifferentReadingsSeperation = 2 * nResFactor;
			m_iInnerDataRowEndPos = 4 * nResFactor; //PSR - Reverted the 1-YVI2O0 changes
			m_iInnerDataRowHorizBorder = 3 * nResFactor;
			m_usNoOfSetsOfSingleReadings = 7 /** nResFactor*/;
			break;
		default:
			// should never happen
#ifdef _DEBUG
				DebugBreak();
#endif
			break;
		}
	}
}
//****************************************************************************
///
/// Method that returns the pen number for the passed in data item reference
///
/// @param[in]	CDataItemRef *pDataItemRef - The data item to check
///
/// @return The pen number of the passed in data item reference
///
//****************************************************************************
int CTabularDisplayObject::GetPenNumber(CDataItemRef *pDataItemRef) {
	CDataItemPen *pDataItemPen = (CDataItemPen*) pDataItemRef->m_pDataItem;
	return pDataItemPen->m_pPenConfig->Instance;
}
//****************************************************************************
///
/// Method that returns the pen number for the passed in lane number (as in cell
/// number on the tabular display)
///
/// @param[in]	int nLane - The lane number to get the pen number for
///
/// @return The pen number of the passed in lane number
///
//****************************************************************************
int CTabularDisplayObject::GetPenNumber(int nLane) {
	return GetPenNumber(m_pDataItemRef[nLane]);
}
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CTabularDisplayObject::OnDraw(CTabularDisplayObject *pThis, HDC hdc, QRect *pClipRect) {
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	// if Update Required make any updates due to data item changes/flashing then do a repaint
	if (pThis->m_UpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object.
		if (pThis->m_UpdateValue) {
			// Cache current values and alarm status.
			pThis->m_bInAlarm = FALSE;
			for (int nLane = 0; nLane < pThis->m_nNumPens; nLane++) {
				if (pThis->m_bCurrentAlarm[nLane] = pThis->m_pDataItemRef[nLane]->m_pDataItem->GetAlarmStatus() > 0) {
					pThis->m_bInAlarm = TRUE;
				}
			}
			pThis->m_UpdateValue = FALSE;
		}
		// also handle any flashing updates here even though they aren't currently used at the moment
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	}
	// Draw border if required - shouldn't happen with our canned screens
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered)) {
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	}
	// Update the current clipping region. This handling will prevent
	// anything from being drawn outside the pen pointers object.
	pThis->m_pWidget->SetClipRect(hdc, &pThis->m_ClientRect);
	CDC *pDC = CDC::FromHandle(hdc);
	int nOldBkMode = pDC->GetBkMode();
	int nOldBkColour = pDC->GetBkColor();
	COLORREF crOldTextColour = pDC->GetTextColor();
	WCHAR wcaPenTag[ PEN_TAG_LEN + 5];
	WCHAR wcaPenVal[20];
	if (!pThis->m_pCMMbase->IsTransparent) {
		// Create a brush for background
		HBRUSH hBrushback = CreateSolidBrush(*pThis->m_pBackColour);
		FillRect(hdc, &pThis->m_ClientRect, hBrushback);
		// Delete the brush object and free all resources associated with it.
		DeleteObject(hBrushback);
	}
	// now fill the area in which the readings will be going
	QRect tInnerArea;
	tInnerArea.setTop(pThis)->m_iInnerDataRowStartPos + pThis->m_ClientRect.top;
	tInnerArea.bottom = (pThis->m_ClientRect.bottom - pThis->m_iInnerDataRowEndPos);
	tInnerArea.setleft(pThis)->m_ClientRect.left + pThis->m_iInnerDataRowHorizBorder;
	tInnerArea.setright(pThis)->m_ClientRect.right - pThis->m_iInnerDataRowHorizBorder;
	{
		HBRUSH hInnerBdrBrush = CreateSolidBrush(pThis->m_crInnerBorderColour);
		FillRect(hdc, &tInnerArea, hInnerBdrBrush);
		// Delete the brush object and free all resources associated with it.
		DeleteObject(hInnerBdrBrush);
	}
	//Aditya
	QRect tCell;
	tCell.setleft(tInnerArea).left + 1;
	tCell.setright(tInnerArea).right - 1;
	tCell.setTop(tInnerArea).top;
	tCell.setBottom(tCell).top + pThis->m_iInnerDataRowHeight;
	HBRUSH hCellBackGndBrush = CreateSolidBrush(pThis->m_crCellBackGndColour);
	// bias the width slight towards the date/time cell by making the cells 1 pixel smaller
	// that it could be - the remainder pixels are added to the time date column
	const int iCELL_WIDTH = ((tInnerArea.right - tInnerArea.left) / pThis->m_usNoOfCols) - 1;
	int ileftOverPixels = ((tInnerArea.right - tInnerArea.left) - (pThis->m_usNoOfCols * iCELL_WIDTH));
	// take off the border/line between the time and readings and the fact we want 1 pixel on
	// the left and right edges
	ileftOverPixels -= 3;
	// Get the font for the required pen pointer size.
	CFontCache *pkFontCache = CFontCache::GetHandle();
	int iYOffset = 0;
	QFont hOldFont;
	QFont hFont;
	QFont hSymbolFont;
	T_DEV_TYPE devType = pGlbDal->GetDeviceType();
	if (devType == DEV_ARISTOS_MINITREND || devType == DEV_PC_MINI) {
		//Aditya - Modified font in Tabular screen
		hFont = pkFontCache->GetNumericFont(11, &iYOffset);
		hSymbolFont = pkFontCache->GetNumericFont(12, &iYOffset);
	} else if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_PC_MULTI || devType == DEV_SCR_MINITREND) {
		//Aditya - Modified font in Tabular screen . // //Aditya. //PAR:1-1NA990N
		hFont = pkFontCache->GetNumericFont1(11.5, &iYOffset);//Aditya: Modified from 13 to 13.5 and created one more function to take float values //1-YVI2O0
		hSymbolFont = pkFontCache->GetNumericFont(14, &iYOffset);
	} else {
		hFont = pkFontCache->GetNumericFont(8, &iYOffset);
		hSymbolFont = pkFontCache->GetNumericFont(9, &iYOffset);
	}
	hOldFont = (QFont) pDC->SelectObject(hFont);
	// copy the normal cell background colour for this - can be changed in the future
	COLORREF crInactiveCell = pThis->m_crCellBackGndColour;
	HBRUSH hCellBackGndInactiveBrush = CreateSolidBrush(crInactiveCell);
	COLORREF crSeperatorLineCol = RGB(200, 200, 200);
	//
	// Stability Project Fix:
	//
	QPen hSeperatorLinePen = ::CreatePen(PS_SOLID, 1, crSeperatorLineCol);
	QPen hOldPen = (QPen) SelectObject(hdc, hSeperatorLinePen);
	int iPens = 0;
	bool bCurrentReadingsValid = false;
	T_DATAITEM_STATUS ePenStatus = DISTAT_NORMAL;
	float fPenValue = 0;
	// lock access to the readings while we are reading this information
	pTABULAR.lockForUpdates();
	// set to the first/newest set of readings
	if ( pTABULAR->SetToNewestReadings()) {
		bCurrentReadingsValid = true;
	}
	// done the background now loop through and draw the inner cells
	for (USHORT usReadingSet = 0; usReadingSet < pThis->m_usNoOfSetsOfSingleReadings; usReadingSet++) {
		// move by the border seperation between groups of readings
		tCell.setTop(pThis)->m_iDifferentReadingsSeperation;
		tCell.setBottom(pThis)->m_iDifferentReadingsSeperation;
		// draw the time/date cell
		tCell.setleft(tInnerArea).left + 1;
		tCell.setright(tCell).left + iCELL_WIDTH + ileftOverPixels;
		// the time cell might need to span multiple rows therefore create a seperate rect from
		// this point
		QRect tTimeCell = tCell;
		tTimeCell.bottom += (pThis->m_iInnerDataRowHeight * (pThis->m_usNoOfRowsPerSetOfReadings - 1));
		// fill in the cell background for the time cell
		FillRect(hdc, &tTimeCell, hCellBackGndBrush);
		// draw the date and time cell first
		WCHAR wcaDateTime[26];
		wcaDateTime[0] = 0;
		if (bCurrentReadingsValid) {
			CStringUtils::SafeWcsCpy(wcaDateTime, pTABULAR->GetCurrentReadingLogTime(), 26);
		}
		// set the correct text colour	
		pDC->SetTextColor(*pThis->m_pForeColour);
		DrawText(hdc, wcaDateTime, static_cast<int>(wcslen(wcaDateTime)), &tTimeCell,
				DT_CENTER | DT_WORDBREAK /*| DT_VCENTER */);
		// now loop through all the pens writing the values in each cell
		for (iPens = 0; iPens < pThis->m_nNumPens; iPens++) {
			// determine the status and if not valid then setup the appropriate symbols
			ePenStatus = pTABULAR->GetCurrentReadingPenStatus(pThis->m_pDataItemRef[iPens]->Instance);
			fPenValue = pTABULAR->GetCurrentReadingPenValue(pThis->m_pDataItemRef[iPens]->Instance);
			// move the current cell position left or to the beginning 
			if ((iPens % (pThis->m_usNoOfCols - 1)) == 0) {
				// move to the beginning of the row
				tCell.setleft(tInnerArea).left + ileftOverPixels + iCELL_WIDTH + 2;
				tCell.setright(tCell).left + iCELL_WIDTH;
				// If not the first pen then move on to the next line
				if (iPens != 0) {
					// move down on the next line for this set of readings
					tCell.setTop(pThis)->m_iInnerDataRowHeight;
					tCell.setBottom(pThis)->m_iInnerDataRowHeight;
				}
			} else {
				// move right onto the next cell
				tCell.setLeft(iCELL_WIDTH);
				tCell.setRight(iCELL_WIDTH);
			}
			// fill in the cell background for the pen value cell
			FillRect(hdc, &tCell, hCellBackGndBrush);
			// draw a seperator line assuming this isn't the last cell in a line
			if ((iPens + 1) % (pThis->m_usNoOfCols - 1)) {
				MoveToEx(hdc, tCell.right - 1, tCell.top, NULL);
				LineTo(hdc, tCell.right - 1, tCell.bottom);
			}
			// now add the pen information - pen tag, value and symbol
			swprintf(wcaPenTag, L"%u:%s", pThis->GetPenNumber(iPens) + 1,
					pThis->m_pDataItemRef[iPens]->m_pDataItem->GetTag());
			if (ePenStatus < DISTAT_NORMAL) {
				// add arrows for known out-of-range conditions
				if (ePenStatus == DISTAT_INPUT_OVERRANGE) {
					wcaPenVal[0] = 0xE051;
					wcaPenVal[1] = 0xE051;
					wcaPenVal[2] = 0xE051;
					wcaPenVal[3] = 0xE051;
					wcaPenVal[4] = 0x0000;
				} else if (ePenStatus == DISTAT_INPUT_UNDERRANGE) {
					wcaPenVal[0] = 0xE050;
					wcaPenVal[1] = 0xE050;
					wcaPenVal[2] = 0xE050;
					wcaPenVal[3] = 0xE050;
					wcaPenVal[4] = 0x0000;
				} else if (ePenStatus == DISTAT_INPUT_UPSCALE_BURNOUT) {
					wcaPenVal[0] = 0xE051;
					wcaPenVal[1] = 0xE051;
					wcaPenVal[2] = 0xE051;
					wcaPenVal[3] = 0x0000;	// show 3 arrows only, to show a difference to very high temperature
				} else if (ePenStatus == DISTAT_INPUT_DOWNSCALE_BURNOUT) {
					wcaPenVal[0] = 0xE050;
					wcaPenVal[1] = 0xE050;
					wcaPenVal[2] = 0xE050;
					wcaPenVal[3] = 0x0000;	// show 3 arrows only to show a difference to very low temperature
				} else {
					// fill with large '*' EUDC chars.
					wcaPenVal[0] = 0xE027;
					wcaPenVal[1] = 0xE027;
					wcaPenVal[2] = 0xE027;
					wcaPenVal[3] = 0xE027;
					wcaPenVal[4] = 0x0000;
				}
			} else {
				// change to scientific when very large, or in log scale, if in Auto mode
				// better to keep log scale consistently in scientific. But if the customer doesn't like it,
				// disable auto decimal places.
				BOOL logScale = pThis->m_patScaleInfo[iPens]->LogScale;
				if ((pThis->m_patScaleInfo[iPens]->NumF.Auto == TRUE)
						&& (pThis->m_patScaleInfo[iPens]->NumF.Scientific == FALSE)
						&& ((fPenValue > 9999999.0) || (fPenValue < -9999999.0) || logScale))
						// if value is higher than can be displayed in normal notation, or is log scale, change to scientific
						{
					// convert the value to formatted string
					swprintf(wcaPenVal, sizeof(wcaPenVal) / sizeof(WCHAR), L"%.1e", fPenValue); // scientific notation
					int length = (int) wcslen(wcaPenVal);
					wcsncpy_s(&wcaPenVal[length - 3], 3, &wcaPenVal[length - 2], 3); // copy last 3 digits (including null) one character back in the string
				} else {
					// convert the value to formatted string
					swprintf(wcaPenVal, sizeof(wcaPenVal) / sizeof(WCHAR), pThis->m_awcasprintfStr[iPens], fPenValue);
					// test for scientific and if so, remove third from last digit to give 2-digit exponent
					if (pThis->m_patScaleInfo[iPens]->NumF.Scientific) {
						int length = (int) wcslen(wcaPenVal);
						wcsncpy_s(&wcaPenVal[length - 3], 3, &wcaPenVal[length - 2], 3); // copy last 3 digits (including null) one character back in the string
					}
					// negative out-of-range numbers only display one exponent digit in a DPM. 
					// It would be possible to set Auto up to only print one exponent if the number is a negative number
					// under -10^9. Negative numbers greater than this could be set to display no negative places.
					// But this could also cause confusion due to inconsistency: for now, don't bother
					// The number can be read by clicking to a DPM only screen
				}
			}
			// under range and over range displayed using with EUDC characters 
			wchar_t SymbolText[2] = { 0, 0 };
			int Symbolwidth = 10 * m_fResFactor; // width of over and under range characters
			if (!pThis->m_bIsQXRecorder) {
				Symbolwidth = 14 * m_fResFactor;
			}
			if (ePenStatus > DISTAT_NORMAL) {
				if (ePenStatus == DISTAT_UNDERRANGE) {
					SymbolText[0] = 0xE052;
				}
				if (ePenStatus == DISTAT_OVERRANGE) {
					SymbolText[0] = 0xE053;
				}
			}
			QRect tValCell = tCell;
			// trim the edges so we don't get text in adjacent cells butting right up against each other
			tValCell.setLeft(1);
			tValCell.setRight(1);
			tValCell.top += (pThis->m_iInnerDataRowHeight / 2);
			QRect tSymCell = tValCell;
			// if there is a symbol to display then we need to make room for it by reducing
			// the pen value field
			if (SymbolText[0]) {
				tSymCell.setright(tSymCell).left + Symbolwidth;
				tValCell.setleft(tSymCell).right;
			}
			// now draw the pen tag, value and symbol
			if (!pThis->m_pCMMTabDisp->Base.FixForeColour) {
				pDC->SetTextColor(*pThis->m_pDataItemRef[iPens]->m_pDataItem->GetColour());
			}
			SetBkColor(hdc, pThis->m_crCellBackGndColour);
			QRect tTagCell = tCell;
			tTagCell.bottom -= (pThis->m_iInnerDataRowHeight / 2);
			tTagCell.setRight(1);
			tTagCell.setLeft(1);
			// only draw the text if the readings are valid, otherwise we will just leave them blank
			if (bCurrentReadingsValid) {
				// draw the pen tag
				DrawText(hdc, wcaPenTag, static_cast<int>(wcslen(wcaPenTag)), &tTagCell,
						DT_WORD_ELLIPSIS | DT_CENTER | DT_SINGLELINE | DT_VCENTER);
				// draw the symbol is one is necessary
				if (SymbolText[0]) {
					pDC->SelectObject(hSymbolFont);
					DrawText(hdc, SymbolText, static_cast<int>(wcslen(SymbolText)), &tSymCell,
							DT_CENTER | DT_SINGLELINE | DT_VCENTER);
					pDC->SelectObject(hFont);
					// draw the pen value
					DrawText(hdc, wcaPenVal, static_cast<int>(wcslen(wcaPenVal)), &tValCell,
							DT_SINGLELINE | DT_VCENTER);
				} else {
					// draw the pen value
					DrawText(hdc, wcaPenVal, static_cast<int>(wcslen(wcaPenVal)), &tValCell,
							DT_CENTER | DT_SINGLELINE | DT_VCENTER);
				}
			}
		}
		// check if we have some empty cells on the current line
		if ((iPens % (pThis->m_usNoOfCols - 1)) != 0) {
			// yes we do therefore loop round and blank their background
			do {
				// move the cell position right
				tCell.setLeft(iCELL_WIDTH);
				tCell.setRight(iCELL_WIDTH);
				// draw the extra cells but in a grey colour
				FillRect(hdc, &tCell, hCellBackGndInactiveBrush);
				++iPens;
			} while ((iPens % (pThis->m_usNoOfCols - 1)) != 0);
		}
		// draw the seperator lines between the data readings if multiline
		int iSeperatorLinesToDraw = pThis->m_usNoOfRowsPerSetOfReadings - 1;
		LONG lLineXPos = tCell.top;
		while (iSeperatorLinesToDraw != 0) {
			MoveToEx(hdc, tInnerArea.left + ileftOverPixels + iCELL_WIDTH + 2, lLineXPos, NULL);
			LineTo(hdc, tInnerArea.right - 1, lLineXPos);
			// move the line position up to the next row of cells
			lLineXPos -= pThis->m_iInnerDataRowHeight;
			--iSeperatorLinesToDraw;
		}
		// move down on the next line for this set of readings
		tCell.setTop(pThis)->m_iInnerDataRowHeight;
	tCell.setBottom(pThis)->m_iInnerDataRo

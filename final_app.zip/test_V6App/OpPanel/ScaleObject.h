/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ScaleObject.h
/// @n Description: Scale Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  45  Stability Project 1.42.1.1 7/2/2011 5:01:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  44  Stability Project 1.42.1.0 7/1/2011 4:25:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  43  V6 Firmware 1.42 1/12/2006 10:20:53 PM  Mark Dennison 
//  Added variable for automatic scientific notation
//  42  V6 Firmware 1.41 11/22/2005 9:52:57 PM  David Fulmer (Ft
//  Washington) Fixed problem with keeping the link positions aligned for
//  multiple scale instances on multiple custom screens using the same
//  template
// $
//
// **************************************************************************
#ifndef _SCALEOBJECT_H
#define _SCALEOBJECT_H
#include <math.h> // for fabs, ceil, log10, ...
// Forward Class Declarations
class ScaleDrawingObject;
//**Class*********************************************************************
///
/// @brief Scale Object
/// 
/// This class is a simple standard drawn object for the scale object which
/// is derived from the CBaseObject class. Note that for a horizontal scale,
/// zero is always at the left end of the scale and span is always at the
/// right end of the scale. For a vertical scale, zero is always at the bottom
/// of the scale and span is always at the top of the scale. Note, too, that
/// the values of zero and span can be inverted (i.e., zero > span).
///
/// NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE!
/// NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE! NOTE!
///
/// Any CScaleObject member variable, including any member variable in any of
/// its base classes, updated by SetBounds or the Recalculate method within
/// it must be saved and restored in method SaveScaleObjectState and method
/// RestoreScaleObjectState. This is necessary so methods CalcLinkPositions
/// and CanSetLinkPositions can be treated as "const" methods (i.e., they do
/// not update the internal state of the scale object).
///
//****************************************************************************
class CScaleObject: public CBaseObject {
private:
	CDataItemRef *m_pDataItemRef;	///< Data item table reference (could have more than 1)
	T_SCALEOBJECT *m_pCMMscale;		///< Pointer to our CMM configuration
	BOOL m_bComputeIndents;			///< Compute indents or use precalculated indents for linking?
	BOOL m_bPrevHoriz;				///< Was scale orientation previously horizontal? (If we switch
									///< the orientation of the scale, then we definitely want to
									///< recompute the zero and span indents!)
									// Derived objects must draw themselves.
									// Called via the m_pOnDraw pointer to function.
	static void OnDraw(CScaleObject *pThis, HDC hdc, QRect *pClipRect);
private:
	// The object responsible for the actual drawing
	ScaleDrawingObject *m_pScaleDrawingObject;
	BOOL SaveScaleObjectState(BYTE *pbySaveBuffer, int nSaveBufferByteSize);
	void RestoreScaleObjectState();
	void Save(void *pbySrc, int nSrcByteSize);
	void Restore(void *pbyDst, int nDstByteSize);
	BOOL m_bSaveOk;
	BYTE *m_pbySaveBuffer;
	int m_nSaveBufferBytesRemaining;
public:
	// Constructor
	CScaleObject(CWidget *pWidget);
	// Destructor
	~CScaleObject();
	// overidden functions that must be supplied
	virtual void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);///< set bounds of the object relative to the CScreen's top left corner.
	///< init first time
	virtual void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);
	///< config changes	
	virtual void ConfigChange();
	virtual void Destroy();
	///< can the Object be linked and if so, which way?
	virtual LinkOrientation GetLinkOrient();
	///< calculate the link positions from the object limits
	virtual BOOL CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2);
	///< baseobject version does not impose any restrictions
	virtual BOOL CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2);
};
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: BarObject.h
/// @n Description: Derived Object BarObject
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  37  Stability Project 1.34.1.1 7/2/2011 4:55:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  36  Stability Project 1.34.1.0 7/1/2011 4:25:53 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  35  V6 Firmware 1.34 11/22/2005 9:53:11 PM  David Fulmer (Ft
//  Washington) Fixed problem with keeping the link positions aligned for
//  multiple scale instances on multiple custom screens using the same
//  template
//  34  V6 Firmware 1.33 10/27/2005 1:23:36 AM  David Fulmer (Ft
//  Washington) Fixed CR1263 (log scales don't work)
//  33  V6 Firmware 1.32 10/13/2005 9:44:35 PM  Jason Parker  
//  Tidied bar object. now lines up with scale when linked
//  32  V6 Firmware 1.31 6/13/2005 9:00:11 PM  Usha Kaloor (Ft
//  Washington) Defined one set of constants for Horizontal and Vertical
//  Orientation for all the objects
//  31  V6 Firmware 1.30 6/8/2005 7:46:16 PM Usha Kaloor (Ft
//  Washington) created Error Indicator Flash colour arrays
//  30  V6 Firmware 1.29 6/8/2005 2:47:47 AM Usha Kaloor (Ft
//  Washington) Added more BarObject properties
//  29  V6 Firmware 1.28 6/8/2005 12:10:53 AM  Usha Kaloor (Ft
//  Washington) moved some enum definitions to LayoutItem.h from
//  BarObject.h. Uses all ULONG colours now
//  28  V6 Firmware 1.27 5/31/2005 7:14:31 PM  Roger Dawson  
//  Screen designer configuration changes. Removed methods that refer to
//  the LAYOUTITEM_PROP structures which have now been removed.
//  27  V6 Firmware 1.26 5/31/2005 6:53:51 PM  Usha Kaloor (Ft
//  Washington) Coding standards
//  26  V6 Firmware 1.25 5/18/2005 12:51:06 AM  Usha Kaloor (Ft
//  Washington) Uses drawn asterisk on EUDC characters for Upscale and
//  Downscale Burnout Indicators
//  25  V6 Firmware 1.24 4/21/2005 7:19:15 PM  Usha Kaloor (Ft
//  Washington) Code cleanup
//  24  V6 Firmware 1.23 4/21/2005 1:52:40 AM  Usha Kaloor (Ft
//  Washington) gets ScaleInfo from T_PSCALEINFO
//  struct(log/Linear/StartDecade/NumDecade etc.)
//  23  V6 Firmware 1.22 4/16/2005 3:11:52 AM  Usha Kaloor (Ft
//  Washington) code cleanup
//  22  V6 Firmware 1.21 4/15/2005 3:25:27 AM  Usha Kaloor (Ft
//  Washington) Added EUDC characters for Error Indicators and Alarm
//  Markers(not completed)
//  21  V6 Firmware 1.20 4/12/2005 2:11:58 AM  Usha Kaloor (Ft
//  Washington) GetLinkOrient function added
//  20  V6 Firmware 1.19 4/8/2005 7:58:38 PM Usha Kaloor (Ft
//  Washington) Log Scale support for all supported Bar Types/Styles.
//  Added Test properties:Log Scale(Linear/Log), ZoomMode(No Zoom/In
//  Zoom), Zoom Zero and Zoom Span
//  19  V6 Firmware 1.18 4/8/2005 1:24:25 AM Usha Kaloor (Ft
//  Washington) some cleanup
//  18  V6 Firmware 1.17 4/7/2005 9:46:13 PM Usha Kaloor (Ft
//  Washington) Removed, modified some strings, changed some colour data
//  types from USHORT to ULONG, Added Solid Above and Below colour
//  functionality for Based Bar Type
//  17  V6 Firmware 1.16 4/7/2005 2:58:40 AM Usha Kaloor (Ft
//  Washington) Flashing, Log Scale feature added
//  16  V6 Firmware 1.15 4/6/2005 9:21:21 PM Usha Kaloor (Ft
//  Washington) Changed SetPixelV to SetPixel as it is not supported in
//  EVC
//  15  V6 Firmware 1.14 4/6/2005 2:26:33 AM Usha Kaloor (Ft
//  Washington) Fade BarType functionality fixed. MaxMin marker set
//  properly
//  14  V6 Firmware 1.13 4/5/2005 3:18:49 AM Usha Kaloor (Ft
//  Washington) Created references fro max and min values
//  13  V6 Firmware 1.12 4/2/2005 1:34:20 AM Usha Kaloor (Ft
//  Washington) Added retrieval of max and min values, display of max and
//  min markers
//  12  V6 Firmware 1.11 4/1/2005 4:07:03 AM Usha Kaloor (Ft
//  Washington) MaxMin markers added. Currentvalue matches Scale Readings
//  following Zero and Span settings
//  11  V6 Firmware 1.10 3/28/2005 10:52:09 PM  Usha Kaloor (Ft
//  Washington) Range,Burnout,Invalid Reading indicators implemented.
//  10  V6 Firmware 1.9 3/19/2005 3:35:13 AM  Usha Kaloor (Ft
//  Washington) Bar Styles Solid,Fade, Dynamic work with Types up, Down,
//  Based, None. Style traffic work with Up,Down,None.
//  9 V6 Firmware 1.8 3/16/2005 8:07:26 PM  Usha Kaloor (Ft
//  Washington) Code cleanup
//  8 V6 Firmware 1.7 3/16/2005 4:11:37 AM  Usha Kaloor (Ft
//  Washington) Traffic light, Dynamic Colouring implemented. LevelCap
//  movement handled for all Bar types.
//  7 V6 Firmware 1.6 3/12/2005 3:31:46 AM  Usha Kaloor (Ft
//  Washington) BarStyle Fade and Dynamic Colouring implemented, All
//  BarTypes implemented
//  6 V6 Firmware 1.5 3/8/2005 2:53:38 AM Usha Kaloor (Ft
//  Washington) Some features are implemented. Checked in for feedback.
//  5 V6 Firmware 1.4 2/17/2005 3:33:47 AM  David Fulmer (Ft
//  Washington) Updated as part of getting/setting property values in the
//  Properties window using the new get/set scheme (CurrentVal in
//  T_LYTITEM_PROP is now overloaded to be either a T_XXX field address
//  or a property id)
//  4 V6 Firmware 1.3 2/9/2005 3:58:37 AM Usha Kaloor (Ft
//  Washington) Made changes related to Item Properties after the class
//  hierarchy has been changed
//  3 V6 Firmware 1.2 1/18/2005 3:50:14 AM  Usha Kaloor (Ft
//  Washington) added T_ to OBJECT_PROP structure, followed some coding
//  standards
//  2 V6 Firmware 1.1 1/13/2005 5:56:45 PM  Jason Parker  
//  removed resource.h include (not required)
//  1 V6 Firmware 1.0 1/13/2005 1:58:01 AM  Usha Kaloor (Ft
//  Washington) 
// $
//
// **************************************************************************
#ifndef _BAROBJECT_H
#define _BAROBJECT_H
#include "BaseObject.h"
#include "Defines.h"
const int MAX_DIT_REF_BAROBJ = 3; //2 dataitem references, for CurrVal, Max and Min values 
const unsigned short DEF_LEVELCAP_COLOUR = 65534; ///<this value is matched to the default value of the CMM db
const unsigned long DEF_ABOVE_COLOUR = 57372; ///<this value is matched to the default value of the CMM db
const unsigned long DEF_BELOW_COLOUR = 4225; ///<this value is matched to the default value of the CMM db
const unsigned long DEF_FLSHCLR2 = 65535; ///<this value is matched to the default value of the CMM db
const int MAX_ERR_INDICATOR_COLS = 5; ///<Error Indicator Flash colours and InterFlashColours
static COLORREF G_abovecolour = RGB(255, 255, 255);
static COLORREF G_belowcolour = RGB(0, 0, 0);
//*******************************************************
// enum 
///
/// 3 dataItem Table references for CurrVal, Max and Min Val
///
//*******************************************************
enum {
	CURRENT_VAL, MAX_VAL, MIN_VAL
};
//*******************************************************
// enum 
///
/// levelCap position field for the BarObject
/// where does the level cap go? towards left/top of ValueRect or right/bottom?
/// This depends upon the scale reversed(span<zero) or not
//*******************************************************
enum {
	rectleftTop, rectrightBottom
};
//*******************************************************
// enum 
///
/// Direction of the Error Indicators on the bar
/// Up/Forward for OverRange/Upscale Burnout indication based on 
/// Vertical or Horizontal bar
/// Down/Back for UnderRAnge/Downscale Burnout indication based on 
/// Vertical or Horizontal bar
//*******************************************************
enum {
	UpForward, DownBack
};
//**Class*********************************************************************
///
/// @brief ExampleBar Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used as a 'template' for all other derived Objects.
///
//****************************************************************************
class CBarObject: public CBaseObject {
private:
	// this stuff has to be configured from screen designer
	// need some kind of table with:
	// values, 
	// description (from string table)
	// if uses settings from the DataItem or overridden by screen designer
	BOOL m_IsOverRange;
	BOOL m_IsUnderRange;
	BOOL m_IsUpscBurnout;
	BOOL m_IsDownscBurnout;
	BOOL m_IsInvalidReading;
	BOOL m_bLogScale;
	BOOL m_bLogScaleScrDes;
	BOOL m_bSetScale;
	float m_fZoomZero;
	float m_fZoomSpan;
	USHORT m_ErrIndicator;
	BOOL m_bSetErrors;
	BOOL m_bInZoom;
	//forecolour and backColour are inherited from base class.
//item 13, rotatingbars, what is this??? What are the conditions for displaying 2 or more bars in place?
	BOOL m_DrawInFlashState;
	COLORREF *m_pAboveColour;	//Above colour for Solid, Based Bar Type(when the current val>BasePoint)
	COLORREF *m_pBelowColour;	//Below colour for Solid, Based Bar Type(when the current val<BasePoint)
	COLORREF *m_pErrIndicatorFlashCols[MAX_ERR_INDICATOR_COLS];
	COLORREF *m_pErrIndicatorInterFlashCols[MAX_ERR_INDICATOR_COLS];
	COLORREF m_DiErrIndicatorFlashCols[MAX_ERR_INDICATOR_COLS];
	COLORREF m_DiErrIndicatorInterFlashCols[MAX_ERR_INDICATOR_COLS];
	// derived objects must draw themselves 
	// called via the pOnDraw pointer to function.
	float m_TopLimit;		///< Top Bar value set from CMM or Data Item
	float m_BottomLimit;	///< Bottom Bar value set from CMM or Data Item
	float m_CurrentValue;	///< Current value of channel (pen) to be displayed
	float m_MaxValue;		///<Max indefinate time period user reset
	float m_MinValue;		///<Min indefinate time period user reset
	int m_Shape;
	CDataItemRef *m_pDataItemRef[MAX_DIT_REF_BAROBJ];///< data item table reference, for currentValue, MaxValue and MinValue
	T_BAROBJECT *m_pCMMBar;	///< pointer to our CMM configuration
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CBarObject *pThis, HDC hdc, QRect *pClipRect);
	void SetBarType(HDC hdc);
	void SetLevelCap(HDC hdc, QRect levelRect, int rectSide = rectrightBottom);
	void FillBar(HDC hdc, QRect valueRect, QRect backRect);
	void GetStartEndClr();
	void SetErrIndicators(HDC hdc, USHORT uErrType, wchar_t IndicatorCharVert, wchar_t IndicatorCharHoriz);
	void SetMaxMinMarkers(HDC hdc);
	void FillBarFade(HDC hdc, QRect valueRect);
	void GetClrScheme();
	void GradFill(int stLoop, int EndLoop, int LoopIncr, int StartPoint);
	void DrawIndicators(CDC *pDC, QRect Trirect);
	void SetErrorRect(QRect &Trirect, SIZE size, int Direction);
	void SetNumericArea(QRect &textRect);
	void Zoom(float fZero, float fSpan);
	static BOOL IsScaleReversed(CBarObject *pThis) {
		return (pThis->m_BottomLimit > pThis->m_TopLimit);
	}
	void LimitBounds(QRect bounds, QRect &currRect);
	int m_drawvalue;
	int m_drawvalSpan;
	int m_drawvalZero;
	BOOL m_ScaleReversed;
	COLORREF m_crStart;
	COLORREF m_crEnd;
	int m_Segments;
	int m_IncR;
	int m_IncG;
	int m_IncB;
	int m_StartR;
	int m_StartG;
	int m_StartB;
	int m_Incr;
	CDC *m_dcMemory;
	CFFConversionInfo m_conv;
public:
	// optional overrides
	LinkOrientation GetLinkOrient();
	virtual void SetBounds(QRect *bounds, int *pPos1 = NULL, int *pPos2 = NULL);///< set bounds of the object relative to the CScreen's top left corner.
	//virtual void InitItemProp();
	CBarObject(CWidget *pWidget);
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
};
#endif

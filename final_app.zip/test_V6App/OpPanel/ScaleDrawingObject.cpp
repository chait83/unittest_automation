/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ScaleDrawingObject.cpp
/// @n Description: Implementation of the Scale Drawing Object class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]$
//
//  30-Oct-14 Rajanbabu M  Fixed PAR:1-3KZWBIH-Load custom screen is not working in Multi and DRG2 Recorders
// **************************************************************************
#include "V6globals.h"
#include "FFConversionInfo.h"
#include "ScaleDrawingObject.h"
#include <math.h>
#include <atltypes.h>
#include "MathUtils.h"
#include "OpPanelIncludes.h"
//****************************************************************************
/// ChartObject Constructor
/// 
//****************************************************************************
ScaleDrawingObject::ScaleDrawingObject(BOOL &updateRequired, BOOL &updateValue, BOOL &updateFlash, BOOL &flashState,
		const BOOL flashing, COpPanel *pOpPanel) : m_flashing(flashing) {
	m_pUpdateRequired = &updateRequired;
	m_pUpdateValue = &updateValue;
	m_pUpdateFlash = &updateFlash;
	m_pFlashState = &flashState;
	m_bComputeIndents = FALSE;
	m_pScaleObjectCfg = NULL;
	m_nLimitLabelHeight = 0;
	m_nMajorLabelHeight = 0;
	m_bLabelMajors = FALSE;
	m_bLabelLimits = FALSE;
	m_nMajorGradLength = 0;
	m_nMinorGradLength = 0;
	m_bDrawMajorGrads = FALSE;
	m_bDrawMinorGrads = FALSE;
	m_nMajorLabelTopleft = 0;
	m_nLayout = SCALE_HTUN;
	m_fMajorSpacing = 20.0;
	m_fMinorSpacing = 10.0;
	m_zero = m_zoomZero = 0.0;
	m_span = m_zoomSpan = 100.0;
	// default these to floating point
	wcscpy_s(m_LimitasprintfStr, sizeof(m_LimitasprintfStr) / sizeof(WCHAR), L"%%.2f");
	wcscpy_s(m_MajorasprintfStr, sizeof(m_LimitasprintfStr) / sizeof(WCHAR), L"%%.2f");
	m_bLogScale = false;
	m_bScientificForced = false;
	m_bInZoom = false;
	m_pOpPanel = pOpPanel;
}
//****************************************************************************
/// ChartObject Destructor
/// 
//****************************************************************************
ScaleDrawingObject::~ScaleDrawingObject(void) {
}
const int ScaleDrawingObject::left(const T_TV_RECT &bounds) const {
#ifdef DOCVIEW
	return bounds.left+m_pOpPanel->m_RecScreenOffset.x;
#else
	return bounds.left;
#endif
}
const int ScaleDrawingObject::top(const T_TV_RECT &bounds) const {
#ifdef DOCVIEW
	return bounds.top+m_pOpPanel->m_RecScreenOffset.y;
#else
	return bounds.top;
#endif
}
const int ScaleDrawingObject::right(const T_TV_RECT &bounds) const {
#ifdef DOCVIEW
	return bounds.right+m_pOpPanel->m_RecScreenOffset.x;
#else
	return bounds.right;
#endif
}
const int ScaleDrawingObject::bottom(const T_TV_RECT &bounds) const {
#ifdef DOCVIEW
	return bounds.bottom+m_pOpPanel->m_RecScreenOffset.y;
#else
	return bounds.bottom;
#endif
}
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void ScaleDrawingObject::OnDraw(HDC hdc, QRect *pClipRect) {
	//if(pThis->isObjectOverlapped()) 
	//	return;
	BOOL bHoriz = m_pScaleObjectCfg->Orientation == OBJECT_HORIZONTAL;
	CDC *pDC = CDC::FromHandle(hdc);
	// if Update Required make any updates due to data item changes/flashing then do a repaint
	if (*m_pUpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object.
		if (*m_pUpdateValue) {
			//pThis->m_CurrentValue=pThis->m_pDataItemRef->m_pDataItem->GetFPValue();
			*m_pUpdateValue = FALSE;
		}
		// also handle and flashing updates here
		if (*m_pUpdateFlash) {
			*m_pFlashState = !*m_pFlashState; // toggle the flash state.			
			*m_pUpdateFlash = FALSE;
		}
		*m_pUpdateRequired = FALSE;
	}
	BOOL DrawInFlashState = FALSE;
	if (m_flashing) // if we are flashing set our drawInFlashState.
	{
		DrawInFlashState = *m_pFlashState;
	}
	// Draw border if required.
	if (m_pScaleObjectCfg->Base.Border.BorderUsed && (pClipRect || m_pScaleObjectCfg->Base.IsBuffered)) {
		DrawBorder(hdc, m_bounds, &m_pScaleObjectCfg->Base.Border);
	}
	// Update the current clipping region. This handling will prevent the
	// grads (or anything else) from being drawn outside the scale object.
	//SetClipRect(hdc, m_pClientRect);
	if (m_pScaleObjectCfg->Base.IsTransparent)
		pDC->SetBkMode(TRANSPARENT);
	else {
		// Create background brush and fill in client rect.
		QBrush BackBrush;
		BackBrush.CreateSolidBrush(*m_pBackColour);
		pDC->FillRect(m_pClientRect, &BackBrush);
	}
	// Need to adjust the zero or span grad else it would
	// be one off from the baseline and it would disappear
	// completely when a bar linked to the scale would be
	// moved to the edge of the widget. Trying to do this
	// adjustment elsewhere proved to be very tricky.
	// There is a corresponding restore at end of method!
	//if(bHoriz)
	//{
	//	pThis->m_rcSpanGrad.left--;
	//	pThis->m_rcSpanGrad.right--;
	//}
	//else
	//{
	//	pThis->m_rcZeroGrad.top--;
	//	pThis->m_rcZeroGrad.bottom--;
	//}
	if (bHoriz)
		m_rcBaseline.right++;
	else
		m_rcBaseline.bottom++;
	// Draw the grads - set up the pen.
	CPen GradsPen;
	GradsPen.CreatePen(PS_SOLID, 1, *m_pGradsColour);
	CPen *pOldPen = pDC->SelectObject(&GradsPen);
	BOOL bDrawLimitGrads; // draw limit grads if they don't cross over
	if (bHoriz)
		bDrawLimitGrads = m_rcZeroGrad.right < m_rcSpanGrad.left;
	else
		bDrawLimitGrads = m_rcSpanGrad.bottom < m_rcZeroGrad.top;
	if (bDrawLimitGrads) {
		// Draw zero grad.
		pDC->MoveTo(m_rcZeroGrad.Topleft());
		pDC->LineTo(m_rcZeroGrad.Bottomright());
		// Draw span grad.
		pDC->MoveTo(m_rcSpanGrad.Topleft());
		pDC->LineTo(m_rcSpanGrad.Bottomright());
	}
	// Draw the major grads.
	if (m_pScaleObjectCfg->MajorGrads && m_bDrawMajorGrads) {
		QRect rcGrad;
		float fGrad = GetFirstMajorGrad(); // first major grad value in EU (linear) or power of 10 (log)
		float fMajorDivs = GetMajorDivs(); // offset value in EU (linear) or 1 (power of 10) (log) between each major grad
		while (MakeGrad( TRUE /*check*/, rcGrad, fGrad,
				m_nMajorGradLength /*nMaxDistanceFromBaseline*//*, pThis->m_pCMMscale->MinorGrads&&!pThis->m_pCMMscale->FullWidth ? pThis->m_pCMMscale->MinorLength : 0 /*nMinDistanceFromBaseline*/)) {
			pDC->MoveTo(rcGrad.Topleft());
			pDC->LineTo(rcGrad.Bottomright());
			fGrad += fMajorDivs;
		}
	}
	// Draw the minor grads. Note that the minor grads are also drawn at the major grad locations.
	// The major grads might not be shown, but we want to show the minor grads at their locations.
	if (m_pScaleObjectCfg->MinorGrads && m_bDrawMinorGrads)
		if (m_bLogScale) {
			QRect rcGrad;
			int nDecade, nDiv; // nDiv goes from 2 to 9 for the minor divisions within a decade
			float fGrad = GetFirstMinorGrad(nDecade, nDiv); // first minor grad value in power of 10
			while (MakeGrad( TRUE /*check*/, rcGrad, fGrad, m_nMinorGradLength /*nMaxDistanceFromBaseline*/)) {
				pDC->MoveTo(rcGrad.Topleft());
				pDC->LineTo(rcGrad.Bottomright());
				if (nDiv == 9) {
					++nDecade;
					nDiv = 1;
				} else
					++nDiv;
				fGrad = nDecade + (float) log10((double) nDiv);
			}
		} else // linear scale
		{
			QRect rcGrad;
			int nDecade, nDiv; // not used for linear scale
			float fGrad = ScaleDrawingObject::GetFirstMinorGrad(nDecade, nDiv); // first minor grad value in EU
			float fMinorDivs = GetMinorDivs(); // offset value in EU between each minor grad
			while (MakeGrad( TRUE /*check*/, rcGrad, fGrad, m_nMinorGradLength /*nMaxDistanceFromBaseline*/)) {
				pDC->MoveTo(rcGrad.Topleft());
				pDC->LineTo(rcGrad.Bottomright());
				fGrad += fMinorDivs;
			}
		}
	pDC->SelectObject(pOldPen);
	GradsPen.DeleteObject();
	// Draw the baseline.
	if (m_pScaleObjectCfg->Baseline) {
		CPen BaselinePen;
		BaselinePen.CreatePen(PS_SOLID, 1, *m_pBaselineColour);
		CPen *pOldPen = pDC->SelectObject(&BaselinePen);
		pDC->MoveTo(m_rcBaseline.Topleft());
		pDC->LineTo(m_rcBaseline.Bottomright());
		pDC->SelectObject(pOldPen);
		BaselinePen.DeleteObject();
	}
	// Set up for drawing the labels.
	int nOldBkMode = pDC->SetBkMode(TRANSPARENT);
	COLORREF crOldForeColour = pDC->SetTextColor(*m_pForeColour);
	// Draw the zero and span limit labels.
	if (m_bLabelLimits) {
		CFontCache *pfc = CFontCache::GetHandle();
		int yoffset = 0;
		QFont hfont = pfc->GetNumericFont(m_nLimitLabelHeight, &yoffset);
		QFont hOldfont = (QFont) pDC->SelectObject(hfont);
		QString sZeroLabel;
		sZeroLabel = QString::asprintf(m_LimitasprintfStr, GetZero());
		//MarkD: remove extra exponent character if scientific notation was forced, 
		// unless in log scale in which case the labelling is different
		if ((m_bScientificForced || m_numberasprintf.Scientific) && (!m_bLogScale)) {
			sZeroLabel.remove((sZeroLabel.size() - 3), 1);	// delete the third from last char
		}
		QRect rc(m_rcZeroLabel);
		rc.OffsetRect(0, -yoffset);
		pDC->DrawText(sZeroLabel, rc, DT_NOCLIP);
		QString sSpanLabel;
		sSpanLabel = QString::asprintf(m_LimitasprintfStr, GetSpan());
		//MarkD: remove extra exponent character if scientific notation was forced
		// unless in log scale in which case the labelling is different
		if ((m_bScientificForced || m_numberasprintf.Scientific) && (!m_bLogScale))
			sSpanLabel.remove((sSpanLabel.size() - 3), 1);	// delete the third from last char
		rc.CopyRect(&m_rcSpanLabel);
		rc.OffsetRect(0, -yoffset);
		pDC->DrawText(sSpanLabel, rc, DT_NOCLIP);
		pDC->SelectObject(hOldfont);
		pfc->ReleaseFont(hfont);
	}
	// Draw the major labels.
	if (m_bDrawMajorGrads && m_bLabelMajors) {
		CFontCache *pfc = CFontCache::GetHandle();
		int yoffset = 0;
		QFont hfont = pfc->GetNumericFont(m_nMajorLabelHeight, &yoffset);
		QFont hOldfont = (QFont) pDC->SelectObject(hfont);
		QRect rcGrad, rcLabel;
		float fGrad = GetFirstMajorGrad(); // first major grad value in EU (linear) or power of 10 (log)
		float fMajorDivs = GetMajorDivs(); // offset value in EU (linear) or 1 (power of 10) (log) between each major grad
		QString sLabel;
		while (MakeGrad(TRUE /*check*/, rcGrad, fGrad, m_nMajorGradLength /*nMaxDistanceFromBaseline*/)) {
			sLabel = QString::asprintf(m_MajorasprintfStr, fGrad);
			//MarkD: remove extra exponent character if scientific notation was forced
			// unless in log scale in which case the labelling is different
			if ((m_bScientificForced || m_numberasprintf.Scientific) && (!m_bLogScale))
				sLabel.remove((sLabel.size() - 3), 1);	// delete the third from last char
			// For a vertical scale, offset the labels down one pixel so that for negative values,
			// the minus sign won't line up with the graduations and be easy for the user to miss.
			MakeLabel(rcLabel, sLabel, m_nMajorLabelHeight, bHoriz ? TOP_CENTER_PT : LEFT_CENTER_PT,
					bHoriz ?
							QPoint(rcGrad.left, m_nMajorLabelTopleft) :
							QPoint(m_nMajorLabelTopleft, rcGrad.top + (!m_bLogScale && fGrad < 0.0F)));
			QRect rc(rcLabel);
			rc.OffsetRect(0, -yoffset);
			pDC->DrawText(sLabel, rc, DT_NOCLIP);
			fGrad += fMajorDivs;
		}
		pDC->SelectObject(hOldfont);
		pfc->ReleaseFont(hfont);
	}
	// Restore the zero or span grad.
	//if(bHoriz)
	//{
	//	pThis->m_rcSpanGrad.left++;
	//	pThis->m_rcSpanGrad.right++;
	//}
	//else
	//{
	//	pThis->m_rcZeroGrad.top++;
	//	pThis->m_rcZeroGrad.bottom++;
	//}
	if (bHoriz)
		m_rcBaseline.right--;
	else
		m_rcBaseline.bottom--;
	// Restore GDI objects after drawing labels.
	pDC->SetTextColor(crOldForeColour);
	pDC->SetBkMode(nOldBkMode);
}
// Make a grad from the baseline.
// bCheck set to TRUE means method will check if grad is strictly between zero and span.
//		method will return FALSE if grad is not strictly inside zero and span.
// rcGrad will contain the client coordinates of the grad
// fGrad specifies in eng units for a linear scale or in powers of 10 for a logarithmic scale
//		where between zero and span to make the grad
// nMaxDistanceFromBaseline specifies in pixels the farthest point along the grad to the baseline
// nMinDistanceFromBaseline specifies in pixels the closest point along the grad to the baseline
//		0 means that the grad is anchored to the baseline
BOOL ScaleDrawingObject::MakeGrad(BOOL bCheck, QRect &rcGrad, float fGrad, int nMaxDistanceFromBaseline,
		int nMinDistanceFromBaseline/*=0*/) {
	if (bCheck) // check grad is strictly within zero and span
	{
		float upper = GetVisibleUpperEnd();
		if (upper >= 0.0F) {
			upper *= 0.99999F;
		} else {
			upper *= 1.00001F;
		}
		//float upper = GetVisibleUpperEnd() * 0.99999;		//MarkD: negligable percentage change, but ensures float compare works 
		//if(fGrad<=GetVisibleLowerEnd() || fGrad>=GetVisibleUpperEnd())
		//MarkD: comparing eg 3.2 with 3.2 doesn't match. so span label clashes with last major label
		// span level is adjusted slightly to avoid this
		// limitation on number of major grads means this adjustment doesn't matter
		if (fGrad <= GetVisibleLowerEnd() || fGrad >= upper)
			return FALSE;
	}
	int nPixel = (int) (m_convInfo.CalcSourceToDest(fGrad) + 0.5); // convert source to pixel position
	// Adjust parameters nMaxDistanceFromBaseline and nMinDistanceFromBaseline as follows:
	//
	// a negative number for a horizontal baseline positions the grad above the baseline
	// a positive number for a horizontal baseline positions the grad below the baseline
	// a negative number for a vertical baseline positions the grad left of the baseline
	// a positive number for a vertical baseline positions the grad right of the baseline
	if (m_pScaleObjectCfg->Orientation == OBJECT_HORIZONTAL) {
		if (m_pScaleObjectCfg->GradsDirection == GRADS_UP) {
			nMaxDistanceFromBaseline = -nMaxDistanceFromBaseline;
			nMinDistanceFromBaseline = -nMinDistanceFromBaseline;
		}
		rcGrad.setleft(nPixel);
		rcGrad.setTop(m_rcBaseline).top + nMaxDistanceFromBaseline;
		rcGrad.setright(rcGrad).left;
		rcGrad.setBottom(m_rcBaseline).top + nMinDistanceFromBaseline;
	} else {
		if (m_pScaleObjectCfg->GradsDirection == GRADS_LEFT) {
			nMaxDistanceFromBaseline = -nMaxDistanceFromBaseline;
			nMinDistanceFromBaseline = -nMinDistanceFromBaseline;
		}
		rcGrad.setleft(m_rcBaseline).left + nMinDistanceFromBaseline;
		rcGrad.setTop(nPixel);
		rcGrad.setright(m_rcBaseline).left + nMaxDistanceFromBaseline;
		rcGrad.setBottom(rcGrad).top;
	}
	rcGrad.NormalizeRect();
	return TRUE;
}
// Get the first minor grad starting from the numerically lower end of the scale
// that will be visible in the scale. Consider whether the scale is in zoom mode.
float ScaleDrawingObject::GetFirstMinorGrad(int &nDecade, int &nDiv) {
	// Determine numerically lower end and zoomed lower end of the scale.
	float fLowerEnd = IsScaleReversed() ? m_span : m_zero;
	float fZoomedLowerEnd = IsScaleReversed() ? m_zoomSpan : m_zoomZero;
	if (m_bLogScale) {
		// Get the first logarithm (log10(2) through log10(9)) that when added
		// to the decade (1, 2, 3, ...) of the lower end or the zoomed lower end
		// depending on the zoom mode is greater than that lower end. Return this
		// division (2 through 9) so that we can continue drawing minor grads from it.
		float fEnd = m_bInZoom ? fZoomedLowerEnd : fLowerEnd;
		nDecade = (int) fEnd;
		nDiv = 2;
		float fGrad;
		while ((fGrad = nDecade + (float) log10((double) nDiv)) <= fEnd)
			++nDiv;
		if (nDiv == 10) {
			// We're into the next decade. Example is starting from lower
			// end of 95. log10(95)=1.9777. Decade is 1 and log(9)=.9542.
			++nDecade;
			nDiv = 1; // will be incremented to 2 by caller before it is used
			fGrad = (float) nDecade;
		}
		return fGrad;
	} else if (m_bInZoom) // linear scale
	{
		// Determine how many minor graduations "n" we need from the numerically
		// lower end of the scale until we pass the zoomed lower end of the scale.
		// Solve for "n" in equation: fLowerEnd+(GetMinorDivs()*n)>fZoomedLowerEnd
		int n = (int) ceil((fZoomedLowerEnd - fLowerEnd) / GetMinorDivs());
		if (fLowerEnd + (GetMinorDivs() * n) == fZoomedLowerEnd)
			n++; // first minor grad at zoomed lower end - we want to go past it
		return fLowerEnd + (GetMinorDivs() * n);
	} else
		return fLowerEnd + GetMinorDivs();
}
// Make a label rect, aligning the specified point in the rect to the specified point in client coordinates.
void ScaleDrawingObject::MakeLabel(QRect &rcLabel, const QString &sLabel, int nLabelHeight, ERectPt eRectPt,
		QPoint pt) {
	CFontCache *pfc = CFontCache::GetHandle();
	HDC hdc = pfc->m_fontHdc;
	int yoffset = 0;
	QFont hfont = pfc->GetNumericFont(nLabelHeight, &yoffset);
	QFont hOldfont = (QFont) SelectObject(hdc, hfont);
	QSize size;
	GetTextExtentPoint32(hdc, sLabel, sLabel.size(), &size);
	SelectObject(hdc, hOldfont);
	pfc->ReleaseFont(hfont);
	rcLabel.SetRect(QPoint(0, 0), QPoint(size.cx, nLabelHeight));
	switch (eRectPt) {
	case TOP_LEFT_PT:
		rcLabel.OffsetRect(pt);
		break;
	case TOP_CENTER_PT:
		rcLabel.setleft(pt).x - rcLabel.right / 2;
		rcLabel.setTop(pt).y;
		rcLabel.setRight(rcLabel).left;
		rcLabel.setBottom(pt).y;
		break;
	case TOP_RIGHT_PT:
		rcLabel.setleft(pt).x - rcLabel.right;
		rcLabel.setTop(pt).y;
		rcLabel.setright(pt).x;
		rcLabel.setBottom(pt).y;
		break;
	case BOTTOM_LEFT_PT:
		rcLabel.setleft(pt).x;
		rcLabel.setTop(pt).y - rcLabel.bottom;
		rcLabel.setRight(pt).x;
		rcLabel.setBottom(pt).y;
		break;
	case BOTTOM_RIGHT_PT:
		rcLabel.setleft(pt).x - rcLabel.right;
		rcLabel.setTop(pt).y - rcLabel.bottom;
		rcLabel.setright(pt).x;
		rcLabel.setBottom(pt).y;
		break;
	case LEFT_CENTER_PT:
		rcLabel.setleft(pt).x;
		rcLabel.setTop(pt).y - rcLabel.bottom / 2;
		rcLabel.setRight(pt).x;
		rcLabel.setBottom(rcLabel).top;
		break;
	default:
		assert(0);
		break;
	}
}
// Get the first major grad starting from the numerically lower end of the scale
// that will be visible in the scale. Consider whether the scale is in zoom mode.
float ScaleDrawingObject::GetFirstMajorGrad() {
	// Determine numerically lower end and zoomed lower end of the scale.
	float fLowerEnd = IsScaleReversed() ? m_span : m_zero;
	float fZoomedLowerEnd = IsScaleReversed() ? m_zoomSpan : m_zoomZero;
	if (m_bLogScale)
		return (float) (int) ((m_bInZoom ? fZoomedLowerEnd : fLowerEnd) + 1); // get next decade
	else if (m_bInZoom) // linear scale
	{
		// Determine how many major graduations "n" we need from the numerically
		// lower end of the scale until we pass the zoomed lower end of the scale.
		// Solve for "n" in equation: fLowerEnd+(GetMajorDivs()*n)>fZoomedLowerEnd
		int n = (int) ceil((fZoomedLowerEnd - fLowerEnd) / GetMajorDivs());
		if (fLowerEnd + (GetMajorDivs() * n) == fZoomedLowerEnd)
			n++; // first major grad at zoomed lower end - we want to go past it
		return fLowerEnd + (GetMajorDivs() * n);
	} else
		return fLowerEnd + GetMajorDivs();
}
void ScaleDrawingObject::MakeLimitLabels() {
	QString sZeroLabel;
	sZeroLabel = QString::asprintf(m_LimitasprintfStr, GetZero());
	QString sSpanLabel;
	sSpanLabel = QString::asprintf(m_LimitasprintfStr, GetSpan());
	if (m_pScaleObjectCfg->Orientation == OBJECT_HORIZONTAL) {
		MakeLabel(m_rcZeroLabel, sZeroLabel, m_nLimitLabelHeight, TOP_LEFT_PT,
				QPoint(m_pClientRect->left, m_nMajorLabelTopleft));
		MakeLabel(m_rcSpanLabel, sSpanLabel, m_nLimitLabelHeight, TOP_RIGHT_PT,
				QPoint(m_pClientRect->right, m_nMajorLabelTopleft));
	} else {
		// For a vertical scale, offset the labels slightly inward so that for negative values,
		// the minus sign won't line up with the graduations and be easy for the user to miss.
		MakeLabel(m_rcZeroLabel, sZeroLabel, m_nLimitLabelHeight, LEFT_CENTER_PT,
				QPoint(m_nMajorLabelTopleft, m_rcZeroGrad.bottom - (!m_bLogScale && GetZero() < 0.0F)));
		MakeLabel(m_rcSpanLabel, sSpanLabel, m_nLimitLabelHeight, LEFT_CENTER_PT,
				QPoint(m_nMajorLabelTopleft, m_rcSpanGrad.top + (!m_bLogScale && GetSpan() < 0.0F)));
		// Check if we have to move the zero label up to be within client rect.
		if (m_rcZeroLabel.bottom > m_pClientRect->bottom)
			m_rcZeroLabel.OffsetRect(0, m_pClientRect->bottom - m_rcZeroLabel.bottom);
		// Check if we have to move the span label down to be within client rect.
		if (m_rcSpanLabel.top < m_pClientRect->top)
			m_rcSpanLabel.OffsetRect(0, m_pClientRect->top - m_rcSpanLabel.top);
	}
}
BOOL ScaleDrawingObject::IsLabelOverlap(int &nWorstOverlap) {
	BOOL bHoriz = m_pScaleObjectCfg->Orientation == OBJECT_HORIZONTAL;
	// Loop over the labels and keep track of the worst overlap between labels.
	// An overlap of 0 means adjacent labels are right next to each other with
	// no space in between. An overlap of a positive number means there's that
	// many pixels between the adjacent labels. An overlap of a negative number
	// means one label encroaches on another by that many pixels.
	nWorstOverlap = INT_MAX; // overlap in pixels of labels which overlap the most
	// Consider the following three cases of labeling options:
	//
	// 1) Don't label limits but label majors => Check if majors overlap
	// 2) Don't label majors but label limits => Check if limits overlap
	// 3) Label limits and label majors => Check if majors and/or limits overlap
	// compare the previous label's edge with the current label's edge to detect
	// any overlap. The edges in question (top, left, bottom, or right) depend on
	// which end of the scale we start from (zero or span) and whether the scale's
	// orientation is horizontal or vertical.
	int nPrevEdge; // remember where our previous label's edge is
	if (m_bLabelLimits)
		if (bHoriz)
			nPrevEdge = IsScaleReversed() ? m_rcSpanLabel.left : m_rcZeroLabel.right;
		else
			nPrevEdge = IsScaleReversed() ? m_rcSpanLabel.bottom : m_rcZeroLabel.top;
	else if (bHoriz)
		nPrevEdge = IsScaleReversed() ? m_pClientRect->right : m_pClientRect->left;
	else
		nPrevEdge = IsScaleReversed() ? m_pClientRect->top : m_pClientRect->bottom;
	if (m_bLabelMajors) {
		QRect rcGrad, rcLabel;
		float fGrad = GetFirstMajorGrad(); // first major grad value in EU (linear) or power of 10 (log)
		float fMajorDivs = GetMajorDivs(); // offset value in EU (linear) or 1 (power of 10) (log) between each major grad
		QString sLabel;
		while (MakeGrad(TRUE /*check*/, rcGrad, fGrad, m_nMajorGradLength /*nMaxDistanceFromBaseline*/)) {
			// For a vertical scale, offset the labels down one pixel so that for negative values,
			// the minus sign won't line up with the graduations and be easy for the user to miss.
			sLabel = QString::asprintf(m_MajorasprintfStr, fGrad);
			MakeLabel(rcLabel, sLabel, m_nMajorLabelHeight, bHoriz ? TOP_CENTER_PT : LEFT_CENTER_PT,
					bHoriz ?
							QPoint(rcGrad.left, m_nMajorLabelTopleft) :
							QPoint(m_nMajorLabelTopleft, rcGrad.top + (!m_bLogScale && fGrad < 0.0F)));
			int nOverlap;
			if (bHoriz)
				nOverlap = IsScaleReversed() ? nPrevEdge - rcLabel.right - 1 : rcLabel.left - nPrevEdge - 1;
			else
				nOverlap = IsScaleReversed() ? rcLabel.top - nPrevEdge - 1 : nPrevEdge - rcLabel.bottom - 1;
			if (nOverlap < nWorstOverlap)
				nWorstOverlap = nOverlap;
			if (bHoriz)
				nPrevEdge = IsScaleReversed() ? rcLabel.left : rcLabel.right;
			else
				nPrevEdge = IsScaleReversed() ? rcLabel.bottom : rcLabel.top;
			fGrad += fMajorDivs;
		}
	}
	if (m_bLabelLimits) {
		int nOverlap;
		if (bHoriz)
			nOverlap = IsScaleReversed() ? nPrevEdge - m_rcZeroLabel.right - 1 : m_rcSpanLabel.left - nPrevEdge - 1;
		else
			nOverlap = IsScaleReversed() ? m_rcZeroLabel.top - nPrevEdge - 1 : nPrevEdge - m_rcSpanLabel.bottom - 1;
		if (nOverlap < nWorstOverlap)
			nWorstOverlap = nOverlap;
	}
	return nWorstOverlap <= 0;
}
BOOL ScaleDrawingObject::ReduceLabelSizes(int &nWorstOverlap) {
	// Loop to reduce the font sizes of the limit labels and the major labels
	// until there is no longer any overlap between labels or we can't reduce
	// the size anymore because of readability issues. Return TRUE if we still
	// have overlap. Return the worst overlap in output parameter nWorstOverlap.
	m_nLimitLabelHeight = m_pScaleObjectCfg->LimitFont.Height;
	m_nMajorLabelHeight = m_pScaleObjectCfg->MajorFont.Height;
	// Set up the top (y) position of where the major labels should be located
	// for a horizontal scale or the left (x) position for a vertical scale.
	RecalculateMajorLabelTopleft();
	BOOL bIsOverlap;
	BOOL bContinue = TRUE;
	if (m_bLabelLimits)
		MakeLimitLabels();
	do {
		if (bIsOverlap = IsLabelOverlap(nWorstOverlap)) {
			// V6? COMPARE THE WORST OVERLAP TO THE HEIGHT OF THE LABELS?
			// V6? NEED TO HANDLE KIND OF OVERLAP: MAJORS OVERLAP, LIMITS
			// OVERLAP, MAJOR OVERLAPS WITH LIMIT. CAN GET ALL THREE OF THESE!
			int nNewLimitLabelHeight = (int) (m_nLimitLabelHeight * 0.95);
			int nNewMajorLabelHeight = (int) (m_nMajorLabelHeight * 0.95);
			if (m_bLabelLimits && m_bLabelMajors) {
				if (bContinue = (nNewLimitLabelHeight >= 7 || nNewMajorLabelHeight >= 7)) {
					if (nNewLimitLabelHeight >= 7) {
						m_nLimitLabelHeight = nNewLimitLabelHeight;
						MakeLimitLabels();
						RecalculateScaleLimits();
					}
					if (nNewMajorLabelHeight >= 7)
						m_nMajorLabelHeight = nNewMajorLabelHeight;
				}
			} else if (m_bLabelLimits) {
				if (bContinue = (nNewLimitLabelHeight >= 7)) {
					m_nLimitLabelHeight = nNewLimitLabelHeight;
					MakeLimitLabels();
					RecalculateScaleLimits();
				}
			} else if (bContinue = (nNewMajorLabelHeight >= 7))
				m_nMajorLabelHeight = nNewMajorLabelHeight;
		}
	} while (bIsOverlap && bContinue);
	return bIsOverlap;
}
void ScaleDrawingObject::Recalculate(T_PSCALEOBJECT pScaleObjectCfg, QRect &clientRect, BOOL bComputeIndents,
		QRect bounds) {
	m_bComputeIndents = bComputeIndents;
	m_bounds = bounds;
	m_pClientRect = &clientRect;
	m_pScaleObjectCfg = pScaleObjectCfg;
	// Set initially whether we're going to label the major grads. We
	// might have to set this FALSE later if there's no room to show
	// the major labels without having them overlap, even after reducing
	// their font size. Do the same for the limits. Set label heights.
	m_bLabelMajors = m_pScaleObjectCfg->MajorGrads && m_pScaleObjectCfg->LabelMajors;
	m_bLabelLimits = m_pScaleObjectCfg->LabelLimits;
	m_nLimitLabelHeight = m_pScaleObjectCfg->LimitFont.Height;
	m_nMajorLabelHeight = m_pScaleObjectCfg->MajorFont.Height;
	// Create a number 0-15 based on the four scale attributes below. This
	// number represents a basic layout of the scale. Each attribute has two
	// possible values. Use the number created to determine where the baseline
	// should be located in the client rectangle. The position of the grads
	// are then based on where this baseline is located. See enum EScaleLayout
	// in ScaleObject.h to decipher the case labels below.
	m_nLayout = (EScaleLayout) ((m_pScaleObjectCfg->Orientation << 3) + (m_pScaleObjectCfg->LabelPosition << 2)
			+ (m_pScaleObjectCfg->GradsDirection << 1) + m_pScaleObjectCfg->FullWidth);
	RecalculateScaleLimits();
	RecalculateLabels();
	RecalculateScaleLimits();
}
void ScaleDrawingObject::RecalculateBaseline() {
	switch (m_nLayout) {
	case SCALE_HTDN:
		m_rcBaseline.SetRect(m_pClientRect->left + m_pScaleObjectCfg->ZeroIndent,
				m_pClientRect->bottom - m_pScaleObjectCfg->MajorLength,
				m_pClientRect->right - m_pScaleObjectCfg->SpanIndent,
				m_pClientRect->bottom - m_pScaleObjectCfg->MajorLength);
		break;
	case SCALE_HBUN:
		m_rcBaseline.SetRect(m_pClientRect->left + m_pScaleObjectCfg->ZeroIndent,
				m_pClientRect->top + m_pScaleObjectCfg->MajorLength,
				m_pClientRect->right - m_pScaleObjectCfg->SpanIndent,
				m_pClientRect->top + m_pScaleObjectCfg->MajorLength);
		break;
	case SCALE_HTDY:
	case SCALE_HBDN:
	case SCALE_HBDY:
		m_rcBaseline.SetRect(m_pClientRect->left + m_pScaleObjectCfg->ZeroIndent, m_pClientRect->top,
				m_pClientRect->right - m_pScaleObjectCfg->SpanIndent, m_pClientRect->top);
		break;
	case SCALE_HTUN:
	case SCALE_HTUY:
	case SCALE_HBUY:
		m_rcBaseline.SetRect(m_pClientRect->left + m_pScaleObjectCfg->ZeroIndent, m_pClientRect->bottom - 1,
				m_pClientRect->right - m_pScaleObjectCfg->SpanIndent, m_pClientRect->bottom - 1);
		break;
	case SCALE_VRRN:
	case SCALE_VRRY:
	case SCALE_VLRY:
		m_rcBaseline.SetRect(m_pClientRect->left, m_pClientRect->top + m_pScaleObjectCfg->SpanIndent,
				m_pClientRect->left, m_pClientRect->bottom - m_pScaleObjectCfg->ZeroIndent);
		break;
	case SCALE_VRLN:
		m_rcBaseline.SetRect(m_pClientRect->left + m_pScaleObjectCfg->MajorLength,
				m_pClientRect->top + m_pScaleObjectCfg->SpanIndent,
				m_pClientRect->left + m_pScaleObjectCfg->MajorLength,
				m_pClientRect->bottom - m_pScaleObjectCfg->ZeroIndent);
		break;
	case SCALE_VRLY:
	case SCALE_VLLN:
	case SCALE_VLLY:
		m_rcBaseline.SetRect(m_pClientRect->right - 1, m_pClientRect->top + m_pScaleObjectCfg->SpanIndent,
				m_pClientRect->right - 1, m_pClientRect->bottom - m_pScaleObjectCfg->ZeroIndent);
		break;
	case SCALE_VLRN:
		m_rcBaseline.SetRect(m_pClientRect->right - m_pScaleObjectCfg->MajorLength,
				m_pClientRect->top + m_pScaleObjectCfg->SpanIndent,
				m_pClientRect->right - m_pScaleObjectCfg->MajorLength,
				m_pClientRect->bottom - m_pScaleObjectCfg->ZeroIndent);
		break;
	default:
		assert(0);
		break;
	}
}
void ScaleDrawingObject::RecalculateBaselineIndent() {
	if (!m_bComputeIndents)
		return;
	if (!m_bLabelLimits) {
		m_pScaleObjectCfg->ZeroIndent = 3;
		m_pScaleObjectCfg->SpanIndent = 3;
	} else {
		QString sZeroLabel;
		sZeroLabel = QString::asprintf(m_LimitasprintfStr, GetZero());
		QString sSpanLabel;
		sSpanLabel = QString::asprintf(m_LimitasprintfStr, GetSpan());
		CFontCache *pfc = CFontCache::GetHandle();
		HDC hdc = pfc->m_fontHdc;
		int yoffset = 0;
		QFont hfont = pfc->GetNumericFont(m_nLimitLabelHeight, &yoffset);
		QFont hOldfont = (QFont) SelectObject(hdc, hfont);
		QSize size;
		GetTextExtentPoint32(hdc, sZeroLabel, sZeroLabel.size(), &size);
		m_pScaleObjectCfg->ZeroIndent = (USHORT) (
				m_pScaleObjectCfg->Orientation == OBJECT_HORIZONTAL ? size.cx / 2 : (size.cy - yoffset) / 2);
		GetTextExtentPoint32(hdc, sSpanLabel, sSpanLabel.size(), &size);
		m_pScaleObjectCfg->SpanIndent = (USHORT) (
				m_pScaleObjectCfg->Orientation == OBJECT_HORIZONTAL ? size.cx / 2 : (size.cy - yoffset) / 2);
	SelectObject(hdc, h

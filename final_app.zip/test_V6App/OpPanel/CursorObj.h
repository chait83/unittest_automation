/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CursorObj.h
/// @n Description: Cursor Object for Replay and Analysis
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  8 Stability Project 1.5.1.1 7/2/2011 4:56:27 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.5.1.0 7/1/2011 4:25:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 V6 Firmware 1.5 3/14/2007 3:35:43 PM  Jason Parker  The
//  zooming methods have been modified to ensure that any errors in time
//  calculations do not get magnified by zooming
//  5 V6 Firmware 1.4 2/28/2007 5:46:41 PM  Jason Parker  
//  Work in progress - Adding dual cursors
// $
//
// **************************************************************************
#ifndef _CURSOROBJ_H
#define _CURSOROBJ_H
//#define T_CURSOROBJECT T_BASEOBJECT
//**Class*********************************************************************
///
/// @brief Cursor Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It is used in conjunction with the chart in Replay mode
///
//****************************************************************************
class CCursorObject: public CBaseObject {
private:
	T_CURSOROBJECT *m_pCMMcursor;	///< pointer to our CMM configuration
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CCursorObject *pThis, HDC hdc, QRect *pClipRect);
	void SetValuesAndStatus(int enabledPenIndex, float max, float min);
	void SetStatusInvalid(int enabledPenIndex);
	int m_enabledReplayPens;
	CChartQ *m_pChartQ[MAX_CHART_PENS];
	CDataItem *m_pDataItemMax[MAX_CHART_PENS];
	CDataItem *m_pDataItemMin[MAX_CHART_PENS];
	CChartObject *m_pChartObject;
	void DrawCursorV(HDC hdc);
	void DrawCursorH(HDC hdc);
	void CalcTimestampsRect();
	int m_TSfontHeight;
	QRect m_TSrect;
	int m_bannerHeight;
	BOOL m_1OnleftSide;
	BOOL m_2OnleftSide;
	BOOL m_1OnTopSide;
	BOOL m_2OnTopSide;
	QPoint m_MousePos;
public:
	CCursorObject(CWidget *pWidget);
	BOOL m_DualCursors;
	BOOL m_Cursor1Moves;
	BOOL m_Cursor2Moves;
	BOOL m_CursorsLinked;
	int m_Cursor1Pos;
	int m_Cursor2Pos; // for dual cursor useage
	LONGLONG m_Cursor1Time;
	LONGLONG m_Cursor2Time;
	LONGLONG m_display1Time; // times used for calculating diff time to display on banner
	LONGLONG m_display2Time;
	LONGLONG m_actualtime1;
	LONGLONG m_actualtime2;
	void SetActualTime1();
	void SetActualTime2();
	void CalcNewCursorPos();
	void SetDualCursors(BOOL enable);
	void SwapCursors();
	void LinkUnlinkCursors(BOOL link);
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
	void OnChar(wchar_t ch);						///< User input (keyboard or SIP)
	void OnMouseDown(UINT nFlags, QPoint &p);	///< Mouse button down (or touch screen touched) at point
	void OnMouseUp(UINT nFlags, QPoint &p);		///< Mouse button up (or touchscreen)
	void OnMouseMove(UINT nFlags, QPoint &p);	///< Dragging on screen with mouse or touchscreen
	void UpdateCursorPos(QPoint &point);
};
#endif

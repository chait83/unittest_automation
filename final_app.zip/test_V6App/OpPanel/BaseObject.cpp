/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: BaseObject.cpp 
/// @n Description: Base Object class definition
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  78  Stability Project 1.73.1.3 7/2/2011 4:55:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  77  Stability Project 1.73.1.2 7/1/2011 4:37:59 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  76  Stability Project 1.73.1.1 3/17/2011 3:20:11 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  75  Stability Project 1.73.1.0 2/15/2011 3:02:15 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "BaseObject.h"
#ifndef DOCVIEW
#ifndef V6IOTEST
#include "TopStatusBar.h"
#endif
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define DEF_FORECOLOUR	65535 ///<this value is matched to the default value of the CMM db
static BOOL G_flashdefault = FALSE;
static BOOL G_visibledefault = TRUE;
static COLORREF G_forecolour = RGB(255, 255, 255);
static COLORREF G_backcolour = RGB(0, 0, 0);
// Static Initialisation
const USHORT CBaseObject::ms_usMAX_MULTITREND_CHART_PENS = MAX_CHART_PENS;
const USHORT CBaseObject::ms_usMAX_MINITREND_CHART_PENS = 16;
bool CBaseObject::m_bIsQXRecorder = false;
bool CBaseObject::ms_bRecorderTypeInit = false;
//****************************************************************************
/// CBaseObject Constructor
///
/// @param pParentWidget Pointer to Parent Widget 
/// 
//****************************************************************************
CBaseObject::CBaseObject(CWidget *pParentWidget) {
	// keep pointer to our parent widget
	m_pWidget = pParentWidget;
	/// set up empty block info structure;
	BLOCK_INFO emptyInfo = { 0, 0, 0, NULL, 0 };
	m_CMMinfo = emptyInfo;
	m_pCMMbase = NULL;
	m_pNextObj = NULL;
	m_pLinked = NULL;
	m_Originator = FALSE;
	// set these pointers to point to something as default.
	m_pForeColour = &G_forecolour;
	m_pBackColour = &G_backcolour;
	m_pFlashing = &G_flashdefault;
	m_pVisible = &G_visibledefault;
	m_UpdateRequired = FALSE;
	m_UpdateValue = FALSE;
	m_UpdateRotate = FALSE;
	m_UpdateFlash = FALSE;
	m_FlashState = FALSE;
	m_ShowHandles = FALSE;
	m_ResizeState = ResizeNone;
	SetRectEmpty(&m_ClientRect);
	m_pDDSurf = NULL;
	m_ColourKey = 0;
	m_LastFlashUpdate100 = 0;
	// set up OnDraw pointer (however, BaseObject OnDraw does nothing)
	m_pOnDraw = (ONDRAWCAST)&CBaseObject::OnDraw;
	// check if the recorder type has been initialised yet
	if (!ms_bRecorderTypeInit) {
		//ARISTOS QXe Device Type updates
		T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
		// check if this is a minitrend 
		if ( pDEVICE_INFO->IsRecorderMini() || (devType == DEV_XS_MINITREND) ||
		pDEVICE_INFO->IsRecorderEzTrend()) {
			// must be a mini
			m_bIsQXRecorder = true;
		} else if ( pDEVICE_INFO->IsRecorderMulti() || (devType == DEV_XS_MULTIPLUS)) {
			m_bIsQXRecorder = false;
		} else if (devType == DEV_PC_SCREEN_DESIGNER) {
			USHORT recorderType = m_pWidget->m_pScreen->m_pOpPanel->m_pCMMlayout->RecorderType;
			// need to get the information from the layout file
			if ((m_pWidget != NULL) && (m_pWidget->m_pScreen != NULL) && (m_pWidget->m_pScreen->m_pOpPanel != NULL)
					&& (m_pWidget->m_pScreen->m_pOpPanel->m_pCMMlayout != NULL)
					&& (recorderType == DEV_ARISTOS_MULTIPLUS || recorderType == DEV_XS_MULTIPLUS
							|| recorderType == DEV_SCR_MINITREND)) {
				m_bIsQXRecorder = false;
			} else {
				// must be a mini
				m_bIsQXRecorder = true;
			}
		} else {
			// should not happen but set to a mini
			m_bIsQXRecorder = true;
		}
		// only update the init flag if this is the recorder build and not screen designer
#ifndef DOCVIEW
		ms_bRecorderTypeInit = true;
#endif
	}
}
//****************************************************************************
/// CBaseObject Destructor
/// Clean up as Object is deleted (Destroy function does most of the work)
/// 
/// @todo put whatever we need to do in here !!
//****************************************************************************
CBaseObject::~CBaseObject() {
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo - This is a block of CMM info
///
/// @return none
/// 
//****************************************************************************
void CBaseObject::CMMInitBase(BLOCK_INFO *CMMinfo) {
	// keep a copy of the CMM info block passed in.
	m_CMMinfo = *CMMinfo;
	// set up pointer to BaseObject data in CMM info block.
	m_pCMMbase = (T_BASEOBJECT*) m_CMMinfo.pByBlock;
	// here ensure the object can be seen (min size 5x5)
	int minWidth = GetMinWidth();
	int minHeight = GetMinHeight();
	if (m_pCMMbase->Bounds.right - m_pCMMbase->Bounds.left < minWidth)
		m_pCMMbase->Bounds.setright(m_pCMMbase)->Bounds.left + minWidth;
	if (m_pCMMbase->Bounds.bottom - m_pCMMbase->Bounds.top < minHeight)
		m_pCMMbase->Bounds.setBottom(m_pCMMbase)->Bounds.top + minHeight;
	// validate the bounds here against parent widget
	// This code couold be removed after final testing @todo
	BOOL reposition = FALSE;
	QRect Widgetclient = m_pWidget->GetWidgetClientActual();
	if (m_pCMMbase->Bounds.left < Widgetclient.left)
		m_pCMMbase->Bounds.setleft(Widgetclient).left;
	else if (m_pCMMbase->Bounds.left > Widgetclient.right)
		reposition = TRUE;
	if (m_pCMMbase->Bounds.top < Widgetclient.top)
		m_pCMMbase->Bounds.setTop(Widgetclient).top;
	else if (m_pCMMbase->Bounds.top > Widgetclient.bottom)
		reposition = TRUE;
	if (m_pCMMbase->Bounds.right > Widgetclient.right)
		m_pCMMbase->Bounds.setright(Widgetclient).right;
	else if (m_pCMMbase->Bounds.right < Widgetclient.left)
		reposition = TRUE;
	if (m_pCMMbase->Bounds.bottom > Widgetclient.bottom)
		m_pCMMbase->Bounds.setBottom(Widgetclient).bottom;
	else if (m_pCMMbase->Bounds.bottom < Widgetclient.top)
		reposition = TRUE;
	// do we need to reposition it, top left?
	if (reposition) {
		m_pCMMbase->Bounds.setleft(Widgetclient).left;
		m_pCMMbase->Bounds.setTop(Widgetclient).top;
		m_pCMMbase->Bounds.setright(Widgetclient).left + _Width(Widgetclient) / 2;
		m_pCMMbase->Bounds.setBottom(Widgetclient).top + _Height(Widgetclient) / 2;
	}
	// set client from bounds and border settings...
	SetClientRect();
	if ((m_pCMMbase->IsSelected) && (GetOpPanel()->m_EditMode == DESIGNER_MODE))
		m_ShowHandles = TRUE;
	// For loading a previous configuration:
	// linked objects will be re-establised once the complete class hierachy has been reformed.
}
//****************************************************************************
///
/// Drawing function. 
/// This base class version does nothing, except output a debug message.
/// In derived classes it will perform all of the Objects' drawing.
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use
/// @param[in] pClipRect	- pointer to rectangle requiring updating
///							 (must draw *at least* this much)
///
/// @return none
/// 
//****************************************************************************
void CBaseObject::OnDraw(CBaseObject *pThis, HDC hdc, QRect *pClipRect) {
	OutputDebugString(L"Your Object does not have an OnDraw function defined.\n");
}
int CBaseObject::left() {
#ifdef DOCVIEW
	return m_pCMMbase->Bounds.left+GetOpPanel()->m_RecScreenOffset.x;
#else
	return m_pCMMbase->Bounds.left;
#endif
}
int CBaseObject::top() {
#ifdef DOCVIEW
	return m_pCMMbase->Bounds.top+GetOpPanel()->m_RecScreenOffset.y;
#else
	return m_pCMMbase->Bounds.top;
#endif
}
int CBaseObject::right() {
#ifdef DOCVIEW
	return m_pCMMbase->Bounds.right+GetOpPanel()->m_RecScreenOffset.x;
#else
	return m_pCMMbase->Bounds.right;
#endif
}
int CBaseObject::bottom() {
#ifdef DOCVIEW
	return m_pCMMbase->Bounds.bottom+GetOpPanel()->m_RecScreenOffset.y;
#else
	return m_pCMMbase->Bounds.bottom;
#endif
}
;
//****************************************************************************
///
/// Gets the bounds (bounding rectangle - position and size) of the Object in
/// relative co-ordinates (i.e. relative to the Widget).
///
/// @return QRect structure, containing relative co-ordinates 
/// 
//****************************************************************************
QRect CBaseObject::GetBoundsRelative() {
	QRect relative = *(QRect*) &m_pCMMbase->Bounds;
	// convert to 'relative object co-ords'
	QRect WidgetBounds = m_pWidget->GetWidgetBounds();
	OffsetRect(&relative, -WidgetBounds.left, -WidgetBounds.top);
	return relative;
}
//****************************************************************************
///
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// relative co-ordinates (i.e. relative to the Widget).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
///
/// @return none
/// 
//****************************************************************************
void CBaseObject::SetBoundsRelative(QRect *bounds) {
	QRect relative = *bounds;
	// convert to 'widget co-ords'
	QRect WidgetBounds = m_pWidget->GetWidgetBounds();
	OffsetRect(&relative, WidgetBounds.left, WidgetBounds.top);
#ifdef DOCVIEW
	OffsetRect(&relative,-GetOpPanel()->m_RecScreenOffset.x,-GetOpPanel()->m_RecScreenOffset.y);
#endif
	m_pCMMbase->Bounds = *(T_TV_RECT*) &relative; ///< cast to TV_RECT (CMM struct)
	SetClientRect();
}
//****************************************************************************
///
/// Gets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @return QRect structure, containing Widget co-ordinates 
/// 
//****************************************************************************
QRect CBaseObject::GetBounds() {
	QRect temp = *(QRect*) &m_pCMMbase->Bounds;
#ifdef DOCVIEW	
	OffsetRect(&temp,GetOpPanel()->m_RecScreenOffset.x,GetOpPanel()->m_RecScreenOffset.y);
#endif
	return temp;
}
//****************************************************************************
/// Get the XFactor - ratio of width to height
///
/// @param[in] bounds	- bounds to use for x factor calculation (not current bounds)
///						 
/// @return xfactor
/// 
//****************************************************************************
float CBaseObject::GetXfactor(QRect bounds) {
	float xfactor = _Width(bounds) / (float) _Height(bounds);
	return xfactor;
}
//****************************************************************************
///
/// Gets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @return QRect structure, containing Widget co-ordinates 
/// 
//****************************************************************************
QRect CBaseObject::GetBoundsActual() {
	return *(QRect*) &m_pCMMbase->Bounds;
}
//****************************************************************************
///
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CBaseObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	QRect temp = *bounds;
#ifdef DOCVIEW
	OffsetRect(&temp,-GetOpPanel()->m_RecScreenOffset.x,-GetOpPanel()->m_RecScreenOffset.y);
#endif
	m_pCMMbase->Bounds = *(T_TV_RECT*) &temp;  ///< cast to TV_RECT (CMM struct)
	SetClientRect();
}
//****************************************************************************
///
/// Sets the Objects Client rectangle (bounds less border)
///	Assumes bounds have been set correctly in advance
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CBaseObject::SetClientRect() {
	// set m_ClientRect (equal to bounds less border)
	m_ClientRect = *(QRect*) &m_pCMMbase->Bounds;
#ifdef DOCVIEW
	OffsetRect(&m_ClientRect,GetOpPanel()->m_RecScreenOffset.x,GetOpPanel()->m_RecScreenOffset.y);
#endif
	// 'inflate' it by negative amounts (i.e. deflate). if no border then ClientArea=Bounds
	if (m_pCMMbase->Border.BorderUsed)
		InflateRect(&m_ClientRect, -m_pCMMbase->Border.BorderWidth, -m_pCMMbase->Border.BorderWidth);
#ifdef DOCVIEW
	GetOpPanel()->OnBoundsChanged(this); // update Screen Designer's position/size indicators
#endif
}
//****************************************************************************
///
/// Overridable function to get an area of an Object to update
/// This default version returns the object's client rectangle
///
/// @param[in] pUpdateRect	- pointer to rectangle to configure
/// @param[in] ticks100		- Optional time param (100ths)
///
/// @return T/F
/// 
//****************************************************************************
BOOL CBaseObject::GetUpdateRect(QRect *pUpdateRect, LONGLONG ticks100) //=0
		{
	*pUpdateRect = m_ClientRect;
	return FALSE;
}
//****************************************************************************
///
/// Check the Handles for mouse contact
///
/// @param[in] point	- reference to Point to check against handles
///
/// @return none
/// 
//****************************************************************************
BOOL CBaseObject::HitTestHandles(QPoint &point) {
	return ::HitTestHandles(GetBounds(), m_ResizeState, point);
}
//****************************************************************************
///
/// Draw the Handles
///
/// @param[in] hdc		- Device Context handle to draw to
///
/// @return none
/// 
//****************************************************************************
void CBaseObject::DrawObjectHandles(HDC hdc) {
	DrawHandles(hdc, GetBounds(), RGB(0, 0, 255)); // blue for Object
}
//****************************************************************************
///
/// Draw the Handles
///
/// @param[in] pDDsurf	- pointer to DirectDraw surface to draw to
///
/// @return none
/// 
//****************************************************************************
//E437415
void CBaseObject::DrawObjectHandles(LPDIRECTDRAWSURFACE pDDsurf) {
	HDC hdc;
	int hr = pDDsurf->GetDC(&hdc);
	if (!FAILED(hr)) {
		DrawHandles(hdc, GetBounds(), RGB(0, 0, 255)); // blue for Object		
		pDDsurf->ReleaseDC(hdc);
	}
}
//****************************************************************************
///
/// SetColourKey for Transparent blts.
///
/// @param[in] colr		- Colour to set as transparency
///
/// @return none
/// 
//****************************************************************************
void CBaseObject::SetColourKey(Colour colr) {
	m_ColourKey = colr; // save it here (used for TransAlphaBlend)
	// then also set it up here for Transparent blts
	DDCOLORKEY ddck;
	ddck.dwColorSpaceLowValue = colr;
	ddck.dwColorSpaceHighValue = ddck.dwColorSpaceLowValue;
	m_pDDSurf->SetColorKey(DDCKEY_SRCBLT, &ddck);
}
//****************************************************************************
///
/// Returns the T_LAYOUTITEM of this Object
///
/// @param none
///
/// @return T_LAYOUTITEM
/// 
//****************************************************************************
T_LAYOUTITEM CBaseObject::GetLayoutItem() {
	T_LAYOUTITEM ref;
	ref.CMM_Type = m_CMMinfo.wBlockType;
	ref.CMM_Inst = m_CMMinfo.wInstanceID;
	return ref;
}
//****************************************************************************
///
///	Function to check if this CBaseObject matches a LayoutItem reference from 
/// the CMM.
///
/// @param[in] LayoutItem - type and instance reference from CMM
///
/// @return TRUE/FALSE
/// 
//****************************************************************************
BOOL CBaseObject::MatchLayoutItem(T_LAYOUTITEM *LayoutItem) {
	return ((m_CMMinfo.wInstanceID == LayoutItem->CMM_Inst) && // match type and instance?
			(m_CMMinfo.wBlockType == LayoutItem->CMM_Type)); // check it's BLK_xxxx object type
}
COpPanel* CBaseObject::GetOpPanel() {
	return m_pWidget->m_pScreen->m_pOpPanel;
}
/*
 typedef enum ObjectType
 {
 NoObject=0,
 ExampleBar,
 DigitalObject,
 BarObject,
 TextObject,
 ScaleObject,
 BitmapObject,
 ChartObject,
 PenPointersObject,
 AlarmMrkrObject,
 ButtonObject,
 TabularDisplayObject,
 TUSObject,
 CircularChartObject
 SUPPORTED_OBJECT_TYPES // keep at end of list 
 } T_OBJECT_TYPE;
 */
// strings for testing below
WCHAR ObjectStr[SUPPORTED_OBJECT_TYPES][20] = { L"NoObject", L"ExampleBar", L"DigitalObject", L"BarObject",
		L"TextObject", L"ScaleObject", L"BitmapObject", L"ChartObject", L"PenPointersObject", L"AlarmMrkrObject",
		L"CursorObject", L"ButtonObject", L"TabularDisplay", L"TUSObject", L"CircularChartObject" };
//****************************************************************************
///
/// Function called from screen designer to link an Object into the chain
///
/// @param [in] pObj - pointer to object to link in
/// @param [in] bDeferLinking - if TRUE, defer linking (for canned screens)
/// @param [out] pLinkError	- link error when function returns FALSE
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CBaseObject::LinkTo(CBaseObject *pObj, BOOL bDeferLinking/*=FALSE*/, LinkError *pLinkError/*=NULL*/,
		BOOL bDoingDeferedLink) //=FALSE
		{
	if (pLinkError)
		*pLinkError = LINK_ERROR_NONE;
	if (bDoingDeferedLink) // not required now
		return FALSE;
	/*
	 // probably not required now. Use the bDeferLinking flag to allow 'cross-widget' linking for canned screens (see below)
	 if(bDeferLinking)
	 {
	 // For canned screen setup (there may be other
	 // cases in the future), defer the linking until
	 // the layout is "at rest". The linking alignment
	 // wouldn't be correct if the linking was done
	 // immediately when the canned screens were set up.
	 LinkToCmd linkcmd;
	 linkcmd.pLinkToInvoker=this;
	 linkcmd.pLinkToInvokee=pObj;
	 GetOpPanel()->m_LinkToCmdArray.Add(linkcmd);
	 return TRUE;
	 }
	 */
	// check it's ok to link 
	if (pObj->m_pLinked) {
		if (pLinkError)
			*pLinkError = LINK_ERROR_ALREADY_LINKED;
		return FALSE; // object to link to is already linked!
	}
	// find out if object allows linking
	if (pObj->GetLinkOrient() == LINK_NONE) {
		if (pLinkError)
			*pLinkError = LINK_ERROR_CANNOT_LINK;
		return FALSE; // object cannot link
	}
	// find out if object is same object
	if (pObj == this) {
		if (pLinkError)
			*pLinkError = LINK_ERROR_SAME_OBJECT;
		return FALSE; // object is same object
	}
	if (!bDeferLinking) // don't do this check for canned screens (allow temporary cross-widget linking)
	{
		// find out if object in same widget
		if (pObj->m_pWidget != m_pWidget) {
			if (pLinkError)
				*pLinkError = LINK_ERROR_BETWEEN_WIDGETS;
			return FALSE; // object in another widget
		}
	}
	// find out if the orientation is OK
	if (pObj->GetLinkOrient() != GetLinkOrient()) {
		if (pLinkError)
			*pLinkError = LINK_ERROR_WRONG_ORIENTATION;
		return FALSE; // object is the wrong way around
	}
	// are we already linked ?
	CBaseObject *pExistingLink = NULL;
	if (m_pLinked)
		pExistingLink = m_pLinked; // keep exisiting
	m_pLinked = pObj; // link in the new Object
	if (pExistingLink)
		pObj->m_pLinked = pExistingLink; // make new object point to where we pointed.
	else
		pObj->m_pLinked = this; // make new linked object point back to us	
	// linked into chain ok so far...
	// now test it with our current parameters to see if the Object is ok
	BOOL retval = FALSE;
	QRect newbounds = GetBounds();
	if (GetLinkOrient() == LINK_VERTICAL) {
		retval = SetLinkLimits(*(int*) &newbounds.top, *(int*) &newbounds.bottom);
		if (!retval && pLinkError)
			*pLinkError = LINK_ERROR_CANNOT_SET_LINK_LIMITS;
	} else {
		retval = SetLinkLimits(*(int*) &newbounds.left, *(int*) &newbounds.right);
		if (!retval && pLinkError)
			*pLinkError = LINK_ERROR_CANNOT_SET_LINK_LIMITS;
	}
	if (retval) {
		// all ok so assign the CMM reference to linked object.
		SetBounds(&newbounds);
		m_pCMMbase->LinkedObj = pObj->GetLayoutItem();
		if (pExistingLink)
			pObj->m_pCMMbase->LinkedObj = pExistingLink->GetLayoutItem(); // ref of object we used to point to
		else
			pObj->m_pCMMbase->LinkedObj = GetLayoutItem(); // make new linked object reference us	
		//	qDebug("LLLL --- Linked %s and %s OK \n",ObjectStr[m_pCMMbase->ObjectType], ObjectStr[pObj->m_pCMMbase->ObjectType]);
	} else {
		// otherwise linking has failed, we need to remove the Object 
		m_pLinked = pObj->m_pLinked;
		pObj->m_pLinked = NULL;
		qDebug("LLLL --- Linking FAILED between %s and %s\n", ObjectStr[this->m_pCMMbase->ObjectType],
				ObjectStr[pObj->m_pCMMbase->ObjectType]);
	}
	return retval;
}
//****************************************************************************
///
/// Function called from screen designer to unlink this Object from the chain
///
/// @return TRUE if object unlinked or FALSE if object wasn't linked
/// 
//****************************************************************************	
BOOL CBaseObject::Unlink() {
	BOOL bRet;
	if (bRet = (m_pLinked != NULL)) {
		// Traverse the link chain to find the
		// object pointing to me (pMyPredObj).
		CBaseObject *pNextObj = m_pLinked; // start at what I point to and loop back to me
		CBaseObject *pMyPredObj = NULL;	 // this will be the object preceding pNextObj
		while (pNextObj != this) // loop back to me in the link chain
		{
			pMyPredObj = pNextObj;
			pNextObj = pNextObj->m_pLinked;
		}
		// Point the object pointing to me to what I point to.
		// If I point to this predecessor object, then there's
		// just two objects in chain, so take both out of chain.
		if (pMyPredObj)
			if (m_pLinked != pMyPredObj) {
				pMyPredObj->m_pLinked = m_pLinked;
				pMyPredObj->m_pCMMbase->LinkedObj = m_pLinked->GetLayoutItem();
			} else {
				pMyPredObj->m_pLinked = NULL;
				SetNull(pMyPredObj->m_pCMMbase->LinkedObj);
			}
		// Take myself out of the chain.
		m_pLinked = NULL;
		SetNull(m_pCMMbase->LinkedObj);
	}
	return bRet;
}
//****************************************************************************
///
/// Called when an object is resized to check the new limits with any linked 
/// Objects to see if it is allowed to proceed
///
/// @param [in] lim1	- top or left of Object bounds
/// @param [in] lim2	- bottom or right of Object bounds 
/// @param [out] pPos1	- link position 1 (top or left of scale)
///						 to return if pointer is non-NULL
/// @param [out] pPos2	- link position 2 (bottom or right of scale)
///						 to return if pointer is non-NULL
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CBaseObject::SetLinkLimits(int &lim1, int &lim2, int *pPos1, int *pPos2) {
	BOOL retval = TRUE;
	if (m_pLinked) {
		// Object is linked.
		int pos1 = 0;
		int pos2 = 0;
		// calculate the new link positions based on the Object size limits
		// if this is not possible (e.g. for size reasons) return FALSE
		if ((retval = CalcLinkPositions(lim1, lim2, &pos1, &pos2)) == TRUE) {
			// set our flag so we know we are the originator
			m_Originator = TRUE;
			// call the test functions along the chain with the link positions
			retval = m_pLinked->TestLinkPositions(pos1, pos2);
			if (retval && pPos1 && pPos2) {
				*pPos1 = pos1;
				*pPos2 = pos2;
			}
			m_Originator = FALSE;
		}
	}
	return retval;
}
//****************************************************************************
///
/// Called for each object along the chain, checking the link positions.
/// (if Object can resize so that zero and span are on the supplied positions)
///
/// @param [in] pos1	- link position 1 (top or left of scale)
/// @param [in] pos2	- link position 2 (bottom or right of scale)
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CBaseObject::TestLinkPositions(int pos1, int pos2) {
	if (m_Originator)
		return TRUE; // we have got to the end of the list
	// check to see if the positions can be set to match
	// if so, new limits for the objects bounds will be returned.
	int lim1 = 0;
	int lim2 = 0;
	if (!CanSetLinkPositions(pos1, pos2, &lim1, &lim2))
		return FALSE; // can't do it.
	// otherwise call next linked object
	BOOL retval = m_pLinked->TestLinkPositions(pos1, pos2);
	if (retval == TRUE) {
		// all ok, so set the new size here
		QRect oldbounds = GetBounds();
		QRect bounds = oldbounds;
		// use the limits returned above to set the new bounds.
		if (GetLinkOrient() == LINK_VERTICAL) {
			bounds.setTop(lim1);
			bounds.setBottom(lim2);
		} else {
			bounds.setleft(lim1);
			bounds.setright(lim2);
		}
		SetBounds(&bounds, &pos1, &pos2); // set the object bounds (and client area)	
		// apply to all objects on all screens using template
		GetOpPanel()->UpdateBounds(&bounds, &m_pWidget->GetLayoutItem(), &GetLayoutItem(), &pos1, &pos2);
		// now repaint!
		UnionRect(&bounds, &oldbounds, &bounds);
		m_pWidget->InvalidateArea(bounds, FALSE); // do not do an update here (will be all done at once)
	}
	return retval;
}
//****************************************************************************
///
/// Overridable function to convert from limits of object (bounds) to scale
/// positions. Returns FALSE if can't be done.
///
///	@param [in] lim1	- top or left of Object bounds
/// @param [in] lim2	- bottom or right of Object bounds 
/// @param [out] pPos1	- link position 1 (top or left of scale)
/// @param [out] pPos2	- link position 2 (bottom or right of scale)
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CBaseObject::CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2) {
	// allow for border...
	int borderWidth = 0;
	if (m_pCMMbase->Border.BorderUsed)
		borderWidth = m_pCMMbase->Border.BorderWidth;
	*pPos1 = lim1 + borderWidth;
	*pPos2 = lim2 - 1 - borderWidth; // allow for bottom/right hand edge
	if ((*pPos1) < (*pPos2))
		return TRUE;
	return FALSE; // cannot use the limits as supplied.
}
//****************************************************************************
///
/// Check if the Object can be resized so that the scale postions are pos1 
/// and pos2. Object must return the new bounds required to do this in 
/// pLim1 and pLim2
///
/// @param [in] pos1	- link position to match (top or left of scale)
/// @param [in] pos2	- link position to match (bottom or right of scale)
///	@param [out] pLim1	- top or left of Object bounds
/// @param [out] pLim2	- bottom or right of Object bounds 
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CBaseObject::CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2) {
	// allow for border...
	int borderWidth = 0;
	if (m_pCMMbase->Border.BorderUsed)
		borderWidth = m_pCMMbase->Border.BorderWidth;
	*pLim1 = pos1 - borderWidth;
	*pLim2 = pos2 + 1 + borderWidth; // allow for bottom/right hand edge
	// check new overall limits against Widget's client area
	if (GetLinkOrient() == LINK_VERTICAL) {
		if (((*pLim1) >= m_pWidget->m_WidgetClientRect.top) && ((*pLim2) <= m_pWidget->m_WidgetClientRect.bottom))
			return TRUE;
	} else // HORIZONTAL
	{
		if (((*pLim1) >= m_pWidget->m_WidgetClientRect.left) && ((*pLim2) <= m_pWidget->m_WidgetClientRect.right))
			return TRUE;
	}
	return FALSE; // cannot use the positions as supplied.
}
QString CBaseObject::GetId() {
	return m_pWidget->GetObjectName(m_pCMMbase) + L" in " + m_pWidget->GetId();
}
//****************************************************************************
// const USHORT GetMaxChartPens()
///
/// Method that gets the maximum allowable number of chart pens given the current device type
///
/// @return The maximum number of chart pens allowed on this device type
/// 
/// @todo Possibly make this method use the layout device type rather than the setup device type
///
//****************************************************************************	
const USHORT CBaseObject::GetMaxChartPens() {
	USHORT usMaxChartPens = 0;
	T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
	//ARISTOS QXe Device Type updates
	// check if this is a minitrend 
	if ( pDEVICE_INFO->IsRecorderMini() || (devType == DEV_XS_MINITREND) ||
	pDEVICE_INFO->IsRecorderEzTrend()) {
		usMaxChartPens = ms_usMAX_MINITREND_CHART_PENS;
	} else if ( pDEVICE_INFO->IsRecorderMulti() || (devType == DEV_XS_MULTIPLUS)) {
		usMaxChartPens = ms_usMAX_MULTITREND_CHART_PENS;
	} else if ( pDEVICE_INFO->GetDeviceType() == DEV_PC_SCREEN_DESIGNER) {
		T_DEV_TYPE recorderType = m_pWidget->m_pConfig->GetRecorderType();
		// need to get the information from the layout file
		if (recorderType == DEV_ARISTOS_MULTIPLUS || recorderType == DEV_XS_MULTIPLUS
				|| recorderType == DEV_SCR_MINITREND) {
			usMaxChartPens = ms_usMAX_MULTITREND_CHART_PENS;
		} else {
			// must be a mini
			usMaxChartPens = ms_usMAX_MINITREND_CHART_PENS;
		}
	} else {
		// should not happen but set to one
		usMaxChartPens = 1;
	}
	return usMaxChartPens;
}
//BOOL CBaseObject::isObjectOverlapped()
//{
////#ifndef UNDER_CE
//	return FALSE;
////#endif
//
//	HWND hfgWnd		= GetForegroundWindow();
//	QRect rectFG;
//	GetWindowRect(hfgWnd, &rectFG);
//	QRect rectOP;
//	GetOpPanel()->GetWindowRect(&rectOP);
//	BOOL bIsWndOverlapping = FALSE;
//	
//	if ( _Width(rectFG) < _Width(rectOP) )
//	{
//		bIsWndOverlapping = TRUE;
//
//	}
//	//else if (_Height(rectFG) > _Height(rectOP))
//	//{
//	//	// SIP dialog is displayed in full screen
//
//	//	bIsWndOverlapping = TRUE;
//
//	//}
//#ifndef DOCVIEW
//	else if ( CTopStatusBar::Instance()->IsControlBarInUse() )
//	{
//		CTopStatusBar::Instance()->GetControlBarRect(rectFG);
//		bIsWndOverlapping = TRUE;
//	}
//
//	else if ( CTopStatusBar::Instance()->GetErrorDlgRectIfVisible(rectFG) )
//	{
//		bIsWndOverlapping = TRUE;
//	}
//#endif	
//	if ( bIsWndOverlapping == TRUE )
//	{
//				// we have found some other window on top of oppanel, so do not paint on that window
//		if ( m_ClientRect.left < rectFG.right &&
//			 m_ClientRect.right > rectFG.left &&
//			 m_ClientRect.top < rectFG.bottom &&
//			 m_ClientRect.bottom > rectFG.top)
//		{
//			return TRUE;
//		}
//
//	}
//	
//	return FALSE;
//}

/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/****************************************************************************
 //  COPYRIGHT (c) 2014
 // HONEYWELL INTERNATIONAL INC.
 // ALL RIGHTS RESERVED
 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: CircularChartObject.cpp
/// @n Description: Circular chart object 
///
// **************************************************************************
// Revision History
// **************************************************************************
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "TimeHistory.h"
#include "float.h"
#include "CircularChartUtils.h"
#ifndef UNDER_CE
#include "Mmsystem.h"
#pragma comment( lib, "Winmm" )
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
extern BOOL Glb_SeeRegions;
#pragma warning( disable : 4244 4267)
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CCircularChartObject
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#define MAX_CIRCI_UPDATE_IN_TICKS	100			// Cap Circular updates to 1 second
/// The variables below are used to setup the correct font for each product
const int QVGA_TIMESTAMP_FONT_HEIGHT = 11;		//XS - Qx and Qxe GR - Qxe
const int VGA_TIMESTAMP_FONT_HEIGHT = 22;		//GR - Qx
const int SVGA_PLUS_TIMESTAMP_FONT_HEIGHT = 13;	//XS - Sx
const int XVGA_PLUS_TIMESTAMP_FONT_HEIGHT = 16; //PSR - timestamp font height for GR SX (13*1.28)
// Colours used for drawing circular charts
#define CIRCI_MAJOR_GRAD_COL			RGB(128,128,128)
#define CIRCI_MINOR_GRAD_COL			RGB(192,192,192)
#define CIRCI_SUB_MINOR_GRAD_COL		RGB(220,220,220)
#define CIRCI_HOLE_FILL_COL				RGB(225,225,225)
#define CIRCI_PAPER_COL					RGB(255,255,255)
#define CIRCI_DIVIDER_COL				RGB(0,0,0)
#define CIRCI_TS_COL					RGB(64,64,64)
#define CIRCI_RT_BACKGROUND_COL			RGB(231,223,231)
#define CIRCI_PEEK_BACKGROUND_COL		RGB(255,236,139)//RGB(223,223,255)//PSR Fix for PAR# 1-3K9UAG0 - Circi Chart screen Background color and History text size
//****************************************************************************
/// CCircularChartObject Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
//****************************************************************************
CCircularChartObject::CCircularChartObject(CWidget *pParentWidget) : CBaseObject(pParentWidget) {
	// Default to realtime mode
	m_bShowingRealtime = TRUE;
	m_RealtimeMode = TRUE;
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CCircularChartObject::OnDraw;
	// Setup font sizes
	m_TSfontHeight = QVGA_TIMESTAMP_FONT_HEIGHT;
	if ( pDALGLB->IsRecorderMini()) {
		m_TSfontHeight = VGA_TIMESTAMP_FONT_HEIGHT;
	} else if ( pDALGLB->IsRecorderMulti()) {
		m_TSfontHeight = XVGA_PLUS_TIMESTAMP_FONT_HEIGHT;
	}
	// Default working variables
	m_ChartSpeed = SPEED_FAST;
	m_enabledChartPens = 0;
	m_LastUpdateTime = 0;
	m_ChartDurationAsStr = "None";
	// Create view model
	vm = new CirciViewModel();
	// Switch of drawing until updates required
	m_FullDraw = false;
	m_LeadingDraw = false;
	m_LastTimeChangeValue = 0;
	// Assign instances to all scales
	for (int i = 0; i < MAX_CIRCI_SCALES; i++) {
		m_Scale[i].m_Instance = i;
	}
}
//****************************************************************************
///	Destructor 
///
/// @param none
//****************************************************************************
CCircularChartObject::~CCircularChartObject() {
	delete (vm);
}
//****************************************************************************
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
//****************************************************************************
void CCircularChartObject::Destroy() {
}
//****************************************************************************
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
//****************************************************************************
void CCircularChartObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CCircularChartObject data in CMM info block.
	m_pCMMchart = (T_CIRCCHARTOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		m_pCMMbase->Border.BorderUsed = TRUE;
		m_pCMMbase->Border.BorderWidth = 1;
		// set the attribute block settings for chart
		m_pCMMbase->AttrBlocks.BackColourBlk = ATTRIB_CHART_NORMAL; // use this GLOBAL attribute block for background colour
		m_pCMMbase->AttrBlocks.ForeColourBlk = ATTRIB_CHART_NORMAL; // use this GLOBAL attribute block for foreground colour
	}
	// Override the update rate and set to 1 second, we do not want very fast updates
	m_pCMMbase->UpdateRate100 = MAX_CIRCI_UPDATE_IN_TICKS;
	// set these flags for specific Object (i.e.advanced draw only)
	m_pCMMbase->IsAdvancedDraw = TRUE; // chart is advanced drawn only.
	m_pCMMbase->IsPrimaryDirect = FALSE; // not primary direct (may not allow at all)
	// if primary direct was not set, then we would have the following as next default
	m_pCMMbase->IsPermanent = TRUE; // on permanent surface
	m_pCMMbase->IsBackground = TRUE;
	ConfigChange();
}
//****************************************************************************
/// This function will be called after any setup changes have been made 
/// and will be used toi reconfgiure the chart for speed changes and 
/// Peek view
///
/// @param none
///
/// @return none
//****************************************************************************
void CCircularChartObject::ConfigChange() {
	// Assign time update of this config change
	// Used to detect if time changed and required a refresh
	m_LastTimeChangeValue = pSYSTIMER->GetPreTimeChangeProcessTime().GetMicroSecs();
	// set up our surface pointer here...
	if (m_pCMMbase->IsPermanent)
		m_pDDSurf = m_pWidget->m_pDDSPermanent;
	CScreen *pkParentScreen = m_pWidget->GetScreen();
	const USHORT usSCREEN_NO = pkParentScreen->m_pCMMscreen->Number - 1;
	USHORT usChartIndex = 0;
	CWidget *pkWidget = pkParentScreen->m_pWidgets;
	bool bFoundChart = false;
	while ((pkWidget != NULL) && !bFoundChart) {
		CBaseObject *pkBaseObject = pkWidget->m_pObjects;
		while ((pkBaseObject != NULL) && !bFoundChart) {
			// check if this is a chart object
			if (pkBaseObject->GetLayoutItem().CMM_Type == BLK_CIRCCHARTOBJECT) {
				// this is a chart object therefore check if it has the same index as the current selected
				// object
				if (pkBaseObject == this) {
					bFoundChart = true;
					break;
				} else {
					// not the right chart therefore increment the chart index 
					++usChartIndex;
					// break from the object loop to save time as only one chart is allowed per widget
					break;
				}
			}
			// move onto the next object
			pkBaseObject = pkBaseObject->m_pNextObj;
		}
		// move on to the next widget
		pkWidget = pkWidget->m_pNextWgt;
	}
	// Get chart speed
	m_ChartSpeed = static_cast<ChartSpeed>( pSYSTEM_INFO->GetChartSpeed(usChartIndex, usSCREEN_NO));
	// Setup index to get older chart data if required, 
	// Note: this is where you would modify to get even older peek histories
	int histIndex = (m_RealtimeMode) ? 0 : 1;
	// Get the desired start and end time of the chart
	CTVtime startTime, endTime;
	T_PRECPROFILE ptRecProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	CircularChartUtils::GetCircularChartHistoricalSpan(&ptRecProfile->Chart, m_ChartSpeed, histIndex, startTime,
			endTime, m_ChartDurationAsStr);
	int seconds = USEC_TO_SEC(endTime.GetMicroSecs() - startTime.GetMicroSecs());
	// Get chart divs and drawing slots
	T_CIRC_CHART_DIVISIONS divs;
	CircularChartUtils::GetChartTimeDivisions(&ptRecProfile->Chart, m_ChartSpeed, divs);
	// Setup circular chart VM
	vm->SetDataInfo(startTime, seconds, divs.PointsPerChart, divs.majorDivs.numberOfDivs, divs.minorDivs.numberOfDivs,
			divs.subsideriesPerMinor.numberOfDivs);
	// Pre-Calculate the timestamps rect
	CalcTimestampsRect();
	// Configure all Pens in chart
	T_CHANNELREF channelInfo;
	channelInfo.Enabled = TRUE;
	channelInfo.Updates = FALSE;
	channelInfo.Rotate = FALSE;
	channelInfo.ItemType = DI_PEN;
	channelInfo.SubType = 0;
	m_enabledChartPens = 0;
	USHORT usMaxChartPens = GetMaxChartPens();
	for (int i = 0; i < usMaxChartPens; i++) {
		// reset all traces
		vm->m_Trace[i].Reset();
		if (i < m_pWidget->m_pCMMwidget->NumChannels) {
			// complete our channel Ref info here
			channelInfo.IndexChan = i; // use Widget's channel index
			CDataItem *pDataItem = m_pWidget->GetDataItemPtr(&channelInfo);
			if (pDataItem && pDataItem->IsEnabled()) // is the data item actually enabled?
					{
				vm->m_Trace[m_enabledChartPens].m_pChartDataItem = pDataItem;
				m_enabledChartPens++;
			}
		}
	}
	// Assign vm with number of enabled traces
	vm->m_EnabledTraces = m_enabledChartPens;
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
	// Get a handle on the time history table
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	// No, we need to calculate the tick time from the realtime
	// so get entry in time table to reconcile real time with tick time
	DetailedTimeEntry pEntry = pTh->GetDetailedTimeEntry(startTime);
	// Get the end time as the point could span multiple time slots
	DetailedTimeEntry pEntryEnd = pTh->GetDetailedTimeEntry(endTime);
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
	// For those enabled pens, get the chartQ's and configure the conversion info
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->WaitLock(1);
	for (int p = 0; p < m_enabledChartPens; p++) {
		// re-init these
		vm->m_Trace[p].m_Initialised = FALSE;
		/// Allocate readings
		vm->AllocateTraceReadings(p);
		// Add/or gets the chart Q thet we require
		vm->m_Trace[p].m_pChartQ = CM->AddCircularChartQ(vm->m_Trace[p].m_pChartDataItem->GetInstance(), m_ChartSpeed);
		vm->m_Trace[p].m_pChartQ->m_DrawingTpp = vm->m_TicksPerReading;
		vm->m_Trace[p].m_pChartQ->m_ReplayUsage = FALSE;
		// here only do this if the chart is on the active screen
		// since each screen is 'active' as it is created, only do this if it matches the current screen number
		CScreen *pkParentScreen = m_pWidget->GetScreen();
		if (pkParentScreen->GetOpPanel()->m_CurrentScreenNumber == pkParentScreen->m_pCMMscreen->Number) {
			if (!vm->m_Trace[p].m_pChartQ->m_InitialRequest) {
				vm->m_Trace[p].m_pChartQ->m_InitialRequest = TRUE; // set this again to ensure we get a request for the most recent screens worth of data
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin	
				if ( FALSE == m_bShowingRealtime && FALSE == m_RealtimeMode) {
					//Chart in history mode
					//qDebug("\n(pEntry.StartTick100 = %d, pEntry.EndTick100 = %d) and (pEntryEnd.StartTick100 = %d, pEntryEnd.EndTick100 = %d)\n", pEntry.StartTick100, pEntry.EndTick100, pEntryEnd.StartTick100 ,pEntryEnd.EndTick100);
					if ((0 != pEntry.StartTick100) && (0 != pEntryEnd.EndTick100)) {
						vm->m_Trace[p].m_pChartQ->CheckQueue(true, pEntry.StartTick100, pEntryEnd.EndTick100);
					}
					if ((0 != pEntry.StartTick100) && (0 != pEntryEnd.StartTick100)) {
						vm->m_Trace[p].m_pChartQ->CheckQueue(true, pEntry.StartTick100, pEntryEnd.StartTick100);
					}
					if ((0 != pEntry.StartTick100) && (0 != pEntry.EndTick100)) {
						vm->m_Trace[p].m_pChartQ->CheckQueue(true, pEntry.StartTick100, pEntry.EndTick100);
					} else {
						vm->m_Trace[p].m_pChartQ->CheckQueue(true, 0, 0);
					}
				} else {
					//Chart in realtime mode
					vm->m_Trace[p].m_pChartQ->CheckQueue(false, 0, 0);
				}
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
			}
		}
	}
	// Setup message list access
	vm->m_InitialisedMessages = FALSE;
	vm->m_pMessageQ = CM->m_ChartMessageQ;
	// Release the queue access
	CM->Unlock();
	// Assign data item to scale
	if (m_enabledChartPens > 0) {
		// Note, Only setup 1 scale here, but this would be used to setup multiple scales if required
		m_Scale[0].Config(vm->m_Trace[0].m_pChartDataItem, true);
	}
	// Setup group number
	if (GetWidget()->GetScreen()->m_pCMMscreen->UseGroups)
		vm->m_GroupNumber = GetWidget()->GetScreen()->m_pCMMscreen->GroupIndex + 1;
	else
		vm->m_GroupNumber = 0;
	// Set bounds
	SetBounds(&GetBounds());
	// Don't update immediately. 	
	m_LastUpdateTime = pGlbSysTimer->GetHighResOnGoingTick100();
}
//****************************************************************************
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
//****************************************************************************
void CCircularChartObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	CBaseObject::SetBounds(bounds, pPos1, pPos2); // call the base Object version
	CChartQManager *CM = CChartQManager::GetHandle();
	// Set Chart dimensions and position
	vm->SetDimensionsFromBoundingRect(bounds, 2);
	// Set the bounds for the scale rects
	for (int i = 0; i < MAX_CIRCI_SCALES; i++) {
		m_Scale[i].SetRect(vm->m_centreX, vm->m_centreY, vm->m_radius, vm->m_holeRadius);
	}
	// for the enabled pens, configure the conversion info and calc the grads
	for (int p = 0; p < m_enabledChartPens; p++) {
		float zero = vm->m_Trace[p].m_pChartDataItem->GetZero();
		float span = vm->m_Trace[p].m_pChartDataItem->GetSpan();
		vm->m_Trace[p].m_convInfo.CalcFConvInfo(zero, span, (float) vm->m_zeroRadius, (float) vm->m_spanRadius);
		// the first pens conversion info is used for the graduations	
		// HTS - if you wasnt to make first scale selectable this is where you would change
		if (p == 0) {
			m_grads.SetZoomed(FALSE, 0, 0); // are we zoomed?
			m_grads.CalcScale(vm->m_Trace[p].m_pChartDataItem->GetScaleInfo(), &(vm->m_Trace[p].m_convInfo), FLT_MAX,
			FLT_MAX, FLT_MAX);
		}
	}
}
//****************************************************************************
/// Virtual function override of baseObject GetUpdateRect
/// Gets the update rectangle for the CCircularChartObject
///
/// @param[in] pUpdateRect	- pointer to rectangle to set
///	@param[in] time100		- time to use for calculations (100ths sec)
///
/// @return TRUE if update required, FALSE if not
//****************************************************************************
BOOL CCircularChartObject::GetUpdateRect(QRect *pUpdateRect, LONGLONG time100) {
	// If updating we will always be updating the whole object rect
	*pUpdateRect = m_ClientRect;
	if (m_RealtimeMode && (m_LastTimeChangeValue != pSYSTIMER->GetPreTimeChangeProcessTime().GetMicroSecs())) {
		// We have a time change, need to refresh everything
		ConfigChange();
		// Request a redraw 
		return true;
	}
	// Has there been a change of state between realtime and peek view
	if (m_bShowingRealtime != m_RealtimeMode) {
		// Yes, reflect change in mode
		m_RealtimeMode = m_bShowingRealtime;
		// Change config to reflect new state
		ConfigChange();
		// Request a redraw 
		return true;
	}
	// Calculate time since last update
	LONGLONG time100SinceLastUpdate = time100 - m_LastUpdateTime;
	// Have we recently updated the chart
	if (time100SinceLastUpdate < m_pCMMbase->UpdateRate100) {
		// Yes, update not required just yet
		m_UpdateValue = FALSE;
		return m_UpdateValue;
	}
	// Set last update time to current, and proceed to update chart
	m_LastUpdateTime = time100;
	// Update marker for queues loading data in background
	bool fullUpdate = false;
	// Is this realtime?
	if (m_RealtimeMode) {
		// Yes, Have we rolled a chart?
		if (pGlbSysTimer->GetCurrentProcessTimeInMicroSec() > vm->m_ChartEndTime.GetMicroSecs()) {
			// Chart rollover, do a config change to refresh everything
			ConfigChange();
			fullUpdate = true;
		} else {
			// Check any queue's loaded data since last update
			fullUpdate = FullUpdateRequired();
		}
		// Do we need to do a full refresh of the chart
		if (fullUpdate) {
			// Yes cleardown the trace readings
			vm->Clear();
		}
		// Populate view model with any required updates from queues
		int updates = vm->UpdateReadings(pGlbSysTimer->GetCurrentProcessTimeInMicroSec());
		// If we have updated more then 1 reading we will need a complete redraw
		m_FullDraw = (updates > 0);
		// If not a full update then we just do a leading draw of new trace values and messages
		m_LeadingDraw = !m_FullDraw;
	} else {
		// No, We are in peek view, check for updates from queue (loading old data in)
		fullUpdate = FullUpdateRequired();
		// New queue data available?
		if (fullUpdate) {
			// Cleardown current queue data
			vm->Clear();
		}
		// Populate view model with any required updates from queues
		int updates = vm->UpdateReadings(vm->m_ChartEndTime);
		// If we have updateswe will need a complete redraw
		m_FullDraw = (updates > 0);
		// We never do leading draw, it's all historical so only ever full draws required
		m_LeadingDraw = false;
	}
	// Return draw refresh state 
	return m_FullDraw || m_LeadingDraw;
}
//****************************************************************************
/// Check queues to see if there has been any previous data loaded in that
/// is now ready for updating the view model
///
///	@param[in] chartspan- span of the chart
///
/// @return - true if update require, otherwise false
//****************************************************************************
bool CCircularChartObject::FullUpdateRequired() {
	bool retval = false;
	// Check for any outstanding message requests
	if (!vm->m_InitialisedMessages) {
		if (!vm->m_pMessageQ->m_InitialRequest) // if this is Not set, then once all replies are in refresh the screen
		{
			BOOL outstanding = FALSE;
			for (int q = 0; q < NUM_CHART_MESSAGE_Qs; q++) {
				outstanding |= vm->m_pMessageQ->m_RequestInfo[q].m_OutstandingRequest;
			}
			if (!outstanding) {
				vm->m_InitialisedMessages = TRUE;
				retval = true;
			}
		}
	}
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->WaitLock(1);
	// Check for any outstanding Chart queue requests
	for (int p = 0; p < m_enabledChartPens; p++) {
		if (!vm->m_Trace[p].m_Initialised) {
			// not initialised, or being reinitialised
			if (vm->m_Trace[p].m_pChartQ->m_InitialRequest) // is the initial request flagged?
			{
				if (!vm->m_Trace[p].m_pChartQ->m_OutstandingRequest) // not done and not doing it!
				{
					vm->m_Trace[p].m_pChartQ->CheckQueue(0, 0); // make the request again!				
				}
			} else if (!vm->m_Trace[p].m_pChartQ->m_OutstandingRequest) {
				// is done,
				vm->m_Trace[p].m_Initialised = TRUE;
				retval = true;
			}
		}
	}
	CM->Unlock();
	return retval;
}
//****************************************************************************
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] not_used		- Handle to Device Context (will be NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CCircularChartObject::OnDraw(CCircularChartObject *pThis, HDC not_used, QRect *pClipRect) {
	//Get the pointer to OpPanel.
	COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
	HDC sdc;
	pThis->m_pDDSurf->GetDC(&sdc);
	// Is this a full draw
	if (pThis->m_FullDraw) {
		// Yes, draw everything from the view model
		// Draw the background rect
		if (pThis->m_pCMMbase->Border.BorderUsed && pClipRect) {
			DrawBorder(sdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
		}
		// Draw the blank chart paper
		pThis->DrawBlankChart(sdc);
		// Draw the time graduations
		pThis->DrawTimeGrads(sdc, 0, pThis->vm->m_NumReadings);
		// Draw the scales
		for (int i = 0; i < MAX_CIRCI_SCALES; i++) {
			pThis->m_Scale[i].Draw(sdc, pClipRect);
		}
		// Redraw centre circle as can get overwritten by grads
		pThis->DrawCircle(sdc, pThis->vm->m_holeRadius, CIRCI_DIVIDER_COL, CIRCI_HOLE_FILL_COL);
		// Draw Messages
		pThis->DrawMessages(sdc, 0, pThis->vm->m_lastReadingIx + 1);
		// Draw traces
		pThis->DrawTraces(sdc, 0, pThis->vm->m_lastReadingIx + 1);
	} else if (pThis->m_LeadingDraw) {
		// Leading draw so only update trace reading and new messages 
		// Draw latest messages
		pThis->DrawMessages(sdc, pThis->vm->m_lastReadingIx, pThis->vm->m_lastReadingIx + 1);
		// Draw latest trace point
		pThis->DrawTraces(sdc, pThis->vm->m_lastReadingIx, pThis->vm->m_lastReadingIx + 1);
	}
	// Release the DC
	pThis->m_pDDSurf->ReleaseDC(sdc);
	// Not using these, but set then for housekeeping.
	pThis->m_UpdateValue = FALSE;
	pThis->m_UpdateRequired = FALSE;
	return;
}
//****************************************************************************
/// Helper to validate start and end index positions for partial draws
///	
/// @param[out] startPosition	- Start position, validated
/// @param[out] endPosition		- End position, validated
///
/// @return none
//****************************************************************************
void CCircularChartObject::ValidatePositions(int &startPosition, int &endPosition) {
	// Check start position limits
	if (startPosition < 0 || startPosition >= vm->m_NumReadings) {
		// Outside limits, set to start
		startPosition = 0;
	}
	if (endPosition < 1 || endPosition > vm->m_NumReadings) {
		// Outside limits, set to end
		endPosition = vm->m_NumReadings;
	}
}
//****************************************************************************
/// Draw all traces between start and end position indexes
///	
/// @param[in] sdc				- Handle to Device Context to draw to (a surface DC)
/// @param[in] startPosition	- Start position in reading index on current vm
/// @param[in] endPosition		- End position in reading index on current vm
///
/// @return none
//****************************************************************************
void CCircularChartObject::DrawTraces(HDC sdc, int startPosition, int endPosition) {
	// Validate positions limits
	ValidatePositions(startPosition, endPosition);
	// Run through all enabled traces
	for (int t = 0; t < vm->m_EnabledTraces; t++) {
		CirciTrace *pTrace = vm->GetTrace(t);
		// Trace inititalised?
		if (pTrace->m_Initialised) {
			// Yes, create pen and brush for drawing
			QPen hPen = NULL;
			HBRUSH hBrush = NULL;
			HGDIOBJ hPenOld, hBrushOld;
			// Create Pen
			hPen = ::CreatePen(PS_SOLID, 1, pTrace->m_pChartDataItem->GetLineInfo()->Colour);
			hPenOld = SelectObject(sdc, hPen);
			// Create a solid filled brush
			hBrush = CreateSolidBrush(pTrace->m_pChartDataItem->GetLineInfo()->Colour);
			hBrushOld = SelectObject(sdc, hBrush);
			// Run through all trace positions that need to be drawn
			for (int i = startPosition; i < endPosition; i++) {
				// Does this position have a reading?
				if (pTrace->m_Buf[i].Status != CRS_NO_READING) {
					// Yes, is this a reversed scale?
					if (pTrace->m_convInfo.SourceScaleReversed()) {
						// Yes, Draw trace element for reversed scales
						DrawTraceElement(sdc, vm->m_DegreesPerReading * i, vm->m_DegreesPerReading * (i + 1),
								(int) pTrace->m_convInfo.CalcSourceToDest(pTrace->m_Buf[i].Max),
								(int) pTrace->m_convInfo.CalcSourceToDest(pTrace->m_Buf[i].Min));
					} else {
						// No, Draw trace element for normal scales
						DrawTraceElement(sdc, vm->m_DegreesPerReading * i, vm->m_DegreesPerReading * (i + 1),
								(int) pTrace->m_convInfo.CalcSourceToDest(pTrace->m_Buf[i].Min),
								(int) pTrace->m_convInfo.CalcSourceToDest(pTrace->m_Buf[i].Max));
					}
				}
			}
			// Delselect and cleanup Pen
			SelectObject(sdc, hPenOld);
			DeleteObject(hPen);
			//De-Select and cleanup brush
			SelectObject(sdc, hBrushOld);
			DeleteObject(hBrush);
		}
	}
}
//****************************************************************************
/// Draw all messages between start and end position indexes
///	
/// @param[in] sdc				- Handle to Device Context to draw to (a surface DC)
/// @param[in] startPosition	- Start position in reading index on current vm
/// @param[in] endPosition		- End position in reading index on current vm
///
/// @return none
//****************************************************************************
void CCircularChartObject::DrawMessages(HDC sdc, int startPosition, int endPosition) {
	// Validate positions limits
	ValidatePositions(startPosition, endPosition);
	// Run through all message positions that need to be drawn
	for (int i = startPosition; i < endPosition; i++) {
		// Is there a message marking at this point?
		if (vm->m_CtlBuf[i].Message > 0) {
			// Yes, non-zero so draw message marker
			DrawMessageMark(sdc, i);
		}
	}
}
//****************************************************************************
/// Draw all time graduations between start and end position indexes
///	
/// @param[in] sdc				- Handle to Device Context to draw to (a surface DC)
/// @param[in] startPosition	- Start position in reading index on current vm
/// @param[in] endPosition		- End position in reading index on current vm
///
/// @return none
//****************************************************************************
void CCircularChartObject::DrawTimeGrads(HDC sdc, int startPosition, int endPosition) {
	// Validate positions limits
	ValidatePositions(startPosition, endPosition);
	// Create and select in the pen to draw grads
	QPen hPen = NULL;
	HGDIOBJ hPenOld;
	hPen = ::CreatePen(PS_SOLID, 1, CIRCI_MAJOR_GRAD_COL);
	hPenOld = SelectObject(sdc, hPen);
	// Draw the time graduations that fall between these points
	for (int i = startPosition; i < endPosition; i++) {
		// Is there a graduation at this point?
		if (vm->m_CtlBuf[i].TimeGrad != 0) {
			// yes, draw the grauation
			DrawFromTimeGradEntry(sdc, vm->m_CtlBuf[i].TimeGrad);
		}
	}
	// Select original Pen
	SelectObject(sdc, hPenOld);
	DeleteObject(hPen);
}
//****************************************************************************
/// Draw a time graduation line from an time grad entry
///	
/// @param[in] sdc				- Handle to Device Context to draw to (a surface DC)
/// @param[in] timeGradIndex	- Index to CIRCI_TIMEGRADS in curently select vm
///
/// @return none
//****************************************************************************
void CCircularChartObject::DrawFromTimeGradEntry(HDC sdc, int timeGradIndex) {
	// Get the time grad instance
	CIRCI_TIMEGRADS *pTimeGrad = vm->GetTimeGrad(timeGradIndex);
	// Drawing changes based on grad type
	switch (pTimeGrad->Type) {
	case CTT_MAJOR: {
		// Draw Major division and timestamp 
		DrawSegmentingLine(sdc, pTimeGrad->PositionInDegrees, CIRCI_MAJOR_GRAD_COL, 2);
		DrawCirciTimeStamp(sdc, pTimeGrad);
		break;
	}
	case CTT_MINOR: {
		// Draw Minor division
		DrawSegmentingLine(sdc, pTimeGrad->PositionInDegrees, CIRCI_MINOR_GRAD_COL, 1);
		break;
	}
	case CTT_SUB_MINOR: {
		// Draw Sub minor
		DrawSegmentingLine(sdc, pTimeGrad->PositionInDegrees, CIRCI_SUB_MINOR_GRAD_COL, 1);
		break;
	}
	default: {
		qDebug("CIRCI ERROR: Drawing Time Grad for an invalid grad, index %d", timeGradIndex);
		break;
	}
	}
}
//****************************************************************************
/// Draw a circi timestamp, code taken from strip chart 
///	
/// @param[in] sdc			- Handle to Device Context to draw to (a surface DC)
/// @param[in] pTimeGrad	- ptr to TimeGrad to draw timestamp
///
/// @return none
//****************************************************************************
void CCircularChartObject::DrawCirciTimeStamp(HDC sdc, CIRCI_TIMEGRADS *pTimeGrad) {
	// Get correct font
	CFontCache *pfc = CFontCache::GetHandle();
	QFont hfont, hOldfont;
	if (!pDALGLB->IsRecorderMini() && (m_TSfontHeight > SVGA_PLUS_TIMESTAMP_FONT_HEIGHT)) {
		hfont = pfc->GetFont(m_TSfontHeight, QFont::Bold, 3, ANTIALIASED_QUALITY);
	} else {
		hfont = pfc->GetFont(m_TSfontHeight, QFont::Normal, 3, DEFAULT_QUALITY);
	}
	hOldfont = (QFont) SelectObject(sdc, hfont);
	// Setup the colour and drawing mode
	SetTextColor(sdc, CIRCI_TS_COL);
	SetBkMode(sdc, TRANSPARENT);
	// asprintf the timestamp into time and date
	WCHAR dateStr[20];
	WCHAR timeStr[20];
	TimeToString(&pTimeGrad->TimeStamp, dateStr, timeStr);
	// Get the point within around the circle of the centre of the timestamp
	int halfWidth = _Width(m_TSrect) / 2;
	int halfHeight = _Height(m_TSrect) / 2;
	int tsCentreX, tsCentreY;
vm->GetCoordsFromHeightAndDegrees(pTimeGrad->PositionInDegrees, vm->m_radius-halfWidth, tsCentreX, tsCentreY, false );
// D D
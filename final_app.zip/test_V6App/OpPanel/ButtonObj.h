/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: TextObj.h
/// @n Description: Text Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:55:47 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:25:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 9/23/2008 3:09:20 PM  Build Machine 
//  AMS2750 Merge
//  1 V6 Firmware 1.0 5/24/2006 8:59:59 PM  Jason Parker  
// $
//
// **************************************************************************
#ifndef _BUTTONOBJ_H
#define _BUTTONOBJ_H
#define WINDOWS_STYLE 0
#include "AMS2750TimerCtrlMgr.h"
//**Class*********************************************************************
///
/// @brief Text Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used to show Text in a Widget in OpPanel
///
//****************************************************************************
class CButtonObject: public CBaseObject {
private:
	CDataItemRef *m_pDataItemRef;	///< data item table reference
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CButtonObject *pThis, HDC hdc, QRect *pClipRect);
#ifndef DOCVIEW	
	// Method that obtains the required background colour for an AMS2750 timer
	static const COLORREF SetTimerBtnCol(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO);
#endif
	BOOL m_DrawButtonDown;
	BOOL m_ButtonIsDown;
	// Colours used for illustrating the various button conditions
	static const COLORREF ms_crOK;
	static const COLORREF ms_crWarning;
	static const COLORREF ms_crError;
	static const COLORREF ms_crInactive;
public:
// make this private when done testing
	T_BUTTONOBJECT *m_pCMMbutton;		///< pointer to our CMM configuration
	int m_ButtonID;
	CButtonObject(CWidget *pWidget);
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
	// Method that returns a pointer to an internal string that is a copy of the text string held in
	// the CMM
	QString  GetTextString();
	void SetTextString(QString pText);
	void OnMouseDown(UINT nFlags, QPoint &p);	///< Mouse button down (or touch screen touched) at point
	void OnMouseUp(UINT nFlags, QPoint &p);		///< Mouse button up (or touchscreen)
	void OnMouseMove(UINT nFlags, QPoint &p);	///< Dragging on screen with mouse or touchscreen
};
#endif

#ifndef _OPPANELINCLUDES_H
#define _OPPANELINCLUDES_H
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "TraceDefines.h"
#include "CMMDefines.h"
#include "V6defines.h"
#include "V6Config.h"
#include "TVtime.h"
#include "FFConversionInfo.h"
#include "Utilities.h"
#include "DataItemManager.h"
#include "LayoutItem.h"
#include "BaseObject.h"
#include "Widget.h"
#include "Template.h"
#include "Screen.h"
#include "LayoutConfiguration.h"
#include "exampleBar.h"
#include "BarObject.h"
#include "DigitalObj.h"
#include "TextObj.h"
#include "ScaleObject.h"
#include "PenPointersObject.h"
#include "AlarmMarkerObject.h"
#include "BasicMaxMinAve.h"
#include "QMDataBlock.h"
#include "QueueManager.h"
#include "ChartQueues.h"
#include "ChartObject.h"
#include "CircularChartObject.h"
#include "CursorObj.h"
#include "ButtonObj.h"
#include "BitmapObj.h"
#include "TabularDisplayObject.h"
#include "TUSObject.h"
//#ifdef TESTBUILD
//#include "testdialog.h" // for test build only
//#else
#include "ControlSequencer.h" // v6 desktop build
//#endif
#ifdef DOCVIEW
#include "oppaneldvdoc.h"
#endif
#include "V6ActiveModule.h"
#include "OpPanel.h"
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: PenPointersObject.cpp
/// @n Description: Pen Pointers Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  64  Stability Project 1.59.1.3 7/2/2011 4:59:40 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  63  Stability Project 1.59.1.2 7/1/2011 4:38:37 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  62  Stability Project 1.59.1.1 3/17/2011 3:20:33 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  61  Stability Project 1.59.1.0 2/15/2011 3:03:40 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include <float.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CPenPointersObject::CPenPointersObject(CWidget *pWidget) : CBaseObject(pWidget) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CPenPointersObject::OnDraw;
	// set all of the object's internal settings to defaults
	m_uTestCase = 0;
	m_bInZoom = FALSE;
	m_fZoomZero = 0.0;
	m_fZoomSpan = 100.0;
	m_nPrevHeight = 0;
	m_bInAlarm = FALSE;
	m_pFlashing = &m_bInAlarm;
	m_RotateSources = FALSE;
	m_nLastLane = 0;	//MarkD
	m_llPreviousLaneToggle = pGlbSysTimer->GetCurrentSystemTimeTick100();
	m_nFirstAlarm = 0;
	m_nAlarmsActive = 0;
	for (int nLane = 0; nLane < MAX_PEN_POINTERS; nLane++) {
		m_pDataItemRef[nLane] = NULL;
		m_fCurrentValue[nLane] = 0.0;
		m_bCurrentAlarm[nLane] = FALSE;
		m_eCurrentStatus[nLane] = DISTAT_NORMAL;
	}
}
//****************************************************************************
///
/// Overridable function to convert from limits of object (bounds) to scale
/// positions. Returns FALSE if can't be done.
///
///	@param [in] lim1	- top or left of Object bounds
/// @param [in] lim2	- bottom or right of Object bounds 
/// @param [out] pPos1	- link position 1 (top or left of scale)
/// @param [out] pPos2	- link position 2 (bottom or right of scale)
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CPenPointersObject::CalcLinkPositions(int &lim1, int &lim2, int *pPos1, int *pPos2) {
	// Save away on the stack the member variables that can be updated
	// by the Recalculate method. The CalcLinkPositions method should
	// be considered "const" method: doesn't update pen pointers object.
	BYTE SaveBuffer[250];
	if (SavePenPointersObjectState(SaveBuffer, sizeof(SaveBuffer))) {
		// Call SetBounds with a rectangle derived from the passed in limits 1
		// (top or left) and 2 (bottom or right) and the other dimension of the
		// pen pointers object's current bounds.
		QRect rcBounds;
		if (m_pCMMpens->Orientation == OBJECT_HORIZONTAL)
			rcBounds.SetRect(lim1, top(), lim2, bottom());
		else
			rcBounds.SetRect(left(), lim1, right(), lim2);
		SetBounds(rcBounds);
		// Return as link positions 1 (top or left of scale) and 2 (bottom or right
		// of scale) the values based on the scale indent value that was computed by
		// the Recalculate method.
		int nBorderWidth = 0;
		if (m_pCMMbase->Border.BorderUsed)
			nBorderWidth = m_pCMMbase->Border.BorderWidth;
		*pPos1 = lim1 + m_pCMMpens->ScaleIndent + nBorderWidth;
		*pPos2 = lim2 - 1 - m_pCMMpens->ScaleIndent - nBorderWidth;
		RestorePenPointersObjectState();
	}
	return TRUE;
}
//****************************************************************************
///
/// Check if the Object can be resized so that the scale positions are pos1 
/// and pos2. Object must return the new bounds required to do this in 
/// pLim1 and pLim2
///
/// @param [in] pos1	- link position to match (top or left of scale)
/// @param [in] pos2	- link position to match (bottom or right of scale)
///	@param [out] pLim1	- top or left of Object bounds
/// @param [out] pLim2	- bottom or right of Object bounds 
///
/// @return TRUE/FALSE 
/// 
//****************************************************************************	
BOOL CPenPointersObject::CanSetLinkPositions(int pos1, int pos2, int *pLim1, int *pLim2) {
	BOOL bRet; // return result
	BOOL bHoriz = m_pCMMpens->Orientation == OBJECT_HORIZONTAL;
	// Save away on the stack the member variables that can be updated
	// by the Recalculate method. The CanSetLinkPositions method should
	// be considered "const" method: doesn't update pen pointers object.
	BYTE SaveBuffer[250];
	if (bRet = SavePenPointersObjectState(SaveBuffer, sizeof(SaveBuffer))) {
		// Call SetBounds with a rectangle derived from the passed in positions 1
		// (top or left) and 2 (bottom or right) and the other dimension of the
		// pen pointers object's current bounds.
		QRect rcBounds;
		if (m_pCMMpens->Orientation == OBJECT_HORIZONTAL)
			rcBounds.SetRect(pos1, top(), pos2 + 1, bottom());
		else
			rcBounds.SetRect(left(), pos1, right(), pos2 + 1);
		SetBounds(rcBounds);
		// Return as the limits 1 (top or left of object bounds) and 2 (bottom or
		// right of object bounds) the values based on what we calculated for the
		// scale indent. Prevent the zero and span of the pen pointers object from
		// going into any border area that the pen pointers object has.
		int nBorderWidth = 0;
		if (m_pCMMbase->Border.BorderUsed)
			nBorderWidth = m_pCMMbase->Border.BorderWidth;
		*pLim1 = pos1 - m_pCMMpens->ScaleIndent - nBorderWidth;
		*pLim2 = pos2 + 1 + m_pCMMpens->ScaleIndent + nBorderWidth;
		QRect rcWidget = m_pWidget->m_WidgetClientRect;
		if (bHoriz)
			bRet = *pLim1 >= rcWidget.left && *pLim2 <= rcWidget.right;
		else
			bRet = *pLim1 >= rcWidget.top && *pLim2 <= rcWidget.bottom;
		RestorePenPointersObjectState();
	}
	return bRet;
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Required size and position for a new Object
///
/// @return none
/// 
//****************************************************************************
void CPenPointersObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CPenPointersObject data in CMM info block.
	m_pCMMpens = (T_PENPTRSOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		// set these flags for specific Object (e.g. may be advanced draw only)
		/*
		 m_pCMMbase->IsAdvancedDraw
		 m_pCMMbase->IsPermanent
		 m_pCMMbase->IsBackground
		 m_pCMMbase->IsPrimaryDirect
		 // etc...
		 */
		m_pCMMbase->IsBuffered = TRUE;
		m_pCMMbase->UpdateRate100 = 20; // faster redraw update (to match chart)
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
		m_nPrevHeight = m_pCMMpens->Height;
	}
	ConfigChange();
}
//****************************************************************************
///
/// compare function to pass to qsort in RecalculatePenPointerLanes to sort
/// the data item references by pen number. The arguments arg1 and arg2 point
/// to a CDataItemRef pointer each, which represent the two pens to compare.
///
/// @param[in] arg1	- Pointer to first data item reference pointer
/// @param[in] arg2	- Pointer to second data item reference pointer
///
/// @return <0 for Pen1<Pen2; ==0 for Pen1==Pen2 or >0 for Pen1>Pen2
/// 
//****************************************************************************
int CPenPointersObject::CompareDataItemRefs(const void *arg1, const void *arg2) {
	CDataItemRef **pPen1 = (CDataItemRef**) arg1;
	CDataItemRef **pPen2 = (CDataItemRef**) arg2;
	return GetPenNumber(*pPen1) - GetPenNumber(*pPen2);
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CPenPointersObject::ConfigChange() {
	// Data item configuration done here. 
	T_CHANNELREF channelInfo;
	channelInfo.Enabled = TRUE;
	channelInfo.Updates = TRUE;
	channelInfo.Rotate = 1; // always set here, if set for the widget will rotate.
	channelInfo.ItemType = DI_PEN;
	channelInfo.SubType = 0;
	int nIndex = 0;
	// Loop over the pen channels in the widget and maintain in the widget
	// data item references for those pens that are enabled. Remove from the
	// widget any data item references for disabled pens. After the loop we
	// we will thus have an array of size MAX_PEN_POINTERS of data item
	// reference pointers. We will move all non-NULL pointers up in the array.
	USHORT usMaxChartPens = GetMaxChartPens();
	m_RotateSources = m_pWidget->m_pCMMwidget->RotateChannels; // set this here form Widget
	if (m_RotateSources)
		usMaxChartPens = 1; // only use one dataitemRef if rotating. (will be different pen as it rotates)
	for (nIndex = 0; nIndex < usMaxChartPens; nIndex++) {
		if (nIndex < m_pWidget->m_pCMMwidget->NumChannels) {
			if (!m_pDataItemRef[nIndex])
				m_pDataItemRef[nIndex] = new CDataItemRef(this); // create our pen reference
			if (m_pDataItemRef[nIndex]) {
				channelInfo.IndexChan = nIndex; // use widget's channel index
				m_pWidget->GetDataItem(m_pDataItemRef[nIndex], &channelInfo);
				if (!m_pDataItemRef[nIndex]->m_pDataItem->IsEnabled()) // is the data item actually enabled?
				{
					// delete it now as we don't want this to continually get added to the widget link list
					// thus causing a gradual decline in memory
					m_pWidget->DeleteDataItem(m_pDataItemRef[nIndex]);
					m_pDataItemRef[nIndex] = NULL;
				}
			}
		} else {
			if (m_pDataItemRef[nIndex]) // already configured this reference?
			{
				// delete it now as we don't want this to continually get added to the widget link list
				// thus causing a gradual decline in memory
				m_pWidget->DeleteDataItem(m_pDataItemRef[nIndex]);
				m_pDataItemRef[nIndex] = NULL;
			}
		}
	}
	// Determine the number of enabled pen channels (m_nNumPens) in the widget. Move all the
	// enabled data item references to be at m_pDataItemRef[0] to m_pDataItemRef[m_nNumPens-1]
	// so that the rest of the code doesn't have to worry about testing for NULL data item refs.
	m_nNumPens = 0;
	for (nIndex = 0; (nIndex < m_pWidget->m_pCMMwidget->NumChannels) && (nIndex < usMaxChartPens); nIndex++)
		if (m_pDataItemRef[nIndex]) // have an enabled pen reference
		{
			if (m_nNumPens != nIndex) {
				m_pDataItemRef[m_nNumPens] = m_pDataItemRef[nIndex];
				m_pDataItemRef[nIndex] = NULL;
			}
			m_nNumPens++;
		}
	// Set our members based on CMM settings and data item info
	//MarkD: restart pen pointer rotations
	m_nLastLane = 0;
	// T_BASEOBJECT CMM config to CBaseObject members:
	if (m_pCMMbase->FixForeColour)
		// Use foreground colour from CMM (e.g. as selected in Screen Designer).
		m_pForeColour = &m_pCMMbase->ForeColour;
	else if (m_pCMMbase->AttrBlocks.ForeColourBlk)
		// Use foreground colour from Attribute block.
		m_pForeColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
	if (m_pCMMbase->FixBackColour)
		// Use background colour from CMM (e.g. as selected in Screen Designer).
		m_pBackColour = &m_pCMMbase->BackColour;
	else if (m_pCMMbase->AttrBlocks.BackColourBlk)
		// Use background colour from Attribute block.
		m_pBackColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
	// Use visible attribute from Attribute block if set (1=default=TRUE).
	m_pVisible = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
	// T_PENPTRSOBJECT CMM config to CPenPointersObject members:
	if (m_pCMMpens->FlshFGonAlarm)
		if (m_pCMMpens->FixFGAlarmCol)
			m_pForeAlarmColour = &m_pCMMpens->FGAlarmCol;
		else
			m_pForeAlarmColour =
					&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_ALARM_OVERVIEW)->FGCol;
	else
		m_pForeAlarmColour = NULL; // not used
	SetBounds(&GetBounds()); // sets up the m_ClientRect etc.
	// set up the initial (current) status and value for the pens
	m_bInAlarm = FALSE;
	for (int nLane = 0; nLane < m_nNumPens; nLane++) {
		m_eCurrentStatus[nLane] = m_pDataItemRef[nLane]->m_pDataItem->GetStatus();
		m_fCurrentValue[nLane] = m_pDataItemRef[nLane]->m_pDataItem->GetFPValue();
		if (m_bCurrentAlarm[nLane] = m_pDataItemRef[nLane]->m_pDataItem->GetAlarmStatus() > 0)
			m_bInAlarm = TRUE;
	}
	m_nPrevHeight = m_pCMMpens->Height;
}
int CPenPointersObject::GetPenNumber(CDataItemRef *pDataItemRef) {
	CDataItemPen *pDataItemPen = (CDataItemPen*) pDataItemRef->m_pDataItem;
	return pDataItemPen->m_pPenConfig->Instance;
}
void CPenPointersObject::SetRotating() {
	m_RotateSources = TRUE;
}
int CPenPointersObject::GetPenNumber(int nLane) {
	return GetPenNumber(m_pDataItemRef[nLane]);
}
void CPenPointersObject::Recalculate() {
	RecalculateScaleLimits();
	RecalculatePenPointerLanes();
}
void CPenPointersObject::RecalculatePenPointerLanes() {
	BOOL bHoriz = m_pCMMpens->Orientation == OBJECT_HORIZONTAL;
	// "VALID READING" LANE OFFSET COMPUTATION:
	// Make each lane of maximum size. If the orientation of the pen pointers
	// object is vertical, for example, then we want the tip of the first pen
	// pointer to touch the left side of the client rectangle and we want the
	// tail of the last pen pointer to touch the right side of the client
	// rectangle. We thus want to divide the space between the tip of the first
	// pen pointer and the tip of the last pen pointer by the number of pen
	// pointers minus one (the number of lanes before the last pen pointer).
	// "OUT-OF-RANGE" LANE OFFSET COMPUTATION:
	// Make each lane of maximum size. If the orientation of the pen pointers
	// object is vertical, for example, then we want the left edge of the first
	// pen pointer to touch the left side of the client rectangle and we want
	// the right edge of the last pen pointer to touch the right side of the
	// client rectangle. We thus want to divide the space between the left edge
	// of the first pen pointer and the left edge of the last pen pointer by the
	// number of pen pointers minus one (the number of lanes before the last pen
	// pointer).
	if (m_nNumPens < 2) // protect against divide by zero below
			{
		m_nValidReadingLaneOffset = 0;
		m_nOutOfRangeLaneOffset = 0;
	} else {
		if (bHoriz) {
			m_nValidReadingLaneOffset = (_Height(m_ClientRect) - m_nPenHeight) / (m_nNumPens - 1);
			m_nOutOfRangeLaneOffset = (_Height(m_ClientRect) - m_nPenWidth) / (m_nNumPens - 1);
		} else {
			m_nValidReadingLaneOffset = (_Width(m_ClientRect) - m_nPenWidth) / (m_nNumPens - 1);
			m_nOutOfRangeLaneOffset = (_Width(m_ClientRect) - m_nPenHeight) / (m_nNumPens - 1);
		}
		if (m_nValidReadingLaneOffset < 0)
			m_nValidReadingLaneOffset = 0;
		if (m_nOutOfRangeLaneOffset < 0)
			m_nOutOfRangeLaneOffset = 0;
	}
	// Sort the data item references by pen number so pens in lanes will be sorted.
	qsort(m_pDataItemRef, m_nNumPens, sizeof(m_pDataItemRef[0]), CompareDataItemRefs);
	// Set up information for EU (linear) or power of 10 (log) to pixel conversion.
	// Note that each pen pointer has its own scale, so we need to set up conversion
	// information for each pen pointer.
	for (int nLane = 0; nLane < m_nNumPens; nLane++)
		m_ci[nLane].CalcFConvInfo(GetZero(nLane), GetSpan(nLane),
				bHoriz ?
						(float) m_ClientRect.left + m_pCMMpens->ScaleIndent :
						(float) m_ClientRect.bottom - 1 - m_pCMMpens->ScaleIndent,
				bHoriz ?
						(float) m_ClientRect.right - 1 - m_pCMMpens->ScaleIndent :
						(float) m_ClientRect.top + m_pCMMpens->ScaleIndent);
}
void CPenPointersObject::RecalculateScaleLimits() {
	BOOL bHoriz = m_pCMMpens->Orientation == OBJECT_HORIZONTAL;
	// Force scale indent change on Height property change.
	if (m_pCMMpens->Height != m_nPrevHeight)
		m_pCMMpens->ScaleIndent = 0;
	if (m_pCMMpens->ScaleIndent == 0) // scale indent NOT set up
			{
		// Compute the zero and span indent to be half the height or width of the pen
		// pointer size so that if a pen pointer is at zero or span, it will still be
		// within the client rectangle of the pen pointers object. indexOf the largest
		// numeric font height whose symbol height is no more than the required pen
		// pointer height.
		// OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!! OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!!
		// OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!! OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!!
		// OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!! OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!!
		m_nPenFontHeight = 0;
		for (int nPenFontHeight = 1; nPenFontHeight < MAX_EUDC_FONT_SIZE; nPenFontHeight++)
			if (COpPanel::m_EUDC[nPenFontHeight].nSymbolHeight <= m_pCMMpens->Height)
				m_nPenFontHeight = nPenFontHeight;
		if (bHoriz)
			m_pCMMpens->ScaleIndent = (int) ceil((COpPanel::m_EUDC[m_nPenFontHeight].nCellWidth * 42 / 64) / 2.0);
		else
			m_pCMMpens->ScaleIndent = (int) ceil((COpPanel::m_EUDC[m_nPenFontHeight].nSymbolHeight * 42 / 64) / 2.0);
	} else {
		// Scale indent already set up. indexOf largest pen font height such that
		// no more than half the pen pointer symbol height or width extends past
		// the scale indent.
		// OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!! OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!!
		// OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!! OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!!
		// OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!! OPTIMISE BELOW WITH BINARY SEARCH INSTEAD!!!
		m_nPenFontHeight = 0;
		for (int nPenFontHeight = 1; nPenFontHeight < MAX_EUDC_FONT_SIZE; nPenFontHeight++)
			if (bHoriz) {
				if ((int) ceil((COpPanel::m_EUDC[nPenFontHeight].nCellWidth * 42 / 64) / 2.0)
						<= m_pCMMpens->ScaleIndent)
					m_nPenFontHeight = nPenFontHeight;
			} else {
				if ((int) ceil((COpPanel::m_EUDC[nPenFontHeight].nSymbolHeight * 42 / 64) / 2.0)
						<= m_pCMMpens->ScaleIndent)
					m_nPenFontHeight = nPenFontHeight;
			}
	}
	//Aditya : Increased the font for pen pointer 1-1N97IIP
	//PSR - 1-2KZJUXO - Not required here because this has been handled through screen.cpp by applying resolution factor
	//So Removed the resfactor here to PenPointerFontHeight
	m_nCharCellHeight = COpPanel::m_EUDC[m_nPenFontHeight].nCellHeight;
	m_nCharCellWidth = COpPanel::m_EUDC[m_nPenFontHeight].nCellWidth;
	if (bHoriz) {
		m_nPenHeight = COpPanel::m_EUDC[m_nPenFontHeight].nSymbolHeight;
		m_nPenWidth = m_nCharCellWidth * 42 / 64;
		m_ptArrowTip.x = m_nCharCellWidth / 2;
		m_ptArrowTip.y = COpPanel::m_EUDC[m_nPenFontHeight].nAboveHeight + m_nPenHeight; // add in whitespace above the EUDC symbol
	} else {
		m_nPenHeight = COpPanel::m_EUDC[m_nPenFontHeight].nSymbolHeight * 42 / 64;
		m_nPenWidth = m_nCharCellWidth;
		m_ptArrowTip.x = 0;
		m_ptArrowTip.y = COpPanel::m_EUDC[m_nPenFontHeight].nAboveHeight
				+ COpPanel::m_EUDC[m_nPenFontHeight].nSymbolHeight / 2; // add in whitespace above the EUDC symbol
	}
}
//****************************************************************************
///
/// Drawing function. 
/// This function does all of the drawing for the Object.
/// Standard Objects will have a valid HDC passed and should draw all output 
/// to it. Advanced Objects will have a NULL HDC passed and will draw their 
/// output directly to the relavent surface. 
/// The ClipRect pointer can either be valid (indicating a WM_PAINT situation)
/// or NULL indicating the draw is the result of a data/flash update 
/// (m_UpdateRequired is TRUE) or that it overlaps another Object that is 
/// updating. 
/// When the ClipRect pointer is valid:
/// the function must draw *at least* the area specified. The clipping 
/// rectangle will be the intersection of the Objects bounds with the HDC's 
/// clipping region. The HDC's clipping region will normally be larger than the
/// bounds of the object (e.g. a full screen draw it will be the Widget) So it 
/// can not be used to 'contain' drawing within the Object Bounds. If the HDC's
/// clipping region is changed in this function, it must be restored before 
/// returning. If the clipping region is smaller than the Object Bounds any 
/// drawing done outside of it will not be visible, but usually it is easier 
/// (and quicker) to draw everything for the Object rather than work out those 
/// parts actually required.
///
/// When the ClipRect pointer is NULL:
/// If m_UpdateRequired is set the Object must be updated and fully redrawn 
/// (can be optimised for unbufferd Objects - see below). 
/// if m_UpdateRequired is not set the Object can inspect the Widgets 
/// m_UpdateRgn to see if an optimised draw is possible. At least part of the
/// Object will be contained in the region for the draw function to have been 
/// called, though it may be faster to simply draw everything.
///
///
/// @param[in] pThis		- pointer to 'this' object
/// @param[in] hdc			- Handle to Device Context to use (or NULL)
/// @param[in] pClipRect	- pointer to minimum rectangle requiring updating
///							 OR NULL indicating Full draw required
/// @return none
/// 
//****************************************************************************
void CPenPointersObject::OnDraw(CPenPointersObject *pThis, HDC hdc, QRect *pClipRect) {
	if (!pThis->m_pVisible)
		return; // draw nothing.	
	// if Update Required make any updates due to data item changes/flashing then do a repaint
	if (pThis->m_UpdateRequired) {
		// Get latest values from Data Item Table	
		// NB: these should always be copied to members within the Object.
		if (pThis->m_UpdateValue) {
			// Cache current values and alarm status.
			pThis->m_bInAlarm = FALSE;
			for (int nLane = 0; nLane < pThis->m_nNumPens; nLane++) {
				pThis->m_eCurrentStatus[nLane] = pThis->m_pDataItemRef[nLane]->m_pDataItem->GetStatus();
				pThis->m_fCurrentValue[nLane] = pThis->m_pDataItemRef[nLane]->m_pDataItem->GetFPValue();
				if (pThis->m_bCurrentAlarm[nLane] = pThis->m_pDataItemRef[nLane]->m_pDataItem->GetAlarmStatus() > 0)
					pThis->m_bInAlarm = TRUE;
			}
			pThis->m_UpdateValue = FALSE;
		}
		// also handle any flashing updates here
		if (pThis->m_UpdateFlash) {
			pThis->m_FlashState = !pThis->m_FlashState; // toggle the flash state.			
			pThis->m_UpdateFlash = FALSE;
		}
		pThis->m_UpdateRequired = FALSE;
	}
	BOOL DrawInFlashState = FALSE;
	if (*(pThis->m_pFlashing)) // if we are flashing set our drawInFlashState.
		DrawInFlashState = pThis->m_FlashState;
	// Draw border if required.
	if (pThis->m_pCMMbase->Border.BorderUsed && (pClipRect || pThis->m_pCMMbase->IsBuffered))
		DrawBorder(hdc, pThis->GetBounds(), &pThis->m_pCMMbase->Border);
	// Update the current clipping region. This handling will prevent
	// anything from being drawn outside the pen pointers object.
	pThis->m_pWidget->SetClipRect(hdc, &pThis->m_ClientRect);
	CDC *pDC = CDC::FromHandle(hdc);
	int nOldBkMode = pDC->GetBkMode();
	int nOldBkColour = pDC->GetBkColor();
	COLORREF crOldTextColour = pDC->GetTextColor();
	if (!pThis->m_pCMMbase->IsTransparent) {
		// Create a brush for background
		HBRUSH hBrushback = CreateSolidBrush(*pThis->m_pBackColour);
		FillRect(hdc, &pThis->m_ClientRect, hBrushback);
		// Delete the brush object and free all resources associated with it.
		DeleteObject(hBrushback);
	}
	// Get the font for the required pen pointer size.
	CFontCache *pfc = CFontCache::GetHandle();
	int yoffset = 0;
	QFont hfont = pfc->GetNumericFont(pThis->m_nPenFontHeight, &yoffset);
	QFont hOldfont = (QFont) pDC->SelectObject(hfont);
	// Draw the pen pointers not in alarm first and then draw
	// the pen pointers in alarm last so that the pen pointers
	// in alarm will be on top of all others.
	int nLane = 0;
	//MarkD: rotate which pointer is the last drawn
	// but don't increment every time, otherwise the change looks like an alarm flash
	// we should probably bite the bullet and do a call to a timer, setting the flash rate
	// to be a minimum that way (doesn't set maximum, as with no alarms, this routine may notbe called
	// very often - but at least the toggle would occur on every entry in this case)
	LONGLONG timeNow = pGlbSysTimer->GetCurrentSystemTimeTick100();
	int alarmToggle = 400;
	if (pThis->m_nAlarmsActive > 0) {
		// some circumstances speed up the rotation - when there's potentially a hidden alarm
		if (pThis->m_nAlarmsActive > 1)
			alarmToggle = 200;	// shorter time to rotate - need to see lower alarms	
		else if (pThis->m_nFirstAlarm < pThis->m_nLastLane)
			alarmToggle = 200;	// shorter time to rotate - need to see lower alarms
	}
	if (((timeNow >= (pThis->m_llPreviousLaneToggle + alarmToggle)) && (pThis->m_nAlarmsActive == 0))
			|| ((timeNow >= (pThis->m_llPreviousLaneToggle + alarmToggle)) && (pThis->m_nAlarmsActive > 0))) {
		pThis->m_nLastLane++;
		pThis->m_llPreviousLaneToggle = timeNow;
	}
	if (pThis->m_nLastLane >= pThis->m_nNumPens)
		pThis->m_nLastLane = 0;
	for (nLane = 0; nLane < pThis->m_nNumPens; nLane++) {
		if ((!pThis->m_bCurrentAlarm[nLane]) && (nLane != pThis->m_nLastLane)) {
			pThis->DrawPenPointer(pDC, nLane, DrawInFlashState);
		}
	}
	// If m_nLastLane is lower than a pen in alarm, the alarmed pen will be overwritten.
	// Therefore, if this is the case, reduce the time before the next change.
	// If there is more than one pen in Alarm, the higher number could hide the lower number.
	// Therefore, if there is more than one alarm, also reduce the time before the next change.
	pThis->m_nAlarmsActive = 0;	// reset number of active alarms
	for (nLane = 0; nLane < pThis->m_nNumPens; nLane++) {
		if ((pThis->m_bCurrentAlarm[nLane]) && (nLane != pThis->m_nLastLane)) {
			pThis->DrawPenPointer(pDC, nLane, DrawInFlashState);
			pThis->m_nAlarmsActive++;
			if (pThis->m_nAlarmsActive == 1)
				pThis->m_nFirstAlarm = nLane;
		}
	}
	// draw one pen last (even on top of any alarms) on a rotating basis
	if (pThis->m_nNumPens > 0)
		pThis->DrawPenPointer(pDC, pThis->m_nLastLane, DrawInFlashState);
	/*
	 for(nLane=0; nLane<pThis->m_nNumPens; nLane++)
	 if(!pThis->m_bCurrentAlarm[nLane])
	 pThis->DrawPenPointer(pDC, nLane, DrawInFlashState);
	 for(  nLane=0; nLane<pThis->m_nNumPens; nLane++)
	 if(pThis->m_bCurrentAlarm[nLane])
	 pThis->DrawPenPointer(pDC, nLane, DrawInFlashState);
	 */
	// Restore GDI objects after drawing pen pointers.
	pDC->SetBkMode(nOldBkMode);
	pDC->SetBkColor(nOldBkColour);
	pDC->SetTextColor(crOldTextColour);
	pDC->SelectObject(hOldfont);
	pfc->ReleaseFont(hfont);
	// Restore clipping region 
	pThis->m_pWidget->RestoreClipping(hdc);
}
void CPenPointersObject::Save(void *pbySrc, int nSrcByteSize) {
	if (m_nSaveBufferBytesRemaining >= nSrcByteSize) {
		memcpy(m_pbySaveBuffer, pbySrc, nSrcByteSize);
		m_pbySaveBuffer += nSrcByteSize;
		m_nSaveBufferBytesRemaining -= nSrcByteSize;
	} else {
		assert(0); // save buffer is not big enough!
		m_bSaveOk = FALSE;
	}
}
void CPenPointersObject::Restore(void *pbyDst, int nDstByteSize) {
	memcpy(pbyDst, m_pbySaveBuffer, nDstByteSize);
	m_pbySaveBuffer += nDstByteSize;
}
BOOL CPenPointersObject::SavePenPointersObjectState(BYTE *pbySaveBuffer, int nSaveBufferByteSize) {
	m_bSaveOk = TRUE;
	m_pbySaveBuffer = pbySaveBuffer;
	m_nSaveBufferBytesRemaining = nSaveBufferByteSize;
	Save(&m_ClientRect, sizeof(m_ClientRect));
	Save(&m_nCharCellHeight, sizeof(m_nCharCellHeight));
	Save(&m_nCharCellWidth, sizeof(m_nCharCellWidth));
	Save(&m_nPenFontHeight, sizeof(m_nPenFontHeight));
	Save(&m_nPenHeight, sizeof(m_nPenHeight));
	Save(&m_nPenWidth, sizeof(m_nPenWidth));
	Save(&m_nPrevHeight, sizeof(m_nPrevHeight));
	Save(&m_pCMMpens->ScaleIndent, sizeof(m_pCMMpens->ScaleIndent));
	Save(&m_pCMMbase->Bounds, sizeof(m_pCMMbase->Bounds));
	Save(&m_pDataItemRef, sizeof(m_pDataItemRef));
	Save(&m_ptArrowTip, sizeof(m_ptArrowTip));
	m_pbySaveBuffer = pbySaveBuffer; // restore to beginning
	return m_bSaveOk;
}
void CPenPointersObject::RestorePenPointersObjectState() {
	if (m_bSaveOk) {
		Restore(&m_ClientRect, sizeof(m_ClientRect));
		Restore(&m_nCharCellHeight, sizeof(m_nCharCellHeight));
		Restore(&m_nCharCellWidth, sizeof(m_nCharCellWidth));
		Restore(&m_nPenFontHeight, sizeof(m_nPenFontHeight));
		Restore(&m_nPenHeight, sizeof(m_nPenHeight));
		Restore(&m_nPenWidth, sizeof(m_nPenWidth));
		Restore(&m_nPrevHeight, sizeof(m_nPrevHeight));
		Restore(&m_pCMMpens->ScaleIndent, sizeof(m_pCMMpens->ScaleIndent));
		Restore(&m_pCMMbase->Bounds, sizeof(m_pCMMbase->Bounds));
		Restore(&m_pDataItemRef, sizeof(m_pDataItemRef));
		Restore(&m_ptArrowTip, sizeof(m_ptArrowTip));
		// Set up information for EU (linear) or power of 10 (log) to pixel conversion.
		// Note that each pen pointer has its own scale, so we need to set up conversion
		// information for each pen pointer.
		for (int nLane = 0; nLane < m_nNumPens; nLane++)
			m_ci[nLane].CalcFConvInfo(GetZero(nLane), GetSpan(nLane),
					m_pCMMpens->Orientation == OBJECT_HORIZONTAL ?
							(float) m_ClientRect.left + m_pCMMpens->ScaleIndent :
							(float) m_ClientRect.bottom - 1 - m_pCMMpens->ScaleIndent,
					m_pCMMpens->Orientation == OBJECT_HORIZONTAL ?
							(float) m_ClientRect.right - 1 - m_pCMMpens->ScaleIndent :
							(float) m_ClientRect.top + m_pCMMpens->ScaleIndent);
	} else
		assert(0); // do not attempt restore if save failed!
}
//****************************************************************************
///
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CPenPointersObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	CBaseObject::SetBounds(bounds, pPos1, pPos2); // call the base Object version
	Recalculate();
}
//****************************************************************************
/// 
///	Tidy up before destructor is called
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CPenPointersObject::Destroy() {
}
void CPenPointersObject::DrawPenPointer(CDC *pDC, int nLane, BOOL DrawInFlashState) {
	BOOL bHoriz = m_pCMMpens->Orientation == OBJECT_HORIZONTAL;
	CDataItemPen *pDataItemPen = (CDataItemPen*) m_pDataItemRef[nLane]->m_pDataItem;
	COLORREF crPenColour = *pDataItemPen->GetColour();
	// Set up colour for pen pointer symbol.
	if (m_pCMMbase->IsTransparent)
		pDC->SetBkMode(TRANSPARENT);
	else
		pDC->SetBkColor(*m_pBackColour);
	//E528446[
	// Fix for Custom screen issue
	// 1.	Menu bar as well as settings tab gets hang once goes into alarm state for custom screen (PAR MH2VUR).
	// 2.	Another one is DPMs shows zero value once recorder goes into alarm state for custom screen
	// as shown below (PAR LTB591).
	if (m_pForeAlarmColour) {
		pDC->SetTextColor(DrawInFlashState && m_bCurrentAlarm[nLane] ? *m_pForeAlarmColour : crPenColour);
	} else {
		pDC->SetTextColor(crPenColour);
	}
	//]
	// Determine the pen pointer symbol to use and where
	// to place the pen pointer symbol based on the pen
	// status (underrange, overrange, or valid reading)
	// and the orientation (vertical or horizontal) of
	// the pen pointers object.
	WCHAR PenPtrText[2];
	PenPtrText[1] = 0; // terminator
	QRect rc; // where to place the pen pointer symbol
			  // where to place the pen pointer number
	switch (m_eCurrentStatus[nLane]) {
	case DISTAT_UNDERRANGE:
	case DISTAT_T_

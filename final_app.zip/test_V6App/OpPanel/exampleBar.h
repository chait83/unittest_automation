/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ExampleBar.h
/// @n Description: Derived Object example (simple bar)
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  10  Stability Project 1.7.1.1 7/2/2011 4:57:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  9 Stability Project 1.7.1.0 7/1/2011 4:25:51 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  8 V6 Firmware 1.7 4/7/2005 9:14:59 PM Jason Parker  
//  Added Object Linking
//  7 V6 Firmware 1.6 12/8/2004 9:54:28 PM  Jason Parker  
//  Changes following code review
// $
//
// **************************************************************************
#ifndef _EXAMPLEBAR_H
#define _EXAMPLEBAR_H
//**Class*********************************************************************
///
/// @brief ExampleBar Object
/// 
/// This class is a simple Standard Drawn Object which is derived from the 
/// BaseObject. It can be used as a 'template' for all other derived Objects.
///
//****************************************************************************
class CExampleBar: public CBaseObject {
private:
	// this stuff has to be configured from screen designer
	// need some kind of table with:
	// values, 
	// description (from string table)
	// if uses settings from the DataItem table or overridden by screen designer (stored in CMM)
	float m_TopLimit;		///< Top Bar value set from CMM or Data Item
	float m_BottomLimit;	///< Bottom Bar value set from CMM or Data Item
	float m_CurrentValue;	///< Current value of channel (pen) to be displayed
	CDataItemRef *m_pDataItemRef;	///< data item table reference (could have more than 1)
	T_EXAMPLEBAR *m_pCMMexample;	///< pointer to our CMM configuration
	// derived objects must draw themselves 
	// called via the m_pOnDraw pointer to function.
	static void OnDraw(CExampleBar *pThis, HDC hdc, QRect *pClipRect);
public:
	CExampleBar(CWidget *pWidget);
	// overidden functions that must be supplied
	void CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds);	///< init first time
	void ConfigChange();								///< config changes	
	void Destroy();
	// optional overrides
	LinkOrientation GetLinkOrient();
	BOOL CanSetLinkPositions(int pos1, int pos2);
};
#endif

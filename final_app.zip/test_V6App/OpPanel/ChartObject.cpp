/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Op Panel
/// @n Filename: ChartObject.cpp
/// @n Description: Derived Object 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  106  Stability Project 1.101.1.3  7/2/2011 4:56:04 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  105  Stability Project 1.101.1.2  7/1/2011 4:38:05 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  104  Stability Project 1.101.1.1  3/17/2011 3:20:15 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  103  Stability Project 1.101.1.0  2/15/2011 3:02:32 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "OpPanelIncludes.h"
#include "TimeHistory.h"
#include "float.h"
#ifndef UNDER_CE
// for sndPlaySound on the desktop build
#include "Mmsystem.h"
#pragma comment( lib, "Winmm" )
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
extern BOOL Glb_SeeRegions;
#pragma warning( disable : 4244 4267)
////////////////////////////////////// TEST FUNCTIONS /////////////////////////////////////////////////
/*
 WCHAR stimetbuff2[50];
 QString  FS2(LONGLONG thetime)
 {
 CTimeHistory* pTh=CTimeHistory::GetHandle();
 TableEntry* pEntry=pTh->GetEntry(thetime);
 if(!pEntry)
 return NULL;  // major problem here - no time history!
 
 LONGLONG diffmicro=(thetime-pEntry->Tick100)*10000;	
 CTVtime displaytime=pEntry->ActualTime+diffmicro;  
 
 displaytime.TimeToStringShort(stimetbuff2);
 return stimetbuff2;
 }

 WCHAR etimetbuff2[50];
 QString  FE2(LONGLONG thetime)
 {
 CTimeHistory* pTh=CTimeHistory::GetHandle();
 TableEntry* pEntry=pTh->GetEntry(thetime);
 if(!pEntry)
 return NULL;  // major problem here - no time history!
 
 LONGLONG diffmicro=(thetime-pEntry->Tick100)*10000;	
 CTVtime displaytime=pEntry->ActualTime+diffmicro;  
 
 displaytime.TimeToStringShort(etimetbuff2);
 return etimetbuff2;
 }
 */
////////////////////////////////////// TEST FUNCTIONS /////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CChartObject
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#define HORIZONTAL 0
#define VERTICAL  1
/// The variables below are used to setup the correct font for each product
const int QVGA_TIMESTAMP_FONT_HEIGHT = 11;		//XS - Qx and Qxe GR - Qxe
const int VGA_TIMESTAMP_FONT_HEIGHT = 22;		//GR - Qx
const int SVGA_PLUS_TIMESTAMP_FONT_HEIGHT = 13;	//XS - Sx
const int XVGA_PLUS_TIMESTAMP_FONT_HEIGHT = 16; //PSR - timestamp font height for GR SX (13*1.28) and DRG2
const int EDF_TIMESTAMP_FONT_HEIGHT = 20;
//****************************************************************************
/// ChartObject Constructor
///
/// @param[in] pParentWidget - pointer to Parent Widget
/// 
//****************************************************************************
CChartObject::CChartObject(CWidget *pParentWidget) : CBaseObject(pParentWidget) {
	// reassign function pointer (speed issue)
	m_pOnDraw = (ONDRAWCAST) & CChartObject::OnDraw;
	m_pDDSprivate = NULL;
	m_TSalpha = TRUE;
	m_bIsReplayWidget = FALSE;
	m_TSinterval = 500; // 5sec
	m_TSfontHeight = QVGA_TIMESTAMP_FONT_HEIGHT;
	// due to the smaller pitch of a mini and multi we need to make the font much bigger
	if ( pDALGLB->IsRecorderMini()) {
		m_TSfontHeight = VGA_TIMESTAMP_FONT_HEIGHT;
	} else if ( pDALGLB->IsRecorderMulti()) {
		m_TSfontHeight = XVGA_PLUS_TIMESTAMP_FONT_HEIGHT;
	}
#ifdef DOCVIEW
	m_TSalpha=FALSE;
	T_DEV_TYPE recorderType = GetOpPanel()->m_pMainConfig->GetRecorderType();
	if( recorderType == DEV_ARISTOS_MULTIPLUS || recorderType == DEV_SCR_MINITREND )	
	{
		m_TSfontHeight=XVGA_PLUS_TIMESTAMP_FONT_HEIGHT;
	}
	else if (recorderType == DEV_ARISTOS_MINITREND )	
	{
		m_TSfontHeight=VGA_TIMESTAMP_FONT_HEIGHT;
	}
#endif
	m_longestMonthBuff[0] = 0;
	m_pTScolour = NULL;
	m_pBackAlarmColour = NULL;
	m_pMessageColour = NULL;
	// set all of the objects internal settings to defaults
	m_Origin100 = 0;
	m_ScrollAmount = 0;
	m_ScrollAmount2 = 0;
	m_mode = AUTO_SCROLL;
	m_KeepOrigin = FALSE;
	// these will get reset in ConfigChange based on the chart config
	m_ChartSpeed = SPEED_FAST;
	m_Tpp = CChartQManager::GetChartSpeed(CQT_STRIP, m_ChartSpeed);
	m_GroupNumber = 0;
	m_enabledChartPens = 0;
	m_ThickestPen = 0;
	m_LastUpdateTime = 0;
	m_EdFstamps = FALSE;
	for (int p = 0; p < MAX_CHART_PENS; p++) {
		m_pChartDataItem[p] = NULL;
		m_pChartQ[p] = NULL;
		m_latestDataSeen[p] = 0;
		m_Initialised[p] = FALSE;
	}
	m_lastestMessageSeen = BEGINNING_OF_TIME;
	m_pMessageQ = NULL;
	m_InitialisedMessages = FALSE;
	memset(&m_BaseAlarmMessage, 0, sizeof(T_MSGLISTSER_MESSAGE));
	m_BaseAlarmMessageTime = BEGINNING_OF_TIME;
	m_TimePos1 = BEGINNING_OF_TIME;
	m_TimePos2 = END_OF_TIME;
}
//****************************************************************************
///
///	Destructor 
///
/// @param none
/// 
//****************************************************************************
CChartObject::~CChartObject() {
	if (m_pDDSprivate) {
		m_pDDSprivate->Release();
		m_pDDSprivate = NULL;
	}
}
//****************************************************************************
///
/// Initialises the Object with the block of data from the CMM.
/// This will either be to reconstruct a previously saved Object
/// Or will be a new defaulted block for a new Object. 
///
/// @param[in] CMMinfo	- Block of CMM info
/// @param[in] bounds	- Size and position for a new Object
///						 or NULL for a previous (reloaded) Object	
///
/// @return none
/// 
//****************************************************************************
void CChartObject::CMMInit(BLOCK_INFO *CMMinfo, QRect *bounds) {
	CMMInitBase(CMMinfo);
	// set up pointer to CChartObject data in CMM info block.
	m_pCMMchart = (T_CHARTOBJECT*) CMMinfo->pByBlock;
	// if bounds passed in, set these here (also updates the CMM values)
	// also presume that this is therefore a new Object.
	if (bounds) {
		SetBoundsRelative(bounds);
		// update CMM settings (from the defaults) for this specific Object type
		m_pCMMbase->Border.BorderUsed = TRUE;
		m_pCMMbase->Border.BorderWidth = 1;
		m_pCMMbase->UpdateRate100 = 20; // faster redraw update.
		// set the attribute block settings for chart
		m_pCMMbase->AttrBlocks.BackColourBlk = ATTRIB_CHART_NORMAL; // use this GLOBAL attribute block for background colour
		m_pCMMbase->AttrBlocks.ForeColourBlk = ATTRIB_CHART_NORMAL; // use this GLOBAL attribute block for foreground colour
		// set these to sensible defaults.
		m_pCMMbase->FixBackColour = 0;
		m_pCMMbase->BackColour = RGB(255, 255, 255); // white background
		m_pCMMbase->FixForeColour = 0;
		m_pCMMbase->ForeColour = RGB(200, 200, 200); // mid grey (for graduations)
		m_pCMMchart->FixBGAlarmCol = 0;
		m_pCMMchart->BGAlarmCol = RGB(255, 255, 200); // yellow
	} else {
		// When loading a previous configuration:
		// initialise any members here from loaded CMM values
	}
	// set these flags for specific Object (i.e.advanced draw only)
	m_pCMMbase->IsAdvancedDraw = TRUE; // chart is advanced drawn only.
	m_pCMMbase->IsPrimaryDirect = FALSE; // not primary direct (may not allow at all)
	// if primary direct was not set, then we would have the following as next default
	m_pCMMbase->IsPermanent = TRUE; // on permanent surface
	m_pCMMbase->IsBackground = TRUE;
	ConfigChange();
}
//****************************************************************************
///
/// This function will be called after any setup changes have been made or 
/// other changes to the Data Item Table references
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CChartObject::ConfigChange() {
	// set up our surface pointer here...
//	if(m_pCMMbase->IsPrimaryDirect)
//		m_pDDSurf=m_pWidget->m_pDDSPrimary;
	if (m_pCMMbase->IsPermanent)
		m_pDDSurf = m_pWidget->m_pDDSPermanent;
	// T_BASEOBJECT CMM config to CBaseObject members:
	// set our internal members values from the Attribute block or source or CMM 
	// forecolour is colour of graduations.
	if (m_pCMMbase->FixForeColour)
		// use foreground colour from CMM (e.g. as selected in Screen Designer)
		m_pForeColour = &m_pCMMbase->ForeColour;
	else {
		if (m_pCMMbase->AttrBlocks.ForeColourBlk)
			// use foreground colour from user definable Attribute block
			m_pForeColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
					m_pCMMbase->AttrBlocks.ForeColourBlk)->FGCol;
		else
			m_pForeColour = &m_pCMMbase->ForeColour; // not fixed and no attrib block
	}
	if (m_pCMMbase->FixBackColour)
		// use background colour from CMM (e.g. as selected in Screen Designer)
		m_pBackColour = &m_pCMMbase->BackColour;
	else {
		if (m_pCMMbase->AttrBlocks.BackColourBlk)
			// use background colour from user definable Attribute block
			m_pBackColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(
					m_pCMMbase->AttrBlocks.BackColourBlk)->BGCol;
		else
			m_pBackColour = &m_pCMMbase->BackColour; // not fixed and no attrib block
	}
	// for the remainder of the settings the attribute blocks may be changed for a global (all chart) change
	// The user attribute blocks cannot be used here.
	// or individual charts may be changed. 
	if (m_pCMMchart->FixBGAlarmCol)
		// use background alarm colour from CMM (e.g. as selected in Screen Designer)
		m_pBackAlarmColour = &m_pCMMchart->BGAlarmCol;
	else
		// use ackground alarm colour from GLOBAL Attribute block
		m_pBackAlarmColour =
				&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_CHART_NORMAL_ALARM)->BGCol;
	if (m_pCMMchart->FixFontCol) // fix font colour 
		// use timestamp font colour from CMM (e.g. as selected in Screen Designer)
		m_pTScolour = &m_pCMMchart->FontColour;
	else
		// use timestamp font colour from GLOBAL Attribute block
		m_pTScolour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_CHART_TEXT)->FGCol;
	if (m_pCMMchart->FixMessageCol)
		// use message font colour from CMM (e.g. as selected in Screen Designer)
		m_pMessageColour = &m_pCMMchart->MessageCol;
	else
		// use message font colour from GLOBAL Attribute block
		m_pMessageColour = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(ATTRIB_CHART_TEXT)->BGCol;
	// use flash atrtribute from Attribute block if set (0=default=FALSE)
	m_pFlashing =
			&m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.FlashingBlk)->Flashing;
	// use visible atrtribute from Attribute block if set (0=default=TRUE)
	m_pVisible = &m_pWidget->m_pScreen->m_pOpPanel->m_pDIT->attribBlockPtr(m_pCMMbase->AttrBlocks.VisibleBlk)->Visible;
	// based on a m_pForeColour of RGB(200,200,200)
	// adjust the gradlines to suit the displays.
#ifdef UNDER_CE
		m_MajorColour=*m_pForeColour;				 // darker grey
		m_MinorColour=ColourAdjust(*m_pForeColour,25);// light grey
		m_HeavyGrey=ColourAdjust(*m_pForeColour,-30);
	#else
	m_MajorColour = ColourAdjust(*m_pForeColour, 20);				 // darker grey
	m_MinorColour = ColourAdjust(*m_pForeColour, 40);				 // light grey
	m_HeavyGrey = ColourAdjust(*m_pForeColour, -30);
#endif
	if (m_pDDSprivate) {
		m_pDDSprivate->Release();
		m_pDDSprivate = NULL;
	}
	// SETTING CHART SPEED and m_Tpp here - but only for non-replay usage.
	if (m_mode < REPLAY) {
		//m_ChartSpeed=(ChartSpeed)m_pCMMchart->ChartSpeed; // use the chart speed (fast/med/slow) from the layout
		CScreen *pkParentScreen = m_pWidget->GetScreen();
		const USHORT usSCREEN_NO = pkParentScreen->m_pCMMscreen->Number - 1;
		USHORT usChartIndex = 0;
		CWidget *pkWidget = pkParentScreen->m_pWidgets;
		bool bFoundChart = false;
		while ((pkWidget != NULL) && !bFoundChart) {
			CBaseObject *pkBaseObject = pkWidget->m_pObjects;
			while ((pkBaseObject != NULL) && !bFoundChart) {
				// check if this is a chart object
				if (pkBaseObject->GetLayoutItem().CMM_Type == BLK_CHARTOBJECT) {
					// this is a chart object therefore check if it has the same index as the current selected
					// object
					if (pkBaseObject == this) {
						bFoundChart = true;
						break;
					} else {
						// not the right chart therefore increment the chart index
						++usChartIndex;
						// break from the object loop to save time as only one chart is allowed per widget
						break;
					}
				}
				// move onto the next object
				pkBaseObject = pkBaseObject->m_pNextObj;
			}
			// move on to the next widget
			pkWidget = pkWidget->m_pNextWgt;
		}
		m_ChartSpeed = static_cast<ChartSpeed>( pSYSTEM_INFO->GetChartSpeed(usChartIndex, usSCREEN_NO));
		m_Tpp = CChartQManager::GetChartSpeed(CQT_STRIP, m_ChartSpeed);
	}
	CalcTimestampsRect(); // first calc the rect
	// then create the surface that size..
	if (m_TSalpha && (m_pDDSprivate == NULL))
		CreateSurface();
	// Data item configuration done here. 
	// Since chart data does NOT come from the data item table, there is no point maintaining all the Data Item Refs.
	// Here we request data item pointers from the widget.
	T_CHANNELREF channelInfo;
	channelInfo.Enabled = TRUE;
	channelInfo.Updates = FALSE;
	channelInfo.Rotate = FALSE;
	channelInfo.ItemType = DI_PEN;
	channelInfo.SubType = 0;
	m_enabledChartPens = 0;
	USHORT usMaxChartPens = GetMaxChartPens();
	for (int i = 0; i < usMaxChartPens; i++) {
		if (i < m_pWidget->m_pCMMwidget->NumChannels) {
			// E527303
			//if((m_mode>=REPLAY)&&(GetWidget()->GetScreen()->m_pCMMscreen->CannedPens[i].Dpm==FALSE))
			if ((m_mode >= REPLAY) && (GetWidget()->GetScreen()->m_pCMMscreen->ReplayPens[i].Dpm == FALSE))
				continue; // don't add this chart data item if dpm is disabled for replay
			// complete our channel Ref info here
			channelInfo.IndexChan = i; // use Widget's channel index
			CDataItem *pDataItem = m_pWidget->GetDataItemPtr(&channelInfo);
			if (pDataItem && pDataItem->IsEnabled()) // is the data item actually enabled?
					{
				m_pChartDataItem[m_enabledChartPens] = pDataItem;
				m_enabledChartPens++;
			}
		}
	}
	m_ThickestPen = 0;
// now for those enabled pens, get the chartQ's and configure the conversion info
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->WaitLock(1);
	for (int p = 0; p < m_enabledChartPens; p++) {
		// re-init these
		m_latestDataSeen[p] = 0;
		m_Initialised[p] = FALSE;
		if (m_pChartDataItem[p]->GetLineInfo()->Thickness > m_ThickestPen)
			m_ThickestPen = m_pChartDataItem[p]->GetLineInfo()->Thickness;
		// add/or gets the chart Q thet we require
#ifndef DOCVIEW
		// but not for screen designer!
		m_pChartQ[p] = CM->AddStripChartQ(m_pChartDataItem[p]->GetInstance(), m_ChartSpeed);
		// Set up for going into /coming out of replay
		if (m_mode >= REPLAY) {
			// REPLAY		
			m_pChartQ[p]->m_DrawingTpp = m_Tpp; // set the drawing tpp for the queue to this charts tpp
			m_pChartQ[p]->m_ReplayUsage = TRUE;
		} else {
			m_pChartQ[p]->m_DrawingTpp = m_pChartQ[p]->m_Tpp; // set the drawing tpp for the queue to it's Q tpp
			m_pChartQ[p]->m_ReplayUsage = FALSE;
			// here only do this if the chart is on the active screen
			// since each screen is 'active' as it is created, only do this if it matches the current screen number
			CScreen *pkParentScreen = m_pWidget->GetScreen();
			if (pkParentScreen->GetOpPanel()->m_CurrentScreenNumber == pkParentScreen->m_pCMMscreen->Number) {
				if (!m_pChartQ[p]->m_InitialRequest) {
					//qDebug("))))CONFIG Change %d\n",m_pChartQ[p]->m_QHandle);
					m_pChartQ[p]->m_InitialRequest = TRUE; // set this again to ensure we get a request for the most recent screens worth of data
					m_pChartQ[p]->CheckQueue(0, 0);
				}
			}
		}
#endif
	}
	CM->Unlock();
	if (GetWidget()->GetScreen()->m_pCMMscreen->UseGroups)
		m_GroupNumber = GetWidget()->GetScreen()->m_pCMMscreen->GroupIndex + 1;
	else
		m_GroupNumber = 0;
	SetBounds(&GetBounds()); // sets up the m_Origin100 etc.
	if (CM->IsReconCharts())
		m_LastUpdateTime = pGlbSysTimer->GetHighResOnGoingTick100(); // need to do this for all charts on a restart
	CalcTimestampBases(); // requires m_Origin100 (do after SetBounds)
#ifndef DOCVIEW
	// not for screen designer!
	CM->WaitLock(1);
	m_lastestMessageSeen = BEGINNING_OF_TIME;
	m_InitialisedMessages = FALSE;
	m_pMessageQ = CM->m_ChartMessageQ;
	/*
	 CScreen *pkParentScreen = m_pWidget->GetScreen();
	 if(pkParentScreen->GetOpPanel()->m_CurrentScreenNumber==pkParentScreen->m_pCMMscreen->Number)
	 {
	 if(!m_pMessageQ->m_InitialRequest)
	 {
	 m_pMessageQ->m_InitialRequest=TRUE;
	 m_pMessageQ->CheckQueue(0,0);
	 }
	 }
	 */
	// get alarm message at or prior to m_Origin100, and go back as far as we can.			
	if (m_pMessageQ->GetPreviousAlarmMessage(m_Origin100, &m_BaseAlarmMessage, m_GroupNumber))
		m_BaseAlarmMessageTime = m_BaseAlarmMessage.messageId >> 16;
	else
		m_BaseAlarmMessageTime = BEGINNING_OF_TIME; //default. (none found)
	CM->Unlock();
#endif
}
//****************************************************************************
///
/// Virtual function override of baseObject SetBounds
/// Sets the bounds (bounding rectangle - position and size) of the Object in
/// Widget co-ordinates (i.e. relative to the CScreen).
///
/// @param[in] bounds	- pointer to rectangle containing bounds to set
/// @param[in] pPos1	- pointer to link position 1 (top or left of scale)
///						 to set if non-NULL (force link position to this value)
/// @param[in] pPos2	- pointer to link position 2 (bottom or right of scale)
///						 to set if non-NULL (force link position to this value)
///
/// @return none
/// 
//****************************************************************************
void CChartObject::SetBounds(QRect *bounds, int *pPos1, int *pPos2) {
	CBaseObject::SetBounds(bounds, pPos1, pPos2); // call the base Object version
	CChartQManager *CM = CChartQManager::GetHandle();
	if (!m_KeepOrigin || CM->IsReconCharts()) {
		m_Origin100 = 0;
		if (!(CM->IsChartsPaused(m_GroupNumber) || CM->IsChartsPaused(PEN_GROUP_NONE)) || CM->IsReconCharts()) {
#ifndef DOCVIEW
			if (pGlbSysTimer)
				m_Origin100 = pGlbSysTimer->GetHighResOnGoingTick100();
#endif
		} else {
			if (CM->IsChartsPaused(m_GroupNumber))
				m_Origin100 = CM->GetPausedTime(m_GroupNumber);
			else
				m_Origin100 = CM->GetPausedTime(PEN_GROUP_NONE);
		}
		int remainder = m_Origin100 % m_Tpp;
		if (remainder)
			m_Origin100 += (m_Tpp - remainder); // round up to next m_Tpp boundary
		if (m_pCMMchart->IsVertical)
			m_ChartSpan = _Height(m_ClientRect);
		else
			m_ChartSpan = _Width(m_ClientRect);
		m_Origin100 -= (m_ChartSpan * m_Tpp);
	}
	// Link position offset - initially allow 5% (max 10 pixels) inside the clientrect limits
	// this may get made smaller when linked.
	// check to see if this object is linked (use CMM setting)
	if (m_pCMMbase->LinkedObj.CMM_Type == 0) {
		// not linked, so set to default.
		if (m_pCMMchart->IsVertical)
			m_pCMMchart->posOffset = (int) (_Width(m_ClientRect) * 0.05);
		else
			m_pCMMchart->posOffset = (int) (_Height(m_ClientRect) * 0.05);
		if (m_pCMMchart->posOffset > 10)
			m_pCMMchart->posOffset = 10; // set max of 10 pixels.
	}
	// and calculate the link positions
	if (m_pCMMchart->IsVertical) {
		m_pos1 = m_ClientRect.left + m_pCMMchart->posOffset;
		m_pos2 = m_ClientRect.right - 1 - m_pCMMchart->posOffset; // allow for the rh edge
	} else {
		m_pos1 = m_ClientRect.top + m_pCMMchart->posOffset;
		m_pos2 = m_ClientRect.bottom - 1 - m_pCMMchart->posOffset; // allow for the bottom edge
	}
	// for the enabled pens, configure the conversion info and calc the grads
	for (int p = 0; p < m_enabledChartPens; p++) {
		float zero = m_pChartDataItem[p]->GetZero();
		float span = m_pChartDataItem[p]->GetSpan();
		// configure the conversion info positions
		if (m_pCMMchart->IsVertical)
			m_convInfo[p].CalcFConvInfo(zero, span, (float) m_pos1, (float) m_pos2);
		else
			m_convInfo[p].CalcFConvInfo(zero, span, (float) m_pos2, (float) m_pos1);
		// the first pens conversion info is used for the graduations	
		if (p == 0) {
			m_grads.SetZoomed(FALSE, 0, 0); // are we zoomed?
			if (!m_pCMMchart->IncGridLine1) {
				m_pCMMchart->GridLine1 = FLT_MAX;
			}
			if (!m_pCMMchart->IncGridLine2) {
				m_pCMMchart->GridLine2 = FLT_MAX;
			}
			if (!m_pCMMchart->IncSetpointLine) {
				m_pCMMchart->SetpointLine = FLT_MAX;
			}
			m_grads.CalcScale(m_pChartDataItem[p]->GetScaleInfo(), &m_convInfo[p], m_pCMMchart->GridLine1,
					m_pCMMchart->GridLine2, m_pCMMchart->SetpointLine);
		}
	}
}
//****************************************************************************
///
/// Zoom Out
/// 
/// @param[in] cursorTimex -	Cursor time (100ths) to zoom out around
///
/// @return none 
/// 
//****************************************************************************
void CChartObject::ZoomOut(LONGLONG cursorTimex) {
	if (m_mode >= REPLAY) // in a replay mode
			{
		// get our current index into the rates available
		int index = CChartQManager::RateToIndex(CQT_STRIP, m_Tpp);
		if (index < NUM_STRIP_RATES - 1) {
			// not at the last, so can zoom out.
			// now check that we are using the correct queue
			int rate_fast = CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_FAST);
			int rate_med = CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_MEDIUM);
			int rate_slow = CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_SLOW);
			int fast_index = CChartQManager::RateToIndex(CQT_STRIP, rate_fast);
			int med_index = CChartQManager::RateToIndex(CQT_STRIP, rate_med);
			int slow_index = CChartQManager::RateToIndex(CQT_STRIP, rate_slow);
			BOOL use_fast;
			BOOL use_med;
			BOOL use_slow;
			BOOL exact_fast;
			BOOL exact_med;
			BOOL exact_slow;
			do {
				index++; // increment for zoom out
				use_fast = FALSE;
				use_med = FALSE;
				use_slow = FALSE;
				exact_fast = FALSE;
				exact_med = FALSE;
				exact_slow = FALSE;
				if (index > fast_index) {
					if (index - fast_index <= 2) // allow up to an index of 2 more than source data
						use_fast = TRUE;
				} else if (index < fast_index) {
					if (fast_index - index <= 1) // allow up to an index of 4 less than source data
						use_fast = TRUE;
				} else {
					use_fast = TRUE;
					exact_fast = TRUE;
				}
				// zoom out - allow up to an index of 2 more from source data
				if (index > med_index) {
					if (index - med_index <= 2)
						use_med = TRUE;
				} else if (index < med_index) {
					if (med_index - index <= 1)
						use_med = TRUE;
				} else {
					use_med = TRUE;
					exact_med = TRUE;
				}
				// zoom out - allow up to an index of 2 more from source data
				if (index > slow_index) {
					if (index - slow_index <= 2)
						use_slow = TRUE;
				} else if (index < slow_index) {
					if (slow_index - index <= 1)
						use_slow = TRUE;
				} else {
					use_slow = TRUE;
					exact_slow = TRUE;
				}
			} while (((use_fast || use_med || use_slow) == FALSE) && (index < NUM_STRIP_RATES - 1));
			// see if it's worth going further...
			if ((use_fast || use_med || use_slow) == FALSE) {
				qDebug("************* Not possible to zoom out here **********\n");
				sndPlaySound(L"Default.wav", SND_FILENAME | SND_ASYNC | SND_NOSTOP);
				return;
			}
			// calc what these values will be if it succeeds..
			int poss_Tpp = CChartQManager::GetRateAtIndex(CQT_STRIP, index);
			LONGLONG poss_Origin100 = cursorTimex - (m_ChartSpan * poss_Tpp) / 2;
			poss_Origin100 -= (poss_Origin100 % poss_Tpp); // align on a boundary.
			CChartQManager *CM = CChartQManager::GetHandle();
			LONGLONG oldestFast = 0;
			LONGLONG oldestMedium = 0;
			LONGLONG oldestSlow = 0;
			CM->GetOldestTimes(&oldestFast, &oldestMedium, &oldestSlow, CQT_STRIP);
			if (cursorTimex < oldestFast)
				use_fast = FALSE;
			if (cursorTimex < oldestMedium)
				use_med = FALSE;
			if (cursorTimex < oldestSlow)
				use_slow = FALSE;
			// test to see if we have any data at origin..
			if ((use_fast || use_med || use_slow) == FALSE) {
				qDebug("************* No chart data old enough **********\n");
				sndPlaySound(L"Default.wav", SND_FILENAME | SND_ASYNC | SND_NOSTOP);
				return;
			}
			// ok, here we can do it
			// now set m_Tpp and m_Origin100 in the chart.
			m_Tpp = poss_Tpp;
			m_Origin100 = poss_Origin100;
			// check in this order and see which are true....
			if (use_slow)
				m_ChartSpeed = SPEED_SLOW;
			if (use_med)
				m_ChartSpeed = SPEED_MEDIUM;
			if (use_fast)
				m_ChartSpeed = SPEED_FAST;
			if (exact_slow)
				m_ChartSpeed = SPEED_SLOW;
			else if (exact_med)
				m_ChartSpeed = SPEED_MEDIUM;
			else if (exact_fast)
				m_ChartSpeed = SPEED_FAST;
			//qDebug("Using queue %d (%d) and drawing Tpp %d\n",m_ChartSpeed,CChartQManager::GetChartSpeed(CQT_STRIP, m_ChartSpeed), m_Tpp);
			// now check cursor pos, and update origin so that cursortime is in middle of screen
			COpPanel *pOpPanel = GetOpPanel();
			// set up displaytime with the new TPP Cursortime on the new TPP boundary
			pOpPanel->m_pReplayCursorObject->m_display1Time = pOpPanel->m_pReplayCursorObject->m_Cursor1Time;
			pOpPanel->m_pReplayCursorObject->m_display1Time -=
					(pOpPanel->m_pReplayCursorObject->m_display1Time % m_Tpp);
			CTimeHistory *pTh = CTimeHistory::GetHandle();
			TableEntry *pEntry = pTh->GetEntry(pOpPanel->m_pReplayCursorObject->m_Cursor1Time); // use cursor time here
			if (!pEntry)
				return;  // major problem here - no time history!
			LONGLONG diffmicro = (pOpPanel->m_pReplayCursorObject->m_display1Time - pEntry->Tick100) * 10000; // use displaytime here
			CTVtime displaytime = pEntry->ActualTime;
			displaytime += diffmicro; // actual realworld time of this position.
			LONGLONG displaytime100 = displaytime.GetMicroSecs() / 10000;
			displaytime100 -= (displaytime100 % m_Tpp); // on boundary (NEW TPP)
			LONGLONG diff = pOpPanel->m_pReplayCursorObject->m_actualtime1 - displaytime100;
			//qDebug("Diff %I64d Tpp %d \n",diff,m_Tpp);
			int inc = m_Tpp;
			if (diff < 0) {
				diff = -diff;
				inc = -inc;
			}
			while (diff >= m_Tpp) {
				m_Origin100 += inc;
				pOpPanel->m_pReplayCursorObject->m_display1Time += inc;
				diff -= m_Tpp;
			}
			if (pOpPanel->m_pReplayCursorObject->m_DualCursors) {
				pOpPanel->m_pReplayCursorObject->m_display2Time = pOpPanel->m_pReplayCursorObject->m_Cursor2Time;
				pOpPanel->m_pReplayCursorObject->m_display2Time -= (pOpPanel->m_pReplayCursorObject->m_display2Time
						% m_Tpp);
				pEntry = pTh->GetEntry(pOpPanel->m_pReplayCursorObject->m_Cursor2Time); // use cursor time here
				if (!pEntry)
					return;  // major problem here - no time history!
				diffmicro = (pOpPanel->m_pReplayCursorObject->m_display2Time - pEntry->Tick100) * 10000; // use displaytime here
				displaytime = pEntry->ActualTime;
				displaytime += diffmicro; // actual realworld time of this position.
				displaytime100 = displaytime.GetMicroSecs() / 10000;
				displaytime100 -= (displaytime100 % m_Tpp); // on boundary (NEW TPP)
				diff = pOpPanel->m_pReplayCursorObject->m_actualtime2 - displaytime100;
				//qDebug("Diff %I64d Tpp %d \n",diff,m_Tpp);
				int inc = m_Tpp;
				if (diff < 0) {
					diff = -diff;
					inc = -inc;
				}
				while (diff >= m_Tpp) {
					//m_Origin100+=inc;
					pOpPanel->m_pReplayCursorObject->m_display2Time += inc;
					diff -= m_Tpp;
				}
			}
			pOpPanel->m_pReplayCursorObject->CalcNewCursorPos();
			m_pWidget->ConfigChange(); // config change for Widget will do cursor and (this)chart 
		}
	}
}
//****************************************************************************
///
/// Zoom in
/// 
/// @param[in] cursorTimex -	Cursor time (100ths) to zoom in at
///
/// @return none 
/// 
//****************************************************************************
void CChartObject::ZoomIn(LONGLONG cursorTimex) {
if(m_mode>=REPLAY) // in a replay mode
{
	// get our current index into the rates available
	int index=CChartQManager::RateToIndex(CQT_STRIP, m_Tpp);
	if(index>0)
	{
		// not at the first, so can zoom in.
		// now check that we are using the correct queue
		int rate_fast=CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_FAST);
		int rate_med=CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_MEDIUM);
		int rate_slow=CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_SLOW);
		int fast_index=CChartQManager::RateToIndex(CQT_STRIP, rate_fast);
		int med_index=CChartQManager::RateToIndex(CQT_STRIP, rate_med);
		int slow_index=CChartQManager::RateToIndex(CQT_STRIP, rate_slow);
		BOOL use_fast;
		BOOL use_med;
		BOOL use_slow;
		BOOL exact_fast;
		BOOL exact_med;
		BOOL exact_slow;
		do
		{
			index--; //decrement for zoom in
			use_fast=FALSE;
			use_med=FALSE;
			use_slow=FALSE;
			exact_fast=FALSE;
			exact_med=FALSE;
			exact_slow=FALSE;
			if(index>fast_index)
			{
				if(index-fast_index<=2) // allow up to an index of 1 more than source data
				use_fast=TRUE;
			}
			else
			if(index<fast_index)
			{
				if(fast_index-index<=1) // allow up to an index of 2 less than source data
				use_fast=TRUE;
			}
			else
			{
				use_fast=TRUE;
				exact_fast=TRUE;
			}
			if(index>med_index)
			{
				if(index-med_index<=2)
				use_med=TRUE;
			}
			else
			if(index<med_index)
			{
				if(med_index-index<=1)
				use_med=TRUE;
			}
			else
			{
				use_med=TRUE;
				exact_med=TRUE;
			}
			if(index>slow_index)
			{
				if(index-slow_index<=2)
				use_slow=TRUE;
			}
			else
			if(index<slow_index)
			{
				if(slow_index-index<=1)
				use_slow=TRUE;
			}
			else
			{
				use_slow=TRUE;
				exact_slow=TRUE;
			}
		}while(((use_fast||use_med||use_slow)==FALSE) && (index>0));
		// see if it's worth going further...
		if((use_fast||use_med||use_slow)==FALSE)
		{
			qDebug("************* Not possible to zoom in here **********\n");
			sndPlaySound(L"Default.wav",SND_FILENAME|SND_ASYNC | SND_NOSTOP );
			return;
		}
		// calc what these values will be if it succeeds..
		int poss_Tpp= CChartQManager::GetRateAtIndex( CQT_STRIP, index );
		LONGLONG poss_Origin100=cursorTimex-(m_ChartSpan*poss_Tpp)/2;// calc origin so that cursor will be in the middle
		poss_Origin100-=(poss_Origin100 % poss_Tpp);// align on a boundary.
		CChartQManager* CM=CChartQManager::GetHandle();
		LONGLONG oldestFast=0;
		LONGLONG oldestMedium=0;
		LONGLONG oldestSlow=0;
		CM->GetOldestTimes(&oldestFast, &oldestMedium, &oldestSlow, CQT_STRIP);
		if(cursorTimex<oldestFast)
		use_fast=FALSE;
		if(cursorTimex<oldestMedium)
		use_med=FALSE;
		if(cursorTimex<oldestSlow)
		use_slow=FALSE;
		// test to see if we have any data at origin..
		if((use_fast||use_med||use_slow)==FALSE)
		{
			qDebug("************* No chart data old enough **********\n");
			sndPlaySound(L"Default.wav",SND_FILENAME|SND_ASYNC | SND_NOSTOP );
			return;
		}
		// ok, here we can do it
		// now set m_Tpp and m_Origin100 in the chart.
		m_Tpp=poss_Tpp;
		m_Origin100=poss_Origin100;
		// check in this order slow to fast (use the faster if several possible)
		if(use_slow)
		m_ChartSpeed=SPEED_SLOW;
		if(use_med)
		m_ChartSpeed=SPEED_MEDIUM;
		if(use_fast)
		m_ChartSpeed=SPEED_FAST;
		if(exact_slow)
		m_ChartSpeed=SPEED_SLOW;
		else
		if(exact_med)
		m_ChartSpeed=SPEED_MEDIUM;
		else
		if(exact_fast)
		m_ChartSpeed=SPEED_FAST;
		//qDebug("Using queue %d (%d) and drawing Tpp %d\n",m_ChartSpeed,CChartQManager::GetChartSpeed(CQT_STRIP, m_ChartSpeed), m_Tpp);
		// now check cursor pos, and update origin so that cursortime is in middle of screen
		// this is more difficult than you might think.. When moving between zoom levels and trying to keep cursors at the correct times.
		COpPanel *pOpPanel=GetOpPanel();
		// set up displaytime with the new TPP Cursortime on the new TPP boundary
		pOpPanel->m_pReplayCursorObject->m_display1Time=pOpPanel->m_pReplayCursoror

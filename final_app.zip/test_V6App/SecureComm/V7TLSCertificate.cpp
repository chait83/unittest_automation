/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsCertificate.cpp
/// @n Description: TLS Certificate
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//
// **************************************************************************
#define SECURITY_WIN32
#include <map>
#include "V7TLSCertificate.h"
#include <algorithm>
#include <vector>
#include "V7CertRAII.h"
#include "V7TLSServCleComm.h"
#include "V7TLSUtilities.h"
#include "wincrypt.h"
#include "V7tstring.h"
#ifdef _WCE_SECTION
	#ifndef V6APP_NOT_INCLUDED
	#include "CertSubjectsStore.h"
	#include "V6globals.h"
	#endif
#else
#include <cryptuiapi.h>
#include <string>
#endif
#ifdef HTDATA_SERVER
	#include "HtDataServer.h"
	#include "V6App_i.h"
#endif
#ifndef _WCE_SECTION
#pragma comment(lib, "Cryptui.lib")
#endif
#pragma comment(lib, "Dnsapi.lib")
//static CertStore userStore{}, machineStore{}; // These stores are intended to stay open and be reused once used // FOR REF
static CertStore userStore; // These stores are intended to stay open and be reused once used
static CertStore machineStore; // These stores are intended to stay open and be reused once used
class CV7StrCompare {
public:
	bool operator()(const std::tstring &first, const std::tstring &second) const {
		int ret;
		ret = first.compare(second);
		return ((bool) ret);
	}
};
typedef std::map<std::tstring, CredHandle, CV7StrCompare> Map_t;
typedef Map_t::iterator MapItr_t;
Map_t credMap = Map_t();
/* Utility functions to help with certificates */
int hex_char_to_int(char c) {
	int result = -1;
	if (('0' <= c) && (c <= '9')) {
		result = c - '0';
	} else if (('A' <= c) && (c <= 'F')) {
		result = 10 + c - 'A';
	} else if (('a' <= c) && (c <= 'f')) {
		result = 10 + c - 'a';
	}
	return result;
}
std::vector<byte> hexToBinary(const char *const str) {
	std::vector<byte> boutput(20);
	byte nibbleValue = 0;
	byte byteValue = 0;
	std::vector<byte>::iterator it = boutput.begin();
	const char *p = str;
	bool highOrder = false;
	while (*p != 0 && str - p < 40 && it != boutput.end()) {
		nibbleValue = static_cast<byte>(hex_char_to_int(*p++));
		if (nibbleValue >= 0) {
			highOrder = !highOrder;
			if (highOrder) {
				byteValue = nibbleValue << 4;
			} else {
				*it = byteValue | nibbleValue;
				it++;
			}
		}
	}
	return boutput;
}
/* ===============================================================================================================
 Section of code supporting CertindexOfCertificateUI which uses CryptUIDlgSelectCertificate a function 
 that is not exported, so you have to link to it dynamically. Also various required structures and
 methods are not in the header file, so they have to be declared. 
 =================================================================================================================*/
typedef
BOOL(WINAPI * PFNCCERTDISPLAYPROC)(
		_In_ PCCERT_CONTEXT pCertContext,
		_In_ HWND hWndSelCertDlg,
		_In_ void *pvCallbackData
);
#ifndef _WCE_SECTION
typedef struct _CRYPTUI_SELECTCERTIFICATE_STRUCT {
	DWORD dwSize;
	HWND hwndParent;
	DWORD dwFlags;
	LPCTSTR szTitle;
	DWORD dwDontUseColumn;
	LPCTSTR szDisplayString;
	PFNCFILTERPROC pFilterCallback;
	PFNCCERTDISPLAYPROC pDisplayCallback;
	void *pvCallbackData;
	DWORD cDisplayStores;
	HCERTSTORE *rghDisplayStores;
	DWORD cStores;
	HCERTSTORE *rghStores;
	DWORD cPropSheetPages;
	LPCPROPSHEETPAGE rgPropSheetPages;
	HCERTSTORE hSelectedCertStore;
} CRYPTUI_SELECTCERTIFICATE_STRUCT, *PCRYPTUI_SELECTCERTIFICATE_STRUCT;
typedef PCCERT_CONTEXT (WINAPI *CryptUIDlgSelectCertificate)(PCRYPTUI_SELECTCERTIFICATE_STRUCT pcsc);
#endif
/*====================================================================================================================
 Make sure the certificate is a valid server certificate, for example, does the name match, do you have a private key,
 is the certificate allowed to be used for server identification 
 ====================================================================================================================*/
BOOL WINAPI ValidServerCert(PCCERT_CONTEXT pCertContext, BOOL *pfInitialSelectedCert, void *pvCallbackData) {
	UNREFERENCED_PARAMETER(pfInitialSelectedCert);
	DWORD cbData = 0;
	std::tstring s = std::tstring(
			_T("Certificate ") + CV7TLSCertificate::instance().GetCertName(pCertContext) + _T("' "));
	if (!CV7TLSCertificate::instance().MatchCertificateName(pCertContext, pvCallbackData)) {
		DebugMsg(s + std::tstring(_T("has wrong subject name.")));
	} else if (!CertGetCertificateContextProperty(pCertContext, CERT_KEY_PROV_INFO_PROP_ID, NULL, &cbData)
			&& GetLastError() == CRYPT_E_NOT_FOUND) {
		DebugMsg(s + _T("has no private key."));
	} else { /* All checks passed now check Enhanced Key Usage */
		cbData = 0;
		CertGetEnhancedKeyUsage(pCertContext, 0, NULL, &cbData);
		if (cbData == 0)
			return TRUE; /* There are no EKU entries, so any usage is allowed */
		else {
			std::vector<byte> Data(cbData);
			PCERT_ENHKEY_USAGE peku = (PCERT_ENHKEY_USAGE)(&Data[0]);
			CertGetEnhancedKeyUsage(pCertContext, 0, peku, &cbData);
			LPSTR *szUsageID = peku->rgpszUsageIdentifier;
			for (DWORD i = 0; i < peku->cUsageIdentifier; i++) {
				if (!strcmp(*szUsageID, szOID_PKIX_KP_SERVER_AUTH))
					return TRUE; /* All checks passed and the certificate is allowed to be used for server identification */
				szUsageID++;
			}
			DebugMsg(s + _T("is not allowed use for server authentication."));
		}
	}
	/* One of the checks failed */
	return FALSE;
}
#ifndef _WCE_SECTION
CryptUIDlgSelectCertificate SelectCertificate = NULL;
SECURITY_STATUS CV7TLSCertificate::CertindexOfServerCertificateUI(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName,
		boolean fUserStore) {
	/* Open a certificate store. */
	HCERTSTORE hCertStore;
	SECURITY_STATUS hr = GetStore(hCertStore, fUserStore);
	if (FAILED(hr))
		return hr;
	/* The caller passed in a certificate context we no longer need, so free it */
	if (pCertContext) {
		CertFreeCertificateContext(pCertContext);
		pCertContext = NULL;
	}
	/* Link to SelectCertificate if it has not already been done */
	if (!SelectCertificate) {
		/* Not linked yet, find the function in the DLL */
		tstring wstrDll;
		wstrDll = _T("CryptUI.dll");
		//HINSTANCE CryptUIDLL = LoadLibrary(wstrDll.c_str()); // CID 1016430: Coverity fix - H196266
		if (NULL == m_hInstCryptUIDLL) {
			m_hInstCryptUIDLL = LoadLibrary(wstrDll.c_str()); // CID 1016430: Coverity fix - H196266
		}
		if (NULL != m_hInstCryptUIDLL) {
#ifdef _UNICODE 
			SelectCertificate = (CryptUIDlgSelectCertificate)GetProcAddress(m_hInstCryptUIDLL, "CryptUIDlgSelectCertificateW");
#else
			SelectCertificate = (CryptUIDlgSelectCertificate) GetProcAddress(m_hInstCryptUIDLL,
					"CryptUIDlgSelectCertificateA");
#endif
		} else {
			return E_NOINTERFACE;
		}
		// Do not call FreeLibrary because the function may be called again later
	}
	/* Display a list of the certificates in the store and allow the user to select a certificate.
	 Note that only certificates which pass the test defined in ValidCert (if any) will be displayed. */
	CRYPTUI_SELECTCERTIFICATE_STRUCT csc;
	HCERTSTORE tempStore = hCertStore;
	csc.dwSize = sizeof csc;
	csc.szTitle = _T("Select a Server Certificate");
	csc.dwDontUseColumn = CRYPTUI_SELECT_LOCATION_COLUMN;
	csc.pFilterCallback = ValidServerCert;
	csc.cDisplayStores = 1;
	csc.rghDisplayStores = &tempStore;
	csc.pvCallbackData = (LPVOID) pszSubjectName;
	if ((pCertContext = SelectCertificate(&csc)) == 0)
		DebugMsg(_T("Select Certificate UI did not return a certificate."));
	return pCertContext ? SEC_E_OK : SEC_E_CERT_UNKNOWN;
}
#endif
/* ==========================================================================================================
 This method is called when the first client tries to connect in order to allow a certificate to be selected to 
 send to the client It has to wait for the client connect request because the client tells the server what identity 
 it expects it to present This is called SNI (Server Name Indication) and it is a relatively new SSL feature
 
 =================================================================================================================*/
SECURITY_STATUS CV7TLSCertificate::SelectServerCert(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName) {
	SECURITY_STATUS status = SEC_E_INVALID_HANDLE;
	DebugMsg(_T(" SelectServerCert for Subject = %s"), pszSubjectName);
	// The next line invokes a UI to let the user select a certificate manually
#ifndef _WCE_SECTION
	//	status = CV7TLSCertificate::instance().CertindexOfServerCertificateUI(pCertContext, pszSubjectName, false);
#endif
	if (!pCertContext) // If we don't already have a certificate, try and select a specific one
		status = CV7TLSCertificate::instance().CertindexOfCertificateBySignature(pCertContext,
				"a9 f4 6e bf 4e 1d 6d 67 2d 2b 39 14 ee ee 58 97 d1 d7 e9 d0", true); // "true" looks in user store, "false", or nothing looks in machine store
	if (!pCertContext) // If we don't already have a certificate, try and select a likely looking one
		status = CV7TLSCertificate::instance().CertindexOfServerCertificateByName(pCertContext, pszSubjectName); // Add "true" to look in user store, "false", or nothing looks in machine store
	if (pCertContext) {
#ifdef _UNICODE
		//std::wcout << L"Server certificate requested for " << pszSubjectName << L", found \"" << CV7TLSCertificate::instance().GetCertName(pCertContext).c_str() << L"\"" << std::endl;
#else
		//std::cout << "Server certificate requested for " << pszSubjectName << ", found \"" << CV7TLSCertificate::instance().GetCertName(pCertContext).c_str() << "\"" << std::endl;
#endif
	}
	// Uncomment the next 2 lines if you want to see details of the selected certificate
	//if (pCertContext)
	//	CV7TLSCertificate::instance().ShowCertInfo(pCertContext, "Server Certificate In Use");
	return status;
}
// This methood is called when a client connection is offered, it returns an indication of whether the certificate (or lack of one) is acceptable 
bool CV7TLSCertificate::ClientCertAcceptable(PCCERT_CONTEXT pCertContext, const bool trusted) {
	//if (trusted)
	//{		
	//	//DebugMsg(_T("A trusted"));		
	//}
	//else
	//{
	//	//DebugMsg(_T("An untrusted"));		
	//}
	//DebugMsg(_T("client certificate was returned for %s "), CV7TLSCertificate::instance().GetCertName(pCertContext).c_str());
	CV7TLSCertificate::instance().GetCertName(pCertContext);
	/* Meaning any certificate is fine, trusted or not, but there must be one */
	return NULL != pCertContext;
}
SECURITY_STATUS CV7TLSCertificate::GetCredHandleFor(std::tstring serverName, SelectServerCertFPTR SelectServerCert,
		PCredHandle phCreds) {
	std::tstring localServerName;
	char name[255] = "\0";
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
		QString   strDbgLog;
#endif
#ifdef _WCE_SECTION
  // serverName = MY_SEERVER_NAME_STRING; //L"XS-904154.TechMahindra.com";
 //Retrieving Device Serial number
		QString   strCertSub(_T("XS-999999"));
	
#if defined (REMOTE_DISPLAY_SERVER) 
		BSTR bstrCertSub;
		pV6AppInterface->GetCertificateDetails(&bstrCertSub); 
		strCertSub = (QString   )bstrCertSub;
		::SysFreeString(bstrCertSub); 
#endif
#ifdef HTDATA_SERVER 
		BSTR bstrCertSub;
		CHtDataServerApp* pApp = (CHtDataServerApp*)AfxGetApp();
		if( NULL != pApp )
		{
			IV6AppInterface *pV6AppInterface	= NULL;
			pV6AppInterface = pApp->GetV6AppInterface();
			if( NULL != pV6AppInterface )
			{
				pV6AppInterface	->GetCertificateDetails(&bstrCertSub);
				strCertSub = (QString   )bstrCertSub;
				::SysFreeString(bstrCertSub);
			}
		}
#endif
	 #ifndef V6APP_NOT_INCLUDED
	 T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock( CONFIG_COMMITTED );
	 BOOL bGlobalCAEnabled = ptCommsData->SecurityOptions.CACertificate;
	 if(bGlobalCAEnabled)
	 {
		 CCertSubjectsStore cCertSubjStore;
		 strCertSub=cCertSubjStore.GetServerSubjectKey();
	 }
	 else
	 {
			strCertSub = QString::asprintf(_T("XS-%06.6d"), pGlbSysInfo->GetSerialNumber());
	 }
	 #endif 
  localServerName = strCertSub;
  serverName = strCertSub;
#else
	QString strCertSub;
	if (serverName.empty()) // There was no hostname supplied
	{
		localServerName = gethostname(name, 254); // GetHostName(); // NEED TO CHECK THIS
		//localServerName = gethostname((char)ComputerNameDnsFullyQualified,254);
		//localServerName= "INHYTCLP00114.TechMahindra.com";
		DebugMsg(_T("  ServerName Empty = %s"), serverName.c_str());
	} else {
		localServerName = serverName;
		DebugMsg(_T("  ServerName Not Empty = %s"), serverName.c_str());
	}
#endif 
	MapItr_t got;
	CV7MyMutex::instance().lockMutex();
	std::tstring strServName(localServerName.begin(), localServerName.end());
	got = credMap.find(strServName);
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
		strDbgLog = QString::asprintf(_T("CV7TLSCertificate:: strServName= %s, got %d "),strServName.c_str(),got);
		LogDebugMessage(strDbgLog);
	#endif
	if (got == credMap.end()) {
		// There were no credentials stored for that host, create some and add them
		PCCERT_CONTEXT pCertContext = NULL;
		SECURITY_STATUS status = SEC_E_INTERNAL_ERROR;
		if (SelectServerCert) {
			status = SelectServerCert(pCertContext, serverName.c_str());
			if (FAILED(status)) {
				DebugMsg(_T("SelectServerCert returned an error = 0x%08x"), status);
				CV7MyMutex::instance().unLockMutex();
				return SEC_E_INTERNAL_ERROR;
			}
		} else {
			/* Add "true" to look in user store, "false", or nothing looks in machine store */
			status = CertindexOfServerCertificateByName(pCertContext, serverName.c_str());
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
			strDbgLog = QString::asprintf(_T("CV7TLSCertificate::CertindexOfServerCertificateByName status= %%lx "),status);
			LogDebugMessage(strDbgLog);
		#endif
		}
		if (SUCCEEDED(status)) {
			CredHandle hServerCred = { 0 };
			status = CreateCredentialsFromCertificate(&hServerCred, pCertContext);
			if (SEC_E_OK == status) {
				credMap.insert(std::pair<std::tstring, CredHandle>(strServName, hServerCred));
				phCreds->dwLower = hServerCred.dwLower;
				phCreds->dwUpper = hServerCred.dwUpper;
			}
			CV7MyMutex::instance().unLockMutex();
			return status; //SEC_E_OK;
		} else {
			DebugMsg(_T("Failed handling server initialization, error = 0x%08x"), status);
			CV7MyMutex::instance().unLockMutex();
			return SEC_E_INTERNAL_ERROR;
		}
	} else {
		phCreds->dwLower = (got->second).dwLower;
		phCreds->dwUpper = (got->second).dwUpper;
		CV7MyMutex::instance().unLockMutex();
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
		strDbgLog = QString::asprintf(_T("CV7TLSCertificate::Skipped certificate!!"));
		LogDebugMessage(strDbgLog);
		#endif
		return SEC_E_OK;
	}
}
/* ==========================================================================================================
 Return an indication of whether a certificate is trusted by asking Windows to validate the
 trust chain (basically asking is the certificate issuer trusted)
 =================================================================================================================*/
HRESULT CV7TLSCertificate::CertTrusted(PCCERT_CONTEXT pCertContext, const bool isClientCert) {
	HTTPSPolicyCallbackData polHttps = { };
	CERT_CHAIN_POLICY_PARA PolicyPara = { };
	CERT_CHAIN_POLICY_STATUS PolicyStatus = { };
	CERT_CHAIN_PARA ChainPara = { };
	PCCERT_CHAIN_CONTEXT pChainContext = NULL;
	HRESULT Status;
	LPSTR rgszUsages[] = { isClientCert ? szOID_PKIX_KP_CLIENT_AUTH : szOID_PKIX_KP_SERVER_AUTH,
			szOID_SERVER_GATED_CRYPTO, szOID_SGC_NETSCAPE };
	DWORD cUsages = _countof(rgszUsages);
	/* Build certificate chain. */
	ChainPara.cbSize = sizeof(ChainPara);
	ChainPara.RequestedUsage.dwType = USAGE_MATCH_TYPE_OR;
	ChainPara.RequestedUsage.Usage.cUsageIdentifier = cUsages;
	ChainPara.RequestedUsage.Usage.rgpszUsageIdentifier = rgszUsages;
	if (!CertGetCertificateChain(NULL, pCertContext, NULL, pCertContext->hCertStore, &ChainPara, 0, NULL,
			&pChainContext)) {
		Status = GetLastError();
		DebugMsg(_T("Error %#x returned by CertGetCertificateChain!"), Status);
		goto cleanup;
	}
	/* Validate certificate chain. */
	polHttps.cbStruct = sizeof(HTTPSPolicyCallbackData);
	polHttps.dwAuthType = isClientCert ? AUTHTYPE_CLIENT : AUTHTYPE_SERVER;
	polHttps.fdwChecks = 0;
	polHttps.pwszServerName = NULL;
	PolicyPara.cbSize = sizeof(PolicyPara);
	PolicyPara.pvExtraPolicyPara = &polHttps;
	PolicyStatus.cbSize = sizeof(PolicyStatus);
	if (!CertVerifyCertificateChainPolicy(CERT_CHAIN_POLICY_SSL, pChainContext, &PolicyPara, &PolicyStatus)) {
		Status = HRESULT_FROM_WIN32(GetLastError());
		DebugMsg(_T("Error %#x returned by CertVerifyCertificateChainPolicy!"), Status);
		goto cleanup;
	}
	if (PolicyStatus.dwError) {
		Status = S_FALSE;
		DebugMsg(_T("PolicyStatus error %#x returned by CertVerifyCertificateChainPolicy!"), PolicyStatus.dwError);
		goto cleanup;
	}
	Status = SEC_E_OK;
	cleanup: if (pChainContext)
		CertFreeCertificateChain(pChainContext);
	return Status;
}
/* =============================================================================================================
 Display a UI with the certificate info and also write it to the debug output
 =================================================================================================================*/
HRESULT CV7TLSCertificate::ShowCertInfo(PCCERT_CONTEXT pCertContext, std::tstring Title) {
	TCHAR pszNameString[256];
	void *pvData;
	DWORD cbData;
	DWORD dwPropId = 0;
#ifndef _WCE_SECTION
	/* Display the certificate. */
	if (!CryptUIDlgViewContext(CERT_STORE_CERTIFICATE_CONTEXT, pCertContext, NULL, (LPWSTR) Title.c_str(), 0,
			pszNameString)) {
		DebugMsg(_T("UI failed."));
	}
#endif  
	if (CertGetNameString(pCertContext, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, NULL, pszNameString, 128)) {
		DebugMsg(_T("111 Certificate for %s"), pszNameString);
	} else {
		DebugMsg(_T("CertGetName failed."));
	}
	int Extensions = pCertContext->pCertInfo->cExtension;
	PCERT_EXTENSION p = pCertContext->pCertInfo->rgExtension;
	/*Loop to find all of the property identifiers for the specified 
	 certificate. The loop continues until 
	 CertEnumCertificateContextProperties returns zero. */
	while (0 != (dwPropId = CertEnumCertificateContextProperties(pCertContext, dwPropId))) {
		/*When the loop is executed, a property identifier has been found.
		 Print the property number. */
		DebugMsg(_T("Property # %d found->"), dwPropId);
		switch (dwPropId) {
		case CERT_FRIENDLY_NAME_PROP_ID: {
			DebugMsg(_T("Friendly name: "));
			break;
		}
		case CERT_SIGNATURE_HASH_PROP_ID: {
			DebugMsg(_T("Signature hash identifier "));
			break;
		}
		case CERT_KEY_PROV_HANDLE_PROP_ID: {
			DebugMsg(_T("KEY PROVE HANDLE"));
			break;
		}
		case CERT_KEY_PROV_INFO_PROP_ID: {
			DebugMsg(_T("KEY PROV INFO PROP ID "));
			break;
		}
		case CERT_SHA1_HASH_PROP_ID: {
			DebugMsg(_T("SHA1 HASH identifier"));
			break;
		}
		case CERT_MD5_HASH_PROP_ID: {
			DebugMsg(_T("md5 hash identifier "));
			break;
		}
		case CERT_KEY_CONTEXT_PROP_ID: {
			DebugMsg(_T("KEY CONTEXT PROP identifier"));
			break;
		}
		case CERT_KEY_SPEC_PROP_ID: {
			DebugMsg(_T("KEY SPEC PROP identifier"));
			break;
		}
		case CERT_ENHKEY_USAGE_PROP_ID: {
			DebugMsg(_T("ENHKEY USAGE PROP identifier"));
			break;
		}
		case CERT_NEXT_UPDATE_LOCATION_PROP_ID: {
			DebugMsg(_T("NEXT UPDATE LOCATION PROP identifier"));
			break;
		}
		case CERT_PVK_FILE_PROP_ID: {
			DebugMsg(_T("PVK FILE PROP identifier "));
			break;
		}
		case CERT_DESCRIPTION_PROP_ID: {
			DebugMsg(_T("DESCRIPTION PROP identifier "));
			break;
		}
		case CERT_ACCESS_STATE_PROP_ID: {
			DebugMsg(_T("ACCESS STATE PROP identifier "));
			break;
		}
		case CERT_SMART_CARD_DATA_PROP_ID: {
			DebugMsg(_T("SMART_CARD DATA PROP identifier "));
			break;
		}
		case CERT_EFS_PROP_ID: {
			DebugMsg(_T("EFS PROP identifier "));
			break;
		}
		case CERT_FORTEZZA_DATA_PROP_ID: {
			DebugMsg(_T("FORTEZZA DATA PROP identifier "));
			break;
		}
		case CERT_ARCHIVED_PROP_ID: {
			DebugMsg(_T("ARCHIVED PROP identifier "));
			break;
		}
		case CERT_KEY_IDENTIFIER_PROP_ID: {
			DebugMsg(_T("KEY IDENTIFIER PROP identifier "));
			break;
		}
		case CERT_AUTO_ENROLL_PROP_ID: {
			DebugMsg(_T("AUTO ENROLL identifier. "));
			break;
		}
		case CERT_ISSUER_PUBLIC_KEY_MD5_HASH_PROP_ID: {
			DebugMsg(_T("ISSUER PUBLIC KEY MD5 HASH identifier. "));
			break;
		}
		} // End switch.
		/* Retrieve information on the property by first getting the 
		 property size. For more information, see CertGetCertificateContextProperty. */
		if (CertGetCertificateContextProperty(pCertContext, dwPropId, NULL, &cbData)) {
			/* Continue. */
		} else {
			/* If the first call to the function failed, exit to an error routine. */
			DebugMsg(_T("Call #1 to CertGetCertificateContextProperty failed."));
			return E_FAIL;
		}
		/* The call succeeded. Use the size to allocate memory for the property. */
		if (cbData > 0) {
			std::vector<char> propertydata(cbData);
			pvData = &propertydata[0];
			/* Allocation succeeded. Retrieve the property data. */
			if (CertGetCertificateContextProperty(pCertContext, dwPropId, pvData, &cbData)) {
				/*The data has been retrieved. Continue.*/
			} else {
				/* If an error occurred in the second call, exit to an error routine.*/
				DebugMsg(_T("Call #2 to CertGetCertificateContextProperty failed."));
				return E_FAIL;
			}
			DebugMsg(_T("The Property Content is"));
			PrintHexDump(cbData, pvData);
		} else {
			DebugMsg(_T("The Property is empty"));
		}
	}
	return S_OK;
}
/* =============================================================================================================
 Create a self-signed certificate and store it in the machine personal store
 =================================================================================================================*/
PCCERT_CONTEXT CV7TLSCertificate::CreateCertificate(bool useMachineStore, LPCTSTR Subject, LPCTSTR FriendlyName,
		LPCTSTR Description, bool forClient) {
	/* CREATE KEY PAIR FOR SELF-SIGNED CERTIFICATE IN MACHINE PROFILE */
	CryptProvider cryptprovider;
	CryptKey key;
	DWORD KeyFlags = useMachineStore ? CRYPT_MACHINE_KEYSET : 0;
	/* Acquire key container */
	DebugMsg(_T("CryptAcquireContext of existing key container... "));
	if (!cryptprovider.AcquireContext(KeyFlags)) {
		int err = GetLastError();
		if (err == NTE_BAD_KEYSET)
			DebugMsg(_T("**** CryptAcquireContext failed with 'bad keyset'"));
		else
			DebugMsg(_T("**** Error 0x%.8x returned by CryptAcquireContext"), err);
		/* Try to create a new key container */
		DebugMsg(_T("CryptAcquireContext create new container... "));
		if (!cryptprovider.AcquireContext(CRYPT_NEWKEYSET | CRYPT_MACHINE_KEYSET)) {
			err = GetLastError();
			if (err == NTE_EXISTS)
				DebugMsg(_T("**** CryptAcquireContext failed with 'already exists', are you running as administrator"));
			else
				DebugMsg(_T("**** Error 0x%.8x returned by CryptAcquireContext"), err);
			DebugMsg(_T("Error 0x%.8x"), GetLastError());
			return 0;
		} else {
			DebugMsg(_T("Success - new container created"));
		}
	} else {
		DebugMsg(_T("Success - container found"));
	}
	// Generate new key pair
	DebugMsg(_T("CryptGenKey... "));
	if (!key.CryptGenKey(cryptprovider)) {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	} else
		DebugMsg(_T("Success"));
	// Create self-signed certificate and add it to personal store in machine or user profile
	std::vector<BYTE> CertName;
	// Encode certificate Subject
#ifdef _UNICODE
	std::wstring X500(_T("CN="));
#else
	std::string X500(_T("CN="));
#endif
	if (Subject)
		X500 += Subject;
	else
		X500 += _T("localuser");
	DWORD cbEncoded = 0;
	// indexOf out how many bytes are needed to encode the certificate
	DebugMsg(_T("CertStrToName... "));
	if (CertStrToName(X509_ASN_ENCODING, X500.c_str(), CERT_X500_NAME_STR, NULL, NULL, &cbEncoded, NULL))
		DebugMsg(_T("Success"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	// Allocate the required space
	CertName.resize(cbEncoded);
	// Encode the certificate
	DebugMsg(_T("CertStrToName... "));
	if (CertStrToName(X509_ASN_ENCODING, X500.c_str(), CERT_X500_NAME_STR, NULL, &CertName[0], &cbEncoded, NULL))
		DebugMsg(_T("Success"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	// Prepare certificate Subject for self-signed certificate
	CERT_NAME_BLOB SubjectIssuerBlob = { 0 };
	SubjectIssuerBlob.cbData = cbEncoded;
	SubjectIssuerBlob.pbData = &CertName[0];
	// Prepare key provider structure for certificate
	CRYPT_KEY_PROV_INFO KeyProvInfo = { 0 };
	QString W
	strKeyW;
	LPWSTR strKeyProvContainer;
#ifndef _UNICODE
	QString A
	strKeyA(cryptprovider.KeyContainerName);
	int cc = 0;
	// get length (cc) of the new widechar excluding the \0 terminator first
	if ((cc = MultiByteToWideChar(CP_UTF8, 0, strKeyA, -1, NULL, 0) - 1) > 0) {
		// convert
		wchar_t *buf = strKeyW.GetBuffer(cc);
		if (buf)
			MultiByteToWideChar(CP_UTF8, 0, strKeyA, -1, buf, cc);
		strKeyW.ReleaseBuffer();
	}
	strKeyProvContainer = (LPWSTR) (LPCWSTR) strKeyW;
#else
	strKeyW=cryptprovider.KeyContainerName;
	strKeyProvContainer = (LPWSTR)(LPCWSTR)strKeyW;
#endif
	KeyProvInfo.pwszContainerName = strKeyProvContainer;
	KeyProvInfo.pwszProvName = NULL;
	KeyProvInfo.dwProvType = PROV_RSA_FULL;
	KeyProvInfo.dwFlags = CRYPT_MACHINE_KEYSET;
	KeyProvInfo.cProvParam = 0;
	KeyProvInfo.rgProvParam = NULL;
	KeyProvInfo.dwKeySpec = AT_SIGNATURE;
	// Prepare algorithm structure for certificate
	CRYPT_ALGORITHM_IDENTIFIER SignatureAlgorithm = { 0 };
	SignatureAlgorithm.pszObjId = szOID_RSA_SHA1RSA;
	// Prepare Expiration date for certificate
	QDateTime EndTime;
	GetSystemTime(&EndTime);
	EndTime.wYear += 5;
	// Create certificate
	DebugMsg(_T("CertCreateSelfSignCertificate... "));
	PCCERT_CONTEXT pCertContext = NULL;
#ifndef _WCE_SECTION
	pCertContext = CertCreateSelfSignCertificate(NULL, &SubjectIssuerBlob, 0, &KeyProvInfo, &SignatureAlgorithm, 0,
			&EndTime, 0);
#endif	
	if (pCertContext)
		DebugMsg(_T("Success"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	// Specify the allowed usage of the certificate (client or server authentication)
	DebugMsg(_T("CertAddEnhancedKeyUsageIdentifier"));
	if (CertAddEnhancedKeyUsageIdentifier(pCertContext,
			forClient ? szOID_PKIX_KP_CLIENT_AUTH : szOID_PKIX_KP_SERVER_AUTH))
		DebugMsg(_T("Success"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	// Common variable used in several calls below
	CRYPT_DATA_BLOB cdblob;
	// Give the certificate a friendly name
	if (FriendlyName)
		cdblob.pbData = (BYTE*) FriendlyName;
	else
		cdblob.pbData = (BYTE*) _T("SSLStream Testing");
	cdblob.cbData = (wcslen((LPWSTR) cdblob.pbData) + 1) * sizeof(WCHAR);
	DebugMsg(_T("CertSetCertificateContextProperty CERT_FRIENDLY_NAME_PROP_ID"));
	if (CertAddEnhancedKeyUsageIdentifier(pCertContext,
			forClient ? szOID_PKIX_KP_CLIENT_AUTH : szOID_PKIX_KP_SERVER_AUTH))
		DebugMsg(_T("Success"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	// Give the certificate a description
	if (Description)
		cdblob.pbData = (BYTE*) Description;
	else if (forClient)
		cdblob.pbData = (BYTE*) _T("SSL Stream Client Test created automatically");
	else
		cdblob.pbData = (BYTE*) _T("SSLStream Server Test created automatically");
	cdblob.cbData = (wcslen((LPWSTR) cdblob.pbData) + 1) * sizeof(WCHAR);
	DebugMsg(_T("CertSetCertificateContextProperty CERT_DESCRIPTION_PROP_ID"));
	if (CertSetCertificateContextProperty(pCertContext, CERT_DESCRIPTION_PROP_ID, 0, &cdblob))
		DebugMsg(_T("Success"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	// Open Personal certificate store for whole machine or individual user
	DebugMsg(_T("Opening root store for writingusing CertOpenStore"));
	CertStore store;
	if (store.CertOpenStore(useMachineStore ? CERT_SYSTEM_STORE_LOCAL_MACHINE : CERT_SYSTEM_STORE_CURRENT_USER))
		DebugMsg(_T("CertOpenStore succeeded"));
	else {
		// Error
		int err = GetLastError();
		if (err == ERROR_ACCESS_DENIED)
			DebugMsg(_T("**** CertOpenStore failed with 'access denied' are you running as administrator?"));
		else
			DebugMsg(_T("**** Error 0x%.8x returned by CertOpenStore"), err);
		return 0;
	}
	// Add the cert to the store
	DebugMsg(_T("CertAddCertificateContextToStore... "));
	if (store.AddCertificateContext(pCertContext))
		DebugMsg(_T("Success"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	// Just for testing, verify that we can access cert's private key
	DebugMsg(_T("CryptAcquireCertificatePrivateKey... "));
	CSP csp;
	if (csp.AcquirePrivateKey(pCertContext))
		DebugMsg(_T("Success, private key acquired"));
	else {
		// Error
		DebugMsg(_T("Error 0x%.8x"), GetLastError());
		return 0;
	}
	return pCertContext;
}
///////////////////////////////////////////////////////////////////
// CLASS CV7TLSCertificate
//////////////////////////////////////////////////////////////////
CV7TLSCertificate::CV7TLSCertificate()
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
: m_pDebugFileLogger(NULL)
#endif
{
	m_hInstCryptUIDLL = NULL; // CID 1016430: Coverity fix - H196266
}
CV7TLSCertificate::~CV7TLSCertificate() {
	if (NULL != m_hInstCryptUIDLL) {
		::FreeLibrary(m_hInstCryptUIDLL); // CID 1016430: Coverity fix - H196266
		m_hInstCryptUIDLL = NULL; // CID 1016430: Coverity fix - H196266
	}
}
CV7TLSCertificate& CV7TLSCertificate::instance() {
	static CV7TLSCertificate singleObj;
	return singleObj;
}
// Open the required user of machine store and cache it so you can hand back handles to it
// The returned handles should NOT be closed after use
SECURITY_STATUS CV7TLSCertificate::GetStore(HCERTSTORE &phStore, bool useUserStore) {
	CertStore *certStore = useUserStore ? &userStore : &machineStore;
	if (!*certStore) {
		if (!certStore->CertOpenStore(
				CERT_STORE_OPEN_EXISTING_FLAG | CERT_STORE_READONLY_FLAG
						| (useUserStore ? CERT_SYSTEM_STORE_CURRENT_USER : CERT_SYSTEM_STORE_LOCAL_MACHINE))) {
			int err = GetLastError();
			if (err == ERROR_ACCESS_DENIED)
				DebugMsg(_T("**** GetStore failed with 'access denied'"));
			else
				DebugMsg(_T("**** Error %d returned by CertOpenStore"), err);
			return HRESULT_FROM_WIN32(err);
		}
	}
	phStore = certStore->get();
	return SEC_E_OK;
}
// Match the required name (HostName) to the name on the certificate pRequiredName, which might be wildcarded
bool CV7TLSCertificate::DnsNameMatches(std::tstring HostName, PCTSTR pRequiredName) {
	//if (DnsNameCompare(HostName.c_str(), pRequiredName)) // The HostName is the RequiredName
	if (_tcscmp(HostName.c_str(), pRequiredName) == 0)
		return true;
	else if (*pRequiredName != L'*') // The RequiredName is not a wildcarded hostname
		return false;
	else // The RequiredName is wildcarded, something like *.unisys.com (wildcards represent whole nodes)
	{
		std::tstring RequiredName(pRequiredName);
		unsigned int suffixLen = HostName.length() - HostName.find(L'.'); // The length of the domain part
		if ((RequiredName.length() != suffixLen + 1) && (RequiredName[0] != L'*')) // our wildcard names must begin with "*..."
			return false;
		else if (RequiredName.length() - RequiredName.find(L'.') != suffixLen) // The two suffix lengths must match
			return false;
		else
			return (HostName.length() - HostName.find(L'.') == suffixLen); // if only the first node differs, we're good to go
	}
}
// See http://etutorials.org/Programming/secure+programming/Chapter+10.+Public+Key+Infrastructure/10.8+Adding+Hostname+Checking+to+Certificate+Verification/
// for a pre C++11 version of this algorithm
bool CV7TLSCertificate::MatchCertificateName(PCCERT_CONTEXT pCertContext, LPCTSTR pszRequiredName) {
/* Try SUBJECT_ALT_NAME2 first
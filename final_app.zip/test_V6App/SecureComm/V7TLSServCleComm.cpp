/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsServCleComm.cpp
/// @n Description: Common Communication function for Server and Client
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//
// **************************************************************************
#define SECURITY_WIN32
//#include "RecrTLSServerProcess.h"
#include "V7TLSDecoder.h"
#include "V7TLSCertificate.h"
#include "V7TLSServCleComm.h"
#include "V7TLSUtilities.h"
#include "V7tstring.h"
#include "Defines.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif
// Global value to optimize access since it is set only once
PSecurityFunctionTable CV7TLSServCleComm::g_pSSPI = NULL;
// Avoid using (or exporting) g_pSSPI directly to give us some flexibility in case we want
// to change implementation later
PSecurityFunctionTable CV7TLSServCleComm::SSPI(void) {
	return g_pSSPI;
}
// Establish SSPI pointer
HRESULT CV7TLSServCleComm::InitializeSSPI(void) {
	g_pSSPI = InitSecurityInterface();
	if (g_pSSPI == NULL) {
		int err = ::GetLastError();
		if (err == 0)
			return E_FAIL;
		else
			return HRESULT_FROM_WIN32(err);
	}
	return S_OK;
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// THIS Constructor Used in Stand alone application with Process class
//CV7TLSServCleComm::CV7TLSServCleComm(QAbstractSocket skt, RecrTLSServerProcess * serverProc) 
//{
//	DebugMsg("Constructor CV7TLSServCleComm(skt,proc)");
//	initReadWriteParameter(skt,serverProc);
//
//	//m_ServerProc->UpdateClientCount();
//	m_SocketStream = this;
//	m_SocketStream->SetTimeoutSeconds(READ_WRITE_TIMEOUT);
//}
// This constructor used for Library
CV7TLSServCleComm::CV7TLSServCleComm(QAbstractSocket skt)
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
: m_pDebugFileLogger(NULL)
#endif
		{
	DebugMsg(_T("Constructor CV7TLSServCleComm(skt)"));
	initReadWriteParameter(skt);
	m_SocketStream = this;
	m_SocketStream->SetTimeoutSeconds(READ_WRITE_TIMEOUT);
}
CV7TLSServCleComm::CV7TLSServCleComm(QAbstractSocket skt, CredHandle *hServerCreds, CtxtHandle *hContext)
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
: m_pDebugFileLogger(NULL)
#endif
		{
	DebugMsg(_T("Constructor CV7TLSServCleComm(skt,hServerCreds,hContext = 0x%.8x)"), hContext);
	initReadWriteParameter(skt);
	m_SocketStream = this;
	m_SocketStream->SetTimeoutSeconds(READ_WRITE_TIMEOUT);
	m_encrypting = true;
	m_hServerCreds.dwLower = hServerCreds->dwLower;
	m_hServerCreds.dwUpper = hServerCreds->dwUpper;
	m_hContext.dwLower = hContext->dwLower;
	m_hContext.dwUpper = hContext->dwUpper;
}
CV7TLSServCleComm::~CV7TLSServCleComm() {
	DebugMsg(_T(" ~CV7TLSServCleComm()"));
	m_SocketStream = NULL;
}
// Init Socket and Read write parameter
//void CV7TLSServCleComm::initReadWriteParameter(QAbstractSocket skt, RecrTLSServerProcess * serverProc)
void CV7TLSServCleComm::initReadWriteParameter(QAbstractSocket skt) {
	m_SocketStream = NULL;
	m_IsConnected = false;
	//m_ServerProc  = serverProc,
	m_LastError = 0;
	m_encrypting = false;
	readBufferBytes = 0;
	readPtr = readBuffer;
	decReadBufferBytes = 0;
	decReadPtr = decReadBuffer;
	/* Read write Parameter */
	m_recvInitiated = false;
	m_lastSocketError = 0;
	m_timeoutSeconds = 1;
	m_actualSocket = skt;
	ZeroMemory(&m_os, sizeof(m_os));
	m_read_event = WSACreateEvent(); // if create fails we should return an error
	WSAResetEvent(m_read_event);
	m_write_event = WSACreateEvent(); // if create fails we should return an error
	WSAResetEvent(m_write_event);
	int rc = 1;
	setsockopt(m_actualSocket, IPPROTO_TCP, TCP_NODELAY, (char*) &rc, sizeof(int));
	//m_hStopEvent = serverProc->getStopEventHandle();
}
// Return the last error value for this CSSLServer
int CV7TLSServCleComm::GetLastError(void) {
	if (m_LastError)
		return m_LastError;
	else
		return m_lastSocketError;
}
// Start Handshake Procedure
bool CV7TLSServCleComm::StartHandShake(void) {
	bool retVal = false;
	SelectServerCert = &CV7TLSCertificate::SelectServerCert;
	ClientCertAcceptable = &CV7TLSCertificate::ClientCertAcceptable;
	HRESULT hr = InitializeConnection();
	if SUCCEEDED(hr)
	{
		m_IsConnected = true;
		retVal = true;
	}
	else
	{
		int err = GetLastError();
		if (hr == SEC_E_INVALID_TOKEN)
		{
			LogWarning(_T("SSL token invalid, perhaps the client rejected our certificate"));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			QString strDbgLog;
			strDbgLog = QString::asprintf(_T("SSL token invalid, perhaps the client rejected our certificate"));
			LogDebugMessage(strDbgLog);
#endif
		}
		else if (hr == CRYPT_E_NOT_FOUND)
		{
			LogWarning(_T("A usable SSL certificate could not be found"));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			QString strDbgLog;
			strDbgLog = QString::asprintf(_T("A usable SSL certificate could not be found"));
			LogDebugMessage(strDbgLog);
#endif
		}
		else if (hr == E_ACCESSDENIED)
		{
			LogWarning(_T("Could not access certificate store, is this program running with administrative privileges?"));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			QString strDbgLog;
			strDbgLog = QString::asprintf(_T("Could not access certificate store, is this program running with administrative privileges?"));
			LogDebugMessage(strDbgLog);
#endif
		}
		else if (hr == SEC_E_UNKNOWN_CREDENTIALS)
		{
			LogWarning(_T("Credentials unknown, is this program running with administrative privileges?"));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			QString strDbgLog;
			strDbgLog = QString::asprintf(_T("Credentials unknown, is this program running with administrative privileges?"));
			LogDebugMessage(strDbgLog);
#endif
		}
		else if (hr == SEC_E_CERT_UNKNOWN)
		{
			LogWarning(_T("The returned client certificate was unacceptable"));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			QString strDbgLog;
			strDbgLog = QString::asprintf(_T("The returned client certificate was unacceptable"));
			LogDebugMessage(strDbgLog);
#endif
		}
		else
		{
			std::tstring m = string_format(_T("SSL could not be used, hr =0x%lx, lasterror=0x%lx"), hr, err);
			LogWarning(m.c_str());
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			QString strDbgLog;
			strDbgLog = QString::asprintf(_T("SSL could not be used, hr =0x%lx, lasterror=0x%lx"), hr, err);
			LogDebugMessage(strDbgLog);
#endif
		}
		retVal = false;
	}
	return (retVal);
}
// Init Security context, and perform handshake
HRESULT CV7TLSServCleComm::InitializeConnection(const void *const lpBuf, const int Len) {
	HRESULT hr = S_OK;
	SECURITY_STATUS scRet;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		QString   strDbgLog;
		strDbgLog = QString::asprintf(_T("InitializeConnection:: Begin"));
		LogDebugMessage(strDbgLog);
	#endif
	if (!g_pSSPI) {
		hr = InitializeSSPI();
	if FAILED(hr)
	return hr;
}
if (!g_pSSPI)
	return E_POINTER;
InitializeReadBuffer(lpBuf, Len);
// Perform SSL handshake
if (!SSPINegotiateLoop()) {
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		//strDbgLog = QString::asprintf(_T("InitializeConnection:: Couldn't connect"));
		//LogDebugMessage(strDbgLog);
		#endif
	if (IsUserAdmin()) {
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE		
			//strDbgLog = QString::asprintf(_T("InitializeConnection:: SSL handshake failed."));
			//LogDebugMessage(strDbgLog);
			#endif
	} else {
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE		
			strDbgLog = QString::asprintf(_T("SSL handshake failed, perhaps because you are not running as administrator."));
			LogDebugMessage(strDbgLog);
			#endif
	}
	int le = GetLastError();
	return le == 0 ? E_FAIL : HRESULT_FROM_WIN32(le);
}
// indexOf out how big the header and trailer will be:
scRet = g_pSSPI->QueryContextAttributes(&m_hContext, SECPKG_ATTR_STREAM_SIZES, &Sizes);
if (scRet != SEC_E_OK) {
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE		
		strDbgLog = QString::asprintf(_T("InitializeConnection::Couldn't get Sizes"));
		LogDebugMessage(strDbgLog);
		#endif
	return E_FAIL;
}
return S_OK;
}
// preload the IO buffer with whatever we already read
void CV7TLSServCleComm::InitializeReadBuffer(const void *const lpBuf, const int Len) {
if (lpBuf && (Len > 0)) { // preload the IO buffer with whatever we already read
	readBufferBytes = Len;
	memcpy_s(readBuffer, sizeof(readBuffer), lpBuf, Len);
} else {
	readBufferBytes = 0;
}
}
BOOL CV7TLSServCleComm::ShutDown(int nHow) {
return ::shutdown(m_actualSocket, nHow);
}
void CV7TLSServCleComm::SetTimeoutSeconds(int NewTimeoutSeconds) {
if (NewTimeoutSeconds > 0) {
	m_timeoutSeconds = NewTimeoutSeconds;
	m_sendEndTime = m_recvEndTime = CTime::GetCurrentTime() + CTimeSpan(0, 0, 0, m_timeoutSeconds);
}
}
HRESULT CV7TLSServCleComm::DisconnectSocket(void) {
return ShutDown() ? HRESULT_FROM_WIN32(GetLastError()) : S_OK;
}
// Receives exactly Len bytes of data and returns the amount received - or QAbstractSocket_ERROR if it times out
int CV7TLSServCleComm::ReceiveBytes(void *const lpBuf, const int Len) {
int bytes_received = 0;
int total_bytes_received = 0;
DebugMsg(_T("CV7TLSServCleComm::ReceiveBytes()"));
m_recvEndTime = CTime::GetCurrentTime() + CTimeSpan(0, 0, 0, m_timeoutSeconds);
while (total_bytes_received < Len) {
	bytes_received = Recv((char*) lpBuf + total_bytes_received, Len - total_bytes_received);
	if (bytes_received == QAbstractSocket_ERROR)
		return QAbstractSocket_ERROR;
	else if (bytes_received == 0)
		break; // socket is closed, no data left to receive
	else {
		total_bytes_received += bytes_received;
	}
}; // loop
return (total_bytes_received);
}
//sends all the data or returns a timeout
int CV7TLSServCleComm::SendBytes(const void *const lpBuf, const int Len) {
DebugMsg(_T("CV7TLSServCleComm::SendBytes()"));
int bytes_sent = 0, total_bytes_sent = 0;
m_recvEndTime = CTime::GetCurrentTime() + CTimeSpan(0, 0, 0, m_timeoutSeconds);
while (total_bytes_sent < Len) {
	bytes_sent = Send((char*) lpBuf + total_bytes_sent, Len - total_bytes_sent);
	if ((bytes_sent == QAbstractSocket_ERROR))
		return QAbstractSocket_ERROR;
	else if (bytes_sent == 0)
		if (total_bytes_sent == 0)
			return QAbstractSocket_ERROR;
		else
			break; // socket is closed, no chance of sending more
	else
		total_bytes_sent += bytes_sent;
}; // loop
return (total_bytes_sent);
}
int CV7TLSServCleComm::Recv(void *const lpBuf, const int Len) {
DebugMsg(_T("CV7TLSServCleComm::Recv() m_encrypting:%d"), m_encrypting);
if (m_encrypting)
	return RecvEncrypted(lpBuf, Len);
else {
	// Not currently encrypting, just receive from the socket
	DebugMsg(_T("Recv called and we are not encrypting"));
	if (readBufferBytes > 0) {	// There is already data in the buffer, so process it first
		DebugMsg(_T("Using the saved %d bytes from client, which may well be encrypted"), readBufferBytes);
		PrintHexDump(readBufferBytes, readPtr);
		if (Len >= int(readBufferBytes)) {
			memcpy_s(lpBuf, Len, readPtr, readBufferBytes);
			int i = readBufferBytes;
			readBufferBytes = 0;
			return i;
		} else {	// More bytes were decoded than the caller requested, so return an error
			m_LastError = WSAEMSGSIZE;
			return QAbstractSocket_ERROR;
		}
	} else {
		int err = m_SocketStream->RecvDataBuffer(lpBuf, Len);
		m_LastError = 0; // Means use the one from m_SocketStream
		if ((err == QAbstractSocket_ERROR) || (err == 0)) {
			if (WSA_IO_PENDING == m_SocketStream->GetLastError())
				DebugMsg(_T("Recv timed out"));
			else if (WSAECONNRESET == m_SocketStream->GetLastError())
				DebugMsg(_T("Recv failed, the socket was closed by the other host"));
			else
				DebugMsg(_T("Recv failed: %ld"), m_SocketStream->GetLastError());
			return QAbstractSocket_ERROR;
		} else {
			DebugMsg(_T("CV7TLSServCleComm::Recv(): Received %d unencrypted bytes from client"), err);
			PrintHexDump(err, lpBuf);
			return err; // normal case, returns received message length
		}
	}
}
}
int CV7TLSServCleComm::decryptReceivedData(void *lpBuf, int Len, bool bInExMode, char **ppExtraBuf, int *pnExtraLen) {
int nRet = 0;
INT i;
SecBufferDesc Message;
SecBuffer Buffers[4];
SECURITY_STATUS scRet = SEC_E_INCOMPLETE_MESSAGE;
int nBytesToReturn = Len;
//
// Initialize security buffer structs, basically, these point to places to put encrypted data,
// for SSL there's a header, some encrypted data, then a trailer. All three get put in the same buffer
// (ReadBuffer) and then decrypted. So one SecBuffer points to the header, one to the data, and one to the trailer.
//
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("decryptReceivedData begin bInExMode %d Msg len %d m_encrypting %d "), bInExMode, Len, m_encrypting);
	LogDebugMessage(strDbgMsg);	
	#endif	
Message.ulVersion = SECBUFFER_VERSION;
Message.cBuffers = 4;
Message.pBuffers = Buffers;
Buffers[0].BufferType = SECBUFFER_EMPTY;
Buffers[1].BufferType = SECBUFFER_EMPTY;
Buffers[2].BufferType = SECBUFFER_EMPTY;
Buffers[3].BufferType = SECBUFFER_EMPTY;
if (readBufferBytes == 0) {
	scRet = SEC_E_INCOMPLETE_MESSAGE;
} else {	// There is already data in the buffer, so process it first
			//DebugMsg(_T("Using the saved %d bytes from client"), readBufferBytes);
			//PrintHexDump(readBufferBytes, readPtr);
	Buffers[0].pvBuffer = readPtr;
	Buffers[0].cbBuffer = readBufferBytes;
	Buffers[0].BufferType = SECBUFFER_DATA;
	scRet = g_pSSPI->DecryptMessage(&m_hContext, &Message, 0, NULL);
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		strDbgMsg = QString::asprintf(_T("Using the saved %d bytes from client scRet 0x%x"),readBufferBytes, scRet);
		LogDebugMessage(strDbgMsg);	
		#endif	
	//readBufferBytes = 0; // We have consumed them
}
if ((scRet == SEC_E_INCOMPLETE_MESSAGE) && (false == bInExMode)) {
	int freeBytesAtStart = static_cast<int>((CHAR*) readPtr - &readBuffer[0]);
	int freeBytesAtEnd = static_cast<int>(sizeof(readBuffer)) - readBufferBytes - freeBytesAtStart;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		strDbgMsg = QString::asprintf(_T("readBufferBytes %d freeBytesAtStart %d freeBytesAtEnd %d"),readBufferBytes, freeBytesAtStart, freeBytesAtEnd);
		LogDebugMessage(strDbgMsg);	
		#endif	
	if (freeBytesAtEnd == 0) // There is no space to add more at the end of the buffer
			{
		if (freeBytesAtStart > 0) // which ought to always be true at this point
				{
			// Move down the existing data to make room for more at the end of the buffer
			memmove_s(readBuffer, sizeof(readBuffer), readPtr, static_cast<int>(sizeof(readBuffer)) - freeBytesAtStart);
			freeBytesAtEnd = freeBytesAtStart;
			readPtr = readBuffer;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
					strDbgMsg = QString::asprintf(_T("Re-adjusted readbuffer readBufferBytes %d freeBytesAtStart %d freeBytesAtEnd %d"),readBufferBytes, freeBytesAtStart, freeBytesAtEnd);
					LogDebugMessage(strDbgMsg);	
					#endif
		} else {
			//DebugMsg(_T("RecvMsg Buffer inexplicably full"));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
					strDbgMsg = QString::asprintf(_T("RecvMsg Buffer inexplicably full nRet %d"), nRet);
					LogDebugMessage(strDbgMsg);	
					#endif	
			//std::cout << "READ 116 scRet: "<< scRet << " readPtr: "<< readPtr <<std::endl;
			return nRet;
		}
	}
	//Copy from the received
	memcpy_s((CHAR*) readPtr + readBufferBytes, freeBytesAtEnd, lpBuf, Len);
	readBufferBytes += Len;
	Buffers[0].pvBuffer = readPtr;
	Buffers[0].cbBuffer = readBufferBytes;
	Buffers[0].BufferType = SECBUFFER_DATA;
	Buffers[1].BufferType = SECBUFFER_EMPTY;
	Buffers[2].BufferType = SECBUFFER_EMPTY;
	Buffers[3].BufferType = SECBUFFER_EMPTY;
	scRet = SSPI()->DecryptMessage(&m_hContext, &Message, 0, NULL);
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		strDbgMsg = QString::asprintf(_T("DecryptMessage attempt scRet 0X%X"), scRet);
		LogDebugMessage(strDbgMsg);	
		#endif
}
if (SEC_E_OK == scRet) {
	PSecBuffer pDataBuffer(NULL); // Points to databuffer if there is one
	//DebugMsg(_T("Decrypted message from client."));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		strDbgMsg = QString::asprintf(_T("Decrypted message from client. scRet 0x%x"), scRet);
		LogDebugMessage(strDbgMsg);	
		#endif
	// Locate the data buffer because the decrypted data is placed there. It's almost certainly
	// the second buffer (index 1) and we start there, but search all but the first just in case...
	for (i = 1; i < 4; i++) {
		if (Buffers[i].BufferType == SECBUFFER_DATA) {
			pDataBuffer = &Buffers[i];
			break;
		}
	}
	if (!pDataBuffer) {
		//DebugMsg(_T("No data returned"));
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			strDbgMsg = QString::asprintf(_T("No data returned scRet 0x%x"), scRet);
			LogDebugMessage(strDbgMsg);	
			#endif
		m_LastError = WSASYSCALLFAILURE;
		return nRet;
	}
	//DebugMsg(_T(" "));
	//DebugMsg(_T("Decrypted message has %d bytes"), pDataBuffer->cbBuffer);
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		strDbgMsg = QString::asprintf(_T("Decrypted message has %d bytes"), pDataBuffer->cbBuffer);
		LogDebugMessage(strDbgMsg);	
		#endif
	//Utilize to copy the max entent of the buffer avaialble then copy remaining in to plain text buf
	if (Len <= V7_TLS_MAX_RECORD_SIZE) {
		if (Len < int(pDataBuffer->cbBuffer)) {
			if (pDataBuffer->cbBuffer <= V7_TLS_MAX_RECORD_SIZE) {
				nBytesToReturn = pDataBuffer->cbBuffer;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
					strDbgMsg = QString::asprintf(_T("Extra %lu bytes decoded will try to adjust in buffer"), (pDataBuffer->cbBuffer-Len));
					LogDebugMessage(strDbgMsg);	
					#endif
			} else {
				nBytesToReturn = V7_TLS_MAX_RECORD_SIZE;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
					strDbgMsg = QString::asprintf(_T("Utilizing the max buf %lu out of decoded %lu"), nBytesToReturn, pDataBuffer->cbBuffer);
					LogDebugMessage(strDbgMsg);	
					#endif					
			}
		} else {
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
				strDbgMsg = QString::asprintf(_T("Decrytpted buffer %lu does fit in transceive buf %lu"), pDataBuffer->cbBuffer, Len);
				LogDebugMessage(strDbgMsg);	
				#endif
			nBytesToReturn = Len;
		}
	} else {
		nBytesToReturn = V7_TLS_MAX_RECORD_SIZE;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			strDbgMsg = QString::asprintf(_T("Len %ld is more than the max buf %lu out of decoded %lu"), Len, nBytesToReturn, pDataBuffer->cbBuffer);
			LogDebugMessage(strDbgMsg);	
			#endif				
	}
	// Move the data to the output stream	
	if (nBytesToReturn >= int(pDataBuffer->cbBuffer)) {
		memcpy_s(lpBuf, pDataBuffer->cbBuffer, pDataBuffer->pvBuffer, pDataBuffer->cbBuffer);
		nBytesToReturn = pDataBuffer->cbBuffer;
	} else {	// More bytes were decoded than the caller requested, so return some, store the rest until the next call
		memcpy_s(lpBuf, nBytesToReturn, pDataBuffer->pvBuffer, nBytesToReturn);
		decReadBufferBytes = pDataBuffer->cbBuffer - nBytesToReturn;
		decReadPtr = decReadBuffer;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			strDbgMsg = QString::asprintf(_T("Extra %d plaintext bytes stored"), decReadBufferBytes);
			LogDebugMessage(strDbgMsg);	
			#endif
		if (memcpy_s(decReadBuffer, sizeof(decReadBuffer), (char*) pDataBuffer->pvBuffer + nBytesToReturn,
				decReadBufferBytes)) {
			m_LastError = WSAEMSGSIZE;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
				strDbgMsg = QString::asprintf(_T("Extra %d plaintext bytes copy error"), decReadBufferBytes);
				LogDebugMessage(strDbgMsg);	
				#endif
			return QAbstractSocket_ERROR;
		} else {
			//pDataBuffer->cbBuffer = nBytesToReturn;//Len; // Pretend we only saw Len bytes
		}
	}
	// See if there was any extra data read beyond what was needed for the message we are handling
	// TCP can sometime merge multiple messages into a single one, if there is, it will amost 
	// certainly be in the fourth buffer (index 3), but search all but the first, just in case.
	PSecBuffer pExtraDataBuffer(NULL);
	for (i = 1; i < 4; i++) {
		if (Buffers[i].BufferType == SECBUFFER_EXTRA) {
			pExtraDataBuffer = &Buffers[i];
			break;
		}
	}
	if (pExtraDataBuffer) {
		//Position of the extra cipher in input buffer
		DWORD dwExCipherPos = readBufferBytes - pExtraDataBuffer->cbBuffer;
		// More data was read than is needed, this happens sometimes with TCP
		/*#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		 strDbgMsg = QString::asprintf(_T("In readBufferBytes %ld Some extra ciphertext was read at %ld (%ld bytes)"), readBufferBytes, dwExCipherPos, pExtraDataBuffer->cbBuffer);
		 LogDebugMessage(strDbgMsg);	
		 #endif*/
		//Check if already processing in exmode (then not expected )
		if (true == bInExMode) {
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
				strDbgMsg = QString::asprintf(_T("Still (not expected) Some extra ciphertext was read (%d bytes)"), pExtraDataBuffer->cbBuffer);
				LogDebugMessage(strDbgMsg);	
				#endif
			readPtr = readBuffer + dwExCipherPos;
			readBufferBytes = pExtraDataBuffer->cbBuffer;
		} else {
			/*Note:The pvBuffer field of the extra buffer does not contain a copy of the excess data.
			 If you receive an extra buffer from a SSPI function, 
			 you must remove the already processed information from the input buffer and call the function again. 
			 Schannel can, and often does, return only the extra buffer and nothing else in the output buffers.*/
			//shift buffer 
			memmove_s(readBuffer, sizeof(readBuffer), readBuffer + dwExCipherPos, pExtraDataBuffer->cbBuffer);
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
				strDbgMsg = QString::asprintf(_T("In readBufferBytes %ld Extra ciphertext pos %ld and size %ld bytes)"), readBufferBytes, dwExCipherPos, pExtraDataBuffer->cbBuffer);
				LogDebugMessage(strDbgMsg);	
				#endif
			// Remember (where the) how much data is for next time
			readBufferBytes = pExtraDataBuffer->cbBuffer;
			//Set the buffer position
			readPtr = readBuffer; //pExtraDataBuffer->pvBuffer;
			if ((NULL != ppExtraBuf) && (NULL != pnExtraLen)) {
				//Have the buffer to get extra bytes if decoded successfully
				char *pExtrabuf = new char[readBufferBytes];
				memset(pExtrabuf, 0, readBufferBytes);
				int nExtraRet = 0;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
					strDbgMsg = QString::asprintf(_T("ExMode ::decryptReceivedData begin %ld Extrabytes)"), readBufferBytes);
					LogDebugMessage(strDbgMsg);	
					#endif
				//Attempt to decrypt the extra buf and collect decoded bytes (recurceive)
				nExtraRet = decryptReceivedData(pExtrabuf, readBufferBytes, true, NULL, NULL);
				if (nExtraRet > 0) {
					//Set the out put extra buffers
					*ppExtraBuf = pExtrabuf;
					*pnExtraLen = nExtraRet;
				} else {
					//Its not a complete packet discard
					delete[] pExtrabuf;
					pExtrabuf = NULL;
				}
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
					strDbgMsg = QString::asprintf(_T("ExMode ::decryptReceivedData end Extra Decrypted %ld)"), nExtraRet);
					LogDebugMessage(strDbgMsg);	
					#endif
			}
		}
	} else {
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
			strDbgMsg = QString::asprintf(_T("No extra ciphertext was read"));
			LogDebugMessage(strDbgMsg);	
			#endif
		readBufferBytes = 0;
		readPtr = readBuffer;
	}
	nRet = nBytesToReturn; //pDataBuffer->cbBuffer;
} else if (scRet != SEC_E_INCOMPLETE_MESSAGE) {
	//Failed to decrypt the Message..
	//Ignore the packet and reset the buffer
	readBufferBytes = 0;
	readPtr = readBuffer;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		strDbgMsg = QString::asprintf(_T("decryptReceivedData failed bInExMode %d scRet 0x%x"), bInExMode, scRet);
		LogDebugMessage(strDbgMsg);	
		#endif
}
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
	strDbgMsg = QString::asprintf(_T("decryptReceivedData end bInExMode %d nRet %d"), bInExMode, nRet);
	LogDebugMessage(strDbgMsg);	
	#endif
return nRet;
}
// Receive an encrypted message, decrypt it, and return the resulting plaintext
int CV7TLSServCleComm::RecvEncrypted(void *const lpBuf, const int Len) {
INT err;
INT i;
SecBufferDesc Message;
SecBuffer Buffers[4];
SECURITY_STATUS scRet;
//
// Initialize security buffer structs, basically, these point to places to put encrypted data,
// for SSL there's a header, some encrypted data, then a trailer. All three get put in the same buffer
// (ReadBuffer) and then decrypted. So one SecBuffer points to the header, one to the data, and one to the trailer.
//
DebugMsg(_T("CV7TLSServCleComm::RecvEncrypted() m_encrypting:%d"), m_encrypting);
Message.ulVersion = SECBUFFER_VERSION;
Message.cBuffers = 4;
Message.pBuffers = Buffers;
Buffers[0].BufferType = SECBUFFER_EMPTY;
Buffers[1].BufferType = SECBUFFER_EMPTY;
Buffers[2].BufferType = SECBUFFER_EMPTY;
Buffers[3].BufferType = SECBUFFER_EMPTY;
if (readBufferBytes == 0)
	scRet = SEC_E_INCOMPLETE_MESSAGE;
else {	// There is already data in the buffer, so process it first
	DebugMsg(_T(" "));
	DebugMsg(_T("Using the saved %d bytes from client"), readBufferBytes);
	PrintHexDump(readBufferBytes, readPtr);
	Buffers[0].pvBuffer = readPtr;
	Buffers[0].cbBuffer = readBufferBytes;
	Buffers[0].BufferType = SECBUFFER_DATA;
	scRet = g_pSSPI->DecryptMessage(&m_hContext, &Message, 0, NULL);
	readBufferBytes = 0; // We have consumed them
}
while (scRet == SEC_E_INCOMPLETE_MESSAGE) {
	err = m_SocketStream->RecvDataBuffer((CHAR*) readPtr + readBufferBytes,
			sizeof(readBuffer) - readBufferBytes - ((CHAR*) readPtr - &readBuffer[0]));
	if ((err == QAbstractSocket_ERROR) || (err == 0)) {
		if (WSA_IO_PENDING == GetLastError())
			DebugMsg(_T("Recv timed out"));
		else if (WSAECONNRESET == GetLastError())
			DebugMsg(_T("Recv failed, the socket was closed by the other host"));
		else
			DebugMsg(_T("Recv failed: %ld"), GetLastError());
		return QAbstractSocket_ERROR;
	}
	DebugMsg(_T(" "));
	DebugMsg(_T("CV7TLSServCleComm::RecvEncrypted(): Received %d encrypted bytes from client"), err);
	PrintHexDump(err, (CHAR*) readPtr + readBufferBytes);
	readBufferBytes += err;
	Buffers[0].pvBuffer = readPtr;
	Buffers[0].cbBuffer = readBufferBytes;
	Buffers[0].BufferType = SECBUFFER_DATA;
	Buffers[1].BufferType = SECBUFFER_EMPTY;
	Buffers[2].BufferType = SECBUFFER_EMPTY;
	Buffers[3].BufferType = SECBUFFER_EMPTY;
	// This is a horrible kludge because apparently DecryptMessage isn't smart enough to recognize a
	// shutdown message with other data concatenated
	const int headerLen = 5, shutdownLen = 26;
	if (((CHAR*) readPtr)[0] == 21 // Alert message type
	&& readBufferBytes > (shutdownLen + headerLen) // Could be a shutdown message followed by something else
	&& ((CHAR*) readPtr)[3] == 0 && ((CHAR*) readPtr)[4] == shutdownLen // the first message is the correct length for a shutdown message
	&& ((CHAR*) readPtr)[5] == 0 // it is a "close notify" (aka shutdown) message
			) {
		DebugMsg(_T("Looks like a concatenated shutdown message and something else"));
		PrintHexDump(err, readPtr, true);
		Buffers[0].cbBuffer = shutdownLen + headerLen;
		scRet = g_pSSPI->DecryptMessage(&m_hContext, &Message, 0, NULL);
		if (scRet == SEC_I_CONTEXT_EXPIRED) {
			Buffers[1].pvBuffer = (CHAR*) readPtr + shutdownLen + headerLen;
			Buffers[1].cbBuffer = readBufferBytes - shutdownLen - headerLen;
			Buffers[1].BufferType = SECBUFFER_EXTRA;
		}
	} else // The normal case
	{
		scRet = g_pSSPI->DecryptMessage(&m_hContext, &Message, 0, NULL);
	}
}
PSecBuffer pDataBuffer(NULL); // Points to databuffer if there is one
if (scRet == SEC_E_OK) {
	DebugMsg(_T("Decrypted message from client."));
	// Locate the data buffer because the decrypted data is placed there. It's almost certainly
	// the second buffer (index 1) and we start there, but search all but the first just in case...
	for (i = 1; i < 4; i++) {
		if (Buffers[i].BufferType == SECBUFFER_DATA) {
			pDataBuffer = &Buffers[i];
			break;
		}
	}
	if (!pDataBuffer) {
		DebugMsg(_T("No data returned"));
		m_LastError = WSASYSCALLFAILURE;
		return QAbstractSocket_ERROR;
	}
	DebugMsg(_T(" "));
	DebugMsg(_T("Decrypted message has %d bytes"), pDataBuffer->cbBuffer);
	PrintHexDump(pDataBuffer->cbBuffer, pDataBuffer->pvBuffer);
	// Move the data to the output stream
	if (Len >= int(pDataBuffer->cbBuffer))
		memcpy_s(lpBuf, Len, pDataBuffer->pvBuffer, pDataBuffer->cbBuffer);
	else {	// More bytes were decoded than the caller requested, so return an error
		m_LastError = WSAEMSGSIZE;
		return QAbstractSocket_ERROR;
	}
} else if (scRet == SEC_I_CONTEXT_EXPIRED) {
	DebugMsg(_T("Notified that SSL disabled"));
	m_LastError = scRet;
	m_encrypting = false;
} else {
	DebugMsg(_T("Couldn't decrypt 2, error %lx"), scRet);
	readBufferBytes = 0; // Assume they have all been consumed
	return QAbstractSocket_ERROR;
}
// See if there was any extra data read beyond what was needed for the message we are handling
// TCP can sometime merge multiple messages into a single one, if there is, it will almost 
// certainly be in the fourth buffer (index 3), but search all but the first, just in case.
// This does not work with a shutdown message - if it is concatenated with a following plaintext
// the decryption just fails with a "cannot decrypt" error, which is why it has special handling above.
PSecBuffer pExtraDataBuffer(NULL);
for (i = 1; i < 4; i++) {
	if (Buffers[i].BufferType == SECBUFFER_EXTRA) {
		pExtraDataBuffer = &Buffers[i];
		break;
	}
}
if (pExtraDataBuffer) {	// More data was read than is needed, this happens sometimes with TCP
	DebugMsg(_T(" "));
	DebugMsg(_T("Some extra data was read (%d bytes)"), pExtraDataBuffer->cbBuffer);
	// Remember where the data is for next time
	readBufferBytes = pExtraDataBuffer->cbBuffer;
	readPtr = pExtraDataBuffer->pvBuffer;
} else {
	DebugMsg(_T("No extra data was read"));
	readBufferBytes = 0;
	readPtr = readBuffer;
}
return (pDataBuffer) ? pDataBuffer->cbBuffer : 0;
}
int CV7TLSServCleComm::Send(const void *const lpBuf, const int Len) {
INT err;
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
	QString   strDbgLog;
	//strDbgLog = QString::asprintf(_T("CV7TLSServCleComm::Send() m_encrypting %d len %d"), m_encrypting, Len);
	//LogDebugMessage(strDbgLog);
#endif
if (m_encrypting)
	return SendEncrypted(lpBuf, Len);
else {
	err = m_SocketStream->SendDataBuffer(lpBuf, Len);
	m_LastError = 0;
	DebugMsg(_T("Send %d Plain bytes to client"), Len);
	PrintHexDump(Len, lpBuf);
	if (err == QAbstractSocket_ERROR) {
		DebugMsg(_T("Send failed: %ld"), m_SocketStream->GetLastError());
		return QAbstractSocket_ERROR;
	}
	return Len;
}
}
// Send an encrypted message containing an encrypted version of 
// whatever plaintext data the caller provides
int CV7TLSServCleComm::SendEncrypted(const void *const lpBuf, const int Len) {
DebugMsg(_T("CV7TLSServCleComm::SendEncrypted() m_encrypting:%d"), m_encrypting);
if (!lpBuf || Len > MaxMsgSize)
	return QAbstractSocket_ERROR;
if (!m_encrypting) {
	DebugMsg(_T("Send can only be called when encrypting"));
	m_LastError = ERROR_FILE_NOT_ENCRYPTED;
	return QAbstractSocket_ERROR;
}
INT err = 0;
SecBufferDesc Message;
SecBuffer Buffers[4];
SECURITY_STATUS scRet;
Message.ulVersion = SECBUFFER_VERSION;
Message.cBuffers = 4;
Message.pBuffers = Buffers;
Buffers[0].BufferType = SECBUFFER_EMPTY;
Buffers[1].BufferType = SECBUFFER_EMPTY;
Buffers[2].BufferType = SECBUFFER_EMPTY;
Buffers[3].BufferType = SECBUFFER_EMPTY;
/* Put the message in the right place in the buffer */
memcpy_s(writeBuffer + Sizes.cbHeader, sizeof(writeBuffer) - Sizes.cbHeader - Sizes.cbTrailer, lpBuf, Len);
Buffers[0].pvBuffer = writeBuffer;
Buffers[0].cbBuffer = Sizes.cbHeader;
Buffers[0].BufferType = SECBUFFER_STREAM_HEADER;
Buffers[1].pvBuffer = writeBuffer + Sizes.cbHeader;
Buffers[1].cbBuffer = Len;
Buffers[1].BufferType = SECBUFFER_DATA;
Buffers[2].pvBuffer = writeBuffer + Sizes.cbHeader + Len;
Buffers[2].cbBuffer = Sizes.cbTrailer;
Buffers[2].BufferType = SECBUFFER_STREAM_TRAILER;
Buffers[3].BufferType = SECBUFFER_EMPTY;
scRet = g_pSSPI->EncryptMessage(&m_hContext, 0, &Message, 0);
DebugMsg(_T(" "));
DebugMsg(_T("Plaintext message has %d bytes"), Len);
PrintHexDump(Len, lpBuf);
if (FAILED(scRet)) {
	DebugMsg(_T("EncryptMessage failed with %#x"), scRet);
	m_LastError = scRet;
	return QAbstractSocket_ERROR;
}
err = m_SocketStream->SendDataBuffer(writeBuffer, Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
m_LastError = 0;
DebugMsg(_T("Send %d encrypted bytes to client"), Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
PrintHexDump(Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer, writeBuffer);
if (err == QAbstractSocket_ERROR)
{
DebugMsg(_T("Send failed: %ld"), m_SocketStream->GetLastError());
return QAbstractSocket_ERROR;
}

// File to test the structure alignment
#include "CMMDefines.h"
#include "V6Config.h"
#include "TraceMsg.h"
#include "ConfigurationManager.h"

/*
 Function Name : testV6ConfigStructures
 Prototype	: BOOL testV6ConfigStructures()
 Parameters : None
 Return Value:
 TRUE - if the configuration structures are properly 4 byte packed.
 FALSE - if the configuration structures are misaligned.
 */
BOOL testV6ConfigStructures() {
	DWORD dwstructsize = 0;
	BOOL bRet = TRUE;
	GetSizeOfBlockType(BLK_TV5TIMESETUP, &dwstructsize);
    CTracer* msg = CTracer::Instance();
	if (dwstructsize != sizeof(T_TV5TIMESETUP)) {
		bRet = FALSE;
        msg->OutputDebugTrace(TRACE_2_FILE + TRACE_ALWAYS, "T_TV5TIMESETUP - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
        LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TV5TIMESETUP - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TVTIMESETUP, &dwstructsize);
	if (dwstructsize != sizeof(T_TVTIMESETUP)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TVTIMESETUP - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TVTIMESETUP - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SCREENMETRICS, &dwstructsize);
	if (dwstructsize != sizeof(T_SCREENMETRICS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCREENMETRICS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCREENMETRICS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_IPADDRESS, &dwstructsize);
	if (dwstructsize != sizeof(T_IPADDRESS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_IPADDRESS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_IPADDRESS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_NUMFORMAT, &dwstructsize);
	if (dwstructsize != sizeof(T_NUMFORMAT)) {
		bRet = FALSE;
        LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_NUMFORMAT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_NUMFORMAT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LINESTYLE, &dwstructsize);
	if (dwstructsize != sizeof(T_LINESTYLE)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LINESTYLE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LINESTYLE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_WEEKDAYEVENT, &dwstructsize);
	if (dwstructsize != sizeof(T_WEEKDAYEVENT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_WEEKDAYEVENT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_WEEKDAYEVENT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BOOTLACESRAM, &dwstructsize);
	if (dwstructsize != sizeof(T_BOOTLACESRAM)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOOTLACESRAM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOOTLACESRAM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BOOTLACEFLASH, &dwstructsize);
	if (dwstructsize != sizeof(T_BOOTLACEFLASH)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOOTLACEFLASH - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOOTLACEFLASH - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RECPROD, &dwstructsize);
	if (dwstructsize != sizeof(T_RECPROD)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECPROD - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECPROD - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_IELPARAMS, &dwstructsize);
	if (dwstructsize != sizeof(T_IELPARAMS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_IELPARAMS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_IELPARAMS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_FIRMOPTIONS, &dwstructsize);
	if (dwstructsize != sizeof(T_FIRMOPTIONS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FIRMOPTIONS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FIRMOPTIONS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RECLOCAL, &dwstructsize);
	if (dwstructsize != sizeof(T_RECLOCAL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECLOCAL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECLOCAL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_GENNONVOL, &dwstructsize);
	if (dwstructsize != sizeof(T_GENNONVOL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_GENNONVOL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_GENNONVOL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_VERSIONNUM, &dwstructsize);
	if (dwstructsize != sizeof(T_VERSIONNUM)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_VERSIONNUM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_VERSIONNUM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BOARDDETAILS, &dwstructsize);
	if (dwstructsize != sizeof(T_BOARDDETAILS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOARDDETAILS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOARDDETAILS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RANGEINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_RANGEINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RANGEINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RANGEINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_AISLOTINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_AISLOTINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AISLOTINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AISLOTINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SLOTINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_SLOTINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SLOTINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SLOTINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_DEVICECAPS, &dwstructsize);
	if (dwstructsize != sizeof(T_DEVICECAPS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DEVICECAPS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DEVICECAPS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CHARTINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_CHARTINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHARTINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHARTINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LOGGINGINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_LOGGINGINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOGGINGINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOGGINGINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SCREENGENERAL, &dwstructsize);
	if (dwstructsize != sizeof(T_SCREENGENERAL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCREENGENERAL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCREENGENERAL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SOUNDS, &dwstructsize);
	if (dwstructsize != sizeof(T_SOUNDS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SOUNDS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SOUNDS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TABULARDISPLAY, &dwstructsize);
	if (dwstructsize != sizeof(T_TABULARDISPLAY)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TABULARDISPLAY - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TABULARDISPLAY - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RECPROFILE, &dwstructsize);
	if (dwstructsize != sizeof(T_RECPROFILE)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECPROFILE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECPROFILE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CHANGEHEADER, &dwstructsize);
	if (dwstructsize != sizeof(T_CHANGEHEADER)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANGEHEADER - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANGEHEADER - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_P2P, &dwstructsize);
	if (dwstructsize != sizeof(T_P2P)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_P2P - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_P2P - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RS485PORT, &dwstructsize);
	if (dwstructsize != sizeof(T_RS485PORT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RS485PORT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RS485PORT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_NETWORK, &dwstructsize);
	if (dwstructsize != sizeof(T_NETWORK)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_NETWORK - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_NETWORK - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MODBUSTX, &dwstructsize);
	if (dwstructsize != sizeof(T_MODBUSTX)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSTX - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSTX - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MODBUSSLAVEDEV, &dwstructsize);
	if (dwstructsize != sizeof(T_MODBUSSLAVEDEV)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSSLAVEDEV - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSSLAVEDEV - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MODBUSMASTER, &dwstructsize);
	if (dwstructsize != sizeof(T_MODBUSMASTER)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSMASTER - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSMASTER - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MODBUSDEVICE, &dwstructsize);
	if (dwstructsize != sizeof(T_MODBUSDEVICE)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSDEVICE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MODBUSDEVICE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TRENDBUSDEVICE, &dwstructsize);
	if (dwstructsize != sizeof(T_TRENDBUSDEVICE)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TRENDBUSDEVICE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TRENDBUSDEVICE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SNTPSERVER, &dwstructsize);
	if (dwstructsize != sizeof(T_SNTPSERVER)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SNTPSERVER - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SNTPSERVER - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LANINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_LANINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LANINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LANINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_EMAIL, &dwstructsize);
	if (dwstructsize != sizeof(T_EMAIL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EMAIL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EMAIL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_FTP, &dwstructsize);
	if (dwstructsize != sizeof(T_FTP)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FTP - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FTP - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_OPCUA, &dwstructsize);
	if (dwstructsize != sizeof(T_OPCUA)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_OPCUA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_OPCUA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SECURITYOPTIONS, &dwstructsize);
	if (dwstructsize != sizeof(T_SECURITYOPTIONS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SECURITYOPTIONS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SECURITYOPTIONS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_COMMUNICATIONS, &dwstructsize);
	if (dwstructsize != sizeof(T_COMMUNICATIONS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_COMMUNICATIONS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_COMMUNICATIONS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LOADSAVEMEDIA, &dwstructsize);
	if (dwstructsize != sizeof(T_LOADSAVEMEDIA)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOADSAVEMEDIA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOADSAVEMEDIA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_ERRORCONTROL, &dwstructsize);
	if (dwstructsize != sizeof(T_ERRORCONTROL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_ERRORCONTROL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_ERRORCONTROL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_GROUPINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_GROUPINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_GROUPINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_GROUPINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BATCH, &dwstructsize);
	if (dwstructsize != sizeof(T_BATCH)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BATCH - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BATCH - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PRINTERSET, &dwstructsize);
	if (dwstructsize != sizeof(T_PRINTERSET)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PRINTERSET - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PRINTERSET - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RESETACTIONS, &dwstructsize);
	if (dwstructsize != sizeof(T_RESETACTIONS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RESETACTIONS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RESETACTIONS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LTELEMENT, &dwstructsize);
	if (dwstructsize != sizeof(T_LTELEMENT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LTELEMENT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LTELEMENT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LOOKUPTABLE, &dwstructsize);
	if (dwstructsize != sizeof(T_LOOKUPTABLE)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOOKUPTABLE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOOKUPTABLE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MESSAGECFG, &dwstructsize);
	if (dwstructsize != sizeof(T_MESSAGECFG)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MESSAGECFG - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MESSAGECFG - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_FURNACE, &dwstructsize);
	if (dwstructsize != sizeof(T_FURNACE)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FURNACE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FURNACE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SETPOINT, &dwstructsize);
	if (dwstructsize != sizeof(T_SETPOINT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SETPOINT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SETPOINT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_STABILITYDETECT, &dwstructsize);
	if (dwstructsize != sizeof(T_STABILITYDETECT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_STABILITYDETECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_STABILITYDETECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_FURNACESCONFIG, &dwstructsize);
	if (dwstructsize != sizeof(T_FURNACESCONFIG)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FURNACESCONFIG - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_FURNACESCONFIG - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_GENERALCONFIG, &dwstructsize);
	if (dwstructsize != sizeof(T_GENERALCONFIG)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_GENERALCONFIG - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_GENERALCONFIG - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SESSIONINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_SESSIONINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SESSIONINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SESSIONINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_DIGITALMASK, &dwstructsize);
	if (dwstructsize != sizeof(T_DIGITALMASK)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DIGITALMASK - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DIGITALMASK - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_ROLLINGAVERAGES, &dwstructsize);
	if (dwstructsize != sizeof(T_ROLLINGAVERAGES)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_ROLLINGAVERAGES - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_ROLLINGAVERAGES - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SCALEINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_SCALEINFO)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCALEINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCALEINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_ALARM, &dwstructsize);
	if (dwstructsize != sizeof(T_ALARM)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_ALARM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_ALARM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TOTAL, &dwstructsize);
	if (dwstructsize != sizeof(T_TOTAL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TOTAL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TOTAL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LOGGING, &dwstructsize);
	if (dwstructsize != sizeof(T_LOGGING)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOGGING - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LOGGING - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PEN, &dwstructsize);
	if (dwstructsize != sizeof(T_PEN)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PEN - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PEN - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SCHEDEVENTDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_SCHEDEVENTDATA)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCHEDEVENTDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_SCHEDEVENTDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PENALARMDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_PENALARMDATA)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PENALARMDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PENALARMDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_EVENTDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_EVENTDATA)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_EVENTCAUSE, &dwstructsize);
	if (dwstructsize != sizeof(T_EVENTCAUSE)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTCAUSE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTCAUSE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_EVENTEFFECT, &dwstructsize);
	if (dwstructsize != sizeof(T_EVENTEFFECT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTEFFECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTEFFECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_EVENT, &dwstructsize);
	if (dwstructsize != sizeof(T_EVENT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TIMESYNC, &dwstructsize);
	if (dwstructsize != sizeof(T_TIMESYNC)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TIMESYNC - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TIMESYNC - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_EVENTSYSTEM, &dwstructsize);
	if (dwstructsize != sizeof(T_EVENTSYSTEM)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTSYSTEM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_EVENTSYSTEM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_COUNTERSDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_COUNTERSDATA)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_COUNTERSDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_COUNTERSDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_COUNTERS, &dwstructsize);
	if (dwstructsize != sizeof(T_COUNTERS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_COUNTERS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_COUNTERS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_REPORTDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_REPORTDATA)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_REPORTDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_REPORTDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_REPORTS, &dwstructsize);
	if (dwstructsize != sizeof(T_REPORTS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_REPORTS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_REPORTS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CHANCALPOINT, &dwstructsize);
	if (dwstructsize != sizeof(T_CHANCALPOINT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANCALPOINT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANCALPOINT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_IORANGECAL, &dwstructsize);
	if (dwstructsize != sizeof(T_IORANGECAL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_IORANGECAL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_IORANGECAL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CHANCJCCAL, &dwstructsize);
	if (dwstructsize != sizeof(T_CHANCJCCAL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANCJCCAL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANCJCCAL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CHANNELCALS, &dwstructsize);
	if (dwstructsize != sizeof(T_CHANNELCALS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANNELCALS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_CHANNELCALS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BOARDCALS, &dwstructsize);
	if (dwstructsize != sizeof(T_BOARDCALS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOARDCALS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_BOARDCALS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RECORDERCAL, &dwstructsize);
	if (dwstructsize != sizeof(T_RECORDERCAL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECORDERCAL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RECORDERCAL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LINEARCHAN, &dwstructsize);
	if (dwstructsize != sizeof(T_LINEARCHAN)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LINEARCHAN - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_LINEARCHAN - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TCCHANITEM, &dwstructsize);
	if (dwstructsize != sizeof(T_TCCHANITEM)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TCCHANITEM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TCCHANITEM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_RTCHANITEM, &dwstructsize);
	if (dwstructsize != sizeof(T_RTCHANITEM)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RTCHANITEM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_RTCHANITEM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_AICHANNEL, &dwstructsize);
	if (dwstructsize != sizeof(T_AICHANNEL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AICHANNEL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AICHANNEL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_AMS2750TCCAL, &dwstructsize);
	if (dwstructsize != sizeof(T_AMS2750TCCAL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750TCCAL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750TCCAL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_AMS2750SENSOR, &dwstructsize);
	if (dwstructsize != sizeof(T_AMS2750SENSOR)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750SENSOR - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750SENSOR - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_AMS2750SENSORS, &dwstructsize);
	if (dwstructsize != sizeof(T_AMS2750SENSORS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750SENSORS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750SENSORS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MPCALPOINT, &dwstructsize);
	if (dwstructsize != sizeof(T_MPCALPOINT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MPCALPOINT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MPCALPOINT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MPCALCHANNEL, &dwstructsize);
	if (dwstructsize != sizeof(T_MPCALCHANNEL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MPCALCHANNEL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MPCALCHANNEL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_MPCALCHANNELS, &dwstructsize);
	if (dwstructsize != sizeof(T_MPCALCHANNELS)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MPCALCHANNELS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_MPCALCHANNELS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_AMS2750CALCFG, &dwstructsize);
	if (dwstructsize != sizeof(T_AMS2750CALCFG)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750CALCFG - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AMS2750CALCFG - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_AOCHANNEL, &dwstructsize);
	if (dwstructsize != sizeof(T_AOCHANNEL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AOCHANNEL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_AOCHANNEL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_DIGOUTCHANITEM, &dwstructsize);
	if (dwstructsize != sizeof(T_DIGOUTCHANITEM)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DIGOUTCHANITEM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DIGOUTCHANITEM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_DIGCHANNEL, &dwstructsize);
	if (dwstructsize != sizeof(T_DIGCHANNEL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DIGCHANNEL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DIGCHANNEL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PULSECHANNEL, &dwstructsize);
	if (dwstructsize != sizeof(T_PULSECHANNEL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PULSECHANNEL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_PULSECHANNEL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_DEMOCHANNEL, &dwstructsize);
	if (dwstructsize != sizeof(T_DEMOCHANNEL)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DEMOCHANNEL - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_DEMOCHANNEL - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TOPSLOT, &dwstructsize);
	if (dwstructsize != sizeof(T_TOPSLOT)) {
		bRet = FALSE;
		LOG_WRN(TRACE_2_FILE + TRACE_ALWAYS, "T_TOPSLOT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_TOPSLOT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BOTTOMSLOT, &dwstructsize);
	if (dwstructsize != sizeof(T_BOTTOMSLOT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_BOTTOMSLOT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_BOTTOMSLOT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CARDLAYOUT, &dwstructsize);
	if (dwstructsize != sizeof(T_CARDLAYOUT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_CARDLAYOUT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_CARDLAYOUT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PWDNETSYNCINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_PWDNETSYNCINFO)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_PWDNETSYNCINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_PWDNETSYNCINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_USERINFO, &dwstructsize);
	if (dwstructsize != sizeof(T_USERINFO)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_USERINFO - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_USERINFO - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SECUREPWD, &dwstructsize);
	if (dwstructsize != sizeof(T_SECUREPWD)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_SECUREPWD - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_SECUREPWD - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_USERPASSPERM, &dwstructsize);
	if (dwstructsize != sizeof(T_USERPASSPERM)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_USERPASSPERM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_USERPASSPERM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_USERDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_USERDATA)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_USERDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_USERDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PMMDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_PMMDATA)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_PMMDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_PMMDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_GENERALPOLICY, &dwstructsize);
	if (dwstructsize != sizeof(T_GENERALPOLICY)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_GENERALPOLICY - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_GENERALPOLICY - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PWRDPOLICY, &dwstructsize);
	if (dwstructsize != sizeof(T_PWRDPOLICY)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_PWRDPOLICY - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_PWRDPOLICY - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_USERPOLICY, &dwstructsize);
	if (dwstructsize != sizeof(T_USERPOLICY)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_USERPOLICY - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_USERPOLICY - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PMMPOLICYDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_PMMPOLICYDATA)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_PMMPOLICYDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_PMMPOLICYDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PMMNVDATA, &dwstructsize);
	if (dwstructsize != sizeof(T_PMMNVDATA)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_PMMNVDATA - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_PMMNVDATA - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LAYOUTITEM, &dwstructsize);
	if (dwstructsize != sizeof(T_LAYOUTITEM)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_LAYOUTITEM - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_LAYOUTITEM - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TV_RECT, &dwstructsize);
	if (dwstructsize != sizeof(T_TV_RECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_TV_RECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_TV_RECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_ATTRBLOCKS, &dwstructsize);
	if (dwstructsize != sizeof(T_ATTRBLOCKS)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_ATTRBLOCKS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_ATTRBLOCKS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BORDER, &dwstructsize);
	if (dwstructsize != sizeof(T_BORDER)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_BORDER - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_BORDER - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_FONT, &dwstructsize);
	if (dwstructsize != sizeof(T_FONT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_FONT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_FONT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BASEOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_BASEOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_BASEOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_BASEOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CHANNELREF, &dwstructsize);
	if (dwstructsize != sizeof(T_CHANNELREF)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_CHANNELREF - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_CHANNELREF - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_EXAMPLEBAR, &dwstructsize);
	if (dwstructsize != sizeof(T_EXAMPLEBAR)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_EXAMPLEBAR - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_EXAMPLEBAR - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_DIGITALOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_DIGITALOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_DIGITALOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_DIGITALOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TEXTOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_TEXTOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_TEXTOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_TEXTOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TABULAROBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_TABULAROBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_TABULAROBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_TABULAROBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_TUSOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_TUSOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_TUSOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_TUSOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BUTTONOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_BUTTONOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_BUTTONOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_BUTTONOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BAROBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_BAROBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_BAROBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_BAROBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SCALEOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_SCALEOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_SCALEOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_SCALEOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_PENPTRSOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_PENPTRSOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_PENPTRSOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_PENPTRSOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_ALARMMRKROBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_ALARMMRKROBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_ALARMMRKROBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_ALARMMRKROBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CHARTOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_CHARTOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_CHARTOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_CHARTOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CIRCCHARTOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_CIRCCHARTOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_CIRCCHARTOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_CIRCCHARTOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CURSOROBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_CURSOROBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_CURSOROBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_CURSOROBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_BITMAPOBJECT, &dwstructsize);
	if (dwstructsize != sizeof(T_BITMAPOBJECT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_BITMAPOBJECT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_BITMAPOBJECT - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_WIDGET, &dwstructsize);
	if (dwstructsize != sizeof(T_WIDGET)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_WIDGET - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_WIDGET - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SCRTEMPLATE, &dwstructsize);
	if (dwstructsize != sizeof(T_SCRTEMPLATE)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_SCRTEMPLATE - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_SCRTEMPLATE - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_CANNEDPENS, &dwstructsize);
	if (dwstructsize != sizeof(T_CANNEDPENS)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_CANNEDPENS - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_CANNEDPENS - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_SCREEN, &dwstructsize);
	if (dwstructsize != sizeof(T_SCREEN)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_SCREEN - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_SCREEN - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_HOTBUTTON, &dwstructsize);
	if (dwstructsize != sizeof(T_HOTBUTTON)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_HOTBUTTON - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_HOTBUTTON - is not divisable by 4");
	}
	GetSizeOfBlockType(BLK_LAYOUT, &dwstructsize);
	if (dwstructsize != sizeof(T_LAYOUT)) {
		bRet = FALSE;
		LOG_WRN( TRACE_2_FILE + TRACE_ALWAYS, "T_LAYOUT - size mismatch with CMM");
	}
	if ((dwstructsize % 4) != 0) {
		bRet = FALSE;
		LOG_WRN ( TRACE_2_FILE + TRACE_ALWAYS, "T_LAYOUT - is not divisable by 4");
	}
	return bRet;
}

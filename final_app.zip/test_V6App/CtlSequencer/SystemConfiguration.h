/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Control Sequencer
/// @n Filename:  SystemConfiguration.h
/// @n Description: Class Declaration for System Configuration
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  23  Stability Project 1.20.1.1 7/2/2011 5:01:58 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  22  Stability Project 1.20.1.0 7/1/2011 4:26:30 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  21  V6 Firmware 1.20 11/17/2006 8:35:18 PM  Roger Dawson  
//  Fixed a problem where loading an out-of-date resource DLL would fail
//  in an obscure manner. The fault condition should be much clearer to
//  diagnose now.
//  20  V6 Firmware 1.19 8/9/2006 3:49:54 PM Jason Parker  
//  change name for bitmaps collection file when in use on the recorder
//  to match the default layout config
// $
//
// **************************************************************************
#ifndef _SYSTEMCONFIGURATION_H
#define _SYSTEMCONFIGURATION_H
#include "ConfigurationCommon.h"
const USHORT SYSCONFIG_ZERO = 0;		///< Represents the Value of Zero
const USHORT SYSCONFIG_BASE_CONFIG_ID = 0;		///< Default LCM Reference Configuration ID
/// Return Values for CSystemConfiguration Member Functions, used to describe the type of 
/// success or failure.
//
typedef enum _eSysConfigReturnValue {
	SYSCONFIG_OK,
	SYSCONFIG_ERROR,
	SYSCONFIG_ACTION_COULD_NOT_TO_PERFORMED,
	SYSCONFIG_INITIALISATION_FAILED,
	SYSCONFIG_METADATA_VERSION_MISMATCH,
	SYSCONFIG_METADATA_LOADED,
	SYSCONFIG_METADATA_NOT_LOADED,
	SYSCONFIG_CMM_INIT_FAILED,
	SYSCONFIG_CMM_INITIALISED,
	SYSCONFIG_NO_PERSISTED_CONFIGURATION,
	SYSCONFIG_LOAD_PERSISTED_ERROR,
	SYSCONFIG_PERSISTED_CONFIGURATION_LOADED,
	SYSCONFIG_CMM_UPDATE_RQD,
	SYSCONFIG_PMM_DEFAULT_CONFIG_CREATED
} T_SYSCONFIG_RETURN_VALUE;
typedef enum _eSysConfigAction {
	SYSCONFIG_LOAD_PERSISTED_CONFIG, SYSCONFIG_LOAD_CONFIGURATION, SYSCONFIG_UPDATE_CONFIG
} T_SYSCONFIG_CONFIGURATION_ACTION;
const QString SYSCONFIG_DEFAULT_PERSISTED_SETUP_FILENAME = "DefaultSetupConfig.set";
const QString SYSCONFIG_DEFAULT_PERSISTED_LAYOUT_FILENAME = "DefaultLayoutConfig.lay";
const QString SYSCONFIG_DEFAULT_PERSISTED_BITMAPS_FILENAME = "DefaultLayoutConfig.bcf";
//#define SYSCONFIG_DEFAULT_PERSISTED_SETUP_FILENAME L"DefaultSetupConfig.cfg"
//**Class*********************************************************************
///
/// @brief System Configuration Class for initialising the system for operating
/// 
/// This class encapsulates all the fuctionality that is required to initialise
/// the V6 software for operation. 
//****************************************************************************
class CSystemConfiguration {
public:
	/// Constructor
	CSystemConfiguration(void);
	/// Destructor
	virtual ~CSystemConfiguration(void);
	/// Initialise System Configuration
	T_SYSCONFIG_RETURN_VALUE Initialise();
	/// Initialise System Configuration
	T_SYSCONFIG_RETURN_VALUE InitialiseCMM(QString pName, ULONG deviceSerialNumber);
	/// Perform Setup Configuration
	// T_SYSCONFIG_RETURN_VALUE PerformSetupConfiguration( DWORD sessionNumber );
	/// Perform Password Configuration
	T_SYSCONFIG_RETURN_VALUE PerformPasswordConfiguration(DWORD sessionNumber);
	/// Perform Layout Configuration
	T_SYSCONFIG_RETURN_VALUE PerformLayoutConfiguration(DWORD sessionNumber);
	///
	T_CONFIG_RETURN_VALUE PerformLayoutConfigAction(const T_SYSCONFIG_CONFIGURATION_ACTION layoutConfigurationAction,
			const QString pConfigFileAndPathName = NULL);
	/// Perform a Specific Action on the Setup Configuration
	T_CONFIG_RETURN_VALUE PerformSetupConfigAction(const T_SYSCONFIG_CONFIGURATION_ACTION setupConfigurationAction,
			const QString pConfigFileAndPathName = NULL);
	T_CONFIG_RETURN_VALUE InitialiseLCM(void);
// T_CONFIG_RETURN_VALUE LoadNewSetupConfig( const WCHAR* pNewConfigFileName );
// T_SYSCONFIG_RETURN_VALUE LoadNewPasswordConfig( WCHAR* pNewConfigFileName ); 
// T_SYSCONFIG_RETURN_VALUE LoadNewLayoutConfig( const WCHAR* pNewConfigPathandFileName ); 
	T_CONFIG_RETURN_VALUE PersistSetupConfig(void);
	T_SYSCONFIG_RETURN_VALUE PersistPasswordConfig(void);
	T_CONFIG_RETURN_VALUE PersistLayoutConfig(void);
	T_CONFIG_RETURN_VALUE LoadPersistedSetupConfig(void);
	T_SYSCONFIG_RETURN_VALUE LoadPersistedPasswordConfig(void);
	T_CONFIG_RETURN_VALUE LoadPersistedLayoutConfig(void);
	class CSetupConfiguration* GetCurrentSetupConfig(void) {
		return m_pSetupConfiguration;
	}
	;
	class CLayoutConfiguration* GetCurrentLayoutConfig(void) {
		return m_pLayoutConfiguration;
	}
	;
	class CPasswordConfiguration* GetCurrentPasswordConfig(void) {
		return m_pPasswordConfiguration;
	}
	;
	T_CONFIG_RETURN_VALUE PerformPasswordUpdate(void);
private:
	// Private Member Functions
	/// Load the Metadata from the Resources
	T_SYSCONFIG_RETURN_VALUE LoadMetadata(void);
	// Private Member Data
	HGLOBAL m_hMetadataResourceHandler;							///< Handler to the Metadata Global Memory Block
	QString m_pPersisitedSetupFileName;
	CSetupConfiguration *m_pSetupConfiguration;					///< Setup Configuration 
	CLayoutConfiguration *m_pLayoutConfiguration;				///< Layout configuration
	class CPasswordConfiguration *m_pPasswordConfiguration;		///< Password Configuratiu
};
// End of Class Declaration
#endif // _SYSTEMCONFIGURATION_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Control Sequencer
/// @n Filename:  NormalOperation.h
/// @n Description: Class Declaration for Normal Operation
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Stability Project 1.9.1.1 7/2/2011 4:59:06 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.9.1.0 7/1/2011 4:26:30 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  V6 Firmware 1.9 2/2/2006 4:54:03 PM Andy Kassell  
//  Cleanup firmware upgrade code to remove old implementation
//  9 V6 Firmware 1.8 11/7/2005 9:02:25 PM  Andy Kassell  Add
//  calibration processing mode
// $
//
#ifndef _NORMALOPERATION_H
#define _NORMALOPERATION_H
#include "ModuleConstants.h"
#include "ModuleMsgManagerClient.h"
#include "V6ActiveModuleServices.h"
//#include "ControlSequencer.h"
/// Return Values for CNormalOperation Member Functions, used to describe the type of 
/// success or failure.
//
typedef enum _eNormalOpReturnValue {
	NORMALOP_OK,
	NORMALOP_ERROR,
	NORMALOP_NEW_MESSAGE,
	NORMALOP_RESTART_SYSTEM,
	NORMALOP_CHANGE_STATE_TO_NORMAL_OP,
	NORMALOP_CHANGE_STATE_TO_SELF_TEST,
	NORMALOP_NORMAL_OPERATION
} T_NORMALOP_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Carries out the Normal Operation functionality of the Control Sequencer
/// 
/// This class encapsulates all the functionality that is required for the Control
/// Sequencer to undertake when operating in Normal Operation mode. 
//****************************************************************************
class CNormalOperation {
	friend class CControlSequencer;
public:
	/// Constructor
	CNormalOperation(class CSystemConfiguration &systemConfiguration,
			class CV6ActiveModuleServices &activeModuleServices);
	/// Destructor
	virtual ~CNormalOperation(void);
	/// Process Message sent to the Control Sequencer for processing
	T_NORMALOP_RETURN_VALUE ProcessMessage(CModuleMsgManagerClient &ctrlSeqMessageQueue);
	void SetIOSchedulerPointer(class CIOScheduler *pIOScheduler) {
		m_pIOScheduler = pIOScheduler;
	}
private:
	class CSystemConfiguration &m_SystemConfiguration;
	class CIOScheduler *m_pIOScheduler;
	class CV6ActiveModuleServices &m_AModSer;
	BOOL m_InNormalOperation;		// Indicates if control seq is in normal operation or not.
private:	// member functions
	T_NORMALOP_RETURN_VALUE NormalOperation(void);
	T_NORMALOP_RETURN_VALUE ProcessConfigChange(const T_MOD_CFG_CHG_MSGDATA *const configChangeMsgData);
	T_NORMALOP_RETURN_VALUE ProcessSystemShutdown();
	T_NORMALOP_RETURN_VALUE ProcessSelfTest();
	T_NORMALOP_RETURN_VALUE EndSelfTest();
	T_NORMALOP_RETURN_VALUE ProcessEnterCalMode();
	T_NORMALOP_RETURN_VALUE PrepareForConfigChange(const T_MOD_CFG_CHG_TYPE configChangeType);
	T_NORMALOP_RETURN_VALUE PrepareForShutdown(void);
	T_NORMALOP_RETURN_VALUE ShutdownSystem(void);
	T_NORMALOP_RETURN_VALUE ApplyConfigChange(const T_MOD_CFG_CHG_MSGDATA *const configChangeMsgData);
	T_NORMALOP_RETURN_VALUE ConfigChangeComplete(const T_MOD_CFG_CHG_TYPE configChangeType);
	T_NORMALOP_RETURN_VALUE PerformSystemAction(const T_MOD_SYS_CFG_CHG_ACTION systemAction);
};
// End of Class Declaration
#endif // _NORMALOPERATION_H

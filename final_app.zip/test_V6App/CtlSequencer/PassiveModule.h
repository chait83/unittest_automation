/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Control Sequencer
/// @n Filename:  PassiveModule.h
/// @n Description: Class Declaration File for the class CPassiveModule
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:59:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:24 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 3/30/2005 4:00:27 PM  Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _PASSIVEMODULE_H
#define _PASSIVEMODULE_H
//**Class*********************************************************************
///
/// @brief Base Class for all Passive Modules within V6
/// 
/// This class provides common functionality that will be available from all 
/// modules that DO NOT operate within their own thread. Passive Modules will
/// be used by other modules within V6 as service classes to perform
/// specific functionality. 
///
/// @note Modules that DO NOT operate within their own thread are known as
///  Passive Modules.
//****************************************************************************
class CPassiveModule {
public:
	/// Constructor
	CPassiveModule(void);
	/// Destructor
	virtual ~CPassiveModule(void);
};
// End of Class Declaration
#endif // _PASSIVEMODULE_H

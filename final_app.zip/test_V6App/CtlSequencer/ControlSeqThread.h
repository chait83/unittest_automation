#ifndef _CONTROLSEQTHREAD_H
#define _CONTROLSEQTHREAD_H
#include <QThread>
#include "Defines.h"
/// Passed into the AfxBeginThread when starting the Control Sequencer,
/// to indicate which mode the system shall be started. This will primarily
/// effect which modules are told to begin execution.  
typedef enum e_CtrlSeqThOperationalMode {
	CTRLSEQTH_MODE_NORMAL_OPERATION,  // Use unless specific operation is required
	CTRLSEQTH_MODE_ATE_QUERY_HARDWARE, // ATE Specific Mode
	CTRLSEQTH_MODE_ATE_CALIBRATION, // ATE Specific Mode
	CTRLSEQTH_MODE_ATE_TEST // ATE Specific Mode
} T_CTRLSEQTH_OPERATIONAL_MODE;
// CControlSeqThread
class CControlSeqThread: public QThread {
	// DECLARE_DYNCREATE (CControlSeqThread)
public:
	CControlSeqThread();
protected:
	// protected constructor used by dynamic creation
	virtual ~CControlSeqThread();
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
public:
	static UINT ThreadFunc(LPVOID lpParam);
};
#endif //_CONTROLSEQTHREAD_H

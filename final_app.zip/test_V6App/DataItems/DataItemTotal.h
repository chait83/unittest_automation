/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemTotal.h
/// @n Desc:	 Totaliser specific details for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//10Stability Project 1.7.1.1 7/2/2011 4:56:39 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//9 Stability Project 1.7.1.0 7/1/2011 4:27:26 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//8 V6 Firmware 1.7 2/24/2006 8:16:58 PMAndy KassellGet
//total units not pen units
//7 V6 Firmware 1.6 11/9/2005 9:46:26 PMAndy Kassell
//Override GetColour to return Pen colour if enabled, otherwise the
//disabled colour
// $
//
// ****************************************************************
#ifndef __DATAITEMTOTAL_H__
#define __DATAITEMTOTAL_H__
#include "DataItemPen.h"
#include <QVector>
typedef enum {
	DI_TOTAL_READING = 0,				///< Reading for Pen total
	DI_TOTAL_MAXTYPES				///< ** Maximum number of types Always keep at end **
} T_DATA_ITEM_TOTAL_TYPES;
//**Class*********************************************************************
///
/// @brief Totaliser Data Items
/// 
/// This class will provide the support for Totaliser based data items
///
//****************************************************************************
class CDataItemTotal: public CDataItem {
public:
	void WhoAmI() {
		qDebug("I'm a totlaiser ");
		CDataItem::WhoAmI();
	}
	;
	float GetZero() const {
		return m_pPenDIT->GetZero();
	}
	;
	float GetSpan() const {
		return m_pPenDIT->GetSpan();
	}
	;
	const WCHAR* GetTag() const {
		return m_pPenDIT->m_pPenConfig->Tot.Tag;
	}
	;
	const WCHAR* GetUnits() const {
		return m_pPenDIT->m_pPenConfig->Tot.Units;
	}
	;
	COLORREF* GetColour();
	T_PSCALEINFO GetScaleInfo() {
		return &m_ScaleInfo;
	}
	;
	T_PLINESTYLE GetLineInfo() {
		return m_pPenDIT->GetLineInfo();
	}
	;
	USHORT GetAlarmStatus() {
		return m_pPenDIT->GetAlarmStatus();
	}
	;	///< Return number of active alarms
	void SetAlarmStatus(USHORT status) {
		m_pPenDIT->SetAlarmStatus(status);
	}
	;		///< Set alarm status 	
	void SetPenDITPtr(CDataItemPen *pPenDIT) {
		m_pPenDIT = pPenDIT;
	}
	;
	void SetTotalEnable();
	void SetTotalScaleInfo();
private:
	CDataItemPen *m_pPenDIT;			///< Pointer to the Pen data item, base reference for the Alarm.
	T_SCALEINFO m_ScaleInfo;		///< Totalisers scale info
};
//**Class*********************************************************************
///
/// @brief Pen Data Item Type, container class
/// 
/// This class will provide Pen specific access for Pen data items
///
//****************************************************************************
class CDataItemTypeTotal: public CDataItemTypeContainer {
public:
	CDataItemTypeTotal();			///< Constructor
	~CDataItemTypeTotal();			///< Destructor
	T_DI_RETURN CreateItemTable();		///< Create the Data Item table for 
	T_DI_RETURN ApplyConfig();			///< Apply configuration for data table item.
	T_DI_RETURN LinkPenTypes(CDataItemTypePen *pLinkPenType);		///< Link Pen into this Type as it is a dependecy
private:
	QVector<CDataItemTotal> m_TotalDataItemArray;
};
#endif // __DATAITEMTOTAL_H__

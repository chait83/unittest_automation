/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemTble.cpp
/// @n Desc:	 Init data item table
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//10Stability Project 1.5.1.3 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//9 Stability Project 1.5.1.2 7/1/2011 4:38:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//8 Stability Project 1.5.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//7 Stability Project 1.5.1.0 2/15/2011 3:02:53 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "DataItemTable.h"
#include "V6globals.h"
#include <QWidget>
//****************************************************************************
/// Initialise the Data item table, this has been performed outside of the 
/// core Data item table code as it contains specifics on the V6 Platform.
/// However this will enable other user software to intitialse the DIT without
/// including the control sequencer.
///
/// @returnBOOL to indicate success/failure of initialisation
/// 
//****************************************************************************
BOOL InitDataItemTable(CDataItemManager *pkDataItemManager) {
	BOOL retVal = TRUE; // Member Function Return Value
	if (NULL == pkDataItemManager) {
		retVal = FALSE;
	} else {
		QString csTxt;
		csTxt = QWidget::tr("Adding Items to the DIT");
		pGlbSysInfo->SetStartupSubAction(csTxt);
		// Step 1, add all V6 specific interfacing types to the Data Item Table
		pkDataItemManager->AddContainer(DI_PEN, new CDataItemTypePen);			// Pens
		pkDataItemManager->AddContainer(DI_IO, new CDataItemTypeIO);			// IO , Analogue, Digital, Pulse
		pkDataItemManager->AddContainer(DI_MMA, new CDataItemTypeMaxMinAve);	// Max Mins and Averages
		pkDataItemManager->AddContainer(DI_ALARM, new CDataItemTypeAlarm);		// Alarms
		pkDataItemManager->AddContainer(DI_TOTAL, new CDataItemTypeTotal);		// Totalisers
		pkDataItemManager->AddContainer(DI_GENERAL, new CDataItemTypeGeneral);	// General
		pkDataItemManager->AddContainer(DI_COUNTER, new CDataItemTypeCounter);	// General
		// Step 2, Create the Data Item Table **Make sure AddContainer for all types has been completed
		csTxt = QWidget::tr("Creating the DIT");
		pGlbSysInfo->SetStartupSubAction(csTxt);
		if (pkDataItemManager->CreateDataItemTable() == FALSE) {
			///@TODO error handler
			retVal = FALSE;
		} // End of IF
		//Step 3, Create any Links between the typesm for instance Max,Mins,Totals,alarms are all linked to Pens
		// Link MaxMins & Averages with Pen
		csTxt = QWidget::tr("Creating DIT Links");
		pGlbSysInfo->SetStartupSubAction(csTxt);
		((CDataItemTypeMaxMinAve*) pkDataItemManager->GetContainerPtr(DI_MMA))->LinkPenTypes(
				(CDataItemTypePen*) pkDataItemManager->GetContainerPtr(DI_PEN));
		// Link Alarms with Pen
		((CDataItemTypeAlarm*) pkDataItemManager->GetContainerPtr(DI_ALARM))->LinkPenTypes(
				(CDataItemTypePen*) pkDataItemManager->GetContainerPtr(DI_PEN));
		// Link Totalisers with Pen
		((CDataItemTypeTotal*) pkDataItemManager->GetContainerPtr(DI_TOTAL))->LinkPenTypes(
				(CDataItemTypePen*) pkDataItemManager->GetContainerPtr(DI_PEN));
	} // End of IF
	return retVal;
}

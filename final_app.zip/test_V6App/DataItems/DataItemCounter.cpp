/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemCounter.cpp
/// @n Desc:	 Counetr system items for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//7 Stability Project 1.2.1.3 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//6 Stability Project 1.2.1.2 7/1/2011 4:38:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//5 Stability Project 1.2.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//4 Stability Project 1.2.1.0 2/15/2011 3:02:51 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "DataItemCounter.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
const int MAX_COUNTER_SIZE = MAX_DIGITAL_IO + 1; /// Add 1 for the power relay.
//=============================================================================
// CDataItemTypeCounter Class
//=============================================================================
//****************************************************************************
/// CDataItemTypeCounter Constructor
//****************************************************************************
CDataItemTypeCounter::CDataItemTypeCounter() {
}
//****************************************************************************
/// CDataItemTypeCounter Destructor
//****************************************************************************
CDataItemTypeCounter::~CDataItemTypeCounter() {
	m_CounterDataItemArray.clear();
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeCounter::CreateItemTable() {
	WCHAR varName[MAX_VARNAME_LEN];	// Container to build variable names into		
	T_DI_RETURN retVal = DI_OKAY;
	int itemCount = 0;
	m_maxItems = 0;		// No items added, zero max items
	// Stage 1, Create the memory space for the DataItems
	m_CounterDataItemArray.resize(MAX_COUNTER_SIZE * DI_COUNTTYPE_MAX_TYPES);
	SetDataItemInfo(DI_COUNTER, DI_COUNTTYPE_MAX_TYPES, MAX_COUNTER_SIZE);// Type counter, subtypes and Max IO instance.
	// Stage 2, initialise the data items
	// *** User counters ***
	for (itemCount = 0; itemCount < V6_USER_COUNTERS; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"UC%d", itemCount + 1);
		// Add comms variables to the Data itme table
		AddItem(itemCount, DI_COUNTTYPE_USER, static_cast<NVVAR_IDENT>(NVV_USERCOUNT_FIRST + itemCount),
				QString::fromWCharArray(varName));
	}
	// *** Event counters ***
	for (itemCount = 0; itemCount < V6_MAX_EVENTS; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"EC%d", itemCount + 1);
		// Add comms variables to the Data itme table
		AddItem(itemCount, DI_COUNTTYPE_EVENTS, static_cast<NVVAR_IDENT>(NVV_EVENTCOUNT_FIRST + itemCount),
				QString::fromWCharArray(varName));
	}
	// *** Lo Res pulse counters (Dig IO) ***
	for (itemCount = 0; itemCount < MAX_LORES_PULSE; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"LPC%d", itemCount + 1);
		// Add comms variables to the Data itme table
		AddItem(itemCount, DI_COUNTTYPE_LCOUNT, static_cast<NVVAR_IDENT>(NVV_LHWCOUNT_FIRST + itemCount),
				QString::fromWCharArray(varName));
	}
	// *** Hi Res pulse counters (Pulse Card) ***
	for (itemCount = 0; itemCount < MAX_HIRES_PULSE; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"HPC%d", itemCount + 1);
		// Add comms variables to the Data itme table
		AddItem(itemCount, DI_COUNTTYPE_HCOUNT, static_cast<NVVAR_IDENT>(NVV_HHWCOUNT_FIRST + itemCount),
				QString::fromWCharArray(varName));
	}
	// *** IO counter, include the poer relay ***
	for (itemCount = 0; itemCount < MAX_DIGITAL_IO; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"IOC%d", itemCount + 1);
		// Add comms variables to the Data itme table
		AddItem(itemCount, DI_COUNTTYPE_IO, static_cast<NVVAR_IDENT>(NVV_IOCOUNT_FIRST + itemCount),
				QString::fromWCharArray(varName));
	}
	swprintf(varName, MAX_VARNAME_LEN, L"PRC");
	AddItem(MAX_DIGITAL_IO, DI_COUNTTYPE_IO, static_cast<NVVAR_IDENT>(NVV_IOCOUNT_FIRST + MAX_DIGITAL_IO),
			QString::fromWCharArray(varName));
	// Set the dummy General Data Item
	CDataItemCounter *ptrDummyData = new CDataItemCounter();
	SetDummyDataItem((CDataItem*) ptrDummyData);
	return retVal;
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeCounter::AddItem(int index, T_COUNTER_TYPES type, NVVAR_IDENT nvid, QString varName) {
	T_DI_RETURN retVal = DI_OKAY;
	// Add item to the Data item table
	retVal = AddDataItem(&m_CounterDataItemArray[m_maxItems], type, index, varName, DI_FLOAT);
	// initialise the zero span tag and units label of the general data item
	m_CounterDataItemArray[m_maxItems].SetNVHandle(pNV_VARS->GetBasicVarNVObject(nvid));
	m_CounterDataItemArray[m_maxItems].SetValue(
			m_CounterDataItemArray[m_maxItems].GetNVHandle()->GetFromNV()->value.flt);
	++m_maxItems;
	return retVal;
}
//****************************************************************************
/// ApplyConfig overridden method, handle all configuration changes and startup
/// Will be called on startup when configuration in place and every time
/// the current configuration changes.
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeCounter::ApplyConfig() {
	T_DI_RETURN retVal = DI_OKAY;
	return retVal;
}
//=============================================================================
// CDataItemCounter Class
//=============================================================================
//****************************************************************************
/// CDataItemCounter Constructor 
///
//****************************************************************************
CDataItemCounter::CDataItemCounter() {
	m_pNV = NULL;
	setTag("--");
}
//****************************************************************************
/// Override SetValue to amange NV access if required
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemCounter::SetValue(float value) {
	// Set the value and the time
	CDataItem::SetValue(value);
	CDataItem::SetTime( pSYSTIMER->GetCurrentProcessTimeInMicroSec());
	// if this is tied to an NV reference, update the NV values
	if (m_pNV != NULL) {
		m_pNV->SetToNV(GetComboValue());		// Set the NV data
	}
}
//****************************************************************************
/// Reset the counter
///
/// @param[in]	value - override reset value, default to 0
///
/// @return - nothing 
//****************************************************************************
void CDataItemCounter::ResetCounter(float value = 0) {
	SetValue(value);
}
//****************************************************************************
/// Increment the counter
///
/// @param[in]	incBy - override increment value, default to 1
///
/// @return - nothing 
//****************************************************************************
void CDataItemCounter::IncrementCounter(float incBy = 1) {
	float currValue = GetFPValue();
	currValue += incBy;
	SetValue(currValue);
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemPen.h
/// @n Desc:	 Pen Max Min and Average details for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//12Stability Project 1.9.1.1 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//11Stability Project 1.9.1.0 7/1/2011 4:27:24 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//10V6 Firmware 1.9 11/9/2005 9:46:26 PMAndy Kassell
//Override GetColour to return Pen colour if enabled, otherwise the
//disabled colour
//9 V6 Firmware 1.8 9/12/2005 9:30:27 PMAndy Kassell
//Remove timed max min and average items
//Add type of itme so tag can be recovered
// $
//
// ****************************************************************
#ifndef __DATAITEMMMA_H__
#define __DATAITEMMMA_H__
#include "DataItemBase.h"
#include "DataItemPen.h"
#include "V6Config.h"
typedef enum {
	DI_MMA_TYPE_MIN,			///< Min
	DI_MMA_TYPE_MAX,			///< Max
	DI_MMA_TYPE_AVE,			///< Average
} T_MAX_MIN_AVE;
/// Max min and average data item types stored in table
typedef enum {
	DI_MMA_MIN_USER = 0,			///< Min indefinate time period user reset
	DI_MMA_MAX_USER,			///< Max indefinate time period user reset
	DI_MMA_AVE_USER,			///< Average indefinate time period user reset
	DI_MMA_MAXTYPES				///< ** Maximum number of rates Always keep at end **
} T_DATA_ITEM_MMA_TYPES;
//**Class*********************************************************************
///
/// @brief Max Min Average Data Items
/// 
/// This class will provide the support for Pen based data items
///
//****************************************************************************
class CDataItemMaxMinAve: public CDataItem {
public:
	CDataItemMaxMinAve();
	void WhoAmI() {
		qDebug("I'm a Max Min Ave ");
		CDataItem::WhoAmI();
	}
	;
	float GetZero() const {
		return m_pPenDIT->GetZero();
	}
	;
	float GetSpan() const {
		return m_pPenDIT->GetSpan();
	}
	;
	const WCHAR* GetUnits() const {
		return m_pPenDIT->GetUnits();
	}
	;
	COLORREF* GetColour();
	T_PSCALEINFO GetScaleInfo() {
		return m_pPenDIT->GetScaleInfo();
	}
	;
	T_PLINESTYLE GetLineInfo() {
		return m_pPenDIT->GetLineInfo();
	}
	;
	const WCHAR* GetTag() const;
	USHORT GetAlarmStatus() {
		return m_pPenDIT->GetAlarmStatus();
	}
	;	///< Return number of active alarms
	void SetAlarmStatus(USHORT status) {
		m_pPenDIT->SetAlarmStatus(status);
	}
	;		///< Set alarm status 	
	void SetPenDITPtr(CDataItemPen *pPenDIT) {
		m_pPenDIT = pPenDIT;
	}
	;
	void SetMMAEnabled();
	void SetType(T_MAX_MIN_AVE type) {
		m_Type = type;
	}
	;
public:
	CDataItemPen *m_pPenDIT;		///< Pointer to the Pen data item, base reference for the Max Min or Ave.
	T_MAX_MIN_AVE m_Type;			///< Max Min or Average type
};
//**Class*********************************************************************
///
/// @brief Max Min Average Data Item Type, container class
/// 
/// This class will provide Pen specific access for Pen data items
///
//****************************************************************************
class CDataItemTypeMaxMinAve: public CDataItemTypeContainer {
public:
	CDataItemTypeMaxMinAve();			///< Constructor
	~CDataItemTypeMaxMinAve();			///< Destructor
	T_DI_RETURN CreateItemTable();		///< Create the Data Item table for 
	T_DI_RETURN ApplyConfig();			///< Apply configuration for data table item.
	T_DI_RETURN LinkPenTypes(CDataItemTypePen *pLinkPenType);		///< Link Pen into this Type as it is a dependecy
private:
	QVector<CDataItemMaxMinAve> m_MMADataItemArray;
};
#endif // __DATAITEMMMA_H__

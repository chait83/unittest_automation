/// @file 
/// ****************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemPen.h
/// @n Desc:	 Pen specific details for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//26Stability Project 1.23.1.1 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//25Stability Project 1.23.1.0 7/1/2011 4:27:16 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//24V6 Firmware 1.23 9/23/2008 3:09:23 PMBuild Machine 
//AMS2750 Merge
//23V6 Firmware 1.22 4/3/2007 3:04:40 PM Jason Parker
//uncomment function call
// $
//
// ****************************************************************
#ifndef __DATAITEMPEN_H__
#define __DATAITEMPEN_H__
#include "DataItemBase.h"
#include "V6Config.h"
#include <QVector>
#include "Defines.h"
typedef enum {
	DI_PEN_READING = 0,			///< Standard Pen reading
	DI_PEN_MM_REPLAY = 1,			///< Max Min replay pens (dynamic) 
	DI_PEN_MAX_TYPES			///< Max item types, NB always at end
} T_DATA_ITEM_PEN_LIST;
//**Class*********************************************************************
///
/// @brief Pen Data Items
/// 
/// This class will provide the support for Pen based data items
///
//****************************************************************************
class CDataItemPen: public CDataItem {
public:
	CDataItemPen();
	void WhoAmI() {
		qDebug("Im a Pen ");
		CDataItem::WhoAmI();
	}
	;
	float GetZero() const {
		return m_zero;
	}
	;
	float GetSpan() const {
		return m_span;
	}
	;
	const WCHAR* GetTag() const {
		return m_pPenConfig->Tag;
	}
	;
	const WCHAR* GetDesc() const {
		return m_pPenConfig->Description;
	}
	;
	const WCHAR* GetUnits() const {
		return m_pPenConfig->Units;
	}
	;
	COLORREF* GetColour() {
		return &m_PenColour;
	}
	;
	T_PSCALEINFO GetScaleInfo() {
		return &m_tScaleInfo;
	}
	;
	T_PLINESTYLE GetLineInfo() {
		return &m_pPenConfig->Style;
	}
	;
	USHORT GetAlarmStatus() {
		return m_AlarmStatus;
	}
	;		///< Return number of active alarms
	void SetAlarmStatus(USHORT status) {
		m_AlarmStatus = status;
	}
	;		///< Set alarm status 
	USHORT GetAlarmAckStatus() {
		return m_AlarmAckStatus;
	}
	;	///< Return number of alarm requiring acknowledgement
	void SetAlarmAckStatus(USHORT status) {
		m_AlarmAckStatus = status;
	}
	;	///< Set alarm acknowledge status 
	void SetPenConfiguration(T_PPEN pPenBlock) {
		m_pPenConfig = pPenBlock;
		if (pPenBlock != NULL) {
			m_tScaleInfo = m_pPenConfig->Scale;
		}
	}
	;
	void SetZeroAndSpan(float zero, float span) {
		m_zero = zero;
		m_span = span;
	}
	;
	void SetValue(float value);
	T_PPEN GetPenConfig() {
		return m_pPenConfig;
	}
	;
	void SetPenConfig();
	void SetupCMMConfig(int penIndex);
	void SetReplayPenConfig(int toPenIndex);
public:
	T_PPEN m_pPenConfig;		///< Pointer to the current commited pen config in CMM
	USHORT m_AlarmStatus;		///< Pen alarm state summary, contain the number of Active alarms
	USHORT m_AlarmAckStatus;///< Pen alarm acknowledge summary, contain the number of alarms requiring an acknowledge
	COLORREF m_PenColour;		///< Colour of Pen, take form Pen config when enabled , otherwise set to disabled colour
private:
	float m_zero;				///< Zero range of pen, this will depend on log scales setting
	float m_span;				///< Span range of pen, this will depend on log scales setting
	BOOL m_reverseScale;		///< TRUE if reverse scale, otherwise false
	T_SCALEINFO m_tScaleInfo;	///< Copy of the scale information
};
//**Class*********************************************************************
///
/// @brief Pen Data Item Type, container class
/// 
/// This class will provide Pen specific access for Pen data items
///
//****************************************************************************
class CDataItemTypePen: public CDataItemTypeContainer {
public:
	CDataItemTypePen();					///< Constructor
	~CDataItemTypePen();				///< Destructor
	T_DI_RETURN CreateItemTable();		///< Create the Data Item table for 
	T_DI_RETURN ApplyConfig();			///< Apply configuration for data table item.
private:
	QVector<CDataItemPen> m_penDataItemArray;
};
#endif // __DATAITEMPEN_H__

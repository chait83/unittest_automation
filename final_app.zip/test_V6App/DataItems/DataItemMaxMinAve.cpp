/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemMaxMinAve.cpp
/// @n Desc:	 Pen Max min and Average items for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//15Stability Project 1.10.1.3 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//14Stability Project 1.10.1.2 7/1/2011 4:38:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//13Stability Project 1.10.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//12Stability Project 1.10.1.0 2/15/2011 3:02:52 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "DataItemMaxMinAve.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//=============================================================================
// CDataItemTypeMaxMinAve Class
//=============================================================================
//****************************************************************************
/// CDataItemTypeMaxMinAve Constructor
//****************************************************************************
CDataItemTypeMaxMinAve::CDataItemTypeMaxMinAve() {
}
//****************************************************************************
/// CDataItemTypeMaxMinAve Destructor
//****************************************************************************
CDataItemTypeMaxMinAve::~CDataItemTypeMaxMinAve() {
	m_MMADataItemArray.clear();
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeMaxMinAve::CreateItemTable() {
	T_DI_RETURN retVal = DI_OKAY;
	//qDebug("Create Data Item table for a %d MMAs\n",V6_MAX_PENS);
	// Stage 1, Create the memory space for the DataItems
	m_MMADataItemArray.reserve(V6_MAX_PENS * DI_MMA_MAXTYPES);
	SetDataItemInfo(DI_MMA, DI_MMA_MAXTYPES, V6_MAX_PENS); // Type Max Min Average, number of MMA types and Max Pens instance.
	// Stage 2, initialise the data items
	WCHAR varName[MAX_VARNAME_LEN];
	int baseIndex = 0;
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		baseIndex = penCount * DI_MMA_MAXTYPES;
		// Config Max
		swprintf(varName, MAX_VARNAME_LEN, L"P%dMAXU", penCount + 1);
		AddDataItem(&m_MMADataItemArray[baseIndex + DI_MMA_MAX_USER], DI_MMA_MAX_USER, penCount,
				QString::fromWCharArray(varName), DI_FLOAT);
		m_MMADataItemArray[baseIndex + DI_MMA_MAX_USER].SetType(DI_MMA_TYPE_MAX);
		// Config Min
		swprintf(varName, MAX_VARNAME_LEN, L"P%dMINU", penCount + 1);
		AddDataItem(&m_MMADataItemArray[baseIndex + DI_MMA_MIN_USER], DI_MMA_MIN_USER, penCount,
				QString::fromWCharArray(varName), DI_FLOAT);
		m_MMADataItemArray[baseIndex + DI_MMA_MIN_USER].SetType(DI_MMA_TYPE_MIN);
		// Config Ave
		swprintf(varName, MAX_VARNAME_LEN, L"P%dAVEU", penCount + 1);
		AddDataItem(&m_MMADataItemArray[baseIndex + DI_MMA_AVE_USER], DI_MMA_AVE_USER, penCount,
				QString::fromWCharArray(varName), DI_FLOAT);
		m_MMADataItemArray[baseIndex + DI_MMA_AVE_USER].SetType(DI_MMA_TYPE_AVE);
	}
	// Set the dummy MMA Data Item
	SetDummyDataItem(new CDataItemMaxMinAve());
	return retVal;
}
//****************************************************************************
/// ApplyConfig overridden method, handle all configuration changes and startup
/// Will be called on startup when configuration in place and every time
/// the current configuration changes.
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeMaxMinAve::ApplyConfig() {
	T_DI_RETURN retVal = DI_OKAY;
	CDataItemMaxMinAve *pMMADIT;
	// Loop through all Pens and assign the Pen Data Item to each of the MMA types
	// so they can derive their details from the Pens.
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		for (int mmaType = 0; mmaType < DI_MMA_MAXTYPES; mmaType++) {
			// Get a handle on the Max Min or Average Type
			pMMADIT = (CDataItemMaxMinAve*) GetDataItemPtr(mmaType, penCount);
			// if pen is enabled then MaxMin & Average is enabled
			pMMADIT->SetEnabled(pMMADIT->m_pPenDIT->IsEnabled());
			pMMADIT->RegisterChange();
		}
	}
	return retVal;
}
//****************************************************************************
/// Link CDataItemTypeMaxMinAve table items to CDataItemTypePen items as these
/// Max Min and Average Items are all derived form a Pen
///
/// @param[in] - pLinkPenType, ptr to Pen DIT Type, this type is dependent on Pens
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeMaxMinAve::LinkPenTypes(CDataItemTypePen *pLinkPenType) {
	T_DI_RETURN retVal = DI_OKAY;
	CDataItemMaxMinAve *pMMADIT;
	// Loop through all Pens and assign the Pen Data Item to each of the MMA types
	// so they can derive their details from the Pens.
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		for (int mmaType = 0; mmaType < DI_MMA_MAXTYPES; mmaType++) {
			// Get a handle on the Max Min or Average Type
			pMMADIT = (CDataItemMaxMinAve*) GetDataItemPtr(mmaType, penCount);
			// Assign Pen Data Item to the MMA type.
			pMMADIT->SetPenDITPtr((CDataItemPen*) pLinkPenType->GetDataItemPtr(DI_PEN_READING, penCount));
		}
	}
	// Setup the dummy data item to look at the dummy pen data item
	reinterpret_cast<CDataItemMaxMinAve*>(GetDummyDataItem())->SetPenDITPtr(
			(CDataItemPen*) pLinkPenType->GetDummyDataItem());
	return retVal;
}
//=============================================================================
// CDataItemMaxMinAve Class
//=============================================================================
//****************************************************************************
/// CDataItemMaxMinAve() constructor
///
//****************************************************************************
CDataItemMaxMinAve::CDataItemMaxMinAve() {
	SetType(DI_MMA_TYPE_MAX);
}
//****************************************************************************
/// Get the colour of the Data Item, will return the disabled colour of disabled
///
/// @return - pointer to a COLOREF
//****************************************************************************
COLORREF* CDataItemMaxMinAve::GetColour() {
	if (IsEnabled())
		return m_pPenDIT->GetColour();
	else
		return &GlbDITDisabaledColour;
}
//****************************************************************************
/// Get the tag of the Max Min or Average
///
/// @return - pointer to "Max" "Min" or "Average" label 
///
//****************************************************************************
const WCHAR* CDataItemMaxMinAve::GetTag() const {
	/// @todo AK, QUAD routine, convert this to looking in the resource table
	static WCHAR max_tag[] = L"Max";
	static WCHAR min_tag[] = L"Min";
	static WCHAR ave_tag[] = L"Average";
	QString pTag = QString::fromWCharArray(max_tag);
	switch (m_Type) {
	case DI_MMA_TYPE_MIN:
		pTag = QString::fromWCharArray(min_tag);
		break;
	case DI_MMA_TYPE_AVE:
		pTag = QString::fromWCharArray(ave_tag);
		break;
	default:
		pTag = QString::fromWCharArray(max_tag);
		break;
	}
	WCHAR ret[10];
	pTag.toWCharArray(ret);
	return ret;
}

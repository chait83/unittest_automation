/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemIO.cpp
/// @n Desc:	 IO specific details for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//27Stability Project 1.22.1.3 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//26Stability Project 1.22.1.2 7/1/2011 4:38:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//25Stability Project 1.22.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//24Stability Project 1.22.1.0 2/15/2011 3:02:52 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6defines.h"
#include "DataItemIO.h"
#include "V6globals.h"
#include "AIConfig.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// CDataItemTypeIO destructor
//****************************************************************************
CDataItemTypeIO::~CDataItemTypeIO() {
	m_IODataItemArray.clear();
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeIO::CreateItemTable() {
	T_DI_RETURN retVal = DI_OKAY;
	// Get handle on slot map
	m_pSlotMap = CSlotMap::GetHandle();
	ClearOutputCache();
	ClearOldOutputCache();	//MarkD
	// Setup an array of types, but number of elements for each type is dependent on the 
	// largest of Analogues or digital count
	int maxItemCount = MAX_ANALOGUE_IN;
	if (MAX_DIGITAL_IO > MAX_ANALOGUE_IN) {
		maxItemCount = MAX_DIGITAL_IO;
	}
	int totalIO = maxItemCount * DI_IO_MAX_TYPES;		// Multiple largest count by number of types
	//qDebug("Create Data Item table for a %d IO\n",totalIO);
	// Stage 1, Create the memory space for the DataItems
	m_IODataItemArray.reserve(totalIO);	/// Create IO specific data items space
	SetDataItemInfo(DI_IO, DI_IO_MAX_TYPES, maxItemCount);	/// Confirm data item sizing to abstract interface
	// Stage 2, initialise the data items
	WCHAR varName[MAX_VARNAME_LEN];
	int itemCount = 0;
	int ioCount = 0;
	// Add engineering scales analogue readings
	for (ioCount = 0; ioCount < MAX_ANALOGUE_IN; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"A%d", ioCount + 1);
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_ANALOGUE, ioCount, varName, DI_FLOAT);
	}
	// Add the Raw analogue data items
	for (ioCount = 0; ioCount < MAX_ANALOGUE_IN; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"RA%d", ioCount + 1);
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_ANALOGUE_RAW, ioCount, varName, DI_FLOAT);
	}
	// Add the the RT Comp data items
	for (ioCount = 0; ioCount < MAX_ANALOGUE_IN; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"RTCOMP%d", ioCount + 1);
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_RT_COMP, ioCount, varName, DI_FLOAT);
	}
	// Add the RT Cal data items
	for (ioCount = 0; ioCount < MAX_ANALOGUE_IN; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"RTCAL%d", ioCount + 1);
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_RT_CAL, ioCount, varName, DI_FLOAT);
	}
	// Add the Digital IO Data Items
	for (ioCount = 0; ioCount < MAX_DIGITAL_IO; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"D%d", ioCount + 1);
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_DIGITAL, ioCount, varName, DI_FLOAT);
	}
	// Add the Hi res PULSE Data Items
	for (ioCount = 0; ioCount < MAX_HIRES_PULSE; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"HPUL%d", ioCount + 1);
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_HIPULSE, ioCount, varName, DI_FLOAT);
	}
	// Add the Lo res PULSE Data Items
	for (ioCount = 0; ioCount < MAX_LORES_PULSE; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"LPUL%d", ioCount + 1);
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_LOPULSE, ioCount, varName, DI_FLOAT);
	}
	int tempDiIndex;
	// Add the CJC's to Data Items
	for (ioCount = DI_IO_MISC_CJC1; ioCount <= DI_IO_MISC_CJC6; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"CJC%d", (ioCount - DI_IO_MISC_CJC1) + 1);
		tempDiIndex = itemCount;
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_MISC, ioCount, varName, DI_FLOAT);
		// ensure the status is invalid - this will get set correctly on startup if CJC(s) exist
		m_IODataItemArray[tempDiIndex].SetStatus(DISTAT_INVALID);
	}
	// Add the CJC's C to Data Items
	for (ioCount = DI_IO_MISC_CJC1_C; ioCount <= DI_IO_MISC_CJC6_C; ioCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"CJC%dC", (ioCount - DI_IO_MISC_CJC1_C) + 1);
		tempDiIndex = itemCount;
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_MISC, ioCount, varName, DI_FLOAT);
		// ensure the status is invalid - this will get set correctly on startup if CJC(s) exist
		m_IODataItemArray[tempDiIndex].SetStatus(DISTAT_INVALID);
	}
	// Add digital card bitvalue for slot 1
	AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_MISC, DI_IO_DIG_BITS_SLOT1, L"DIO1", DI_FLOAT);
	// Add digital card bitvalue for slot 2
	AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_MISC, DI_IO_DIG_BITS_SLOT2, L"DIO2", DI_FLOAT);
	// Add digital card bitvalue for slot 3
	AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_MISC, DI_IO_DIG_BITS_SLOT3, L"DIO3", DI_FLOAT);
	// Add Power relay data item
	AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_MISC, DI_IO_DIG_POWERRELAY, L"PWRREL", DI_FLOAT);
	// Add the CJC's C to Data Items
	int boardNo;
	int cjcNo;
	for (ioCount = DI_IO_CJC_FIRST; ioCount <= DI_IO_CJC_LAST; ioCount++) {
		// get the board and channel no
		GetCJCBoardAndChanneFromDIRef(ioCount, boardNo, cjcNo);
		swprintf(varName, MAX_VARNAME_LEN, L"CJC%d%d", boardNo + 1, cjcNo + 1);
		tempDiIndex = itemCount;
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_CJC_MULTI_CHAN, ioCount, varName, DI_FLOAT);
		// ensure the status is invalid - this will get set correctly on startup if CJC(s) exist
		m_IODataItemArray[tempDiIndex].SetStatus(DISTAT_INVALID);
	}
	// Add the CJC's C to Data Items
	for (ioCount = DI_IO_CJC_C_FIRST; ioCount <= DI_IO_CJC_C_LAST; ioCount++) {
		// get the board and channel no
		GetCJCBoardAndChanneFromDIRef(ioCount, boardNo, cjcNo);
		swprintf(varName, MAX_VARNAME_LEN, L"CJC%d%dC", boardNo + 1, cjcNo + 1);
		tempDiIndex = itemCount;
		AddDataItem(&m_IODataItemArray[itemCount++], DI_IO_CJC_MULTI_CHAN, ioCount, varName, DI_FLOAT);
		// ensure the status is invalid - this will get set correctly on startup if CJC(s) exist
		m_IODataItemArray[tempDiIndex].SetStatus(DISTAT_INVALID);
	}
	// Set the dummy IO Data Item
	SetDummyDataItem(new CDataItemIO());
	return retVal;
}
//****************************************************************************
/// Converts a slot and channel number into a CJC V7AI data item reference number
///
/// @return - the data item reference
///
//****************************************************************************
int CDataItemTypeIO::GetCJCDIRef(int boardNo, int channelNo, bool degCIsRequired) {
	int offset = 0;
	// Note: board/slot number is 0-based, channel is 0 based
	if (degCIsRequired) {
		offset = DI_IO_CJC_C_FIRST;
	}
	return offset + (boardNo * 4) + (channelNo / 2);
}
//****************************************************************************
/// Converts a CJC V7AI data item reference number into a slot and board specific CJC number
///
//****************************************************************************
void CDataItemTypeIO::GetCJCBoardAndChanneFromDIRef(int diRef, int &rBoardNo, int &rCJCNo) {
	// Note: board/slot number is 0-based, channel is 0 based
	// check it's not a deg C reference
	if (diRef > DI_IO_CJC_LAST) {
		// this is a CJC C reference so normalise it as board and slot still the same
		diRef -= DI_IO_CJC_C_FIRST;
	}
	// there are 4 channels per card, so divide by 4 to get the slot number 
	rBoardNo = (diRef / 4);
	rCJCNo = diRef % 4;
}
//****************************************************************************
/// ApplyConfig overridden method, handle all configuration changes and startup
/// Will be called on startup when configuration in place and every time
/// the current configuration changes.
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeIO::ApplyConfig() {
	T_DI_RETURN retVal = DI_OKAY;
	UCHAR SlotNumber;		// Number of slot that channel is in
	UCHAR SlotChannel;		// Number of channel in that slot
	UCHAR ChannelType;		// Type of channel per slot/channel
	USHORT AIAcqRate;			// Acqusition rate of channel
	USHORT CMMAIAcqRate;			// Acqusition rate of channel
	CDataItemIO *pDITIO;		// Pointer to data IO item
	T_PAICHANNEL pAIInput;	// Pointer to analogue input structure in config
	// Get the acquisiton rates for the Analogue inputs
	for (int aiNumber = 0; aiNumber < MAX_ANALOGUE_IN; aiNumber++) {
		// Get slot, channel and type from the system analogue input number
		SlotNumber = m_pSlotMap->GetAnaInChannelSlotNo(aiNumber, ZERO_BASED);
		SlotChannel = m_pSlotMap->GetBoardChannelFromAnaInChannel(aiNumber, ZERO_BASED);
		ChannelType = pDEVICE_INFO->GetChannelCaps(SlotNumber, SlotChannel);
		// Get handle on DIT for this AI
		pDITIO = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE, aiNumber));
		// Get pointer to current configuration for this analogue input
		pAIInput = pSETUP->GetIOSetupConfig()->GetAnalogueInput(SlotNumber, SlotChannel, CONFIG_COMMITTED);
		if (ChannelType == CHANNEL_CAP_AI && pAIInput != NULL) {
			// If the analogue input is enabled, set up rate and zero/span
			if (pAIInput->Enabled == TRUE) {
				// Convert from Hz to number of ticks per second
//				AIAcqRate = PROCESS_TICKS_PER_SECOND / pSETUP->GetIOSetupConfig()->GetAIChannelRateFromConfiguration(pAIInput->AcqRate);
				pSETUP->GetIOSetupConfig()->QueryAIAcqRate(CONFIG_COMMITTED, SlotNumber, SlotChannel, &CMMAIAcqRate);
				AIAcqRate = PROCESS_TICKS_PER_SECOND /
				pSETUP->GetIOSetupConfig()->GetAIChannelRateFromConfiguration(static_cast<UCHAR>(CMMAIAcqRate));
				pDITIO->SetRange(pAIInput->EngZero, pAIInput->EngSpan);
			} else {
				AIAcqRate = DEFAULT_RATE;
			}
			pDITIO->SetEnabled(pAIInput->Enabled);
		} else {
			pDITIO->SetEnabled( FALSE);
			AIAcqRate = DEFAULT_RATE;
		}
		pDITIO->SetRate(AIAcqRate);
	}
	// Set the direction of each Digital Digital IO Type
	for (int dioNumber = 0; dioNumber < MAX_DIGITAL_IO; dioNumber++) {
		pDITIO = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, dioNumber));
		pDITIO->SetChannelDirection(dioNumber);
		// Get slot, channel and type from the system digital number
		SlotNumber = m_pSlotMap->GetDigitalChannelSlotNo(dioNumber, ZERO_BASED);
		SlotChannel = m_pSlotMap->GetBoardChannelFromDigitalChannel(dioNumber, ZERO_BASED);
		ChannelType = pDEVICE_INFO->GetChannelCaps(SlotNumber, SlotChannel);
		if ((ChannelType & CHANNEL_CAP_DI) != 0) {
			pDITIO->SetRate(10);
		}
	}
	// ALways set power relay to an output
	pDITIO = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, DI_IO_DIG_POWERRELAY));
	pDITIO->SetDirectionType(CDataItemIO::typeOUT);
	return retVal;
}
//=============================================================================
// CDataItemIO Class
//=============================================================================
//****************************************************************************
/// CDataItemIO Constructor
//****************************************************************************
CDataItemIO::CDataItemIO() {
	SetRange(0, 100);
	m_dirType = CDataItemIO::typeIN;	// Default to input type
}
//****************************************************************************
/// Setup the IO type for digital data item
///
/// @return - nothing
///
//****************************************************************************
void CDataItemIO::SetChannelDirection(USHORT channelNumber) {
	m_dirType = CDataItemIO::typeIN;	// Default to input type
	CSlotMap *pSlotMap = CSlotMap::GetHandle();
	switch (pSlotMap->GetBottomSlotChannelSelectedType(channelNumber, ZERO_BASED)) {
	case CHANNEL_DI:
		SetDirectionType(CDataItemIO::typeIN);	// Input
		break;
	case CHANNEL_DO:
		SetDirectionType(CDataItemIO::typeOUT);	// Output
		break;
	}
}
//=============================================================================
// CDataItemDigitalIOUser Class
//=============================================================================
//****************************************************************************
/// CDataItemIO Constructor
//****************************************************************************
CDataItemDigitalIOUser::CDataItemDigitalIOUser() {
	for (int digiIOIndex = 0; digiIOIndex < DIGITAL_IO_INC_POWER_RELAY; digiIOIndex++) {
		m_pDataItem[digiIOIndex] = NULL;
		indexCache[digiIOIndex] = 0;
	}
	m_NumberInIndexCache = 0;
	m_pDITIOContainer = NULL;
}
//****************************************************************************
/// Initialise the digital IO user, setup pointers to the data items for 
/// quick access
///
/// @return - nothing
///
//****************************************************************************
void CDataItemDigitalIOUser::Initialise() {
	// Set-up pointers to all the digital IO data items
	int digiIOIndex = 0;
	for (digiIOIndex = 0; digiIOIndex < MAX_DIGITAL_IO; digiIOIndex++) {
		m_pDataItem[digiIOIndex] = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL,
				digiIOIndex));
	}
	// Set-up pointer to power relay
	m_pDataItem[digiIOIndex] = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC,
			DI_IO_DIG_POWERRELAY));
	m_pDITIOContainer = reinterpret_cast<CDataItemTypeIO*>(pDIT->GetContainerPtr(DI_IO));
}
//**********************************************************************
/// Build a quick lookup cache from a T_DIGITALMASK to only access the required
/// digital items.
/// 
/// @param[in] DigMask - mask of data items to check
///
/// @return		nothing
/// 
//**********************************************************************
void CDataItemDigitalIOUser::BuildCacheFromMask(T_DIGITALMASK *pDigMask) {
	m_NumberInIndexCache = 0;
	for (int digiIOIndex = 0; digiIOIndex < DIGITAL_IO_INC_POWER_RELAY; digiIOIndex++) {
		if (GetStatusOfBit(digiIOIndex, pDigMask) == TRUE) {
			indexCache[m_NumberInIndexCache++] = digiIOIndex;
		}
	}
}
//**********************************************************************
/// Build the outputCache on start-up
/// 
/// @param[in] DigMask - mask of data items to check
///
/// @return		nothing
/// 
//**********************************************************************
void CDataItemDigitalIOUser::BuildOutputCacheAtStartup(void) {
	// initialise outputCache settings without going into alarm in the state machine	
	for (int digiIOCacheIndex = 0; digiIOCacheIndex < m_NumberInIndexCache; digiIOCacheIndex++) {
		m_pDITIOContainer->IncrementOutputCache(indexCache[digiIOCacheIndex]);// Add one (this alarm) for each relay in cache
	}
}
//**********************************************************************
/// Check if any of the cached digital inputs are asserted
/// 
/// @param[in] DigMask - ptr to the T_DIGITALMASK to test, NULL to use cache
///
/// @return		TRUE if any of the digitals asserted, otherwise FALSE
/// 
//**********************************************************************
BOOL CDataItemDigitalIOUser::AnyOfTheseDigitalInputAsserted(T_DIGITALMASK *pDigMask) {
	BOOL aDigitalIsAsserted = FALSE;
	if (pDigMask == NULL) {
		// Run though the cached index to test for any of the cached digitals being asserted
		for (int digiIOCacheIndex = 0; digiIOCacheIndex < m_NumberInIndexCache; digiIOCacheIndex++) {
			if (GetDigitalState(digiIOCacheIndex) == digassert) {
				aDigitalIsAsserted = TRUE;
				break;
			}
		}
	} else {
		// Run through all digitals and test if any of the digital in the mask are assterted
		for (int digiIOIndex = 0; digiIOIndex < DIGITAL_IO_INC_POWER_RELAY; digiIOIndex++) {
			if (GetStatusOfBit(digiIOIndex, pDigMask) == TRUE) {
				if (GetDigitalState(digiIOIndex) == digassert) {
					aDigitalIsAsserted = TRUE;
					break;
				}
			}
		}
	}
	return aDigitalIsAsserted;
}
//**********************************************************************
/// Set digital outputs from the Cached values
/// 
/// @param[in] DigMask - set type for digital output T_DIG_STATE use digCLEAR or digassert
/// @param[in] DigMask - ptr to the T_DIGITALMASK to Aseert or clear, NULL to use cache
///
/// @return		nothing
/// 
//**********************************************************************
void CDataItemDigitalIOUser::SetDigitalOutputs(T_DIG_STATE setType, T_DIGITALMASK *pDigMask) {
	if (pDigMask == NULL) {
		// Run though the cached index to and assert these digitals
		for (int digiIOCacheIndex = 0; digiIOCacheIndex < m_NumberInIndexCache; digiIOCacheIndex++) {
			SetDigitalState(setType, digiIOCacheIndex);
		}
	} else {
		// Run through all digitals and test if any of the digital in the mask are assterted
		for (int digiIOIndex = 0; digiIOIndex < DIGITAL_IO_INC_POWER_RELAY; digiIOIndex++) {
			if (GetStatusOfBit(digiIOIndex, pDigMask) == TRUE) {
				SetDigitalState(setType, digiIOIndex);
			}
		}
	}
}
QString CDataItemDigitalIOUser::LogAlarmDigitalOutputs() {
	QString printMsg(QString::fromWCharArray(L" DIO:"));
	QString tmp("");
	// Run through the cached index to check and assert these digitals
	for (int digiIOCacheIndex = 0; digiIOCacheIndex < m_NumberInIndexCache; digiIOCacheIndex++) {
		BOOL bState = 0;
		bState = GetDigitalState(digiIOCacheIndex);	// always set asserted status	
		tmp.vsp(L"%d ", bState);
		printMsg += tmp;
	}
	return printMsg;
}
BOOL CDataItemDigitalIOUser::AnyOfTheseDIOAsserted(T_DIGITALMASK *pDigMask) {
	return AnyOfTheseDigitalInputAsserted(pDigMask);
}
BOOL CDataItemDigitalIOUser::AnyOfTheseDIOCleared(T_DIGITALMASK *pDigMask) {
	BOOL bDIOCleared = FALSE;
	if (NULL == pDigMask) {
		// Run though the cached index to test for any of the cached digitals being asserted
		//Check for the first 2 relays only for temporary for BI config
		for (int digiIOCacheIndex = 0; digiIOCacheIndex < m_NumberInIndexCache; digiIOCacheIndex++) {
			int nDioNumber = indexCache[digiIOCacheIndex];
			// Get slot, channel and type from the system digital number
			CSlotMap *pSlotMap = CSlotMap::GetHandle();
			USHORT usSlotNumber = pSlotMap->GetDigitalChannelSlotNo(nDioNumber, ZERO_BASED);
			USHORT usSlotChannel = pSlotMap->GetBoardChannelFromDigitalChannel(nDioNumber, ZERO_BASED);
			// Get the config block for a Pen from the CMM
			T_PDIGCHANNEL pDigChan = NULL;
			pDigChan = pSETUP->GetIOSetupConfig()->GetDigital(usSlotNumber, usSlotChannel, CONFIG_COMMITTED);
			if (NULL != pDigChan) {
				//Check if the Digital IO is latched or not
				if ( TRUE == pDigChan->DigO.OPLatched) {
					//For lacthed output only get the state and check if it is in CLEAR STATE
					if (GetDigitalState(digiIOCacheIndex) == digCLEAR) {
						bDIOCleared = TRUE;
						break;
					}
				}
			}
		}
	} else {
		// Run through all digitals and test if any of the digital in the mask are assterted
		for (int digiIOIndex = 0; digiIOIndex < DIGITAL_IO_INC_POWER_RELAY; digiIOIndex++) {
			if (GetStatusOfBit(digiIOIndex, pDigMask) == TRUE) {
				if (GetDigitalState(digiIOIndex) == digCLEAR) {
					bDIOCleared = TRUE;
					break;
				}
			}
		}
	}
	return bDIOCleared;
}
//**********************************************************************
/// Set digital outputs from the Cached values - used by Alarms only
/// 
/// @param[in] DigMask - set type for digital output T_DIG_STATE use digCLEAR or digassert
/// @param[in] DigMask - ptr to the T_DIGITALMASK to Aseert or clear, NULL to use cache
///
/// @return		nothing
/// 
//**********************************************************************
void CDataItemDigitalIOUser::SetAlarmDigitalOutputs(T_DIG_STATE setType, T_DIGITALMASK *pDigMask) {
	if (pDigMask == NULL) {
		// Run through the cached index to check and assert these digitals
		for (int digiIOCacheIndex = 0; digiIOCacheIndex < m_NumberInIndexCache; digiIOCacheIndex++) {
			// first update outputCache, then set new state if required
			if (setType == digassert) {
				m_pDITIOContainer->IncrementOutputCache(indexCache[digiIOCacheIndex]);
				//qDebug("indexCache[digiIOCacheIndex] = %d\n", (int) indexCache[digiIOCacheIndex] );
				//qDebug("Inc outputCache[indexCache[digiIOCacheIndex]] = %d\n", (int) (pALARM_OVERVIEW->GetOutputCache(indexCache[digiIOCacheIndex])));
				SetDigitalState(setType, digiIOCacheIndex);	// always set asserted status
			} else // request to clear - only action if no alarms are still asserting
			{
				if (m_pDITIOContainer->GetOutputCache(indexCache[digiIOCacheIndex]) > 0) {
					m_pDITIOContainer->DecrementOutputCache(indexCache[digiIOCacheIndex]); // decrement alarms requesting assert
				}
				if (m_pDITIOContainer->GetOutputCache(indexCache[digiIOCacheIndex]) == 0) // check if none left asserting - OK to clear
						{
					//qDebug("indexCache[digiIOCacheIndex] = %d\n", (int) indexCache[digiIOCacheIndex] );
					//qDebug("Inc outputCache[indexCache[digiIOCacheIndex]] = %d\n", (int) (pALARM_OVERVIEW->GetOutputCache(indexCache[digiIOCacheIndex])));				
					SetDigitalState(setType, digiIOCacheIndex);
				}
			}
		}
	} else {
		// Run through all digitals and test if any of the digital in the mask are asserted
		for (int digiIOIndex = 0; digiIOIndex < DIGITAL_IO_INC_POWER_RELAY; digiIOIndex++) {
			if (GetStatusOfBit(digiIOIndex, pDigMask) == TRUE) {
				//MarkD: first update outputCache, then set new state if required
				if (setType == digassert) {
					m_pDITIOContainer->IncrementOutputCache(digiIOIndex);
					SetDigitalState(setType, digiIOIndex);	// always set asserted status
				} else // request to clear - only action if no alarms are still asserting
				{
					if (m_pDITIOContainer->GetOutputCache(digiIOIndex) > 0)
						m_pDITIOContainer->DecrementOutputCache(digiIOIndex);	// decrement alarms requesting assert
					if (m_pDITIOContainer->GetOutputCache(digiIOIndex) == 0)// check if none left asserting - OK to clear
						SetDigitalState(setType, digiIOIndex);
				}
			}
		}
	}
}
//**********************************************************************
/// Clear old relays - only used to clear relays when disabling an active alarm
///
/// @return		nothing
/// 
//**********************************************************************
void CDataItemDigitalIOUser::ClearDigitalState(void) {
	// If the new outputCache has a zero where the old (oldOutputCache) has an entry,
	// this indicates that the alarm(s) which caused the old entry are no longer active
	// and the relay state should be reset. More than one indicates other alarms are still active, so 
	// decrement the old cache and zero the relay if all alarms are removed.
	for (int digiIOIndex = 0; digiIOIndex < DIGITAL_IO_INC_POWER_RELAY; digiIOIndex++) {
		if ((m_pDITIOContainer->GetOutputCache(digiIOIndex) == 0)
				&& (m_pDITIOContainer->GetOldOutputCache(digiIOIndex) > 0)) {
			m_pDITIOContainer->DecrementOldOutputCache(digiIOIndex);
			if (m_pDITIOContainer->GetOldOutputCache(digiIOIndex) == 0) {
				// alarms have been disabled while active - reset them (clear the defined relay)
				m_pDataItem[digiIOIndex]->SetValue(static_cast<float>(CDataItemDigitalIOUser::digCLEAR));
			}
		}
	}
}
//**********************************************************************
/// Clear relays from DI-enabled state - only used to clear relays from start-up
///
/// @return		nothing
/// 
//**********************************************************************
void CDataItemDigitalIOUser::ClearDIenabledState(void) {
	// Run through the cached index to check and potentially clear these digitals
	for (int digiIOCacheIndex = 0; digiIOCacheIndex < m_NumberInIndexCache; digiIOCacheIndex++) {
		// request to clear - only action if no alarms are still asserting
		if (m_pDITIOContainer->GetOutputCache(indexCache[digiIOCacheIndex]) == 0)// check if none left asserting - OK to clear
				{
			SetDigitalState(CDataItemDigitalIOUser::digCLEAR, digiIOCacheIndex);
		}
	}
}
//**********************************************************************
/// Get the status of a bit in the digital mask
/// 
/// @param[in] bitNumber - number of bit we want to find
/// @param[in] pBits - ptr to the T_DIGITALMASK to return bit from
///
/// @return		TRUE if bit set otherwise FALSE
/// 
//**********************************************************************
BOOL CDataItemDigitalIOUser::GetStatusOfBit(USHORT bitNumber, T_DIGITALMASK *pBits) {
	// MIPSII 32bit processor, bit process on whole register most effective
	USHORT BitIndex = bitNumber >> 5;		// divide by 32 provides index into 32 bit 
	USHORT BitBit = bitNumber & 0x1F;		// mask to find remainder gicing bit number 0-31
	return (BOOL) ((pBits->L[BitIndex] >> BitBit) & 0x01);
}

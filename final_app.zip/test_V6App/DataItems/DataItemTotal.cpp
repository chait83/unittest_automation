/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemAlarm.cpp
/// @n Desc:	 Pen Alarm items for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//12Stability Project 1.7.1.3 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//11Stability Project 1.7.1.2 7/1/2011 4:38:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//10Stability Project 1.7.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//9 Stability Project 1.7.1.0 2/15/2011 3:02:53 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "DataItemTotal.h"
#include "ErrorServices.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//=============================================================================
// CDataItemTypeTotal Class
//=============================================================================
//****************************************************************************
/// CDataItemTypeTotal Constructor
//****************************************************************************
CDataItemTypeTotal::CDataItemTypeTotal() {
}
//****************************************************************************
/// CDataItemTypeTotal Destructor
//****************************************************************************
CDataItemTypeTotal::~CDataItemTypeTotal() {
	m_TotalDataItemArray.clear();
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeTotal::CreateItemTable() {
	T_DI_RETURN retVal = DI_OKAY;
	//qDebug("Create Data Item table for a %d Totals\n",V6_MAX_PENS*DI_TOTAL_MAXTYPES);
	// Stage 1, Create the memory space for the DataItems
	m_TotalDataItemArray.resize(V6_MAX_PENS * DI_TOTAL_MAXTYPES);
	SetDataItemInfo(DI_TOTAL, DI_TOTAL_MAXTYPES, V6_MAX_PENS); // Type Alarm, number of alarms types and Max Pens instance.
	// Stage 2, initialise the data items
	WCHAR varName[MAX_VARNAME_LEN];
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"T%d", penCount + 1);
		AddDataItem(&m_TotalDataItemArray[penCount], DI_TOTAL_READING, penCount, QString::fromWCharArray(varName),
				DI_FLOAT);
	}
	// Set the dummy MMA Data Item
	SetDummyDataItem(new CDataItemTotal());
	return retVal;
}
//****************************************************************************
/// ApplyConfig overridden method, handle all configuration changes and startup
/// Will be called on startup when configuration in place and every time
/// the current configuration changes.
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeTotal::ApplyConfig() {
	T_DI_RETURN retVal = DI_OKAY;
	CDataItemTotal *pTotalDIT;
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		// Get a handle on the Alarm Data Item
		pTotalDIT = (CDataItemTotal*) GetDataItemPtr(DI_TOTAL_READING, penCount);
		pTotalDIT->SetTotalEnable();
		pTotalDIT->SetTotalScaleInfo();
	}
	return retVal;
}
//****************************************************************************
/// Link CDataItemTypeTotal table items to CDataItemTypePen items as these
/// Alarms are all derived from a Pen
///
/// @param[in] - pLinkPenType, ptr to Pen DIT Type, this type is dependent on Pens
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeTotal::LinkPenTypes(CDataItemTypePen *pLinkPenType) {
	T_DI_RETURN retVal = DI_OKAY;
	CDataItemTotal *pTotalDIT;
	// Loop through all Pens and assign the Pen Data Item to each of the MMA types
	// so they can derive their details from the Pens.
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		pTotalDIT = (CDataItemTotal*) GetDataItemPtr(DI_TOTAL_READING, penCount);
		// Assign Pen Data Item to the Alarm Data Item
		pTotalDIT->SetPenDITPtr((CDataItemPen*) pLinkPenType->GetDataItemPtr(DI_PEN_READING, penCount));
	}
	// Setup the dummy data item to look at the dummy pen data item
	reinterpret_cast<CDataItemTotal*>(GetDummyDataItem())->SetPenDITPtr(
			(CDataItemPen*) pLinkPenType->GetDummyDataItem());
	return retVal;
}
//=============================================================================
// CDataItemTotal Class
//=============================================================================
//****************************************************************************
/// Setup the DIT enabled flags for this type
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemTotal::SetTotalEnable() {
	BOOL enabled = FALSE;		// Default the enable to false
	// If the Pen is enabled, get the individual enabled setting for the alarm
	if (m_pPenDIT->IsEnabled()) {
		enabled = m_pPenDIT->m_pPenConfig->Tot.Enabled;
	}
	SetEnabled(enabled);		// Set the enabled status of the 
	RegisterChange();
}
//****************************************************************************
/// Get the colour of the Data Item, will return the disabled colour of disabled
///
/// @return - pointer to a COLOREF
//****************************************************************************
COLORREF* CDataItemTotal::GetColour() {
	if (IsEnabled())
		return m_pPenDIT->GetColour();
	else
		return &GlbDITDisabaledColour;
}
//****************************************************************************
/// Setup the scale information for a totlaiser
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemTotal::SetTotalScaleInfo() {
	m_ScaleInfo = m_pPenDIT->m_pPenConfig->Scale;				// Set totaliser to pen scale by default
	m_ScaleInfo.NumF = m_pPenDIT->m_pPenConfig->Tot.NumF;		// Set totlaiser number format the same
	// Set the totaliser to Auto divs and scale.
	m_ScaleInfo.automaticDivs = TRUE;
	//m_ScaleInfo.NumF.Auto = TRUE;	// MarkD: don't force auto - get from menu
	// Setup the zero and span (as best we can for totals)
	if (m_pPenDIT->m_pPenConfig->Tot.Type == TOTAL_TYPE_STANDARD) {
		// Always use the Min and Max range
		m_ScaleInfo.Zero = m_pPenDIT->m_pPenConfig->Tot.MinRange;
		m_ScaleInfo.Span = m_pPenDIT->m_pPenConfig->Tot.MaxRange;
	} else {
		// It's a sterilisation and we default the scale to 0 - completion factor
		m_ScaleInfo.Zero = 0;
		m_ScaleInfo.Span = m_pPenDIT->m_pPenConfig->Tot.CompleteVal;
		if (m_pPenDIT->m_pPenConfig->Tot.IncludeCool) {
			// If cooling is included then add on half the completion factor again.
			m_ScaleInfo.Span += m_pPenDIT->m_pPenConfig->Tot.CompleteVal / 2;
		}
	}
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemIO.h
/// @n Desc:	 IO specific details for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//19Stability Project 1.16.1.1 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//18Stability Project 1.16.1.0 7/1/2011 4:27:17 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//17V6 Firmware 1.16 11/9/2006 3:22:31 PMGraham Waterfield
//Added 1 based DIT holder value for fixed relay
//16V6 Firmware 1.15 3/6/2006 9:30:04 PM Mark Dennison 
//Increase reliability of alarm disabling/config changes/power cycling
// $
//
// ****************************************************************
#ifndef __DATAITEMIO_H__
#define __DATAITEMIO_H__
#include "DataItemBase.h"
#include "V6defines.h"
#include "SlotMap.h"
#include <QVector>
/// IO Types available, This is used a the Data item "sub type"
typedef enum {
	DI_IO_ANALOGUE = 0,			///< Analogue value in conditioned engineering units
	DI_IO_DIGITAL,				///< Individual digital IO status
	DI_IO_HIPULSE,				///< Hi Resolution Pulse inputs(pulse cards)
	DI_IO_LOPULSE,				///< Low Resolution pulse inputs(Di cards as pulse)
	DI_IO_MISC,					///< Misc items, old AI or averaged CJCs, Digital bitmasks etc..
	DI_IO_ANALOGUE_RAW,			///< Analogue in electrical range unit
	DI_IO_RT_COMP,				///< RT Comp Values for each channel
	DI_IO_RT_CAL,				///< RT Cal values for each channel
	DI_IO_CJC_MULTI_CHAN,	///< CJC values for each channel pair
	DI_IO_MAX_TYPES				///< Max item types, NB always at end
} T_DATA_ITEM_IO_LIST;
/// Data items contained within the DI_IO_MISC type of miscallaneous items, used as "Instance"
typedef enum {
	DI_IO_MISC_CJC1 = 0,					///< CJC entries for each card, top slots 1-6 in display units
	DI_IO_MISC_CJC2,
	DI_IO_MISC_CJC3,
	DI_IO_MISC_CJC4,
	DI_IO_MISC_CJC5,
	DI_IO_MISC_CJC6,
	DI_IO_MISC_CJC1_C,					///< CJC entries for each card, top slots 1-6 in deg C always
	DI_IO_MISC_CJC2_C,
	DI_IO_MISC_CJC3_C,
	DI_IO_MISC_CJC4_C,
	DI_IO_MISC_CJC5_C,
	DI_IO_MISC_CJC6_C,
	DI_IO_DIG_BITS_SLOT1,				///< Bit pattern value of digital card, bottom slots 1-3.
	DI_IO_DIG_BITS_SLOT2,
	DI_IO_DIG_BITS_SLOT3,
	DI_IO_DIG_POWERRELAY,				///< Power Relay status
	DI_IO_MISC_LAST						///< Last list item, Always at end
} T_DATA_ITEM_IO_MISC_LIST;
/// Data items contained within the DI_IO_CJC_MULTI_CHAN type of CJC items, used as "Instance"
typedef enum {
	DI_IO_CJC_FIRST, ///< CJC's, going from channel 1/2, 3/4, 5/6 and 7/8 and then to the next slot
	DI_IO_CJC_LAST = DI_IO_CJC_FIRST + 23,
	DI_IO_CJC_C_FIRST,
	DI_IO_CJC_C_LAST = DI_IO_CJC_C_FIRST + 23,
	DI_IO_CJC_END					///< Last list item, Always at end
} T_DATA_ITEM_IO_CJC_MULTI_CHAN_LIST;
//**Class*********************************************************************
///
/// @brief IO point Data Item
/// 
/// This class will provide the support for IO based data items
///
//****************************************************************************
class CDataItemIO: public CDataItem {
public:
	// IO direction type
	enum T_IOTYPE {
		typeIN,			///< Input
		typeOUT,		///< Output
	};
public:
	CDataItemIO();
	void WhoAmI() {
		qDebug("I am IO");
		WhoAmI();
	}
	;
	float GetZero() const {
		return m_Zero;
	}
	;
	float GetSpan() const {
		return m_Span;
	}
	;
	void SetRange(float zero, float span) {
		m_Zero = zero;
		m_Span = span;
	}
	;
	T_IOTYPE GetDirectionType() {
		return m_dirType;
	}
	;
	void SetDirectionType(T_IOTYPE type) {
		m_dirType = type;
	}
	;
	void SetChannelDirection(USHORT channelNumber);
	void SetCounter(ULONG count) {
		m_Counter = count;
	}
	;
	ULONG GetCounter() {
		return m_Counter;
	}
	;
	void IncrementCounter() {
		m_Counter++;
	}
	;
private:
	T_IOTYPE m_dirType;			///< Currently configured as input, output or pulse
	float m_Zero;
	float m_Span;
	ULONG m_Counter;											///< Digital
};
//**Class*********************************************************************
///
/// @brief IO point Data Item Type, container class
/// 
/// This class will provide IO specific access for IO Based data items
///
//****************************************************************************
class CDataItemTypeIO: public CDataItemTypeContainer {
public:
	~CDataItemTypeIO();
	T_DI_RETURN CreateItemTable();		///< Create the Data Item table for 
	T_DI_RETURN ApplyConfig();			///< Apply configuration for data table item.
	//counter access for number of alarms acting on each relay
	void IncrementOutputCache(int digIndex) {
		m_outputCache[digIndex]++;
	}
	;
	void DecrementOutputCache(int digIndex) {
		m_outputCache[digIndex]--;
	}
	;
	int GetOutputCache(int digIndex) {
		return m_outputCache[digIndex];
	}
	;
	void ClearOutputCache() {
		for (int digiIOIndex = 0; digiIOIndex < MAX_DIGITAL_IO + 1; digiIOIndex++)
			m_outputCache[digiIOIndex] = 0;
	}
	;
	//MarkD: de-activate relays on alarm disable
	void SetOldOutputCache() {
		for (int digiIOIndex = 0; digiIOIndex < MAX_DIGITAL_IO + 1; digiIOIndex++)
			m_oldOutputCache[digiIOIndex] = m_outputCache[digiIOIndex];
	}
	;
	int GetOldOutputCache(int digIndex) {
		return m_oldOutputCache[digIndex];
	}
	;
	void DecrementOldOutputCache(int digIndex) {
		m_oldOutputCache[digIndex]--;
	}
	;
	void ClearOldOutputCache() {
		for (int digiIOIndex = 0; digiIOIndex < MAX_DIGITAL_IO + 1; digiIOIndex++)
			m_oldOutputCache[digiIOIndex] = 0;
	}
	;
	static int GetCJCDIRef(int boardNo, int channelNo, bool degCIsRequired);
	static void GetCJCBoardAndChanneFromDIRef(int diRef, int &rBoardNo, int &rCJCNo);
private:
	char a;
	QVector<int> m_IODataItemArray;
	CSlotMap *m_pSlotMap;					///< Handle on Slot map for IO 
	int m_outputCache[DIGITAL_IO_INC_POWER_RELAY];	// cache to indicate number of asserted alarms acting on each relay
	int m_oldOutputCache[DIGITAL_IO_INC_POWER_RELAY];// cache to remember previous alarm dependancies in case of disabled active alarm
};
const int DIGITALS_1_TO_31 = 0;
const int DIGITALS_32_TO_49 = 1;
//**Class*********************************************************************
///
/// @brief IO Digital IO user class
/// 
/// This class provides an interface function allowing optimised digital access
/// to the data item table
///
//****************************************************************************
class CDataItemDigitalIOUser {
public:
	enum T_DIG_STATE {
		digCLEAR = 0,				///< Clear the digital output (de assert)
		digassert = 1,			///< assert the digital output
	};
public:
	CDataItemDigitalIOUser();
	void Initialise();
	void BuildCacheFromMask(T_DIGITALMASK *pDigMask);
	void BuildOutputCacheAtStartup(void);
	BOOL AnyOfTheseDigitalInputAsserted(T_DIGITALMASK *pDigMask);
	void SetDigitalOutputs(T_DIG_STATE setType, T_DIGITALMASK *pDigMask);
	void SetAlarmDigitalOutputs(T_DIG_STATE setType, T_DIGITALMASK *pDigMask);
	void ClearDigitalState(void);	//MarkD
	void ClearDIenabledState(void); //MarkD
	QString LogAlarmDigitalOutputs();
	BOOL AnyOfTheseDIOAsserted(T_DIGITALMASK *pDigMask = NULL);
	BOOL AnyOfTheseDIOCleared(T_DIGITALMASK *pDigMask = NULL);
private:
	BOOL GetStatusOfBit(USHORT bitNumber, T_DIGITALMASK *pBits);
	CDataItemIO *m_pDataItem[DIGITAL_IO_INC_POWER_RELAY];		// Cached pointers to IO data item table
	void SetDigitalState(T_DIG_STATE setType, int digitalIndex) {
		m_pDataItem[indexCache[digitalIndex]]->SetValue(static_cast<float>(setType));
	}
	;
	T_DIG_STATE GetDigitalState(int digitalIndex) {
		return static_cast<T_DIG_STATE>((int) m_pDataItem[indexCache[digitalIndex]]->GetFPValue());
	}
	;
private:
	int indexCache[DIGITAL_IO_INC_POWER_RELAY];				// Cache of indexes, pre-built list of Data Items to process
	int m_NumberInIndexCache;
	CDataItemTypeIO *m_pDITIOContainer;
};
#endif // __DATAITEMIO_H__

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigInterface.cpp
/// @n Description: Implementation of the CConfigInterface class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  9 Stability Project 1.4.1.3 7/2/2011 4:56:16 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  8 Stability Project 1.4.1.2 7/1/2011 4:38:07 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  7 Stability Project 1.4.1.1 3/17/2011 3:20:17 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  6 Stability Project 1.4.1.0 2/15/2011 3:02:39 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "ConfigInterface.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// Static/const initialisations
const WCHAR CConfigInterface::ms_wcDELIMITER = '|';
// Global ENABLED flag to make properties read-only on a standard screen
BOOL CConfigInterface::ms_bENABLED = TRUE;
//****************************************************************************
// CConfigInterface(	const QString   &rstrKEY,
//						const QString   &rstrTITLE,
//						const QString   &rstrSUB_TITLE,
//						const ControlType eCONTROL_TYPE,
//						const bool bMODIFIED,
//						const bool bENABLED,
//						const long lHELP_ID,
//						const bool bLOCKED,
//						CConfigInterface* const pkPARENT,
//						const T_CFG_INTERFACE_TYPE_ENUM eCFG_TYPE )
///
/// Constructor
///
/// @param[in] 			const QString   &rstrKEY - Unique Key used to identify the config item
/// @param[in] 			const QString   &rstrTITLE - Title string to be displayed on the control
/// @param[in] 			const QString   &rstrSUB_TITLE - Subtitle string to be displayed on the control
/// @param[in] 			const ControlType eCONTROL_TYPE - The type of control
/// @param[in] 			const bool bMODIFIED - Flag indicating if this item or any of its children have
///						been modified
/// @param[in] 			const bool bENABLED - Flag indicating if the config item is enabled
/// @param[in] 			const long lHELP_ID - The resource ID for a help string
/// @param[in] 			const bool bLOCKED - Flag indicating if the config item is editable or not - this is
///						to allow the user to browse the configuration structure but to not modify the data
/// @param[in] 			CConfigInterface* const pkPARENT - Pointer to the parent config branch class
/// @param[in] 			const T_CFG_INTERFACE_TYPE_ENUM eCFG_TYPE - Enumerated varaible indicating which
///						inherited type of class this is
///
//****************************************************************************
CConfigInterface::CConfigInterface(const QString &rstrKEY, const QString &rstrTITLE, const QString &rstrSUB_TITLE,
		const ControlType eCONTROL_TYPE, const bool bMODIFIED, const bool bENABLED, const long lHELP_ID,
		const bool bLOCKED, CConfigInterface *const pkPARENT, const T_CFG_INTERFACE_TYPE_ENUM eCFG_TYPE) : m_strTITLE(
		rstrTITLE), m_strKEY(rstrKEY), m_pkParent(pkPARENT), m_eCONTROL_TYPE(eCONTROL_TYPE), m_eCONFIG_INTERFACE_TYPE(
		eCFG_TYPE) {
	m_strSubTitle = rstrSUB_TITLE;
	m_bModified = bMODIFIED;
	m_bEnabled = ms_bENABLED && bENABLED;
	m_bLocked = bLOCKED;
}
//****************************************************************************
// ~CConfigInterface(void)
///
/// Destructor
///
//****************************************************************************
CConfigInterface::~CConfigInterface(void) {
}
//****************************************************************************
// const QString   GetKey( ) const
///
/// Method that dynmamically builds up and returns the key for this item
///
//****************************************************************************
const QString CConfigInterface::GetKey() const {
	QString strCompleteKey(m_strKEY + QString(ms_wcDELIMITER));
	// get the parent key's
	if (m_pkParent != NULL) {
		strCompleteKey = m_pkParent->GetKey() + strCompleteKey;
	}
	return strCompleteKey;
}

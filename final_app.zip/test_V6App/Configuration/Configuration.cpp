/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration
/// @n Filename: Configuration.cpp
/// @n Desc:	 Base configuration class, CMM interface
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  45  Stability Project 1.40.1.3 7/2/2011 4:56:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  44  Stability Project 1.40.1.2 7/1/2011 4:38:08 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  43  Stability Project 1.40.1.1 3/17/2011 3:20:17 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  42  Stability Project 1.40.1.0 2/15/2011 3:02:40 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "configuration.h"
#include "configurationmanager.h"
#include "v6crc.h"
#include "tvtime.h"
#include "configuration.h"
#include "../inc/V6globals.h"
#include "../Media/FileList.h"
#include "../inc/TV6Timer.h"
#include "../MessageList/MessageListServicesItem.h"
#include "../Configuration/V6Config.h"
#include <QtWidgets/qwidget.h>
#include <QString>
#include <QDebug>
#include <QFile>
#include <QMessageBox>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//***************************************************************************************
/// CConfiguration constructor
///
//***************************************************************************************
CConfiguration::CConfiguration(void) : m_ConfigurationId(0) {
	m_ConversionPerformed = FALSE;
}
//***************************************************************************************
/// CConfiguration destructor
///
//***************************************************************************************
CConfiguration::~CConfiguration(void) {
	if (m_ConfigurationId) {
		DeleteConfig();
	}
}
//***************************************************************************************
/// Create a CMM session holder
///
/// @param[in] sessionNumber - session number to create holder with
///
/// @return Pointer to the required block, if any error or does not exist will return NULL
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::CreateCMMHolder(DWORD sessionNumber) {
#ifdef PWDLOGS_ENABLE		
	WCHAR szDbgMsg[512];
#endif
	CMMERROR cmmError = CMM_FAILED;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	// Create a CMM Configuration
	cmmError = CreateConfiguration(&m_ConfigurationId, pSYSTEM_INFO->GetNextSessionNumberPtr());
	if (CMM_SUCCESS == cmmError) {
		qDebug("New config ID %d\n", m_ConfigurationId);
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CConfiguration::CreateCMMHolder: New config ID %d GTC %d\n",m_ConfigurationId,GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		retValue = CONFIG_CMM_HOLDER_CREATED;
	}
	return (retValue);
} // End of Initialise()
//***************************************************************************************
///
/// Create a new block fixed size block in the CMM
///
/// @param[in] blockType - Type of block, see BLK_xxxxx in V6Config.h
/// @param[in] instance - instance of blocktype
/// @param[in] configID - Confgiuration ID to access
///
/// @return Pointer to the required block, if any error or does not exist will return NULL
/// 
//***************************************************************************************
void* CConfiguration::CreateNewBlock(WORD blockType, WORD instance, DWORD configID) {
	BLOCK_INFO blockInfo;
	blockInfo.wInstanceID = instance;
	blockInfo.pByBlock = NULL;								///< Pointer to the actual data
	blockInfo.wBlockType = blockType;
	CreateDataBlock(configID, &blockInfo);
	return blockInfo.pByBlock;
}
//***************************************************************************************
///
/// Create a new block variabled sized block in the CMM
///
/// @param[in] blockType - Type of block, see BLKVARIABLE_xxxxx in v6configuration.h
/// @param[in] instance - instance of blocktype
/// @param[in] size - size of default block in bytes
/// @param[in] configID - Confgiuration ID to access
///
/// @return Pointer to the required block, if any error or does not exist will return NULL
/// 
//***************************************************************************************
void* CConfiguration::CreateNewVariableSizedBlock(WORD blockType, WORD instance, DWORD size, DWORD configID) {
	BLOCK_INFO blockInfo;
	blockInfo.wInstanceID = instance;
	blockInfo.pByBlock = NULL;								///< Pointer to the actual data
	blockInfo.wBlockType = blockType;
	blockInfo.dwBlockSize = size;
	CMMERROR cmmErr = CreateDataBlock(configID, &blockInfo);
	return blockInfo.pByBlock;
}
//***************************************************************************************
///
/// Modify variabled sized block in the CMM
///
/// @param[in] blockType - Type of block, see BLKVARIABLE_xxxxx in v6configuration.h
/// @param[in] instance - instance of blocktype
/// @param[in] size - size of new block in bytes
/// @param[in] *pNewBlock - pointer to new block
/// @param[in] configID - Confgiuration ID to access
///
/// @return CMMERROR if having trouble creating the new block
/// 
//***************************************************************************************
CMMERROR CConfiguration::ModifyVariableSizedBlock(WORD blockType, WORD instance, DWORD size, BYTE *pNewBlock,
		DWORD configID) {
	BLOCK_INFO blockInfo;
	CMMERROR cmmResult = CMM_SUCCESS;
	blockInfo.wInstanceID = instance;
	blockInfo.pByBlock = pNewBlock;								///< Pointer to the actual data
	blockInfo.wBlockType = blockType;
	blockInfo.dwBlockSize = size;
	cmmResult = ModifyDataBlock(configID, &blockInfo);
	return cmmResult;
}
//***************************************************************************************
///
/// Static function to get a block from the CMM
///
/// @param[in] blockType - Type of block, see BLK_xxxxx in V6Config.h
/// @param[in] instance - instance of blocktype
/// @param[in] configID - Confgiuration ID to access
/// @param[in] cfgType - The type of configuration to access CONFIG_MODIFIABLE or CONFIG_COMMITTED
///
/// @return Pointer to the required block, if any error or does not exist will return NULL
/// 
//***************************************************************************************
void* CConfiguration::GetBlock(WORD blockType, WORD instance, DWORD configID, REFERENCE cfgType) {
	BLOCK_INFO blockInfo;
	// Setup block info structure to pass into CMM
	blockInfo.wInstanceID = instance;
	blockInfo.pByBlock = NULL;								///< Pointer to the actual data
	blockInfo.wBlockType = blockType;
	CMMERROR cmmResult = GetDataBlock(configID, &blockInfo, cfgType);
	return blockInfo.pByBlock;
}
//***************************************************************************************
///
/// Static function to test if a block has been changed in the CMM
///
/// @param[in] blockType - Type of block, see BLK_xxxxx in V6Config.h
/// @param[in] instance - instance of blocktype
/// @param[in] configID - Confgiuration ID to access
///
/// @return TRUE if block chnaged, otherwise FALSE
/// 
//***************************************************************************************
BOOL CConfiguration::WasBlockModified(WORD blockType, WORD instance, DWORD configID) {
	BLOCK_INFO blockInfo;
	BOOL blockModified = FALSE;
	// Setup block info structure to pass into CMM
	blockInfo.wInstanceID = instance;
	blockInfo.pByBlock = NULL;
	blockInfo.wBlockType = blockType;
	blockInfo.dwSessionNumber = 0;
	// Check the commited setup to see if a block was modified
	GetDataBlock(configID, &blockInfo, CONFIG_COMMITTED);
	// Check if session numbers match, if they do the block was recently changed
	if (blockInfo.dwSessionNumber == pSYSTEM_INFO->GetNextSessionNumber()) {
		// Block is the same as the current session
		blockModified = TRUE;
	}
	return blockModified;
}
//***************************************************************************************
/// Save a configuration by QFile object
///
/// @param[in] pFile - Pointer to QFile object to perform configuration save with
///
/// @return T_CONFIG_RETURN_VALUE result
/// 
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::SaveConfig(QFile *pFile) {
	DWORD configBufferSize = 0; ///< Size of the current configuration
	BYTE *pConfigBuffer = NULL;  ///< Pointer to the current configuration
	USHORT configFileCRCValue = 0; ///< Calculated CRC for Config File
	CMMERROR err;
	CONFIGHEADERINFO pLogConfigDetails;
    //swprintf(pLogConfigDetails.szFileName, "%s", pFile->fileName());
    pFile->fileName().toWCharArray(pLogConfigDetails.szFileName);
    pLogConfigDetails.szFileName[pFile->fileName().size()] = L'\0';
    QDateTime  ourTime;
    ourTime.currentDateTime();
    pLogConfigDetails.dtCreationDateTime = ourTime.toMSecsSinceEpoch() * 1000LL;
    pLogConfigDetails.szPassword[0] = L'\0';
    pLogConfigDetails.wEncryption = 0;
    pLogConfigDetails.wFileType = 1;
    pLogConfigDetails.dwSource = 0;
    pLogConfigDetails.dwAction = 1;
	// Update log entry
	err = SetConfigurationLog(m_ConfigurationId, &pLogConfigDetails);
	// Request pointer to config 
	err = GetConfiguration(m_ConfigurationId, &configBufferSize, &pConfigBuffer);
	// Calculate the CRC for the entire Config File, this value
	// shall be appended to the end of the config file.  
    const char* constCharArray = reinterpret_cast<const char*>(pConfigBuffer);
    configFileCRCValue = CrcCalc(pConfigBuffer, configBufferSize);
    pFile->write(constCharArray, configBufferSize);
	// Write High Byte of the CRC to the file
	BYTE highByte = (BYTE) (configFileCRCValue >> 8);
    const char* constCharArrayHighByte = reinterpret_cast<const char*>(highByte);
    pFile->write(constCharArrayHighByte, sizeof(BYTE));
	// Write Low Byte of the CRC to the file

	BYTE lowByte = (BYTE) (configFileCRCValue & 0xFF);
    const char* constCharArrayLowByte = reinterpret_cast<const char*>(lowByte);
    pFile->write(constCharArrayLowByte, sizeof(BYTE));
	return T_CONFIG_RETURN_VALUE();
}
//***************************************************************************************
/// Commit a configuration, wraps the call to CMM
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::CommitConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_CMM_COMMIT_CONFIG_ERROR;
	if (CMM_SUCCESS == CommitConfiguration(m_ConfigurationId)) {
		retValue = CONFIG_OK;
	}
	return (retValue);
}
//***************************************************************************************
/// Save a configuration by QFile object
///
/// @param[in] pConfigFileName - Path and filename of configuration to check
/// @param[in] fileType - target filetype to check for T_CONFIG_FILE_TYPE
///
/// @return TRUE if a valid config file of required type, otherwise FALSE
/// 
//***************************************************************************************
BOOL CConfiguration::ValidateConfigFile(QString pConfigFileName, T_CONFIG_FILE_TYPE fileType) {
	BYTE pConfigFileHeaderBuffer[sizeof(CONFIGFILE_HEADER)];
	BOOL retValue = FALSE;
	CONFIGFILE_HEADER *pConfigFileHeader = NULL;
	// Create an Instance of CStorage for accessing the Configuration File to
	// be loaded.
	CStorage configFile;
	// Open the Configuration File
	configFile.Open(pConfigFileName, QFile::ReadOnly);
	// Read the Configuration File Header into Memory
	configFile.Read(pConfigFileHeaderBuffer, sizeof(CONFIGFILE_HEADER));
	// Close the File
	configFile.Close();
	// Undertake the validation checks required, file type, password etc
	// Validate whether the file is of the correct type
	pConfigFileHeader = (CONFIGFILE_HEADER*) (pConfigFileHeaderBuffer);
	if (fileType == (T_CONFIG_FILE_TYPE) pConfigFileHeader->wFileType) {
		retValue = TRUE;
	}
	return (retValue);
}
//***************************************************************************************
/// Delete a configuration from the CMM
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::DeleteConfig(void) {
	if (m_ConfigurationId) {
		DeleteConfiguration(m_ConfigurationId);
		m_ConfigurationId = 0;	// indicate we have no configuration now
	}
	return (CONFIG_OK);
}
//***************************************************************************************
/// Wait for an available configuration after loading into CMM
///
/// @param[in] cmmSection - CONFIG_MODIFIABLE or CONFIG_COMMITTED
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::WaitForConfigurationAvailability(WORD cmmSection) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_CMM_LOAD_CONFIG_FAILED;
	CTV6Timer CMMConversionTimer(TIMER_HIGH_RES);
	TV_BOOL CMMConversionTimedOut = FALSE;
	CMMERROR conversionRetValue = CMM_CONFIGURATION_UNAVAILABLE;
	const USHORT CONFIG_CMM_CONVERSION = 600;  ///< CMM conversion Process timeout Value
	// Start the timer
	CMMConversionTimer.StartTimer();
	// Loop until the CMM Conversion has been completed, or the timeout reached
	while ((CMM_CONFIGURATION_UNAVAILABLE == conversionRetValue) && ( FALSE == CMMConversionTimedOut)) {
		conversionRetValue = IsConfigurationAvailable(m_ConfigurationId, cmmSection);
		// if( USEC_TO_SEC( CMMConversionTimer.ElapsedTimeInMicroSeconds() ) > CONFIG_CMM_CONVERSION_TIMEOUT_IN_SEC )
		if ( USEC_TO_SEC( CMMConversionTimer.ElapsedTimeInMicroSeconds() ) > CONFIG_CMM_CONVERSION)
		{
			CMMConversionTimedOut = TRUE;
		}
		sleep(CONFIG_WAIT);		// Allow other threads to be rescheduled
	}
	CMMConversionTimer.StopTimer();
	if (CMM_CONFIGURATION_CORRUPT == conversionRetValue || TRUE == CMMConversionTimedOut) {
		retValue = CONFIG_CMM_LOAD_CONFIG_FAILED;
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CMM: Configuration conversion failed");
	} else {
		retValue = CONFIG_OK;
	}
	return (retValue);
}
//***************************************************************************************
/// Create a configuration in the CMM
///
/// @return T_CONFIG_RETURN_VALUE result
//*************************************************************************************** 
T_CONFIG_RETURN_VALUE CConfiguration::CreateCMMConfiguration(void) {
	// Member Function Return Value
	T_CONFIG_RETURN_VALUE retValue = CONFIG_CMM_HOLDER_COULD_NOT_BE_CREATED;
	// Store the Current Configuration Id, before creating the new Id
	m_PreviousConfigurationId = m_ConfigurationId;
	// Create the Configuration Holder
	if (CMM_SUCCESS == CreateConfiguration(&m_ConfigurationId, pSYSTEM_INFO->GetNextSessionNumberPtr())) {
		retValue = CONFIG_OK;
		qDebug("New config ID %d previous %d\n", m_ConfigurationId, m_PreviousConfigurationId);
	} else {
		qDebug("failed creating new config ID previous = %d\n", m_PreviousConfigurationId);
	}
	return (retValue);
}
//***************************************************************************************
/// Load a Configuration File into the CMM Configuration 
///
/// @param[in] fileToLoadConfig - reference to the fiel handler of config to load
/// @param[in] configFileType - type of file to load
/// @param[in] cmmSection - CONFIG_MODIFIABLE or CONFIG_COMMITTED
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::LoadConfigFile(QFile &fileToLoadConfig, const T_CONFIG_FILE_TYPE configFileType,
		const TV_BOOL persistedLoad) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_INVALID_FILE;  // Member Function Return Value
	BYTE *pAllocatedBuffer = NULL; // CMM Allocated Buffer Pointer 
	// Ensure the Path and File Name is a valid pointer
	//if( NULL != pConfigPathAndFileName )
	{
		//CStorage configFileToBeLoaded; // File Handler to the Configuration File to be Loaded
		CONFIGHEADERINFO configFileHeader; // Configuration File Header

		// Open the Configuration File to be Loaded
        if( TRUE == fileToLoadConfig.open(QIODevice::ReadOnly) )
		{
			// Read the Configuration File Header 
            uCONFIGHEADERINFO temp;
            *temp.raw = fileToLoadConfig.read(sizeof(CONFIGHEADERINFO));
            copyCONFIGHEADERINFO(temp,configFileHeader);
			// Validate the Configuration File Header
			if (CONFIG_OK == ValidateConfigFileHeader(configFileHeader, configFileType)) {
				// Configuration File Length
				UINT configLengthInBytes = static_cast<UINT>(fileToLoadConfig.size());
				// Configuration File Buffer
				BYTE *pConfigFileBuffer = new BYTE[configLengthInBytes];
				// CMM Allocated Buffer Pointer 
				BYTE *pAllocatedBuffer = NULL;
				// Ensure we load the Configuration from the start of the File 
				fileToLoadConfig.seek(0);
				// Read the Configuration File into memory
                QByteArray  byteArray(fileToLoadConfig.read(configLengthInBytes));
                const unsigned char* unsignedCharArray = reinterpret_cast<const unsigned char*>(byteArray.constData());
                unsigned char* nonConstPointer = const_cast<unsigned char*>(unsignedCharArray);
                pConfigFileBuffer = nonConstPointer;
				// Perform CRC Validation
				if (CRC_TEST_PASSED == CrcTest(pConfigFileBuffer, configLengthInBytes)) {
					// CRC has been verified and is correct, decrement the CRC from the 
					// configuration length. The CMM requires the buffer to contain just
					// the configuration data, excluding CRC.
					retValue = PerformLoadCMMConfiguration((configLengthInBytes - CONFIG_CRC_LENGTH), pAllocatedBuffer,
							pConfigFileBuffer, persistedLoad);
				} else {
					retValue = CONFIG_CRC_INVALID;
				}
				// Delete the Previously Allocated Buffer
				delete (pConfigFileBuffer);
				pConfigFileBuffer = NULL;
			}
			// Open the Configuration File to be Loaded
			//configFileToBeLoaded.Close();
		}
		// else
		// {
		// retValue = CONFIG_FILE_DOES_NOT_EXIST;
		// } 
	}
	return (retValue);
}
//***************************************************************************************
/// Validate the Configuration File
///
/// @param[in] configurationHeader - reference to the configuration header to check
/// @param[in] configFileType - configuration type to validate against
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::ValidateConfigFileHeader(const CONFIGHEADERINFO &configurationHeader,
		const T_CONFIG_FILE_TYPE configFileType) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_INVALID_FILE;
	if (configFileType == configurationHeader.wFileType) {
		retValue = CONFIG_OK;
	}
	return (retValue);
}
//***************************************************************************************
/// Save a Configuration from the CMM
///
/// @param[in] fileToLoadConfig - reference to the file handler of config to load
/// @param[in] configurationHeader - reference to configuration holder
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::SaveConfigFile(QFile &fileToSaveConfig, CONFIGHEADERINFO &configurationHeader) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_SAVE_CONFIG_FILE_FAILED;
	DWORD configBufferSize = CONFIG_WAIT;  ///< Size of the current configuration
	BYTE *pConfigBuffer = NULL; ///< Pointer to the current configuration
	USHORT configFileCRCValue = 0;				///< Calculated CRC for Config File
	// Set Configuration Log
	if (CMM_SUCCESS == SetConfigurationLog(m_ConfigurationId, &configurationHeader)) {
		// Request Pointer to Configuration 
		if (CMM_SUCCESS == GetConfiguration(m_ConfigurationId, &configBufferSize, &pConfigBuffer)) {
			// Calculate the CRC for the entire Config File, this value
			// shall be appended to the end of the config file.  
			configFileCRCValue = CrcCalc(pConfigBuffer, configBufferSize);
			// Write the Configuration to the File
            const char* constCharArray = reinterpret_cast<const char*>(pConfigBuffer);
            fileToSaveConfig.write(constCharArray, configBufferSize);
			// --- Write the CRC to the End of the File --- //
			// Write High Byte of the CRC to the file
			BYTE highByte = (BYTE) (configFileCRCValue >> 8);
            const char* constCharArrayHighByte = reinterpret_cast<const char*>(highByte);
            fileToSaveConfig.write(constCharArrayHighByte, sizeof(BYTE));
			// Write Low Byte of the CRC to the file
			BYTE lowByte = (BYTE) (configFileCRCValue & 0xFF);
            const char* constCharArrayLowByte = reinterpret_cast<const char*>(lowByte);
            fileToSaveConfig.write(constCharArrayLowByte, sizeof(BYTE));
			// Indicate Successful Write of the Configuration to the File
			retValue = CONFIG_OK;
		}
	}
	return (retValue);
}
//***************************************************************************************
/// Load a configuration into the CMM
///
/// @param[in] configLenghtInBytesWithoutCRC - length of file not including CRC
/// @param[in] pAllocatedBuffer - pointer to a CMM buffer tha configuration will be loaded into(allocated by CMM)
/// @param[in] pConfigFileBuffer - pointer to a file buffer containing the config
/// @param[in] persistedLoad - persisted load, TRUE will directly load into commited if no conversion needed 
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::PerformLoadCMMConfiguration(const UINT configLenghtInBytesWithoutCRC,
		BYTE *pAllocatedBuffer, const BYTE *const pConfigFileBuffer, const TV_BOOL persistedLoad) {
#ifdef PWDLOGS_ENABLE		
	WCHAR szDbgMsg[512];
#endif
	T_CONFIG_RETURN_VALUE retValue = CONFIG_CMM_MEMORY_ALLOCATION_FAILED;
	// Allocate memory within the CMM for the configuration
	if (CMM_SUCCESS == AllocateBuffer(m_ConfigurationId, configLenghtInBytesWithoutCRC, &pAllocatedBuffer)) {
#ifdef PWDLOGS_ENABLE		
		swprintf( szDbgMsg, L"CConfiguration::PerformLoadCMMConfiguration: Allocate memory within the CMM for the configuration GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		// Copy the configuration Data to the CMM allocation buffer  
		memcpy(pAllocatedBuffer, pConfigFileBuffer, configLenghtInBytesWithoutCRC);
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CConfiguration::PerformLoadCMMConfiguration: Copy the configuration Data to the CMM allocation buffer GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		// Load the Configuration
		// JLP - noticed that persistedLoad was always FALSE - did not get passed all the way down here.
		// Now it does - but maybe we do want it to always be FALSE - for firmware upgrades etc.
		//
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CConfiguration::PerformLoadCMMConfiguration - m_ConfigurationId: %ld m_ConfigVersion: %lu GTC %d\n",m_ConfigurationId,m_ConfigVersion, GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		if (CMM_SUCCESS == LoadConfiguration(m_ConfigurationId, FALSE, &m_ConfigVersion))
// if( CMM_SUCCESS == LoadConfiguration( m_ConfigurationId, persistedLoad, &m_ConfigVersion ) )
				{
			// CMM may need to convert the Configuration, hence wait until the 
			// conversion process has been completed. This has a potential to 
			// cause an infinite loop therefore a timeout is implemented to
			// ensure this situation does not occur.
			if (m_ConfigVersion != CF_VERSION) {
				m_ConversionPerformed = TRUE;	// Configuration is different so a conversion will be performed
			} else {
				m_ConversionPerformed = FALSE;	// No conversion will be performed
			}
			// JLP - see comment above about persistedLoad
//			if( TRUE == persistedLoad )
// {
// retValue = WaitForConfigurationAvailability( CONFIG_COMMITTED );
// }
// else
			{
				retValue = WaitForConfigurationAvailability(CONFIG_MODIFIABLE);
			}
		} else {
			retValue = CONFIG_CMM_LOAD_CONFIG_FAILED;
		}
	}
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CConfiguration::PerformLoadCMMConfiguration - retvalue :: %d GTC %d\n", retValue ,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	return (retValue);
}
//***************************************************************************************
/// Load and commit a configuration
///
/// @param[in] fileToLoadConfig - reference to file handle of configuration.
/// @param[in] configFileType - file type that is being loaded
/// @param[in] persistedLoad - persisted load, TRUE will directly load into commited if no conversion needed 
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::LoadConfigService(QFile &fileToLoadConfig,
		const T_CONFIG_FILE_TYPE configFileType, const TV_BOOL persistedLoad) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_INVALID_FILE;
	// Store the Current Configuration Id, to ensure that if any failure occur we
	// can revert back to the previous configuration. 
	DWORD previousConfigurationId = GetConfigId();
	ClearDepersistChangesMade();		// Indicate no depersist changes have been made
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	int iPathLen = 256;
	BOOLEAN isFileCreated = FALSE;
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"LoadConfigService.txt", (256 - wcslen( InitLogFileName )) );
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Initialisation started-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Create a CMM Configuration Holder
	retValue = CreateCMMConfiguration();
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"LoadConfigFile( fileToLoadConfig, configFileType, persistedLoad )\n");
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	if (CONFIG_OK == retValue) {
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"LoadConfigFile( fileToLoadConfig, configFileType, persistedLoad )\n");
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		// Load the Configuration File into the Configuration Previously Created
		retValue = LoadConfigFile(fileToLoadConfig, configFileType, persistedLoad);
		if (CONFIG_OK == retValue) {
#ifdef STARTUP_LOGGING
			wcscpy(InitLogString,L"ValidateConfiguration()\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
			T_CONFIG_VALIDATE_RETURN validateResult = ValidateConfiguration();
			if (CONFIG_VALIDATE_INVALID == validateResult) {
				// only gets generated for layout
				retValue = CONFIG_INCORRECT_FILE_TYPE;
				qDebug("CConfiguration::LoadConfigService - Incorrect/invalid layout type\n");

                QString strErrorMessage = QWidget::tr("Layout not valid or incorrect recorder type");
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strErrorMessage);
			} else if (CONFIG_VALIDATE_CHANGES_MADE == validateResult) {
				retValue = CONFIG_OK_VALIDATE_UPDATED_CMM;
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"SetDepersistChangesMade()\n");
				if( kLogFile.Open(	InitLogFileName, 
									CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
									&kFileEx ) )
				{
					kLogFile.SeekToEnd();
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				SetDepersistChangesMade();
			} else {
				retValue = CONFIG_OK;
			}
			if (retValue != CONFIG_INCORRECT_FILE_TYPE) {
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"UpdateConfig()\n");
				if( kLogFile.Open(	InitLogFileName, 
									CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
									&kFileEx ) )
				{
					kLogFile.SeekToEnd();
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				// Commit the Configuration
				if (CONFIG_OK != UpdateConfig()) {
					retValue = CONFIG_CMM_COMMIT_CONFIG_ERROR;
				}
			}
		} else {
			QString strError("");
            strError = QString::asprintf("Unable to load %s", fileToLoadConfig.fileName().toUtf8().constData());
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strError);
		}
	} else {
		qDebug("CConfiguration::LoadConfigService - Failed to create CMM holder\n");
	}
	// Remove previous configuration now the new has be loaded
	if (CONFIG_OK == retValue || CONFIG_OK_VALIDATE_UPDATED_CMM == retValue) {
		// Don't remove the configuration if it's a setup config (unless it's not a recorder i.e. ttr6setup), as the LCM needs 
		// to compare both before in order to successfully update itself.
		if (configFileType != CONFIG_SETUP_FILE_TYPE || pDALGLB->IsRecorderPCorEmbedded() != TRUE) {
#ifdef STARTUP_LOGGING
			wcscpy(InitLogString,L"CleanUpConfiguration(TRUE)\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
			CleanUpConfiguration(TRUE);
		}
	} else {
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"CleanUpConfiguration(FALSE)\n");
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		CleanUpConfiguration(FALSE);
	}
	return (retValue);
}
//***************************************************************************************
/// Clean up a configuration, delete the previous configuration from the CMM after
/// loading a new one (CMM load new configs under a different ID)
///
/// @param[in] operationSuccessful - TRUE = delete the previous configuration as the new load was successful
///									 FALSE = new config was not successful so delete that and revert back to previous.
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::CleanUpConfiguration(const BOOL operationSuccessful) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	// Was the new load successful?
	if ( TRUE == operationSuccessful) {
		// Yes, delete the previous configuration
		if (CONFIG_INVALID_CONFIGURATION_ID != m_PreviousConfigurationId) {
			qDebug("Deleting previous %d\n", m_PreviousConfigurationId);
			DeleteConfiguration(m_PreviousConfigurationId);
		}
	} else {
		qDebug("Deleting current %d reverting to previous %d\n", GetConfigId(), m_PreviousConfigurationId);
		// No preserve the previous config and get rid of the new(failed) config
		if (CONFIG_INVALID_CONFIGURATION_ID != m_PreviousConfigurationId) {
			// Delete the Configuration
			DeleteConfiguration(GetConfigId());
		}
		// Set the Configuration back to the Previous Id
		SetConfigurationId(m_PreviousConfigurationId);
	}
	return (retValue);
}
//***************************************************************************************
/// Save a configuration using the filename
///
/// @param[in] pConfigPathAndFileName, path and filename to save configuration as
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::SaveConfigUsingFileName(const QString pConfigPathAndFileName,
		TV_BOOL persistedSave) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_INVALID_FILE;
	CStorage fileToSaveConfig;
    if ( TRUE == fileToSaveConfig.Open(pConfigPathAndFileName, QFile::WriteOnly)) {
		retValue = SaveConfig(fileToSaveConfig, persistedSave);
		fileToSaveConfig.Close();
	}
	return (retValue);
}
//***************************************************************************************
/// Load a configuration using the filename
///
/// @param[in] pConfigPathAndFileName, path and filename to save configuration as
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::LoadConfigUsingFileName(const QString pConfigPathAndFileName,
		TV_BOOL persistedLoad) {
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	int iPathLen = 256;
	BOOLEAN isFileCreated = FALSE;
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"LoadConfigUsingFileName.txt", (256 - wcslen( InitLogFileName )) );
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Initialisation started-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	T_CONFIG_RETURN_VALUE retValue = CONFIG_FILE_DOES_NOT_EXIST;
	CStorage configFileToBeLoaded;
	QString csTxt;
    csTxt = QWidget::tr("Opening Config File");
	pGlbSysInfo->SetStartupSubAction(csTxt);
    QFileDevice::FileError kEx;
	if ( TRUE == configFileToBeLoaded.Open(pConfigPathAndFileName, QFile::ReadOnly, &kEx)) {
        csTxt = QWidget::tr("Config File Loading");
		pGlbSysInfo->SetStartupSubAction(csTxt);
#ifdef STARTUP_LOGGING
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			wcscpy(InitLogString,L"LoadConfig()\n");
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		retValue = LoadConfig(configFileToBeLoaded, persistedLoad);
#ifdef STARTUP_LOGGING  
		wcscpy(InitLogString,L"configFileToBeLoaded.Close()\n");
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		configFileToBeLoaded.Close();
	} else {
        if (kEx != QFileDevice::FileError::OpenError) {
            WCHAR wcaError[100] = L"An error occurred when opening the file/device";
            //kEx.GetErrorMessage(wcaError, 100);
			QString strError("");
			strError = QString::asprintf("CConfiguration::LoadConfigUsingFileName( ) Filename: %s - %s",
                    pConfigPathAndFileName.toStdString().c_str(), wcaError);
            //QMessageBox::warning(NULL, strError, L"CStorage Error", (MB_OK)); //  | MB_TOPMOST));
            QMessageBox::critical(nullptr, "Error","CStorage Error");
		}
	}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"--------END-------\n");
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return (retValue);
}
//***************************************************************************************
/// Discard any changes made to the Configuration, this will rebuild working(MODIFIABLE) from current (COMMITED)
///
/// @return T_CONFIG_RETURN_VALUE result
//***************************************************************************************
T_CONFIG_RETURN_VALUE CConfiguration::DiscardConfigurationChanges(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	// Make a call to the CMM to discard any changes made to the CMM for the configuration
	if (CMM_SUCCESS == DiscardChanges(m_ConfigurationId)) {
		retValue = WaitForConfigurationAvailability(CONFIG_MODIFIABLE);
	}
	return (retValue);
}

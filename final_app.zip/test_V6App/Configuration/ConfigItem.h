/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigItem.h
/// @n Description: Definition for the CConfigItem class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:56:16 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:28:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 8/11/2005 8:19:49 PM  Roger Dawson  
//  Preliminary implementation of the screen designer object channel map 
//  changes.
//  3 V6 Firmware 1.2 5/31/2005 7:16:50 PM  Roger Dawson  
//  Screen designer configuration changes.
// $
//
// **************************************************************************
#pragma once
#include "ConfigInterface.h"
#include <QString>
// Forward Class declarations
class CConfigData;
//**CConfigItem*********************************************************************
///
/// @brief This is an inherited class that forms a leaf in a configuration hierarchy.
/// 
/// This is an inherited class that forms a leaf in a configuration hierarchy. It has
/// no children stemming from it. This class must always be the child of a branch (see
/// CConfigBranch class). This class will be used by GUI's to create a menu interface item
/// ( e.g. a button ) or to populate an editor that allows the items associated data to
/// be modfied. Also refer to the CConfigInterface and CConfigBranch classes for a
/// broader view of how these classes are designed to operate. This class is designed
/// to allow a user ot modify its associated data without actually knowing what the data
/// realtes (e.g. pen or password configuration information).
///
//****************************************************************************
class CConfigItem: public CConfigInterface {
public:
	// Constructor
	CConfigItem(const QString &rstrKEY, const QString &rstrTITLE, const QString &rstrSUB_TITLE,
			const ControlType eCONTROL_TYPE, CConfigData *const pkCONFIG_DATA, const bool bMODIFIED,
			const bool bENABLED, const long lHELP_ID, const bool bLOCKED, CConfigInterface *const pkPARENT);
	~CConfigItem(void);
	// Accessor Method for the data
	CConfigData* GetData() const {
		return m_pkConfigData;
	}
private:
	/// Pointer to the class that contains information on the actual data this config item relates to
	CConfigData *m_pkConfigData;
};

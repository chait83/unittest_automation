/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Configuration System
/// @n Filename:	ConfigSystemData.h
/// @n Description: Definition for the Configuration system globals and typedef's
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 33	Stability Project 1.30.1.1	7/2/2011 4:56:17 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 32	Stability Project 1.30.1.0	7/1/2011 4:28:12 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 31	V6 Firmware 1.30		9/23/2008 3:09:23 PM	Build Machine 
//		AMS2750 Merge
// 30	V6 Firmware 1.29		4/19/2007 3:53:28 PM	Roger Dawson 
//		Modified the SIP so it now allows 10 characters when enterring a
//		ULONG and 11 characters when entering a LONG. Also reduced the max
//		range for the batch counter configuration items so ULONG_MAX - 1 so
//		the validation continues to work correctly as larger entering larger
//		numbers appears to set the result to ULONG_MAX.
// $
//
// **************************************************************************
#ifndef _CONFIG_SYSTEM_DATA_H
#define _CONFIG_SYSTEM_DATA_H
#include "Defines.h"
/// Required control type e.g. button, list control etc
typedef enum {
	ctMainMenuButton, ctSubMenuButton, ctItemButton
} ControlType;
/// Enum of possible data types
typedef enum {
	dtBool,			// Used
	dtShortBitField,			// Used
	dtLongBitField,	// Used
	dtShort,		// Used
	dtUnsignedShort,		// Used
	dtBrightness,	// Used
	dt16Colour,		// Used
	dtLong,			// Used
	dtUnsignedLong,	// Used
	dtFWPens,		// Used
	dtColour,		// Used
	dtFloat,		// Used
	dtByte,			// Used
	dtTemperature,	// Used
	dtTempRelative,	// Used
	dtString,		// Used
	dtPassword,		// Used
	dtUserName,		// Used
	dtEmailAddr,	// Used
	dtIPAddr,		// Used
	dtFWOptBitField,		// Used
	dtOptionsCode,	// Used
	dtDateTime,		// Used
	dtDate,			// Used
	dtTimeOfDay,	// Used
	dtInterval,		// Used
	dtCopy,
	dtAdd,
	dtDelete,
	dtCauses,
	dtEffects,
	dtMuLEPenScript,	// Used
	dtMuLEEmailTemplate,		// Used
	dtSiLEScript,		// Used
	dtLinearisationTable,	//Used
	dtAMS2750SensorCal,	// Used
	dtMultiPointCal,	// Used
	dtAMS2750Cal,	// Used
	dtSharePath,	// Used
	// PICKERS - keet
	dtSinglePen,		// This is checked as the start picker
	dtSinglePenIncNoneSel,	// Used
	dtSinglePenAlarm,	// Used
	dtSinglePenLatchedAlarm,	// Used
	dtSingleAlarm,		// Used
	dtSingleAnalogueRTIn,	// Used
	dtSingleAnalogueTCIn,	// Used
	dtSingleAnalogueIn,	// Used
	dtMultiAnalogueRTIn,	// Used
	dtMultiAnalogueTCIn,	// Used
	dtMultiAnalogueTUSTCIn,	// Used
	dtMultiAnalogueIn,	// Used
	dtSingleDigIn,		// Used
	dtSingleRelayOut,	// Used
	dtSingleLoPulseIn,	// Used
	dtSingleHiPulseIn,	// Used
	dtMultiPulseIn,		// Used
	dtMultiDigIn,		// Used
	dtMultiRelayOut,	// Used
	dtMultiPen,			// Used
	dtMultiPenTotaliser,			// Used
	dtMultiPenLogging,	// Used
	dtEmailRecipients,	// Used
	dtDaysOfTheWeek,	// Used
	dtScreens,			// Used
	dtSingleEvent,		// Used
	dtMultiEvent,		// Used
	dtSingleUserCounters,		// Used
	dtMultiUserCounters,		// Used
	dtAllCounterTypes,	// Used
	dtMessageListTypes, // Used
	dtSingleTimer,		// Used
	dtMultipleTimers,	// Used
	dtMultiLatchedAlarm,	// Used
	dtMultiAlarm,	// This is checked as the end picker - do not put any picker type data items past this point
	dtObject,			// Used
	dtCannedScreenSetup,			// Used
	dtAddScreen,		// Used
	dtDeleteScreen,		// Used
	dtReplayPenSeletionScrn, // Used	// E527303
	dtMultipleUserVars,
	dtNone				// Used
} T_CFG_DATA_TYPE;
/// Enum used to identify a CConfigBranch or CConfigItem class
typedef enum {
	citConfigBranch, citConfigItem
} T_CFG_INTERFACE_TYPE_ENUM;
/// Structure used to store string based picker data e.g. the picker uses names for selections, not numbers
typedef struct {
	ULONG ulScreenBitset;
	QString strScreenList;
} T_STRING_PICKER_DATA;
/// Enum indicating the analogue input type
typedef enum {
	aptRT, aptTC, aptTUSSensor, aptAMS2750TUSCopySensor, aptAMS2750ProcessCopySensor, aptALL
} T_AIN_PICKER_TYPES;
// The maximum string lengths when entering numbers of the indicated types - used to 
// restrict how many characters the user can enter when editing configuration data
const USHORT g_usMAX_SHORT_STR_LEN = 5;
const USHORT g_usMAX_LONG_STR_LEN = 10;
const USHORT g_usMAX_USHORT_STR_LEN = 6;
const USHORT g_usMAX_ULONG_STR_LEN = 11;
const USHORT g_usMAX_FLOAT_STR_LEN = 15;
const USHORT g_usMAX_SOUNDS = 20;
const USHORT g_usMAX_COUNTER_TYPES = 6;
const USHORT g_usMAX_SELECTABLE_MSG_LIST_TYPES = 5;
#endif // _CONFIG_SYSTEM_DATA_H

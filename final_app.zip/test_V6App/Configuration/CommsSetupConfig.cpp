/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration
/// @n Filename: CommsSetupConfig.cpp
/// @n Desc:	 Class to manage the configuration of the communications
///				 block
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  03-Sep-15 Rajanbabu M  Updated Registry Entry "AutoUpdate" for SNTP
//  60  Stability Project 1.54.1.4 7/2/2011 4:56:13 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  59  Stability Project 1.54.1.3 7/1/2011 4:38:06 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  58  Stability Project 1.54.1.2 3/17/2011 3:20:16 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  57  Stability Project 1.54.1.1 2/15/2011 3:02:37 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "../inc/V6defines.h"
#include "../inc/V6globals.h"
#include "V6Config.h"
#include "../inc/V6Configuration.h"
#include "CommsSetupConfig.h"
#include "../Utilities/StringUtils.h"
#include "../inc/V6ResourceBase.h"
#include "../inc/V6UIResource.h"
#include <stdio.h>
#include <QtWidgets/qwidget.h>
#include "../Utilities/Crypto.h"
#include <netinet/in.h>
#include <arpa/inet.h>
#include <QTcpSocket>
#include <QHostAddress>
#include <QDebug>
#include <QCoreApplication>
#include <iostream>
#include <cstring>
#include <netdb.h>
#ifdef UNDER_CE
//#include <cred.h>
//
// Stability Project Fix:
//
// statement commented to fix issue related to 'struct' type redefinition.
//
//#undef _WINNETWK_ 
#endif
#include "../inc/Registry.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#define ERROR_ALREADY_ASSIGNED  85L
const DWORD dwERROR = ERROR_SUCCESS;
T_REG_TABLE_ENTRY CommsTable[] = { { "Comm\\FEC1\\Parms\\TcpIp", "EnableDHCP", VALUE_DWORD, ITEM_DHCP_ENABLE, TRUE }, {
		"Comm\\FEC1\\Parms\\TcpIp", "AutoCfg", VALUE_DWORD, ITEM_AUTO_CONFIG, TRUE }, { "Comm\\FEC1\\Parms\\TcpIp",
		"IPAddress", VALUE_STRING, ITEM_IP_ADDRESS, TRUE }, { "Comm\\FEC1\\Parms\\TcpIp", "SubnetMask", VALUE_STRING,
		ITEM_SUBNET_MASK, FALSE }, { "Comm\\FEC1\\Parms\\TcpIp", "DefaultGateway", VALUE_STRING, ITEM_DEFAULT_GATEWAY,
		FALSE }, { "Comm\\FEC1\\Parms\\TcpIp", "DNS", VALUE_STRING, ITEM_PRIMARY_DNS, FALSE },
//{ "Comm\\FEC1\\Parms\\TcpIp", "DNS", VALUE_STRING, ITEM_SECONDARY_DNS,	FALSE }, ///@todo secondary DNS server address
		{ "Comm\\FEC1\\Parms\\TcpIp", "WINS", VALUE_STRING, ITEM_PRIMARY_WINS, FALSE },
		//{ "Comm\\FEC1\\Parms\\TcpIp", "WINS",VALUE_STRING, ITEM_PRIMARY_WINS,	FALSE }, ///@todo secondary WINS server address
		{ "Comm\\AFD", "NameResolutionOrder", VALUE_DWORD, ITEM_DNS_ORDER, FALSE }, { "Comm\\AFD", "EnableMDNS",
				VALUE_DWORD, ITEM_DNS_ORDER, FALSE }, { "Comm\\HTTPD", "Port", VALUE_DWORD, ITEM_HTTP_PORT_1, TRUE }, {
				"Services\\HTTPD\\Accept\\TCP-80", "SockAddr", VALUE_BINARY, ITEM_HTTP_PORT_2, TRUE }, { "Comm\\HTTPD",
				"IsEnabled", VALUE_DWORD, ITEM_HTTP_ENABLE, TRUE }, { "Comm\\FTPD", "Port", VALUE_DWORD, ITEM_FTP_PORT,
				TRUE }, { "Comm\\FTPD", "IsEnabled", VALUE_DWORD, ITEM_FTP_ENABLE, TRUE, },
		//{ "Services\\TIMESVC",		"ClientOnly",VALUE_DWORD, ITEM_SNTP_CLIENT,		FALSE },
		{ "Services\\TIMESVC", "ServerRole", VALUE_DWORD, ITEM_SNTP_SERVER, TRUE }, { "Services\\TIMESVC", "Keep",
				VALUE_DWORD, ITEM_SNTP_KEEP, TRUE }, { "Services\\TIMESVC", "Server", VALUE_STRING, ITEM_SNTP_CLIENT,
				TRUE }, { "Services\\TIMESVC", "Refresh", VALUE_DWORD, ITEM_SNTP_REFRESH, TRUE }, { "Services\\TIMESVC",
				"RecoveryRefresh", VALUE_DWORD, ITEM_SNTP_RECOVERY, FALSE }, { "Services\\TIMESVC", "Threshold",
				VALUE_DWORD, ITEM_SNTP_THRESHOLD, TRUE }, { "Services\\TIMESVC", "trustlocalclock", VALUE_DWORD,
				ITEM_SNTP_TRUST_LOCAL_CLK, FALSE },
		//PSR - SNTP fix begin
#ifdef UNDER_CE
                                   { "Services\\TIMESVC",		"Flags",	VALUE_DWORD, ITEM_SNTP_FLAGS,		FALSE },
                                   { "Services\\TIMESVC", "AutoUpdate", VALUE_DWORD, ITEM_SNTP_AUTOUPDATE, TRUE },
                                   #endif
		//PSR - SNTP fix end
		{ NULL, NULL, VALUE_DWORD, NUM_REG_ITEMS, FALSE }	// End of table
};
CCommsSetupConfig::CCommsSetupConfig(void) {
}
CCommsSetupConfig::~CCommsSetupConfig(void) {
}
//*************************************************************************************
/// Enable DCOM calls 
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
/// @note This leaves CE wide open!
/// @todo Sort DCOM security!
///
///[HKEY_LOCAL_MACHINE\SOFTWARE\MICROSOFT\OLE]
/// "EnableDCOM"="Y"
/// "LegacyAuthenticationLevel"=dword:1
/// "LegacyImpersonationLevel"=dword:1
/// "DefaultAccessPermission"=hex:03,00,00,00,1d,03,00,00,00,00,00,00,c0,00,00,00,00,00,00,46,2a,00,00,00
/// "DefaultLaunchPermission"=hex:03,00,00,00,1d,03,00,00,00,00,00,00,c0,00,00,00,00,00,00,46,2a,00,00,00 
/////////////////////////////////////////////////////
//*************************************************************************************
T_CONFIG_RETURN_VALUE CCommsSetupConfig::EnableDCOM(BOOL Enable) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CRegistryKey RegKey;
    RegKey.OpenKey("SOFTWARE\\MICROSOFT\\OLE");
	if (Enable) {
		BYTE DefaultAccess[24] = { 0x03, 0x00, 0x00, 0x00, 0x1d, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xc0, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x46, 0x2a, 0x00, 0x00, 0x00 };
		BYTE DefaultPermission[24] = { 0x03, 0x00, 0x00, 0x00, 0x1d, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xc0,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46, 0x2a, 0x00, 0x00, 0x00 };
		/// @todo :- Setting this to 'Y' causes EVC debug to drop after 10 minutes?
#ifdef DEBUG
		RegKey.WriteValue( L"EnableDCOM", L"N" );
#else
        RegKey.WriteValue("EnableDCOM", "Y");
#endif
        RegKey.WriteValue("LegacyAuthenticationLevel", (DWORD) 1);
        RegKey.WriteValue("LegacyImpersonationLevel", (DWORD) 1);
        RegKey.WriteValue("DefaultAccessPermission", DefaultAccess, (DWORD) 24);
        RegKey.WriteValue("DefaultLaunchPermission", DefaultPermission, (DWORD) 24);
	} else {
        RegKey.WriteValue("EnableDCOM", "N");
	}
	RegKey.Flush();
	RegKey.Close();
	return retValue;
}
//*************************************************************************************
/// 
///
//*************************************************************************************
T_CONFIG_RETURN_VALUE CCommsSetupConfig::CreateServiceDefaultConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CRegistryKey RegKey;
	// Create a default comms block
	if (CreateDefaultCommsBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	// Create free format e-mail blocks
	int ffEmailIndex = 0;
	for (ffEmailIndex = 0; ffEmailIndex < EMAIL_TEMPLATES_SIZE; ffEmailIndex++) {
		CreateEmailIfNotAvailable(ffEmailIndex);
	}
	// Initialise OS Registry values
//	RegKey.Update( CommsTable );
	return (retValue);
}
//*************************************************************************************
/// Validate the configuration items when a config has been loaded and is about to be commited
///
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
T_CONFIG_VALIDATE_RETURN CCommsSetupConfig::ValidateServiceConfig(void) {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	T_PCOMMUNICATIONS pCommunications = NULL;
	pCommunications = GetCommsBlock(CONFIG_MODIFIABLE);
	if (pCommunications == NULL) {
		// There is no communications block in the current setup, so create one. 
		if (CreateDefaultCommsBlock() == NULL) {
			// Throw an error
		}
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	} else {
		// Comms block exists, but there could be incompatabilities
		if (!pDALGLB->IsRecorderEzTrend()) //Prasad Fix for 1-3EPDROF QXe_Unnecessary message "Trendbus RS485 not available, selected Ethernet" better to remove from LIst
		{
			if ((pCommunications->TrendbusSlave.Port == PORT_SERIAL) && (pDALGLB->GetRS485fitted() == FALSE)) {
				QString strErrorMsg = "";
				// Serial port selected for Trendbus, but none available
				pCommunications->TrendbusSlave.Port = PORT_ETHER;
				strErrorMsg = QWidget::tr("Trendbus RS485 not available, selected ethernet");
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg);
				retValue = CONFIG_VALIDATE_CHANGES_MADE; // Changes have been made
			}
		}
		if ((pCommunications->ModbusSlave.Port == PORT_SERIAL) && (pDALGLB->GetRS485fitted() == FALSE)) {
			QString strErrorMsg = "";
			// Serial port selected for Modbus, but none available
			pCommunications->ModbusSlave.Port = PORT_ETHER;
			strErrorMsg = QWidget::tr("Modbus RS485 not available, selected ethernet");
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg);
			retValue = CONFIG_VALIDATE_CHANGES_MADE;
		}
	}
	// Create free format e-mail blocks if they do not exist
	int ffEmailIndex = 0;
	for (ffEmailIndex = 0; ffEmailIndex < EMAIL_TEMPLATES_SIZE; ffEmailIndex++) {
		if (CreateEmailIfNotAvailable(ffEmailIndex) == CONFIG_BLOCK_ADDED) {
			retValue = CONFIG_VALIDATE_CHANGES_MADE;
		}
	}
	return (retValue);
}
//****************************************************************************
// const bool SetupLoginInfo( )
///
/// Method that stores the login information in order to provide automatic connection
/// to network resources
///
/// @return True if the login information was stored correctly
///
//****************************************************************************
const bool CCommsSetupConfig::SetupLoginInfo() {
	bool bRetVal = FALSE;
	QString strNotSet("");
	strNotSet = QWidget::tr("Not set");
	T_PCOMMUNICATIONS pCommunications = NULL;
	pCommunications = GetCommsBlock(CONFIG_MODIFIABLE);
	T_LANINFO *ptLanInfo = &pCommunications->LanInfo;
	// check if a username and password have been specified
    QString strUsername;;
    strUsername = QString::fromWCharArray(ptLanInfo->user);
	//if( ( strUsername != QString   ::fromWCharArray("") ) && ( strUsername != L"0" ) && ( strUsername != strNotSet ) /*&&
	//	( strPassword != QString   ::fromWCharArray("") ) && ( strPassword != L"0" ) && ( strPassword!= strNotSet ) */)
	{
		// decrypt the password
		CCrypto kCrypto;
        QString strDecryptedPwd(kCrypto.Decrypt(QString::fromWCharArray(ptLanInfo->password), LANINFO_PASSWORD_LEN));
		// log into the network share again just in case the 
		// username/password/domain have been changed
#ifdef UNDER_CE
		// check if there is a domain specified
        if( ptLanInfo->domain[0] == L'\0')
		{
            QString   strDomainName = ""; //( QString   ::fromWCharArray("") );
            strDomainName = QString::fromWCharArray(ptLanInfo->domain);
			strUsername = strDomainName + strUsername;
		}
		CRED tCredentials;
        WCHAR defTarget[]  = L"";
		DWORD defTargetLen  = sizeof(defTarget)/sizeof(defTarget[0]);
	  
		// Set up the credential
        tCredentials.dwVersion = L"CRED_VER_1";
        tCredentials.dwType = L"CRED_TYPE_DOMAIN_PASSWORD";
		tCredentials.wszTarget = defTarget;
        tCredentials.dwTargetLen= 0; //defTargetLen;
        tCredentials.dwFlags	= L"CRED_FLAG_DEFAULT|CRED_FLAG_PERSIST";
        tCredentials.wszUser  = const_cast<WCHAR*>(strUsername.toStdWString().c_str());
		tCredentials.dwUserLen = strUsername.size() + 1;
        tCredentials.pBlob = const_cast<WCHAR*>(strDecryptedPwd.toStdWString().c_str());
		tCredentials.dwBlobSize	= ( strDecryptedPwd.size() + 1 ) * sizeof( WCHAR );
		// Write the credential
        //const DWORD dwERROR = CredWrite( &tCredentials,0); ///TODO define CredWrite
#else
		const DWORD dwERROR = ERROR_SUCCESS;
#endif
		// check if successful
		if ((ERROR_SUCCESS != dwERROR) && (dwERROR != ERROR_ALREADY_ASSIGNED)) {
			QString strError("");
            strError = QString::asprintf("Unable to store network credentials, error %u. Please update network admin settings", dwERROR);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
	}
	return bRetVal;
}
//**********************************************************************
///
/// Function that is called immediately after a setup config is commited
/// to the CMM.
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
T_CONFIG_RETURN_VALUE CCommsSetupConfig::PostCommitProcessing(void) {
	//TM - this code is unused by the TTR6SETUP DLL and so has been compiled out
#ifndef TTR6SETUP	
#ifndef V6IOTEST
	T_PCOMMUNICATIONS pCommunications = NULL;
	pCommunications = GetCommsBlock(CONFIG_MODIFIABLE);
	HANDLE hPort = NULL;
	// Open RS485 port
	hPort = CreateFile((TEXT("COM1:")), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	pGlbDal->RS458SetTurnaround(pCommunications->SerialPort.LineTurnAround, &hPort);
	//No need to close the mutex in Qt
	/*
	 #ifdef UNDER_CE
	 // Ensure the host name has been set for static IP addresses
	 if ( TRUE == pCommunications->Ethernet.UseStaticIP )
	 {
	 char szValue[256]; 
	 sprintf( szValue, "XS-%06.6d", pGlbSysInfo->GetSerialNumber() );
	 if ( 0 != sethostname( szValue, strlen( szValue )+1 ) )
	 {
	 int iLastError = 0;
	 iLastError = WSAGetLastError( );
	 qDebug(" SetHostName returned error %d.\n", iLastError );
	 }
	 }
	 #endif // UNDER_CE
	 */
	CRegistryKey RegKey;
	/****************************************************************************************/
	SHORT TLS_Version = pCommunications->SecurityOptions.TLSProtocol;
	switch (TLS_Version) {
	case 0:			//TLS_1.0
	{
		UpdateTLSProtocolSettings(TLS_V_1_0, true);
		UpdateTLSProtocolSettings(TLS_V_1_1, true);
		UpdateTLSProtocolSettings(TLS_V_1_2, true);
	}
		break;
	case 1:			//TLS_1.1
	{
		UpdateTLSProtocolSettings(TLS_V_1_0, false);
		UpdateTLSProtocolSettings(TLS_V_1_1, true);
		UpdateTLSProtocolSettings(TLS_V_1_2, true);
	}
		break;
	case 2:			//TLS_1.2
	{
		UpdateTLSProtocolSettings(TLS_V_1_0, false);
		UpdateTLSProtocolSettings(TLS_V_1_1, false);
		UpdateTLSProtocolSettings(TLS_V_1_2, true);
	}
		break;
	default: {
		break;
	}
	}
	/****************************************************************************************/
	// Check if any 'Reboot Required' registry values have changed
	if (TRUE == RegKey.Update(CommsTable)) {
        pSETUP->RequestUnitResetAfterConfigChange("RESET REQUIRED: Comms Registry info updated");
	} else {
		// no reboot required - setup the shares again in case something has changed
		T_LANINFO *ptLanInfo = &pCommunications->LanInfo;
		CRegistryKey kRegKey;
		bool bKeyOpen = false;
        if (!kRegKey.OpenKey("Ident")) {
            if (kRegKey.CreateKey("Ident")) {
				bKeyOpen = true;
			} else {
				bKeyOpen = false;
			}
		} else {
			bKeyOpen = true;
		}
		if (bKeyOpen) {
            kRegKey.WriteValue("ComputerDomain", QString::fromStdWString(ptLanInfo->domain));
			kRegKey.Flush();
			kRegKey.Close();
		}
		// store the login credentials
		SetupLoginInfo();
	}
#endif
#endif
	return CONFIG_OK;
}
//******************************************************
// GetCommsBlock()
///
/// Get the current communications configuration from the CMM.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the communications block; otherwise NULL
/// 
//******************************************************
T_PCOMMUNICATIONS CCommsSetupConfig::GetCommsBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PCOMMUNICATIONS>(CConfiguration::GetBlock(BLK_COMMUNICATIONS, 0, m_ConfigurationId,
			cfgType));
}
//*****************************************************************************************
///
/// Create a default communications block
///
/// @return Pointer to the communications block; otherwise NULL if failed to create
/// 
//*****************************************************************************************
T_PCOMMUNICATIONS CCommsSetupConfig::CreateDefaultCommsBlock() {
	T_PCOMMUNICATIONS pCommunications = NULL;
	pCommunications = reinterpret_cast<T_PCOMMUNICATIONS>(CConfiguration::CreateNewBlock(BLK_COMMUNICATIONS, 0,
			m_ConfigurationId));
	if (pCommunications != NULL) {
		//Initialise OPC UA Block
		T_POPCUA opcua = &pCommunications->OPCUA;
		opcua->Enabled = FALSE;
		// Initialise default RS485 block
		T_PRS485PORT rs485port = &pCommunications->SerialPort;
		rs485port->BaudRate = BD_38400;
		rs485port->ByteOptions = N_8_1;
		// Initialise default Ethernet block
		T_PNETWORK network = &pCommunications->Ethernet;
		// Default IP address
		network->IPAddress.L = inet_addr("127.0.0.1");
		// Default sub-net mask
		network->SubNetMask.L = inet_addr("255.255.255.0");
		// Default default gateway
		network->DefaultGateway.L = inet_addr("0.0.0.0");
		// Default DNS server address
		network->DNSServer[0].L = inet_addr("0.0.0.0");
		network->DNSServer[1].L = inet_addr("0.0.0.0");
		// Default WINS server address
		network->WINSServer[0].L = inet_addr("0.0.0.0");
		network->WINSServer[1].L = inet_addr("0.0.0.0");
		// Default network options
		network->UseStaticIP = FALSE;
		network->EnableDNS = TRUE;
		network->EnableMDNS = TRUE;
		network->EnableWINS = TRUE;
		// Dynamic IP address search order
		network->DNSOrder = D_M_W;		// (CE Default)
		// Default sockets
//		network->HTTPSocket = 80;
		network->FTPSocket[0] = 20;
		network->FTPSocket[1] = 21;
//		network->ModbusSocket = 502;
//		network->TrendbusSocket = 5001;
		// Initialise default Modbus block
		T_PMODBUSDEVICE modbus = &pCommunications->ModbusSlave;
		modbus->Enabled = FALSE;
		modbus->Port = PORT_ETHER;
		modbus->Protocol = PR_MODBUS_X;
		modbus->Address = 1;
		// Initialise default Trendbus block
		T_PTRENDBUSDEVICE trendbus = &pCommunications->TrendbusSlave;
		trendbus->Enabled = FALSE;
		trendbus->Port = PORT_SERIAL;
		trendbus->Address = 1;
		// Initialise default NTP/SNTP block
		T_PSNTPSERVER timeservice = &pCommunications->TimeServer;
		timeservice->ServerEnable = FALSE;
		timeservice->ClientEnable = FALSE;
		memset(timeservice->ServerName, '\0', SNTPSERVER_SERVERNAME_LEN * sizeof(WCHAR));
		CStringUtils::SafeWcsCpy(timeservice->ServerName, DEFAULT_TIME_SERVER, SNTPSERVER_SERVERNAME_LEN);
		/// @todo Set a realistic threshold, this one is for testing...
		timeservice->UpdatePeriod = 3600;			// Default 1 hour update
		timeservice->UpdateThreshold = 3600;		// Default 1 Hour (time in seconds)
		// Email addresses
		QString strAddr("");
		T_EMAIL *ptEmail = &pCommunications->Email;
		QString strNotSet("");
		strNotSet = QWidget::tr("Not set");
		memset(ptEmail->Username, 0, EMAIL_USERNAME_LEN * sizeof(WCHAR));
		memset(ptEmail->Password, 0, EMAIL_PASSWORD_LEN * sizeof(WCHAR));
		memset(ptEmail->UserAddress, 0, EMAIL_USERADDRESS_LEN * sizeof(WCHAR));
#if _MSC_VER < 1400 
        wcsncpy(ptEmail->Username, strNotSet.toStdWString().c_str(), EMAIL_USERNAME_LEN);
        wcsncpy(ptEmail->Password, strNotSet.toStdWString().c_str(), EMAIL_PASSWORD_LEN);
        wcsncpy(ptEmail->UserAddress, strNotSet.toStdWString().c_str(), EMAIL_USERADDRESS_LEN);
#else
		wmemcpy_s( ptEmail->Username, sizeof(ptEmail->Username)/sizeof(WCHAR), strNotSet, strNotSet.size()<EMAIL_USERNAME_LEN?strNotSet.size():_TRUNCATE );
		wmemcpy_s( ptEmail->Password, sizeof(ptEmail->Password)/sizeof(WCHAR), strNotSet, strNotSet.size()<EMAIL_PASSWORD_LEN?strNotSet.size():_TRUNCATE );
		wmemcpy_s( ptEmail->UserAddress, sizeof(ptEmail->UserAddress)/sizeof(WCHAR),strNotSet, strNotSet.size()<EMAIL_USERADDRESS_LEN?strNotSet.size():_TRUNCATE );
		
#endif
		for (USHORT usCount = 0; usCount < EMAIL_EMAILADDRESSES_SIZE; usCount++) {
			// set the field to not set
			memset(ptEmail->EmailAddresses[usCount], 0, EMAIL_EMAILADDRESSES_LEN * sizeof(WCHAR));
#if _MSC_VER < 1400 
            wcsncpy(ptEmail->EmailAddresses[usCount], strNotSet.toStdWString().c_str(), EMAIL_EMAILADDRESSES_LEN);
#else
			wcsncpy_s( ptEmail->EmailAddresses[ usCount ],sizeof(ptEmail->EmailAddresses[ usCount ])/sizeof(WCHAR), strNotSet, _TRUNCATE );
#endif
		}
		// set the subject string to something meaningful
		QString strSubject("");
		strSubject = QWidget::tr("Subject");
		QString strSubjectTitle("");
		for (USHORT usTemplateCount = 0; usTemplateCount < EMAIL_TEMPLATES_SIZE; usTemplateCount++) {
			// set the field to not set
            strSubjectTitle = QString::asprintf("%s %u", strSubject.toStdWString().c_str(), usTemplateCount + 1);
			memset(ptEmail->Templates[usTemplateCount], 0, EMAIL_TEMPLATES_LEN * sizeof(WCHAR));
#if _MSC_VER < 1400 
            wcsncpy(ptEmail->Templates[usTemplateCount], strSubjectTitle.toStdWString().c_str(), EMAIL_TEMPLATES_LEN);
#else
			wcsncpy_s( ptEmail->Templates[ usTemplateCount ], sizeof(ptEmail->Templates[ usTemplateCount ])/sizeof(WCHAR), strSubjectTitle, _TRUNCATE );
#endif
		}
		// Lan information
		T_LANINFO *ptLanInfo = &pCommunications->LanInfo;
		memset(ptLanInfo->user, 0, LANINFO_USER_LEN * sizeof(WCHAR));
		memset(ptLanInfo->password, 0, LANINFO_PASSWORD_LEN * sizeof(WCHAR));
		memset(ptLanInfo->domain, 0, LANINFO_DOMAIN_LEN * sizeof(WCHAR));
		memset(ptLanInfo->sharePath, 0, LANINFO_SHAREPATH_LEN * sizeof(WCHAR));
#if _MSC_VER < 1400 
        wmemcpy(ptLanInfo->user, strNotSet.toStdWString().c_str(), LANINFO_PASSWORD_LEN);
        wmemcpy(ptLanInfo->password, strNotSet.toStdWString().c_str(), LANINFO_USER_LEN);
        wmemcpy(ptLanInfo->domain, strNotSet.toStdWString().c_str(), LANINFO_DOMAIN_LEN);
        wmemcpy(ptLanInfo->sharePath, strNotSet.toStdWString().c_str(), LANINFO_SHAREPATH_LEN);
#else
		wmemcpy_s( ptLanInfo->user, sizeof(ptLanInfo->user)/sizeof(WCHAR),strNotSet, strNotSet.size()<LANINFO_PASSWORD_LEN?strNotSet.size():_TRUNCATE );
		wmemcpy_s( ptLanInfo->password, sizeof(ptLanInfo->password)/sizeof(WCHAR),strNotSet.toLocal8Bit().data(), strNotSet.size()<LANINFO_USER_LEN?strNotSet.size():_TRUNCATE );
		wmemcpy_s( ptLanInfo->domain, sizeof(ptLanInfo->domain)/sizeof(WCHAR),strNotSet, strNotSet.size()<LANINFO_DOMAIN_LEN?strNotSet.size():_TRUNCATE );
		wmemcpy_s( ptLanInfo->sharePath, sizeof(ptLanInfo->sharePath)/sizeof(WCHAR),strNotSet, strNotSet.size()<LANINFO_SHAREPATH_LEN?strNotSet.size():_TRUNCATE );
#endif
		//Security Information
		T_SECURITYOPTIONS *ptSecurityOptions = &pCommunications->SecurityOptions;
		memset(ptSecurityOptions->CertPfxPassword, 0, SECURITYOPTIONS_CERTPFXPASSWORD_LEN * sizeof(WCHAR));
#if _MSC_VER < 1400 
        wmemcpy(ptSecurityOptions->CertPfxPassword, strNotSet.toStdWString().c_str(), SECURITYOPTIONS_CERTPFXPASSWORD_LEN);
#else		
		wmemcpy_s(ptSecurityOptions->CertPfxPassword, sizeof(ptSecurityOptions->CertPfxPassword)/sizeof(WCHAR),strNotSet, strNotSet.size()<SECURITYOPTIONS_CERTPFXPASSWORD_LEN?strNotSet.size():_TRUNCATE );	
#endif
		return pCommunications;
	}
	return pCommunications;		// coverity fix h350726 return pCommunications
}
//****************************************************************************
// const QString   GetEmailAddresses( const ULONG ulEMAIL_ADDRS_BITFIELD )
///
/// Method that returns a string containing the email addresses that relate to the 
/// passed in bitfield
///
///	@param[in]		const ULONG ulEMAIL_ADDRS_BITFIELD - 
///
/// @return		A string contaiting the relkevant email addresses, delimitted with a '|' if there
///				are multiple addresses selected by the bitfield
///
//****************************************************************************
const QString CCommsSetupConfig::GetEmailAddresses(const quint64 ulEMAIL_ADDRS_BITFIELD) {
	QString strAddresses("");
	T_PCOMMUNICATIONS ptCommsData = NULL;
	ptCommsData = GetCommsBlock(CONFIG_COMMITTED);
	if (ptCommsData != NULL) {
		T_EMAIL *ptEmail = &ptCommsData->Email;
		QString strEmailAddr("");
		quint64 ulEmailBitmask = 0x0000000000000001;
		for (int iCount = 0; iCount < EMAIL_EMAILADDRESSES_SIZE; iCount++) {
			// if the address is valid and selected then add to the list
			strEmailAddr = QString::asprintf("%s|", ptEmail->EmailAddresses[iCount]);
			if ((strEmailAddr.indexOf('@') != -1) && ((ulEMAIL_ADDRS_BITFIELD & ulEmailBitmask) == ulEmailBitmask)) {
				// valid address and selected so add
				strAddresses += strEmailAddr;
			}
			// shift the bitmask along to the next item
			ulEmailBitmask <<= 1;
		}
	}
	return strAddresses;
}
//****************************************************************************
// const QString   GetIPAddress( )
///
/// Method that returns a string containing the recorders current IP address
///
///
/// @return		A string contaiting the current IP address
///
//****************************************************************************
const QString CCommsSetupConfig::GetIPAddress() const {
	QString strIPAddress;
	// check if this is static 
	char caDeviceName[80];
    if (gethostname(caDeviceName, sizeof(caDeviceName)) == QAbstractSocket::SocketError()) {
        strIPAddress = "NA";
	} else {

		struct hostent *phe = gethostbyname(caDeviceName);
		if (phe == 0) {
            strIPAddress = "NA";
		} else {
			// just use the first address available
			struct in_addr addr;
			memcpy(&addr, phe->h_addr_list[0], sizeof(struct in_addr));
			char *pcStr = inet_ntoa(addr);
			strIPAddress = QString::asprintf("%S", pcStr);
		}
	}
	return strIPAddress;
}
const USHORT DEFAULT_EMAIL_SIZE = 20;		// Default email size
//*****************************************************************************
/// Create a default script block if one is not available
///
/// @param[in] emailNumber - zero based e-mail number
///
/// @return creation success state
//*****************************************************************************
T_CONFIG_RETURN_VALUE CCommsSetupConfig::CreateEmailIfNotAvailable(USHORT emailNumber) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
    QString pEmailBlock = QString::fromWCharArray(GetEmailBlock(emailNumber, CONFIG_MODIFIABLE));
	if (pEmailBlock == NULL) {
		// No script block found for Pen, so create it and make sure it's one based.
		retValue = CONFIG_BLOCK_ADDED;
        QString pEmailBlock = QString::fromWCharArray(reinterpret_cast<WCHAR*>(CConfiguration::CreateNewVariableSizedBlock(
        BLKVARIABLE_EMAIL_MSG, emailNumber + 1, DEFAULT_EMAIL_SIZE, m_ConfigurationId)));
		if (pEmailBlock != NULL) {
			WCHAR defaultMail[DEFAULT_EMAIL_SIZE];
            swprintf(defaultMail,sizeof(defaultMail), L"Empty e-mail %d", emailNumber + 1);
            if (ModifyEmailBlock(emailNumber, QString::fromWCharArray(defaultMail)) != CMM_SUCCESS) {
				///< Log the error that occured
				retValue = CONFIG_ERROR;
			}
		} else {
			retValue = CONFIG_ERROR;
		}
	}
	return retValue;
}
//****************************************************************************
/// Get a free format e-mail block from config
///
/// @param[in] emailNumber - zero based e-mail number
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the email data block
/// 
//****************************************************************************
WCHAR* CCommsSetupConfig::GetEmailBlock(USHORT emailNumber, REFERENCE cfgType) {
	return reinterpret_cast<WCHAR*>(CConfiguration::GetBlock( BLKVARIABLE_EMAIL_MSG, emailNumber + 1, m_ConfigurationId,
			cfgType));
}
//****************************************************************************
/// Modify an email Block
///
/// @param[in] emailNumber - zero based e-mail number
/// @param[in] pNewBlock - pointer to new email block to store (NULL terminated)
///
/// @return error code from CConfiguration::ModifyVariableSizedBlock(...)
/// 
//****************************************************************************
CMMERROR CCommsSetupConfig::ModifyEmailBlock(USHORT emailNumber, QString pNewBlock) {
    DWORD size = static_cast<DWORD>(pNewBlock.length() + 1) * sizeof(WCHAR);	// Get string length including termination
    ALIGN_UP_4(size);

    QByteArray byteArray = pNewBlock.toUtf8();

        // Access the raw data as const unsigned char*
        const unsigned char* myUnsignedCharArray = reinterpret_cast<const unsigned char*>(byteArray.constData());
        unsigned char* myUnsignedChar = const_cast<unsigned char*>(myUnsignedCharArray);
	return CConfiguration::ModifyVariableSizedBlock( BLKVARIABLE_EMAIL_MSG, emailNumber + 1, size,
            (myUnsignedChar), m_ConfigurationId);
}
//****************************************************************************
//Function for Enabling/ Disabling TLS Protocol Version
//****************************************************************************
void CCommsSetupConfig::UpdateTLSProtocolSettings(E_TLS_PROTOCOL_CONFIG_ID eTlsV, bool bEnable) {
	QString strClientRegKey(("HKEY_LOCAL_MACHINE\\Comm\\SecurityProviders\\SCHANNEL\\Protocols\\"));
	QString strServerRegKey(("HKEY_LOCAL_MACHINE\\Comm\\SecurityProviders\\SCHANNEL\\Protocols\\"));
	CRegistryKey RegKey;
	switch (eTlsV) {
	case TLS_V_1_0:
		strServerRegKey += ("TLS 1.0\\Server");
		strClientRegKey += ("TLS 1.0\\Client");
		break;
	case TLS_V_1_1:
		strServerRegKey += ("TLS 1.1\\Server");
		strClientRegKey += ("TLS 1.1\\Client");
		break;
	case TLS_V_1_2:
		strServerRegKey += ("TLS 1.2\\Server");
		strClientRegKey += ("TLS 1.2\\Client");
		break;
	default:
		break;
	}
	DWORD dwTLSEnable = 0;
	if (bEnable) {
		dwTLSEnable = 1;
	}
	//client
	if (RegKey.OpenKey(strClientRegKey)) {
		//Update the registry value whether enabled or not
		RegKey.WriteValue(("Enabled"), dwTLSEnable);
	}
	RegKey.Close(); //RegKey.Flush( );
	//Server
	if (RegKey.OpenKey(strServerRegKey)) {
		RegKey.WriteValue(("Enabled"), dwTLSEnable);
	}
	RegKey.Close(); //RegKey.Flush( );
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration
/// @n Filename: SetupServiceConfig.h
/// @n Desc: Base class for Setup configuration services
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  8 Stability Project 1.5.1.1 7/2/2011 5:01:16 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.5.1.0 7/1/2011 4:28:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 V6 Firmware 1.5 8/26/2005 5:30:54 PM  Andy Kassell  Add
//  pre and Post commit processing
//  5 V6 Firmware 1.4 6/3/2005 7:34:21 PM Andy Kassell  
//  Modify to notify that changes have been made on a validation of
//  configuration
// $
//
// ****************************************************************
#ifndef _SETUPCONFIGSERVICE_H
#define _SETUPCONFIGSERVICE_H
#include "CMMDefines.h"
#include "ConfigurationCommon.h"
#include "ConfigurationManager.h"
class CSetupConfigService {
public:
	CSetupConfigService(void);
	virtual ~CSetupConfigService(void);
	// Each service must support the following service calls
    virtual T_CONFIG_RETURN_VALUE CreateServiceDefaultConfig(void) = 0
	;
    virtual T_CONFIG_VALIDATE_RETURN ValidateServiceConfig(void) = 0
	;
	// Each service can optionally support the following calls if processing is required
	virtual T_CONFIG_RETURN_VALUE PreCommitProcessing(void) {
		return CONFIG_OK;
	}
	;
	virtual T_CONFIG_RETURN_VALUE PostCommitProcessing(void) {
		return CONFIG_OK;
	}
	;
	void SetConfigurationId(DWORD configurationId) {
		m_ConfigurationId = configurationId;
	}
protected:
	DWORD m_ConfigurationId;
};
// End of Class Declaration
#endif // _SETUPCONFIGSERVICE_H

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Configuration
/// @n PenSetupConfig.h
/// @n interface to handle creating default configurations
///	and getting CMM pen configuration.
/// @author GKW
/// @date 22/09/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 15	Stability Project 1.12.1.1	7/2/2011 4:59:41 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 14	Stability Project 1.12.1.0	7/1/2011 4:28:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 13	V6 Firmware 1.12		9/23/2008 3:09:30 PM	Build Machine 
//		AMS2750 Merge
// 12	V6 Firmware 1.11		2/7/2007 8:28:27 PM	Jason Parker	Use
//		PEN_GROUP_MAX define
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PENSETUPCONFIG_H
#define _PENSETUPCONFIG_H
#include "SetupConfigService.h"
#include "V6Config.h"
#include "../inc/V6defines.h"
class CPenSetupConfig: public CSetupConfigService {
public:
	CPenSetupConfig(void);
	virtual ~CPenSetupConfig(void);
	T_CONFIG_RETURN_VALUE CreateServiceDefaultConfig(void);
	T_CONFIG_VALIDATE_RETURN ValidateServiceConfig(void);
	T_CONFIG_RETURN_VALUE PreCommitProcessing(void);
	// Pen specific CMM access
	T_PPEN GetPen(USHORT penNumber, T_PENBASE base, REFERENCE cfgType);
	char* GetPenScriptBlock(USHORT penNumber, T_PENBASE base, REFERENCE cfgType);
	T_CONFIG_RETURN_VALUE CreateScriptIfNotAvailable(USHORT penNumber, T_PENBASE base);
	CMMERROR ModifyScriptBlock(USHORT penNumber, T_PENBASE base, char *pNewBlock);
	T_PPEN GetDummyPen() {
		return &m_dummyPen;
	}
	;
	UCHAR GroupChangedFlag(int GroupNumber) {
		return (m_GroupChanged[GroupNumber] || m_GroupUnused[GroupNumber]);
	}
	;
	BOOL GroupsChanged() {
		return m_ChangesMade;
	}
	;
	/// @todo replace this accessor possibly - talk to grazza
	T_CONFIG_RETURN_VALUE GetPenLimits(REFERENCE cfgType, USHORT PenNo, float *pPenZero, float *pPenSpan);
private:
	T_CONFIG_RETURN_VALUE CreatePen(USHORT penNumber, T_PENBASE base);
	// Method that sets the span to the highest configured setpoint - used in TUS mode
	const T_CONFIG_VALIDATE_RETURN SetSpanToHiSetpoint(float &rfSpan);
	T_PEN m_dummyPen; ///< Dummy Pen structure, ensures data always available so no ptr checks required
	BOOL m_ChangesMade;
	UCHAR m_GroupChanged[PEN_GROUP_MAX]; //0=none, then 1 to 6 for groups. 
	UCHAR m_GroupUnused[PEN_GROUP_MAX]; // as above
};
// End of Class Declaration
#endif // _PENSETUPCONFIG_H

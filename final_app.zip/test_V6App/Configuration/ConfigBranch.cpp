/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigBranch.cpp
/// @n Description: Implementation for the CConfigBranch class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Stability Project 1.7.1.3 7/2/2011 4:56:15 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:06 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:16 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:02:38 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "ConfigBranch.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
// CConfigBranch(	const QString   &rstrKEY,
//					const QString   &rstrTITLE,
//					const QString   &rstrSUB_TITLE,
//					const ControlType eCONTROL_TYPE,
//					const bool bMODIFIED,
//					const bool bENABLED,
//					const long lHELP_ID,
//					const bool bLOCKED,
//					CConfigInterface* const pkPARENT )
///
/// Constructor
///
/// @param[in] 			const QString   &rstrKEY - Unique Key used to identify the config item
/// @param[in] 			const QString   &rstrTITLE - Title string to be displayed on the control
/// @param[in] 			const QString   &rstrSUB_TITLE - Subtitle string to be displayed on the control
/// @param[in] 			const ControlType eCONTROL_TYPE - The type of control
/// @param[in] 			const bool bMODIFIED - Flag indicating if this item or any of its children have
///						been modified
/// @param[in] 			const bool bENABLED - Flag indicating if the config item is enabled
/// @param[in] 			const long lHELP_ID - The resource ID for a help string
/// @param[in] 			const bool bLOCKED - Flag indicating if the config branch is editable or not - this is
///						to allow the user to browse the configuration structure but to not modify the data
/// @param[in] 			CConfigInterface* const pkPARENT - Pointer to the parent config branch class
///
//****************************************************************************
CConfigBranch::CConfigBranch(const QString &rstrKEY, const QString &rstrTITLE, const QString &rstrSUB_TITLE,
		const ControlType eCONTROL_TYPE, const bool bMODIFIED, const bool bENABLED, const long lHELP_ID,
		const bool bLOCKED, CConfigInterface *const pkPARENT) : CConfigInterface(rstrKEY, rstrTITLE, rstrSUB_TITLE,
		eCONTROL_TYPE, bMODIFIED, bENABLED, lHELP_ID, bLOCKED, pkPARENT, citConfigBranch) {
	m_usCurrentChild = 0;
	m_kChildren.clear();
}
//****************************************************************************
// ~CConfigBranch(void)
///
/// Destructor
///
//****************************************************************************
CConfigBranch::~CConfigBranch(void) {
	// release the memory for the children
	std::vector<CConfigInterface*>::iterator kCurr = m_kChildren.begin();
	std::vector<CConfigInterface*>::iterator kEnd = m_kChildren.end();
	while (kCurr != kEnd) {
		delete (*kCurr);
		++kCurr;
	}
	// clear the list
	m_kChildren.clear();
}
//****************************************************************************
// void AddChild( CConfigInterface *pkChild )
///
/// Method that adds a child to the list of child items
///
/// @param[in]		CConfigInterface *pkChild - Pointer to the child variable that is
///					to be added
/// 
//****************************************************************************
void CConfigBranch::AddChild(CConfigInterface *pkChild) {
	m_kChildren.push_back(pkChild);
}
//****************************************************************************
// CConfigInterface* GetFirstChild( )
///
/// Method that gets the first child and sets the current child variable to one
///
/// @return			Pointer to the first child or NULL if there are none
/// 
//****************************************************************************
CConfigInterface* CConfigBranch::GetFirstChild() {
	CConfigInterface *pkFirstChild = NULL;
	// should never be less than one child but check anyway
	if (m_kChildren.size() > 0) {
		m_usCurrentChild = 1;
		pkFirstChild = m_kChildren[0];
	}
	return pkFirstChild;
}
//****************************************************************************
// CConfigInterface* GetNextChild( )
///
/// Method that gets the current child and increments the current child variable by one
///
/// @return			Pointer to the current child or NULL if there are no children or the current 
///					child variable has not been reset by calling the GetFirstChild method
/// 
//****************************************************************************
CConfigInterface* CConfigBranch::GetNextChild() {
	CConfigInterface *pkChild = NULL;
	// check it does not exceed our list length
	if (m_usCurrentChild < m_kChildren.size()) {
		pkChild = m_kChildren[m_usCurrentChild];
		// move the current child pointer on one
		++m_usCurrentChild;
	}
	return pkChild;
}
//****************************************************************************
// CConfigInterface* GetChild( const USHORT usCHILD_NUM )
///
/// Method that gets the requested child using the passed in number
///
/// @param[in] 		const USHORT usCHILD_NUM - The number of the currnet required child
///
/// @return			Pointer to the required child or NULL if there are no children or the required
///					child variable exceeds the number of children in the list
/// 
//****************************************************************************
CConfigInterface* CConfigBranch::GetChild(const USHORT usCHILD_NUM) {
	CConfigInterface *pkChild = NULL;
	// check it does not exceed our list length
	if (usCHILD_NUM < m_kChildren.size()) {
		pkChild = m_kChildren[usCHILD_NUM];
	}
	return pkChild;
}
//****************************************************************************
// void ReplaceChild( CConfigInterface *pkNewChild )
///
/// Method that adds replace a child in the list of child items
///
/// @param[in]		CConfigInterface *pkChild - Pointer to the child variable that is
///					to be added
/// 
//****************************************************************************
void CConfigBranch::ReplaceChild(CConfigInterface *pkNewChild) {
	QString strNEW_CHILD_KEY = pkNewChild->GetKey();
	std::vector<CConfigInterface*>::iterator kCurr = m_kChildren.begin();
	std::vector<CConfigInterface*>::iterator kEnd = m_kChildren.end();
	bool bInserted = false;
	// loop through all the children
	while (kCurr != kEnd) {
		// find the item with a matching key
		if (strNEW_CHILD_KEY == (*kCurr)->GetKey()) {
			// match found therefore delete this item and replace it with the new one
			delete (*kCurr);
			(*kCurr) = pkNewChild;
			break;
		} else {
			++kCurr;
		}
	}
}
//****************************************************************************
// const USHORT indexOfChildPos( const CConfigInterface* const pkCHILD ) const
///
/// Method that returns the position of this item within the child list
///
/// @param[in]		CConfigInterface *pkChild - Pointer to the child variable who's position is
///					to be found
/// 
/// @return			The position number of the passed in child item - 0 based and 0 is not found
///
//****************************************************************************
const USHORT CConfigBranch::indexOfChildPos(const CConfigInterface *const pkCHILD) {
	USHORT usChildNum = 0;
	std::vector<CConfigInterface*>::iterator kCurr = m_kChildren.begin();
	std::vector<CConfigInterface*>::iterator kEnd = m_kChildren.end();
	// loop through all the children
	USHORT usCount = 0;
	while (kCurr != kEnd) {
		// check if this is the same pointer
		if (pkCHILD == (*kCurr)) {
			// we have found our child
			usChildNum = usCount;
			break;
		}
		++usCount;
		++kCurr;
	}
	return usChildNum;
}
//****************************************************************************
// void InsertChild( CConfigInterface *pkNewChild, CConfigInterface *pkChildToInsertBefore )
///
/// Method that inserts a new child into this parents child list
///
/// @param[in]		CConfigInterface *pkNewChild - Pointer to the new child
/// @param[in]		CConfigInterface *pkChildToInsertBefore - Pointer to the child that the
///					new child is to be inserted in front of
///
//****************************************************************************
void CConfigBranch::InsertChild(CConfigInterface *pkNewChild, CConfigInterface *pkChildToInsertBefore) {
	std::vector<CConfigInterface*>::iterator kCurr = m_kChildren.begin();
	std::vector<CConfigInterface*>::iterator kEnd = m_kChildren.end();
	bool bInserted = false;
	// loop through all the children
	while (kCurr != kEnd) {
		// find the item with a matching key
		if (pkChildToInsertBefore == (*kCurr)) {
			// match found therefore insert our new child
			m_kChildren.insert(kCurr, pkNewChild);
			break;
		} else {
			++kCurr;
		}
	}
}
//****************************************************************************
// CConfigInterface* CConfigBranch::GetChildByKey( const QString   & csKey)
///
/// Method that gets a child item from the passed in key
///
/// @param[in]		const QString   & csKey - Pointer to the key to be sought
///
//****************************************************************************
CConfigInterface* CConfigBranch::GetChildByKey(const QString &csKey) {
	CConfigInterface *pkChild = NULL;
	//determine that there are child items to search before trying to find our "Tag" child
	if (m_kChildren.size() > 0) {
		pkChild = GetFirstChild();		//get the first child item
		BOOL bFound = FALSE;		//initialise the "get out when match found" flag
		//search every child item until either a match is found or there are no more children - sounds like a job for the child catcher!!!!
		while ((NULL != pkChild) && (FALSE == bFound)) {
			QString csSubTitle = pkChild->GetKey();		//get the associated Key for this child item
			/*
			 traverse the key string finding the last delimiter 
			 */
			int nDelim = csSubTitle.indexOf(L'|', 0);				//initialise our delimiter locater
			int nLastDelim = nDelim;				//keep a copy of the delimit value as the delimiter will get to -1
			//keep running through the list until the end of the string, and last delimiter, is found		
			while (nDelim > 0) {
				nDelim = csSubTitle.indexOf(L'|', nDelim + 1);	//get next delimiter posiiton
				//if the end of the string is not reached then take a copy
				//don't move along if the delimiter is at the end of the string
				if ((nDelim > 0) && (nDelim != csSubTitle.size() - 1))
					nLastDelim = nDelim;
				else if (nDelim == csSubTitle.size() - 1) {
					//if the delimiter is at the end of the string the last entry has
					//been found so break out without changing the last delimiter pos
					break;
				}
			}
			//having got to the end of the string make sure that we have at least 1 delimiter
			if (nLastDelim >= 0) {
				//get the last Tag in the string
				QString csSubKey = csSubTitle.right(csSubTitle.size() - (nLastDelim + 1));
				//remove the last character, a '|' 
				csSubKey.remove('|');
				//if the tag matches the passed in tag then set the found flag TRUE, and end the search
				if (csSubKey.compare(csKey) == 0) {
					bFound = TRUE;
				} else	//get the next child item
				{
					pkChild = GetNextChild();
				}
			}
		}
	}
	return pkChild;
}

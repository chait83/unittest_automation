/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AMS2750CalConfigData.h
/// @n Description: Declaration for the CAMS2750CalConfigData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:$
//
// **************************************************************************
#if !defined(AFX_AMS2750CALCONFIGDATA_H__712E2766_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_)
#define AFX_AMS2750CALCONFIGDATA_H__712E2766_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ConfigData.h"
#include "V6Config.h"
#include <QString>
#include "../ConfigurationManager/windef.h"
//**CAMS2750CalConfigData*****************************************************
///
/// @brief Provides an interface to T_AMS2750CALCFG information for the data-driven menu's
/// 
/// Provides an interface to T_AMS2750CALCFG information for the data-driven menu's
///
//****************************************************************************
class CAMS2750CalConfigData: public CConfigData {
public:
	// Constructor
	CAMS2750CalConfigData(T_PAMS2750CALCFG ptCalConfig);
	// Destructor
	virtual ~CAMS2750CalConfigData();
	// Method called to validate data entered by a user - not used
	virtual bool ValidateData(const QString pwcDATA) {
		return true;
	}
	// Method called to validate data entered by the user
	static const bool ValidateData(const T_PAMS2750CALCFG ptSENSOR_DATA, USHORT &rusFailedValue);
	// Method that updates the data based on the passed in string - not used
	virtual void UpdateData(const QString pwcDATA) {
		;
	}
	// Method that returns the data as a string
	virtual const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
	// Method that returns a pointer to the data
	virtual void* GetData() const {
		return m_ptAMS2750CalConfig;
	}
private:
	/// Variable used to store a pointer to the calibration configuration information
	T_PAMS2750CALCFG m_ptAMS2750CalConfig;
};
#endif // !defined(AFX_AMS2750CALCONFIGDATA_H__712E2766_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_)

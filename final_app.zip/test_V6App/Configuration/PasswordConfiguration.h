/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Configuration
/// @n Filename:	PasswordConfiguration.h
/// @n Description: Class Declaration for Passward Configuration 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 12	Stability Project 1.9.1.1	7/2/2011 4:59:37 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 11	Stability Project 1.9.1.0	7/1/2011 4:28:18 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 10	V6 Firmware 1.9		8/9/2006 1:44:38 PM	Jason Parker 
//		persist flag passed to load and save configs
// 9	V6 Firmware 1.8		4/19/2006 5:08:09 PM	Roger Dawson 
//		Replaced CStorage with QFile to avoid problems with screen designer.
// $
//
// **************************************************************************
#ifndef _PASSWORDCONFIGURATION_H
#define _PASSWORDCONFIGURATION_H
#include <QFile>
#include "Configuration.h"
#include "V6Config.h"
//**Class*********************************************************************
///
/// @brief Password Configuration Class
/// 
/// This class creates default Password configurations and provides general
/// functions for dealing with the CMM
///
//****************************************************************************
class CPasswordConfiguration: public CConfiguration {
public:
	/// Constructor 
	CPasswordConfiguration(void);
	/// Destructor
	virtual ~CPasswordConfiguration(void);
	/// Create a Default Configuration 
	virtual T_CONFIG_RETURN_VALUE CreateDefaultConfig(void);
	/// Validate a Configuration 
	virtual T_CONFIG_VALIDATE_RETURN ValidateConfiguration(void);
	///
	virtual T_CONFIG_RETURN_VALUE LoadConfig(QFile &fileToLoadConfig, const TV_BOOL persistedLoad = FALSE);
	T_CONFIG_RETURN_VALUE LoadConfig(BYTE *pConfBuf, ULONG bufSiz, const TV_BOOL persistedLoad = FALSE);
	/// 
	virtual T_CONFIG_RETURN_VALUE SaveConfiguration(const QString &rstrFILE_NAME) const;
	// virtual T_CONFIG_RETURN_VALUE SaveConfig( const QString   const pConfigPathAndFileName ); 
	/// 
	virtual T_CONFIG_RETURN_VALUE SaveConfig(QFile &fileToSaveConfig, const TV_BOOL persistedSave = FALSE);
	/// 
	virtual T_CONFIG_RETURN_VALUE UpdateConfig(void);
	virtual void SetConfigurationId(const DWORD configurationId);
	T_CONFIG_RETURN_VALUE GetWorkingPasswordConfig(BYTE **pPmmBuf, BYTE **pPolicyBuf);
	T_CONFIG_RETURN_VALUE PersistConfig(void);
private:
	T_CONFIG_RETURN_VALUE MigrateConfig(void);
};
// End of Class Declaration
#endif // _PASSWORDCONFIGURATION_H

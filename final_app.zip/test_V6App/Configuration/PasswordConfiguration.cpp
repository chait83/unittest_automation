/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Configuration
/// @n Filename:  PasswordConfiguration.cpp
/// @n Description: Class Implementation for Password Configuration
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  32  Stability Project 1.27.1.3 7/2/2011 4:59:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  31  Stability Project 1.27.1.2 7/1/2011 4:38:35 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  30  Stability Project 1.27.1.1 3/17/2011 3:20:33 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  29  Stability Project 1.27.1.0 2/15/2011 3:03:38 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "../inc/V6globals.h"
#include "PasswordConfiguration.h"
#include "TVTime.h"
#include "V6crc.h"
#include "PMMglobal.h"
#include "../inc/PMMDefines.h"
#include "../inc/PassAuthDefines.h"
#include "../Passwords/CPasswordModule.h"
#include "../Passwords/AuthenticatePwd.h"
#include "SysInfo.h"
#include "QtWidgets/qwidget.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
const USHORT MAX_PASS_BLOCK_SIZE = 62000;	///< Size in bytes of maximum to store per flash block
CPasswordConfiguration::CPasswordConfiguration(void) {
}
CPasswordConfiguration::~CPasswordConfiguration(void) {
}
//void CPasswordConfiguration::GetPasswordConfig()
//{
//}
T_CONFIG_RETURN_VALUE CPasswordConfiguration::CreateDefaultConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CMMERROR err;
	BLOCK_INFO pBlockDetails;
	T_PMMDATA *pPmm;
	T_PMMPOLICYDATA *pPolicy;
	pBlockDetails.wInstanceID = 1;
	pBlockDetails.wBlockType = BLK_PMMPOLICYDATA;
	pBlockDetails.dwSessionNumber = 1;
	pBlockDetails.pByBlock = NULL;
	err = CreateDataBlock(GetConfigId(), &pBlockDetails);
	pPolicy = (T_PMMPOLICYDATA*) pBlockDetails.pByBlock;
	pBlockDetails.wInstanceID = 1;
	pBlockDetails.wBlockType = BLK_PMMDATA;
	pBlockDetails.dwSessionNumber = 1;
	pBlockDetails.pByBlock = NULL;
	err = CreateDataBlock(GetConfigId(), &pBlockDetails);
	pPmm = (T_PMMDATA*) pBlockDetails.pByBlock;
	for (int i = 1; i < 6; i++) {
		pPmm->GroupPerm[i][0] = AUTH_NO_ACCESS;
		pPmm->GroupPerm[i][1] = AUTH_NO_ACCESS;
		pPmm->GroupPerm[i][2] = AUTH_NO_ACCESS;
		pPmm->GroupPerm[i][3] = AUTH_NO_ACCESS;
	}
	QString csTmp;
    csTmp =QWidget::tr("Administrator");
    wcsncpy(pPolicy->GPolicyData.userLevelLables[USER_LEVEL_0], csTmp.toStdWString().c_str(), csTmp.length());

	pPmm->GroupPerm[USER_LEVEL_0][0] = AUTH_ALL_ACCESS;	//all access for admin
	pPmm->GroupPerm[USER_LEVEL_0][1] = AUTH_ALL_ACCESS;
	pPmm->GroupPerm[USER_LEVEL_0][2] = AUTH_ALL_ACCESS;
	pPmm->GroupPerm[USER_LEVEL_0][3] = AUTH_ALL_ACCESS;
    csTmp =QWidget::tr("Engineer");
    wcsncpy(pPolicy->GPolicyData.userLevelLables[USER_LEVEL_1],csTmp.toStdWString().c_str(), csTmp.length());
	pPmm->GroupPerm[USER_LEVEL_1][0] = AUTH_ENG_LO_SEG;
	pPmm->GroupPerm[USER_LEVEL_1][1] = AUTH_ENG_SEC_SEG;
    csTmp =QWidget::tr("Supervisor");
    wcsncpy(pPolicy->GPolicyData.userLevelLables[USER_LEVEL_2],csTmp.toStdWString().c_str(), csTmp.length());
	pPmm->GroupPerm[USER_LEVEL_2][0] = AUTH_SUP_LO_SEG;
	pPmm->GroupPerm[USER_LEVEL_2][1] = AUTH_SUP_SEC_SEG;
    csTmp =QWidget::tr("Technician");
    wcsncpy(pPolicy->GPolicyData.userLevelLables[USER_LEVEL_3],csTmp.toStdWString().c_str(), csTmp.length());
	pPmm->GroupPerm[USER_LEVEL_3][0] = AUTH_TEC_LO_SEG;
	pPmm->GroupPerm[USER_LEVEL_3][1] = AUTH_TEC_SEC_SEG;
    csTmp =QWidget::tr("Operator");
    wcsncpy(pPolicy->GPolicyData.userLevelLables[USER_LEVEL_4],csTmp.toStdWString().c_str(), csTmp.length());
	pPmm->GroupPerm[USER_LEVEL_4][0] = AUTH_OP_LO_SEG;
	pPmm->GroupPerm[USER_LEVEL_4][1] = AUTH_OP_SEC_SEG;
    csTmp =QWidget::tr("Unrestricted");
    wcsncpy(pPolicy->GPolicyData.userLevelLables[USER_LEVEL_5],csTmp.toStdWString().c_str(), csTmp.length());
	pPmm->GroupPerm[USER_LEVEL_5][0] = AUTH_DEF_UNRES_LO;
	pPmm->GroupPerm[USER_LEVEL_5][1] = AUTH_DEF_UNRES_SEC;
	if (CMM_SUCCESS != err)
		retValue = CONFIG_CMM_CREATE_DATA_BLOCK_FAILED;
	if (!pSYSTEM_INFO->FWOptionPasswordCFRAvailable()) {
		// password CFR is turned off - 'soften' the password settings a little
		pPolicy->PwdPolicyData.expiryDays = 0;
	}
	return (retValue);
} // End of Member Function
T_CONFIG_RETURN_VALUE CPasswordConfiguration::MigrateConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CMMERROR err = CMM_FAILED;
	BLOCK_INFO pBlockDetails;
	T_PMMDATA *pPmm = NULL;
	T_PMMPOLICYDATA *pPolicy = NULL;
	pBlockDetails.wInstanceID = 1;
	pBlockDetails.wBlockType = BLK_PMMDATA;
	pBlockDetails.dwSessionNumber = 1;
	pBlockDetails.pByBlock = NULL;
	GetWorkingPasswordConfig((BYTE**) &pPmm, (BYTE**) &pPolicy);
	if ((pPmm != NULL) && (pPolicy != NULL)) {
		for (USHORT usUserID = 0; usUserID < MAX_USERS; usUserID++) {
#ifndef DOCVIEW
			//Migrate the Current Password
            CAuthenticatePwd objAuthCurrPwd(QString::fromWCharArray(pPmm->UserData[usUserID].PwdInfo.CurrentPassword));
			HASHDWSZ2BU_32 uHash;
			SALTDWSZ2BU_8 uSalt;
			CAuthenticatePwd::resetHash(uHash);
			CAuthenticatePwd::resetSalt(uSalt);
			objAuthCurrPwd.getHash(uHash);
			objAuthCurrPwd.getSalt(uSalt);
            memcpy(pPmm->UserData[usUserID].PwdInfo.HSCurrentPwd.Hash, uHash.b, sizeof(uHash));
            memcpy(pPmm->UserData[usUserID].PwdInfo.HSCurrentPwd.Salt, uSalt.b, sizeof(uSalt));
			//Migrate the Password history
			for (short pwdhsty = 0; pwdhsty <= pPolicy->PwdPolicyData.PreviousPwd; pwdhsty++) {
				CAuthenticatePwd::resetHash(uHash);
				CAuthenticatePwd::resetSalt(uSalt);
                CAuthenticatePwd newAuthPwd(QString::fromWCharArray(pPmm->UserData[usUserID].PwdInfo.Password[pwdhsty]));
				newAuthPwd.getHash(uHash);
				newAuthPwd.getSalt(uSalt);
                memcpy(pPmm->UserData[usUserID].PwdInfo.HSPassword[pwdhsty].Hash, uHash.b,
						sizeof(uHash));
                memcpy(pPmm->UserData[usUserID].PwdInfo.HSPassword[pwdhsty].Salt, uSalt.b,
						sizeof(uSalt));
				//	pPmm->UserData[usUserID].PwdInfo.Password[pwdhsty] = ;
				CStringUtils::SafeWcsCpy(pPmm->UserData[usUserID].PwdInfo.Password[pwdhsty], L"\0",
				USERPASSPERM_CURRENTPASSWORD_LEN);
			}
#endif
		}
		retValue = UpdateConfig();
	}
	return (retValue);
}
//********************************************************************************
/// Validates the CMM Configuration and makes the neccessary modifications to ensure
/// the CMM is correct for Operation. The Validate routines will be called on each
/// of the Setup Configuration Service Classes. 
/// 
/// @param[in] - NONE
///
/// @return CONFIG_OK - Validation Completed Successfully
/// 
//********************************************************************************
T_CONFIG_VALIDATE_RETURN CPasswordConfiguration::ValidateConfiguration(void) {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES; // Member Function Return Value
// if config validated and changed set return value
//	CONFIG_VALIDATE_NO_CHANGES,					
//	CONFIG_VALIDATE_CHANGES_MADE				
	return (retValue);
} // End of Member Function 
///
T_CONFIG_RETURN_VALUE CPasswordConfiguration::LoadConfig(QFile &fileToLoadConfig, const TV_BOOL persistedLoad) {
	return (LoadConfigService(fileToLoadConfig, CONFIG_PASSWORD_FILE_TYPE, persistedLoad));
}
T_CONFIG_RETURN_VALUE CPasswordConfiguration::LoadConfig(BYTE *pConfBuf, ULONG bufSiz, const TV_BOOL persistedLoad) {
	WCHAR szDbgMsg[512];
	const USHORT PWD_CFVERSION = 194;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_INVALID_FILE;  // Member Function Return Value
	// Store the Current Configuration Id, to ensure that if any failure occur we
	// can revert back to the previous configuration. 
	DWORD previousConfigurationId = GetConfigId();
	// Create a CMM Configuration Holder
	retValue = CreateCMMConfiguration();
	T_CONFIG_RETURN_VALUE ret;
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CPasswordConfiguration::LoadConfig: CreateCMMConfiguration GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	if (CONFIG_OK == retValue) {
		BYTE *pAllocatedBuffer = NULL; // CMM Allocated Buffer Pointer 
		//CStorage configFileToBeLoaded; // File Handler to the Configuration File to be Loaded
		CONFIGHEADERINFO *configFileHeader = (CONFIGHEADERINFO*) pConfBuf;
		if (CONFIG_OK == ValidateConfigFileHeader(*configFileHeader, CONFIG_PASSWORD_FILE_TYPE)) {
			// CMM Allocated Buffer Pointer 
			BYTE *pAllocatedBuffer = NULL;
			// Perform CRC Validation
			if (CRC_TEST_PASSED == CrcTest(pConfBuf, bufSiz)) {
				// CRC has been verified and is correct, decrement the CRC from the 
				// configuration length. The CMM requires the buffer to contain just
				// the configuration data, excluding CRC.
				retValue = PerformLoadCMMConfiguration((bufSiz - CONFIG_CRC_LENGTH), pAllocatedBuffer, pConfBuf,
						persistedLoad);
			} else {
				retValue = CONFIG_CRC_INVALID;
			} // End of IF
		}
	}
	if (pSYSTEM_INFO->IsFirmwareUpgraded() && (ConversionHasBeenPerformed() == TRUE)) {
		if (ConvertedFromVersion() < PWD_CFVERSION) {
			ret = MigrateConfig();
		}
		//retValue=SaveConfiguration(_T("C:\\TV6PC\\intcf\\Passwordconfig.cfg"));
	}
	return retValue;
}
////////////////////////////////////////////
T_CONFIG_RETURN_VALUE CPasswordConfiguration::SaveConfiguration(const QString &rstrFILE_NAME) const {
	CStorage kConfigFile;
    kConfigFile.Open(rstrFILE_NAME, QFile::WriteOnly);
	T_CONFIG_RETURN_VALUE eRetVal;
	eRetVal = pPwdSetup->SaveConfig(kConfigFile);
	kConfigFile.Close();
	return eRetVal;
}
///////////////////////////////////////////////
/// 
T_CONFIG_RETURN_VALUE CPasswordConfiguration::SaveConfig(QFile &fileToSaveConfig, const TV_BOOL persistedSave) {
	CONFIGHEADERINFO configFileHeader;
	// fileToSaveConfig.GetfILE
	// Construct the Configuration File Header
    swprintf(configFileHeader.szFileName,sizeof(configFileHeader.szFileName), L"%s", fileToSaveConfig.fileName().size() + 1);
    QDateTime ourTime;
    ourTime.currentDateTime();
    configFileHeader.dtCreationDateTime = ourTime.toMSecsSinceEpoch() * 1000LL;
	configFileHeader.szPassword[0] = L'\0';
	configFileHeader.wEncryption = 0;
	configFileHeader.wFileType = CONFIG_PASSWORD_FILE_TYPE;
	configFileHeader.dwSource = 0;
    configFileHeader.dwAction = 1;

	return (SaveConfigFile(fileToSaveConfig, configFileHeader));
}
/// 
/*T_CONFIG_RETURN_VALUE CPasswordConfiguration::SaveConfig( const QString  const pConfigPathAndFileName )
 {
 T_CONFIG_RETURN_VALUE retValue = CONFIG_INVALID_FILE;
 
 if( NULL != pConfigPathAndFileName )
 {
 CONFIGHEADERINFO configFileHeader;
 
 // Construct the Configuration File Header
 
 swprintf( configFileHeader.szFileName, L"%s", pConfigPathAndFileName );
 
 QTime ourTime;
 ourTime.TimeNow();
 configFileHeader.dtCreationDateTime = ourTime.GetMicroSecs();	
 configFileHeader.szPassword[0] = L'\0';
 configFileHeader.wEncryption  = 0;
 configFileHeader.wFileType = CONFIG_PASSWORD_FILE_TYPE;
 configFileHeader.dwSource = 0;
 configFileHeader.dwAction = 1;
 
 retValue = SaveConfigFile( pConfigPathAndFileName, configFileHeader );
 
 } // End of IF
 
 return( retValue );
 } // End of Member Function*/
/// 
T_CONFIG_RETURN_VALUE CPasswordConfiguration::UpdateConfig(void) {
	return (CommitConfig());
}
void CPasswordConfiguration::SetConfigurationId(const DWORD configurationId) {
	SetConfigId(configurationId);
}
T_CONFIG_RETURN_VALUE CPasswordConfiguration::GetWorkingPasswordConfig(BYTE **pPmmBuf, BYTE **pPolicyBuf) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CMMERROR err;
	DWORD dwSize;
	BLOCK_INFO pBlockDetails;
	pBlockDetails.wInstanceID = 1;
	pBlockDetails.wBlockType = BLK_PMMPOLICYDATA;
	pBlockDetails.dwSessionNumber = 1;
	pBlockDetails.pByBlock = NULL;
	GetSizeOfBlockType(BLK_PMMPOLICYDATA, &dwSize);
	//pBlockDetails.pByBlock = pPolicyBuf;
	err = GetDataBlock(GetConfigId(), &pBlockDetails, CONFIG_MODIFIABLE);
	*pPolicyBuf = pBlockDetails.pByBlock;
	pBlockDetails.wBlockType = BLK_PMMDATA;
	GetSizeOfBlockType(BLK_PMMDATA, &dwSize);
	//pBlockDetails.pByBlock = pPmmBuf;
	err = GetDataBlock(GetConfigId(), &pBlockDetails, CONFIG_MODIFIABLE);
	*pPmmBuf = pBlockDetails.pByBlock;
	if (CMM_SUCCESS != err)
		retValue = CONFIG_ACTION_COULD_NOT_BE_PERFORMED;
	return (retValue);
}
T_CONFIG_RETURN_VALUE CPasswordConfiguration::PersistConfig(void) {
	CFlashManager *pFlash = CFlashManager::GetHandle();
//////////////////
	CONFIGHEADERINFO configFileHeader;
	// fileToSaveConfig.GetfILE
	// Construct the Configuration File Header
	//swprintf( configFileHeader.szFileName, L"%s", fileToSaveConfig.GetFileName() );
    QDateTime ourTime;
    ourTime.currentDateTime();
    configFileHeader.dtCreationDateTime = ourTime.toMSecsSinceEpoch() * 1000LL;
    configFileHeader.szPassword[0] = L'\0';
    configFileHeader.wEncryption = 0;
    configFileHeader.wFileType = CONFIG_PASSWORD_FILE_TYPE;
    configFileHeader.dwSource = 0;
    configFileHeader.dwAction = 1;
/////////////////
	T_CONFIG_RETURN_VALUE retValue = CONFIG_NO_PERSISTED_CONFIGURATION;
	DWORD configBufferSize = CONFIG_WAIT;  ///< Size of the current configuration
	BYTE *pConfigBuffer = NULL; ///< Pointer to the current configuration
	BYTE *pBlockToWrite = NULL;
	USHORT configFileCRCValue = 0;				///< Calculated CRC for Config File
	// Set Configuration Log
	if (CMM_SUCCESS == SetConfigurationLog(GetConfigId(), &configFileHeader)) {
		// Request Pointer to Configuration 
		if (CMM_SUCCESS == GetConfiguration(GetConfigId(), &configBufferSize, &pConfigBuffer)) {
			// Calculate the CRC for the entire Config File, this value
			// shall be appended to the end of the config file.  
			configFileCRCValue = CrcCalc(pConfigBuffer, configBufferSize);
			//CStorage configFileToBeSaved;  // File Handler for the Configuration to be saved to.
			//if( TRUE == configFileToBeSaved.Open( pConfigPathAndFileName,  | QFile::WriteOnly ) )
			{
				// Write the Configuration to the File
				pBlockToWrite = new BYTE[configBufferSize + CONFIG_CRC_LENGTH];
				memcpy(pBlockToWrite, pConfigBuffer, configBufferSize);
				// --- Write the CRC to the End of the File --- //
				// Write High Byte of the CRC to the file
				pBlockToWrite[configBufferSize++] = (BYTE) (configFileCRCValue >> 8);
				// Write Low Byte of the CRC to the file
				pBlockToWrite[configBufferSize++] = (BYTE) (configFileCRCValue & 0xFF);
				// Indicate Successful Write of the Configuration to the File
				retValue = CONFIG_OK;
			}
		}
	}
	if ((CONFIG_OK == retValue) && pBlockToWrite) {
		if (configBufferSize > MAX_PASS_BLOCK_SIZE) {
			LONG remainSiz = configBufferSize - MAX_PASS_BLOCK_SIZE;
			BYTE *pTmp = pBlockToWrite;
			// Write the password config to flash memory, flash is split into 64K blocks, password will be just bigger 
			// then one block so needs to be split over two blocks
			if (FLASH_STATUS_OKAY == pFlash->WriteBlock(FLASH_BLK_PASSWORDS, pTmp, MAX_PASS_BLOCK_SIZE)) {
				pTmp += MAX_PASS_BLOCK_SIZE;
				if (FLASH_STATUS_OKAY == pFlash->WriteBlock(FLASH_BLK_PASSWORDS2, pTmp, remainSiz)) {
					retValue = CONFIG_OK;
				}
			}
		} else {
			if (FLASH_STATUS_OKAY == pFlash->WriteBlock(FLASH_BLK_PASSWORDS, pBlockToWrite, configBufferSize))
				retValue = CONFIG_OK;
		}
		delete pBlockToWrite;
	}
	return retValue;
}

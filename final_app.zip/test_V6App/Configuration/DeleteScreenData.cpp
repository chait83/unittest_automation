/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  DeleteScreenData.cpp
/// @n Description: Implementation for the CDeleteScreenData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.1.1.3 7/2/2011 4:56:42 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.1.1.2 7/1/2011 4:38:14 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.1.1.1 3/17/2011 3:20:21 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  3 Stability Project 1.1.1.0 2/15/2011 3:02:55 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "DeleteScreenData.h"
#include "ConfigInterface.h"
#include "ConfigBranch.h"
#include "../OpPanel/Screen.h"
#include "ScrnDesCfgMgr.h"
#include "../UIControl/CfgBitFieldEditDlg.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
// CDeleteScreenData(	const int iHELP_ID,
//					const int iDESC_ID )
///
/// Constructor
///
/// @param[in]			const int iHELP_ID - The resource ID of the associated help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
///
//****************************************************************************
CDeleteScreenData::CDeleteScreenData(const int iHELP_ID, const char* iDESC_ID) : CConfigData(dtDeleteScreen, iHELP_ID,
		iDESC_ID, true) {
}
//****************************************************************************
// ~CDeleteScreenData(void)
///
/// Destructor
///
//****************************************************************************
CDeleteScreenData::~CDeleteScreenData() {
}
//****************************************************************************
// const QString   GetDataAsString( ) const
///
/// Method called to get the data as a string
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string - not used for this item
///
/// @return	The data as a string
///
//****************************************************************************
const QString CDeleteScreenData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	strData = QWidget::tr("Delete Screen");
	return strData;
}
//****************************************************************************
// void UpdateData( CConfigInterface *pkThisItem )
///
/// Method that updates the data e.g. a new screen is added to the layout 
///
//****************************************************************************
const bool CDeleteScreenData::UpdateData() {
	bool bUpdated = false;
    //COpPanel *pkOpPanel = static_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
    //QString strScreenList(pkOpPanel->GetScreenList(true));
	USHORT usSelScreen = 0;
    //CShortBitFieldData *pkScreenListData = new CShortBitFieldData(&usSelScreen, 8, 0, strScreenList, bfeSingleSelList,
            //0, 0, false);
    ////CCfgBitFieldEditDlg kDlg(pkScreenListData, pkOpPanel, L"EditLayout", L"DeleteScreen");
    // (kDlg.exec() == IDOK) {
		// the user selected a screen - we must now delete this screen from the modifiable config
    //	pkOpPanel->SendMessage(WM_DELETE_SCREEN, usSelScreen, 0);
		bUpdated = true;
    //}
    //delete pkScreenListData;
	return bUpdated;
}

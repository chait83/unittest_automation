/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  LinearisationData.cpp
/// @n Description: Implementation for the CLinearisationData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 4:58:21 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:38:26 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:27 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:03:13 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "LinearisationData.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
// CLinearisationData( T_LOOKUPTABLE *ptTable,
//						const USHORT usMAX_NO_OF_ELEMENTS )
///
/// Constructor
///
/// @param[in/out] 		T_LOOKUPTABLE *ptTable - Pointer ot the table data we want to modify/view	
///
//****************************************************************************
CLinearisationData::CLinearisationData(T_LOOKUPTABLE *ptTable) : CConfigData(dtLinearisationTable, 0, 0, false), m_ptLinearisationTable(
		ptTable) {
}
//****************************************************************************
// ~CLinearisationData( )
///
/// Destructor
///
//****************************************************************************
CLinearisationData::~CLinearisationData() {
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS )
///
/// Method that returns the data as a string
///
/// @return		A string containing the data
///
//****************************************************************************
const QString CLinearisationData::GetDataAsString(const bool bINCLUDE_UNITS) {
	QString strTitle("");
    strTitle = QString::asprintf("%u Points", m_ptLinearisationTable->ElementCount);
	return strTitle;
}
//****************************************************************************
// const bool ValidateData(	const T_PLOOKUPTABLE ptNEW_TABLE_DATA,
//								USHORT &rusFailedValueZeroBased )
///
/// Method called to validate data entered by the user
///
/// @param[in]		const T_PLOOKUPTABLE ptNEW_TABLE_DATA - The new linearisation data thast we need
///					to validate
/// @param[out]		USHORT &rusFailedValueZeroBased - The value that has failed, zero based
///
/// @return		True if the data validated okay
///
//****************************************************************************
const bool CLinearisationData::ValidateData(const T_PLOOKUPTABLE ptNEW_TABLE_DATA, USHORT &rusFailedValueZeroBased) {
	bool bOK = true;
	// check there are a minimum of 2 elements defined
	if (ptNEW_TABLE_DATA->ElementCount >= 2) {
		// run through the table checking for dog legs - firstly check which way we are
		// going
		bool bAscending = false;
		if (ptNEW_TABLE_DATA->LookupEntry[0].in < ptNEW_TABLE_DATA->LookupEntry[1].in) {
			// the X values are in ascending order
			bAscending = true;
		} else {
			// the X values are in descending order
			bAscending = false;
		}
		// loop through all the values checking if they are valid - don't check the first value as it can
		// only be checked against the next reading
		for (USHORT usCount = 1; usCount < ptNEW_TABLE_DATA->ElementCount; usCount++) {
			// check based on the ascending flag
			if (bAscending) {
				// the current must be greater than the previous
				if (ptNEW_TABLE_DATA->LookupEntry[usCount].in <= ptNEW_TABLE_DATA->LookupEntry[usCount - 1].in) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			} else {
				// the current must be less than the previous
				if (ptNEW_TABLE_DATA->LookupEntry[usCount].in >= ptNEW_TABLE_DATA->LookupEntry[usCount - 1].in) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			}
		}
	} else {
		// there are less than two elements defined therefore this is a failure - set the return value
		// to zero which will imply there are not enough elements (as the other checks cannot set values
		// of less than 1)
		rusFailedValueZeroBased = 0;
		bOK = false;
	}
	return bOK;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Automated Operations
/// @n Filename:  AutoOpRequestInfo.h
/// @n Description: AutoOpRequestInfo class declaration.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:55:32 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:27:46 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 8/2/2006 2:11:29 PM Charles Boardman
//  Adding support for ConnectionSpeed in the request and the XML handler
//  for requests.
//  4 V6 Firmware 1.3 8/1/2006 8:51:11 PM Roger Dawson  
//  Replaced QVector< QString   , QString   & > with a typedef called
//  CAutoOpStringArray. Also modified the second parameter to be a
//  QString   rather than a reference copy. This allowed const QString   
//  objects to be passed to various AutoOp methods.
// $
//
// **************************************************************************
#pragma once
#if ! defined ( __AUTOOPREQUESTINFO_H__ )
#define __AUTOOPREQUESTINFO_H__
// AutoOpInfo
#include "AutoOpInfo.h"
// Enumerated type for identifying the connection speed.
typedef enum tagAutoOpConnectionSpeed {
	AUTOOPCONSPEED_NotSupportedFirstInList = 0,
	AUTOOPCONSPEED_Fast = 1, AUTOOPCONSPEED_Medium = 2, AUTOOPCONSPEED_Slow = 3,
	// NEXT AVAILABLE ENUM IS 4. PLEASE UPDATE ME AS YO ADD ENUMS AND DO NOT 
	// REUSE NUMBERS BELONGING TO DELETED ENUMS OR ANYTHING LIKE THAT.
	AUTOOPCONSPEED_NotSupportLastInList = 4
} T_AutoOpConnectionSpeed;
//** AutoOpRequestInfo *******************************************************
///
/// @brief Describes a request for an operation. It extends AutoOpInfo.
/// 
/// AutoOpRequestInfo extends AutoOpInfo and is used to encapsulate the data 
/// for an operation being requested.
///
//****************************************************************************
class AutoOpRequestInfo: public AutoOpInfo {
public:
	//-------- Construction / Destruction --------
	AutoOpRequestInfo();
	AutoOpRequestInfo(const AutoOpRequestInfo &aRequest);
	AutoOpRequestInfo(const AutoOpInfo &anOp);
	AutoOpRequestInfo(T_AutoOp anOp, T_AutoOpConnectionSpeed conSpeed = AUTOOPCONSPEED_Fast);
	virtual ~AutoOpRequestInfo(void);
	// Assignment operator
	AutoOpRequestInfo& operator=(const AutoOpRequestInfo &rhs);
public:
	//-------- Public methods --------
	// Add name/value pairs.
	virtual BOOL AddTagValuePair(const QString &strTag, const QString &strValue);
	// Get / Set the connection speed.
	T_AutoOpConnectionSpeed GetConnectionSpeed(void) const;
	BOOL SetConnectionSpeed(T_AutoOpConnectionSpeed connectionSpeed);
protected:
	//-------- Protected methods --------
	//-------- Protected data members --------
private:
	//-------- Private constants --------
	static const QString StrTagNameConnectionSpeed;
	//-------- Private methods --------
	//-------- Private data members --------
	// Connection speed - will help recorder decide timeout values.
	T_AutoOpConnectionSpeed m_ConnectionSpeed;
};
#endif // __AUTOOPREQUESTINFO_H__

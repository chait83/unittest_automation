/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Automated Operations
/// @n Filename:  CeAutoOpsXMLHandler.cpp
/// @n Description: Implementation for the CCeAutoOpsXMLHandler class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Aristos  1.6.1.3.1.0 9/19/2011 4:51:07 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  11  Stability Project 1.6.1.3 7/2/2011 4:55:56 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  10  Stability Project 1.6.1.2 7/1/2011 4:38:02 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  9 Stability Project 1.6.1.1 3/17/2011 3:20:13 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#if defined ( UNICODE )
#include "StringUtils.h"
#endif
#include "CStorage.h"
#include "CeAutoOpsXMLHandler.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
// Constant definitions
const QString CCeAutoOpsXMLHandler::ms_strRootTagRequests("XSeriesAutoOpRequests");
const QString CCeAutoOpsXMLHandler::ms_strRootTagResponses("XSeriesAutoOpResponses");
const QString CCeAutoOpsXMLHandler::ms_strTagRequest("Request");
const QString CCeAutoOpsXMLHandler::ms_strTagResponse("Response");
const QString CCeAutoOpsXMLHandler::ms_strTagIPAddress("IPAddress");
const QString CCeAutoOpsXMLHandler::ms_strTagNetBIOSName("NetBIOSName");
const QString CCeAutoOpsXMLHandler::ms_strTagOperation("Operation");
const QString CCeAutoOpsXMLHandler::ms_strTagConnectionSpeed("ConnectionSpeed");
const QString CCeAutoOpsXMLHandler::ms_strTagIterationCount("IterationCount");
const QString CCeAutoOpsXMLHandler::ms_strTagIterationStatus("IterationStatus");
const QString CCeAutoOpsXMLHandler::ms_strTagFilesToCopy("FilesToCopy");
const QString CCeAutoOpsXMLHandler::ms_strTagOverallStatus("OverallStatus");
const QString CCeAutoOpsXMLHandler::ms_strAttributeID("ID");
//****************************************************************************
// CCeAutoOpsXMLHandler(	const QString   &rstrDIRECTORY_NAME,
//							const QString   &rstrFILE_NAME )
///
/// Constructor
///
///	@param[in]		const QString   &rstrDIRECTORY_NAME - The directory name of the XML file		
///	@param[in]		const QString   &rstrFILE_NAME - The name of the XML file
///
//****************************************************************************
CCeAutoOpsXMLHandler::CCeAutoOpsXMLHandler(const QString &rstrDIRECTORY_NAME, const QString &rstrFILE_NAME)
#ifdef UNICODE
:	CStorage(),
#else
: QFile(),
#endif
		m_strDirectoryPath(rstrDIRECTORY_NAME), m_strFilename(rstrFILE_NAME), m_strXMLData("") {
}
//****************************************************************************
// ~CCeAutoOpsXMLHandler()
///
/// Destructor
///
//****************************************************************************
CCeAutoOpsXMLHandler::~CCeAutoOpsXMLHandler() {
}
//****************************************************************************
// const T_AUTO_OPS_XML_FILE_STATUS WriteOperation( const AutoOpResponseInfo &rkRESPONSE_INFO )
///
/// Method that writes a response file based on the passed in response class parameters
///
/// @param[in]		const AutoOpResponseInfo &rkRESPONSE_INFO - The reponse info class whose information
///					we wish to put into a file
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::WriteOperation(
		const AutoOpResponseInfo &rkRESPONSE_INFO) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strCompleteFilename(m_strDirectoryPath + m_strFilename);
	// open the file with the correct write privelages
	this->setFileName(strCompleteFilename);
	if (open(QFile::Append | QFile::ReadWrite)) {
		// there has been a problem so log the error
//		ShowError(kFileEx);
		eRetVal = aoxCOULD_NOT_OPEN_FILE;
	} else {
		// opened the file successfully, read the current contents into the internal
		// storage string and check the opening headers exist
		eRetVal = LoadXML();
		if ((eRetVal == aoxOK) || (eRetVal == aoxINVALID_FILE_LENGTH)) {
			// check if the file length was invalid in which case we need
			// to add the opening tags
			if (eRetVal == aoxINVALID_FILE_LENGTH) {
				m_strXMLData = "<?xml version=\"1.0\" ?>\n";
				m_strXMLData += "<" + ms_strRootTagResponses + ">\n";
				m_strXMLData += "</" + ms_strRootTagResponses + ">\n";
			} else if (m_strXMLData.size() > 5000) {
				// the file size is getting too large - delete some of the older operations
				RemoveOldOperations(ms_strRootTagResponses, ms_strTagResponse);
			}
			// now add/insert the new response information
			eRetVal = InsertResponseInfo(rkRESPONSE_INFO, m_strXMLData);
			// check the data was inserted okay and then overwrite the file and close it
			if (eRetVal == aoxOK) {
				eRetVal = WriteXML();
			}
		}
		// always close the file
		close();
	}
	return eRetVal;
}
//****************************************************************************
// const T_AUTO_OPS_XML_FILE_STATUS WriteOperation( const AutoOpRequestInfo &rkREQUEST_INFO )
///
/// Method that writes a request file based on the passed in request class parameters
///
/// @param[in]		const AutoOpRequestInfo &rkREQUEST_INFO - The request info class whose information
///					we wish to put into a file
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::WriteOperation(
		const AutoOpRequestInfo &rkREQUEST_INFO) {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strCompleteFilename(m_strDirectoryPath + m_strFilename);
	this->setFileName(strCompleteFilename);
	// open the file with the correct write privelages
	if (!open(QFile::Append | QFile::ReadWrite)) {
		// there has been a problem so log the error
//		ShowError(kFileEx);
		eRetVal = aoxCOULD_NOT_OPEN_FILE;
	} else {
		// opened the file successfully, read the current contents into the internal
		// storage string and check the opening headers exist
		eRetVal = LoadXML();
		if ((eRetVal == aoxOK) || (eRetVal == aoxINVALID_FILE_LENGTH)) {
			// check if the file length was invalid in which case we need
			// to add the opening tags
			if (eRetVal == aoxINVALID_FILE_LENGTH) {
				m_strXMLData = "<?xml version=\"1.0\" ?>\n";
				m_strXMLData += "<" + ms_strRootTagRequests + ">\n";
				m_strXMLData += "</" + ms_strRootTagRequests + ">\n";
			} else if (m_strXMLData.size() > 5000) {
				// the file size is getting too large - delete some of the older operations
				RemoveOldOperations(ms_strRootTagRequests, ms_strTagRequest);
			}
			// now add/insert the new response information
			eRetVal = InsertRequestInfo(rkREQUEST_INFO, m_strXMLData);
			// check the data was inserted okay and then overwrite the file and close it
			if (eRetVal == aoxOK) {
				eRetVal = WriteXML();
			}
		}
		// always close the file
		close();
	}
	return eRetVal;
}
//****************************************************************************
// const T_AUTO_OPS_XML_FILE_STATUS RemoveOldOperations(	const QString   &rstrTAG_TO_FIND,
//								const QString   &rstrCURR_OP_ID )
///
/// Method that removes any old operations from the current XML file
///
/// @param[in]		const QString   &rstrPARENT_TAG - The main parent tag for this file
/// @param[in]		const QString   &rstrTAG_TO_FIND - The tag to look for (will be a response 
///					or request tag)
///
/// @return			aoxOK if everything was okay, else an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::RemoveOldOperations(
		const QString &rstrPARENT_TAG, const QString &rstrTAG_TO_FIND) {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	// get the end of the initial node. Will be -1 if not 
	// found so we won't try to be clever and adjust it to
	// make any string searches marginally quicker.
	long lSTART_NODE_POS = indexOfTagInfo(m_strXMLData, rstrPARENT_TAG, 0);
	// get the number of operations within this file - divide the result by two as we will be getting the start and
	// end tags for each operation
#if defined ( UNICODE )
	USHORT usInstances = CStringUtils::InstanceOfStr( m_strXMLData, rstrTAG_TO_FIND ) / 2;
#else
	USHORT usInstances = 0;
#endif
	// loop through looking deleting the beginning responses as long as there are more than 3 within the file
	while (usInstances > 3) {
		// check the node was found okay
		if (lSTART_NODE_POS != -1) {
			long lNODE_START_POS = indexOfTagInfo(m_strXMLData, rstrTAG_TO_FIND, lSTART_NODE_POS);
			long lNODE_END_POS = indexOfTagInfo(m_strXMLData, rstrTAG_TO_FIND, lSTART_NODE_POS + rstrTAG_TO_FIND.size(),
					false);
			// check the response start and end nodes were found okay
			if ((lNODE_START_POS != -1) && (lNODE_END_POS != -1)) {
				// delete this item
				m_strXMLData.remove(lNODE_START_POS - 1, (lNODE_END_POS + 2) - (lNODE_START_POS - 1));
			} else {
				eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
				break;
			}
		} else {
			eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
			break;
		}
		// removed an operation so decrement the number of instances remaining
		--usInstances;
	}
	return eRetVal;
}
//****************************************************************************
// BOOL ReadOperation( AutoOpRequestInfo &rkRequestInfo )
///
/// Method that reads a request within a request file and populates the passed
/// in request class accordingly
///
/// @param[out]		AutoOpRequestInfo &rkRequestInfo - The request info structure we wish to
///					populate with the information stored within the request file
///
//****************************************************************************
BOOL CCeAutoOpsXMLHandler::ReadOperation(AutoOpRequestInfo &rkRequestInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strCompleteFilename(m_strDirectoryPath + m_strFilename);
	/// TODO: Rewrite this code.
	CFileStatus tFileStatus;
	// check the file exists by checking it's status is okay
	if (CStorage::GetStatus(strCompleteFilename, &tFileStatus)) {
		// check the file is okay to read first
		CFileStatus kFileStatus;
		if (CStorage::GetStatus(strCompleteFilename, &kFileStatus)) {
			// open the file but only with read privelages
			this->setFileName(strCompleteFilename);
			if (!open(QFile::Append | QFile::ReadOnly)) {
				// there has been a problem so log the error
//				ShowError(kFileEx);
				eRetVal = aoxCOULD_NOT_OPEN_FILE;
			} else {
				// load the XML data into the internal storage string
				if ((eRetVal = LoadXML()) == aoxOK) {
					// get the end of the initial node
					const long lSTART_NODE_POS = indexOfTagInfo(m_strXMLData, ms_strRootTagRequests, 0);
					// check the node was found okay
					if (lSTART_NODE_POS != -1) {
						long lREQUEST_NODE_START_POS = indexOfTagInfo(m_strXMLData, ms_strTagRequest,
								lSTART_NODE_POS + ms_strRootTagRequests.size());
						long lREQUEST_NODE_END_POS = indexOfTagInfo(m_strXMLData, ms_strTagRequest,
								lSTART_NODE_POS + ms_strRootTagRequests.size(), false);
						// check the request start and end nodes were found okay
						if ((lREQUEST_NODE_START_POS != -1) && (lREQUEST_NODE_END_POS != -1)) {
							// we now have the start of the request so pass it on for further
							// extraction
							ExtractRequestInfo(rkRequestInfo,
									m_strXMLData.mid(lREQUEST_NODE_START_POS,
											lREQUEST_NODE_END_POS - lREQUEST_NODE_START_POS));
						} else {
							eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
						}
					} else {
						eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
					}
				}
				// close the file now
				close();
			}
		} else {
			eRetVal = aoxFILE_LOCKED;
		}
	} else {
		eRetVal = aoxFILE_DOES_NOT_EXIST;
	}
	return (eRetVal == aoxOK);
}
//****************************************************************************
// BOOL ReadOperation(	AutoOpResponseInfo &rkResponseInfo, const QString   &rstrID /* = QString   ::fromWCharArray("") */ )
///
/// Method that reads a response within a response file and populates the passed in response
/// class accordingly
///
/// @param[out]		const AutoOpResponseInfo &responseInfo - The response info structure we wish to
///					populate with the information stored within the response file
/// @param[in]		const QString   &rstrID - The ID of the response we are looking for - an empty string means
///					get the first item
///
///	@return			True if the operation was found okay
///
//****************************************************************************
BOOL CCeAutoOpsXMLHandler::ReadOperation(AutoOpResponseInfo &rkResponseInfo,
		const QString &rstrID /* = QString   ::fromWCharArray("") */) {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strCompleteFilename(m_strDirectoryPath + m_strFilename);
	CFileStatus tFileStatus;
	// check the file exists by checking it's status is okay
	if (CStorage::GetStatus(strCompleteFilename, &tFileStatus)) {
		// check the file is okay to read first
		CFileStatus kFileStatus;
		if (CStorage::GetStatus(strCompleteFilename, &kFileStatus)) {
			// open the file but only with read privelages
			this->setFileName(strCompleteFilename);
			if (!open(QFile::Append | QFile::ReadOnly)) {
				// there has been a problem so log the error
//				ShowError(kFileEx);
				eRetVal = aoxCOULD_NOT_OPEN_FILE;
			} else {
				// load the XML data into the internal storage string
				if ((eRetVal = LoadXML()) == aoxOK) {
					bool bFoundRequest = false;
					// get the end of the initial node. Will be -1 if not 
					// found so we won't try to be clever and adjust it to
					// make any string searches marginally quicker.
					long lSTART_NODE_POS = indexOfTagInfo(m_strXMLData, ms_strRootTagResponses, 0);
					// loop through looking for either the first response or a response with a specific ID
					while (!bFoundRequest) {
						// check the node was found okay
						if (lSTART_NODE_POS != -1) {
							long lRESPONSE_NODE_START_POS = indexOfTagInfo(m_strXMLData, ms_strTagResponse,
									lSTART_NODE_POS);
							long lRESPONSE_NODE_END_POS = indexOfTagInfo(m_strXMLData, ms_strTagResponse,
									lSTART_NODE_POS + ms_strTagResponse.size(), false);
							// check the response start and end nodes were found okay
							if ((lRESPONSE_NODE_START_POS != -1) && (lRESPONSE_NODE_END_POS != -1)) {
								// we now have the start of the response so pass it on for further
								// extraction
								ExtractResponseInfo(rkResponseInfo,
										m_strXMLData.mid(lRESPONSE_NODE_START_POS,
												lRESPONSE_NODE_END_POS - lRESPONSE_NODE_START_POS));
								// check if we can stop looking
								if ((rstrID == "") || (rstrID == rkResponseInfo.GetID())) {
									bFoundRequest = true;
								} else {
									// Unrecognised response, move on the start position to look again.
									lSTART_NODE_POS = lRESPONSE_NODE_END_POS;
								}
							} else {
								eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
#if defined ( UNICODE )
								// Make this DebugBreak() conditional on being 
								// under a CE build because in TMP if a response
								// file is fetched before the recorder has a
								// chance to update it, then this condition can
								// be hit quite often.
#endif
								break;
							}
						} else {
							eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
							break;
						}
					}
					// check if something was found
					if (!bFoundRequest && (eRetVal == aoxOK)) {
						eRetVal = aoxCOULD_NOT_FIND_OP_ID;
					}
				}
				// close the file now
				close();
			}
		} else {
			eRetVal = aoxFILE_LOCKED;
		}
	} else {
		eRetVal = aoxFILE_DOES_NOT_EXIST;
	}
	return (eRetVal == aoxOK);
}
//****************************************************************************
// const T_AUTO_OPS_XML_FILE_STATUS DeleteOperation( const QString   &rstrID )
///
/// Method that deletes a response/request operation from the response/request file
///
/// @param[in]		const QString   &rstrID - The ID of the reponse we want deleted
/// @param[in]		const bool bREQUEST - Flag indicating if this is a response or request file
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::DeleteOperation(const QString &rstrID,
		const bool bREQUEST) {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strCompleteFilename(m_strDirectoryPath + m_strFilename);
	this->setFileName(strCompleteFilename);
	// open the file with the correct write privelages
	if (!open(QFile::Append | QFile::ReadWrite)) {
		// there has been a problem so log the error
//		ShowError(kFileEx);
		eRetVal = aoxCOULD_NOT_OPEN_FILE;
	} else {
		// opened the file successfully, read the current contents into the internal
		// storage string and check the opening headers exist
		eRetVal = LoadXML();
		if ((eRetVal == aoxOK) || (eRetVal == aoxINVALID_FILE_LENGTH)) {
			// check if the file length was invalid in which case we need
			// to add the opening tags
			if (eRetVal == aoxINVALID_FILE_LENGTH) {
				m_strXMLData = "<?xml version=\"1.0\" ?>\n";
				m_strXMLData += "<" + bREQUEST ? ms_strRootTagRequests : ms_strRootTagResponses + ">\n";
				m_strXMLData += "</" + bREQUEST ? ms_strRootTagRequests : ms_strRootTagResponses + ">\n";
			}
			// now delete the specified response information
			eRetVal = DeleteInfo(rstrID, m_strXMLData, bREQUEST);
			// check the data was deleted okay and then overwrite the file and close it
			if (eRetVal == aoxOK) {
				eRetVal = WriteXML();
			}
		}
		// always close the file
		close();
	}
	return eRetVal;
}
//****************************************************************************
//	void ShowError( QFileDevice::FileError &kEx )
///
/// Method that shows file exception errors
///
/// @param[in]		QFileDevice::FileError &kEx - The file exception generated
///
//****************************************************************************
void CCeAutoOpsXMLHandler::ShowError(QFileDevice::FileError &kEx) {
#if defined ( UNICODE )
	if( V6_RELEASE != RELEASE_PRODUCTION )
	{
		size_t pNoOfChars;
		WCHAR wcaError[ 100 ];
		kEx.GetErrorMessage( wcaError, 100 );
		char pcError[100];
		memset( pcError, 0, 100 );
		wcstombs_s(&pNoOfChars, pcError,100, wcaError, 99 );
		LOG_ERR( TRACE_AUTO_OPS, "%s", pcError );
	}
#else
    QString tError;
    tError = CStorage::GetErrorMessage(kEx);
	QString strMsg;
    strMsg =  tError +"\n";
	qDebug() << strMsg;
#endif
}
//****************************************************************************
//	const long indexOfTagInfo(	const QString   &rstrDATA_TO_SEARCH,
//							const QString   &rstrSEARCH_TAG, 
//							const long lSEEK_POS,
//							const bool bSTART_TAG /* = true */ ) const
///
/// Method that finds the position of the passed in XML tag within the pased in data
///
/// @param[in]		const QString   &rstrDATA_TO_SEARCH - The XML data to search through
/// @param[in]		const QString   &rstrREQUIRED_NODE - The XML tag we are looking for
/// @param[in]		const long lSEEK_POS - Flag indicating where we want to search from
///	@param[in]		const bool bSTART_TAG - Flag indicating if we want to search for
///					the begining tag or end tag
///
/// @return		The start position of the passed in tag, -1 if not found
///
//****************************************************************************
const long CCeAutoOpsXMLHandler::indexOfTagInfo(const QString &rstrDATA_TO_SEARCH, const QString &rstrSEARCH_TAG,
		const long lSEEK_POS, const bool bSTART_TAG /* = true */) const {
	// put the appropriate XML delimitters around the text
	QString strCompleteSearchTag("");
	long lTagPos = 0;
	if (bSTART_TAG) {
		strCompleteSearchTag = "<" + rstrSEARCH_TAG;
		lTagPos = static_cast<long>(rstrDATA_TO_SEARCH.indexOf(strCompleteSearchTag, lSEEK_POS));
	} else {
		strCompleteSearchTag = "</" + rstrSEARCH_TAG + ">";
		lTagPos = static_cast<long>(rstrDATA_TO_SEARCH.indexOf(strCompleteSearchTag, lSEEK_POS));
		// check something was found
		if (lTagPos != -1) {
			// add the length of the string to the end so we get the end of the XML
			lTagPos += strCompleteSearchTag.size();
		}
	}
	return lTagPos;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS LoadXML( )
///
/// Method that loads the entire contents of the XML file
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::LoadXML() {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	// get the file length in WCHAR's plus add one for a NULL terminator
	const qint64 lFILE_LENGTH = size();
	// check the length was valid
	if ((lFILE_LENGTH > 0) && (lFILE_LENGTH < static_cast<long>(0x0000FFFF))) {
		// seek back to the begining of the file
		seek(0);
		QByteArray pcXMLDataToLoad = read(lFILE_LENGTH);
		m_strXMLData = QString::fromLocal8Bit(pcXMLDataToLoad);
	} else {
		// the file was too short or too long
		eRetVal = aoxINVALID_FILE_LENGTH;
	}
	return eRetVal;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS WriteXML( )
///
/// Method that writes the entire contents of the XML file
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::WriteXML() {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	// the file should exist and be open already - therefore we are going
	// to overwrite ALL the existing data with the new information (as it is simpler)
	seek(0);
#if defined ( UNICODE )
	size_t pNoOfChars;
	wcstombs_s( &pNoOfChars,pcWriteBuffer, iBUFFER_LENGTH + 1, m_strXMLData.GetBuffer( 0 ), iBUFFER_LENGTH );
	const DWORD dwRetVal = Write(	reinterpret_cast< void* >( pcWriteBuffer ), 
									iBUFFER_LENGTH );
#else
	DWORD dwRetVal = ERROR_SUCCESS;
	if (write(m_strXMLData.toLocal8Bit().data(), m_strXMLData.length()) == -1) {
		// Raised an exception so report the cause
		qDebug("Write Error");
		eRetVal = aoxCOULD_NOT_WRITE_FILE;
	}
#endif
	// check the operation was okay
	if (dwRetVal != ERROR_SUCCESS) {
		// failed therefore set the couldn't write file error
		eRetVal = aoxCOULD_NOT_WRITE_FILE;
	}
	return eRetVal;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS ExtractRequestInfo(	AutoOpRequestInfo &rkRequestInfo,
//															const QString   &rstrREQUEST_INFO )
///
/// Method that extract the request information contained within the passed in positions
///
/// @param[out]		AutoOpRequestInfo &rkRequestInfo - The request info structure to populate
/// @param[in]		const QString   &rstrREQUEST_INFO - String containing the request information
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::ExtractRequestInfo(
		AutoOpRequestInfo &rkRequestInfo, const QString &rstrREQUEST_INFO) const {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strData("");
	// Try to get the connection speed.
	if ((eRetVal == aoxOK) && (aoxOK == (eRetVal = GetTagValue(ms_strTagConnectionSpeed, strData, rstrREQUEST_INFO)))) {
		rkRequestInfo.AddTagValuePair(ms_strTagConnectionSpeed, strData);
	}
	// If connection speed was extracted okay do all the other basic stuff.
	if (eRetVal == aoxOK) {
		eRetVal = ExtractBaseInfo(rkRequestInfo, rstrREQUEST_INFO);
	}
	return eRetVal;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS ExtractResponseInfo(	AutoOpResponseInfo &rkBaseInfo,
//															const QString   &rstrRESPONSE_INFO )
///
/// Method that extract the response information contained within the passed in positions
///
/// @param[out]		AutoOpResponseInfo &rkResponseInfo - The response info structure to populate
/// @param[in]		const QString   &rstrRESPONSE_INFO - String containing the response information
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::ExtractResponseInfo(
		AutoOpResponseInfo &rkResponseInfo, const QString &rstrRESPONSE_INFO) const {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strData("");
	// Get the iteration status (not really used with the initial 
	// implementation but technically is required field in a response).
	if ((eRetVal == aoxOK)
			&& (aoxOK == (eRetVal = GetTagValue(ms_strTagIterationStatus, strData, rstrRESPONSE_INFO)))) {
		rkResponseInfo.AddTagValuePair(ms_strTagIterationStatus, strData);
	}
	// Get the overall status. This is a required field in a response.
	if ((eRetVal == aoxOK) && (aoxOK == (eRetVal = GetTagValue(ms_strTagOverallStatus, strData, rstrRESPONSE_INFO)))) {
		rkResponseInfo.AddTagValuePair(ms_strTagOverallStatus, strData);
	}
	// Get the file count. This is an optional field in a response.
	if ((eRetVal == aoxOK) && (aoxOK == GetTagValue(ms_strTagFilesToCopy, strData, rstrRESPONSE_INFO))) {
		rkResponseInfo.AddTagValuePair(ms_strTagFilesToCopy, strData);
	}
	// If iteration status and overall status have been extracted then go and
	// extract all the other basic info.
	if (eRetVal == aoxOK) {
		eRetVal = ExtractBaseInfo(rkResponseInfo, rstrRESPONSE_INFO);
	}
	return eRetVal;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS ExtractBaseInfo(	AutoOpInfo &rkBaseInfo,
//														const QString   &rstrOPERATION_INFO )
///
/// Method that extract the operation information contained within the passed in positions
///
/// @param[out]		AutoOpRequestInfo &rkRequestInfo - The base info structure to populate
/// @param[in]		const QString   &rstrOPERATION_INFO - String containing the operation information
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::ExtractBaseInfo(AutoOpInfo &rkBaseInfo,
		const QString &rstrOPERATION_INFO) const {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	QString strData("");
	// now we need to search for each individal tag and extract the information within each
	// Get the ID first
	if ((eRetVal == aoxOK) && (aoxOK == (eRetVal = GetTagValue(ms_strAttributeID, strData, rstrOPERATION_INFO)))) {
		rkBaseInfo.AddTagValuePair(ms_strAttributeID, strData);
	}
	// now get the operation
	if ((eRetVal == aoxOK) && (aoxOK == (eRetVal = GetTagValue(ms_strTagOperation, strData, rstrOPERATION_INFO)))) {
		rkBaseInfo.AddTagValuePair(ms_strTagOperation, strData);
	}
	// Get the iteration count
	if ((eRetVal == aoxOK)
			&& (aoxOK == (eRetVal = GetTagValue(ms_strTagIterationCount, strData, rstrOPERATION_INFO)))) {
		rkBaseInfo.AddTagValuePair(ms_strTagIterationCount, strData);
	}
	// Get the IP address
	if ((eRetVal == aoxOK) && (aoxOK == (eRetVal = GetTagValue(ms_strTagIPAddress, strData, rstrOPERATION_INFO)))) {
		rkBaseInfo.AddTagValuePair(ms_strTagIPAddress, strData);
	}
	// Get the Net BIOS name.
	if ((eRetVal == aoxOK) && (aoxOK == (eRetVal = GetTagValue(ms_strTagNetBIOSName, strData, rstrOPERATION_INFO)))) {
		rkBaseInfo.AddTagValuePair(ms_strTagNetBIOSName, strData);
	}
	return eRetVal;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS GetTagValue(	const QString   &rstrTAG,
//													QString   &rstrValue,
//													const QString   &rstrXML_DATA ) const
///
/// Method that extracts the ID information contained within the passed in string
///
/// @param[in]		const QString   &rstrTAG - The tag to find
///	@param[out]		QString   &rstrValue - The value reposented by the passed in tag
/// @param[in]		const QString   strXML_DATA - String containing the XML information
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::GetTagValue(const QString &rstrTAG,
		QString &rstrValue, const QString &rstrXML_DATA) const {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	long lStartPos = indexOfTagInfo(rstrXML_DATA, rstrTAG, 0, true);
	long lEndPos = indexOfTagInfo(rstrXML_DATA, rstrTAG, 0, false);
	if ((lStartPos != -1) && (lEndPos != -1)) {
		// extract the string
		QString strTagItem = rstrXML_DATA.mid(lStartPos, lEndPos - lStartPos);
		// we have the tag item - now extract the data embedded between the > and < which
		// is the tag value
		int iStartOfTagVal = strTagItem.indexOf('>', 0);
		if (iStartOfTagVal != -1) {
			// the opening '>' exists, now look for the '<'
			int iEndOfTagVal = strTagItem.indexOf('<', iStartOfTagVal);
			// check the end value exists
			if (iEndOfTagVal != -1) {
				// increment the start pos so we don't get the > and <
				++iStartOfTagVal;
				rstrValue = strTagItem.mid(iStartOfTagVal, iEndOfTagVal - iStartOfTagVal);
			} else {
				eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
			}
		} else {
			eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
		}
	} else {
		eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
	}
	return eRetVal;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS InsertResponseInfo(	const AutoOpResponseInfo &rkRESPONSE_INFO,
//															QString &rstrResponseInfo )
///
/// Method that inserts the response information contained within the passed in response into the
/// XML data string
///
/// @param[in]		const AutoOpResponseInfo &rkRESPONSE_INFO - The request info structure to extract
///					information from
/// @param[in]		QString &rstrResponseInfo - String that we need to populate with the response information
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::InsertResponseInfo(
		const AutoOpResponseInfo &rkRESPONSE_INFO, QString &rstrResponseInfo) {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	// create an XML string with this reponse information
	QString strNewXMLResponse("");
	// add the response information
	AddResponseXMLInfo(rkRESPONSE_INFO, strNewXMLResponse);
	// now look for this response in the XML file already
	QString strRESPONSE_ID_TAG(
			"\t<" + ms_strTagResponse + " " + ms_strAttributeID + "=\"" + rkRESPONSE_INFO.GetID() + "\">\n");
	const int iRESP_ID_START_TAG_POS = rstrResponseInfo.indexOf(strRESPONSE_ID_TAG, 0);
	if (iRESP_ID_START_TAG_POS == -1) {
		// this reponse does not exist yet therefore insert at the end of the file (but before the
		// end of the main XML tag )
		const int iMAIN_TAG_END_POS = rstrResponseInfo.indexOf("</" + ms_strRootTagResponses + ">\n");
		// should always be found because of previous check but should cope with the situation anyway
		if (iMAIN_TAG_END_POS != -1) {
			rstrResponseInfo.insert(iMAIN_TAG_END_POS, strNewXMLResponse);
		} else {
			eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
		}
	} else {
		// this reponse exists already therefore replace it with the new response
		// we already have the start of the tag, no find the end
		QString strEND_TAG("</" + ms_strTagResponse + ">\n");
		int iRESP_ID_END_TAG_POS = rstrResponseInfo.indexOf(strEND_TAG, iRESP_ID_START_TAG_POS);
		// check it was found okay
		if (iRESP_ID_END_TAG_POS != -1) {
			/// TODO: resolve delete operation
			rstrResponseInfo.remove(iRESP_ID_START_TAG_POS,
					(iRESP_ID_END_TAG_POS - iRESP_ID_START_TAG_POS) + strEND_TAG.length());
			rstrResponseInfo.insert(iRESP_ID_START_TAG_POS, strNewXMLResponse);
		} else {
			eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
		}
	}
	return eRetVal;
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS InsertRequestInfo(	const AutoOpRequestInfo &rkREQUEST_INFO,
//														QString &rstrRequestInfo )
///
/// Method that inserts the response information contained within the passed in response into the
/// XML data string
///
/// @param[in]		const AutoOpRequestInfo &rkREQUEST_INFO - The request info structure to extract
///					information from
/// @param[in]		QString &rstrRequestInfo - String that we need to populate with the request information
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::InsertRequestInfo(
		const AutoOpRequestInfo &rkREQUEST_INFO, QString &rstrRequestInfo) {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	// create an XML string with this request information
	QString strNewXMLRequest("");
	// add the request information
	AddRequestXMLInfo(rkREQUEST_INFO, strNewXMLRequest);
	// now look for this request in the XML file already
	QString strREQUEST_ID_TAG(
			"\t<" + ms_strTagRequest + " " + ms_strAttributeID + "=\"" + rkREQUEST_INFO.GetID() + "\">\n");
	const int iREQ_ID_START_TAG_POS = rstrRequestInfo.indexOf(strREQUEST_ID_TAG, 0);
	if (iREQ_ID_START_TAG_POS == -1) {
		// this reponse does not exist yet therefore insert at the end of the file (but before the
		// end of the main XML tag )
		const int iMAIN_TAG_END_POS = rstrRequestInfo.indexOf("</" + ms_strRootTagRequests + ">\n");
		// should always be found because of previous check but should cope with the situation anyway
		if (iMAIN_TAG_END_POS != -1) {
			rstrRequestInfo.insert(iMAIN_TAG_END_POS, strNewXMLRequest);
		} else {
			eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
		}
	} else {
		// this request exists already therefore replace it with the new request
		// we already have the start of the tag, now find the end
		QString strEND_TAG("</" + ms_strTagRequest + ">\n");
		int iREQ_ID_END_TAG_POS = rstrRequestInfo.indexOf(strEND_TAG, iREQ_ID_START_TAG_POS);
		// check it was found okay
		if (iREQ_ID_END_TAG_POS != -1) {
			rstrRequestInfo.remove(iREQ_ID_START_TAG_POS,
					(iREQ_ID_END_TAG_POS - iREQ_ID_START_TAG_POS) + strEND_TAG.length());
			rstrRequestInfo.insert(iREQ_ID_START_TAG_POS, strNewXMLRequest);
		} else {
			eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
		}
	}
	return eRetVal;
}
//****************************************************************************
//	void AddBaseXMLInfo(	const AutoOpInfo &rkBASE_INFO,
//								QString &rstrOperationInfo ) const
///
/// Method that inserts the base information contained within the passed in class into an XML
/// data string
///
/// @param[in]		const AutoOpInfo &rkBASE_INFO - The base info structure to extract
///					information from
/// @param[in]		QString &rstrOperationInfo - String that we need to populate with the
///					base information
///
//****************************************************************************
void CCeAutoOpsXMLHandler::AddBaseXMLInfo(const AutoOpInfo &rkBASE_INFO, QString &rstrOperationInfo) const {
	QString strFormatItem("");
	// add the ID
	rstrOperationInfo += "\t\t<" + ms_strAttributeID + ">";
	rstrOperationInfo += rkBASE_INFO.GetID();
	rstrOperationInfo += "</" + ms_strAttributeID + ">\n";
	// add the operation
	rstrOperationInfo += "\t\t<" + ms_strTagOperation + ">";
	strFormatItem = QString::asprintf("%u", rkBASE_INFO.GetOperation());
	rstrOperationInfo += strFormatItem;
	rstrOperationInfo += "</" + ms_strTagOperation + ">\n";
	// add the iteration count
	rstrOperationInfo += "\t\t<" + ms_strTagIterationCount + ">";
	strFormatItem = QString::asprintf("%u", rkBASE_INFO.GetIterationCount());
	rstrOperationInfo += strFormatItem;
	rstrOperationInfo += "</" + ms_strTagIterationCount + ">\n";
	// add the IP address
	rstrOperationInfo += "\t\t<" + ms_strTagIPAddress + ">";
	rstrOperationInfo += rkBASE_INFO.GetIPAddress();
	rstrOperationInfo += "</" + ms_strTagIPAddress + ">\n";
	// add the NetBIOS name
	rstrOperationInfo += "\t\t<" + ms_strTagNetBIOSName + ">";
	rstrOperationInfo += rkBASE_INFO.GetNetBIOSName();
	rstrOperationInfo += "</" + ms_strTagNetBIOSName + ">\n";
}
//****************************************************************************
//	void AddResponseXMLInfo(	const AutoOpResponseInfo &rkRESPONSE_INFO,
//								QString &rstrResponseInfo ) const
///
/// Method that inserts the response information contained within the passed in class
///	into an XML data string
///
/// @param[in]		const AutoOpResponseInfo &rkRESPONSE_INFO - The response info structure
///					to extract information from
/// @param[in]		QString &rstrResponseInfo - String that we need to populate with the
///					response information
///
//****************************************************************************
void CCeAutoOpsXMLHandler::AddResponseXMLInfo(const AutoOpResponseInfo &rkRESPONSE_INFO,
		QString &rstrResponseInfo) const {
	QString strFormatItem("");
	// add the main response header tag
	rstrResponseInfo += "\t<" + ms_strTagResponse + " " + ms_strAttributeID + "=\"";
	rstrResponseInfo += rkRESPONSE_INFO.GetID() + "\">\n";
	// add the base information first
	AddBaseXMLInfo(rkRESPONSE_INFO, rstrResponseInfo);
	// add the iteration status
	rstrResponseInfo += "\t\t<" + ms_strTagIterationStatus + ">";
	strFormatItem = QString::asprintf("%u", rkRESPONSE_INFO.GetIterationStatus());
	rstrResponseInfo += strFormatItem;
	rstrResponseInfo += "</" + ms_strTagIterationStatus + ">\n";
	// add the overall status
	rstrResponseInfo += "\t\t<" + ms_strTagOverallStatus + ">";
	strFormatItem = QString::asprintf("%u", rkRESPONSE_INFO.GetOverallStatus());
	rstrResponseInfo += strFormatItem;
	rstrResponseInfo += "</" + ms_strTagOverallStatus + ">\n";
	// add the files to copy
	rstrResponseInfo += "\t\t<" + ms_strTagFilesToCopy + ">";
	strFormatItem = QString::asprintf("%u", rkRESPONSE_INFO.GetFilesToCopy());
	rstrResponseInfo += strFormatItem;
	rstrResponseInfo += "</" + ms_strTagFilesToCopy + ">\n";
	rstrResponseInfo += "\t</" + ms_strTagResponse + ">\n";
}
//****************************************************************************
//	void AddRequestXMLInfo(	const AutoOpRequestInfo &rkREQUEST_INFO,
//							QString &rstrRequestInfo ) const
///
/// Method that inserts the request information contained within the passed in class
///	into an XML data string
///
/// @param[in]		const AutoOpRequestInfo &rkREQUEST_INFO - The request info structure
///					to extract information from
/// @param[in]		QString &rstrRequestInfo - String that we need to populate with the
///					request information
///
//****************************************************************************
void CCeAutoOpsXMLHandler::AddRequestXMLInfo(const AutoOpRequestInfo &rkREQUEST_INFO, QString &rstrRequestInfo) const {
	QString strFormatItem("");
	// add the main request header tag
	rstrRequestInfo += "\t<" + ms_strTagRequest + " " + ms_strAttributeID + "=\"";
	rstrRequestInfo += rkREQUEST_INFO.GetID() + "\">\n";
	// add the base information first
	AddBaseXMLInfo(rkREQUEST_INFO, rstrRequestInfo);
	// add the connection speed
	rstrRequestInfo += "\t\t<" + ms_strTagConnectionSpeed + ">";
	strFormatItem = QString::asprintf("%u", rkREQUEST_INFO.GetConnectionSpeed());
	rstrRequestInfo += strFormatItem;
	rstrRequestInfo += "</" + ms_strTagConnectionSpeed + ">\n";
	rstrRequestInfo += "\t</" + ms_strTagRequest + ">\n";
}
//****************************************************************************
//	const T_AUTO_OPS_XML_FILE_STATUS DeleteInfo(	const QString &rstrID,
//													QString &rstrXMLData,
//													const bool bREQUEST )
///
/// Method that deletes the response/request information from the XML data that matches the passed in ID
///
/// @param[in]		const QString &rstrID - The operation ID to look for
/// @param[in]		QString &rstrXMLData - String that we need to remove the operation
///					information from
/// @param[in]		const bool bREQUEST - Flag indicating if this is a response or request file
///
/// @return		aoxOK is successful otherwise an error code
///
//****************************************************************************
const CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS CCeAutoOpsXMLHandler::DeleteInfo(const QString &rstrID,
		QString &rstrXMLData, const bool bREQUEST) {
	T_AUTO_OPS_XML_FILE_STATUS eRetVal = aoxOK;
	// now look for this response/request in the XML file already
	QString strRESPONSE_ID_TAG =
			"<" + bREQUEST ? ms_strTagRequest : ms_strTagResponse + " " + ms_strAttributeID + "=\"" + rstrID + "\">\n";
	const int iID_START_TAG_POS = rstrXMLData.indexOf(strRESPONSE_ID_TAG, 0);
	if (iID_START_TAG_POS != -1) {
		// the reponse/request exists therefore we can delete it
		// we already have the start of the tag, no find the end
		QString strEND_TAG("</" + bREQUEST ? ms_strTagRequest : ms_strTagResponse + ">\n");
		int iID_END_TAG_POS = rstrXMLData.indexOf(strEND_TAG, iID_START_TAG_POS);
		// check it was found okay
		if (iID_END_TAG_POS != -1) {
			rstrXMLData.remove(iID_START_TAG_POS, (iID_END_TAG_POS - iID_START_TAG_POS) + strEND_TAG.length());
		} else {
			eRetVal = aoxINCOMPLETE_OR_INVALID_XML_DATA;
		}
	} else {
		// couldn't find the response/request ID tag - shouldn't really happen but don't worry about for now
	}
	return eRetVal;
}

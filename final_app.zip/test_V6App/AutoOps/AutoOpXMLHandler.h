/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Automated Operations
/// @n Filename:	AutoOpXMLHandler.h
/// @n Description: AutoOpXMLHandler class declaration.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:55:34 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:27:46 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 8/2/2006 2:11:29 PM Charles Boardman
//  Adding support for ConnectionSpeed in the request and the XML handler
//  for requests.
//  3 V6 Firmware 1.2 7/19/2006 2:11:01 PM  Charles Boardman
//  Removing dependency on CStorage class. Enhancing the tidy up routine
//  so that it can be used to empty a file of operations. Extending API
//  for read/extract of responses so that it can use an existing
//  (request) operation to match against. It makes it easier to avoid
//  reading the wrong response from a file.
// $
//
// **************************************************************************

#ifndef  _AUTOOPXMLHANDLER_H_
#define _AUTOOPXMLHANDLER_H_

// AutoOpRequestInfo
#include "AutoOpRequestInfo.h"
// AutoOpResponseInfo
#include "AutoOpResponseInfo.h"
//** AutoOpXMLHandler ********************************************************
///
/// @brief AutoOpXMLHandler handles all XML read/write for automated operations.
/// 
/// AutoOpXMLHandler has the responsibility for handling all aspects of 
/// reading and writing XML for the automated operations.
///
//****************************************************************************
class AutoOpXMLHandler {
public:
	//--------Construction / Destruction --------
	AutoOpXMLHandler(const QString &strDirectoryPath, const QString &strFilename);
	virtual ~AutoOpXMLHandler(void);
public:
	//-------- Public methods --------
	// For want of a better name, this will tidy up the file to leave only a
	// maximum of the specified number of operations in the file.
	BOOL TidyUpRequests(long howManyToLeave);
	BOOL TidyUpResponses(long howManyToLeave);
	BOOL TidyUpHistory(long howManyToLeave);
	// The basic interface is simple.
	// Write operation adds XML representation of an operation to an XML file.
	// Read operation builds an operation from an XML node.
	// Extract operation does the same as read, but then removes the XML node 
	// from the XML file.
	virtual BOOL WriteOperation(const AutoOpRequestInfo &requestInfo);
	virtual BOOL WriteLogOperation(const AutoOpRequestInfo &requestInfo);
	virtual BOOL WriteOperation(const AutoOpResponseInfo &responseInfo);
	virtual BOOL WriteLogOperation(const AutoOpResponseInfo &responseInfo);
	virtual BOOL ReadOperation(AutoOpRequestInfo &requestInfo, const QString &strOperationID);
	virtual BOOL ReadFirstOperation(AutoOpRequestInfo &requestInfo);
	virtual BOOL ReadNthOperation(AutoOpRequestInfo &requestInfo, int oneBasedIterationCount);
	virtual BOOL ReadLogOperation(AutoOpRequestInfo &requestInfo, const QString &strOperationID);
	virtual BOOL ReadLogFirstOperation(AutoOpRequestInfo &requestInfo);
	virtual BOOL ReadLogNthOperation(AutoOpRequestInfo &requestInfo, int oneBasedIterationCount);
	virtual BOOL ReadOperation(AutoOpResponseInfo &responseInfo, const QString &strOperationID);
	virtual BOOL ReadOperation(AutoOpResponseInfo &responseInfo, const AutoOpInfo &requestInfo);
	virtual BOOL ReadFirstOperation(AutoOpResponseInfo &responseInfo);
	virtual BOOL ReadNthOperation(AutoOpResponseInfo &responseInfo, int oneBasedIterationCount);
	virtual BOOL ReadLogOperation(AutoOpResponseInfo &responseInfo, const QString &strOperationID);
	virtual BOOL ReadLogOperation(AutoOpResponseInfo &responseInfo, const AutoOpInfo &requestInfo);
	virtual BOOL ReadLogFirstOperation(AutoOpResponseInfo &responseInfo);
	virtual BOOL ReadLogNthOperation(AutoOpResponseInfo &responseInfo, int oneBasedIterationCount);
	virtual BOOL ExtractOperation(AutoOpRequestInfo &requestInfo, const QString &strOperationID);
	virtual BOOL ExtractFirstOperation(AutoOpRequestInfo &requestInfo);
	virtual BOOL ExtractNthOperation(AutoOpRequestInfo &requestInfo, int oneBasedIterationCount);
	// Initially not going to support extracting a logged node - why remove 
	// logged information from the file unless it is getting to be a very
	// large and unmanageable size.
	virtual BOOL ExtractOperation(AutoOpResponseInfo &responseInfo, const QString &strOperationID);
	virtual BOOL ExtractOperation(AutoOpResponseInfo &responseInfo, const AutoOpInfo &requestInfo);
	virtual BOOL ExtractFirstOperation(AutoOpResponseInfo &responseInfo);
	virtual BOOL ExtractNthOperation(AutoOpResponseInfo &responseInfo, int oneBasedIterationCount);
protected:
	//-------- Protected enumerations --------
	typedef enum tagAutoOpXMLFetchMode {
		// **** Always place new types after this first enumeration.
		FETCHMODE_FetchModeNotSupportedFirstInList = 0,
		// Fetch an operation from the file by its ID.
		FETCHMODE_OperationID,
		// Fetch an operation (typically a response) from the file by matching with an existing op.
		FETCHMODE_OperationMatch,
		// Fetch the first operation from the file.
		FETCHMODE_FirstOperation,
		// Fetch the nth operation from the file.
		FETCHMODE_NthOperation,
		// **** Always put new types before this last one in the enumeration.
		FETCHMODE_FetchModeNotSupportedLastInList
	} T_AutoOpXMLFetchMode;
	typedef enum tagAutoOpInfoType {
		// **** Always place new types after this first enumeration.
		INFOTYPE_InfoTypeNotSupportedFirstInList = 0,
		// AutoOpRequestInfo
		INFOTYPE_Request,
		// AutoOpResponseInfo
		INFOTYPE_Response,
		// **** Always put new types before this last one in the enumeration.
		INFOTYPE_InfoTypeNotSupportedLastInList
	} T_AutoOpInfoType;
	//-------- Protected constants --------
	static const QString StrRootTagResponses;
	static const QString StrRootTagRequests;
	static const QString StrRootTagHistory;
	//-------- Protected methods --------
	//-------- Protected data members --------
	// Path of directory that file resides in.
	QString m_strDirectoryPath;
	// Name of file containing the XML to read or write.
	QString m_strFilename;
private:
	//-------- Private constants --------
	static const QString StrTagResponse;
	static const QString StrTagRequest;
	static const QString StrTagIPAddress;
	static const QString StrTagNetBIOSName;
	static const QString StrTagOperation;
	static const QString StrTagConnectionSpeed;
	static const QString StrTagIterationCount;
	static const QString StrTagOverallStatus;
	static const QString StrTagIterationStatus;
	static const QString StrAttributeID;
	static const BOOL m_bCreateXMLIfAbsent;
	static const BOOL m_bDoNotCreateXMLIfAbsent;
	static const BOOL m_bExtractFromXMLWhenRead;
	static const BOOL m_bLeaveInXMLWhenRead;
	static const int m_IterationCountNoCount;
	//-------- Private methods --------
	// Build the XML node based on the data given.
	MSXML2::IXMLDOMNode* BuildXMLNode(const AutoOpRequestInfo &aRequest);
	MSXML2::IXMLDOMNode* BuildXMLNode(const AutoOpResponseInfo &aResponse);
	MSXML2::IXMLDOMNode* BuildXMLNode(const QString &strNodeTag, const AutoOpInfo &anOp);
	// Add a new line node to the given XML node for formatting the output
	// because we do not use a schema to enforce that kind of thing.
	HRESULT AddNewLineNode(MSXML2::IXMLDOMNode *toAddToNode);
	// Open the XML document (and hence the XML file), creating one if the 
	// XML file does not exist.
	BOOL OpenXMLDocument(BOOL bCreateIfDoesNotExist);
	// Save the open document back to XML file.
	HRESULT SaveXMLDocument(void);
	// Internally tidy up the XML file to reduce the contents.
	BOOL InternalTidyUp(const QString &strRootTag, long maximum);
	// Supplies functionality common to all write operations.
	BOOL InternalWriteOperation(const AutoOpInfo &anOp, const QString &strRootTag);
	// Supplies functionality common to all read and extract operations.
	BOOL InternalFetchOperation(AutoOpInfo **theRequestOrResponse, T_AutoOpInfoType infotypeRequestOrResponse,
			T_AutoOpXMLFetchMode fetchMode, BOOL bExtractFromXMLWhenRead, int oneBasedIterationCount,
			const AutoOpInfo &opToMatch, const QString &strOperationID, const QString &strRootTag);
	// Process the results of the internal fetch operation for requests.
	BOOL ConvertInternalFetchResults(BOOL bFetchStatus, AutoOpInfo *theFetchedRequest,
			AutoOpRequestInfo &theConvertedRequest);
	// Process the results of the internal fetch operation for responses.
	BOOL ConvertInternalFetchResults(BOOL bFetchStatus, AutoOpInfo *theFetchedRequest,
			AutoOpResponseInfo &theConvertedRequest);
	//-------- Private data members --------
	// The XML document.
	MSXML2::IXMLDOMDocument2 *m_pXMLDocument;
};
#endif // __AUTOOPXMLHANDLER_H__

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Automated Operations
/// @n Filename:	AutoOpRequestInfo.cpp
/// @n Description:	Implements AutoOpRequestInfo class.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:55:32 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:25:25 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 9/29/2006 5:11:08 PM  Charles Boardman
//  Make sure the connection speed gets set to a sensible value if the
//  current value is not recognised as being valid.
//  4 V6 Firmware 1.3 8/2/2006 2:11:29 PM Charles Boardman
//  Adding support for ConnectionSpeed in the request and the XML handler
//  for requests.
// $
//
// **************************************************************************
// MFC and ATL stuff
// Class header.
#include "AutoOpRequestInfo.h"
// Constant definitions
const QString AutoOpRequestInfo::StrTagNameConnectionSpeed("ConnectionSpeed");
//****************************************************************************
// Constructor
///
/// Default constructor.
//****************************************************************************
AutoOpRequestInfo::AutoOpRequestInfo(void) : AutoOpInfo() {
	SetConnectionSpeed(AUTOOPCONSPEED_Fast);
}
//****************************************************************************
// Constructor
///
/// Copy constructor.
//****************************************************************************
AutoOpRequestInfo::AutoOpRequestInfo(const AutoOpRequestInfo &aRequest) : AutoOpInfo(aRequest) {
	this->m_ConnectionSpeed = aRequest.m_ConnectionSpeed;
}
//****************************************************************************
// Constructor
///
/// Constructs a request operation from a base class instance.
///
/// @param[in]	anOp is the instance of the base class to construct the
///				request from.
//****************************************************************************
AutoOpRequestInfo::AutoOpRequestInfo(const AutoOpInfo &anOp) : AutoOpInfo(anOp) {
	SetConnectionSpeed(AUTOOPCONSPEED_Fast);
}
//****************************************************************************
// Constructor.
///
/// Constructs a request operation from a given operation type to perform. 
/// The base class constructor will be used to generate a unique ID for
/// the operation.
///
/// @param[in]	anOp is the operation to perform.
//****************************************************************************
AutoOpRequestInfo::AutoOpRequestInfo(T_AutoOp anOp, T_AutoOpConnectionSpeed conSpeed) : AutoOpInfo(anOp) {
	SetConnectionSpeed(conSpeed);
}
//****************************************************************************
// Destructor.
//****************************************************************************
AutoOpRequestInfo::~AutoOpRequestInfo(void) {
	// No local data to free up so nothing to do.
}
//****************************************************************************
// operator=
///
/// The assignment operator for AutoOpRequestInfo
///
/// @param[in]	rhs is the right hand side of the assignment expression.
///
/// @return Reference to AutoOpRequestInfo. Being a reference enables support 
/// for x = y = z; so that x will equal z after execution.
//****************************************************************************
AutoOpRequestInfo& AutoOpRequestInfo::operator=(const AutoOpRequestInfo &rhs) {
	// First off copy the attributes of the base class.
	AutoOpInfo::operator=(rhs);
	// Any specific request data to be copied here.
	this->m_ConnectionSpeed = rhs.m_ConnectionSpeed;
	return *this;
}
//****************************************************************************
//	BOOL ::AddTagValuePair( const QString   &strTag, const QString   &strValue )
///
/// Add a name/value pair of data to the object. Any names recognised as 
/// being specific are processed here, otherwise all other data is passed to
/// the base class to be processed.
///
/// @param[in]	strTag the name from the pair.
/// @param[in]	strValue the value from the pair.
///
/// @return TRUE if name/value pair was added ok, FALSE otherwise.
///
//****************************************************************************
BOOL AutoOpRequestInfo::AddTagValuePair(const QString &strTag, const QString &strValue) {
	BOOL bAddStatus = FALSE;
	// Detect any data specific to requests here, otherwise call base class.
	if (!strTag.isEmpty()) {
		if (StrTagNameConnectionSpeed == strTag) {
			T_AutoOpConnectionSpeed connectionSpeed = (T_AutoOpConnectionSpeed) strValue.toInt();
			bAddStatus = SetConnectionSpeed(connectionSpeed);
		} else {
			// Tag was not recognised as specific to a request so let the base
			// class deal with it.
			bAddStatus = AutoOpInfo::AddTagValuePair(strTag, strValue);
		}
	}
	return bAddStatus;
}
//****************************************************************************
// QString   ::GetConnectionSpeed( void )
///
/// Get the connection speed associated with this request.
///
/// @return The connection speed (an enumerated type).
//****************************************************************************
T_AutoOpConnectionSpeed AutoOpRequestInfo::GetConnectionSpeed(void) const {
	return m_ConnectionSpeed;
}
//****************************************************************************
// BOOL ::SetConnectionSpeed( T_AutoOpConnectionSpeed connectionSpeed )
///
/// Sets the connection speed associated with this request.
///
/// @param[in]	connectionSpeed is the connection speed (enumerated type).
///
/// @return TRUE if input was validate and used as connection speed, FALSE
/// otherwise.
//****************************************************************************
BOOL AutoOpRequestInfo::SetConnectionSpeed(T_AutoOpConnectionSpeed connectionSpeed) {
	// Default to some valid value.
	m_ConnectionSpeed = AUTOOPCONSPEED_Fast;
	BOOL bSetStatus = FALSE;
	// Validate input.
	if ((connectionSpeed > AUTOOPCONSPEED_NotSupportedFirstInList)
			&& (connectionSpeed < AUTOOPCONSPEED_NotSupportLastInList)) {
		m_ConnectionSpeed = connectionSpeed;
		bSetStatus = TRUE;
	}
	return bSetStatus;
}

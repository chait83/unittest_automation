/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Automated Operations
/// @n Filename:  AutoOpInfo.cpp
/// @n Description: Implements the AutoOpInfo class.
///
///	Requires Rpcrt4.lib for UuidCreate(), RpcStringFree() and UuidToString()
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  9 Stability Project 1.6.1.1 7/2/2011 4:55:31 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  8 Stability Project 1.6.1.0 7/1/2011 4:25:26 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  7 V6 Firmware 1.6 8/1/2006 8:51:12 PM Roger Dawson  
//  Replaced QVector< QString   , QString   & > with a typedef called
//  CAutoOpStringArray. Also modified the second parameter to be a
//  QString   rather than a reference copy. This allowed const QString   
//  objects to be passed to various AutoOp methods.
//  6 V6 Firmware 1.5 7/24/2006 8:44:25 PM  Charles Boardman
//  Removing some redundant calls for restting the born time of an
//  operation.
// $
//
// **************************************************************************
// MFC and ATL stuff.
// Class header
#include "AutoOpInfo.h"
#include <QString>
// Constant definitions
// These constants will match the XML tags in order to not require a 
// conversion of some XML tag name to some arbitrarily different field name
// that is recognised within AddTagValuePair().
const QString AutoOpInfo::StrTagNameID(("ID"));
const QString AutoOpInfo::StrTagNameIPAddress(("IPAddress"));
const QString AutoOpInfo::StrTagNameNetBIOSName(("NetBIOSName"));
const QString AutoOpInfo::StrTagNameOperation(("Operation"));
const QString AutoOpInfo::StrTagNameIterationCount(("IterationCount"));
const QString AutoOpInfo::StrDefaultIPAddress(("Not set"));
const QString AutoOpInfo::StrDefaultNetBIOSName(("Not set"));
//****************************************************************************
// Constructor
///
/// Default constructor. Generates an ID, but operation type initialised to
/// being deliberately invalid.
//****************************************************************************
AutoOpInfo::AutoOpInfo(void) {
	// Generate an ID for this operation.
	GenerateID();
	// Default iteration counter to the beginning.
	m_IterationCounter = 1;
	// Invalid operation type before it gets set through API.
	// The born time for this operation is set as a side-effect.
	SetOperation(AUTOOP_OperationNotSupportedFirstInList);
	// Default the IP address to unknown, although in future we could try
	// to derive it ourselves.
	m_strIPAddress = StrDefaultIPAddress;
	// Same with the Net BIOS names.
	m_strNetBIOSName = StrDefaultNetBIOSName;
}
//****************************************************************************
// Constructor
///
/// Constructs a copy of the given AutoOpInfo.
///
/// @param[in]	anAutoOpInfo is the operation to copy construct.
//****************************************************************************
AutoOpInfo::AutoOpInfo(const AutoOpInfo &anAutoOpInfo) {
	this->m_TheOp = anAutoOpInfo.m_TheOp;
	this->m_strID = anAutoOpInfo.m_strID;
	this->m_IterationCounter = anAutoOpInfo.m_IterationCounter;
	this->m_strIPAddress = anAutoOpInfo.m_strIPAddress;
	this->m_strNetBIOSName = anAutoOpInfo.m_strNetBIOSName;
	this->m_dwTimeOperationSet = anAutoOpInfo.m_dwTimeOperationSet;
	// Not forgetting the tag/value arrays.
	this->m_arrStrTags.clear();
	this->m_arrStrValues.clear();
//    CopyA
	this->m_arrStrTags += anAutoOpInfo.m_arrStrTags;
	this->m_arrStrValues += anAutoOpInfo.m_arrStrValues;
}
//****************************************************************************
// Constructor
///
/// Constructs an AutoOpInfo for the specified operation and generates a
/// unique id for the operation.
///
/// @param[in]	theOp is the operation to perform.
//****************************************************************************
AutoOpInfo::AutoOpInfo(T_AutoOp theOp) {
	// Generate an ID for this operation.
	GenerateID();
	// Default iteration counter to the beginning.
	m_IterationCounter = 1;
	// Not going to look at return value for setting the operation type
	// because there is nothing we can do about it over and above what gets
	// done in the mutator.
	// The born time for this operation is set as a side-effect.
	SetOperation(theOp);
	// Default the IP address to unknown, although in future we could try
	// to derive it ourselves.
	m_strIPAddress = StrDefaultIPAddress;
	// Same with the Net BIOS names.
	m_strNetBIOSName = StrDefaultNetBIOSName;
}
//****************************************************************************
// Constructor.
///
/// Constructs an AutoOpInfo using the given operation and operation ID.
///
/// @param[in]	theOp is the operation
/// @param[in]	strOpID is the ID of the operation
//****************************************************************************
AutoOpInfo::AutoOpInfo(T_AutoOp theOp, const QString &strOpID) {
	// The ID. An empty string is not okay.
	if (strOpID.isEmpty()) {
		// We were not given an id so generate one.
		GenerateID();
	} else {
		// Use the ID we were given.
		m_strID = strOpID;
	}
	// Default iteration counter to the beginning.
	m_IterationCounter = 1;
	// Not going to look at return value for setting the operation type
	// because there is nothing we can do about it over and above what gets
	// done in the mutator.
	// The born time for this operation is set as a side-effect.
	SetOperation(theOp);
	// Default the IP address to unknown, although in future we could try
	// to derive it ourselves.
	m_strIPAddress = StrDefaultIPAddress;
	// Same with the Net BIOS names.
	m_strNetBIOSName = StrDefaultNetBIOSName;
}
//****************************************************************************
// Constructor.
///
/// Constructs an AutoOpInfo given an operation and a UUID as operation ID.
///
/// @param[in]	theOp is the operation.
/// @param[in]	theUuid is a pointer to a UUID to use as operation ID.
//****************************************************************************
AutoOpInfo::AutoOpInfo(T_AutoOp theOp, UUID *theUuid) {
	// Check for valid input.
	if (NULL != theUuid) {
// Unfortunately PC and CE require different parameter type to the APIs being 
// used.
		unsigned short *theString = NULL;
		RPC_STATUS rpcStatus = UuidToStringW(theUuid, &theString);
		if ((RPC_S_OK == rpcStatus) && (NULL != theString)) {
			// Copy the string.
			m_strID = reinterpret_cast<WCHAR*>(theString);
			// Free the allocated data.
			RpcStringFreeW(&theString);
		} else {
			// Something went wrong in the conversion to string.
			GenerateID();
		}
	} else {
		// Not given a UUID so generate our own ID.
		GenerateID();
	}
	// Default iteration counter to the beginning.
	m_IterationCounter = 1;
	// Not going to look at return value for setting the operation type
	// because there is nothing we can do about it over and above what gets
	// done in the mutator.
	// The born time for this operation is set as a side-effect.
	SetOperation(theOp);
	// Default the IP address to unknown, although in future we could try
	// to derive it ourselves.
	m_strIPAddress = StrDefaultIPAddress;
	// Same with the Net BIOS names.
	m_strNetBIOSName = StrDefaultNetBIOSName;
}
//****************************************************************************
// Constructor.
///
/// Constructs an AutoOpInfo given an operation and a UUID as operation ID.
///
/// @param[in]	theOp is the operation.
/// @param[in]	theUuid is an UUID to use as operation ID.
//****************************************************************************
AutoOpInfo::AutoOpInfo(T_AutoOp theOp, UUID &theUuid) {
	unsigned short *theString = NULL;
	// Deal with the ID for the operation first.
	RPC_STATUS rpcStatus = UuidToStringW(&theUuid, &theString);
	if ((RPC_S_OK == rpcStatus) && (NULL != theString)) {
		// Copy the string.
		m_strID = reinterpret_cast<WCHAR*>(theString);
		// Free the allocated data.
		RpcStringFreeW(&theString);
	} else {
		// Something went wrong in the conversion to string.
		GenerateID();
	}
	m_strID = L"{40EA323F-6F0B-43ab-A206-26571A2B6DA5}";
	// Default iteration counter to the beginning.
	m_IterationCounter = 1;
	// Not going to look at return value for setting the operation type
	// because there is nothing we can do about it over and above what gets
	// done in the mutator.
	// The born time for this operation is set as a side-effect.
	SetOperation(theOp);
	// Default the IP address to unknown, although in future we could try
	// to derive it ourselves.
	m_strIPAddress = StrDefaultIPAddress;
	// Same with the Net BIOS names.
	m_strNetBIOSName = StrDefaultNetBIOSName;
}
//****************************************************************************
// Destructor.
//****************************************************************************
AutoOpInfo::~AutoOpInfo() {
	// Nothing to do Abe.
}
//****************************************************************************
// operator=
///
/// The assignment operator for AutoOpInfo
///
/// @param[in]	rhs is the right hand side of the assignment expression.
///
/// @return Reference to AutoOpInfo. Being a reference enables support for 
/// x = y = z; so that x will equal z after execution.
//****************************************************************************
AutoOpInfo& AutoOpInfo::operator=(const AutoOpInfo &rhs) {
	m_strID = rhs.m_strID;
	m_IterationCounter = rhs.m_IterationCounter;
	m_TheOp = rhs.m_TheOp;
	m_strIPAddress = rhs.m_strIPAddress;
	m_strNetBIOSName = rhs.m_strNetBIOSName;
	m_dwTimeOperationSet = rhs.m_dwTimeOperationSet;
	// Remove existing array contents before assignment. 
	m_arrStrTags.clear();
	m_arrStrValues.clear();
	m_arrStrTags += rhs.m_arrStrTags;
	m_arrStrValues += rhs.m_arrStrValues;
	return *this;
}
//****************************************************************************
// void ::GenerateID( void )
///
/// Generates a UUID to use a ID for the operation - it assigns to the string
/// version of the UUID to the private member that stores the operation ID.
//****************************************************************************
void AutoOpInfo::GenerateID(void) {
	// Generate a unique id for the operation.
	UUID theUuid;
	/// TODO : Resolve this
	RPC_STATUS rpcStatus = UuidCreate(&theUuid);
	if (RPC_S_OK == rpcStatus) {
		unsigned short *theString = NULL;
		rpcStatus = UuidToStringW(&theUuid, &theString);
		if ((RPC_S_OK == rpcStatus) && (NULL != theString)) {
			// Copy the string.
			m_strID = reinterpret_cast<WCHAR*>(theString);
			// Free the allocated data.
			RpcStringFreeW(&theString);
		}
	} else {
		// Generating a UUID failed, so generate any old id, base it on some 
		// things that change to give it a remote chance of being unique.
		static unsigned long justACounter = 0;
		justACounter++;
		unsigned long theTickCount = GetTickCount();
		// A reasonably unique ID.
		m_strID = QString::asprintf(("%lu%lu"), theTickCount, justACounter);
	}
}
//****************************************************************************
// BOOL ::SetID( const QString   &strID )
///
/// Set the ID for this operation.
///
/// @param[in]	strID is the string to use as new operation ID.
///
/// @return TRUE if input was valid and adopted as the new operation ID,
/// otherwise FALSE.
//****************************************************************************
BOOL AutoOpInfo::SetID(const QString &strID) {
	BOOL bSetStatus = FALSE;
	if (!strID.isEmpty()) {
		m_strID = strID;
		bSetStatus = TRUE;
		// A change of the unique ID for this operation is a fundamental
		// identity change and so restart the operation timer.
		m_dwTimeOperationSet = GetTickCount();
	}
	return bSetStatus;
}
//****************************************************************************
// QString   ::GetID( void ) const
///
/// Returns the ID of the operation.
///
/// @return The operation ID.
//****************************************************************************
QString AutoOpInfo::GetID(void) const {
	return m_strID;
}
//****************************************************************************
// BOOL ::SetIPAddress( const QString   &strID )
///
/// Set the IP address for this operation.
///
/// @param[in]	strIPAddress is the string to use as the IP address.
///
/// @return TRUE always.
///
/// @note It is the responsibility of the code using this class to determine
/// the IP address and set it if it is important information to know.
//****************************************************************************
BOOL AutoOpInfo::SetIPAddress(const QString &strIPAddress) {
	BOOL bSetStatus = TRUE;
	// Don't care what the input string is really. It can be empty in order to
	// clear the current value.
	m_strIPAddress = strIPAddress;
	// No need to reset the born time for the operation just because the IP
	// address changes.
	return bSetStatus;
}
//****************************************************************************
// QString   ::GetIPAddress( void ) const
///
/// Returns the IP address of the machine that generated this operation.
///
/// @return IP address.
///
/// @note It is the responsibility of the code using this class to determine
/// the IP address and set it if it is important information to know.
//****************************************************************************
QString AutoOpInfo::GetIPAddress(void) const {
	return m_strIPAddress;
}
//****************************************************************************
// BOOL ::SetNetBIOSName( const QString   &strNetBIOSName )
///
/// Set the NetBIOS name of the machine that generated this operation.
///
/// @param[in]	strNetBIOSName is the string to use as the NetBIOS name.
///
/// @return TRUE always.
///
/// @note It is the responsibility of the code using this class to determine
/// the NetBIOS name and set it if it is important information to know.
//****************************************************************************
BOOL AutoOpInfo::SetNetBIOSName(const QString &strNetBIOSName) {
	BOOL bSetStatus = TRUE;
	// Do not mind what the input string is. It can be empty in order to clear
	// the current value or if NetBIOS name is not known.
	m_strNetBIOSName = strNetBIOSName;
	// No need to reset the born time of this operation just because the 
	// NetBIOS name changes.
	return bSetStatus;
}
//****************************************************************************
// QString   ::GetNetBIOSName( void ) const
///
/// Returns the NetBIOS name of the machine that generated this operation.
///
/// @return NetBIOS name.
///
/// @note It is the responsibility of the code using this class to determine
/// the NetBIOS name and set it if it is important information to know.
//****************************************************************************
QString AutoOpInfo::GetNetBIOSName(void) const {
	return m_strNetBIOSName;
}
//****************************************************************************
// BOOL ::SetOperation( T_AutoOp theOp )
///
/// Sets the operation to be performed.
///
/// @param[in]	T_AutoOp that specifies the operation to be performed.
///
/// @return TRUE if input was valid and adopted as the operation to perform,
/// otherwise FALSE.
//****************************************************************************
BOOL AutoOpInfo::SetOperation(T_AutoOp theOp) {
	// Assume failure until proven otherwise.
	BOOL bSetStatus = FALSE;
	// Default to unsupported operation.
	m_TheOp = AUTOOP_OperationNotSupportedLastInList;
	// A different type of operation is a fundamental identity change. Always 
	// reset the born time as we default the operation in case of invalid 
	// input.
	m_dwTimeOperationSet = GetTickCount();
	// Validate the input.
	if ((theOp > AUTOOP_OperationNotSupportedFirstInList) && (theOp < AUTOOP_OperationNotSupportedLastInList)) {
		m_TheOp = theOp;
		// Success.
		bSetStatus = TRUE;
	}
	return bSetStatus;
}
//****************************************************************************
// T_AutoOp ::GetOperation( void ) const
///
/// Get the operation to be performed.
///
/// @return The operation to perform.
//****************************************************************************
T_AutoOp AutoOpInfo::GetOperation(void) const {
	return m_TheOp;
}
//****************************************************************************
// BOOL ::SetIterationCount( int iterationCount )
///
/// Sets the iteration count for this operation, which can be useful when it
/// is necessary to indicate that an operation is part way through performing
/// all the steps that it needs to before it can be considered complete.
///
/// @param[in]	iterationCount is iteration number to set.
///
/// @return TRUE always, as there is not much to go wrong here.
//****************************************************************************
BOOL AutoOpInfo::SetIterationCount(int iterationCount) {
	BOOL bSetStatus = TRUE;
	// Protect against negative input.
	if (iterationCount < 0) {
		m_IterationCounter = 0;
	} else {
		m_IterationCounter = iterationCount;
	}
	// If the iteration count is changing then this is a fundamental identity
	// change (because it implies progress) and so reset operation born time.
	m_dwTimeOperationSet = GetTickCount();
	return bSetStatus;
}
//****************************************************************************
// unsigned long ::GetIterationCount( void ) const
///
/// Gets the iteration count.
///
/// @return The iteration count.
//****************************************************************************
unsigned long AutoOpInfo::GetIterationCount(void) const {
	return m_IterationCounter;
}
//****************************************************************************
// unsigned long AutoOpInfo::IncrementIterationCount( void )
///
/// Incerments the iteration counter. The idea behind this is that a single
/// object can be used when performing a transactional operation simply by
/// utilising this method.
///
/// @return The updated value of the iteration counter after the increment.
//****************************************************************************
unsigned long AutoOpInfo::IncrementIterationCount(void) {
	// Increment the counter.
	m_IterationCounter++;
	// If the iteration count is changing then this is a fundamental identity
	// change (because it implies progress) and so reset operation born time.
	m_dwTimeOperationSet = GetTickCount();
	// Return the new value.
	return m_IterationCounter;
}
//****************************************************************************
// BOOL ::AddTagValuePair( const QString   &strTag, const QString   &strValue )
///
/// Add a tag name and value to the operation. This enables supplementary 
/// information to be associated with any given operation, which in turn 
/// allows for greater flexibility.
///
/// @param[in]	strTag is the tag name of the pair.
/// @param[in]	strValue is the value of the pair.
///
/// @return TRUE if name/value pair inputs are accepted and added, FALSE
/// otherwise.
///
/// @note This method supports setting the operation, operation id, ip address
/// and iteration counter as an alternative to the direct interfaces supplied 
/// for setting their values.
///
/// This method also allows name/value pairs where the tag name is a duplicate
/// of an existing tag name. This is except for the operation, operation id
/// and iteration count which will be recognised internally and redirected to
/// use the appropriate public mutator.
//****************************************************************************
BOOL AutoOpInfo::AddTagValuePair(const QString &strTag, const QString &strValue) {
	BOOL bAddStatus = FALSE;
	// The tag is effectively a key for looking up values, so it must exist.
	if (!strTag.isEmpty()) {
		// Do not add the pair of data withouth first checking if they are
		// one of the key bits of information relevant to this object.
		// Specifically: Operation ID, Operation type and iteration count.
		if (StrTagNameID == strTag) {
			bAddStatus = SetID(strValue);
		} else if (StrTagNameOperation == strTag) {
			T_AutoOp operation = (T_AutoOp) strValue.toInt();
			bAddStatus = SetOperation(operation);
		} else if (StrTagNameIterationCount == strTag) {
			int iterationCount = strValue.toInt();
			bAddStatus = SetIterationCount(iterationCount);
		} else if (StrTagNameIPAddress == strTag) {
			bAddStatus = SetIPAddress(strValue);
		} else if (StrTagNameNetBIOSName == strTag) {
			bAddStatus = SetNetBIOSName(strValue);
		} else {
			// The tag value pair has not been recognised so it is treated as
			// generic information to be stored.
			m_arrStrTags.append(strTag);
			m_arrStrValues.append(strValue);
			// Make a check that on the integrity of the arrays - they should be
			// the same size.
			if (m_arrStrTags.length() == m_arrStrValues.length()) {
				bAddStatus = TRUE;
			}
		}
	}
	return bAddStatus;
}
//****************************************************************************
// BOOL ::GetSupplementaryTagValuePairs( 
//							CAutoOpStringArray &arrStrTagName, 
//							CAutoOpStringArray &arrStrTagValue 
//							) const
///
/// Get all name/value pairs that have been added to this operation. This will
/// exclude the operation, operation id and iteration count.
///
/// @param[out]	arrStrTagNames is the array that will be changed to contain
///				all of the tag names.
/// @param[out] arrStrTagValues is the array that will be changed to contain
///				all of the tag values.
///
/// @return TRUE if the data was assigned to the the reference parameters,
/// FALSE otherwise.
//****************************************************************************
BOOL AutoOpInfo::GetSupplementaryTagValuePairs(CAutoOpStringArray &arrStrTagNames,
		CAutoOpStringArray &arrStrTagValues) const {
	BOOL bCopiedStatus = FALSE;
	if (m_arrStrTags.length() == m_arrStrValues.length()) {
		// The tag names.
		arrStrTagNames.clear();
		arrStrTagNames += m_arrStrTags;
		// The values.
		arrStrTagValues.clear();
		arrStrTagValues += m_arrStrValues;
		// All done.
		bCopiedStatus = TRUE;
	}
	return bCopiedStatus;
}
//****************************************************************************
// int ::GetSupplementaryTagValuePairs( 
//							const QString   				&strTagName,
//							CAutoOpStringArray	&arrStrTagValues 
//							) const
///
/// Get all name/value pairs with the given tag name that have been added to 
/// this operation. This will exclude the operation, operation id, ip address,
/// NetBIOS name and iteration count.
///
/// @param[in]	strTagName is the tag name to find all values for.
/// @param[out] arrStrTagValues is the array that will be changed to contain
///				all of the tag values.
///
/// @return The number of values with matching tag name returned in the array.
//****************************************************************************
int AutoOpInfo::GetSupplementaryTagValuePairs(const QString &strTagName, CAutoOpStringArray &arrStrTagValues) const {
	// Empty current contents of the values array.
	arrStrTagValues.clear();
	if (m_arrStrTags.length() == m_arrStrValues.length()) {
		int arrSize = (int) m_arrStrTags.length();
		for (int i = 0; i < arrSize; i++) {
			if (strTagName == m_arrStrTags[i]) {
				// Tag matches, so add the corresponding value.
				QString strCurr = m_arrStrValues[i];
				arrStrTagValues.append(strCurr);
			}
		} // end for loop - i
	}
	int numValuesFound = (int) arrStrTagValues.length();
	return numValuesFound;
}
//****************************************************************************
// const bool OperationHasExpired( const USHORT usTIMEOUT_PERIOD ) const
///
/// Method used to identify if this operation has expired.
///
/// @param[in]		const USHORT usTIMEOUT_PERIOD - The timeout period in seconds
///
/// @return			True if the operation has expired
///
//****************************************************************************
const bool AutoOpInfo::OperationHasExpired(const USHORT usTIMEOUT_PERIOD) const {
	// Default to say not expired yet, and change if that is not the case.
	bool bOpExpired = false;
	static const DWORD SecsToMillisMultiplier = 1000;
	// So how many milliseconds is the timeout?
	DWORD dwTimeoutInMS = SecsToMillisMultiplier * (static_cast<DWORD>(usTIMEOUT_PERIOD));
	DWORD dwTickNow = GetTickCount();
	// Op has expired if its born date plus the time out is less than the
	// current time.
	if ((m_dwTimeOperationSet + dwTimeoutInMS) < dwTickNow) {
		bOpExpired = true;
	}
	return bOpExpired;
}

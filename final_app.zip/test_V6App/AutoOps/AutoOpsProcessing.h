/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Automated Operations
/// @n Filename:  AutoOpsProcessing.h
/// @n Description: Declaration for the CAutoOpsProcessing class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  14  Stability Project 1.11.1.1 7/2/2011 4:55:32 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  13  Stability Project 1.11.1.0 7/1/2011 4:27:46 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  12  V6 Firmware 1.11 3/5/2007 3:09:46 PM Roger Dawson  
//  CustomWavs directory created. All custom files will get dumped in
//  this directory and will be used in preference to the default wav
//  file(s). Also added the ability to delete custom wav files by
//  allowing the user to upload a wav file call SXX-Default.wav which
//  results in the custom file being delted but not replaced (e.g.
//  S1-Default.wav will delete any existing custom wav file called
//  S1-XXX.wav).
//  11  V6 Firmware 1.10 12/21/2006 4:51:22 PM  Roger Dawson  
//  Added the ability to load in new sound files.
// $
//
// **************************************************************************
#ifndef _AUTO_OPS_PROCESSING_H
#define _AUTO_OPS_PROCESSING_H
#include "V6ActiveModule.h"
#include "AutoOpRequestInfo.h"
#include "AutoOpResponseInfo.h"
#include <deque>
/// Enumeration for Member function Return Values to indicate success and failure conditions
typedef enum _eAutoOpsReturnValue {
	aorOK, aorINITIALISATION_FAILED,
} T_AUTO_OPS_RETURN_VALUE;
/// Enumeration for the Operational mode of the Message List Processing Module
typedef enum _eAutoOpsOperationalMode {
	aopOPMODE_IDLE, aopOPMODE_NORMAL_OPERATION, aopOPMODE_EXIT
} T_AUTO_OPS_OPERATIONAL_MODE;
//**CAutoOpsProcessing**************************************************
/// 
/// @brief V6 Active module responsible for processing automated operation
/// commands
///
/// V6 Active module responsible for processing automated operation commands
///
//****************************************************************************
class CAutoOpsProcessing: public CV6ActiveModule {
public:
	enum T_OPERATIONS {
		opsNO_OP_IN_PROGRESS,
		opsDOWNLOAD_CFG,
		opsDOWNLOAD_DATA_WAITING_FOR_TMS,
		opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER,
		opsUPLOAD_CFG
	};
	/// Enum indicating the success/failure state of the upload sounds function
	enum T_UPLOAD_SOUND_STATE {
		ussSUCCESS, ussINVALID_NAME, ussMAX_FILE_SIZE_EXCEEDED
	};
	// Constructor
	CAutoOpsProcessing(const T_MODULE_ID eMODULE_ID);
	// Destructor
	virtual ~CAutoOpsProcessing(void);
	/// Get the Operational State of the IO Simulator
	inline const T_AUTO_OPS_OPERATIONAL_MODE GetOperationalState(void) const {
		return (m_eOperationalMode);
	}
	// Primary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	// Secondary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	// Method called when Module goes into Normal Operation
	virtual T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	// Method called when Module is to prepare for Setup Config Change 
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	// Method called when Module is to carry out Setup Change Completion
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	// Method called when a Module is to prepare for Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	// Method called when a Module is to Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE Shutdown(void);
	// Carries out the desired function when a message is received
	virtual T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler(const CMsgQueueMessage *pMsg);
	// Method that checks the FTP directory for new requests
	const bool CheckFTPRequestsDIR(const bool bINACTIVITY_TIMEOUT);
	// Method that checks if there are any lingering setup/data files and delete them
	void CheckForTimeoutResponses();
	// Method responsible for replacing sound files
	static const T_UPLOAD_SOUND_STATE ReplaceSoundFile(QString wcaSourcePathName, QString wcaSourceFileName);
private:
	// --- Private Member Variables --- //
	///< Operational Mode for the Module
	T_AUTO_OPS_OPERATIONAL_MODE m_eOperationalMode;
	/// Store for the current response item
	AutoOpResponseInfo m_kCurrResponse;
	/// Permamanet store for the auto ops directory as it is accessed frequently
	QString m_wcaAutoOpsDir;
	// Enum indicating if there is some action already in progress
	T_OPERATIONS m_eActionInProgress;
	/// Variable indicating we are waiting for a okay to tidy up request from TMP
	int m_iWaitingForTidyUpCommand;
	/// Variable indicating the start time of the current operation - only used for download data
	/// type operations at the moment
	LONGLONG m_llCurrOpStartTime;
	/// Variable used to store the link speed of the latest operation that is actually in progress
	T_AutoOpConnectionSpeed m_eCurrConnSpeed;
	// --- Private Member Functions --- //
	// Initialise the auto ops system
	void Initialise();
	// Method that processes an auto ops request
	void ProcessRequest(AutoOpRequestInfo &kAutoOpReqInfo);
	// Method that processes a request permission for upload setup command
	void ProcessRequestPermissionForUploadSetup(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes an upload setup command
	void ProcessLoadUploadSetup(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes a make setup avaialbe for download command
	void ProcessMakeSetupAvailableForDownload(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes a cancel request
	void ProcessCancelRequest(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes a flush request
	void ProcessFlushRequest(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes a export LCF data request
	void ProcessExportLCFData(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes a export logged pen data request
	void ProcessExportLoggedData(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes remove setup for download command
	void ProcessRemoveSetupForDownload(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes a download pen data complete message from TMP
	void ProcessDownloadPenDataComplete(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that processes an upload soound files command
	void ProcessUploadSoundFilesRequest(AutoOpRequestInfo &rkAutoOpReqInfo);
	// Method that creates an automated reponse and puts it in the auto ops directory
	const AutoOpResponseInfo SendResponse(const AutoOpRequestInfo &kAUTO_OP_REQ_INFO,
			const T_AutoOpIterationStatus eITERATION_STATUS, const T_AutoOpOverallStatus eOVERALL_STATUS) const;
	// Method responsible for deleting a downloaded setup file and tidying up
	// any other related variables
	void RemoveDownloadedSetupFile();
	// Method responsible for deleting an uploaded setup file and tidying up
	// any other related variables
	void RemoveUploadedSetupFile();
	// Method responsible for deleting any downloaded data files and tidying up
	// any other related variables
	void RemoveDownloadedDataFiles();
	// Accessor indicating if FTP uploads are permitted
	const bool UploadAllowed() const;
	// Accessor indicating if FTP downloads are permitted
	const bool DownloadAllowed() const;
	// Method reponsible for initiating the loading of an uploaded setup
	const bool LoadConfiguration(QString wcaFileName);
	// Method that attempts to write the reponse data to the response file
	const bool WriteResponseFile(const AutoOpResponseInfo &rkCURR_RESPONSE) const;
	// Method that determines how many data files are available for transfer
	const USHORT GetDataFilesAvailable() const;
	// Method that posts a message to the export scheduler to cancel the current export
	void SendTXSchedulerCancel();
#ifdef RDL_AUTO_OPS_DBG_ENABLE
	virtual void LogDebugMessage(QString   & strDbgMsg);
	#endif
private:
#ifdef RDL_AUTO_OPS_DBG_ENABLE
	static CDebugFileLogger m_debugFileLogger;
#endif
};
// End of Class Declaration
#endif // _AUTO_OPS_PROCESSING_H

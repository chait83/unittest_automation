/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Automated Operations
/// @n Filename:	AutoOpLogger.h
/// @n Description: AutoOpLogger class declaration.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:55:32 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:25:26 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 6/19/2006 8:12:58 PM  Charles Boardman 
// $
//
// **************************************************************************
#pragma once
#if ! defined ( __AUTOOPLOGGER_H__ )
#define __AUTOOPLOGGER_H__
// AutoOpXMLHandler
#include "AutoOpXMLHandler.h"
//** AutoOpLogger ************************************************************
///
/// @brief ???
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class AutoOpLogger: public AutoOpXMLHandler {
};
#endif // __AUTOOPLOGGER_H__

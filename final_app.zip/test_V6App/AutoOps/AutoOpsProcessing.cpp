/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Automated Operations
/// @n Filename:  AutoOpsProcessing.cpp
/// @n Description: Implementation for the CAutoOpsProcessing class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  39  Aristos  1.33.1.3.1.0 9/19/2011 4:51:07 PM  Hemant(HAIL)
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  38  Stability Project 1.33.1.3 7/2/2011 4:55:32 PM Hemant(HAIL)
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  37  Stability Project 1.33.1.2 7/1/2011 4:37:58 PM Hemant(HAIL)
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware.
//  36  Stability Project 1.33.1.1 3/17/2011 3:20:10 PM  Hemant(HAIL)
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "StringUtils.h"
#include "StringDefinitions.h"
#include "AutoOpsProcessing.h"
#include "AutoOpsProcessingThread.h"
#include "AutoOpRequestInfo.h"
#include "AutoOpResponseInfo.h"
#include "CeAutoOpsXMLHandler.h"
#include "CStorage.h"
#include "StoragePaths.h"
#include "V6globals.h"
#include "TopStatusBar.h"
#include "RecSetupCfgMgr.h"
#include "StringUtils.h"
#include "FTPUser.h"
#include "BatchManager.h"
#include "AMS2750TUSMgr.h"
#include "ThreadInfo.h"
#include "V7DbgLogDefines.h"
#include <QDirIterator>
const QString wcFTP_REQ = "FTPReq.xm";
const QString wcTEMP_FTP_REQ = "notready.req";
const QString wcFTP_RESP = "FTPResp.xm";
const QString wcFTP_CONFIG_SETUP = "FTPSetup.set";
#ifdef RDL_AUTO_OPS_DBG_ENABLE
CDebugFileLogger CAutoOpsProcessing::m_debugFileLogger(_T("\\SDMemory\\AutoOpsDbgLogFile.txt"), FALSE, (10*1024*1024));
#endif
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
extern ULONG glb_MsgCntCht;
#endif
//****************************************************************************
//	CAutoOpsProcessing( const T_MODULE_ID eMODULE_ID )
///
/// Constructor
///
/// @param[in] 	  moduleId - Module Identification Number
///
//****************************************************************************
CAutoOpsProcessing::CAutoOpsProcessing(const T_MODULE_ID eMODULE_ID) : CV6ActiveModule(eMODULE_ID), m_eActionInProgress(
		opsNO_OP_IN_PROGRESS), m_iWaitingForTidyUpCommand(0), m_llCurrOpStartTime(0), m_eCurrConnSpeed(
		AUTOOPCONSPEED_Fast) {
	// Initialise Member Variables
	m_eOperationalMode = aopOPMODE_IDLE;
#ifdef RDL_AUTO_OPS_DBG_ENABLE
    SetDebugLogger(&m_debugFileLogger); //Set the defult static handler for this module
    #endif
} // End of Constructor
//****************************************************************************
//	~CAutoOpsProcessing(void)
///
/// Destructor
///
//****************************************************************************
CAutoOpsProcessing::~CAutoOpsProcessing(void) {
} // End of Destructor
//****************************************************************************
//	void Initialise( )
///
/// Initialise the auto ops system
///
//****************************************************************************
void CAutoOpsProcessing::Initialise() {
	T_AUTO_OPS_RETURN_VALUE retValue = aorINITIALISATION_FAILED; // Member Function Return Value
#ifdef RDL_AUTO_OPS_DBG_ENABLE
    QString   strDbgMsg;
    strDbgMsg = QString::asprintf(_T("Initialise Begin "));
    LogDebugMessage(strDbgMsg);
    #endif
	// create the FTP user class which is responsible for updating the FTP information in
	// the registry and creating the FTP directories
	CFTPUser kFTPUser;
	if ( TRUE != kFTPUser.DoesDefaultUserExist()) {
		kFTPUser.CreateDefaultUser();
	}
	kFTPUser.CreateFolderStructure();
	// make sure the custom sounds folder always exists too
    QString wcaCustomSoundPath;
	int iMaxPath = MAX_PATH;
	//_wcsnset_s( wcaCustomSoundPath, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaCustomSoundPath, sizeof(wcaCustomSoundPath));
    QString fileName = "";
    pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_CUSTOM_WAVS, &fileName, &wcaCustomSoundPath, iMaxPath);
	// create the custom sounds directory
	(wcaCustomSoundPath, NULL);
	// tidy up any lingering setup or data fiels that may be present
	RemoveDownloadedSetupFile();
	CStorage kConfigFile;
	QString wcaFTPCfgFile;
	;
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD_CFG, &wcFTP_CONFIG_SETUP, &wcaFTPCfgFile, MAX_PATH);
	RemoveDownloadedDataFiles();
	// check if the file exists before deleting
	if (kConfigFile.exists(wcaFTPCfgFile)) {
		kConfigFile.QFile::remove(wcaFTPCfgFile);
	}
	// setup the FTP auto ops directory
	//_wcsnset_s( m_wcaAutoOpsDir,sizeof(m_wcaAutoOpsDir)/sizeof(WCHAR), 0, MAX_PATH );
	SecureZeroMemory(m_wcaAutoOpsDir, sizeof(m_wcaAutoOpsDir));
	QString temp = "";
	pDALGLB->BuildPath(IDS_FTP, IDS_AUTO_OPS, &temp, &m_wcaAutoOpsDir, MAX_PATH);
#ifdef RDL_AUTO_OPS_DBG_ENABLE
    strDbgMsg = QString::asprintf(_T("Initialise End "));
    LogDebugMessage(strDbgMsg);
    #endif
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation( void )
///
/// Primary Initialisation of the Module
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::PerformPrimaryInitialisation(void) {
	// Initialise the IO Simulator for Operation
	Initialise();
	return (T_V6ACTMOD_RETURN_VALUE());
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation( void )
///
/// Secondary Initialisation of the Module
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::PerformSecondaryInitialisation(void) {
	// --- Do Nothing --- //
	return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE NormalOperation( void )
///
/// Method called when Module goes into Normal Operation
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::NormalOperation(void) {
	m_eOperationalMode = aopOPMODE_NORMAL_OPERATION;
	return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation( void )
///
/// Method called when Module is to prepare for Setup Config Change
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::SetupConfigChangePreparation(void) {
	m_eOperationalMode = aopOPMODE_IDLE;
	return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete( void )
///
/// Method called when Module is to carry out Setup Change Completion
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::SetupConfigChangeComplete(void) {
	// check if there is an upload config response pending - this should only be possible
	// if the upload config command is what has triggered the config change. In this case
	// we must send the reponse back to TMP
	if (m_eActionInProgress == opsUPLOAD_CFG) {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Setup change complete");
		SendResponse(m_kCurrResponse, AUTOOPITER_Okay, AUTOOPOVERALL_OkayOperationComplete);
		// tidy up
		RemoveUploadedSetupFile();
		// check if a reboot is required
		if ( pSETUP->IsResetRequired()) {
#ifndef V6IOTEST
			// trigger a restart
			LPARAM lRebootParam = static_cast<LPARAM>(CTopStatusBar::slpREBOOT_PENDING);
			lRebootParam |= static_cast<LPARAM>(CTopStatusBar::slpTRIGGER_RESTART);
			// post the message to the top status bar
			::PostMessage(CTopStatusBar::Instance()->m_hWnd, WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_LOCK, lRebootParam);
#endif
		}
	}
	return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE ShutdownPreparation( void )
///
/// Method called when a Module is to prepare for Shutdown
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::ShutdownPreparation(void) {
	// check if there is an upload config response pending - this should only be possible
	// if the upload config command is what has triggered the config change. In this case
	// we must send the reponse back to TMP
	if (m_eActionInProgress == opsUPLOAD_CFG) {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Setup change complete");
		SendResponse(m_kCurrResponse, AUTOOPITER_Okay, AUTOOPOVERALL_OperationCompleteRebootRequired);
		// Wait 2 seconds, which should be ample time for TMP to read the response before the recorder
		// restarts
		sleep(2000);
		CStorage kConfigFile;
		QString wcaFTPCfgFile;
		pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD_CFG, &wcFTP_CONFIG_SETUP, &wcaFTPCfgFile, MAX_PATH);
		// check if the file exists before deleting - should always exist
		if (kConfigFile.exists(wcaFTPCfgFile)) {
			kConfigFile.QFile::remove(wcaFTPCfgFile);
		}
	}
	m_eOperationalMode = aopOPMODE_IDLE;
	return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE Shutdown( void )
///
/// Method called when a Module is to Shutdown
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::Shutdown(void) {
	m_eOperationalMode = aopOPMODE_EXIT;
	return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler( const CMsgQueueMessage *pMsg )
///
/// Carries out the desired function when a message is received
///
/// @param[in] 	  const CMsgQueueMessage *pMsg - Pointer to the received message
///
/// @return V6ACTMOD_OK - Associated Action with Received Message Undertaken Sucessfully
/// @n V6ACTMOD_MESSAGE_NOT_HANDLED - Message Received is not being handled
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CAutoOpsProcessing::ModuleMessageHandler(const CMsgQueueMessage *pMsg) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_OK;
	switch (pMsg->m_MessageType) {
	case MOD_AUTO_OPS_COLLECT_FILES:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Data files ready for transfer");
		// some files have been exported but the 4MB limit for the FTP directory must have been reached
		// therefore we need to get TMS to collect what has been exported so far before exporting
		// check we still think we are processing an export pen data command
		if ((m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER)
				&& ((m_kCurrResponse.GetOperation() == AUTOOP_ExportLoggedDataByFTP)
						|| (m_kCurrResponse.GetOperation() == AUTOOP_ExportAllLoggedDataByFTP))) {
			// show we are waiting for TMS
			m_eActionInProgress = opsDOWNLOAD_DATA_WAITING_FOR_TMS;
			// The export process has finished - send the finished response
			m_kCurrResponse.SetIterationStatus(AUTOOPITER_Okay);
			m_kCurrResponse.SetOverallStatus(AUTOOPOVERALL_OkayFurtherIterationNeeded);
			m_kCurrResponse.SetFilesToCopy(GetDataFilesAvailable());
			// insert the IP address of this device into the response structure
			const CCommsSetupConfig *const pkCOMMS_SETUP = pSETUP->GetCommsSetupConfig();
			if (pkCOMMS_SETUP != NULL) {
				m_kCurrResponse.SetIPAddress(pkCOMMS_SETUP->GetIPAddress());
			}
			// now convert to XML and write the file
			if (WriteResponseFile(m_kCurrResponse)) {
				QString strLogMessage("");
				strLogMessage = QString::asprintf("%u files transferred, waiting for further requests from TMS....",
						m_kCurrResponse.GetFilesToCopy());
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, strLogMessage);
			} else {
				// couldn't update the response file so we are going to have to abort the operation
				m_eActionInProgress = opsNO_OP_IN_PROGRESS;
				RemoveDownloadedDataFiles();
#ifndef V6IOTEST
				// unlock the status bar and delete any data files that may exist
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
				pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
#ifdef RDL_AUTO_OPS_DBG_ENABLE
                    QString   strDbgMsg;
                    strDbgMsg = QString::asprintf(_T("MMH::MsgType %d couldn't update the response file so SendTXSchedulerCancel "), pMsg->m_MessageType);
                    LogDebugMessage(strDbgMsg);
                    #endif
				// Send an error message to the TX scheduler which lets it know it must rollback the transaction
				// points
				SendTXSchedulerCancel();
			}
		} else if (m_eActionInProgress != opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER) {
			// error condition - not much we can do here - presumably TMS will timeout
			// and retry should it have failed in a download - there is also a possiblity a
			// cancel command was sent just as this message was being sent
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR,
					"Transfer out of sequence - should have been waiting for transfer scheduler");
		} else {
			// error condition - not much we can do here - presumably TMS will timeout
			// and retry should it have failed in a download - there is also a possiblity a
			// cancel command was sent just as this message was being sent
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "Transfer out of sequence - current operation does not match");
		}
		break;
	case MOD_AUTO_OPS_EXPORT_FINISHED:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Transfer scheduler reports transfer complete");
		// check we still think we are processing an export pen data command
		if ((m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER)
				&& ((m_kCurrResponse.GetOperation() == AUTOOP_ExportLoggedDataByFTP)
						|| (m_kCurrResponse.GetOperation() == AUTOOP_ExportAllLoggedDataByFTP))) {
			// show we are waiting for TMS
			m_eActionInProgress = opsDOWNLOAD_DATA_WAITING_FOR_TMS;
			// The export process has finished - send the finished response
			m_kCurrResponse.SetIterationStatus(AUTOOPITER_Okay);
			m_kCurrResponse.SetOverallStatus(AUTOOPOVERALL_OkayOperationComplete);
			m_kCurrResponse.SetFilesToCopy(GetDataFilesAvailable());
			CCeAutoOpsXMLHandler kXMLHandler(m_wcaAutoOpsDir, wcFTP_RESP);
			// insert the IP address of this device into the response structure
			const CCommsSetupConfig *const pkCOMMS_SETUP = pSETUP->GetCommsSetupConfig();
			if (pkCOMMS_SETUP != NULL) {
				m_kCurrResponse.SetIPAddress(pkCOMMS_SETUP->GetIPAddress());
			}
			// write the reponse information to the response file
			if (WriteResponseFile(m_kCurrResponse)) {
				QString strLogMessage("");
				strLogMessage = QString::asprintf("%u files transferred, waiting for further requests from TMS....",
						m_kCurrResponse.GetFilesToCopy());
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, strLogMessage);
			} else {
				// couldn't update the response file so we are going to have to abort the operation
				m_eActionInProgress = opsNO_OP_IN_PROGRESS;
				RemoveDownloadedDataFiles();
#ifndef V6IOTEST
				// unlock the status bar and delete any data files that may exist
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
				pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
#ifdef RDL_AUTO_OPS_DBG_ENABLE
                    QString   strDbgMsg;
                    strDbgMsg = QString::asprintf(_T("MMH::MsgType %d couldn't update the response file so SendTXSchedulerCancel "), pMsg->m_MessageType);
                    LogDebugMessage(strDbgMsg);
                    #endif
				// Send an error message to the TX scheduler which lets it know it must rollback the transaction
				// points
				SendTXSchedulerCancel();
			}
		} else {
			// error condition - not much we can do here - presumably TMS will timeout
			// and retry should it have failed in an upload - there is also a possiblity a
			// cancel command was sent just as this message was being sent
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "Transfer out of sequence - current operation does not match");
		}
		break;
	case MOD_AUTO_OPS_OKAY_TO_TIDY_UP: {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Transfer scheduler reports okay - Deleting data files");
		RemoveDownloadedDataFiles();
		// reset the tidy up variable
		m_iWaitingForTidyUpCommand = 0;
#ifndef V6IOTEST
		// send an unlock command back to the top status bar
		CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
		m_eActionInProgress = opsNO_OP_IN_PROGRESS;
	}
		break;
	case MOD_AUTO_OPS_EXPORT_ERROR: {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Transfer scheduler reports an error - Operation aborted");
		// The export process has finished - send the finished response
		m_kCurrResponse.SetIterationStatus(AUTOOPITER_Failed);
		m_kCurrResponse.SetOverallStatus(AUTOOPOVERALL_OperationFailed);
		// insert the IP address of this device into the response structure
		const CCommsSetupConfig *const pkCOMMS_SETUP = pSETUP->GetCommsSetupConfig();
		if (pkCOMMS_SETUP != NULL) {
			m_kCurrResponse.SetIPAddress(pkCOMMS_SETUP->GetIPAddress());
		}
		// now convert to XML and write the file - don't bother checking the error code as there is
		// nothing we can do if the operation fails anyway and this will be flagged in the write
		// response method anyway
		WriteResponseFile(m_kCurrResponse);
		RemoveDownloadedDataFiles();
		// reset the tidy up variable
		m_iWaitingForTidyUpCommand = 0;
#ifndef V6IOTEST
		// send an unlock command back to the top status bar
		CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
		m_eActionInProgress = opsNO_OP_IN_PROGRESS;
	}
		break;
	default:
		// not a specific method therefore pass on to the standard handler
		retValue = CV6ActiveModule::ModuleMessageHandler(pMsg);
		break;
	} // End of SWITCH
	return (retValue);
} // End of Member Function
//****************************************************************************
// void ProcessRequest( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Carries out the desired function when a message is received
///
/// @param[in] 	  AutoOpRequestInfo &rkAutoOpReqInfo - The received request that we must process
///
//****************************************************************************
void CAutoOpsProcessing::ProcessRequest(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	switch (rkAutoOpReqInfo.GetOperation()) {
	case AUTOOP_OperationNotSupportedFirstInList: {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "Unable to process request - unknown command (1st)");
	}
		break;
		// For uploading a setup, need to request permission to upload the
		// setup and then request that it be loaded into the recorder.
	case AUTOOP_RequestPermissionForUploadSetup:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Permission for upload setup request received");
		ProcessRequestPermissionForUploadSetup(rkAutoOpReqInfo);
		break;
	case AUTOOP_LoadUploadedSetup:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Load uploaded setup request received");
		ProcessLoadUploadSetup(rkAutoOpReqInfo);
		break;
		// For downloading a setup, need to request setup to be made available
		// for download, and then must indicate when it is no longer needed.
	case AUTOOP_MakeSetupAvailableForDownload:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Make setup available for download request received");
		ProcessMakeSetupAvailableForDownload(rkAutoOpReqInfo);
		break;
	case AUTOOP_RemoveSetupForDownload:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Remove downloaded setup request received");
		ProcessRemoveSetupForDownload(rkAutoOpReqInfo);
		break;
		// Downloading pen data
	case AUTOOP_ExportLCFByFTP:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Export LCF request received");
		ProcessExportLCFData(rkAutoOpReqInfo);
		break;
	case AUTOOP_ExportLoggedDataByFTP:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Export new logged data request received");
		ProcessExportLoggedData(rkAutoOpReqInfo);
		break;
	case AUTOOP_ExportAllLoggedDataByFTP:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Export ALL logged data request received");
		ProcessExportLoggedData(rkAutoOpReqInfo);
		break;
	case AUTOOP_DownloadPenDataComplete:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Download data complete request received");
		ProcessDownloadPenDataComplete(rkAutoOpReqInfo);
		break;
		// Want to be able to cancel an FTP operation.
	case AUTOOP_CancelFTPRequest:
		// the user has selected cancel to a previous operation
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Cancel request received");
		ProcessCancelRequest(rkAutoOpReqInfo);
		break;
		// Want to be able to cancel an FTP operation.
	case AUTOOP_FlushAutoOpsDirRequest:
		// the user has selected cancel to a previous operation
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Flush auto-ops directory request received");
		ProcessFlushRequest(rkAutoOpReqInfo);
		break;
		// Want to upload some new sound files
	case AUTOOP_UploadSoundFiles:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Upload sound files request received");
		ProcessUploadSoundFilesRequest(rkAutoOpReqInfo);
		break;
		// **** Always put new operations before this last one in the enumeration.
	case AUTOOP_OperationNotSupportedLastInList: {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Unable to process request - unknown command (Last)");
	}
		break;
	}
}
//****************************************************************************
// const bool CheckFTPRequestsDIR( const bool bINACTIVITY_TIMEOUT )
///
/// Method that checks the FTP directory for new requests
///
/// @param[in]		const bool bINACTIVITY_TIMEOUT - Flag indicating an inactivity
///					timeout has occurred thus meaning the system can delete the response
///					file
///
/// @return		True if a new request has just been processed
///
//****************************************************************************
const bool CAutoOpsProcessing::CheckFTPRequestsDIR(const bool bINACTIVITY_TIMEOUT) {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the AutoOps Thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
    glb_MsgCntCht = 25;
    #endif
	bool bProcessedNewRequest = false;
	// check the autoops directory for any new files
	QString wcaFTPFile;
	int iMaxPath = MAX_PATH;
	//_wcsnset_s( wcaFTPFile, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaFTPFile, sizeof(wcaFTPFile));
	pDALGLB->BuildPath(IDS_FTP, IDS_AUTO_OPS, &wcFTP_REQ, &wcaFTPFile, iMaxPath);
	CStorageNC kFTPReqFile;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
    glb_MsgCntCht = 26;
    #endif
	if (kFTPReqFile.exists(wcaFTPFile)) {
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
        glb_MsgCntCht = 27;
        #endif
		kFTPReqFile.setFileName(wcaFTPFile);
		DWORD dwFileSize = kFTPReqFile.size();
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
        glb_MsgCntCht = 28;
        #endif
		// wait a second just in case the file is still being written too - highly unlikely but belt and braces
		sleep(1000);
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the AutoOps thread
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Found new request file");
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
        glb_MsgCntCht = 29;
        #endif
		// a request file is available - read it, post the request and then delete the file
		// scope out the XML handler so we can be sure it doesn't have the file open
		// when we come to delete it
		{
			AutoOpRequestInfo kReqInfo;
			CCeAutoOpsXMLHandler kXMLHandler(m_wcaAutoOpsDir, wcFTP_REQ);
			// attempt to read the request file
			const int iMAX_READ_ATTEMPTS = 5;
			int iReadAttempts = 0;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
            glb_MsgCntCht = 30;
            #endif
			while (!kXMLHandler.ReadOperation(kReqInfo) && (iReadAttempts < iMAX_READ_ATTEMPTS)) {
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the AutoOps thread
					//after each iteration
					pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
				}
				++iReadAttempts;
				sleep(100);
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Read request failed, retrying...........");
			}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
            glb_MsgCntCht = 33;
            #endif
			// check if the operation failed
			if (iReadAttempts >= iMAX_READ_ATTEMPTS) {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "All read request attempts failed, aborted!!!!!!!");
				// set back to no operation so that other ops won't be held up
				m_eActionInProgress = opsNO_OP_IN_PROGRESS;
			} else {
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the AutoOps thread
					//after each iteration
					pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
				}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 35;
                #endif
				ProcessRequest(kReqInfo);
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Finished processing request");
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 36;
                #endif
				// delete the file
				if (kFTPReqFile.QFile::remove(wcaFTPFile)) {
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Deleted request file");
				} else {
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "Failed to delete request file!!!!!!");
				}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 38;
                #endif
			}
		}
		// set the flag indicating we processed a new request
		bProcessedNewRequest = true;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
        glb_MsgCntCht = 40;
        #endif
	} else {
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
        glb_MsgCntCht = 42;
        #endif
		// check we aren't waiting for a tidy up command from TX scheduler
		if (m_iWaitingForTidyUpCommand > 1) {
			--m_iWaitingForTidyUpCommand;
			// check the command hasn't hit 1 in which case we need to reset the status bar
			if (m_iWaitingForTidyUpCommand == 1) {
				// reset back to 0
				m_iWaitingForTidyUpCommand = 0;
#ifndef V6IOTEST
				// unlock the status bar
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
				pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
				m_eActionInProgress = opsNO_OP_IN_PROGRESS;
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
						"No reply from transfer scheduler - tidy up carried out manually");
			}
		}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
        glb_MsgCntCht = 44;
        #endif
		// check if we have an inactivity timeout
		if (bINACTIVITY_TIMEOUT) {
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the AutoOps thread
				//after each iteration
				pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
			}
			//_wcsnset_s( wcaFTPFile,sizeof(wcaFTPFile)/sizeof(WCHAR), 0, iMaxPath );
			SecureZeroMemory(wcaFTPFile, sizeof(wcaFTPFile));
			pDALGLB->BuildPath(IDS_FTP, IDS_AUTO_OPS, &wcFTP_RESP, &wcaFTPFile, iMaxPath);
			QString wcaRenamedFile = "";
			QString wcaTempName = "Temp.xm";
			pDALGLB->BuildPath(IDS_FTP, IDS_AUTO_OPS, &wcaTempName, &wcaRenamedFile, iMaxPath);
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
            glb_MsgCntCht = 46;
            #endif
			try {
				CStorageNC kTempFileCheck;
				if (kTempFileCheck.exists(wcaRenamedFile)) {
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                    glb_MsgCntCht = 48;
                    #endif
					kTempFileCheck.QFile::remove(wcaRenamedFile);
				}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 49;
                #endif
				// check it exists first
				CStorage kResponseFile;
				if (kResponseFile.exists(wcaFTPFile)) {
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                    glb_MsgCntCht = 50;
                    #endif
					CStorage::rename(wcaFTPFile, wcaRenamedFile);
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                    glb_MsgCntCht = 52;
                    #endif
					if (CStorage::QFile::remove(wcaRenamedFile)) {
						LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Inactivity timeout - deleted the response file");
					} else {
						LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
								"Inactivity timeout - could not delete the response file");
					}
					//#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
					//glb_MsgCntCht = 54;
					//#endif
				}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 56;
                #endif
			} catch (...) {
				// unhandled exception
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
						"Inactivity timeout - err - could not delete the response file");
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 58;
                #endif
			}
		}
		bProcessedNewRequest = false;
	}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
    glb_MsgCntCht = 60;
    #endif
	return bProcessedNewRequest;
}
//****************************************************************************
// const AutoOpResponseInfo SendResponse(	const AutoOpRequestInfo &rkAUTO_OP_REQ_INFO,
//											const T_AutoOpIterationStatus eITERATION_STATUS,
//											const T_AutoOpOverallStatus eOVERALL_STATUS ) const
///
/// Method that sends a response back to the auto ops directory reading for picking up
/// by the calling process (e.g. TMS)
///
///	@param[in]		const AutoOpRequestInfo &rkAUTO_OP_REQ_INFO - The original request to base the response upon
///	@param[in]		const T_AutoOpIterationStatus eITERATION_STATUS - The iteration status
///	@param[in]		const T_AutoOpOverallStatus eOVERALL_STATUS - The overall status
///
///	@return			An AutoOpResponseInfo object based on the passed in parameters
///
//****************************************************************************
const AutoOpResponseInfo CAutoOpsProcessing::SendResponse(const AutoOpRequestInfo &rkAUTO_OP_REQ_INFO,
		const T_AutoOpIterationStatus eITERATION_STATUS, const T_AutoOpOverallStatus eOVERALL_STATUS) const {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// now send the response back
	AutoOpResponseInfo kRespInfo(rkAUTO_OP_REQ_INFO);
	kRespInfo.SetIterationStatus(eITERATION_STATUS);
	kRespInfo.SetOverallStatus(eOVERALL_STATUS);
	// now convert to XML and write the file
	// insert the IP address of this device into the response structure
	const CCommsSetupConfig *const pkCOMMS_SETUP = pSETUP->GetCommsSetupConfig();
	if (pkCOMMS_SETUP != NULL) {
		kRespInfo.SetIPAddress(pkCOMMS_SETUP->GetIPAddress());
	}
	// attempt to write to the response file
	if (!WriteResponseFile(kRespInfo)) {
		// couldn't update the response file so we are going to have to abort the operation
	}
	return kRespInfo;
}
//****************************************************************************
// void CheckForTimeoutResponses( )
///
/// Method that checks if there are any lingering setup/data files and delete them
///
//****************************************************************************
void CAutoOpsProcessing::CheckForTimeoutResponses() {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
    glb_MsgCntCht = 80;
    #endif
	switch (m_eActionInProgress) {
	case opsNO_OP_IN_PROGRESS:
		// do nothing
		break;
	case opsDOWNLOAD_CFG: {
		static const UINT s_uiMAX_DOWNLOAD_CONFIG_HOLDING_TIME = 40;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
            glb_MsgCntCht = 82;
            #endif
		// check if it needs to be deleted because it has been here too long
		if (m_kCurrResponse.OperationHasExpired(s_uiMAX_DOWNLOAD_CONFIG_HOLDING_TIME * m_eCurrConnSpeed)) {
			// log the error
			QString strError("");
			QString strTimeout("");
			strTimeout = QString::asprintf("%us", s_uiMAX_DOWNLOAD_CONFIG_HOLDING_TIME * m_eCurrConnSpeed);
			strError = QString::asprintf(IDS_AUTO_OPS_FTP_DOWNLOAD_TIMEOUT_MESSAGE, strTimeout.toLocal8Bit().data());
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strError);
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, strError);
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 84;
                #endif
			// delete this response and the config file that it presumably in the config file directory
			// still
			RemoveDownloadedSetupFile();
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the AutoOps thread
				pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
			}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 86;
                #endif
		}
	}
		break;
	case opsDOWNLOAD_DATA_WAITING_FOR_TMS:
	case opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER: {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the AutoOps thread
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		// download pen data - not sure what kind of expiry we should put on this - try 5 minutes
		// for now
		static const UINT s_uiMAX_DOWNLOAD_PEN_DATA_HOLDING_TIME = 360;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
            glb_MsgCntCht = 88;
            #endif
		if (m_kCurrResponse.OperationHasExpired(s_uiMAX_DOWNLOAD_PEN_DATA_HOLDING_TIME * m_eCurrConnSpeed)) {
			// log the error
			// get the time
			LONGLONG llCURR_OP_END_TIME = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			// get the difference between the beginning and end times
			const LONGLONG llOP_DURATION = llCURR_OP_END_TIME - m_llCurrOpStartTime;
			QString strError("");
			strError = QString::asprintf(IDS_AUTO_OPS_FTP_DOWNLOAD_TIMEOUT_MESSAGE,
					CStringUtils::GetAutoDDHHMMSSspanFromSeconds(USEC_TO_SEC(llOP_DURATION), true));
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strError);
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, strError);
			// reset the start time
			m_llCurrOpStartTime = 0;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 90;
                #endif
			// check if we are waiting for the TMS in which case it is okay to delete the files
			if (m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TMS) {
				// do not delete the files now as there is a small possibility the files could be
				// in the progress of being downloaded still - instead we will always delete the files
				// when a new export request is made as this implies TMP cannot be downloading data still
#ifndef V6IOTEST
				// send an unlock command back to the top status bar
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
				pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
			}
			m_eActionInProgress = opsNO_OP_IN_PROGRESS;
#ifdef RDL_AUTO_OPS_DBG_ENABLE
                QString   strDbgMsg;
                strDbgMsg = QString::asprintf(_T("CheckForTimeOutResp::%lld timeout so SendTXSchedulerCancel "), llOP_DURATION);
                LogDebugMessage(strDbgMsg);
                #endif
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 92;
                #endif
			// send the current response back to this method
			// post a message to the export scheduler to cancel the current export
			SendTXSchedulerCancel();
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the AutoOps thread
				pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
			}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 94;
                #endif
		}
	}
		break;
	case opsUPLOAD_CFG: {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the AutoOps thread
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		static const UINT s_uiMAX_UPLOAD_CONFIG_HOLDING_TIME = 60;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
            glb_MsgCntCht = 96;
            #endif
		// check if it needs to be deleted because it has been here too long
		if (m_kCurrResponse.OperationHasExpired(s_uiMAX_UPLOAD_CONFIG_HOLDING_TIME * m_eCurrConnSpeed)) {
			// log the error
			QString strError("");
			QString strTimeout("");
			strTimeout = QString::asprintf("%us", s_uiMAX_UPLOAD_CONFIG_HOLDING_TIME * m_eCurrConnSpeed);
			strError = QString::asprintf(IDS_AUTO_OPS_FTP_UPLOAD_TIMEOUT_MESSAGE, strTimeout.toLocal8Bit().data());
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strError);
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, strError);
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 98;
                #endif
			// clean up
			RemoveUploadedSetupFile();
		}
	}
		break;
	default: {
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
                glb_MsgCntCht = 99;
                #endif
		// should not happen
	}
		break;
	}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
    glb_MsgCntCht = 100;
    #endif
}
//****************************************************************************
// const bool UploadAllowed() const
///
/// Accessor indicating if FTP uploads are permitted
///
//****************************************************************************
const bool CAutoOpsProcessing::UploadAllowed() const {
	bool bUploadAllowed = false;
	// get the comms data structure and retrieve the FTP status
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
	if (ptCommsData != NULL) {
		T_FTP *ptFTP = &ptCommsData->FTP;
		if (ptFTP->AllowUpload != FALSE) {
			bUploadAllowed = true;
		}
	}
	return bUploadAllowed;
}
//****************************************************************************
// const bool DownloadAllowed() const
///
/// Accessor indicating if FTP downloads are permitted
///
//****************************************************************************
const bool CAutoOpsProcessing::DownloadAllowed() const {
	bool bDownloadAllowed = false;
	// get the comms data structure and retrieve the FTP status
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
	if (ptCommsData != NULL) {
		T_FTP *ptFTP = &ptCommsData->FTP;
		if (ptFTP->AllowDownload != FALSE) {
			bDownloadAllowed = true;
		}
	}
	return bDownloadAllowed;
}
//****************************************************************************
//	const bool LoadConfiguration( QString wcaFileName )
///
/// Method that loads a new setup
///
/// @param[in]		QString wcaFileName - The name (inc path) of the configuration
///					file to load
///
//****************************************************************************
const bool CAutoOpsProcessing::LoadConfiguration(QString wcaFileName) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	bool bReturn = false;
#ifndef V6IOTEST
	// check the file exists before proceeding
	CStorage kConfigFile;
	if (kConfigFile.exists(wcaFileName)) {
		// clear the reboot message list within the config manager stuff
		CRecSetupCfgMgr *pkInstance = CRecSetupCfgMgr::Instance();
		pkInstance->ClearRebootList();
		// send the information to the control sequencer for further processing
		T_MOD_CFG_CHG_MSGDATA msg;
		msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
		msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
		msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_LOAD_NEW;
		CStringUtils::SafeWcsCpy(msg.fileNameAndPath, wcaFileName, MAX_PATH);
		QString strLoadConfig("");
		strLoadConfig = QWidget::tr("Configuration remotely loaded");
#if ! defined ( TTR6SETUP )
		// stop any batches that may be running - this action will have already been
		// authorised earlier
		CBatchManager *pkBatchManager = CBatchManager::Instance();
		pkBatchManager->StopAllBatches();
		// also stop any TUS's - this action wil have been authorised earlier
		CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
		pkTUSMgr->StopTUS(strLoadConfig);
#endif
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the AutoOps thread
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		if (MMMCLIENT_MESSAGE_POSTED
				== m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_CONTROL_SEQUENCER, MODULE_AUTO_OPS,
						MOD_CONFIG_CHANGE, sizeof(T_MOD_CFG_CHG_MSGDATA), (BYTE*) &msg)) {
			// log a configuration change message
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strLoadConfig);
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, strLoadConfig);
			bReturn = true;
		} else {
			// log a configuration failed to load message
			QString strError("");
			strError = QWidget::tr("Failed to transfer setup to recorder");
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strError);
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, strError);
		}
	} else {
		bReturn = false;
	}
#endif
	return bReturn;
}
//****************************************************************************
//	void ProcessRequestPermissionForUploadSetup( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes a request permission for upload setup command
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessRequestPermissionForUploadSetup(AutoOpRequestInfo &rkAutoOpReqInfo) {
#ifndef V6IOTEST
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
	//Check if the hardware security lock is enabled.
	//If yes then do not allow the user to upload the setup
	if (pDALGLB->IsHardwareLockEnabled()) {
		QString strErrorFTPMsg("");
		QString strError("");
		strErrorFTPMsg = QWidget::tr("FTP Upload Failed.");
		strError = QWidget::tr("Hardware Security Lock Enabled. Access denied.");
		QString strFTPSystemMsg("");
		strFTPSystemMsg = strErrorFTPMsg + " " + strError;
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strFTPSystemMsg);
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, strFTPSystemMsg);
		// uploads are not allowed
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedHardwareLockEnabled);
	} else if (!UploadAllowed()) {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Uploading setup's is not allowed!!!!");
		// uploads are not allowed
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedNotPermitted);
	}
	// check there is not already some action in progress
	else if (m_eActionInProgress != opsNO_OP_IN_PROGRESS) {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cannot upload setup as another operation is in progress!!!!");
		// there is some action already in progress therefore send a denied response
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedAnotherInProgress);
	}
	// check if the user is already in the UI editing
	else if (pkStatusBar->IsMenuSystemInUse()) {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cannot upload setup as the menu system is in use!!!!");
		// menu system is in use
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedUserInMenuSystem);
	} else {
		// this action is acceptable
		// check for parked configuration before sending the response
		// set the action in progress flag
		m_eActionInProgress = opsUPLOAD_CFG;
		// store the connnection speed
		m_eCurrConnSpeed = rkAutoOpReqInfo.GetConnectionSpeed();
		// lock the status bar
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_LOCK,
				static_cast<LPARAM>(CTopStatusBar::slpFTP_UPLOAD_CFG));
		CRecSetupCfgMgr *pkInstance = CRecSetupCfgMgr::Instance();
		CBatchManager *pkBatchManager = CBatchManager::Instance();
		// just deal with TUS's like a batch for now
		CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
		bool bBatchRunning = (pkBatchManager->BatchesRunning() != 0)
				|| (pkTUSMgr->GetTUSState() == CAMS2750TUSMgr::tusRUNNING);
		if (pkInstance->GetModified() || bBatchRunning) {
			T_AutoOpOverallStatus eOpReply;
			// determine the reply to send
			if (pkInstance->GetModified() && bBatchRunning) {
				eOpReply = AUTOOPOVERALL_OperationAllowedButParkedConfigAndBatchRunning;
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO,
						"Upload setup allowed but there is a parked setup and batches (or TUS) running");
			} else if (bBatchRunning) {
				eOpReply = AUTOOPOVERALL_OperationAllowedButBatchRunning;
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO,
						"Upload setup allowed but there are 1 or more batches (or TUS) running");
			} else {
				eOpReply = AUTOOPOVERALL_OperationAllowedButParkedConfigExists;
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Upload setup allowed but there is a parked setup");
			}
			// send the parked response
			m_kCurrResponse = SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay, eOpReply);
		} else {
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Upload setup allowed");
			// send the OK response
			m_kCurrResponse = SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay, AUTOOPOVERALL_OperationAllowed);
		}
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Waiting for further requests from TMS....");
	}
#endif
}
//****************************************************************************
//	void ProcessLoadUploadSetup( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes an upload setup command
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessLoadUploadSetup(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// the request to upload a setup should be safe by this point because all the tests have been
	// carried out when processing the 'AUTOOP_RequestPermissionForUploadSetup' command above
	// check the previosu command is still pending and we haven't timedout though - highly unlikely
	if (m_eActionInProgress == opsUPLOAD_CFG) {
		// check the ID's match
		if (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID()) {
			QString wcaFTPCfgFile;
			;
			pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD_CFG, &wcFTP_CONFIG_SETUP, &wcaFTPCfgFile, MAX_PATH);
			// check for failures at this point
			if (!LoadConfiguration(wcaFTPCfgFile)) {
				// send the failed resposne immediately
				SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationConfigChangeFailed);
				RemoveUploadedSetupFile();
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "Failed to load setup as the file does not exist!!!!!");
			} else {
				// the config change command is an asynchronous one therefore we can't expect the operation
				// to have completed successfully yet - the response to this event needs to be posted when
				// the config change complete function is called or a setup prepare shutdown which would
				// imply that something in the config change has forced a reboot
				// Put the response into a pending list though and remove the previous response
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Committing loaded setup...........");
				AutoOpResponseInfo kRespInfo(rkAutoOpReqInfo);
				kRespInfo.SetIterationStatus(AUTOOPITER_Okay);
				m_kCurrResponse = kRespInfo;
			}
		} else {
			// The ID's do not match therefore there must have been a timeout - send the timeout response
			SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationTimeout);
			// this is a bad situation to be in - it could possibly mean another setup has
			// begun uploading but the file will have been overwritten - do not do anything else
			// here
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "ID Mismatch - cannot load the setup");
		}
	} else {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cannot upload setup - no matching operation in progress!!!!");
		// there is no response waiting which probably indicates there has been a timeout
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationTimeout);
		RemoveUploadedSetupFile();
	}
}
//****************************************************************************
//	void ProcessMakeSetupAvailableForDownload( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes a make setup avaialbe for download command
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessMakeSetupAvailableForDownload(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// check if downloads allowed and no other operation in progress
	if ((m_eActionInProgress == opsNO_OP_IN_PROGRESS) && DownloadAllowed()) {
		CStorage kConfigFile;
		QString wcaFTPCfgFile;
		;
		pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_CFG, &wcFTP_CONFIG_SETUP, &wcaFTPCfgFile, MAX_PATH);
		kConfigFile.Open(wcaFTPCfgFile.toLocal8Bit().data(), QFile::WriteOnly);
		T_CONFIG_RETURN_VALUE eRetVal = pGlbSetup->SaveConfig(kConfigFile);
		kConfigFile.Close();
		// set the action in progress flag
		m_eActionInProgress = opsDOWNLOAD_CFG;
		// store the connection speed
		m_eCurrConnSpeed = rkAutoOpReqInfo.GetConnectionSpeed();
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Setup now available for download");
		m_kCurrResponse = SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay, AUTOOPOVERALL_OkayOperationComplete);
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Waiting for further requests from TMS....");
	} else if (m_eActionInProgress == opsNO_OP_IN_PROGRESS) {
		// downloads not allowed
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Downloading is not allowed!!!!");
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedNotPermitted);
	} else {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cannot download setup as another operation is in progress!!!!");
		// busy processing a command for someone else
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedAnotherInProgress);
	}
}
//****************************************************************************
//	void ProcessRemoveSetupForDownload( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes remove setup for download command
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessRemoveSetupForDownload(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// check this request matches the last pending download setup response
	if (m_eActionInProgress == opsDOWNLOAD_CFG) {
		// check the ID's match
		if (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID()) {
			// ID's match therefore bump the current ID off the list and delete the
			// setup file
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Removing downloaded setup file");
			// now send the response back
			SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay, AUTOOPOVERALL_OkayOperationComplete);
			RemoveDownloadedSetupFile();
			// check if we are to log a success message
			CCommsSetupConfig *pkComms = pSETUP->GetCommsSetupConfig();
			if (pkComms != NULL) {
				T_PCOMMUNICATIONS ptComms = pkComms->GetCommsBlock(CONFIG_COMMITTED);
				if (ptComms->FTP.LogMessage == TRUE) {
					// output a system message stating the operation was successful and how long it took
					QString strMessage("");
					strMessage = QWidget::tr("FTP setup transfer complete");
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strMessage,
							(ptComms->FTP.MarkChart == TRUE) ? 0 : s_byDO_NOT_MARK_CHART_SYS_MSG);
				}
			}
		} else {
			// a response has been received but it is not for the current download
			// setup operation - this can only have been caused by the timeout code deleting
			// a response because it took too long for TMP to reply -
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cannot remove downloaded setup as the operation timed out");
			SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationTimeout);
		}
	} else {
		// a response has been received but it is not for the current download
		// setup operation - this can only have been caused by the timeout code deleting
		// a response because it took too long for TMP to reply - may as well send the success
		// flag back to TMP though as the operation has been completed albeit earlier
		// now send the response back
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "ID Mismatch - cannot remove the downloaded setup");
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationTimeout);
	}
}
//****************************************************************************
//	void ProcessCancelRequest( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes a cancel request
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessCancelRequest(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// a cancel request has been received - check which task it is for a take the appropriate
	// measures - only certain operations can have a cancel posted for them so only check
	// the relevant operations
	switch (m_eActionInProgress) {
	case opsNO_OP_IN_PROGRESS:
		// do nothing
		break;
	case opsDOWNLOAD_CFG:
		// tidy up although this should never actually get called
		if (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID()) {
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Cancel request carried out successfully");
			RemoveDownloadedSetupFile();
		} else {
			// ID's do not match therefore this is an erroneous cancel command
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cancel request ignored due to ID mismatch");
		}
		break;
	case opsDOWNLOAD_DATA_WAITING_FOR_TMS:
	case opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER:
		if (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID()) {
			// check if we were waiting for the TMS in which case it is okay to delete the files
			if (m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TMS) {
				// delete this response and the config file that it presumably in the config file
				// directory still
				RemoveDownloadedDataFiles();
#ifndef V6IOTEST
				// send an unlock command back to the top status bar
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
				pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
				m_eActionInProgress = opsNO_OP_IN_PROGRESS;
			} else {
				// set the tidy up wait variable to 10 seconds
				m_iWaitingForTidyUpCommand = 10;
			}
#ifdef RDL_AUTO_OPS_DBG_ENABLE
                QString   strDbgMsg;
                strDbgMsg = QString::asprintf(_T("ProcessCancelRequest:: tidyup waiting time %lld SendTXSchedulerCancel "), m_iWaitingForTidyUpCommand);
                LogDebugMessage(strDbgMsg);
                #endif
			// post a message to the export scheduler to cancel the current export
			SendTXSchedulerCancel();
		} else {
			// ID's do not match therefore this is an erroneous cancel command
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cancel request ignored due to ID mismatch");
		}
		break;
	case opsUPLOAD_CFG:
		if (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID()) {
			// the user has selected to cancel an upload request. Presumably we must be getting a
			// cancel following a request permission call - we should clean do the clean up procedure her
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Cancel request carred out successfully");
			RemoveUploadedSetupFile();
		} else {
			// ID's do not match therefore this is an erroneous cancel command
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cancel request ignored due to ID mismatch");
		}
		break;
	default:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Request received for an unknown operation");
		break;
	}
}
//****************************************************************************
//	void ProcessFlushRequest( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes a flush request
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessFlushRequest(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// a flush request has been received - this will usually be requested because a request file has become
	// 'stuck' within the FTP directory and TMP cannot delete it remotely
	// Firstly let us attempt to delete the contents of the AutoOps directory without changing the properties
	// of the request file
	bool bProcessedNewRequest = false;
	// check the autoops directory for the notready.req request file
	QString wcaFTPFile;
	int iMaxPath = MAX_PATH;
	//_wcsnset_s( wcaFTPFile, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaFTPFile, sizeof(wcaFTPFile));
	pDALGLB->BuildPath(IDS_FTP, IDS_AUTO_OPS, &wcTEMP_FTP_REQ, &wcaFTPFile, iMaxPath);
	CStorageNC kFTPReqFile;
	bool bFileNoLongerPresent = false;
	if (kFTPReqFile.exists(wcaFTPFile)) {
		bool bFailedToDelete = true;
		// let the user know we have found one of the dodgy files
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Found notready.req file - about to attempt to delete...");
		// attempt to delete the file without making any mods to the file attributes first
		if (kFTPReqFile.QFile::remove(wcaFTPFile)) {
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO,
					"Delete operation succeeded. About to check file is no longer present...");
			if (kFTPReqFile.exists(wcaFTPFile)) {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
						"File still present. About to attempt to modify file attributes...");
			} else {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "File no longer present. Flush operation succeeded");
				bFailedToDelete = false;
				bFileNoLongerPresent = true;
			}
		} else {
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
					"Delete operation failed. About to attempt to modify file attributes...");
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the AutoOps thread
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		// check if the file has been successfully deleted yet
		if (bFailedToDelete) {
			// obtain the file attributes first and display them
			CFileStatus kFileStatus;
			/// TODO Resolve this
			if (CStorage::GetStatus(wcaFTPFile, &kFileStatus)) {
				QString strFileStatusInfo("");
				strFileStatusInfo = QString::asprintf("Current file status is %u", kFileStatus.m_attribute);
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, strFileStatusInfo);
				// attempt to modify the file attributes
				kFileStatus.m_attribute = 0;
			} else {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Failed to get file status - will set attributes regardless");
				kFileStatus.m_attribute = 0;
			}
			// now update the status
			CStorage::SetStatus(wcaFTPFile, &kFileStatus);
			// now attempt to delete again
			if (kFTPReqFile.QFile::remove(wcaFTPFile)) {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO,
						"Delete operation succeeded. About to check file is no longer present...");
				if (kFTPReqFile.exists(wcaFTPFile)) {
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "File still present. Flush operation failed");
				} else {
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "File no longer present. Flush operation succeeded");
					bFileNoLongerPresent = true;
				}
			} else {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "Delete operation failed. Flush operation failed");
			}
		} else {
			// do nothing as the file has been successfully deleted and a message reported to the user
		}
	} else {
		// let the user know we have not found one of the dodgy files
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Could not find notready.req file");
		bFileNoLongerPresent = true;
	}
	// report back whether the file was deleted or not
	if (bFileNoLongerPresent) {
		// send a generic success response
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay, AUTOOPOVERALL_OkayOperationComplete);
	} else {
		// send a generic error response
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationFailed);
	}
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// finally we must abort any kind of operation we may have been in the middle of
	switch (m_eActionInProgress) {
	case opsNO_OP_IN_PROGRESS:
		// do nothing
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "No operation to cance");
		break;
	case opsDOWNLOAD_CFG:
		// tidy up although this should never actually get called
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Cancelled download configuration operation successfully");
		RemoveDownloadedSetupFile();
		break;
	case opsDOWNLOAD_DATA_WAITING_FOR_TMS:
	case opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER: {
		// do not bother with an ID mismatch check
		// check if we were waiting for the TMS in which case it is okay to delete the files
		if (m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TMS) {
			// delete this response and the config file that it presumably in the config file
			// directory still
			RemoveDownloadedDataFiles();
#ifndef V6IOTEST
			// send an unlock command back to the top status bar
			CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
			pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
			m_eActionInProgress = opsNO_OP_IN_PROGRESS;
		} else {
			// set the tidy up wait variable to 10 seconds
			m_iWaitingForTidyUpCommand = 10;
		}
#ifdef RDL_AUTO_OPS_DBG_ENABLE
            QString   strDbgMsg;
            strDbgMsg = QString::asprintf(_T("ProcessFlushRequest:: tidyup waiting time %lld SendTXSchedulerCancel "), m_iWaitingForTidyUpCommand);
            LogDebugMessage(strDbgMsg);
            #endif
		// post a message to the export scheduler to cancel the current export
		SendTXSchedulerCancel();
	}
		break;
	case opsUPLOAD_CFG:
		// the user has selected to cancel an upload request. Presumably we must be getting a
		// flush following a request permission call - we should clean do the clean up procedure her
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Cancelled upload configuration operation successfully");
		RemoveUploadedSetupFile();
		break;
	default:
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Unknown operation to cance");
		break;
	}
}
//****************************************************************************
//	void ProcessUploadSoundFilesRequest( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes an upload soound files command
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessUploadSoundFilesRequest(AutoOpRequestInfo &rkAutoOpReqInfo) {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the AutoOps Thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// the request to upload some sound files - the system shouldn't be in the middle of a config
	// change or anything like that as this is an active module - don't need to set the operation in progress
	// flag as this op is very indendant from the rest
	if (!UploadAllowed()) {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Uploading is not allowed!!!!");
		// uploads are not allowed
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedNotPermitted);
	} else {
		bool bSuccess = true;
		CStorage kSoundFile;
		QString wcaSourcePath = "";
		QString wcaFullPath = "";
		QString ext = "*.wav";
		// build the wildcard path
		pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD, &ext, &wcaSourcePath, MAX_PATH);
		// now loop through getting the filenames and copying them over to the wavs directory
		WIN32_FIND_DATA tindexOfFileData;
		tindexOfFileData.cFileName[0] = '\0';

		// now build the source directory name which we will need to pass on to the replace sound function
		pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD, NULL, &wcaSourcePath, MAX_PATH);
        QString fileName = "";
		// insert the first valid filename found within the editbox
        QDirIterator it(wcaSourcePath, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
        // insert the first valid filename found within the editbox
        while (it.hasNext()) {
            fileName = it.next();
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the AutoOps thread
				//after each iteration
				pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
			}
			// copy the file over if we are still in a success condition
			if (bSuccess && (ReplaceSoundFile(wcaSourcePath, fileName) != ussSUCCESS)) {
				QString strError("");
				strError = QString::asprintf("Aborting as failed to copy sound file - %s!!!!",
						fileName.toLocal8Bit().data());
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, strError);
				// the copy failed so abort the operation
				SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationFailed);
				// set the error flag - continue looping though as we must delete all the uploaded
				// sound files
				bSuccess = false;
			}
			// now delete the file
			pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD, &fileName, &wcaFullPath, MAX_PATH);
			kSoundFile.QFile::remove(wcaFullPath);
			// now get the next file (if any)

		}

		// send back the success message if it all went okay
		if (bSuccess) {
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "New sounds uploaded");
			// Uploads are allowed therefore copy the files to the wavs directory
			SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay, AUTOOPOVERALL_OkayOperationComplete);
		}
#ifndef V6IOTEST
		// update the filenames
		CRecSetupCfgMgr *pkCfgMgr = CRecSetupCfgMgr::Instance();
		pkCfgMgr->LoadSoundFileNames();
#endif
	}
}
//****************************************************************************
//	static T_UPLOAD_SOUND_STATE ReplaceSoundFile(	QString wcaSourcePathName,
//													QString wcaSourceFileName )
///
/// Method responsible for replacing sound files
///\
///	@param[in]		QString wcaSourcePathName - The pathname the new file resides in
///	@param[in]		QString wcaSourceFileName - The filename of the new file
///
/// @return		True if sound was replaced
///
//****************************************************************************
const CAutoOpsProcessing::T_UPLOAD_SOUND_STATE CAutoOpsProcessing::ReplaceSoundFile(QString wcaSourcePathName,
		QString wcaSourceFileName) {
	T_UPLOAD_SOUND_STATE eState = ussSUCCESS;
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// get the first two three characters which should be "SX-" or "SXX-"
	QString strIdentifier("");
	strIdentifier = wcaSourceFileName;
	int iDelimPos = strIdentifier.indexOf(L'-', 0);
	// check the delimiter was found, it is in a valid position and the file begins with an S
	if ((iDelimPos >= 2) && (iDelimPos < 4) && (strIdentifier[0] == L'S')) {
		// valid format - check the file is not too big
		QString strSourcePath("");
		strSourcePath = wcaSourcePathName + "/" + wcaSourceFileName;
		if (QFile(strSourcePath).size() <= 102400) {
			// the file is not too big
			// move past the delimiter
			++iDelimPos;
			strIdentifier.remove(iDelimPos, strIdentifier.size() - iDelimPos);
			// now find and delete the sound file with this prefix
			WIN32_FIND_DATA tindexOfFileData;
			QString wcaDestPath = "";
			QString ext = "*.wav";
			// build the wildcard path
			pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_CUSTOM_WAVS, &ext, &wcaDestPath, MAX_PATH);
			tindexOfFileData.cFileName[0] = '\0';
            QString strFileName("");
			// insert the first valid filename found within the editbox
            QDirIterator it(wcaDestPath, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
            // insert the first valid filename found within the editbox
            while (it.hasNext()) {
                strFileName = it.next();
				int iDelimPos = strIdentifier.indexOf(L'-', 0);
				if (iDelimPos >= 2) {
					// move past the delimiter
					++iDelimPos;
					// check if the identifiers match
					if (strIdentifier == strFileName.left(iDelimPos)) {
						// this is our file, therefore delete it and drop out of the loop
						CStorage kFileToDelete;
						pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_CUSTOM_WAVS, &strFileName, &wcaDestPath, MAX_PATH);
						kFileToDelete.DeleteFile(wcaDestPath.toLocal8Bit().data());
						break;
					}
					if (pThreadInfo != NULL) {
						//Update the Thread Counter for the AutoOps thread
						pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
					}
				}

			}

			// only copy the new file over if this is not the 'delete' command which is a file called
			// "SXX-Default.wav"
			QString strDefaultWavName("");
			strDefaultWavName = strIdentifier + "Default.wav";
			if (strDefaultWavName.compare(wcaSourceFileName, Qt::CaseInsensitive) != 0) {
				pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_CUSTOM_WAVS, &wcaSourceFileName, &wcaDestPath, MAX_PATH);
                QFile::copy(strSourcePath,wcaDestPath);
			} else {
				// this is a restoration command for the default file
			}
			eState = ussSUCCESS;
		} else {
			// the file is too big
			eState = ussMAX_FILE_SIZE_EXCEEDED;
		}
	} else {
		// failed so go no further
		eState = ussINVALID_NAME;
	}
	return eState;
}
//****************************************************************************
//	void ProcessExportLCFData( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes a export LCF data request
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessExportLCFData(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// check if downloads allowed
	if (DownloadAllowed()) {
		// check we aren't already in the progress of actioning something other than a download
		// data
		if (m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TMS) {
			// a download is in progress - check the ID matches the one in progress thus meaning
			// this is a iteration of the current request
			if (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID()) {
				// delete the files already copied
				RemoveDownloadedDataFiles();
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the AutoOps thread
					//Ignore the thread when posting the message
					pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS, false);
				}
				// post a message to the export thread letting it know we need an FTP export doing
				if (MMMCLIENT_MESSAGE_COMPLETED != m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
				INFINITE, MODULE_EXPORT_SCHEDULER, MODULE_AUTO_OPS, MOD_AUTO_OPS_EXPORT_LCF, 0, NULL)) {
					if (pThreadInfo != NULL) {
						//Update the Thread Info for the AutoOps thread
						//The wait is over.We can now consider the thread
						//to be monitored byWatchDog
						pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS, true);
					}
					// somehow the message failed to be posted
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
							"Continue export message failed to be posted to transfer scheduler");
					// send a generic error response
					SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationFailed);
				} else {
					if (pThreadInfo != NULL) {
						//Update the Thread Info for the AutoOps thread
						//The wait is over.We can now consider the thread
						//to be monitored byWatchDog
						pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS, true);
					}
					m_eActionInProgress = opsDOWNLOAD_DATA_WAITING_FOR_TMS;
					// export should be begining
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "LCF Files ready for downloading");
					// update the response info
					m_kCurrResponse = SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay,
							AUTOOPOVERALL_OkayOperationComplete);
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Waiting for further requests from TMS....");
				}
			} else {
				// ID mismatch - send an error reponse
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Download LCF request ignored due to ID mismatch");
				SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedAnotherInProgress);
			}
		} else if (m_eActionInProgress == opsNO_OP_IN_PROGRESS) {
			// delete any datafiles that may still be remaining - this would only happen after a timeout on
			// a previous operation
			RemoveDownloadedDataFiles();
#ifndef V6IOTEST
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the AutoOps thread
				//Ignore the thread when posting the message
				pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS, false);
			}
			// send the begin export message to TX scheduler - setup the connection speed too
			m_eCurrConnSpeed = rkAutoOpReqInfo.GetConnectionSpeed();
			if (MMMCLIENT_MESSAGE_COMPLETED != m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
			INFINITE, MODULE_EXPORT_SCHEDULER, MODULE_AUTO_OPS, MOD_AUTO_OPS_EXPORT_LCF, 0, NULL)) {
				if (pThreadInfo != NULL) {
					//Update the Thread Info for the AutoOps thread
					//The wait is over.We can now consider the thread
					//to be monitored byWatchDog
					pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS, true);
				}
				// somehow the message failed to be posted
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
						"Download LCF message failed to be posted to transfer scheduler");
				// send a generic error response
				SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationFailed);
			} else {
				if (pThreadInfo != NULL) {
					//Update the Thread Info for the AutoOps thread
					//The wait is over.We can now consider the thread
					//to be monitored byWatchDog
					pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS, true);
				}
				// set the action in progress flag
				m_eActionInProgress = opsDOWNLOAD_DATA_WAITING_FOR_TMS;
				// lock the status bar and send the begin export message to TX scheduler
				CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
				pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 1);
				// store the time the operation was begun
				m_llCurrOpStartTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
				// export should be begining
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "LCF files ready for downloading");
				// push the response into the download config response list
				m_kCurrResponse = SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay, AUTOOPOVERALL_OkayOperationComplete);
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Waiting for further requests from TMS....");
			}
#endif
		} else {
			// there is a different request already in progress so deny
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
					"Cannot download LCF files as another operation is in progress!!!!");
			SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedAnotherInProgress);
		}
	} else {
		// downloads not allowed
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Downloading is not allowed!!!!");
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedNotPermitted);
	}
}
//****************************************************************************
//	void ProcessExportLoggedData( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes a export logged pen data request
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessExportLoggedData(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// check if downloads allowed
	if (DownloadAllowed()) {
		// check we aren't already in the progress of actioning something other than a download
		// data
		if (m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TMS) {
			// a download is in progress - check the ID matches the one in progress thus meaning
			// this is a iteration of the current request
			if (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID()) {
				// delete the files already copied
				RemoveDownloadedDataFiles();
				// post a message to the export thread letting it know we need an FTP export doing
				USHORT usMessageType = 0;
				// check if this is the first blocks of data that we wish to export
				if (rkAutoOpReqInfo.GetIterationCount() == 1) {
					// first block of data - check if export ALL or NEW
					if (AUTOOP_ExportAllLoggedDataByFTP == rkAutoOpReqInfo.GetOperation()) {
						usMessageType = MOD_AUTO_OPS_EXPORT_ALL_DATA;
					} else {
						usMessageType = MOD_AUTO_OPS_EXPORT_NEW_DATA;
					}
				} else {
					// continuation of a previous block of data - check if export ALL or NEW
					if (AUTOOP_ExportAllLoggedDataByFTP == rkAutoOpReqInfo.GetOperation()) {
						usMessageType = MOD_AUTO_OPS_CONTINUE_EXPORT_ALL;
					} else {
						usMessageType = MOD_AUTO_OPS_CONTINUE_EXPORT_NEW;
					}
				}
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the AutoOps thread
					pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
				}
				if (MMMCLIENT_MESSAGE_POSTED
						!= m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_EXPORT_SCHEDULER,
								MODULE_AUTO_OPS, usMessageType, sizeof(m_eCurrConnSpeed),
								reinterpret_cast<BYTE*>(&m_eCurrConnSpeed))) {
					// somehow the message failed to be posted
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
							"Continue download data message failed to be posted to transfer scheduler");
					// send a generic error response
					SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationFailed);
				} else {
					m_eActionInProgress = opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER;
					// export should be begining
					if (rkAutoOpReqInfo.GetIterationCount() != 1) {
						LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Continuing downloading data.....");
					} else {
						LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Download data beginning");
					}
					// update the response info
					m_kCurrResponse = SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay,
							AUTOOPOVERALL_OkayOperationIsBeingProgressed);
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Waiting for transfer scheduler....");
				}
			} else {
				// ID mismatch - send an error reponse
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Download data request ignored due to ID mismatch");
				SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedAnotherInProgress);
			}
		} else if (m_eActionInProgress == opsNO_OP_IN_PROGRESS) {
			// check the iteration count is 1
			if (rkAutoOpReqInfo.GetIterationCount() == 1) {
				// delete any datafiles that may still be remaining - this would only happen after a timeout on
				// a previous operation
				RemoveDownloadedDataFiles();
				// post a message to the export thread letting it know we need an FTP export doing
				USHORT usMessageType = 0;
				if (AUTOOP_ExportAllLoggedDataByFTP == rkAutoOpReqInfo.GetOperation()) {
					usMessageType = MOD_AUTO_OPS_EXPORT_ALL_DATA;
				} else {
					usMessageType = MOD_AUTO_OPS_EXPORT_NEW_DATA;
				}
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the AutoOps thread
					pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
				}
#ifndef V6IOTEST
				// send the begin export message to TX scheduler - let it know the connection speed too
				m_eCurrConnSpeed = rkAutoOpReqInfo.GetConnectionSpeed();
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the AutoOps thread
					pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
				}
				if (MMMCLIENT_MESSAGE_POSTED
						!= m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_EXPORT_SCHEDULER,
								MODULE_AUTO_OPS, usMessageType, sizeof(m_eCurrConnSpeed),
								reinterpret_cast<BYTE*>(&m_eCurrConnSpeed))) {
					// somehow the mesage failed to be posted
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
							"Begin download data message failed to be posted to transfer scheduler!!!!");
					// send a generic error response
					SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationFailed);
				} else {
					// set the action in progress flag
					m_eActionInProgress = opsDOWNLOAD_DATA_WAITING_FOR_TX_SCHEDULER;
					// lock the status bar and send the begin export message to TX scheduler
					CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
					pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 1);
					// store the time the operation was begun
					m_llCurrOpStartTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
					// export should be begining
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Download data beginning");
					// push the response into the download config response list
					m_kCurrResponse = SendResponse(rkAutoOpReqInfo, AUTOOPITER_Okay,
							AUTOOPOVERALL_OkayOperationIsBeingProgressed);
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Waiting for transfer scheduler....");
				}
#endif
			} else {
				// Interation count is greater than 1, therefore it is likely this is a continuation
				// of a previous request that has timed out - in this situation cancel the operation
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
						"Iteration count > 1 - it is likely a timeout has occured earlier!!!!");
				SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationTimeout);
			}
		} else {
			// there is a different request already in progress so deny
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
					"Cannot download data files as another operation is in progress!!!!");
			SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedAnotherInProgress);
		}
	} else {
		// downloads not allowed
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Downloading is not allowed!!!!");
		SendResponse(rkAutoOpReqInfo, AUTOOPITER_Failed, AUTOOPOVERALL_OperationDeniedNotPermitted);
	}
}
//****************************************************************************
//	void ProcessDownloadPenDataComplete( AutoOpRequestInfo &rkAutoOpReqInfo )
///
/// Method that processes a download pen data complete message from TMP
///
///	@param[in]		AutoOpRequestInfo &rkAutoOpReqInfo - The original request
///
//****************************************************************************
void CAutoOpsProcessing::ProcessDownloadPenDataComplete(AutoOpRequestInfo &rkAutoOpReqInfo) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	// check we think we are still downloading
	if ((m_eActionInProgress == opsDOWNLOAD_DATA_WAITING_FOR_TMS)
			&& (m_kCurrResponse.GetID() == rkAutoOpReqInfo.GetID())) {
		RemoveDownloadedDataFiles();
#ifndef V6IOTEST
		// unlock the status bar and delete any data files that may exist
		CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_DOWNLOAD_DATA, 0);
#endif
		m_eActionInProgress = opsNO_OP_IN_PROGRESS;
		// export should be ending
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Download data operation complete");
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the AutoOps thread
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		// let the tx scheduler system know the download was completed successfully so it can move its
		// validation points on
		if (MMMCLIENT_MESSAGE_POSTED
				!= m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_EXPORT_SCHEDULER, MODULE_AUTO_OPS,
						MOD_AUTO_OPS_EXPORT_FINISHED, 0, NULL)) {
			LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING,
					"Download data complete message failed to be posted to transfer scheduler");
		} else {
			// get the time
			LONGLONG llCURR_OP_END_TIME = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			// get the difference between the beginning and end times
			const LONGLONG llOP_DURATION = llCURR_OP_END_TIME - m_llCurrOpStartTime;
			// check if we are to log a success message
			CCommsSetupConfig *pkComms = pSETUP->GetCommsSetupConfig();
			if (pkComms != NULL) {
				T_PCOMMUNICATIONS ptComms = pkComms->GetCommsBlock(CONFIG_COMMITTED);
				if (ptComms->FTP.LogMessage == TRUE) {
					if (pThreadInfo != NULL) {
						//Update the Thread Counter for the AutoOps thread
						pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
					}
					// output a system message stating the operation was successful and how long it took
					QString strMessage("");
					const QString strDURATION(
							CStringUtils::GetAutoDDHHMMSSspanFromSeconds(USEC_TO_SEC(llOP_DURATION), true));
					strMessage = QString::asprintf(IDS_AUTO_OPS_FTP_DOWNLOAD_DATA_SUCCESS_MESSAGE,
							strDURATION.toLocal8Bit().data());
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strMessage,
							(ptComms->FTP.MarkChart == TRUE) ? 0 : s_byDO_NOT_MARK_CHART_SYS_MSG);
					LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, strMessage);
				}
			}
			// reset the start time
			m_llCurrOpStartTime = 0;
		}
	}
}
//****************************************************************************
//	void RemoveDownloadedDataFiles( )
///
/// Method responsible for deleting any downloaded data files and tidying up
/// any other related variables
///
//****************************************************************************
void CAutoOpsProcessing::RemoveDownloadedDataFiles() {
	CStorage kFileToDelete;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the AutoOps thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	QString wcaFullPath = "";
	QString ext = "*.dat";
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_DATA, &ext, &wcaFullPath, MAX_PATH);
	// now loop through getting the filenames and deleting them
	WIN32_FIND_DATA tindexOfFileData;
	tindexOfFileData.cFileName[0] = '\0';
    QString fileName = "";
	// insert the first valid filename found within the editbox
    QDirIterator it(wcaFullPath, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
    // insert the first valid filename found within the editbox
    while (it.hasNext()) {
        fileName = it.next();
		//Update the thread counter for AutoOps thread
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_DATA, &fileName, &wcaFullPath, MAX_PATH);
		kFileToDelete.QFile::remove(wcaFullPath);
		// now get the next file (if any)

	}

	QString ind = "LCF.Conf.index";
	// now delete the LCF files
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_DATA, &ind, &wcaFullPath, MAX_PATH);
	if (kFileToDelete.exists(wcaFullPath)) {
		kFileToDelete.QFile::remove(wcaFullPath);
	}
	ind = "LCF.Conf";
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_DATA, &ind, &wcaFullPath, MAX_PATH);
	if (kFileToDelete.exists(wcaFullPath)) {
		kFileToDelete.QFile::remove(wcaFullPath);
	}
}
//****************************************************************************
// void RemoveDownloadedSetupFile( )
///
/// Method responsible for deleting a downloaded setup file and tidying up
/// any other related variables
///
//****************************************************************************
void CAutoOpsProcessing::RemoveDownloadedSetupFile() {
	CStorage kConfigFile;
	QString wcaFTPCfgFile;
	;
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_CFG, &wcFTP_CONFIG_SETUP, &wcaFTPCfgFile, MAX_PATH);
	kConfigFile.QFile::remove(wcaFTPCfgFile);
	// reset the action in progress flag to prevent blocking other calls
	m_eActionInProgress = opsNO_OP_IN_PROGRESS;
}
//****************************************************************************
// void RemoveDownloadedSetupFile( )
///
/// Method responsible for deleting an uploaded setup file and tidying up
/// any other related variables
///
//****************************************************************************
void CAutoOpsProcessing::RemoveUploadedSetupFile() {
	// delete the setup file and reset the action in progress flag
	CStorage kConfigFile;
	QString wcaFTPCfgFile;
	;
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD_CFG, &wcFTP_CONFIG_SETUP, &wcaFTPCfgFile, MAX_PATH);
	// check if the file exists before deleting
	if (kConfigFile.exists(wcaFTPCfgFile)) {
		kConfigFile.QFile::remove(wcaFTPCfgFile);
	}
#ifndef V6IOTEST
	// unlock the status bar
	CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
	pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_UNLOCK, CTopStatusBar::slpFTP_UPLOAD_CFG);
#endif
	// reset the action in progress flag to prevent blocking other calls
	m_eActionInProgress = opsNO_OP_IN_PROGRESS;
}
//****************************************************************************
// const bool WriteResponseFile( const AutoOpResponseInfo &rkCURR_RESPONSE ) const
///
/// Method that attempts to write the reponse data to the response file
///
/// @param[in]		const AutoOpResponseInfo - the object containing the information we need to write
///
//****************************************************************************
const bool CAutoOpsProcessing::WriteResponseFile(const AutoOpResponseInfo &rkCURR_RESPONSE) const {
	bool bRetVal = false;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the AutoOps thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// attempt to write to the response file
	const int iMAX_WRITE_ATTEMPTS = 5;
	int iWriteAttempts = 0;
	CCeAutoOpsXMLHandler kXMLHandler(m_wcaAutoOpsDir, wcFTP_RESP);
	CCeAutoOpsXMLHandler::T_AUTO_OPS_XML_FILE_STATUS eStatus = CCeAutoOpsXMLHandler::aoxOK;
	while (((eStatus = kXMLHandler.WriteOperation(rkCURR_RESPONSE)) != CCeAutoOpsXMLHandler::aoxOK)
			&& (iWriteAttempts < iMAX_WRITE_ATTEMPTS)) {
		//Update the thread counter for AutoOps thread
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		++iWriteAttempts;
		// base the wait on the connection speed - this is because for a slower connection the
		// time taken for TMS to download a response file could be as long as 1 second
		sleep(150 * m_eCurrConnSpeed);
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Write response failed, retrying.................");
		// if invalid XML data the file must be corrupt therefore delete it - this could mess up any simultaneous
		// operations that maybe in progress but this is the only guaranteed way for autoops to recover
		if (eStatus == CCeAutoOpsXMLHandler::aoxINCOMPLETE_OR_INVALID_XML_DATA) {
			QString strCompleteFilename("");
			strCompleteFilename = m_wcaAutoOpsDir + "/" + wcFTP_RESP;
			if (CStorage::QFile::remove(strCompleteFilename)) {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Deleted response file");
			} else {
				LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Could not delete response file");
			}
		}
	}
	// check if the operation failed
	if (iWriteAttempts >= iMAX_WRITE_ATTEMPTS) {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_ERROR, "All write response attempts failed, aborted!!!!!!!!!!!!!!!!!");
		bRetVal = false;
	} else {
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Successfully updated response file");
		bRetVal = true;
	}
	return bRetVal;
}
//****************************************************************************
// const USHORT GetDataFilesAvailable( ) const
///
/// Method that determines how many data files are available for transfer
///
///	@returns	The number of data files available for transfer (e.g. the contents of
///				the "FTP\download\data" directory)
///
//****************************************************************************
const USHORT CAutoOpsProcessing::GetDataFilesAvailable() const {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	USHORT usFilesAvailable = 0;
	QString wcaFullPath = "";
	QString ext = "*.dat";
	// build the wildcard path
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_DATA, &ext, &wcaFullPath, MAX_PATH);
	// now loop through getting the filenames and deleting them
	WIN32_FIND_DATA tindexOfFileData;
	tindexOfFileData.cFileName[0] = '\0';
    QString fileName = "";
	// insert the first valid filename found within the editbox
    QDirIterator it(wcaFullPath, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
    // insert the first valid filename found within the editbox
    while (it.hasNext()) {
        fileName  = it.next();
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the AutoOps thread
			pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
		}
		++usFilesAvailable;
		// now get the next file (if any)
	}

	return usFilesAvailable;
}
//****************************************************************************
// const USHORT SendTXSchedulerCancel( )
///
/// Method that posts a message to the export scheduler to cancel the current export
///
//****************************************************************************
void CAutoOpsProcessing::SendTXSchedulerCancel() {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the AutoOps thread
		pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
	}
	if (MMMCLIENT_MESSAGE_POSTED
			!= m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_EXPORT_SCHEDULER, MODULE_AUTO_OPS,
					MOD_AUTO_OPS_CANCEL_EXPORT, 0, NULL)) {
		// somehow the message failed to be posted
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_WARNING, "Cancel message failed to be posted to transfer scheduler");
	} else {
		// successful but don't delete any data files now as this could crash the TX scheduler
		// instead we simply wait for a message back from TX scheduler telling us it is okay to do
		// a delete
		LOG_FTP_MESSAGE(MSGLISTSER_FTP_INFO, "Cancel request carred out successfully");
	}
}
#ifdef RDL_AUTO_OPS_DBG_ENABLE
void CAutoOpsProcessing::LogDebugMessage(QString   & strDbgMsg)
{
    if( NULL != m_pDebugFileLogger )
    {
        QString   strDiagMsg;
        strDiagMsg = QString::asprintf(_T("AutoOps - %s at GTC:%u\r\n"), strDbgMsg, GetTickCount());
        m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
    }
}
#endif

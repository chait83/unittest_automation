/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 FTP user account
/// @n CFTPUser.cpp
/// @n FTP user account class.
/// @author MM
/// @date 25/05/2006
///
/// Note:
///	This class will only work for a CE build.
/// Only one FTP user name and password is currently required/available.
// 
// *******************************************
// Revision History
// *******************************************
// $Log:
//  6 Stability Project 1.3.1.1 7/2/2011 4:57:22 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:25:24 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 9/26/2006 1:17:01 PM  Roger Dawson  
//  Modified the FTP directory to the root of the recorders internal
//  memory rather than the internal compact flahs directory.
//  3 V6 Firmware 1.2 8/4/2006 1:32:07 PM Roger Dawson  
//  Replaced wcsnset calls with _wcsnset in order to remove compilation
//  warnings.
//  2 V6 Firmware 1.1 7/14/2006 5:23:40 PM  Roger Dawson  
//  Fixed bug where FTP directories where not all being created.
//  1 V6 Firmware 1.0 7/12/2006 5:22:59 PM  Roger Dawson  
// $
//
//////////////////////////////////////////////////////////////////////
#include "Registry.h"
#include "FTPUser.h"
#include "StoragePaths.h"
#include "V6globals.h"
//****************************************************************************
/// CFTPUser service: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CFTPUser::CFTPUser() {
	hModule = NULL;
	return;
}
//****************************************************************************
/// CFTPUser service: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CFTPUser::~CFTPUser() {
	return;
}
//****************************************************************************
/// CFTPUser service: Create the default FTP user
///
/// @return			TRUE if successfull, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CFTPUser::CreateDefaultUser() {
	return CreateUser(wcDefaultFTPUserName, wcDefaultFTPPassWord);
}
//****************************************************************************
/// CFTPUser service: Check if the default FTP user account exists
///
/// @return			TRUE if account exists, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CFTPUser::DoesDefaultUserExist() {
	BOOL bResult = FALSE;
	return DoesUserExist(wcDefaultFTPUserName);
}
//****************************************************************************
/// CFTPUser service: Check if a specified FTP user account exists
///
/// @return			TRUE if account exists, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CFTPUser::DoesUserExist(const LPCTSTR lpcUserName) {
	BOOL bResult = FALSE;
#ifdef UNDER_CE
	CRegistryKey cFTPUser;
	if ( cFTPUser.OpenKey( L"Comm\\FTPD" ) )
	{
		QString   csFTPUserName;
		DWORD dwType = REG_SZ;
		DWORD dwSize = MAX_PATH;
		bResult = cFTPUser.ReadValue( L"UserList", csFTPUserName, &dwSize, dwType );
		cFTPUser.Close( );
		if ( bResult )
		{
			bResult = FALSE;
			QString   csUser( "" );
			csUser = lpcUserName;
			if ( 0 == csFTPUserName.compare( csUser ) )
				bResult = TRUE;
		}
	}
#endif
	return bResult;
}
//****************************************************************************
/// FTPUser service: Create an FTP user
///
/// @return			TRUE if successfull, else FALSE
///
/// @note This will only work on a CE build.
/// Create the user log-in account, then add the user to the FTP log-in
//****************************************************************************
BOOL CFTPUser::CreateUser(const LPCTSTR lpcUserName, const LPCTSTR lpcPassWord) {
	BOOL bResult = FALSE;
#ifdef UNDER_CE
	hModule = LoadLibrary( _T("ntlmssp.dll") );
	typedef BOOL ( *PFnSetUser )(IN LPCTSTR pszUser, IN LPCTSTR pszPassword); 
	if ( NULL != hModule )
	{
		// Create the user account and password
		PFnSetUser pFnSetUser; 
		pFnSetUser = (PFnSetUser)GetProcAddress( hModule, L"NTLMSetUserInfo" ); 
		if ( NULL != pFnSetUser )
		{
			// Create (FTP) user log-in account
			bResult = pFnSetUser( lpcUserName, lpcPassWord );
			if ( TRUE == bResult )
			{
				CRegistryKey cFTPUser;
				// Add user to the FTP server access list
				if ( cFTPUser.OpenKey( L"Comm\\FTPD" ) )
				{
					bResult = cFTPUser.WriteValue( L"UserList", (QString )lpcUserName );
					cFTPUser.Flush( );
					cFTPUser.Close( );
				}
			}
		}
		FreeLibrary( hModule );
		hModule = NULL;
	}
#endif
	return bResult;
}
//****************************************************************************
/// FTPUser service: Delete an FTP user
///
/// @return			TRUE if successfull, else FALSE
///
/// @note This will only work on a CE build.
/// Delete the user log-in account, then the FTP log-in
//****************************************************************************
BOOL CFTPUser::DeleteUser(const LPCTSTR lpcUserName) {
	BOOL bResult = FALSE;
#ifdef UNDER_CE
	hModule = LoadLibrary( _T("ntlmssp.dll") );
	typedef BOOL ( *PFnDeleteUser )(IN LPCTSTR pszUser ); 
	if ( NULL != hModule )
	{
		// Create the user account and password
		PFnDeleteUser pFnDeleteUser; 
		pFnDeleteUser = (PFnDeleteUser)GetProcAddress( hModule, L"NTLMDeleteUser" ); 
		if ( NULL != pFnDeleteUser )
		{
			// Delete (FTP) user log-in account
			bResult = pFnDeleteUser( lpcUserName );
			if ( TRUE == bResult )
			{
				CRegistryKey cFTPUser;
				// Delete the FTP server access list
				if ( cFTPUser.OpenKey( L"Comm\\FTPD" ) )
				{
					bResult = cFTPUser.DeleteValue( L"UserList" );
					cFTPUser.Flush( );
					cFTPUser.Close( );
				}
			}
		}
		FreeLibrary( hModule );
		hModule = NULL;
	}
#endif
	return bResult;
}
//****************************************************************************
/// FTPUser service: Create FTP folder structure
///
/// @note 
//****************************************************************************
void CFTPUser::CreateFolderStructure() {
	BOOL bCreated = FALSE;
	// make sure the FTP directories exist - check the memory resident one first
	WCHAR wcaFTPPaths[ MAX_PATH];
	size_t iMaxPath = MAX_PATH;
	//_wcsnset_s( wcaFTPPaths, sizeof(wcaFTPPaths)/sizeof(WCHAR), 0, iMaxPath );
	SecureZeroMemory(wcaFTPPaths, sizeof(wcaFTPPaths));
	//wmemset(wcaFTPPaths, 0, MAX_PATH);
	pDALGLB->BuildPath(IDS_FTP, IDS_AUTO_OPS, "", wcaFTPPaths, iMaxPath);
	// create the auto ops directory
	bCreated = CreateDirectory(wcaFTPPaths, NULL);
	//_wcsnset_s( wcaFTPPaths, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaFTPPaths, sizeof(wcaFTPPaths));
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_ROOT, "", wcaFTPPaths, iMaxPath);
	// create the upload directory
	if (!CreateDirectory(wcaFTPPaths, NULL)) {
		bCreated = false;
	}
	//	_wcsnset_s( wcaFTPPaths, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaFTPPaths, sizeof(wcaFTPPaths));
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD, "", wcaFTPPaths, iMaxPath);
	// create the upload directory
	if (!CreateDirectory(wcaFTPPaths, NULL)) {
		bCreated = false;
	}
	//_wcsnset_s( wcaFTPPaths, MAX_PATH,0, iMaxPath );
	SecureZeroMemory(wcaFTPPaths, sizeof(wcaFTPPaths));
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_UPLOAD_CFG, "", wcaFTPPaths, iMaxPath);
	// create the upload config directory
	if (!CreateDirectory(wcaFTPPaths, NULL)) {
		bCreated = false;
	}
	//_wcsnset_s( wcaFTPPaths, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaFTPPaths, sizeof(wcaFTPPaths));
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD, "", wcaFTPPaths, iMaxPath);
	// create the download directory
	if (!CreateDirectory(wcaFTPPaths, NULL)) {
		bCreated = false;
	}
	//_wcsnset_s( wcaFTPPaths, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaFTPPaths, sizeof(wcaFTPPaths));
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_CFG, "", wcaFTPPaths, iMaxPath);
	// create the download config data directory
	if (!CreateDirectory(wcaFTPPaths, NULL)) {
		bCreated = false;
	}
	//_wcsnset_s( wcaFTPPaths, MAX_PATH, 0, iMaxPath );
	SecureZeroMemory(wcaFTPPaths, sizeof(wcaFTPPaths));
	pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_DATA, "", wcaFTPPaths, iMaxPath);
	// create the download data directory
	if (!CreateDirectory(wcaFTPPaths, NULL)) {
		bCreated = false;
	}
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Automated Operations
/// @n Filename:	AutoOpResponseInfo.h
/// @n Description: AutoOpResponseInfo class header.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  11  Stability Project 1.8.1.1 7/2/2011 4:55:32 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  10  Stability Project 1.8.1.0 7/1/2011 4:27:46 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  9 V6 Firmware 1.8 4/19/2007 5:27:44 PM  Roger Dawson  
//  Fixed a problem where some auto ops commands were being rejected
//  because they were higher values than the last in the last value. 
//  8 V6 Firmware 1.7 3/23/2007 2:48:51 PM  Charles Boardman
//  Updating comment about latest evailable enum - helpful because the
//  enums are not in order.
// $
//
// **************************************************************************
#pragma once
#if ! defined ( __AUTOOPRESPONSEINFO_H__ )
#define __AUTOOPRESPONSEINFO_H__
// AutoOpInfo
#include "AutoOpInfo.h"
// Enumerated type for identifying the overall status of an operation.
typedef enum tagAutoOpOverallStatus {
	// **** Always place new overall statii after this first enumeration.
	AUTOOPOVERALL_InvalidStatusFirstInList = 0,
	/// Indicate that the operation has completed successfully.
	AUTOOPOVERALL_OkayOperationComplete = 1,
	// Indicate thet the current iteration of the operation has completed
	// successfully but at least one more iteration is required before
	// the operation can complete.
	AUTOOPOVERALL_OkayFurtherIterationNeeded = 2,
	// Indicate that the request has been acknowledged and is being progressed.
	// This can be used for operations that may take some time.
	AUTOOPOVERALL_OkayOperationIsBeingProgressed = 3,
	// Possible answers when requesting permission for uploading a setup.
	AUTOOPOVERALL_OperationAllowedButParkedConfigExists = 4,
	AUTOOPOVERALL_OperationAllowed = 5,
	AUTOOPOVERALL_OperationDeniedAnotherInProgress = 6,
	AUTOOPOVERALL_OperationDeniedNotPermitted = 7,
	AUTOOPOVERALL_OperationDeniedUserInMenuSystem = 8,
	AUTOOPOVERALL_OperationConfigChangeFailed = 9,
	AUTOOPOVERALL_OperationCompleteRebootRequired = 10,
	AUTOOPOVERALL_OperationAllowedButBatchRunning = 13,
	AUTOOPOVERALL_OperationAllowedButParkedConfigAndBatchRunning = 14,
	AUTOOPOVERALL_OperationDeniedHardwareLockEnabled = 15,
	// Indicate the operation has timed out because TMS did not complete the current operation
	// in a timely fashion
	AUTOOPOVERALL_OperationTimeout = 11,
	// General failure message for internal failures within the reocrder that cannot be described easily
	// e.g. the active module messages not getting posted correctly
	AUTOOPOVERALL_OperationFailed = 12,
	/// NEXT AVAILABLE ENUM IS 15. PLEASE UPDATE ME AS YOU ADD ENUMS AND DO NOT REUSE NUMBERS
	/// BELONGING TO DELETED ENUMS OR ANYTHING LIKE THAT
	AUTOOPOVERALL_InvalidStatusLastInList = 16
} T_AutoOpOverallStatus;
// Enumerated type for the iteration status of an operation.
typedef enum tagAutoOpIterationStatus {
	// **** Always place new overall statii after this first enumeration.
	AUTOOPITER_InvalidStatusFirstInList = 0,
	AUTOOPITER_Okay = 1,
	AUTOOPITER_Failed = 2,
	/// NEXT AVAILABLE ENUM IS 3. PLEASE UPDATE ME AS YOU ADD ENUMS AND DO NOT REUSE NUMBERS
	/// BELONGING TO DELETED ENUMS OR ANYTHING LIKE THAT
	AUTOOPITER_InvalidStatusLastInList
} T_AutoOpIterationStatus;
//** AutoOpResponseInfo ******************************************************
///
/// @brief Describes a response to an operation.. It extends AutoOpInfo.
/// 
/// AutoOpResponseInfo extends AutoOpInfo and encapsulates the data for 
/// describing the response of an operation.
///
//****************************************************************************
class AutoOpResponseInfo: public AutoOpInfo {
public:
	//-------- Construction / Destruction --------
	AutoOpResponseInfo();
	AutoOpResponseInfo(const AutoOpResponseInfo &aResponse);
	AutoOpResponseInfo(const AutoOpInfo &anOp);
	AutoOpResponseInfo(T_AutoOp anOp);
	virtual ~AutoOpResponseInfo(void);
	// Assignment operator
	AutoOpResponseInfo& operator=(const AutoOpResponseInfo &rhs);
public:
	//-------- Public methods --------
	// Add name/value pairs.
	virtual BOOL AddTagValuePair(const QString &strTag, const QString &strValue);
	// Get the overall status.
	T_AutoOpOverallStatus GetOverallStatus(void) const;
	// Set the overall status.
	BOOL SetOverallStatus(T_AutoOpOverallStatus overallStatus);
	// Set the number of files to copy.
	void SetFilesToCopy(const USHORT usFILES_TO_COPY) {
		m_usFilesToCopy = usFILES_TO_COPY;
	}
	// Get the number of files to copy
	const USHORT GetFilesToCopy() const {
		return m_usFilesToCopy;
	}
	// Get the iteration status.
	T_AutoOpIterationStatus GetIterationStatus(void) const;
	// Set the iteration status.
	BOOL SetIterationStatus(T_AutoOpIterationStatus iterationStatus);
protected:
	//-------- Protected methods --------
	//-------- Protected data members --------
private:
	//-------- Private constants ------
	static const QString StrTagNameOverallStatus;
	static const QString StrTagNameIterationStatus;
	static const QString StrTagNameFilesToCopy;
	//-------- Private methods --------
	//-------- Private data members --------
	T_AutoOpIterationStatus m_IterationStatus;
	T_AutoOpOverallStatus m_OverallStatus;
	USHORT m_usFilesToCopy;
};
#endif // __AUTOOPRESPONSEINFO_H__

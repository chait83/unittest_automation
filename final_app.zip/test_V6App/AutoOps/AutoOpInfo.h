/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Automated Operations
/// @n Filename:	AutoOpInfo.h
/// @n Description:	AutoOpInfo class declaration.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Stability Project 1.9.1.1 7/2/2011 4:55:32 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.9.1.0 7/1/2011 4:27:45 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  V6 Firmware 1.9 7/10/2007 5:05:31 PM  Roger Dawson  
//  Added some of the FTP 'export all' functionality. Work still to be
//  done to TX scheduler to make it work though.
//  9 V6 Firmware 1.8 12/21/2006 4:51:21 PM  Roger Dawson  
//  Added the ability to load in new sound files.
// $
//
// **************************************************************************
#pragma once
#if ! defined ( __AUTOOPINFO_H__ )
#define __AUTOOPINFO_H__
// QVector
#include <QString>
#include "Defines.h"
#include <QVector>
// Typedefs
typedef QVector<QString> CAutoOpStringArray;
// Enumerated type for identifying the operation to be performed.
typedef enum tagAutoOp {
	// **** Always place new operations after this first enumeration.
	AUTOOP_OperationNotSupportedFirstInList = 0,
	// For uploading a setup, need to request permission to upload the 
	// setup and then request that it be loaded into the recorder.
	AUTOOP_RequestPermissionForUploadSetup = 1,
	AUTOOP_LoadUploadedSetup = 2,
	// For downloading a setup, need to request setup to be made available
	// for download, and then must indicate when it is no longer needed.
	AUTOOP_MakeSetupAvailableForDownload = 3,
	AUTOOP_RemoveSetupForDownload = 4,
	AUTOOP_ExportLCFByFTP = 8,
	AUTOOP_ExportLoggedDataByFTP = 5,
	AUTOOP_ExportAllLoggedDataByFTP = 11,
	AUTOOP_DownloadPenDataComplete = 6,
	// Want to be able to cancel an FTP operation.
	AUTOOP_CancelFTPRequest = 7,
	// Want to be able to flush the AutoOp directories operation. This would usually be following 
	// some kind of error where the notready.req file has become stuck on the recorder
	AUTOOP_FlushAutoOpsDirRequest = 9,
	// Want to upload some new default sounds to the recorder
	AUTOOP_UploadSoundFiles = 10,
	/// NEXT AVAILABLE ENUM IS 12. PLEASE UPDATE ME AS YOU ADD ENUMS AND DO NOT REUSE NUMBERS
	/// BELONGING TO DELETED ENUMS OR ANYTHING LIKE THAT
	AUTOOP_OperationNotSupportedLastInList = 12
} T_AutoOp;
//** AutoOpInfo **************************************************************
///
/// @brief AutoOpInfo class contains the basic data for automated operations.
/// 
/// The AutoOpInfo class contains the basic information required to describe
/// an automated operation. Specifically, an identification string, the
/// operation itself ( T_AutoOp ) and an iteration count.
///
/// The class contains support to generate UUID as operation IDs so that they
/// can almost certainly relied upon to be unique - no point in countenancing
/// the improbable occasion when an ID is not unique. The iteration count is
/// to enable transactional operations that may not complete in one go, such
/// as FTP of logged data.
///
//****************************************************************************
class AutoOpInfo {
public:
	//-------- Construction / Destruction --------
	AutoOpInfo();
	AutoOpInfo(const AutoOpInfo &anAutoOpInfo);
	AutoOpInfo(T_AutoOp theOp);
	AutoOpInfo(T_AutoOp theOp, const QString &strOpID);
	AutoOpInfo(T_AutoOp theOp, UUID *theUuid);
	AutoOpInfo(T_AutoOp theOp, UUID &theUuid);
	virtual ~AutoOpInfo();
	// Assignment operator
	AutoOpInfo& operator=(const AutoOpInfo &rhs);
public:
    // Set ID for the operation.
	BOOL SetID(const QString &strID);
	// Get ID for the operation
	QString GetID(void) const;
	// Set the IP address of the machine creating this operation.
	BOOL SetIPAddress(const QString &strIPAddress);
	// Get the IP address of the machine that created this operation.
	QString GetIPAddress(void) const;
	// Set the NetBIOS name of machine that this operation originated from.
	BOOL SetNetBIOSName(const QString &strNetBIOSName);
	// Get the NetBIOS name of the machine that operation originated from.
	QString GetNetBIOSName(void) const;
	// Set the operation type.
	BOOL SetOperation(T_AutoOp theOp);
	// Get the operation type.
	T_AutoOp GetOperation(void) const;
	// Set the iteration count of the operation.
	BOOL SetIterationCount(int iterationCount);
	// Get the iteration count of the operation.
	unsigned long GetIterationCount(void) const;
	unsigned long IncrementIterationCount(void);
	// Add a pair of values, tag name and value.
	virtual BOOL AddTagValuePair(const QString &strTag, const QString &strValue);
	// Get the tag value pairs other than the operation, the operation id
	// and the iteration count.
	virtual BOOL GetSupplementaryTagValuePairs(CAutoOpStringArray &arrStrTagName,
			CAutoOpStringArray &arrStrTagValue) const;
	// Get tag value pairs for the named tag, which will exclude the operation,
	// operation id, iteration count, ip address and netbios name.
	virtual int GetSupplementaryTagValuePairs(const QString &strReferenceTag, CAutoOpStringArray &arrStrTagValue) const;
	// Method used to identify if this operation has expired due to a response timeout
	const bool OperationHasExpired(const USHORT usTIMEOUT_PERIOD) const;
protected:
	//-------- Protected methods --------
	//-------- Protected data members --------
	// ID for the operation.
	QString m_strID;
	// IP address of the machine that generated this operation.
	QString m_strIPAddress;
	// NetBIOS name of the machine that generated this operation.
	QString m_strNetBIOSName;
	// Iteration counter which can be used for transactional operations that
	// require more than one iteration to complete.
	unsigned long m_IterationCounter;
	// The operation to perform.
	T_AutoOp m_TheOp;
private:
	//-------- Private constants --------
	static const QString StrTagNameID;
	static const QString StrTagNameIPAddress;
	static const QString StrTagNameNetBIOSName;
	static const QString StrTagNameOperation;
	static const QString StrTagNameIterationCount;
	static const QString StrDefaultIPAddress;
	static const QString StrDefaultNetBIOSName;
	//-------- Private methods --------
	// Generate an ID.
	void GenerateID(void);
	//-------- Private data members --------
	// The time (in milliseconds) at which the operatio was set - used for 
	// checking the age of an operation
	DWORD m_dwTimeOperationSet;
	// Arrays of tag value pairs.
	CAutoOpStringArray m_arrStrTags;
	CAutoOpStringArray m_arrStrValues;
};
#endif // __AUTOOPINFO_H__

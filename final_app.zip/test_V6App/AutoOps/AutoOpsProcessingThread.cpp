/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Automated Operations
/// @n Filename:  AutoOpsProcessingThread.cpp
/// @n Description: Implementation for the CAutoOpsProcessingThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  8 Aristos  1.2.1.3.1.0 9/19/2011 4:51:07 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  7 Stability Project 1.2.1.3 7/2/2011 4:55:33 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.2.1.2 7/1/2011 4:37:58 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 Stability Project 1.2.1.1 3/17/2011 3:20:10 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "AutoOpsProcessingThread.h"
#include "AutoOpsProcessing.h"
#include "ThreadInfo.h"
#include "V7DbgLogDefines.h"
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
extern ULONG	glb_MsgCntCht;
#endif
// IMPLEMENT_DYNCREATE(CAutoOpsProcessingThread, QThread)
//****************************************************************************
// CAutoOpsProcessingThread()
///
/// Destructor
///
//****************************************************************************
CAutoOpsProcessingThread::CAutoOpsProcessingThread() {
}
//****************************************************************************
// ~CAutoOpsProcessingThread()
///
/// Destructor
///
//****************************************************************************
CAutoOpsProcessingThread::~CAutoOpsProcessingThread() {
}
//****************************************************************************
// BOOL InitInstance() 
///
/// Init Instance method
///
//****************************************************************************
BOOL CAutoOpsProcessingThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
//****************************************************************************
// int ExitInstance() 
///
/// Exit Instance method
///
//****************************************************************************
int CAutoOpsProcessingThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	QThread::exit();
	return 0;
}
//****************************************************************************
/// Thread Function that checks for new automatic operations
///
/// @param[in] 	  lpParam - Pointer to the parent CAutoOpsProcessing class
///
/// @return 0x00 - Thread Exit Successful
/// @n 0xFF - Thread could not operate correctly and has terminated
///
//****************************************************************************
#include "V6globals.h"
UINT CAutoOpsProcessingThread::ThreadFunc(LPVOID lpParam) {
	// Constant to represent Thread Exit Code Successful
	const UINT uiAUTO_OPS_THREAD_EXIT_SUCCESSFUL = 0x00;
	// Constant to represent Thread Exit Code failed
	const UINT uiAUTO_OPS_THREAD_OPERATIONAL_FAILURE = 0xFF;
	// The slow thread update interval in milliseconds
	const UINT uiAUTO_OPS_THREAD_TIMEOUT_INTERVAL = 1000;
	// the variables below are used for providing a timeout which indcates we haven't received
	// any request for some time and ew can therefore delete the response file should one exist
	UINT uiInactivityIntervalCount = 0;
	const UINT uiINACTIVITY_DELETE_FILES_COUNT = 360;
	// Thread Exit Code 
	UINT threadExitCode = uiAUTO_OPS_THREAD_OPERATIONAL_FAILURE;
	// Pointer to the automated operations active module
	CAutoOpsProcessing *pkAutoOps = static_cast<CAutoOpsProcessing*>(lpParam);
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Notify that the WatchdogTimer that the AutoOpsProcessing thread has 
	//started
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS, true);
	}
#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CAutoOpsProcessingThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
	#endif
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
	glb_MsgCntCht = 1;
#endif
	// santy check
	if ( NULL != pkAutoOps) {
		// Loop shall remain active until the automated operations thread is required to Exit
		while (aopOPMODE_EXIT != pkAutoOps->GetOperationalState()) {
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
			glb_MsgCntCht = 5;
			#endif
			// Wait for either a System Message, or a timeout occured meaning we must
			// check for any new automated operation files
			switch (pkAutoOps->EventMessageHandler(uiAUTO_OPS_THREAD_TIMEOUT_INTERVAL)) {
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the AutoOpsProcessing
				//thread 
				pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
			}
		case V6ACTMOD_EVENT_TIMEOUT:
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
				glb_MsgCntCht = 8;
				#endif
			// check we are in normal operation otherwise a setup change or something 
			// similar may be in progress
			if (aopOPMODE_NORMAL_OPERATION == pkAutoOps->GetOperationalState()) {
				bool bInactivityTimeout = false;
				// timeout therefore increment the fast interval counbt and check if the slow
				// interval needs restoring
				if (uiInactivityIntervalCount == uiINACTIVITY_DELETE_FILES_COUNT) {
					// timeout therefore trigger the deletion of the response file should 
					// it exist
					bInactivityTimeout = true;
					++uiInactivityIntervalCount;
				} else if (uiInactivityIntervalCount < uiINACTIVITY_DELETE_FILES_COUNT) {
					// no timeout but keep incrementing
					++uiInactivityIntervalCount;
				}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
					glb_MsgCntCht = 10;
					#endif
				// check the FTP directory for new requests
				if (pkAutoOps->CheckFTPRequestsDIR(bInactivityTimeout)) {
					// just processed a request therefore reset the inactivity timer
					uiInactivityIntervalCount = 0;
				}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
					glb_MsgCntCht = 12;
					#endif
				// check if there are any lingering setup/data files and delete them
				pkAutoOps->CheckForTimeoutResponses();
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
					glb_MsgCntCht = 14;
					#endif
			}
			break;
		case V6ACTMOD_OK:
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
				glb_MsgCntCht = 16;
				#endif
			break;
		default: /* Do Nothing */
			break;
			} // End of SWITCH
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the AutoOpsProcessing
				//thread after each iteration
				pThreadInfo->UpdateThreadCounter(AM_AUTO_OPS);
			}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
			glb_MsgCntCht = 18;
			#endif
		} // End of WHILE 
		// exiting but we have been running successfully
		threadExitCode = uiAUTO_OPS_THREAD_EXIT_SUCCESSFUL;
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
		glb_MsgCntCht = 20;
		#endif
	} // End of IF
	//Update the info that the AutoOpsProcessing thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_AUTO_OPS);
	}
#ifdef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
	glb_MsgCntCht = 1000;
#endif
	return (threadExitCode);
} // End of Member Function

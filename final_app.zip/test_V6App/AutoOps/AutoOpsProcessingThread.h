/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Automated Operations
/// @n Filename:  AutoOpsProcessingThread.h
/// @n Description: Declaration for the CAutoOpsProcessingThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:55:33 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 7/12/2006 5:20:36 PM  Roger Dawson  
// $
//
// **************************************************************************
#ifndef _AUTO_OPS_PROCESSING_THREAD_H
#define _AUTO_OPS_PROCESSING_THREAD_H
#include <QThread>
#include "Defines.h"
//**CAutoOpsProcessingThread**************************************************
/// 
/// @brief Thread responsible for checking whether there are any automated
/// operation files that need processing
///
/// Thread responsible for checking whether there are any automated
/// operation files that need processing
///
//****************************************************************************
class CAutoOpsProcessingThread: public QThread {
	// DECLARE_DYNCREATE (CAutoOpsProcessingThread)
protected:
	// Protected constructor used by dynamic creation
	CAutoOpsProcessingThread();
	// Destructor
	virtual ~CAutoOpsProcessingThread();
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	/// Thread Function that checks for new automatic operations
	static UINT ThreadFunc(LPVOID lpParam);
protected:
	// Generated message map functions
	//{{AFX_MSG(CAutoOpsProcessingThread)
	//}}AFX_MSG
};
// End of Class Declaration
#endif // _AUTO_OPS_PROCESSING_THREAD_H

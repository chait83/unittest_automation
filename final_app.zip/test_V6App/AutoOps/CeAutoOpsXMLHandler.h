/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Automated Operations
/// @n Filename:  CeAutoOpsXMLHandler.h
/// @n Description: Declaration for the CCeAutoOpsXMLHandler class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:55:56 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:25:24 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 10/5/2006 6:47:30 PM  Roger Dawson  
//  Added code that obtains the number of files present for a data file
//  transfer and stores it within the XML response so it may be read by
//  TMP. Also added the file information to the relevant FTP status
//  messages.
//  4 V6 Firmware 1.3 9/26/2006 1:15:24 PM  Roger Dawson  
//  Added code to delete old responses/requests once the file gets above
//  5KB in size.
// $
//
// **************************************************************************
#if !defined(AFX_CEAUTOOPSXMLHANDLER_H__DED4C55A_D449_4FFD_9B7A_64BFB36F09A9__INCLUDED_)
#define AFX_CEAUTOOPSXMLHANDLER_H__DED4C55A_D449_4FFD_9B7A_64BFB36F09A9__INCLUDED_
#include <QFile>
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#ifdef UNICODE
#include "CStorage.h"
#endif
#include "AutoOpRequestInfo.h"
#include "AutoOpResponseInfo.h"
//** CCeAutoOpsXMLHandler ********************************************************
///
/// @brief	CCeAutoOpsXMLHandler handles all XML read/write for automated operations on the
///			recorder only
/// 
/// CCeAutoOpsXMLHandler handles all XML read/write for automated operations on the
///	recorder only
///
//****************************************************************************
class CCeAutoOpsXMLHandler:
#ifdef UNICODE
	public CStorage 
#else
		public QFile
#endif
{
public:
	/// Enum describing the various error conditions that could be experienced
	enum T_AUTO_OPS_XML_FILE_STATUS {
		aoxOK,
		aoxFILE_DOES_NOT_EXIST,
		aoxFILE_LOCKED,
		aoxCOULD_NOT_OPEN_FILE,
		aoxCOULD_NOT_LOAD_XML_DATA,
		aoxINVALID_FILE_LENGTH,
		aoxINCOMPLETE_OR_INVALID_XML_DATA,
		aoxCOULD_NOT_WRITE_FILE,
		aoxCOULD_NOT_FIND_OP_ID
	};
	// Constructor
	CCeAutoOpsXMLHandler(const QString &rstrDIRECTORY_NAME, const QString &rstrFILE_NAME);
	// Destructor
	virtual ~CCeAutoOpsXMLHandler();
	// Method that writes a response file based on the passed in response class parameters
	virtual const T_AUTO_OPS_XML_FILE_STATUS WriteOperation(const AutoOpResponseInfo &rkRESPONSE_INFO);
	// Method that writes a request file based on the passed in request class parameters
	virtual const T_AUTO_OPS_XML_FILE_STATUS WriteOperation(const AutoOpRequestInfo &rkREQUEST_INFO);
	// Method that reads a request within a request file and populates the passed in request
	// class accordingly
	virtual BOOL ReadOperation(AutoOpRequestInfo &rkRequestInfo);
	// Method that reads a response within a response file and populates the passed in response
	// class accordingly
	virtual BOOL ReadOperation(AutoOpResponseInfo &rkResponseInfo, const QString &rstrID = QString(""));
	// Method that deletes a response/request operation from the response/request file
			const T_AUTO_OPS_XML_FILE_STATUS DeleteOperation(const QString &rstrID, const bool bREQUEST);
private:
	//-------- Private constants --------
	static const QString ms_strTagResponse;
	static const QString ms_strTagRequest;
	static const QString ms_strTagIPAddress;
	static const QString ms_strTagNetBIOSName;
	static const QString ms_strTagOperation;
	static const QString ms_strTagConnectionSpeed;
	static const QString ms_strTagIterationCount;
	static const QString ms_strTagOverallStatus;
	static const QString ms_strTagIterationStatus;
	static const QString ms_strTagFilesToCopy;
	static const QString ms_strAttributeID;
	static const QString ms_strRootTagResponses;
	static const QString ms_strRootTagRequests;
	//--------- Private Varaibles --------
	// Path of directory that file resides in.
	QString m_strDirectoryPath;
	// Name of file containing the XML to read or write.
	QString m_strFilename;
	/// Store for the contents of the XML file - assumes the file is never going to
	/// be excessively large (>64K)
	QString m_strXMLData;
	//-------- Private methods --------
	// Method that loads the entire contents of the XML file
	const T_AUTO_OPS_XML_FILE_STATUS LoadXML();
	// Method that writes the entire contents of the XML file
	const T_AUTO_OPS_XML_FILE_STATUS WriteXML();
	// Method that shows file exception errors
    void ShowError(QFileDevice::FileError &kEx);
	// Method that finds the position of the passed in XML tag within the pased in data
	const long indexOfTagInfo(const QString &rstrDATA_TO_SEARCH, const QString &rstrSEARCH_TAG, const long lSEEK_POS,
			const bool bSTART_TAG = true) const;
	// Method that extracts the request information contained within the passed in positions
	const T_AUTO_OPS_XML_FILE_STATUS ExtractRequestInfo(AutoOpRequestInfo &rkRequestInfo,
			const QString &rstrREQUEST_INFO) const;
	// Method that extracts the response information contained within the passed in positions
	const T_AUTO_OPS_XML_FILE_STATUS ExtractResponseInfo(AutoOpResponseInfo &rkResponseInfo,
			const QString &rstrRESPONSE_INFO) const;
	// Method that extract the operation information contained within the passed in positions
	const T_AUTO_OPS_XML_FILE_STATUS ExtractBaseInfo(AutoOpInfo &rkBaseInfo, const QString &rstrOPERATION_INFO) const;
	// Method that extracts the ID information contained within the passed in string
	const T_AUTO_OPS_XML_FILE_STATUS GetTagValue(const QString &rstrTAG, QString &rstrValue,
			const QString &rstrXML_DATA) const;
	// Method that inserts the response information contained within the passed in response into the
	// XML file
	const T_AUTO_OPS_XML_FILE_STATUS InsertResponseInfo(const AutoOpResponseInfo &rkRESPONSE_INFO,
			QString &rstrResponseInfo);
	// Method that inserts the request information contained within the passed in response into the
	// XML file
	const T_AUTO_OPS_XML_FILE_STATUS InsertRequestInfo(const AutoOpRequestInfo &rkREQUEST_INFO,
			QString &rstrRequestInfo);
	// Method that inserts the response information contained within the passed in class into an XML
	// data string
	void AddBaseXMLInfo(const AutoOpInfo &rkBASE_INFO, QString &rstrOperationInfo) const;
	// Method that inserts the response information contained within the passed in class
	// into an XML data string
	void AddResponseXMLInfo(const AutoOpResponseInfo &rkRESPONSE_INFO, QString &rstrResponseInfo) const;
	// Method that inserts the request information contained within the passed in class
	// into an XML data string
	void AddRequestXMLInfo(const AutoOpRequestInfo &rkREQUEST_INFO, QString &rstrRequestInfo) const;
	// Method that deletes the response/request information from the XML data that matches the passed in ID
	const T_AUTO_OPS_XML_FILE_STATUS DeleteInfo(const QString &rstrID, QString &rstrXMLData, const bool bREQUEST);
	// Method that removes any old operations from the current XML file
	const T_AUTO_OPS_XML_FILE_STATUS RemoveOldOperations(const QString &rstrPARENT_TAG, const QString &rstrTAG_TO_FIND);
};
#endif // !defined(AFX_CEAUTOOPSXMLHANDLER_H__DED4C55A_D449_4FFD_9B7A_64BFB36F09A9__INCLUDED_)

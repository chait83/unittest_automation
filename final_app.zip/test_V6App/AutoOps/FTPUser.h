#ifndef __FTP_USER_H_INCLUDED__
#define __FTP_USER_H_INCLUDED__
#pragma once 
#include "Defines.h"
// Default FTP username and password
const LPCTSTR wcDefaultFTPUserName = "aristosftp";
const LPCTSTR wcDefaultFTPPassWord = "R!ngw00d00";
//**Class*********************************************************************
///
/// @brief FTP user account class
/// 
///
//****************************************************************************
class CFTPUser {
public:
	CFTPUser();
	~CFTPUser();
	BOOL DoesDefaultUserExist();
	BOOL DoesUserExist(const LPCTSTR lpcUserName);
	BOOL CreateDefaultUser();
	BOOL CreateUser(const LPCTSTR lpcUserName, const LPCTSTR lpcPassWord);
	BOOL DeleteUser(const LPCTSTR lpcUserName);
	void CreateFolderStructure();
private: // date
	BOOL m_Initialised;
	HANDLE hModule;
};
#endif // __FTP_USER_H_INCLUDED__

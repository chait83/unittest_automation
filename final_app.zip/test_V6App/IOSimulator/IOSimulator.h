/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  IOSimulator
/// @n Filename:  IOSimulator.h
/// @n Description: Class Declaration for the IOSimulator
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:58:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:27:31 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 3/2/2006 5:03:09 PM Roger Dawson  
//  Replaced repetitive code that sets up the demo channels.
//  1 V6 Firmware 1.0 5/27/2005 9:59:22 PM  Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _IOSIMORDER_H
#define _IOSIMORDER_H
#include "AnaloguePulseDemoBoard.h"
#include "V6ActiveModule.h"
const USHORT IOSIM_ZERO = 0; ///< Represents the Value of Zero
const USHORT IOSIM_INVALID_CHANNEL_NUMBER = 0xFFFF; ///< Invalid Channel Number
/// Enumeration for Member function Return Values to indicate success and failure conditions
typedef enum _eIOSimReturnValue {
	IOSIM_OK, IOSIM_INITIALISATION_FAILED, IOSIM_AP_SETUP_FAILED
} T_IOSIM_RETURN_VALUE;
/// Enumeration for Enabling and Disabling Demo Boards.
typedef enum _eIOSimBoardEnabled {
	IOSIM_BOARD_ENABLED, IOSIM_BOARD_DISABLED
} T_IOSIM_BOARD_ENABLED_STATUS;
/// Enumeration for the Operational mode of the Message List Processing Module
typedef enum _eIOSimOperationalMode {
	IOSIM_OPMODE_IDLE, IOSIM_OPMODE_NORMAL_OPERATION, IOSIM_OPMODE_EXIT
} T_IOSIM_OPERATIONAL_MODE;
//**Class*********************************************************************
///
/// @brief Input / Output Simulator for the V6 Project
/// 
/// This class provides the functionality for Simulating a V6 Recorder, in
/// terms of Analogue / Pulse and Digital Boards. Functionality is provided to 
/// allow Channel Data to be simulated, and pushed through the system to allow
/// other modules to operate correctly. The IO Simulator will drive the 
/// Pre Process Queues, providing coverage for the Data Processing Module. The IO
/// Simulator works from the Device Capabilities and CMM to allow Configuration 
/// Changes to take place. Channel and Boards are configurable providing
/// functionality and flexibility. The IO Simulator is driven by the Current
/// System Time, providing a reliable means of populating the Pre Process Queues.
/// Using the System Time also ensures that the Demo Channels are always ahead in
/// terms of coverage than the Physical Channels. This means that PPQ coverage
/// is not effected by running Physical and Demo Boards together.  
///
//****************************************************************************
class CIOSimulator: public CV6ActiveModule {
public:
	/// Constructor
	CIOSimulator(const T_MODULE_ID moduleId);
	/// Destructor
	virtual ~CIOSimulator(void);
	/// Initialise Device Capabilities for Demostration Boards
	T_IOSIM_RETURN_VALUE InitialiseDemoBoardDevCaps(void);
	/// Periodic Update of the IO Simultor to service the Demo Boards and Demo Channels
	T_IOSIM_RETURN_VALUE UpdateIOSimulator(void);
	/// Get the Operational State of the IO Simulator
	T_IOSIM_OPERATIONAL_MODE GetOperationalState(void) const {
		return (m_OperationalMode);
	}
	/// Primary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	/// Secondary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	/// Method called when Module goes into Normal Operation
	virtual T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	/// Method called when Module is to prepare for Setup Config Change 
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	/// Method called when Module is to carry out Setup Change Completion
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	/// Method called when a Module is to prepare for Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	/// Method called when a Module is to Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE Shutdown(void);
private:
	// --- Private Member Functions --- //
	/// Initialise the Demo Recorder for Operation
	T_IOSIM_RETURN_VALUE Initialise(const USHORT deviceType);
	/// Initialise the Analogue / Pulse Demo Boards
	T_IOSIM_RETURN_VALUE InitialiseAnaloguePulseBoards(void);
	/// Initialise the Digital Demo BoardsBoards 
	T_IOSIM_RETURN_VALUE InitialiseDigitalBoards(void);
	/// Setup both Analogue / Pulse and Digital Demo Boards for Operation
	T_IOSIM_RETURN_VALUE SetupBoards(void);
	/// Setup the Analogue/Pulse Demo Boards for Operation
	T_IOSIM_RETURN_VALUE SetupAnaloguePulseBoards(void);
	/// Get the First System Channel Number as known by the end user.  
	USHORT GetFirstSystemChannelNumber(const USHORT slotNumber);
	/// Reset the IO Simulator to Default State
	T_IOSIM_RETURN_VALUE ResetBoards(void);
	/// Set the State of the IO Simulator 
	void SetOperationalState(const T_IOSIM_OPERATIONAL_MODE newState) {
		m_OperationalMode = newState;
	}
	// --- Private Member Variables --- // 
	T_IOSIM_OPERATIONAL_MODE m_OperationalMode; ///< Operational Mode for the Module
	USHORT m_NumOfAnaloguePulseBoards;  ///< Number of Analogue Pulse Boards Available
	USHORT m_NumOfDigitalBoards; ///< Number of Digital Boards Avaliable
	LONGLONG m_IOSimulatorSystemTick;  ///< IO Simulator System Tick which has been processed up until 
	/// An array of Analogue/Pulse Demo Boards that the recorder can have, the array
	/// is constructed dynamically due to the number of boards available are different
	/// between MINI and MULTI Recorders. 
	CAnaloguePulseDemoBoard *m_pAnaloguePulseDemoBoard;
	/// A Dynamic Array to indicated which Analogue/Pulse Demo Boards are Enabled
	T_IOSIM_BOARD_ENABLED_STATUS *m_pAnaloguePulseBoardEnabled;
};
// End of Class Declaration
#endif // _IOSIMORDER_H

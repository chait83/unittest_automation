/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  IO Simulator
/// @n Filename:  IOSimulatorThread.h
/// @n Description: Class Declaration for IO Simulator Thread
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:58:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:31 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 5/27/2005 9:59:22 PM  Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _IOSIMULATORTHREAD_H
#define _IOSIMULATORTHREAD_H
//**Class*********************************************************************
/// Thread to Periodically Simulate Channel Data and Process Control
/// Sequencer Message. 
/// 
//****************************************************************************
class CIOSimulatorThread: public QThread {
	// DECLARE_DYNCREATE (CIOSimulatorThread)
protected:
	CIOSimulatorThread();  // protected constructor used by dynamic creation
	virtual ~CIOSimulatorThread();
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	/// Thread Function
	static UINT ThreadFunc(LPVOID lpParam);
protected:
};
// End of Class Declaration
#endif // _IOSIMULATORTHREAD_H

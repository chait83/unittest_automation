/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  IO Simulator
/// @n Filename:  AnaloguePulseDemoBoard.cpp
/// @n Description: Implementation File for Analogue Pulse Demo Board 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  8 Stability Project 1.3.1.3 7/2/2011 4:55:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:37:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:09 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:02:09 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "AnaloguePulseDemoBoard.h"
#include "V6globals.h"
#include "PPQManager.h"
#include "BoardChannelCommonDefines.h"
//****************************************************************************
/// Constructor
///
//****************************************************************************
CAnaloguePulseDemoBoard::CAnaloguePulseDemoBoard(void) {
	USHORT AIChannels = BRDCHANDEF_CHANNELS_PER_AP_BOARD;
	// Initialise Member Variables to Default Values
	for (USHORT channelIndex = APDEMOBRD_ZERO; channelIndex < AIChannels; ++channelIndex) {
		m_ChannelCurrentTick[channelIndex] = APDEMOBRD_ZERO;
	} // End of FOR
	m_BoardTick = APDEMOBRD_ZERO;
} // End of Constructor
//****************************************************************************
/// Destructor
///
//****************************************************************************
CAnaloguePulseDemoBoard::~CAnaloguePulseDemoBoard(void) {
} // End of Destructor
//****************************************************************************
/// Initialise the Board to Default Variables, and get the board an indentity
/// with reagrd to the slot this board represents. The Associated Channels for
/// the Board are also initialised for First Time Use.
///
/// @param[in] 	 slotNumber - Slot Number the Board Represents
/// @param[in]  firstChannelNumber - First System Channel Number for this Board( One Based ) 
///
/// @return APDEMOBRD_OK - Analogue/Pulse Board Initialisation was Successful
/// 
/// @note Initialise shall only be called Once. 
//****************************************************************************
T_APDEMOBRD_RETURN_VALUE CAnaloguePulseDemoBoard::Initialise(const USHORT slotNumber, const USHORT firstChannelNumber) {
	T_APDEMOBRD_RETURN_VALUE retValue = APDEMOBRD_OK;  // Membrr Function Return Value
	USHORT AIChannels = BRDCHANDEF_CHANNELS_PER_AP_BOARD;
	m_SlotNumber = slotNumber;
	// Initialise Each Channel that is associated with the Board
	for (USHORT channelIndex = 0; channelIndex < AIChannels; ++channelIndex) {
		m_AnaloguePulseChannel[channelIndex].Initialise(firstChannelNumber + channelIndex, slotNumber, channelIndex);
	} // End of FOR
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Sets the Demo Board to the configuration stored within the CMM, the setup
/// of the board is undertaken everytime a setup change is made to the CMM.
///
/// @param[in] 	systemTick  - Current System Tick
/// @param[in] boardType - Type of Board( ANALOGUE, HIPULSE, LOPULSE )
/// @param[in] boardBaseTickInHZ - Board Base Tick Rate (400HZ, 80HZ, 50HZ ) 
///
/// @return APDEMOBRD_INVALID_CHANNEL_TYPE - Invalid Channel Type for Board
/// APDEMOBRD_OK  - Board has been Setup Correctly
/// 
/// @todo Add Pulse Channel Calls
///
//****************************************************************************
T_APDEMOBRD_RETURN_VALUE CAnaloguePulseDemoBoard::SetupBoard(const LONGLONG systemTick,
		const T_BRDCHANDEF_ANALOGUEPULSE_BOARD_TYPE boardType,
		const T_BRDCHANDEF_INPUT_CARD_TICK_RATE boardBaseTickInHZ) {
	T_APDEMOBRD_RETURN_VALUE retValue = APDEMOBRD_OK;  // Member Function Return Value
	USHORT AIChannels = BRDCHANDEF_CHANNELS_PER_AP_BOARD;
	USHORT CMMAIAcqRate;
	T_AICHANNEL *pAIChannel = NULL; // Pointer to the CMM AI Channel Information 
	m_BoardType = boardType;
	m_BoardBaseTickInHZ = boardBaseTickInHZ;
	// Setup Each Channel and Channel PPQ for all Channels associated with the Board   
	for (USHORT channelNumber = 0; channelNumber < AIChannels; ++channelNumber) {
		USHORT selectedChannelType = pGlbSetup->GetIOSetupConfig()->GetChannelSelectedType(m_SlotNumber, channelNumber,
				CONFIG_COMMITTED);
		// Setup the Channel based on its Type   
		switch (selectedChannelType) {
		case CHANNEL_AI:
			pAIChannel = pGlbSetup->GetIOSetupConfig()->GetAnalogueInput(m_SlotNumber, channelNumber, CONFIG_COMMITTED);
			if (NULL != pAIChannel && TRUE == pAIChannel->Enabled) {
				pSETUP->GetIOSetupConfig()->QueryAIAcqRate(CONFIG_COMMITTED, m_SlotNumber, channelNumber,
						&CMMAIAcqRate);
				retValue = SetupBoardChannel(systemTick, channelNumber, CMMAIAcqRate, pAIChannel->EngZero,
						pAIChannel->EngSpan);
			} // End of IF
			break;
		case CHANNEL_PULSE:
		case CHANNEL_DIG_PULSE:
			break;
		default:
			retValue = APDEMOBRD_INVALID_CHANNEL_TYPE;
			break;
		} // End of SWITCH  
	} // End of FOR
	return (retValue);
} // End of Member Function  
//****************************************************************************
/// The Demo Wave Class requires the Source Tick Rate in ticks( 1/100 ) per
/// second. This value is calculated by using the Board Base Tick Rate, and
/// the Acquisition Rate of the Channel. This member function is responsible
/// for performing the required calculation. 
///
/// @param[in] 	acquisitionRate - Channel Acqusition Rate 
///
/// @return Source Tick Rate to be used for Configuring Demo Waves
///
//****************************************************************************
INT CAnaloguePulseDemoBoard::GetAISourceTickRate(const USHORT acquisitionRate) const {
	INT sourceTickRate = APDEMOBRD_ZERO;
	T_BRDCHANDEF_ACQUSITION_RATE acqRate = CardAcqRateToDemoBoardAcqRate(acquisitionRate);
	sourceTickRate = BRDCHANDEF_INPUT_CARD_TICK_COVERAGE[acqRate][m_BoardBaseTickInHZ];
	// When Board Base Tick Rate is 400Hz, we need to divide down to 100Hz for the
	// sourceTickRate to be set correctly.
	if (BRDCHANDEF_INPUT_CARD_TICK_RATE_400HZ == m_BoardBaseTickInHZ) {
		sourceTickRate = static_cast<INT>(sourceTickRate / BRDCHANDEF_SYSCLKRATE_TO_ANALOGCLKRATE_CNV);
	} // End of IF
	return (sourceTickRate);
} // End of Member Function
//****************************************************************************
/// Setup a specific Board Channel for Operation, this involves setting up the
/// Channel Class with the correct Demo Data to simulate an input, together with
/// acquiring a Pre Process Queue to populate for the Data Processing to work
/// with.  
///
/// @param[in] systemTick - System Tick used Synchronise the Pre Process Queues
/// @param[in] channelNumber - Channel to Setup
/// @param[in] channelAcqRate - Acquisition Rate of the Channel 
/// @param[in] zero  - Zero engineering value of the Channel
/// @param[in] channelNumber - Span engineering value of the Channel
///
/// @return APDEMOBRD_OK  - Setup Board Channel Successful
/// APDEMOBRD_SETUP_CHANNEL_FAILED - Setup Board Channel Failed
/// 
//****************************************************************************
T_APDEMOBRD_RETURN_VALUE CAnaloguePulseDemoBoard::SetupBoardChannel(const LONGLONG systemTick,
		const USHORT channelNumber, const UINT channelAcqRate, const FLOAT zero, const FLOAT span) {
	T_APDEMOBRD_RETURN_VALUE retValue = APDEMOBRD_SETUP_CHANNEL_FAILED;  // Member Function Return Value
	// --- Setup the Channel, according to the CMM
	// Obtain a Pointer to the Demo Channel Information stored within the CMM
	T_DEMOCHANNEL *pDemoChannel = pGlbSetup->GetIOSetupConfig()->GetDemoChannel(m_SlotNumber, channelNumber,
			CONFIG_COMMITTED);
	// Set the Channel using the parameter passed in, together with the Demo Channel Information
	m_AnaloguePulseChannel[channelNumber].SetupChannel(CardAcqRateToDemoBoardAcqRate(channelAcqRate), zero, span,
			static_cast<FLOAT>(pDemoChannel->Noise), static_cast<T_DEMOWAVE_TYPES>(pDemoChannel->WaveType),
			pDemoChannel->WaveDuration, GetAISourceTickRate(channelAcqRate));
	// --- Request, Enable and Sync PPQ to allow readings to be processed on Demo Boards
	CPPQManager *pPPQManager = CPPQManager::GetHandle();  // PPQManager Pointer
	if (NULL != pPPQManager) {
		USHORT hPPQ = PPQC_INVALID_REFERENCE;  // Pre Process Queue Handler 
		if (PPQSER_OK == pPPQManager->m_APPPQServices.RequestPPQ(hPPQ)) {
			pPPQManager->m_APPPQServices.EnablePPQ(hPPQ, static_cast<T_PPQC_QUEUE_TYPE>(m_BoardType),
					m_AnaloguePulseChannel[channelNumber].GetChannelReference(),
					static_cast<T_PPQC_ACQUSITION_RATE>(CardAcqRateToDemoBoardAcqRate(channelAcqRate)),
					static_cast<T_PPQC_APCARD_TICK_RATE>(m_BoardBaseTickInHZ));
			pPPQManager->m_APPPQServices.SyncPPQ(hPPQ, APDEMOBRD_ZERO, systemTick);
			// Set Channel PPQ Handler
			m_AnaloguePulseChannel[channelNumber].SetPPQHandler(hPPQ);
			retValue = APDEMOBRD_OK;
		} // End of IF
	} // End of IF 
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// This Member Function simulates that Data is available for a given board. 
/// The board maintains its own Tick Rate, dependant on the Board Type. The 
/// Elapsed System Ticks are converted into the Board Tick Rate, and
/// added to the Board Tick. Each Channel maintains a tick which represents the
/// tick of the last reading added. This is required as the acquistion rate of
/// each Channel will vary the number of readings that can be added. The Channel
/// tick is only incremented by the number of readings that can be added, to avoid 
/// data loss. The board Tick will always increase, proportional to the elapsed 
/// system ticks.  
/// Through comparing the current Board tick with the Channel Tick, the number of 
/// simulated readings to be added to the Pre Process Queue can be determined. 
/// The Pre Process Queues for the Simulated Channels are always populated up to 
/// the current system tick. This ensures that the Demo Channels always have more 
/// coverage than the Physical Channels, and will not impact coverage available on 
/// Physical Channels.  
///
/// @param[in] elapsedSystemTicks - Number of Elasped Ticks from last call
///
/// @return Number of Ticks Between Board Tick and Channel Tick
/// 
//****************************************************************************
T_APDEMOBRD_RETURN_VALUE CAnaloguePulseDemoBoard::ProcessBoardData(const LONGLONG elapsedSystemTicks) {
	T_APDEMOBRD_RETURN_VALUE retValue = APDEMOBRD_OK;
	USHORT AIChannels = BRDCHANDEF_CHANNELS_PER_AP_BOARD;
	m_BoardTick +=
			static_cast<USHORT>(elapsedSystemTicks * BRDCHANDEF_SYS_TICK_TO_INPUT_CARD_TICK[m_BoardBaseTickInHZ]);
	for (USHORT channelNumber = APDEMOBRD_ZERO; channelNumber < AIChannels; ++channelNumber) {
		if (APDEMOCHAN_CHANNEL_ENABLED == m_AnaloguePulseChannel[channelNumber].GetChannelStatus()) {
			USHORT numOfReadings = CalculateNumOfReadings(channelNumber);
			if (APDEMOBRD_NO_READINGS != numOfReadings) {
				USHORT acqRate = m_AnaloguePulseChannel[channelNumber].GetAcquisitionRate();
				// First Reading requires a TimeStamp to be assoicated
				m_AnaloguePulseChannel[channelNumber].ProcessFirstReading(m_ChannelCurrentTick[channelNumber]);
				// Add Additional Readings
				m_AnaloguePulseChannel[channelNumber].ProcessAdditionalReadings(numOfReadings - APDEMOBRD_ONE_READING);
				// Implement the Channel Tick by the number of ticks per reading multipled by the number
				// of readings added. 
				m_ChannelCurrentTick[channelNumber] +=
						(BRDCHANDEF_INPUT_CARD_TICK_COVERAGE[acqRate][m_BoardBaseTickInHZ] * numOfReadings);
			} // End of IF
		} // End of IF
	} // End of FOR
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Calculates the Number of Readings for a given Channel that has elapsed
/// between the Channel Tick and Board tick. The Number of Readings is 
/// calculated by using the Channel Acquisiton Rate and Board Base tick Rate.
/// i.e( A channel @2HZ with a Base Tick Rate of 400HZ, 1 reading = 200 Ticks )
///
/// @param[in] channelNumber - Channel Number to find out the Number of Readings
///
/// @return Number of Ticks Between Board Tick and Channel Tick
/// 
//****************************************************************************
USHORT CAnaloguePulseDemoBoard::CalculateNumOfReadings(const USHORT channelNumber) {
	// Acquisition Rate of the Channel Number 
	T_BRDCHANDEF_ACQUSITION_RATE acqRate = m_AnaloguePulseChannel[channelNumber].GetAcquisitionRate();
	// Number of Ticks one reading represents based on the acqusition rate and board base tick rate 
	USHORT ticksPerReading = BRDCHANDEF_INPUT_CARD_TICK_COVERAGE[acqRate][m_BoardBaseTickInHZ];
	// Calculate the Number of Ticks between the Channel and Board Tick
	SHORT tickDifference = CalculateTickDifference(m_ChannelCurrentTick[channelNumber]);
	// Calculate the number of readings, this calculation will round down and is the desired behaviour.
	// Remaining ticks will be carried forward and processed the next time around. 
	return (static_cast<USHORT>(tickDifference / ticksPerReading));
} // End of Member Function
//****************************************************************************
/// Calculate the Tick Difference between the Channel Tick and Board Tick,
/// calculation takes into account the Board tick might have wrapped and the necessary
/// adjustments are made. 
///
/// @param[in] 	  channelTick - current Tick of the Channel
///
/// @return Number of Ticks Between Board Tick and Channel Tick
/// 
//****************************************************************************
SHORT CAnaloguePulseDemoBoard::CalculateTickDifference(const USHORT channelTick) {
	SHORT tickDifference = APDEMOBRD_ZERO;  ///< Calculated Digital Input Tick Difference
	if (channelTick < m_BoardTick) {
		// Analogue / Pulse Input Clock has wrapped
		tickDifference = static_cast<SHORT>(BRDCHANDEF_MAX_CLOCK_TICK - channelTick + m_BoardTick);
	} else {
		// Analogue / Pulse Input Clock has NOT wrapped
		tickDifference = static_cast<SHORT>(m_BoardTick - channelTick);
	} // End of IF
	return (tickDifference);
} // End of Member Function 
//****************************************************************************
/// Convert the Board Acquisition Rate to Demo Board Acquisition Rate for a
/// given Board Type. 
///
/// @param[in] acqusitionRate - Board Acquisition Rate to be Converted
///
/// @return Converted Acqusition Rate
/// 
/// @todo Add Pulse Card and Digital Pulse Conversions
//****************************************************************************
T_BRDCHANDEF_ACQUSITION_RATE CAnaloguePulseDemoBoard::CardAcqRateToDemoBoardAcqRate(const USHORT acqusitionRate) const {
	T_BRDCHANDEF_ACQUSITION_RATE convertedAcqRate = BRDCHANDEF_1HZ;
	switch (m_BoardType) {
	case BRDCHANDEF_ANALOGUE:
		switch (acqusitionRate) {
		case AI_ACQ_RATE_2HZ:
			convertedAcqRate = BRDCHANDEF_2HZ;
			break;
		case AI_ACQ_RATE_5HZ:
			convertedAcqRate = BRDCHANDEF_5HZ;
			break;
		case AI_ACQ_RATE_10HZ:
			convertedAcqRate = BRDCHANDEF_10HZ;
			break;
		case AI_ACQ_RATE_50HZ:
			convertedAcqRate = BRDCHANDEF_50HZ;
			break;
		default:
			convertedAcqRate = BRDCHANDEF_2HZ;
			break;
		} // End of SWITCH
		break;
	case BRDCHANDEF_HIPULSE:
		break;
	case BRDCHANDEF_LOPULSE:
		break;
	default:
		convertedAcqRate = BRDCHANDEF_1HZ;
		break;
	} // End of Switch
	return (convertedAcqRate);
} // End of Member Function 
//****************************************************************************
/// Reset the Board and Associated Channels to Default State, to allow the 
/// board to be setup to a known configuration. 
///
/// @param[in] - NONE
///
/// @return APDEMOBRD_OK - Board Reset Successfully 
/// 
//****************************************************************************
T_APDEMOBRD_RETURN_VALUE CAnaloguePulseDemoBoard::ResetBoard(void) {
	USHORT AIChannels = BRDCHANDEF_CHANNELS_PER_AP_BOARD;
	// Reset Each Associated Board Channel
	for (USHORT channelIndex = APDEMOBRD_ZERO; channelIndex < AIChannels; ++channelIndex) {
		m_AnaloguePulseChannel[channelIndex].ResetChannel();
		m_ChannelCurrentTick[channelIndex] = APDEMOBRD_ZERO;
	} // End of FOR
	// Reset Board Specific Member Variables 
	m_BoardTick = APDEMOBRD_ZERO;
	return (APDEMOBRD_OK);
} // End of Member Function

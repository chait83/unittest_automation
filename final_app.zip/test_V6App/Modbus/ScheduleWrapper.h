// SchaduleWrapper.h: ModBus master schedule wrapper.
//////////////////////////////////////////////////////////////////////
#if !defined(__SCHEDULEWRAPPER_H__)
#define __SCHEDULEWRAPPER_H__
#include <QMutex>
#include "MbusRtuMasterProtocol.hpp"
#include "MbusAsciiMasterProtocol.hpp"
#include "MbusTcpMasterProtocol.hpp"
#include "MbusRtuOverTcpMasterProtocol.hpp"
#include "ModBusCommon.h"
#include "SlaveDevice.h"
#include "TV6Timer.h"
//#include "Transaction_Wrapper.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Data structures:
// Master Schedule
// The main communications schedule, built from the CV Table
typedef struct {
	BOOL Assigned;				// Schedule entry has been assigned
	USHORT DeviceInstance;			// Slave device instance
	USHORT StartAddress;			// ModBus register start address
	T_eDataRequest RequestType;			// ModBus device register map (3/4/?)
	USHORT BlockSize;				// Data type to read (USHORT, FLOAT... )
	T_eDirection Direction;				// Data direction (This can be derived from RequestType)
	void *Buffer;				// Source/target data buffer
} T_MASTER_SCHEDULE_ENTRY;
// Wrapper for the main ModBus schedule
class CModBusSchedule {
public:		// methods
    static CModBusSchedule* GetHandle();					///< Singleton constructor
	void Initialise();														///< Singleton initialisation
	CModBusSchedule();
	~CModBusSchedule();
	void Destroy();
	BOOL IsEnabled();											// Check is the ModBus master is available and enabled
	void CleanUp();												///< Clean-up the schedule work space before destruction
//	void InitialiseSchedule( );												///< Initialise the schedule date
	void BuildSchedule();													///< Build the schedule
	void RunMasterSchedule();												///< Perform a single pass of the dchedule
	static float* ReadModBusDataItem(USHORT Device, USHORT Transaction, USHORT Item);
	float* ReadDataItem(USHORT Device, USHORT Transaction, USHORT Item);
	static BOOL IsMasterRegisterValid(USHORT Device, USHORT Transaction, USHORT Item);
	BOOL IsRegisterValid(USHORT Device, USHORT Transaction, USHORT Item);
	ULONG ReadMessageCount(USHORT Device);
	ULONG ReadErrorCount(USHORT Device);
	ULONG GetTimeToService(USHORT Device) {
		return m_SlaveDevice[Device].TimeToService();
	}
	;
	T_eErrorState GetDeviceState(USHORT Device) {
		return m_SlaveDevice[Device].ErrorState();
	}
	;
	T_eCommsPort GetDevicePort(USHORT Device) {
		return m_SlaveDevice[Device].Port();
	}
	;
	WCHAR* GetDeviceName(USHORT Device) {
		return m_SlaveDevice[Device].Name();
	}
	;
	BOOL IsSlaveEnabled(USHORT Device) {
		return m_SlaveDevice[Device].Used();
	}
	;
	USHORT DeviceTransactionCount(USHORT Device) {
		return m_SlaveDevice[Device].NumTransactions();
	}
	;
	ULONG GetOveRunTime() {
		return m_OverRunTime;
	}
	;
	ULONG GetQuietTime() {
		return m_QuietTime;
	}
	;
	ULONG GetRunTime() {
		return m_RunTime;
	}
	;
	void BuildTestData();									///< Test method (no longer used or required)
public:		// data
private:	// methods
	void SlaveRead(T_PMODBUSSLAVEDEV pSlaveData, USHORT DeviceInstance, USHORT TransactionInstance);
	void ReadError(T_PMODBUSSLAVEDEV pSlaveData, USHORT DeviceInstance);
	void SlaveWrite(T_PMODBUSSLAVEDEV pSlaveData, USHORT DeviceInstance, USHORT TransactionInstance);
private:	// data
	static CModBusSchedule *pInstance;						///< Single instance  object pointer
    static QMutex hCreationMutex;							///< Object creation mutex
	CTV6Timer *m_ScheduleTimer;								///< Schedule elapsed timer
	CModBusSlaveDevice m_SlaveDevice[MODBUSMASTER_SLAVE_SIZE];
	T_PMODBUSMASTER m_pMasterConfig;
	byte m_Buffer[MAX_BUFFER_SIZE];							// Data transfer buffer
	ULONG m_ScheduleTime;									// Schedule time in ms			
	ULONG m_QuietTime;								// Scheduler quiet time (time left after the schedule is complete)
	ULONG m_OverRunTime;									// Scheduler overrun time (additional time required)
	ULONG m_RunTime;										// Schedule run time
};
#endif // !defined(__SCHEDULEWRAPPER_H__)

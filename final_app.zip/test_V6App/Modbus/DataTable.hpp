/// @file 
/// *****************************************************************
///  Honeywell Trendview
/// *****************************************************************
/// @n Module  : ModBus Slave
/// @n FileName: DataTable.hpp
/// @n Desc  : ModBus data table
///   
/// *****************************************************************
/// Revision History
/// *****************************************************************
/// $Log[4]$
///
#ifndef _MODBUSDATATABLE_H_INCLUDED
#define _MODBUSDATATABLE_H_INCLUDED
#ifndef __cplusplus
#  error Must use C++ to compile this module!
#endif
// Platform header
#include <stdio.h>
#include <string.h>
#include "DiagnosticDataTable.hpp"
#include "Defines.h"
// Package header
#include "MbusDataTableInterface.hpp"
typedef enum {
	FP_B, FP_BB, FP_L, FP_LB
} FLOAT_ORDER;
/*****************************************************************************
 * DiagnosticMbusDataTable class declaration
 *****************************************************************************/
/**
 * @brief This base class implements a Modbus<sup>&reg;</sup> slave server.
 *
 * These methods apply to all protocol flavours via inheritance. For a more
 * detailed description see section @ref mbusslave.  It provides functions
 * to start-up, run and shutdown a Modbus server.  The server processes
 * data and control functions received from a Modbus master. This
 * implementation implements all functions of conformance class 0 and class
 * 1.  In addition some frequently used funtions of conformance class 2 are
 * also implemented. This rich function set enables a user to solve nearly
 * every Modbus data transfer problem.
 *
 * @ingroup mbusslave
 * @version 1.0
 * @see MbusSlaveServer
 * @see mbusslave
 */
// Modbus map: Based on the standard Honeywell register map
// Digitals		1-49
// Analogue In	6145-6241	
// Comm Pens	6273-6337
// Pens			6337-6529
// Totals		6913-7041
// ExComm Pens	9217-9409	
//
// Device ID	61440-61442
//
// Note:
//	If anyone wishes to use a pulse input card in a digital slot, the value can
//	only be returned by mapping the input to a pen.
//
#define	MOD_DIG_START			(1-1)			// (1/2) Digital I/O								// 0x0001
#define MOD_DIG_LEN				49				// 49 digital inputs
#define MOD_ANALOGUE_START		(6145-1)		// (3/4) Analogue inputs.							// 0x1800
#define MOD_ANALOGUE_LEN		96				// 48 in total.
#define MOD_COMPEN_START		(6273-1)		// (3/4) Comms Pens fed back into recorder.			// 0x1880
#define MOD_COMPEN_LEN			64				// 32 in total.
#define MOD_PEN_START			(6337-1)		// (3/4) Maths Pens. 								// 0x18C0
#define MOD_PEN_LEN				192				// 96 in total.
#define MOD_TOTALS_START		(6913-1)		// (3/4) Totalisers.								// 0x1B00
#define MOD_TOTALS_LEN			128				// 64 in total.
#define MOD_EXCOMPEN_START		(9217-1)		// (3/4) Extended Comms Pens fed back into recorder.// 0x2400
#define MOD_EXCOMPEN_LEN		192				// 96 in total.
#define MOD_MASTER_START		(16384)			// (3/4) ModBus master overlap access registers
#define MOD_MASTER_LEN			256				// 256 in total (32 devices * 8 transactions)
#define MOD_ALARM_STATUS_START	(6529-1)		// (3/4) Alarm status
#define MOD_ALARM_STATUS_LEN	96				// 1 per pen 96 in total (single registers)
#define MOD_ALARM_LEVEL_START	(7169-1)		// (3/4/6/16) Alarm Level
#define MOD_ALARM_LEVEL_LEN		1152			// 6 per pen so 6 alarms * 96 pens * 2 registers per
// Device ID block and content
#define MOD_DEVICE_ID_START		(12289-1)				// Device ID block start
#define MOD_DEVICE_ID_LEN		4						// Device ID length
#define MOD_DEVICE_ID_REG		MOD_DEVICE_ID_START				// Device ID as a float
#define MOD_DEVICE_SR_REG		(MOD_DEVICE_ID_START + 2)		// Device serial number as a float value
#define INPUT_TEXT_START		5				// (3/4) Area for text input						// 0x0005
// this is in Honeywell Miscellaneous Register Map
#define INPUT_TEXT_LEN			32				// 32 bytes maximum of message text
#define	CHART_CONTROL_REGISTER	9				// (3/4) Area for chart control message				// 0x0009
// Modbus byte swapping work space
//#pragma pack(push, Default)
//#pragma pack(1)
union ModSwap {
	UCHAR Byte[4];
	USHORT Word[2];
	float Real;
	ULONG DWord;
};
//#pragma pack(pop, Default)
class MbusDataTable: public MbusDataTableInterface {
private:
	USHORT BuildAlarmStatus(USHORT instance);
	BOOL GetPenAlarmInstancesForAlarmLevel(USHORT instance, USHORT &penNumber, USHORT &alarmNumber);
public:
	void static ModFloatSwap(FLOAT_ORDER order, float &fIn, float &fOut);
	void timeOutHandler();
	char readExceptionStatus();
	int readInputRegistersTable(int startRef, short regArr[], int refCnt);
	int readInputDiscretesTable(int startRef, char bitArr[], int refCnt);
	int readCoilsTable(int startRef, char bitArr[], int refCnt);
	int writeCoilsTable(int startRef, const char bitArr[], int refCnt);
	int readHoldingRegistersTable(int startRef, short regArr[], int refCnt);
	int writeHoldingRegistersTable(int startRef, const short regArr[], int refCnt);
	int reportSlaveID(short regArr[]);
};
#endif // ifdef ..._H_INCLUDED

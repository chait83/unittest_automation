/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Reports System UI
/// @n Filename: ReportDoc.cpp
/// @n Desc:	 Implementation of the CReportDoc class
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  11  Aristos  1.3.1.5.1.0 9/19/2011 4:51:06 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  10  Stability Project 1.3.1.5 7/2/2011 5:00:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  9 Stability Project 1.3.1.4 7/1/2011 4:38:49 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  8 Stability Project 1.3.1.3 5/3/2011 2:19:58 PM Hemant(HAIL) 
// Issue Fixed: Alarms and Counters Information Table is not getting
//  displayed. 
// $
//
// ****************************************************************
#include "reportdoc.h"
#include "rtflib.h"
#include "StringUtils.h"
#include "EUDCDefs.h"
#include "ThreadInfo.h"
// IMPLEMENT_DYNCREATE(CReportDoc, QTextDocument)
const QString CReportDoc::ms_strNEW_LINE("\n");
const QString CReportDoc::ms_strPAR(CReportDoc::ms_strNEW_LINE + "\\par");
const QString CReportDoc::ms_strSECT(CReportDoc::ms_strNEW_LINE + "\\sect");
const QString CReportDoc::ms_strTROWD(CReportDoc::ms_strNEW_LINE + "\\trowd");
const QString CReportDoc::ms_strCELL(CReportDoc::ms_strNEW_LINE + "\\cel");
const QString CReportDoc::ms_strSTART_CELL(CReportDoc::ms_strNEW_LINE + "\\tcelld");
const QString CReportDoc::ms_strPARA_IN_CELL(CReportDoc::ms_strNEW_LINE + "\\par\\pard\\intb");
const QString CReportDoc::ms_strCELL_WIDTH("\\cellx");
//****************************************************************************
// CReportDoc( )
///
/// Constructor
///
//****************************************************************************
CReportDoc::CReportDoc() : m_lNoOfLines(0) {
	m_tTableInfo.bInTable = false;
	memset(m_tTableInfo.ulCellEndPos, 0, sizeof(ULONG) * 20);
	m_tTableInfo.iCurrCell = 0;
	m_tTableInfo.iNoOfColumns = 0;
}
//****************************************************************************
// ~CReportDoc( )
///
/// Destructor
///
//****************************************************************************
CReportDoc::~CReportDoc() {
	// empty the segment list
	m_kSegmentList.clear();
}
//****************************************************************************
// BOOL OnNewDocument( )
///
/// Event handler for a new document being created
///
//****************************************************************************
BOOL CReportDoc::OnNewDocument() {
	if (!QTextDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
// CReportDoc diagnostics
#ifdef _DEBUG
//****************************************************************************
// void CReportDoc::AssertValid() const
///
/// Diagnostic Method
///
//****************************************************************************
void CReportDoc::AssertValid() const
{
	QTextDocument::AssertValid();
}
//
// Stability Project Fix:
//
// Comment the Dump () function declaration and definition. 
// CDumpContext class has been removed from MFC 9.0.
//
/*
 //****************************************************************************
 // void CReportDoc::Dump(CDumpContext& dc) const
 ///
 /// Diagnostic Method
 ///
 //****************************************************************************
 void CReportDoc::Dump(CDumpContext& dc) const
 {
 QTextDocument::Dump(dc);
 }
 */
#endif //_DEBUG
//****************************************************************************
// Bvoid CReportDoc::Serialize(CDataItem& ar)
///
/// Serialise Method
///
//****************************************************************************
void CReportDoc::Serialize(CArchive &ar) {
}
//****************************************************************************
// BOOL OnNewDocument( )
///
/// Event handler for a new document being created
///
//****************************************************************************
BOOL CReportDoc::OnOpenDocument(LPCTSTR lpszPathName) {
	if (!QTextDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	CRTFLib kRTFFile;
	QString strBuffer("");
	QString strTempSegment("");
	const ULONG ulMAX_BUFF_SIZE = 32687;
	char *pcTempCharBuffer = new char[ulMAX_BUFF_SIZE + 1];
	memset(pcTempCharBuffer, 0, ulMAX_BUFF_SIZE);
	QString pwcTempWideCharBuffer = "";
	// read the RTF file in
	ULONG ulBytesRead = ulMAX_BUFF_SIZE;
	ULONG ulCurrFilePos = 0;
	kRTFFile.Open(lpszPathName, QFile::ReadOnly);
	QString strSafeToConvertSegData("");
	QString strConvertedSegData("");
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the main thread and reportgen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// continue reading the file until we reach the end
	while (ulBytesRead == ulMAX_BUFF_SIZE) {
		if (pThreadInfo != NULL) {
			//Update the thread count for main thread
			//This is done to kick the watchdog during
			//report viewing
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
			//Update the Thread Counter for the ReportGenThread
			//We do this at reguler intervals so that we can
			//track any hang issues in report generation
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
		ulBytesRead = kRTFFile.Read(pcTempCharBuffer, ulMAX_BUFF_SIZE);
		// make sure we are null terminated
		size_t pNoOfChars;
		pcTempCharBuffer[ulBytesRead] = 0;
		mbstowcs_s(&pNoOfChars, pwcTempWideCharBuffer, ulMAX_BUFF_SIZE + 1, pcTempCharBuffer, ulBytesRead);
		pwcTempWideCharBuffer[ulBytesRead] = 0;
		// check if we have any information remaining in the segment data
		if (strTempSegment != "") {
			// append the new data to the existing string
			QString strTempBuff(strTempSegment);
			//
			// Stability Project Fix:
			//
			// 1. Original, but commented as the format code was truncating the string for Pens above 30
			// and also garbage was getting printed int he reports.
			//
			//strTempSegment = QString::asprintf( "%s%s", strTempBuff, pwcTempWideCharBuffer );
			// 2. new solution to fix the issue of garbage getting displayed in the reports generated
			// and full report not getting displayed issue.
			//
			// 3. While fixing the above issue of garbage getting displayed in the reports and full report not getting displayed
			// another issue get introduced because of the limitation of QString .asprintf API.
			// The newer version of QString .asprintf truncates truncates the output to 1024 character plus the '\0'. 
			// Hence the Alarm Counter Display was not getting displayed in the reports.
			// To resolve the issue and understanding the limitations of QString class below line is commented.
			// 
			//strTempSegment += strTempBuff; 
			strTempSegment += pwcTempWideCharBuffer;
		} else {
			// no additional data so just copy the new string
			strTempSegment = pwcTempWideCharBuffer;
		}
		// get the last point near the end of this segment that is the end of an RTF control string
		// i.e. this is because we don't try and convert a segment when there is a half finished 
		// control word at the end of it
		strSafeToConvertSegData = GetUptoLastCompleteRTFString(strTempSegment);
		// we should now only have a string with complete RTF control words which will be safe to
		// convert the unicode text and then safe to strip the RTF information
		strConvertedSegData = RevertUnicode(strSafeToConvertSegData);
		// strip out the RTF information and put it into our own format
		StripRTF(strConvertedSegData);
		// add the converted data to our ongoing buffer
		strBuffer += strConvertedSegData;
	}
	kRTFFile.Close();
	if (pThreadInfo != NULL) {
		//Update the thread count for main thread
		//This is done to kick the watchdog during
		//report viewing
		pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		//Update the Thread Counter for the ReportGenThread
		//We do this at reguler intervals so that we can
		//track any hang issues in report generation
		pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
	}
	delete[] pcTempCharBuffer;
	delete[] pwcTempWideCharBuffer;
	// read the header
	m_strHeaderInfo = CStringUtils::GetItemAtPos(strBuffer, 0);
	// add a trailing delimiter
	m_strHeaderInfo += ms_strNEW_LINE;
	int iDelimPos = strBuffer.indexOf(CStringUtils::ms_strDELIMITTER);
	if (iDelimPos != -1) {
		strBuffer.remove(0, iDelimPos + 1);
	}
	// read the footer
	m_strFooterInfo = CStringUtils::GetItemAtPos(strBuffer, 0);
	// add a trailing delimiter
	m_strFooterInfo += ms_strNEW_LINE;
	// get rid of the first character which will be a RTF CRLF
	m_strFooterInfo.remove(0, 1);
	iDelimPos = strBuffer.indexOf(CStringUtils::ms_strDELIMITTER);
	if (iDelimPos != -1) {
		strBuffer.remove(0, iDelimPos + 1);
	}
	// now loop round the data extracting whole paragraphs and putting them into report segments
	while (strBuffer != "") {
		if (pThreadInfo != NULL) {
			//Update the thread count for main thread
			//This is done to kick the watchdog during
			//report viewing
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
			//Update the Thread Counter for the ReportGenThread
			//We do this at reguler intervals so that we can
			//track any hang issues in report generation
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
		CReportSegment kReportSegment;
		kReportSegment.InitSegment(strBuffer);
		m_kSegmentList.push_back(kReportSegment);
	}
	return TRUE;
}
//****************************************************************************
//	const QString GetUptoLastCompleteRTFString( Cstring &rstrTempSegment )
///
/// Method that gets the last point near the end of this segment that is the end of an RTF control string
/// i.e. this is because we don't try and convert a segment when there is a half finished 
/// control word at the end of it
///
/// @param[in/out]		QString &rstrTempSegment - The string to strip the complete RTF data from
///
/// @return		String containing upto the last complete RTF control word
///
//****************************************************************************
const QString CReportDoc::GetUptoLastCompleteRTFString(QString &rstrTempSegment) {
	// search back for the last control word
	//WCHAR wcOldCRLF = 10;
	WCHAR wcRTFEndBrace = L'}';
	QString strCompleteRTFSegment("");
	//int iLastRTFCtrlWordPos = rstrTempSegment.ReverseindexOf( wcOldCRLF );
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the main thread and reportgen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	int iLastRTFCtrlWordPos = 0;
	int iCurrPos = 0;
	while (iCurrPos != -1) {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the ReportGenThread
			//and Main thread.We do this at reguler intervals so 
			//that we can track any hang issues in report generation
			//through events as well as manual
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
		// copy the current position as this could potentially be the last valid value
		iLastRTFCtrlWordPos = iCurrPos;
		iCurrPos = rstrTempSegment.indexOf(ms_strTROWD, iCurrPos + 1);
	}
	//rstrTempSegment.ReverseindexOf( wcOldCRLF );
	//int iLastRTFBrace = rstrTempSegment.ReverseindexOf( wcRTFEndBrace );
	int iLastRTFBrace = rstrTempSegment.ReverseindexOf(wcRTFEndBrace);
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the ReportGenThread
		//and Main thread.We do this at reguler intervals so 
		//that we can track any hang issues in report generation
		//through events as well as manual
		pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
	}
	// check a control word was found
	if ((iLastRTFCtrlWordPos != -1) || (iLastRTFBrace != -1)) {
		// string the information out
		if ((iLastRTFCtrlWordPos != -1) && (iLastRTFCtrlWordPos > iLastRTFBrace)) {
			// don't get the RTF CRLF though
			strCompleteRTFSegment = rstrTempSegment.mid(0, iLastRTFCtrlWordPos);
			rstrTempSegment.remove(0, iLastRTFCtrlWordPos);
		} else {
			strCompleteRTFSegment = rstrTempSegment.mid(0, iLastRTFBrace + 1);
			rstrTempSegment.remove(0, iLastRTFBrace + 1);
		}
	} else {
		// neither type of control word found for some reason so just return the entire 
		// string as it seemingly doesn't contain any RTF data??? Don't touch the string - we'll
		// instead wait until another 32K has been added at which point there msut be some other
		// RTF data
#ifdef _DEBUG
		DebugBreak();
#endif
	}
	return strCompleteRTFSegment;
}
//****************************************************************************
//	const bool StripRTF( QString &rstrDataToStrip )
///
/// Method that strips any RTF formatting and puts it into our own internal format
///
/// @param[in/out]		QString &rstrDataToStrip - THe string to strip the RTF formatting from
///
/// @return		Flag indicating if the process has been successful
///
//****************************************************************************
const bool CReportDoc::StripRTF(QString &rstrDataToStrip) {
	// Strip out the RTF information and put into our own internal format
	// Headers will be the first line of information - This will be a CRLF delimitted list 
	// with each delimitter representing a new line. A '|' will signify the end of 
	// the header. Footer will be the second line. The formatting will be the same as 
	// for headers. The RTF text body will be next. New line's/paragraphs will be seperated 
	// with CRLF, tables row's will consist of delimitted strings again terminated with 
	// CRLF. Finally, headings/bold text will be precedded with the control string [[B]] 
	// and must always follow a CRLF
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the main thread and reportgen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the ReportGenThread
		//and Main thread.We do this at reguler intervals so 
		//that we can track any hang issues in report generation
		//through events as well as manual
		pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
	}
	bool bStrippedData = true;
	// replace all 0x0010 characters with a CRLF
	const QString strCRLF("\r\n");
	const QString strHEADER("{ \\header");
	// strip all info up to the header control word as it is irrelevant
	int iCurrPos = rstrDataToStrip.indexOf(strHEADER, 0);
	// check something was found
	if (iCurrPos != -1) {
		rstrDataToStrip.remove(0, iCurrPos);
	}
	// normalise curr pos
	iCurrPos = 0;
	// strip the header information 
	bStrippedData = StripRTFInfo(rstrDataToStrip, strHEADER, iCurrPos);
	// strip the footer information next
	const QString strFOOTER("{ \\footer");
	bStrippedData = StripRTFInfo(rstrDataToStrip, strFOOTER, iCurrPos);
	const QString strSTART_CONTROL_WORD(ms_strNEW_LINE + "\\");
	int iOldCRLFPos = 0;
	int iNextBackslashPos = 0;
	int iNextSpacePos = 0;
	int iNextControlWordPos = 0;
	if (iCurrPos == -1) {
		iCurrPos = 0;
	} else {
		iCurrPos = rstrDataToStrip.indexOf(strSTART_CONTROL_WORD, iCurrPos);
	}
	const int iCTRL_WORD_LEN = strSTART_CONTROL_WORD.size();
	bool bContinue = true;
	QString strNextControlWord("");
	while (bContinue) {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the ReportGenThread
			//and Main thread.We do this at reguler intervals so 
			//that we can track any hang issues in report generation
			//through events as well as manual
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
		// we should now be pointing at the start of a control word e.g. "\x0010\\"
		// we now want to extract this entire control string and do further processing
		// based on it - the control word may be terminated by a space or another control
		// control word so we must search for these two strings
		iNextSpacePos = rstrDataToStrip.indexOf(L' ', iCurrPos);
		// move past the current control word before searching for the next one
		iNextControlWordPos = rstrDataToStrip.indexOf(strSTART_CONTROL_WORD, iCurrPos + iCTRL_WORD_LEN);
		// check a space was defintely found
		if (iNextSpacePos != -1) {
			int iEndOfControlWord = iNextControlWordPos;
			// Get the lowest of the two values
			if (iNextControlWordPos == -1) {
				iEndOfControlWord = iNextSpacePos;
			} else {
				if (iNextSpacePos < iNextControlWordPos) {
					// we'll want to remove the space so add one so that goes
					iEndOfControlWord = iNextSpacePos + 1;
				}
			}
			// extract and remove the entire control string
			strNextControlWord = rstrDataToStrip.mid(iCurrPos, iEndOfControlWord - iCurrPos);
			rstrDataToStrip.remove(iCurrPos, iEndOfControlWord - iCurrPos);
			// process the next control word further
			ProcessControlWord(rstrDataToStrip, strNextControlWord, iCurrPos);
			// move onto the begining of the next control word
			iCurrPos = rstrDataToStrip.indexOf(strSTART_CONTROL_WORD, iCurrPos);
			// check there is still data to read
			if (iCurrPos == -1) {
				bContinue = false;
			}
		} else if (iNextControlWordPos != -1) {
			// no more space which implies no more meaningful data therefore remove the last bit
			// of control data and break from the loop get the current position of the final brace
			int iFinalBracePos = rstrDataToStrip.indexOf(L'}', iCurrPos + iCTRL_WORD_LEN);
			// check the final brace was found
			if (iFinalBracePos != -1) {
				rstrDataToStrip.remove(iCurrPos, (iFinalBracePos - iCurrPos) + 1);
				bContinue = false;
			} else {
				// this is probably the end of a segment rather than the end of the RTF data 
				// therefore we should process the final commands further			
				// extract and remove the entire control string
				strNextControlWord = rstrDataToStrip.mid(iCurrPos, iNextControlWordPos - iCurrPos);
				rstrDataToStrip.remove(iCurrPos, iNextControlWordPos - iCurrPos);
				ProcessControlWord(rstrDataToStrip, strNextControlWord, iCurrPos);
				// move onto the begining of the next control word
				iCurrPos = rstrDataToStrip.indexOf(strSTART_CONTROL_WORD, iCurrPos);
				if (iCurrPos == -1) {
					bContinue = false;
				}
			}
		} else {
			int iFinalBracePos = rstrDataToStrip.indexOf(L'}', iCurrPos + iCTRL_WORD_LEN);
			// check the final brace was found
			if (iFinalBracePos != -1) {
				rstrDataToStrip.remove(iCurrPos, (iFinalBracePos - iCurrPos) + 1);
			} else {
				// this is probably the end of a segment rather than the end of the RTF data 
				// therefore we should process the final commands further			
				// extract and remove the entire control string
				int iEndPos = rstrDataToStrip.size();
				strNextControlWord = rstrDataToStrip.mid(iCurrPos, iEndPos - iCurrPos);
				rstrDataToStrip.remove(iCurrPos, iEndPos - iCurrPos);
				ProcessControlWord(rstrDataToStrip, strNextControlWord, iCurrPos);
			}
			bContinue = false;
		}
	}
	return bStrippedData;
}
//****************************************************************************
//	const bool StripRTFInfo(	QString &rstrDataToStrip,
//								const QString &rstrCONTROL_WORD,
//								int &riCurrPos)
///
/// Method that strips the RTF info and puts it into our own internal format
///
/// @param[in/out]		QString &rstrDataToStrip - The string to strip the RTF control information from
/// @param[in]			const QString &rstrCONTROL_WORD - The word to search for
///	@param[in/out]		int &riCurrPos - The current location from which we are searching
///
/// @return		Flag indicating if the process has been successful
///
//****************************************************************************
const bool CReportDoc::StripRTFInfo(QString &rstrDataToStrip, const QString &rstrCONTROL_WORD, int &riCurrPos) {
	// Headers will be the first line of information - This will be a delimitted list 
	// with each delimitter representing a new line. A CRLF will signify the end of 
	// the header.
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the main thread and reportgen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != pThreadInfo) {
		pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
	}
	bool bStrippedInfo = true;
	if (riCurrPos != -1) {
		// look for the passed in control word 
		riCurrPos = rstrDataToStrip.indexOf(rstrCONTROL_WORD, riCurrPos);
		// check something was found
		if (riCurrPos != -1) {
			// remove the data up to this point which always gets rid of the space before the control word
			rstrDataToStrip.remove(riCurrPos, rstrCONTROL_WORD.size());
			int iSpacePos = 0;
			int iBracePos = 0;
			int iControlWordPos = 0;
			do {
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the ReportGenThread
					//and Main thread.We do this at reguler intervals so 
					//that we can track any hang issues in report generation
					//through events as well as manual
					pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
					pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
				}
				// find the next space from this point onwards - this will give us the text 
				// required for the info
				iSpacePos = rstrDataToStrip.indexOf(L' ', riCurrPos);
				iBracePos = rstrDataToStrip.indexOf(L'}', riCurrPos);
				// check the end brace was found
				if (iBracePos != -1) {
					// check a space was found too and that it is before the next curly bracket
					if ((iSpacePos != -1) && (iSpacePos < iBracePos)) {
						// found the space - remove the data up to this point
						rstrDataToStrip.remove(riCurrPos, (iSpacePos - riCurrPos) + 1);
						// now move the curr pos point on to the start of the next control word or
						// the next curly brace
						iBracePos = rstrDataToStrip.indexOf(L'}', riCurrPos);
						iControlWordPos = rstrDataToStrip.indexOf(L'\\', riCurrPos);
						// check if we found a control word and if it was past the next brace
						if ((iControlWordPos == -1) || (iControlWordPos > iBracePos)) {
							// the control word is past the next brace therefore remove the brace and the control character, add a
							// delimitter and drop out
							rstrDataToStrip.remove(iBracePos, 1);
							rstrDataToStrip.insert(iBracePos, CStringUtils::ms_strDELIMITTER);
							// if valid set the last bracepos for next time around
							riCurrPos = iBracePos + 1;
							break;
						} else {
							// move the current pos upto the next control word and repeat the procedure
							riCurrPos = iControlWordPos;
						}
					}
				} else {
					// something has gone wrong as we can't find the terminating brace - abort
					bStrippedInfo = false;
					break;
				}
			} while (iSpacePos < iBracePos);
		}
	}
	return bStrippedInfo;
}
//****************************************************************************
//	void ProcessControlString(	QString &rstrDataToStrip,
//								const QString &rstrCONTROL_WORD,
//								int &riCurrPos )
///
/// Method that processes a control string further adding replacement text as neccessary
///
/// @param[in/out]		QString &rstrDataToStrip - The string to strip the RTF control information from
/// @param[in]			const QString &rstrCONTROL_STRING - The current word/string that has just been extracted
///	@param[in/out]		int &riCurrPos - The current location from which we are searching
///
//****************************************************************************
void CReportDoc::ProcessControlWord(QString &rstrDataToStrip, const QString &rstrCONTROL_STRING, int &riCurrPos) {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the main thread and reportgen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the ReportGenThread
		//and Main thread.We do this at reguler intervals so 
		//that we can track any hang issues in report generation
		//through events as well as manual
		pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
	}
	QString strControlWord("");
	// get upto the next space, \\, or \x000a within the entire control string
	int iNextSpacePos = rstrCONTROL_STRING.indexOf(L' ', 0);
	int iNextBackSlashPos = rstrCONTROL_STRING.indexOf(L'\\', rstrCONTROL_STRING.indexOf(L'\\', 0) + 1);
	int iNextRTFDelimPos = rstrCONTROL_STRING.indexOf(ms_strNEW_LINE, 1);
	// check if there is a backslash which will take precedence
	if (iNextBackSlashPos != -1) {
		// extract the word i.e. "\x000a\\par"
		strControlWord = rstrCONTROL_STRING.left(iNextBackSlashPos);
	} else {
		// no backslash therefore check for a RTF delim next - this delim and a space
		// should be mutually exclusive at this point
		if (iNextRTFDelimPos != -1) {
			// extract the word i.e. "\x000a\\par"
			strControlWord = rstrCONTROL_STRING.left(iNextRTFDelimPos);
		} else if (iNextSpacePos != -1) {
			// extract the word i.e. "\x000a\\par"
			strControlWord = rstrCONTROL_STRING.left(iNextSpacePos);
		} else {
			// the whol string must be a control word
			strControlWord = rstrCONTROL_STRING;
		}
	}
	// we have the control word - now check it and perform an appropriate action
	if (strControlWord.compare(ms_strPAR) == 0) {
		// check if this is the next new line at the end of a table
		if (m_tTableInfo.bInTable) {
			// a new paragraph within a table cell will begin with a control string like
			// this - \par\pard\intbl - therefore we need to check against this string 
			// before adding a end of table character
			if (ms_strPARA_IN_CELL.compare(rstrCONTROL_STRING.left(ms_strPARA_IN_CELL.size())) != 0) {
				// this must be the first new line since breaking out of a table therefore
				// add an end of table identifier and reset the table flag
				rstrDataToStrip.insert(riCurrPos++, g_wcEND_OF_TABLE_ROW);
				rstrDataToStrip.insert(riCurrPos, g_wcEND_OF_TABLE);
				m_tTableInfo.bInTable = false;
			} else {
				// still in the table so do nothing
			}
		}
		// new paragraph - add a crlf
		rstrDataToStrip.insert(riCurrPos, "\r\n");
	} else if (strControlWord.compare(ms_strSECT) == 0) {
		// start of a new section - do nothing for now
	} else if (strControlWord.compare(ms_strTROWD) == 0) {
		// check if the in table flag is already set
		if (!m_tTableInfo.bInTable) {
			// must be the start of a table - add the relevant control characters
			rstrDataToStrip.insert(riCurrPos++, g_wcSTART_OF_TABLE);
			rstrDataToStrip.insert(riCurrPos, g_wcSTART_OF_TABLE_ROW);
			m_tTableInfo.bInTable = true;
		} else {
			//
			// Stability Project Fix:
			//
			// already in a table therefore we need to add an end of row flag as well as a start of row
			// Check added for stabliity project because if the report size is large 
			// the report is received in segments of data.Hence we cannot add a 
			//" END OF TABLE ROW" character at the start of a data segment.
			//
			// Alarm Counter Issue fix.
			/*if(riCurrPos != 0)
			 {
			 rstrDataToStrip.insert( riCurrPos++, g_wcEND_OF_TABLE_ROW );
			 }*/
			rstrDataToStrip.insert(riCurrPos++, g_wcEND_OF_TABLE_ROW);
			rstrDataToStrip.insert(riCurrPos, g_wcSTART_OF_TABLE_ROW);
		}
		// reset the current table column/cell information
		m_tTableInfo.iCurrCell = 0;
		m_tTableInfo.iNoOfColumns = 0;
	} else if (strControlWord.compare(ms_strCELL) == 0) {
		// must be the end of a cell - add a control character along with the cell end position
		QString strEndOfCellIdentifier("");
		strEndOfCellIdentifier = QString::asprintf("%c%c",
				static_cast<USHORT>(m_tTableInfo.ulCellEndPos[m_tTableInfo.iCurrCell]), g_wcEND_OF_TABLE_CELL);
		rstrDataToStrip.insert(riCurrPos, strEndOfCellIdentifier);
		// move the current cell number on
		++m_tTableInfo.iCurrCell;
	} else if (strControlWord.compare(ms_strSTART_CELL) == 0) {
		// must be the start of a table cell - get the cell width
		int iCellXPos = rstrCONTROL_STRING.indexOf(ms_strCELL_WIDTH);
		// from this point we need to retrive the number which will give us our width
		int iStartOfNum = iCellXPos + ms_strCELL_WIDTH.size();
		// now extract the number
		QString strWidth("");
		strWidth = rstrCONTROL_STRING.mid(iStartOfNum, rstrCONTROL_STRING.size() - iStartOfNum);
		// we should have the number now - now convert into an int and store
		QString pwcStopChar = NULL;
		const ULONG ulWIDTH = strWidth.toULong();
		// check the conversion did not stop prematurely e.g. on an invalid character
		if (*pwcStopChar == '\0') {
			m_tTableInfo.ulCellEndPos[m_tTableInfo.iNoOfColumns] = ulWIDTH;
			++m_tTableInfo.iNoOfColumns;
		} else {
			// just put in an abitary width and flag the error 
			m_tTableInfo.ulCellEndPos[m_tTableInfo.iNoOfColumns] = 2250;
			++m_tTableInfo.iNoOfColumns;
			qDebug("Invalid cell width found\n");
		}
	} else {
	}
}
//****************************************************************************
//	const QString RevertUnicode( const QString pwcBUFFER )
///
/// Method that reverts any RTF unicode characters back into unicode strings
///
/// @param[in]		const QString pwcBUFFER - The RTF text buffer that might contain converted unicode data
///
/// @return		The unicode string
///
//****************************************************************************
const QString CReportDoc::RevertUnicode(const QString pwcBUFFER) {
	QString strReverted("");
	strReverted = pwcBUFFER;
	QString strDecimalVal("");
	const QString strSEARCH_STR("\\u");
	const QString strUNICODE_END_STR(" ?");
	const int iSEARCH_STR_LEN = strSEARCH_STR.size();
	int iUnicodePos = 0;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the main thread and reportgen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	while ((iUnicodePos = strReverted.indexOf(strSEARCH_STR, iUnicodePos)) != -1) {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the ReportGenThread
			//and Main thread.We do this at reguler intervals so 
			//that we can track any hang issues in report generation
			//through events as well as manual
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
		// found a unicode character - get the decimal value
		int iEndUnicodePos = strReverted.indexOf(strUNICODE_END_STR, iUnicodePos);
		if( ( iEndUnicodePos != - 1 ) && ( ( iEndUnicodePos - iUnicodePos ) < 9 ) )
		{
			// extract the decimal part
			strDecimalVal = strReverted.mid(iUnicodePos + iSEARCH_STR_LEN,
					iEndUnicodePos - (iUnicodePos + iSEARCH_STR_LEN));
			// now convert the decimal string into an DWORD/WCHAR
			QString pwcStopChar = NULL;

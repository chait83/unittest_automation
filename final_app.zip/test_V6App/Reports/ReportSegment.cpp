// ReportSegment.cpp: implementation of the CReportSegment class.
//
//////////////////////////////////////////////////////////////////////
#include "ReportSegment.h"
#include "rtflib.h"
#include "StringUtils.h"
//****************************************************************************
// CReportSegment( )
///
/// Constructor
///
//****************************************************************************
CReportSegment::CReportSegment() : m_strReportBlock(""), m_ulNoOfLines(0), m_eSegmentType(rstPARAGRAPH), m_iNoOfRows(0), m_iNoOfCellsPerLine(
		0), m_ulStartLineNo(0) {
}
//****************************************************************************
// CReportSegment( const CReportSegment &rkREPORT_SEGMENT )
///
/// Copy Constructor
///
//****************************************************************************
CReportSegment::CReportSegment(const CReportSegment &rkREPORT_SEGMENT) : m_strReportBlock(
		rkREPORT_SEGMENT.m_strReportBlock), m_ulNoOfLines(rkREPORT_SEGMENT.m_ulNoOfLines), m_eSegmentType(
		rkREPORT_SEGMENT.m_eSegmentType), m_iNoOfRows(rkREPORT_SEGMENT.m_iNoOfRows), m_iNoOfCellsPerLine(
		rkREPORT_SEGMENT.m_iNoOfCellsPerLine), m_ulStartLineNo(rkREPORT_SEGMENT.m_ulStartLineNo) {
}
//****************************************************************************
// ~CReportSegment( )
///
/// Destructor
///
//****************************************************************************
CReportSegment::~CReportSegment() {
}
//****************************************************************************
// operator=( const CReportSegment &rkREPORT_SEGMENT )
///
/// = method
///
/// @param[in]			CReportSegment &rkREPORT_SEGMENT - The segment data to copy
///
//****************************************************************************
void CReportSegment::operator=(const CReportSegment &rkREPORT_SEGMENT) {
	m_strReportBlock = rkREPORT_SEGMENT.m_strReportBlock;
	m_ulNoOfLines = rkREPORT_SEGMENT.m_ulNoOfLines;
	m_eSegmentType = rkREPORT_SEGMENT.m_eSegmentType;
	m_iNoOfRows = rkREPORT_SEGMENT.m_iNoOfRows;
	m_iNoOfCellsPerLine = rkREPORT_SEGMENT.m_iNoOfCellsPerLine;
	m_ulStartLineNo = rkREPORT_SEGMENT.m_ulStartLineNo;
}
//****************************************************************************
// void InitSegment( QString &rstrReportData )
///
/// Method that sets up the segment information and strips the data out of
/// the passed in string
///
/// @param[in/out]	QString &rstrReportData - The string to strip the RTF information
///					out of
///
//****************************************************************************
void CReportSegment::InitSegment(QString &rstrReportData) {
	QString strCRLF("\n");
	const int iCRLF_LEN = strCRLF.size();
	// extract the paragraph or table information - check to see what occurs first - a new table
	// or a paragraph
	int iNewTablePos = rstrReportData.indexOf(g_wcSTART_OF_TABLE, 0);
	int iNewCRLFPos = rstrReportData.indexOf(strCRLF, 0);
	if ((iNewTablePos == -1) || (iNewCRLFPos < iNewTablePos)) {
		m_eSegmentType = rstPARAGRAPH;
		// no more table information or the next character is a CRLF therefore we must extract this paragraph
		// check this is not the end of thedata as well though
		if (iNewCRLFPos != -1) {
			m_strReportBlock = rstrReportData.left(iNewCRLFPos + iCRLF_LEN);
			// string the extracted paragraph from the string
			rstrReportData.remove(0, iNewCRLFPos + iCRLF_LEN);
		} else {
			// must be the end of the data so grab the lot and clear the buffer
			m_strReportBlock = rstrReportData;
			rstrReportData = "";
		}
	} else if (iNewCRLFPos > iNewTablePos) {
		m_eSegmentType = rstTABLE;
		// the table position must be sooner than the CRLF therefore this next segment
		// of data must be a table - extract all the info upto the end of table flag
		int iEndOfTablePos = rstrReportData.indexOf(g_wcEND_OF_TABLE, iNewTablePos);
		// check something was found
		if (iEndOfTablePos != -1) {
			// extract the string between the table delimitters
			m_strReportBlock = rstrReportData.mid(iNewTablePos + 1, iEndOfTablePos - (iNewTablePos + 1));
			// delete the table information including the delimiters
			rstrReportData.remove(iNewTablePos, (iEndOfTablePos - iNewTablePos) + 1);
		} else {
			// problem 
			int i = 0;
			i++;
		}
	} else {
		m_eSegmentType = rstPARAGRAPH;
		// this must be some end text so just extract it and empty the passed in report data buffer
		m_strReportBlock = rstrReportData;
		rstrReportData = "";
	}
}
//****************************************************************************
// void SetNoOfLines(	CDC *pDC,
//						const int iPAGE_WIDTH, 
//						const int iCHAR_HEIGHT,
//						const ULONG ulSTART_LINE_NO )
///
/// Method that sets the number of lines the segment data will occupy based
/// on the passed in page/character parameters
///
//****************************************************************************
void CReportSegment::SetNoOfLines(CDC *pDC, const int iPAGE_WIDTH, const int iCHAR_HEIGHT,
		const ULONG ulSTART_LINE_NO) {
	// reset the current number of lines
	m_ulNoOfLines = 0;
	m_ulStartLineNo = ulSTART_LINE_NO;
	// check what kind of segment type this is
	if (m_eSegmentType == rstPARAGRAPH) {
		QRect tPreferedRect;
		tPreferedRect.setLeft(0);
		tPreferedRect.setTop(0);
		tPreferedRect.setRight(iPAGE_WIDTH);
		tPreferedRect.setBottom(5);
		// re-Calculates the size of the rectangle for size of text
		pDC->DrawText(m_strReportBlock, m_strReportBlock.size(), &tPreferedRect,
				DT_NOPREFIX | DT_CALCRECT | DT_WORDBREAK);
		// CE seems to produce a rect less than the standard char height - add a small
		// amount so that the no of lines effectively gets rounded up rather than down
#ifdef UNDER_CE
		m_ulNoOfLines = ( tPreferedRect.bottom / iCHAR_HEIGHT );
#else
		m_ulNoOfLines = (tPreferedRect.bottom / iCHAR_HEIGHT) - 1;
#endif
	} else {
		// this is table information - we need to look at each cell and count the number of carriage
		// returns and line feeds
		m_iNoOfRows = 0;
		m_iNoOfCellsPerLine = 0;
		QString strCurrRow("");
		QString strCurrCell("");
		QString strCellDelimiter("");
		strCellDelimiter = g_wcEND_OF_TABLE_CELL;
		// loop through the rows
		int iStartOfRowPos = 0;
		int iEndOfRowPos = 0;
		do {
			iStartOfRowPos = m_strReportBlock.indexOf(g_wcSTART_OF_TABLE_ROW, iEndOfRowPos);
			if (iStartOfRowPos != -1) {
				iEndOfRowPos = m_strReportBlock.indexOf(g_wcEND_OF_TABLE_ROW, iStartOfRowPos);
			}
			// check that both delimiters were found
			if ((iStartOfRowPos != -1) && (iEndOfRowPos != -1)) {
				int iMaxLinesThisRow = 1;
				// extract the row not including the delimiters themselves - move the start
				// position past the delimiter
				++iStartOfRowPos;
				strCurrRow = m_strReportBlock.mid(iStartOfRowPos, iEndOfRowPos - iStartOfRowPos);
				m_iNoOfCellsPerLine = 0;
				// we have the row information - not go down to the cell level
				int iCurrCell = 0;
				while ((strCurrCell = CStringUtils::GetItemAtPos(strCurrRow, iCurrCell, strCellDelimiter)) != "") {
					// count the number of carriage returns - this will give the maximum data we will
					// display
					const int iNO_OF_LINES_PER_CELL = CStringUtils::InstanceOfStr(strCurrCell, "\n") + 1;
					// check if greater than our current maximum
					if (iMaxLinesThisRow < iNO_OF_LINES_PER_CELL) {
						// make this our new maximum
						iMaxLinesThisRow = iNO_OF_LINES_PER_CELL;
					}
					++iCurrCell;
					++m_iNoOfCellsPerLine;
				}
				// add the max number of lines for this row to our running total
				m_ulNoOfLines += iMaxLinesThisRow;
				// increment the number of rows
				++m_iNoOfRows;
			} else {
				// break out of the loop
				break;
			}
		} while (strCurrRow != "");
	}
}
//****************************************************************************
// const ULONG DrawSegment(	CDC *pDC, 
//								QRect &tClipRect,
//								const int iCHAR_HEIGHT,
//								const ULONG ulFIRST_VIEWABLE_LINE,
//								const ULONG ulCURR_LINE,
//								const ULONG ulLAST_VIEWABLE_LINE )
///
/// Method that draws the segment information on the screen
///
/// @param[in]		CDC *pDC - The DC we are drawing to
/// @param[in]		QRect &tClipRect - the rectangle we are drawing within
/// @param[in]		const int iCHAR_HEIGHT - The height of the characters
/// @param[in]		const ULONG ulFIRST_VIEWABLE_LINE - The first viewable line
/// @param[in]		const ULONG ulCURR_LINE - The line at which we are currently
///					looking (not necessarily a viewable line)
/// @param[in]		const ULONG ulLAST_VIEWABLE_LINE - The last viewable line
///
/// @return			The number of lines drawing this segment has taken (might be a fraction of the
///					actual max number of lines for this segment)
///
//****************************************************************************
const ULONG CReportSegment::DrawSegment(CDC *pDC, QRect &tClipRect, const int iCHAR_HEIGHT,
		const ULONG ulFIRST_VIEWABLE_LINE, const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE) {
	QRect tThisRect = tClipRect;
	int iNoOfLines = 0;
	// check if this is a paragraph or table
	if (m_eSegmentType == rstPARAGRAPH) {
		// this is a paragraph
		iNoOfLines = DrawParagraph(pDC, tClipRect, iCHAR_HEIGHT, ulFIRST_VIEWABLE_LINE, ulCURR_LINE,
				ulLAST_VIEWABLE_LINE);
	} else {
		// this is a table
		iNoOfLines = DrawTable(pDC, tClipRect, iCHAR_HEIGHT, ulFIRST_VIEWABLE_LINE, ulCURR_LINE, ulLAST_VIEWABLE_LINE);
	}
	return iNoOfLines;
}
//****************************************************************************
// const ULONG DrawParagraph(	CDC *pDC, 
//								QRect &tClipRect,
//								const int iCHAR_HEIGHT,
//								const ULONG ulFIRST_VIEWABLE_LINE,
//								const ULONG ulCURR_LINE,
//								const ULONG ulLAST_VIEWABLE_LINE )
///
/// Method that draws the paragraph information on the screen
///
/// @param[in]		CDC *pDC - The DC we are drawing to
/// @param[in]		QRect &tClipRect - the rectangle we are drawing within
/// @param[in]		const int iCHAR_HEIGHT - The height of the characters
/// @param[in]		const ULONG ulFIRST_VIEWABLE_LINE - The first viewable line
/// @param[in]		const ULONG ulCURR_LINE - The line at which we are currently
///					looking (not necessarily a viewable line)
/// @param[in]		const ULONG ulLAST_VIEWABLE_LINE - The last viewable line
///
/// @return			The number of lines drawing this paragraph has taken (might be a fraction of the
///					actual max number of lines for this segment)
///
//****************************************************************************
const ULONG CReportSegment::DrawParagraph(CDC *pDC, QRect &rtClipRect, const int iCHAR_HEIGHT,
		const ULONG ulFIRST_VIEWABLE_LINE, const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE) {
	QString strTemp = m_strReportBlock;
	strTemp.replace("\n", "");
	strTemp.replace("\t", "");
	pDC->DrawText(strTemp, strTemp.size(), &rtClipRect, DT_NOPREFIX | DT_WORDBREAK);
	rtClipRect.setTop(m_ulNoOfLines) * iCHAR_HEIGHT;
	rtClipRect.setBottom(m_ulNoOfLines) * iCHAR_HEIGHT;
	return m_ulNoOfLines;
}
//****************************************************************************
// const ULONG DrawTable(	CDC *pDC, 
//							QRect &tClipRect,
//							const int iCHAR_HEIGHT,
//							const ULONG ulFIRST_VIEWABLE_LINE,
//							const ULONG ulCURR_LINE,
//							const ULONG ulLAST_VIEWABLE_LINE )
///
/// Method that draws the table information on the screen
///
/// @param[in]		CDC *pDC - The DC we are drawing to
/// @param[in]		QRect &tClipRect - the rectangle we are drawing within
/// @param[in]		const int iCHAR_HEIGHT - The height of the characters
/// @param[in]		const ULONG ulFIRST_VIEWABLE_LINE - The first viewable line
/// @param[in]		const ULONG ulCURR_LINE - The line at which we are currently
///					looking (not necessarily a viewable line)
/// @param[in]		const ULONG ulLAST_VIEWABLE_LINE - The last viewable line
///
/// @return			The number of lines drawing this table has taken (might be a fraction of the
///					actual max number of lines for this segment)
///
//****************************************************************************
const ULONG CReportSegment::DrawTable(CDC *pDC, QRect &rtClipRect, const int iCHAR_HEIGHT,
		const ULONG ulFIRST_VIEWABLE_LINE, const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE) {
	QRect tThisRect = rtClipRect;
	QString strCurrRow("");
	// loop through the rows drawing the cells as appropriate
	int iStartOfRowPos = 0;
	int iEndOfRowPos = 0;
	int iCurrLineNumber = 0;
	do {
		// get the row text
		if (GetRowText(iStartOfRowPos, iEndOfRowPos, strCurrRow)) {
			// draw the row
			iCurrLineNumber += DrawRow(pDC, tThisRect, iCHAR_HEIGHT, ulFIRST_VIEWABLE_LINE,
					ulCURR_LINE + iCurrLineNumber, ulLAST_VIEWABLE_LINE, strCurrRow);
		} else {
			// break out of the loop as the row text is invalid or we have reached the 
			// end of the table
			break;
		}
	} while (strCurrRow != "");
	rtClipRect.setTop(tThisRect).top;
	rtClipRect.setBottom(tThisRect).bottom;
	return m_ulNoOfLines;
}
//****************************************************************************
// const ULONG DrawRow(	CDC *pDC, 
//							QRect &tClipRect,
//							const int iCHAR_HEIGHT,
//							const ULONG ulFIRST_VIEWABLE_LINE,
//							const ULONG ulCURR_LINE,
//							const ULONG ulLAST_VIEWABLE_LINE )
///
/// Method that draws the row information on the screen
///
/// @param[in]		CDC *pDC - The DC we are drawing to
/// @param[in]		QRect &tClipRect - the rectangle we are drawing within
/// @param[in]		const int iCHAR_HEIGHT - The height of the characters
/// @param[in]		const ULONG ulFIRST_VIEWABLE_LINE - The first viewable line
/// @param[in]		const ULONG ulCURR_LINE - The line at which we are currently
///					looking (not necessarily a viewable line)
/// @param[in]		const ULONG ulLAST_VIEWABLE_LINE - The last viewable line
///
/// @return			The number of lines drawing this row has taken
///
//****************************************************************************
const ULONG CReportSegment::DrawRow(CDC *pDC, QRect &rtClipRect, const int iCHAR_HEIGHT,
		const ULONG ulFIRST_VIEWABLE_LINE, const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE,
		const QString &rstrCURR_ROW) {
	// get the availabe width of the table
	const int iPAGE_WIDTH = (rtClipRect.right - rtClipRect.left);
	QString strCellDelimiter("");
	strCellDelimiter = g_wcEND_OF_TABLE_CELL;
	int iMaxLinesThisRow = 0;
	int iMaxLinesDrawnThisRow = 0;
	// we have the row information - now go down to the cell level
	int iCurrCell = 0;
	QString strIndCellLine("");
	QString strCurrCell("");
	ULONG ulPrevCellEndPos = 0;
	// check how many columns there are if too many then reduce the font size
	CFontCache *pkFontCache = CFontCache::GetHandle();
	int iYOffset = 0;
	QFont hFont = NULL;
	QFont hOldFont = NULL;
	const USHORT usNO_OF_COLS = CStringUtils::InstanceOfStr(rstrCURR_ROW, strCellDelimiter);
	if (usNO_OF_COLS >= 10) {
		hFont = pkFontCache->GetNumericFont(static_cast<int>(static_cast<float>(iCHAR_HEIGHT) * 0.6), &iYOffset);
		hOldFont = (QFont) pDC->SelectObject(hFont);
	}
	// loop through all the cell
	while ((strCurrCell = CStringUtils::GetItemAtPos(rstrCURR_ROW, iCurrCell, strCellDelimiter)) != "") {
		// extract and use the column end position
		const ULONG ulCELL_END_POS = strCurrCell.at(strCurrCell.size() - 1);
		// remove the cell width character
		strCurrCell.remove(strCurrCell.size() - 1, 1);
		// add a CRLF to the end so that we can easily extract the information
		strCurrCell += "\n";
		// we have the cell information - keep extracting each cell
		int iCurrIndCellLine = 0;
		int iNoOfLinesThisCell = 0;
		int iNoOfLinesDrawnThisCell = 0;
		QRect tCellRect = rtClipRect;
		// set the correct column width
		tCellRect.setLeft(
				rtClipRect.left()
						+ ((static_cast<float>(ulPrevCellEndPos) / CRTFLib::ms_iMAX_CELL_WIDTH) * iPAGE_WIDTH));
		tCellRect.setRight(
				rtClipRect.left() + ((static_cast<float>(ulCELL_END_POS) / CRTFLib::ms_iMAX_CELL_WIDTH) * iPAGE_WIDTH));
		while ((strIndCellLine = CStringUtils::GetItemAtPos(strCurrCell, iCurrIndCellLine, "\n")) != "") {
			++iNoOfLinesThisCell;
			// check if this line is viewable
			if (!pDC->IsPrinting()
					|| (((iCurrIndCellLine + ulCURR_LINE) >= ulFIRST_VIEWABLE_LINE)
							&& ((iCurrIndCellLine + ulCURR_LINE) <= ulLAST_VIEWABLE_LINE))) {
				++iNoOfLinesDrawnThisCell;
				// yes this line is viewable therefore draw it
				strIndCellLine.replace("\n", "");
				strIndCellLine.replace("\t", "");
				pDC->DrawText(strIndCellLine, strIndCellLine.size(), &tCellRect, DT_NOPREFIX | DT_WORD_ELLIPSIS);
				tCellRect.setTop(tCellRect.top() + iCHAR_HEIGHT);
				tCellRect.setBottom(tCellRect.bottom() + iCHAR_HEIGHT);
			}
			++iCurrIndCellLine;
		}
		// check if greater than our current maximum
		if (iMaxLinesThisRow < iNoOfLinesThisCell) {
			// make this our new maximum
			iMaxLinesThisRow = iNoOfLinesThisCell;
		}
		// check if greater than our current maximum
		if (iMaxLinesDrawnThisRow < iNoOfLinesDrawnThisCell) {
			// make this our new maximum
			iMaxLinesDrawnThisRow = iNoOfLinesDrawnThisCell;
		}
		// store the end position of this cell
		ulPrevCellEndPos = ulCELL_END_POS;
		++iCurrCell;
	}
	if (usNO_OF_COLS >= 10) {
		// restore the original font
		pDC->SelectObject(hOldFont);
		pkFontCache->ReleaseFont(hFont);
	}
	// offset the top as appropriate
	rtClipRect.top += (iMaxLinesDrawnThisRow * iCHAR_HEIGHT);
	rtClipRect.bottom += (iMaxLinesDrawnThisRow * iCHAR_HEIGHT);
	return iMaxLinesThisRow;
}
//****************************************************************************
// const bool GetRowText(	int &riStartOfRowPos, 
//							int &riEndOfRowPos, 
//							QString &rstrCurrRow )
///
/// Method used to extract the row text
///
/// @param[in/out]		int &riStartOfRowPos - The index into the report block from
///						which we should start looking for the row text. Also returned
///						as the location of the start of the row text
/// @param[in/out]		int &riEndOfRowPos - The index into the report block from
///						which we should start looking for the row text. Also returned
///						as the location of the end of the row text
///	@param[out]			QString &rstrCurrRow - The extracted row text
///
//****************************************************************************
const bool CReportSegment::GetRowText(int &riStartOfRowPos, int &riEndOfRowPos, QString &rstrCurrRow) {
	bool bExtractedRow = false;
	// get the start position of the row text
	riStartOfRowPos = m_strReportBlock.indexOf(g_wcSTART_OF_TABLE_ROW, riEndOfRowPos);
	// check the start of text position was valid
	if (riStartOfRowPos != -1) {
		// get the end position of the row text
		riEndOfRowPos = m_strReportBlock.indexOf(g_wcEND_OF_TABLE_ROW, riStartOfRowPos);
	}
	// check that both delimiters were found and therefore we have extracted the text
	// for the next row OK
	if ((riStartOfRowPos != -1) && (riEndOfRowPos != -1)) {
		// extract the row text not including the delimiters themselves - move the start
		// position past the delimiter
		++riStartOfRowPos;
		rstrCurrRow = m_strReportBlock.mid(riStartOfRowPos, riEndOfRowPos - riStartOfRowPos);
		bExtractedRow = true;
	} else {
		bExtractedRow = false;
	}
	return bExtractedRow;
}
#ifdef PRINT_CE
void CReportSegment::SetNoOfLines(	CPrintCEWrapper* pCEWrapper,
									const int iPAGE_WIDTH, 
									const int iCHAR_HEIGHT,
									const ULONG ulSTART_LINE_NO )
{
	// reset the current number of lines
	m_ulNoOfLines = 0;
	m_ulStartLineNo = ulSTART_LINE_NO;
	HDC hDC = pCEWrapper->GetHDC();
	// check what kind of segment type this is
	if( m_eSegmentType == rstPARAGRAPH )
	{
		QRect tPreferedRect;
		tPreferedRect.setLeft(0);
		tPreferedRect.setTop(0);
		tPreferedRect.setRight(iPAGE_WIDTH);
		tPreferedRect.setBottom(5);
		// re-Calculates the size of the rectangle for size of text
		pCEWrapper->PDC_DrawText(hDC, m_strReportBlock,
						m_strReportBlock.size(),
						&tPreferedRect,
						DT_NOPREFIX | DT_CALCRECT | DT_WORDBREAK ); 
		// CE seems to produce a rect less than the standard char height - add a small
		// amount so that the no of lines effectively gets rounded up rather than down
#ifdef UNDER_CE
		m_ulNoOfLines = ( tPreferedRect.bottom / iCHAR_HEIGHT );
#else
		m_ulNoOfLines = ( tPreferedRect.bottom / iCHAR_HEIGHT ) - 1;
#endif
	}
	else
	{
		// this is table information - we need to look at each cell and count the number of carriage
		// returns and line feeds
		m_iNoOfRows = 0;
		m_iNoOfCellsPerLine = 0;
		QString strCurrRow( QString ::fromWCharArray("") );
		QString strCurrCell( QString ::fromWCharArray("") );
		QString strCellDelimiter( QString ::fromWCharArray("") );
		strCellDelimiter = g_wcEND_OF_TABLE_CELL;
		// loop through the rows
		int iStartOfRowPos = 0;
		int iEndOfRowPos = 0;
		do
		{
			iStartOfRowPos = m_strReportBlock.indexOf( g_wcSTART_OF_TABLE_ROW, iEndOfRowPos );
			if( iStartOfRowPos != -1 )
			{
				iEndOfRowPos = m_strReportBlock.indexOf( g_wcEND_OF_TABLE_ROW, iStartOfRowPos );
			}
			// check that both delimiters were found
			if( ( iStartOfRowPos != -1 ) && ( iEndOfRowPos != -1 ) )
			{
				int iMaxLinesThisRow = 1;
				// extract the row not including the delimiters themselves - move the start
				// position past the delimiter
				++iStartOfRowPos;
				strCurrRow = m_strReportBlock.mid( iStartOfRowPos, iEndOfRowPos - iStartOfRowPos );
				m_iNoOfCellsPerLine = 0;
				// we have the row information - not go down to the cell level
				int iCurrCell = 0;
				while( ( strCurrCell = CStringUtils::GetItemAtPos( strCurrRow, iCurrCell, strCellDelimiter ) ) != QString ::fromWCharArray("") )
				{	
					// count the number of carriage returns - this will give the maximum data we will
					// display
        const int iNO_OF_LINES_PER_CELL = CStringUtils::InstanceOfStr( strCurrCell, "\n" ) + 1;
					// check if greater than our current maximum
					if( iMaxLinesThisRow < iNO_OF_LINES_PER_CELL )
					{
						// make this our new maximum
						iMaxLinesThisRow = iNO_OF_LINES_PER_CELL;
					}
	
					++iCurrCell;
					++m_iNoOfCellsPerLine;
				}
				// add the max number of lines for this row to our running total
				m_ulNoOfLines += iMaxLinesThisRow;
				// increment the number of rows
				++m_iNoOfRows;
			}
			else
			{
				// break out of the loop
				break;
			}
		}
		while( strCurrRow != QString ::fromWCharArray("") ); 
	}
}
const ULONG CReportSegment::DrawSegment(	CPrintCEWrapper* pCEWrapper, 
											QRect &tClipRect,
											const int iCHAR_HEIGHT,
											const ULONG ulFIRST_VIEWABLE_LINE,
											const ULONG ulCURR_LINE,
											const ULONG ulLAST_VIEWABLE_LINE )
{
	QRect tThisRect = tClipRect;
	int iNoOfLines = 0;
	// check if this is a paragraph or table
	if( m_eSegmentType == rstPARAGRAPH )
	{
		// this is a paragraph
		iNoOfLines =	DrawParagraph(	pCEWrapper, 
										tClipRect, 
										iCHAR_HEIGHT, 
										ulFIRST_VIEWABLE_LINE,
										ulCURR_LINE,
										ulLAST_VIEWABLE_LINE );
	}
	else
	{
		// this is a table
		iNoOfLines = DrawTable( pCEWrapper, 
								tClipRect, 
								iCHAR_HEIGHT, 
								ulFIRST_VIEWABLE_LINE,
								ulCURR_LINE,
								ulLAST_VIEWABLE_LINE );
	}
	return iNoOfLines;
}
const ULONG CReportSegment::DrawParagraph(	CPrintCEWrapper* pCEWrapper, 
											QRect &rtClipRect,
											const int iCHAR_HEIGHT,
											const ULONG ulFIRST_VIEWABLE_LINE,
											const ULONG ulCURR_LINE,
											const ULONG ulLAST_VIEWABLE_LINE )
{
	QString strTemp = m_strReportBlock;
  strTemp.Replace( "\n", QString ::fromWCharArray("") );
  strTemp.Replace( "\t", QString ::fromWCharArray("") );
	HDC hDC = pCEWrapper->GetHDC();
	pCEWrapper->PDC_DrawText(hDC, strTemp, 
					strTemp.size(),
					&rtClipRect,
					DT_NOPREFIX | DT_WORDBREAK );
	rtClipRect.setTop(m_ulNoOfLines) * iCHAR_HEIGHT;
	rtClipRect.setBottom(m_ulNoOfLines) * iCHAR_HEIGHT;
	return m_ulNoOfLines;
}
const ULONG CReportSegment::DrawTable(	CPrintCEWrapper* pCEWrapper, 
										QRect &rtClipRect,
										const int iCHAR_HEIGHT,
										const ULONG ulFIRST_VIEWABLE_LINE,
										const ULONG ulCURR_LINE,
										const ULONG ulLAST_VIEWABLE_LINE )
{
	QRect tThisRect = rtClipRect;
	QString strCurrRow( QString ::fromWCharArray("") );
	// loop through the rows drawing the cells as appropriate
	int iStartOfRowPos = 0;
	int iEndOfRowPos = 0;
	int iCurrLineNumber = 0;
	do
	{
		// get the row text
		if( GetRowText( iStartOfRowPos, iEndOfRowPos, strCurrRow ) )
		{
			// draw the row
			iCurrLineNumber += DrawRow( pCEWrapper,
										tThisRect, 
										iCHAR_HEIGHT, 
										ulFIRST_VIEWABLE_LINE,
										ulCURR_LINE + iCurrLineNumber,
										ulLAST_VIEWABLE_LINE,
										strCurrRow );
		}
		else
		{
			// break out of the loop as the row text is invalid or we have reached the 
			// end of the table
			break;
		}
	}
	while( strCurrRow != QString ::fromWCharArray("") ); 
	rtClipRect.setTop(tThisRect).top;
	rtClipRect.setBottom(tThisRect).bottom;
	return m_ulNoOfLines;
}
const ULONG CReportSegment::DrawRow(	CPrintCEWrapper* pCEWrapper, 
										QRect &rtClipRect,
										const int iCHAR_HEIGHT,
										const ULONG ulFIRST_VIEWABLE_LINE,
										const ULONG ulCURR_LINE,
										const ULONG ulLAST_VIEWABLE_LINE,
										const QString &rstrCURR_ROW )
{
	// get the availabe width of the table
	const int iPAGE_WIDTH = ( rtClipRect.right - rtClipRect.left );
	QString strCellDelimiter( QString ::fromWCharArray("") );
	strCellDelimiter = g_wcEND_OF_TABLE_CELL;
	int iMaxLinesThisRow = 0;
	int iMaxLinesDrawnThisRow = 0;
	// we have the row information - now go down to the cell level
	int iCurrCell = 0;
	QString strIndCellLine( QString ::fromWCharArray("") );
	QString strCurrCell( QString ::fromWCharArray("") );
	ULONG ulPrevCellEndPos = 0;
	// check how many columns there are if too many then reduce the font size
	CFontCache *pkFontCache = CFontCache::GetHandle();
	int iYOffset = 0;
	HDC hDC = pCEWrapper->GetHDC();
	QFont hFont = NULL;
	//QFont hOldFont = NULL;
	HGDIOBJ hOldFont = NULL;
	const USHORT usNO_OF_COLS = CStringUtils::InstanceOfStr( rstrCURR_ROW, strCellDelimiter );
	if( usNO_OF_COLS >= 10 )
	{
		hFont = pkFontCache->GetNumericFont( static_cast< int >( static_cast< float >( iCHAR_HEIGHT ) * 0.6 ), &iYOffset );
		//hOldFont = (QFont)pDC->SelectObject( hFont );
		hOldFont = pCEWrapper->PDC_SelectObject(hDC, hFont);
	}
	// loop through all the cell
	while( ( strCurrCell = CStringUtils::GetItemAtPos( rstrCURR_ROW, iCurrCell, strCellDelimiter ) ) != QString ::fromWCharArray("") )
	{	
		// extract and use the column end position
		const ULONG ulCELL_END_POS = strCurrCell.at( strCurrCell.size() - 1 );
		// remove the cell width character
		strCurrCell.remove( strCurrCell.size() - 1, 1 );
		// add a CRLF to the end so that we can easily extract the information
    strCurrCell += "\n";
		// we have the cell information - keep extracting each cell
		int iCurrIndCellLine = 0;
		int iNoOfLinesThisCell = 0;
		int iNoOfLinesDrawnThisCell = 0;
		QRect tCellRect = rtClipRect;
		// set the correct column width
		tCellRect.setLeft(rtClipRect).left + ( ( static_cast< float >( ulPrevCellEndPos ) / CRTFLib::ms_iMAX_CELL_WIDTH ) * iPAGE_WIDTH );
		tCellRect.setRight(rtClipRect).left + ( ( static_cast< float >( ulCELL_END_POS ) / CRTFLib::ms_iMAX_CELL_WIDTH ) * iPAGE_WIDTH );
    while( ( strIndCellLine = CStringUtils::GetItemAtPos( strCurrCell, iCurrIndCellLine, "\n" ) ) != QString ::fromWCharArray("") )
		{
			++iNoOfLinesThisCell;
			// check if this line is viewable
			if( !pCEWrapper->IsPrinting() &&
				( ( ( iCurrIndCellLine + ulCURR_LINE ) >= ulFIRST_VIEWABLE_LINE ) &&
				( ( iCurrIndCellLine + ulCURR_LINE ) <= ulLAST_VIEWABLE_LINE ) ) )
			{
				++iNoOfLinesDrawnThisCell;			
	
				// yes this line is viewable therefore draw it
      strIndCellLine.Replace( "\n", QString ::fromWCharArray("") );
      strIndCellLine.Replace( "\t", QString ::fromWCharArray("") );
				pCEWrapper->PDC_DrawText(hDC, strIndCellLine, 
								strIndCellLine.size(),
								&tCellRect,
								DT_NOPREFIX | DT_WORD_ELLIPSIS );
				tCellRect.setTop(iCHAR_HEIGHT);
				tCellRect.setBottom(iCHAR_HEIGHT);
			}
			++iCurrIndCellLine;	
		}
		// check if greater than our current maximum
		if( iMaxLinesThisRow < iNoOfLinesThisCell )
		{
			// make this our new maximum
			iMaxLinesThisRow = iNoOfLinesThisCell;
		}
		// check if greater than our current maximum
		if( iMaxLinesDrawnThisRow < iNoOfLinesDrawnThisCell )
		{
			// make this our new maximum
			iMaxLinesDrawnThisRow = iNoOfLinesDrawnThisCell;
		}
		// store the end position of this cell
		ulPrevCellEndPos = ulCELL_END_POS;
		++iCurrCell;
	}
	if( usNO_OF_COLS >= 10 )
	{	
		// restore the original font
		pCEWrapper->PDC_SelectObject(hDC, hOldFont );
		pkFontCache->ReleaseFont( hFont );
	}
	// offset the top as appropriate
	rtClipRect.top += ( iMaxLinesDrawnThisRow * iCHAR_HEIGHT );
	rtClipRect.bottom += ( iMaxLinesDrawnThisRow * iCHAR_HEIGHT );
	return iMaxLinesThisRow;
}

#endif

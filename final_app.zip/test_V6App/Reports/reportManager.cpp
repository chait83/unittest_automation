/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Report system
/// @n Filename:  ReportManager.cpp
/// @n Description: Implementation of the CReportManager class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  74  Aristos  1.68.1.3.1.0 9/19/2011 4:51:07 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  73  Stability Project 1.68.1.3 7/2/2011 5:00:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  72  Stability Project 1.68.1.2 7/1/2011 4:38:49 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  71  Stability Project 1.68.1.1 3/17/2011 3:20:41 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "V6globals.h"
#include "V6Config.h"
#include "StringDefinitions.h"
#include "rtflib.h"
#include "RTFGlobals.h"
#include "reportdoc.h"
#include "CStorage.h"
#include "reportManager.h"
#include "DataItemManager.h"
#include "SMTPThread.h"
#include "BatchManager.h"
#include "V6globals.h"
#include "BrdInfo.h"
#include "SlotMap.h"
#include "PenManager.h"
#include "PrintManager.h"
#include "EditPrint.h"
#include "Crypto.h"
#include "AMS2750TUSMgr.h"
#include "MediaManager.h"	//E527303
#include "ThreadInfo.h"
const UCHAR NO_DATA_COLUMNS = 1;
const UCHAR SINGLE_DATA_COLUMN = 2;
std::unique_ptr<CReportManager> CReportManager::ms_kReportMgr;
QMutex CReportManager::m_kCritSect;
QMutex CReportManager::m_CreationMutex;
T_NUMFORMAT CReportManager::ms_tNumasprintf = { TRUE, FALSE, FALSE, 0, 0, FALSE, 0, 0 };
CReportManager::CReportManager() : m_usReportsInProgressRefCount(0) {
// use a default number format for real numbers
	ms_tNumasprintf.Auto = TRUE;
	ms_tNumasprintf.Base = FALSE;
	ms_tNumasprintf.Zpad = FALSE;
	ms_tNumasprintf.Scientific = FALSE;
	// Remove all decimal points for counters
	m_tCounterasprintf.Auto = FALSE;
	m_tCounterasprintf.Base = FALSE;
	m_tCounterasprintf.Zpad = FALSE;
	m_tCounterasprintf.Scientific = FALSE;
	m_tCounterasprintf.Ad = 0;
	m_pReportGenThread = NULL; //PSR - fix for Bob's issue 1-30DY01Q
}
//**********************************************************************
///
/// Instance creation of CReportManager singleton
///
/// @return		pointer to single instance of CReportManager
/// 
//**********************************************************************
CReportManager* CReportManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == ms_kReportMgr.get()) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == ms_kReportMgr.get()) {
				// not been created yet therefore create one now
				std::unique_ptr<CReportManager> kNewReportMgr(new CReportManager);
				ms_kReportMgr = kNewReportMgr;
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, "REPORTMANAGER WaitForSingleObject Error", "Report Manager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		CloseHandle(m_CreationMutex);
	}
	return ms_kReportMgr.get();
}
const int iREGISTER_FAILED = -1;
//******************************************************
//
/// Receives notification of event causes to use to stop event.
/// @param[in] fileName - Filename to be used for report.
/// @param[in] reportID - Report number that report belongs to.
///
/// @return -1 if failed to register file; otherwise 0.
/// 
//******************************************************
int CReportManager::RegisterReport(const QString fileName, const USHORT reportID) {
	int retValue = iREGISTER_FAILED;
	// Log report name as used with report ID
	return retValue;
}
//****************************************************************************
// const QString GetMessageIDString( const USHORT usMESSAGE_TYPE )
///
/// Get the message string for the passed in message type
///
/// @param[in]			const USHORT usMESSAGE_TYPE - The type of message
///
/// @return				The index of the image within the image list
///
//****************************************************************************
const QString CReportManager::GetMessageIDString(const USHORT usMESSAGE_TYPE) {
	QString strMessageType;
	switch (usMESSAGE_TYPE) {
	case MSGLISTSER_ALARM_INTO:
		strMessageType = tr("In");
		break;
	case MSGLISTSER_ALARM_OUTOF:
		strMessageType = tr("Out");
		break;
	case MSGLISTSER_ALARM_OUTOF_NOT_ACK:
		strMessageType = tr("Out Ack");
		break;
	case MSGLISTSER_ALARM_ACK_WHILE_IN:
		strMessageType = tr("Ack in");
		break;
	case MSGLISTSER_ALARM_ACK_WHILE_OUT:
		strMessageType = tr("Ack out");
		break;
	case MSGLISTSER_SYSTEM_INFORMATION:
		strMessageType = tr("Info");
		break;
	case MSGLISTSER_SYSTEM_WARNING:
		strMessageType = tr("Warning");
		break;
	case MSGLISTSER_SYSTEM_ERROR:
		strMessageType = tr("Error");
		break;
	case MSGLISTSER_DIAGNOSTIC_INFO:
		strMessageType = tr("Info");
		break;
	case MSGLISTSER_DIAGNOSTIC_WARNING:
		strMessageType = tr("Warning");
		break;
	case MSGLISTSER_DIAGNOSTIC_ERROR:
		strMessageType = tr("Error");
		break;
	case MSGLISTSER_SECURITY_TEMPORARY_USER_LOG_ON:
		strMessageType = tr("Temp logon");
		break;
	case MSGLISTSER_SECURITY_LOG_ON:
		strMessageType = tr("Logon");
		break;
	case MSGLISTSER_SECURITY_LOG_OFF:
		strMessageType = tr("Logoff");
		break;
	case MSGLISTSER_SECURITY_PASSWORD_FAILURE:
		strMessageType = tr("Password");
		break;
	case MSGLISTSER_SECURITY_USERNAME_FAILURE:
		strMessageType = tr("Username");
		break;
	case MSGLISTSER_SECURITY_DAYMASK_FAILURE:
		strMessageType = tr("Day mask");
		break;
	case MSGLISTSER_SECURITY_LOGINTIME_FAILURE:
		strMessageType = tr("Log time");
		break;
	case MSGLISTSER_SECURITY_USERLEVEL_FAILURE:
		strMessageType = tr("Level");
		break;
	case MSGLISTSER_SECURITY_PASSWORD_EXPIRED:
		strMessageType = tr("Expired");
		break;
	case MSGLISTSER_SECURITY_PASSWORD_LOCKED:
		strMessageType = tr("Locked");
		break;
	case MSGLISTSER_SECURITY_INVALID_USER_ID:
		strMessageType = tr("Invalid user");
		break;
	case MSGLISTSER_SECURITY_VALID_AREA:
		strMessageType = tr("Area Auth");
		break;
	case MSGLISTSER_SECURITY_INVALID_USER_AREA:
		strMessageType = tr("Unknown Area");
		break;
	case MSGLISTSER_SECURITY_INACTIVITY_TIMEOUT:
		strMessageType = tr("Timeout");
		break;
	case MSGLISTSER_USER_BATCH_USER_ID:
		strMessageType = tr("Batch user");
		break;
	case MSGLISTSER_USER_BATCH_LOT_NO:
		strMessageType = tr("Batch lot");
		break;
	case MSGLISTSER_USER_BATCH_DESC:
		strMessageType = tr("Batch desc");
		break;
	case MSGLISTSER_USER_BATCH_GENERIC:
		strMessageType = tr("Batch");
		break;
	case MSGLISTSER_USER_BATCH_START:
		strMessageType = tr("Start");
		break;
	case MSGLISTSER_USER_BATCH_STOP:
		strMessageType = tr("Stop");
		break;
	case MSGLISTSER_USER_BATCH_PAUSE:
		strMessageType = tr("Pause");
		break;
	case MSGLISTSER_USER_BATCH_RESUME:
		strMessageType = tr("Resume");
		break;
	case MSGLISTSER_USER_BATCH_ABORT:
		strMessageType = tr("Abort");
		break;
	case MSGLISTSER_USER_GROUP_MARK_ON_CHART:
		strMessageType = tr(IDS_REPORT_MSGLIST_USER_GROUP_MARK_ON_CHART);
		break;
	case MSGLISTSER_USER_MODBUS_MESSAGE:
		strMessageType = tr("Modbus");
		break;
	case MSGLISTSER_USER_GROUP_START_LOGGING_CHART:
		strMessageType = tr("Start");
		break;
	case MSGLISTSER_USER_GROUP_STOP_LOGGING_CHART:
		strMessageType = tr("Stop");
		break;
	case MSGLISTSER_USER_GROUP_ALARM_CHANGE:
		strMessageType = tr("Alarm Chng");
		break;
	case MSGLISTSER_USER_GROUP_TOTALS_STARTED:
		strMessageType = tr("Started");
		break;
	case MSGLISTSER_USER_GROUP_TOTALS_PAUSED:
		strMessageType = tr("Paused");
		break;
	case MSGLISTSER_USER_GROUP_TOTALS_RESUMED:
		strMessageType = tr("Esumed");
		break;
	case MSGLISTSER_USER_GROUP_TOTALS_RESET:
		strMessageType = tr("Reset");
		break;
	case MSGLISTSER_DIGITAL_ACTIVATE:
		strMessageType = tr("Act");
		break;
	case MSGLISTSER_DIGITAL_DEACTIVATE:
		strMessageType = tr("Deact");
		break;
	case MSGLISTSER_USER_GROUP_MAX_MIN_RESET:
		strMessageType = tr("Reset");
		break;
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_PAUSE:
		strMessageType = tr("Pause");
		break;
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_STOP:
		strMessageType = tr("Stop");
		break;
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_RESUME:
		strMessageType = tr("Resume");
		break;
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_CLEAR:
		strMessageType = tr("Clear");
		break;
	case MSGLISTSER_USER_GROUP_CHART_CONTROL_PREFILL:
		strMessageType = tr("Prefill");
		break;
	case MSGLISTSER_USER_GROUP_CLEAR_MESSAGE_LIST:
		strMessageType = tr("Clear Msg");
		break;
	case MSGLISTSER_SMTP_CLIENT_INFO:
		strMessageType = tr("Info");
		break;
	case MSGLISTSER_SMTP_CLIENT_ERROR:
		strMessageType = tr("Error");
		break;
	case MSGLISTSER_SMTP_SERVER_INFO:
		strMessageType = tr("Info");
		break;
	case MSGLISTSER_SMTP_SERVER_WARNING:
		strMessageType = tr("Warning");
		break;
	case MSGLISTSER_SMTP_SERVER_ERROR:
		strMessageType = tr("Error");
		break;
	case MSGLISTSER_FTP_INFO:
		strMessageType = tr("Info");
		break;
	case MSGLISTSER_FTP_ERROR:
		strMessageType = tr("Error");
		break;
	case MSGLISTSER_FTP_WARNING:
		strMessageType = tr("Warning");
		break;
	case MSGLISTSER_P2P_INFO:
	case MSGLISTSER_P2P_PWD_INFO:
		strMessageType = tr("Info");
		break;
	case MSGLISTSER_P2P_ERROR:
	case MSGLISTSER_P2P_PWD_ERROR:
		strMessageType = tr("Error");
		break;
	case MSGLISTSER_P2P_WARNING:
	case MSGLISTSER_P2P_PWD_WARNING:
		strMessageType = tr("Warning");
		break;
	default:
		strMessageType = tr("Error");
		break;
	}
	return strMessageType;
}
#define MAX_MESSAGE_TABLE_COLS 8
// const LONGLONG llONE_HOUR = 3600000000;
const LONGLONG llONE_HOUR = 60 * 60 * (LONGLONG) 1000000;
const LONGLONG llONE_DAY = 24 * llONE_HOUR;
const LONGLONG llONE_WEEK = 7 * llONE_DAY;
const USHORT usmSecsToHundrethSecs = 10;
//******************************************************
//
/// Produces a single message table
/// @param[in] reportNo - Report number.
/// @param[in] kNewRTFFile - The report file RTF handler.
/// @param[in] ptReports - Reports configuration information.
/// @param[in] eMessageFilter - Which table to add.
///
//******************************************************
void CReportManager::ProcessSingleMessageTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo,
		ULONG eMessageFilter) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	LONGLONG llNewestMessageTime = 0L;
	LONGLONG llOldestMessageTime = 0L;
	LONGLONG llOldestMessageTick = 0L;
	LONGLONG llTimeNow = 0L;
	CBatchManager *pkBatchManager = CBatchManager::Instance();
	const T_BATCH_INFO &rkBATCH_INFO = pkBatchManager->GetBatchInfo(ptReports->Report[reportNo].Group);
	T_PEN_GROUPS ePEN_GROUP = PEN_GROUP_ALL;
	std::deque<T_MSGLISTSER_MESSAGE> rkMESSAGES;
	QString strTitle("");
	QString strHeaderItem("");
	QString strHeaderInfo("");
	QString strTableInfo("");
	TCHAR strOldestMessageTime[50];
	TCHAR strNewestMessageTime[50];
	bool noMessagesFound = true;
	TCHAR when[50];
	CTVtime currTime;
	int colNo = 0;
	currTime.TimeNow();
	llNewestMessageTime = llTimeNow = currTime.GetMicroSecs();
	llOldestMessageTick = pSYSTIMER->GetOnGoingProcessTick();
	if (rssNORMAL == ptReports->Report[reportNo].ReportStyle) {
		if ((ptReports->Report[reportNo].IncMessages == rftHOUR) || (ptReports->Report[reportNo].IncMessages == rftDAY)
				|| (ptReports->Report[reportNo].IncMessages == rftWEEK)) {
			if (ptReports->Report[reportNo].IncMessages == rftHOUR) {
				llOldestMessageTime = llTimeNow - llONE_HOUR;
				llOldestMessageTick -= (llONE_HOUR / usmSecsToHundrethSecs);
			} else if (ptReports->Report[reportNo].IncMessages == rftDAY) {
				llOldestMessageTime = llTimeNow - llONE_DAY;
				llOldestMessageTick -= (llONE_DAY / usmSecsToHundrethSecs);
			} else if (ptReports->Report[reportNo].IncMessages == rftWEEK) {
				llOldestMessageTime = llTimeNow - llONE_WEEK;
				llOldestMessageTick -= (llONE_WEEK / usmSecsToHundrethSecs);
			}
		} else if (ptReports->Report[reportNo].IncMessages == rftMONTH) {
			USHORT daysInMonth = currTime.GetDaysInMonth(currTime.GetMonthAndYear() - 1);
			// Check back to same day and time one month previous
			llOldestMessageTime = llTimeNow - (daysInMonth * llONE_DAY);
			llOldestMessageTick -= (daysInMonth * (llONE_DAY / usmSecsToHundrethSecs));
		} else {
			llOldestMessageTick = 0;
		}
	} else if (IsBatchEnabled(reportNo, ptReports) && (rkBATCH_INFO.llStartTime != 0)) {
		// Get start time of valid batch and use that a oldest time
		llOldestMessageTime = rkBATCH_INFO.llStartTime;
		llOldestMessageTick -= ((llTimeNow - llOldestMessageTime / usmSecsToHundrethSecs));
		if (rkBATCH_INFO.llFinishTime != 0) {
			// if batch is finished then we need to ensure no messages past the end of batch is displayed
			llNewestMessageTime = rkBATCH_INFO.llFinishTime;
		}
	}
	if (IsReportByGroup(reportNo, ptReports) == true) {
		// If it is batch or pen group enabled then we are only interested in messages that belong to that group
		ePEN_GROUP = static_cast<T_PEN_GROUPS>(ptReports->Report[reportNo].Group + 1);
	}
	if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) == eMessageFilter)
			|| ((ptReports->Report[reportNo].IncMsgListTypes & mfSystem) == eMessageFilter)
			|| ((ptReports->Report[reportNo].IncMsgListTypes & mfDiagnostic) == eMessageFilter)
			|| ((ptReports->Report[reportNo].IncMsgListTypes & mfSecurity) == eMessageFilter)
			|| ((ptReports->Report[reportNo].IncMsgListTypes & mfUser) == eMessageFilter)
			|| ((ptReports->Report[reportNo].IncMsgListTypes & mfSMTP) == eMessageFilter)
			|| ((ptReports->Report[reportNo].IncMsgListTypes & mfFTP) == eMessageFilter)
			|| ((ptReports->Report[reportNo].IncMsgListTypes & mfP2P) == eMessageFilter) || (eMessageFilter == mfAll)) {
		int iColWidths[ MAX_MESSAGE_TABLE_COLS];
		// Prescan to make sure there are some messages for the table
		pMSG_SERVICES->GetFilteredMessages(200, static_cast<T_MESSAGE_FILTER>(eMessageFilter), rkMESSAGES,
				llOldestMessageTick, ePEN_GROUP, true);
		// We now have all the messages we want, but may have more, if recorder power has been cycled recently
		// or if the batch finished a while ago
		std::deque<T_MSGLISTSER_MESSAGE>::const_iterator kCurr = rkMESSAGES.begin();
		std::deque<T_MSGLISTSER_MESSAGE>::const_iterator kEnd = rkMESSAGES.end();
		std::deque<T_MSGLISTSER_MESSAGE>::const_iterator kItem = kEnd;
		// Trim the extra older messages, if recorder has been power cycled
		if ((kCurr != kEnd) && (llOldestMessageTime != 0)) {
			while ((kCurr != kEnd) && ((*kCurr).logTime < llOldestMessageTime)) {
				++kCurr;
			}
		}
		// if batch is finished then we need to ensure no messages past the end of batch is displayed
		if (IsBatchEnabled(reportNo, ptReports) && (rkBATCH_INFO.llFinishTime != 0) && (kCurr != kEnd)) {
			--kEnd;
			while ((kCurr != kEnd) && ((*kEnd).logTime > rkBATCH_INFO.llFinishTime)) {
				--kEnd;
			}
			// now restore the end iterator back to where it should be i.e. on the previous reading - this stops
			// a problem later where the newest message is missed
			++kEnd;
		}
		// Check for no messages in list at all or
		// The earliest item has been found to have occurred after the batch has finished and/or
		// Removing all the too old messages has left non to display
		if (kCurr != kEnd) {
			noMessagesFound = false;
		}
		// Title table
		if (((rssNORMAL == ptReports->Report[reportNo].ReportStyle)
				&& (ptReports->Report[reportNo].IncMessages == rftALL))
				|| ((rssBATCH == ptReports->Report[reportNo].ReportStyle) && (rkBATCH_INFO.llStartTime == 0))) {
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) == eMessageFilter))
				strTableInfo = tr("Alarm Message Information");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSystem) == eMessageFilter))
				strTableInfo = tr("System Message Information");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfDiagnostic) == eMessageFilter))
				strTableInfo = tr("Diagnostic Message Information");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSecurity) == eMessageFilter))
				strTableInfo = tr("Security Message Information");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfUser) == eMessageFilter))
				strTableInfo = tr("User Message Information");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSMTP) == eMessageFilter)) {
				strTableInfo = tr("SMTP Message Information");
			}
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfFTP) == eMessageFilter)) {
				strTableInfo = tr("FTP Message Information");
			}
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfP2P) == eMessageFilter)) {
				strTableInfo = tr("P2P Message Information");
			}
		} else {
			CTVtime NewestMessTime(llNewestMessageTime);
			CTVtime OldestMessTime(llOldestMessageTime);
			NewestMessTime.TimeToStringNoFracs(strNewestMessageTime);
			OldestMessTime.TimeToStringNoFracs(strOldestMessageTime);
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) == eMessageFilter))
				strTableInfo = QString::asprintf(IDS_REPORT_ALARM_BETWEEN_MESSAGES_TITLE, strOldestMessageTime,
						strNewestMessageTime);
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSystem) == eMessageFilter))
				strTableInfo = QString::asprintf(IDS_REPORT_SYSTEM_BETWEEN_MESSAGES_TITLE, strOldestMessageTime,
						strNewestMessageTime);
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfDiagnostic) == eMessageFilter))
				strTableInfo = QString::asprintf(IDS_REPORT_DIAGNOSTIC_BETWEEN_MESSAGES_TITLE, strOldestMessageTime,
						strNewestMessageTime);
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSecurity) == eMessageFilter))
				strTableInfo = QString::asprintf(IDS_REPORT_SECURITY_BETWEEN_MESSAGES_TITLE, strOldestMessageTime,
						strNewestMessageTime);
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfUser) == eMessageFilter))
				strTableInfo = QString::asprintf(IDS_REPORT_USER_BETWEEN_MESSAGES_TITLE, strOldestMessageTime,
						strNewestMessageTime);
		}
		kNewRTFFile.AddTitle(strTableInfo);
		if (noMessagesFound == true) {
			// State if no messages are available
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) == eMessageFilter))
				strTableInfo = tr("No alarm messages available.");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSystem) == eMessageFilter))
				strTableInfo = tr("No system messages available.");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfDiagnostic) == eMessageFilter))
				strTableInfo = tr("No diagnostic messages available.");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSecurity) == eMessageFilter))
				strTableInfo = tr("No security messages available.");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfUser) == eMessageFilter))
				strTableInfo = tr("No user messages available.");
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfSMTP) == eMessageFilter)) {
				strTableInfo = tr("No SMTP messages available.");
			}
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfFTP) == eMessageFilter)) {
				strTableInfo = tr("No FTP messages available.");
			}
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfP2P) == eMessageFilter)) {
				strTableInfo = tr("No P2P messages available.");
			}
			kNewRTFFile.rtf_start_paragraph(strTableInfo, false);
		} else {
			strHeaderItem = "";
			strHeaderInfo = "";
			// Create new section
			kNewRTFFile.StartTable();
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) != eMessageFilter)) {
				strHeaderItem = tr("Type");
				strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
				iColWidths[colNo++] = 10;
			}
			strHeaderItem = tr("Time");
			strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
			iColWidths[colNo++] = 15;
			strHeaderItem = tr("Date");
			strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
			iColWidths[colNo++] = 15;
			strHeaderItem = tr("Message");
			strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
			if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) == eMessageFilter)) {
				iColWidths[colNo++] = 50;
				// Extra columns required for all info
				/*
				 strHeaderItem = tr("Alm No");
				 strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
				 iColWidths[colNo++] = 10;
				 */
				strHeaderItem = tr("Alm Type");
				strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
				iColWidths[colNo++] = 10;
				strHeaderItem = tr("Alm Level");
				strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
				iColWidths[colNo++] = 10;
				/*
				 strHeaderItem = tr("Pen No");
				 strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
				 iColWidths[colNo++] = 10;
				 */
			} else {
				iColWidths[colNo++] = 60;
			}
			kNewRTFFile.AddTableHeader(strHeaderInfo, iColWidths);
			const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
			cf->SHADING.shadingBkColor = 3;
			pf->CHARACTER.boldCharacter = false;
			while (kCurr != kEnd) {
				// If it's batch we want to display the oldest message first;
				// otherwise display the newest message first
				if (rssBATCH != ptReports->Report[reportNo].ReportStyle) {
					--kEnd;
					kItem = kEnd;
				} else {
					kItem = kCurr;
				}
				kNewRTFFile.StartVarWidthRow(iNO_OF_COLS, iColWidths);
				if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) != eMessageFilter)) {
					strTitle = GetMessageIDString((*kItem).messageType);
					kNewRTFFile.rtf_start_paragraph(strTitle, false);
					// End table cell
					kNewRTFFile.rtf_end_tablecell();
				}
				// Add another row to the table
				CTVtime MessageTime((*kItem).logTime);
				MessageTime.TimeToHourMinsSecsString(when);
				strTitle = QString::asprintf("%s", when);
				kNewRTFFile.rtf_start_paragraph(strTitle, false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
//				MessageTime.DateAsString( strTitle );
//				MessageTime.TimeTemplateDateFirstString( L"ddd MMM dd yy ", L"HH':'mm':'ss", when );
				MessageTime.TimeTemplateDateFirstString("dd/MM/yy ", NULL, when);
				strTitle = QString::asprintf("%s", when);
				kNewRTFFile.rtf_start_paragraph(strTitle, false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				strTitle = QString::fromWCharArray((*kItem).messageText);
				kNewRTFFile.rtf_start_paragraph(strTitle, false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				if (((ptReports->Report[reportNo].IncMsgListTypes & mfAlarm) == eMessageFilter)) {
					/*
					 strTitle = QString::asprintf( L"%d", (*kItem).messageData.uCharParam[MSGLISTSER_ALARM_NUMBER_UCHAR_ELEMENT] );
					 kNewRTFFile.rtf_start_paragraph( strTitle, false );
					 // End table cell
					 kNewRTFFile.rtf_end_tablecell();
					 */
//					strTitle = QString::asprintf( L"%s", (*kEnd).messageData.uCharParam[MSGLISTSER_ALARM_FLAGS_UCHAR_ELEMENT];
					QString strAlarmTypeList;
					strAlarmTypeList = tr("High|Low|Deviation|Rate Up|Rate Down|");
					QString strType = CStringUtils::GetItemAtPos(strAlarmTypeList,
							(*kItem).messageData.uCharParam[MSGLISTSER_ALARM_TYPE_UCHAR_ELEMENT]);
					kNewRTFFile.rtf_start_paragraph(strType, false);
					// End table cell
					kNewRTFFile.rtf_end_tablecell();
					strTitle = CStringUtils::FormatFloat(ms_tNumasprintf,
							(*kItem).messageData.floatParam[MSGLISTSER_ALARM_LEVEL_FLOAT_ELEMENT]);
					kNewRTFFile.rtf_start_paragraph(strTitle, false);
					// End table cell
					kNewRTFFile.rtf_end_tablecell();
					/*
					 strTitle = QString::asprintf( L"%d", ((*kItem).messageData.uCharParam[MSGLISTSER_ALARM_PEN_NUMBER_UCHAR_ELEMENT])+1 );
					 kNewRTFFile.rtf_start_paragraph( strTitle, false );
					 // End table cell
					 kNewRTFFile.rtf_end_tablecell();
					 */
				}
				// End table row
				kNewRTFFile.rtf_end_tablerow();
				if (rssBATCH == ptReports->Report[reportNo].ReportStyle)
					++kCurr;
			}
			kNewRTFFile.EndTable();
		}
		// Leave blank lines at end
		kNewRTFFile.rtf_start_paragraph("", true);
		kNewRTFFile.rtf_start_paragraph("", true);
	}
}
#define MAX_REPORT_MESSAGE_TABLES		5
//******************************************************
//
/// Produces table for all selected messages
/// @param[in] reportNo - Report number.
/// @param[in] kNewRTFFile - The report file RTF handler.
/// @param[in] ptReports - Reports configuration information.
///
//******************************************************
void CReportManager::MessageInfoReport(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	ULONG eMessageFilter = mfAlarm;
	USHORT tableNo = 0;
	for (tableNo = 0; tableNo < MAX_REPORT_MESSAGE_TABLES; tableNo++) {
		// Add table if type selected
		ProcessSingleMessageTable(ptReports, kNewRTFFile, reportNo, eMessageFilter);
		// Next message table type
		eMessageFilter <<= 1;
	}
}
//******************************************************
//
/// Create a seperate batch report table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file RTF handler.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::BatchInfoReport(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	CBatchManager *pkBatchManager = CBatchManager::Instance();
	const T_BATCH_INFO &rkBATCH_INFO = pkBatchManager->GetBatchInfo(ptReports->Report[reportNo].Group);
	TCHAR when[50];
	QString strNA("");
	strNA = tr("NA");
	QString strTitle("");
	QString strValue("");
	QString strDuration("");
	QString strBatchNameTitle("");
	QString strDescriptionTitle("");
	QString strUserIDTitle("");
	QString strLotNoTitle("");
	QString strCommentTitle("");
//	kNewRTFFile.rtf_start_section();
	strTitle = tr("Batch Status");
	kNewRTFFile.AddTitle(strTitle);
	// Create new section
	kNewRTFFile.StartTable();
	// No header & invisible table
	USHORT iNO_OF_COLS = 2;
	cf->SHADING.shadingBkColor = 3;
	// asprintf paragraph
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
	pf->CHARACTER.boldCharacter = false;
	cf->borderBottom.border = false;
	cf->borderTop.border = false;
	cf->borderright.border = false;
	cf->borderleft.border = false;
	strBatchNameTitle = QString::fromWCharArray(ptGeneralData->Batch.FieldNames[bflNAME]);
	strDescriptionTitle = QString::fromWCharArray(ptGeneralData->Batch.FieldNames[bflDESCRIPTION]);
	strUserIDTitle = QString::fromWCharArray(ptGeneralData->Batch.FieldNames[bflUSER_ID]);
	strLotNoTitle = QString::fromWCharArray(ptGeneralData->Batch.FieldNames[bflLOT_NO]);
	strCommentTitle = QString::fromWCharArray(ptGeneralData->Batch.FieldNames[bflCOMMENT]);
	kNewRTFFile.StartRow(iNO_OF_COLS);
	//	strBatchNameTitle = tr("Batch Name:");
	strBatchNameTitle += ": ";
	kNewRTFFile.rtf_start_paragraph(strBatchNameTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// check if the last batch was aborted
	if (!rkBATCH_INFO.bLastBatchAborted) {
		kNewRTFFile.rtf_start_paragraph(rkBATCH_INFO.strName, false);
	} else {
		// batch was aborted thererfore put the aborted text after the batch name
		QString strAborted("");
		strAborted = tr("(Aborted)");
		kNewRTFFile.rtf_start_paragraph(rkBATCH_INFO.strName + strAborted, false);
	}
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.StartRow(iNO_OF_COLS);
	strTitle = tr("Group Name:");
	kNewRTFFile.rtf_start_paragraph(strTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	strTitle = QString::fromWCharArray(ptGeneralData->GroupName[ptReports->Report[reportNo].Group]);
	kNewRTFFile.rtf_start_paragraph(strTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.StartRow(iNO_OF_COLS);
	//	strUserIDTitle = tr("User ID:");
	strUserIDTitle += ": ";
	kNewRTFFile.rtf_start_paragraph(strUserIDTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// Display the relevant value if available otherwise display 'NA'
	if (ptGeneralData->Batch.BSUserID) {
		strUserIDTitle = rkBATCH_INFO.strUserID;
	} else {
		strUserIDTitle = strNA;
	}
	// Write paragraph tabbed text
	kNewRTFFile.rtf_start_paragraph(strUserIDTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.StartRow(iNO_OF_COLS);
	//	strLotNoTitle = tr("Lot No:");
	strLotNoTitle += ": ";
	kNewRTFFile.rtf_start_paragraph(strLotNoTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// Display the relevant value if available otherwise display 'NA'
	if (ptGeneralData->Batch.BSLot) {
		strLotNoTitle = rkBATCH_INFO.strLotNo;
	} else {
		strLotNoTitle = strNA;
	}
	kNewRTFFile.rtf_start_paragraph(strLotNoTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.StartRow(iNO_OF_COLS);
	//	strDescriptionTitle = tr("Description:");
	strDescriptionTitle += ": ";
	kNewRTFFile.rtf_start_paragraph(strDescriptionTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// Display the relevant value if available otherwise display 'NA'
	if (ptGeneralData->Batch.BSDesc) {
		strDescriptionTitle = rkBATCH_INFO.strDescription;
	} else {
		strDescriptionTitle = strNA;
	}
	kNewRTFFile.rtf_start_paragraph(strDescriptionTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.StartRow(iNO_OF_COLS);
	//	strCommentTitle = tr("Comment:");
	strCommentTitle += ": ";
	kNewRTFFile.rtf_start_paragraph(strCommentTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// Display the relevant value if available otherwise display 'NA'
	if (ptGeneralData->Batch.BSComment) {
		strCommentTitle = rkBATCH_INFO.strComment;
	} else {
		strCommentTitle = strNA;
	}
	kNewRTFFile.rtf_start_paragraph(strCommentTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
#if 0
	// Add Blank row
	kNewRTFFile.StartRow( iNO_OF_COLS );
	kNewRTFFile.rtf_start_paragraph(QString ::fromWCharArray(""), false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	kNewRTFFile.rtf_start_paragraph(QString ::fromWCharArray(""), false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
#endif
	kNewRTFFile.StartRow(iNO_OF_COLS);
	strTitle = tr("Start:");
	kNewRTFFile.rtf_start_paragraph(strTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// Check if the start time is set
	if (rkBATCH_INFO.llStartTime == 0) {
		strValue = strNA;
	} else {
		const CTVtime kSTART_TIME(rkBATCH_INFO.llStartTime);
		kSTART_TIME.TimeToStringNoFracs(when);
		strValue = QString::asprintf("%s", when);
	}
	kNewRTFFile.rtf_start_paragraph(strValue, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.StartRow(iNO_OF_COLS);
	strTitle = tr("Finish:");
	kNewRTFFile.rtf_start_paragraph(strTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// Check if the finish time is set
	if (rkBATCH_INFO.llFinishTime == 0) {
		strValue = strNA;
		strDuration = strNA;
	} else {
		const CTVtime kFINISH_TIME(rkBATCH_INFO.llFinishTime);
		kFINISH_TIME.TimeToStringNoFracs(when);
		strValue = QString::asprintf("%s", when);
		const LONGLONG llTIME_IN_SECONDS = USEC_TO_SEC(rkBATCH_INFO.llFinishTime - rkBATCH_INFO.llStartTime);
		strDuration = CStringUtils::GetAutoDDHHMMSSspanFromSeconds(llTIME_IN_SECONDS);
	}
	kNewRTFFile.rtf_start_paragraph(strValue, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.StartRow(iNO_OF_COLS);
	strTitle = tr("Duration:");
	kNewRTFFile.rtf_start_paragraph(strTitle, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	kNewRTFFile.rtf_start_paragraph(strDuration, false);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.EndTable();
	// Leave blank lines at end
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the seperate pen value table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreatePenValueTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	USHORT penNo = 0;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	bool tableEntriesFound = false;
	kNewRTFFile.rtf_start_section();
	for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
		CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
		T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
		// Only process if pen is available and selected for report
		if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
			tableEntriesFound = true;
			break;
		}
	}
	// add the table title
	strHeaderItem = tr("Pen Overview");
	kNewRTFFile.AddTitle(strHeaderItem);
	if (tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Pen");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Value");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
			CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
			T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
			if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_PEN, DI_PEN_READING, penNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_PEN, DI_PEN_READING, penNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no totals enabled");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the seperate digital table
/// @param[in] digIn - true if digital in selected; false if output.
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateDigitalValueTable(const bool digIn, T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
		const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	CIOSetupConfig *pkIOCfg = pSETUP->GetIOSetupConfig();
	T_PDIGCHANNEL pDigChanCfg = NULL;
	class CSlotMap *pSlotMap = CSlotMap::GetHandle();
	class CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	USHORT digNo = 0;
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	UCHAR boardType;
	USHORT chanType = CHANNEL_DI;
	QString strNodigitalAvailable("");
	QString strHeaderItem("");
	QString strHeaderInfo("");
	bool tableEntriesFound = false;
	kNewRTFFile.rtf_start_section();
	if (true == digIn) {
		chanType = CHANNEL_DI;
		strHeaderItem = tr("Digital In State Information");
		strNodigitalAvailable = tr("No digital inputs.");
	} else {
		chanType = CHANNEL_DO;
		strHeaderItem = tr("Digital Out State Information");
		strNodigitalAvailable = tr("No digital outputs.");
	}
	for (digNo = 0; digNo < MAX_DIGITAL_IO; digNo++) {
		pSlotMap->GetSlotAndChannelFromDigitalSysChan(digNo, slotNo, chanNo, ZERO_BASED);
		boardType = pBrdInfo->WhatBoardType(slotNo);
		pDigChanCfg = pkIOCfg->GetDigital(slotNo, chanNo, CONFIG_COMMITTED);
		// Only process if pen is available and selected for report
		if (((boardType == BOARD_DIO) || (boardType == BOARD_AR))
				&& (chanType == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
			tableEntriesFound = true;
			break;
		}
	}
	// add the table title
	kNewRTFFile.AddTitle(strHeaderItem);
	if (tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Pen");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Value");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (digNo = 0; digNo < MAX_DIGITAL_IO; digNo++) {
			pSlotMap->GetSlotAndChannelFromDigitalSysChan(digNo, slotNo, chanNo, ZERO_BASED);
			boardType = pBrdInfo->WhatBoardType(slotNo);
			pDigChanCfg = pkIOCfg->GetDigital(slotNo, chanNo, CONFIG_COMMITTED);
			if (((boardType == BOARD_DIO) || (boardType == BOARD_AR))
					&& (chanType == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(QString::fromWCharArray(pDigChanCfg->Label), false);
//				kNewRTFFile.rtf_start_paragraph( DecodeDataItemTag(DI_IO, DI_IO_DIGITAL, digNo), false );
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_IO, DI_IO_DIGITAL, digNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		kNewRTFFile.rtf_start_paragraph(strNodigitalAvailable, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the seperate max min table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateMaxMinTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	USHORT penNo = 0;
	TCHAR when[50];
	QString strHeaderItem("");
	QString strHeaderInfo("");
	QString strMaxItem("");
	QString strMinItem("");
	bool tableEntriesFound = false;
	kNewRTFFile.rtf_start_section();
	for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
		CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
		T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
		// Only process if pen is available and selected for report
		if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
			tableEntriesFound = true;
			break;
		}
	}
	// add the table title
	strHeaderItem = tr("System Max/Mins Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	if (tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Pen");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Max");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Min");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
			CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
			T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
			if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_PEN, DI_PEN_READING, penNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text
				strMaxItem = DecodeDataItemValue(DI_MMA, DI_MMA_TYPE_MAX, penNo);
				kNewRTFFile.rtf_start_paragraph(strMaxItem, false);
				CNVBasicTimeVar *pkMaxNV = pNV_VARS->GetBasicTimeNVObject(
						static_cast<NVVAR_IDENT>(NVV_PEN_MAX_FIRST + penNo));
				CTVtime kMaxTime((*pkMaxNV->GetFromNV()).time);
				kMaxTime.TimeToStringNoFracs(when);
				strMaxItem = QString::asprintf("@ %s", when);
				kNewRTFFile.rtf_start_paragraph(strMaxItem, true);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				strMinItem = DecodeDataItemValue(DI_MMA, DI_MMA_TYPE_MIN, penNo);
				kNewRTFFile.rtf_start_paragraph(strMinItem, false);
				CNVBasicTimeVar *pkMinNV = pNV_VARS->GetBasicTimeNVObject(
						static_cast<NVVAR_IDENT>(NVV_PEN_MIN_FIRST + penNo));
				CTVtime kMinTime((*pkMinNV->GetFromNV()).time);
				kMinTime.TimeToStringNoFracs(when);
				strMinItem = QString::asprintf("@ %s", when);
				kNewRTFFile.rtf_start_paragraph(strMinItem, true);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no totals enabled");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the seperate totals table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateTotalsTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	USHORT penNo = 0;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	bool tableEntriesFound = false;
	kNewRTFFile.rtf_start_section();
	for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
		CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
		T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
		// Only process if pen is available and selected for report
		if (IsTotalReportPenRequired(penNo, reportNo, ptReports) == true) {
			tableEntriesFound = true;
			break;
		}
	}
	// add the table title
	strHeaderItem = tr("System Total Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	if (tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Pen");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Totals");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
			CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
			T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
			if (IsTotalReportPenRequired(penNo, reportNo, ptReports) == true) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_TOTAL, DI_TOTAL_READING, penNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text	
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_TOTAL, DI_TOTAL_READING, penNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no totals enabled");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
#define FIRST_PEN_ALARM_FOUND 1
//******************************************************
//
/// Create the pen alarms counter table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreatePenAlarmCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
		const USHORT reportNo) {
	QString strCounterValue("");
	USHORT itemCount = 0;
	USHORT penNo = 0;
	USHORT alarmNo = 0;
	USHORT noOfPenAlarmFound = 0;
	QString strHeaderInfo("");
	T_PPEN pPenConfig = NULL;
	CPenManager *pkPenMgr = CPenManager::GetHandle();
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	bool tableEntriesFound = false;
	QString strValueItem("");
	QString strHeaderItem("");
	kNewRTFFile.rtf_start_section();
	for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
		pPenConfig = (pSETUP->GetPenSetupConfig())->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
		if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
			for (alarmNo = 0; alarmNo < PEN_ALM_SIZE; alarmNo++) {
				if (pPenConfig->Alm[alarmNo].EnableType != ALARM_DISABLED) {
					tableEntriesFound = true;
					break;
				}
			}
		}
		if (true == tableEntriesFound)
			break;
	}
	// add the table title
	strHeaderItem = tr("Alarm Counter Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	if (true == tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Pen");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Value");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 3;
		// asprintf paragraph
		pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
		//pf->CHARACTER.boldCharacter = true;
		pf->CHARACTER.boldCharacter = false;
		for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
			pPenConfig = (pSETUP->GetPenSetupConfig())->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
			noOfPenAlarmFound = 0;
			// Only process if pen is available and selected for report
			if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
				// Add each enabled alarm value to the same cell
				for (alarmNo = 0; alarmNo < PEN_ALM_SIZE; alarmNo++) {
					if (pPenConfig->Alm[alarmNo].EnableType != ALARM_DISABLED) {
						++noOfPenAlarmFound;
						// Report pen info only if pen and at least one alarm is enabled
						if ( FIRST_PEN_ALARM_FOUND == noOfPenAlarmFound) {
							kNewRTFFile.StartRow(iNO_OF_COLS);
							// Write paragraph text
							kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_PEN, DI_PEN_READING, penNo), false);
							// End table cell
							kNewRTFFile.rtf_end_tablecell();
						}
						CPenControl *pkPenCtrl = pkPenMgr->GetPenControl(penNo, ZERO_BASED);
						QString strCount("");
						strCount = QString::asprintf(IDS_ACTION_PICKER_DLG_ALARM_DESC_TITLE, alarmNo + 1,
								pkPenCtrl->GetAlarmPtr(alarmNo)->GetAlarmCounter());
						if ( FIRST_PEN_ALARM_FOUND == noOfPenAlarmFound) {
							// Write paragraph text
							kNewRTFFile.rtf_start_paragraph(strCount, false);
						} else {
							// Write paragraph text as new paragraph
							kNewRTFFile.rtf_start_paragraph(strCount, true);
						}
					}
				}	// end of alarm loop
				if (noOfPenAlarmFound > 0) {
					// End table cell
					kNewRTFFile.rtf_end_tablecell();
					// End table row
					kNewRTFFile.rtf_end_tablerow();
				}
			}
		}	// end of pen loop
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no enabled pen alarms.");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the user counter report table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateUserCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	USHORT UserCntNo = 0;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PCOUNTERS ptCounters = pkEventCfg->GetCountersBlock(CONFIG_COMMITTED);
	T_COUNTERSDATA *ptCounter = NULL;
	bool tableEntriesFound = false;
	kNewRTFFile.rtf_start_section();
	for (UserCntNo = 0; UserCntNo < V6_USER_COUNTERS; UserCntNo++) {
		ptCounter = &ptCounters->Counter[UserCntNo];
		// Only process if counter is available
		if (ptCounter->Enabled) {
			tableEntriesFound = true;
		}
	}
	// add the table title
	strHeaderItem = tr("User Counter Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	if (true == tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Counter");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Value");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (UserCntNo = 0; UserCntNo < V6_USER_COUNTERS; UserCntNo++) {
			ptCounter = &ptCounters->Counter[UserCntNo];
			// Only process if counter is available
			if (ptCounter->Enabled) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_COUNTER, DI_COUNTTYPE_USER, UserCntNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text	
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_COUNTER, DI_COUNTTYPE_USER, UserCntNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no user counters enabled");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the event counter report table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateEventCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	USHORT UserCntNo = 0;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PEVENTSYSTEM ptEvents = pkEventCfg->GetEventBlock(CONFIG_COMMITTED);
	T_EVENT *ptEvent = NULL;
	bool tableEntriesFound = false;
	kNewRTFFile.rtf_start_section();
	// add the table title
	strHeaderItem = tr("Event Counter Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	for (UserCntNo = 0; UserCntNo < V6_MAX_EVENTS; UserCntNo++) {
		ptEvent = &ptEvents->Event[UserCntNo];
		// Only process event counter if event is available
		if (ptEvent->Enabled) {
			tableEntriesFound = true;
		}
	}
	// Only add table if there are items to add to the table
	if (true == tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Counter");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Count");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (UserCntNo = 0; UserCntNo < V6_MAX_EVENTS; UserCntNo++) {
			ptEvent = &ptEvents->Event[UserCntNo];
			// Only process event counter if event is available
			if (ptEvent->Enabled) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_COUNTER, DI_COUNTTYPE_EVENTS, UserCntNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text	
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_COUNTER, DI_COUNTTYPE_EVENTS, UserCntNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no events enabled.");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the digital input counter report table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateDigitalInputCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
		const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	CIOSetupConfig *pkIOCfg = pSETUP->GetIOSetupConfig();
	T_PDIGCHANNEL pDigChanCfg = NULL;
	class CSlotMap *pSlotMap = CSlotMap::GetHandle();
	class CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	USHORT DigitalCntNo = 0;
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	UCHAR boardType;
	bool tableEntriesFound = false;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	kNewRTFFile.rtf_start_section();
	// add the table title
	strHeaderItem = tr("Digital Input Counter Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	// indexOf if there are entries to display
	for (DigitalCntNo = 0; DigitalCntNo < MAX_DIGITAL_IO; DigitalCntNo++) {
		pSlotMap->GetSlotAndChannelFromDigitalSysChan(DigitalCntNo, slotNo, chanNo, ZERO_BASED);
		boardType = pBrdInfo->WhatBoardType(slotNo);
		if (((boardType == BOARD_DIO) || (boardType == BOARD_AR))
				&& (CHANNEL_DI == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
			tableEntriesFound = true;
		}
	}
	// Only add table if there are items to add to the table
	if (true == tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Digital input");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		IDS_REPORT_DIGITAL_INPUT_STATE_TABLE_TITLE;
		strHeaderItem = tr("Count");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (DigitalCntNo = 0; DigitalCntNo < MAX_DIGITAL_IO; DigitalCntNo++) {
			// Only process if pulse counter is available
			pSlotMap->GetSlotAndChannelFromDigitalSysChan(DigitalCntNo, slotNo, chanNo, ZERO_BASED);
			boardType = pBrdInfo->WhatBoardType(slotNo);
			if (((boardType == BOARD_DIO) || (boardType == BOARD_AR))
					&& (CHANNEL_DI == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
				pDigChanCfg = pkIOCfg->GetDigital(slotNo, chanNo, CONFIG_COMMITTED);
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
//				kNewRTFFile.rtf_start_paragraph( DecodeDataItemTag(DI_COUNTER, DI_COUNTTYPE_IO, DigitalCntNo), false );
				kNewRTFFile.rtf_start_paragraph(QString::fromWCharArray(pDigChanCfg->Label), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text	
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_COUNTER, DI_COUNTTYPE_IO, DigitalCntNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no enabled digital inputs.");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the digital output counter report table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateDigitalOutputCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
		const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	CIOSetupConfig *pkIOCfg = pSETUP->GetIOSetupConfig();
	T_PDIGCHANNEL pDigChanCfg = NULL;
	class CSlotMap *pSlotMap = CSlotMap::GetHandle();
	class CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	USHORT DigitalCntNo = 0;
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	UCHAR boardType;
	bool tableEntriesFound = false;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	kNewRTFFile.rtf_start_section();
	// add the table title
	strHeaderItem = tr("Digital Output Counter Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	// indexOf if there are entries to display
	for (DigitalCntNo = 0; DigitalCntNo < MAX_DIGITAL_IO; DigitalCntNo++) {
		pSlotMap->GetSlotAndChannelFromDigitalSysChan(DigitalCntNo, slotNo, chanNo, ZERO_BASED);
		boardType = pBrdInfo->WhatBoardType(slotNo);
		if (((boardType == BOARD_DIO) || (boardType == BOARD_AR))
				&& (CHANNEL_DO == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
			tableEntriesFound = true;
		}
	}
	// Only add table if there are items to add to the table
	if (true == tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Digital output");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Count");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (DigitalCntNo = 0; DigitalCntNo < MAX_DIGITAL_IO; DigitalCntNo++) {
			// Only process if pulse counter is available
			pSlotMap->GetSlotAndChannelFromDigitalSysChan(DigitalCntNo, slotNo, chanNo, ZERO_BASED);
			boardType = pBrdInfo->WhatBoardType(slotNo);
			if (((boardType == BOARD_DIO) || (boardType == BOARD_AR))
					&& (CHANNEL_DO == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
				pDigChanCfg = pkIOCfg->GetDigital(slotNo, chanNo, CONFIG_COMMITTED);
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
//				kNewRTFFile.rtf_start_paragraph( DecodeDataItemTag(DI_COUNTER, DI_COUNTTYPE_IO, DigitalCntNo), false );
				kNewRTFFile.rtf_start_paragraph(QString::fromWCharArray(pDigChanCfg->Label), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text	
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_COUNTER, DI_COUNTTYPE_IO, DigitalCntNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no enabled digital outputs.");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the event counter report table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateBottomPulseCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
		const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	CIOSetupConfig *pkIOCfg = pSETUP->GetIOSetupConfig();
	T_PDIGCHANNEL pDigChanCfg = NULL;
	class CSlotMap *pSlotMap = CSlotMap::GetHandle();
	class CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	USHORT PulseCntNo = 0;
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	UCHAR boardType;
	bool tableEntriesFound = false;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	kNewRTFFile.rtf_start_section();
	// add the table title
	strHeaderItem = tr("Lo Resolution Pulse Counter Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	// indexOf if there are entries to display
	for (PulseCntNo = 0; PulseCntNo < MAX_LORES_PULSE; PulseCntNo++) {
		pSlotMap->GetSlotAndChannelFromPulseSysChan(PulseCntNo, slotNo, chanNo, ZERO_BASED);
		boardType = pBrdInfo->WhatBoardType(slotNo);
		if ((boardType == BOARD_DIO) && (CHANNEL_DIG_PULSE == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
			tableEntriesFound = true;
		}
	}
	// Only add table if there are items to add to the table
	if (true == tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Lo Resolution Pulse");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Count");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (PulseCntNo = 0; PulseCntNo < MAX_LORES_PULSE; PulseCntNo++) {
			// Only process if pulse counter is available
			pSlotMap->GetSlotAndChannelFromPulseSysChan(PulseCntNo, slotNo, chanNo, ZERO_BASED);
			boardType = pBrdInfo->WhatBoardType(slotNo);
			if ((boardType == BOARD_DIO) && (CHANNEL_DIG_PULSE == pSlotMap->GetChannelSelectedType(slotNo, chanNo))) {
				pDigChanCfg = pkIOCfg->GetDigital(slotNo, chanNo, CONFIG_COMMITTED);
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
//				kNewRTFFile.rtf_start_paragraph( DecodeDataItemTag(DI_COUNTER, DI_COUNTTYPE_LCOUNT, PulseCntNo), false );
				kNewRTFFile.rtf_start_paragraph(QString::fromWCharArray(pDigChanCfg->Label), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text	
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_COUNTER, DI_COUNTTYPE_LCOUNT, PulseCntNo),
						false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no enabled pulse channels for Lo Resolution pulse channels.");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the event counter report table
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateTopPulseCounterTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
		const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	class CSlotMap *pSlotMap = CSlotMap::GetHandle();
	class CBrdInfo *pBrdInfo = CBrdInfo::GetHandle();
	USHORT PulseCntNo = 0;
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	UCHAR boardType;
	QString strHeaderItem("");
	QString strHeaderInfo("");
	T_PPULSECHANNEL ptPulseData = NULL;
	bool tableEntriesFound = false;
	kNewRTFFile.rtf_start_section();
	// add the table title
	strHeaderItem = tr("Hi Resolution Pulse Counter Information");
	kNewRTFFile.AddTitle(strHeaderItem);
	for (PulseCntNo = 0; PulseCntNo < MAX_HIRES_PULSE; PulseCntNo++) {
		// Only process if pulse counter is available
		pSlotMap->GetSlotAndChannelFromDedicatedPulseSysChan(PulseCntNo, slotNo, chanNo, ZERO_BASED);
		ptPulseData = pIOSetupConfig->GetPulseInput(slotNo, chanNo, CONFIG_COMMITTED);
		boardType = pBrdInfo->WhatBoardType(slotNo);
		if ((boardType == BOARD_PI) && (ptPulseData->Enabled)) {
			tableEntriesFound = true;
		}
	}
	// Only add table if there are items to add to the table
	if (true == tableEntriesFound) {
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Hi Resolution Pulse");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Count");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (PulseCntNo = 0; PulseCntNo < MAX_HIRES_PULSE; PulseCntNo++) {
			// Only process if pulse counter is available
			pSlotMap->GetSlotAndChannelFromDedicatedPulseSysChan(PulseCntNo, slotNo, chanNo, ZERO_BASED);
			ptPulseData = pIOSetupConfig->GetPulseInput(slotNo, chanNo, CONFIG_COMMITTED);
			boardType = pBrdInfo->WhatBoardType(slotNo);
			if ((boardType == BOARD_PI) && (ptPulseData->Enabled)) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
//				kNewRTFFile.rtf_start_paragraph( DecodeDataItemTag(DI_COUNTER, DI_COUNTTYPE_HCOUNT, PulseCntNo), false );
				kNewRTFFile.rtf_start_paragraph(QString::fromWCharArray(ptPulseData->Label), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Write paragraph text	
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemValue(DI_COUNTER, DI_COUNTTYPE_HCOUNT, PulseCntNo),
						false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		strHeaderItem = tr("There are no enabled pulse channels for Hi Resolution pulse channels.");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the seperate counters table for those selected
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateCountersTables(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	QString strCounterValue("");
	USHORT itemCount = 0;
	USHORT penNo = 0;
	USHORT alarmNo = 0;
	QString strHeaderInfo("");
	T_PPEN pPenConfig = NULL;
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	if (ptReports->Report[reportNo].IncCounters & ctbALARMS) {
		CreatePenAlarmCounterTable(ptReports, kNewRTFFile, reportNo);
	}
	if (ptReports->Report[reportNo].IncCounters & ctbUSER) {
		CreateUserCounterTable(ptReports, kNewRTFFile, reportNo);
	}
	if (ptReports->Report[reportNo].IncCounters & ctbEVENT) {
		CreateEventCounterTable(ptReports, kNewRTFFile, reportNo);
	}
	if (ptReports->Report[reportNo].IncCounters & ctbDigIn) {
		CreateDigitalInputCounterTable(ptReports, kNewRTFFile, reportNo);
	}
	if (ptReports->Report[reportNo].IncCounters & ctbRelayOut) {
		CreateDigitalOutputCounterTable(ptReports, kNewRTFFile, reportNo);
	}
	if (ptReports->Report[reportNo].IncCounters & ctbPulse) {
		// Report Hires pulse channels
		CreateTopPulseCounterTable(ptReports, kNewRTFFile, reportNo);
		// Now report Lores pulse channels
		CreateBottomPulseCounterTable(ptReports, kNewRTFFile, reportNo);
	}
}
//******************************************************
//
/// Get the time span from midnight given time of day
/// @param[in] time - The event time in micro secs
/// 
/// @return The time from midnight in hours, minutes and seconds
/// 
//******************************************************
QString CReportManager::GetSecondsSpanString(const LONGLONG time) const {
	QString strTime("");
	CTVtime Span;
	CTVtime When(time);
	LONGLONG daySpanTime = 0L;
	Span = When.GetTimeOfDaySpan();
	daySpanTime = Span.GetSeconds();
	strTime = CStringUtils::GetAutoDDHHMMSSspanFromSeconds(daySpanTime);
	return strTime;
}
#define MICRO_SECS_IN_SEC	1000000
//******************************************************
//
/// Get the period information
/// @param[in] period - T_REPORT_FIELD_TIMINGS
/// @param[in] reportStartTime - Report start time in micro secs
/// @param[out] duration - The duration of the report in micro secs.
/// @param[out] when - The time string that the report period was started on.
/// @param[out] finished - The time string that the period finished.
/// @param[out] strReportTypeInfo - The string that represents the period.
/// 
/// @return Table header if date span is not possible.
/// 
//******************************************************
QString CReportManager::GetPeriodInformation(T_REPORT_FIELD_TIMINGS period, LONGLONG reportStartTime,
		LONGLONG &duration, QString &started, QString &finished, QString &finshedDate, QString &strReportTypeInfo) {
	LONGLONG alignedTimeOfStart = 0L;
	LONGLONG alignedTimeOfFinish = 0L;
	QString strHeaderItem("");
	LONGLONG timeOfFinish = 0L;
	LONGLONG durationTimeOfFinish = 0L;
	LONGLONG daySpanStart = 0L;
	LONGLONG daySpanAlignStart = 0L;
	LONGLONG daySpanAlignFinish = 0L;
	TCHAR time[50];
	UINT nDayInMonth = 0;
	UINT nRepStartTimeHH = 0;
	UINT nRepStartTimeMM = 0;
	UINT nRepStartTimeSS = 0;
	UINT nTotOfDaysInMonth = 0;
	GetReportStartInfo(reportStartTime, nTotOfDaysInMonth, nDayInMonth, nRepStartTimeHH, nRepStartTimeMM,
			nRepStartTimeSS);
	if (rftHOUR == period) {
		duration = 60 * 60;
		duration *= MICRO_SECS_IN_SEC;	// Turn seconds into micro secs
		strReportTypeInfo = tr("Hourly");
	} else if (rftDAY == period) {
		duration = 24 * 60 * 60;
		duration *= MICRO_SECS_IN_SEC;	// Turn seconds into micro secs
		alignedTimeOfStart = reportStartTime % duration;
		strReportTypeInfo = tr("Daily");
	} else if (rftWEEK == period) {
		duration = 7 * 24 * 60 * 60;
		duration *= MICRO_SECS_IN_SEC;	// Turn seconds into micro secs
		strReportTypeInfo = tr("Weekly");
	}
// CR: Customer reports unable to print the dates in his monthly averages report
	else if (rftMONTH == period) {
		if (nTotOfDaysInMonth == nDayInMonth) //This condition checks whether reported started day is equal to total no of days in month.
				{
			duration = (((24 - nRepStartTimeHH) * (60 - nRepStartTimeMM) * 60) - nRepStartTimeSS);
			duration *= MICRO_SECS_IN_SEC;	// Turn seconds into micro secs
			strReportTypeInfo = tr("Monthly");
		} else if (nDayInMonth > 1) //This condition checks whether reported started day is not equal to Total no of days in month.
				{
			duration = ((nTotOfDaysInMonth - nDayInMonth) * 24 * 60 * 60);
			ULONG secondsleft = ((23 - nRepStartTimeHH) * 60 * 60) + ((59 - nRepStartTimeMM) * 60)
					+ (60 - nRepStartTimeSS);
			duration += secondsleft;
			duration *= MICRO_SECS_IN_SEC;	// Turn seconds into micro secs
			strReportTypeInfo = tr("Monthly");
		} else //This condition check will reach when reported started day is equal to Total no of days in month.
		{
			duration = nTotOfDaysInMonth * 24 * 60 * 60;
			duration *= MICRO_SECS_IN_SEC;	// Turn seconds into micro secs
			strReportTypeInfo = tr("Monthly");
		}
	}
	else {
		strReportTypeInfo = tr("Monthly");
	}
	if (duration > 0) {
		alignedTimeOfStart = reportStartTime - (reportStartTime % duration);
		timeOfFinish = reportStartTime + (duration - MICRO_SECS_IN_SEC);
		alignedTimeOfFinish = alignedTimeOfStart + (duration - MICRO_SECS_IN_SEC);
		CTVtime Finished(timeOfFinish);
		CTVtime WhenStarted(reportStartTime);
		if (rftHOUR == period) {
			started = GetSecondsSpanString(reportStartTime);
			finished = GetSecondsSpanString(alignedTimeOfFinish);
			Finished.DateAsString(finshedDate);
		} else if (rftDAY == period) {
			started = GetSecondsSpanString(reportStartTime);
			finished = GetSecondsSpanString(alignedTimeOfFinish);
			Finished.DateAsString(finshedDate);
		} else if (rftWEEK == period) {
			WhenStarted.TimeToStringNoFracs(time);
			started = QString::asprintf("%s", time);
			Finished.TimeToStringNoFracs(time);
			finished = QString::asprintf("%s", time);
		}
//CR: Customer reports unable to print the dates in his monthly averages report
		else if (rftMONTH == period) {
			WhenStarted.TimeToStringNoFracs(time);
			started = QString::asprintf("%s", time);
			Finished.TimeToStringNoFracs(time);
			finished = QString::asprintf("%s", time);
		} else {
			WhenStarted.TimeToStringNoFracs(time);
			strHeaderItem = QString::asprintf(IDS_REPORT_MONTH_STARTING_MAX_MIN_TABLE_TITLE, time);
			Finished.TimeToStringNoFracs(time);
			finished = QString::asprintf("%s", time);
		}
	}
	return strHeaderItem;
}
//******************************************************
//
/// Create the peroidic based Average or total report table
/// @param[in] average - Table type - true if average, false = total.
/// @param[in] period - of Hour, Day, Week, Month
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateTotAveReportPeriodicTable(const bool average, T_REPORT_FIELD_TIMINGS period,
		T_PREPORTS ptReports, class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	QString strReportTypeInfo("");
	QString strHeaderItem("");
	QString strHeaderInfo("");
	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PEVENTSYSTEM ptEvents = pkEventCfg->GetEventBlock(CONFIG_COMMITTED);
	T_EVENT *ptEvent = NULL;
	bool tableEntriesFound = false;
	bool penRequired = false;
	CPenManager *pPenManager = CPenManager::GetHandle();
	float Value = 0.0;
	USHORT penNo;
	T_PPEN pPenConfig = NULL;
	LONGLONG reportStartTime = 0L;
	LONGLONG duration = 0L;
	QString when("");
	QString finished("");
	QString finishedDate("");
	kNewRTFFile.rtf_start_section();
	for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
		pPenConfig = (pSETUP->GetPenSetupConfig())->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
		if (true == average) {
			penRequired = IsReportPenRequired(penNo, reportNo, ptReports);
		} else {
			penRequired = IsTotalReportPenRequired(penNo, reportNo, ptReports);
		}
		// Only process if pen is available and selected for report
		if (true == penRequired) {
			// Get the first report strat time from the first pen on report (if one exists)
			reportStartTime = pPenManager->GetReportStartTime(penNo, ZERO_BASED, LAST_REPORT,
					static_cast<T_REPORT_PERIOD>(period - 1));
			if (reportStartTime != 0L) {
				tableEntriesFound = true;
				break;		// Found first one
			}
		}
	}
	// Only add table if there are items to add to the table that are currently valid
	if (true == tableEntriesFound) {
		// add the table title
		strHeaderItem = GetPeriodInformation(period, reportStartTime, duration, when, finished, finishedDate,
				strReportTypeInfo);
		if (strHeaderItem == "") {
			if (true == average) {
				strHeaderItem = QString::asprintf(IDS_REPORT_AVERAGE_BETWEEN_TITLE, when, finished);
			} else {
				strHeaderItem = QString::asprintf(IDS_REPORT_TOTAL_BETWEEN_TITLE, when, finished);
			}
			if (finishedDate != "")
				strHeaderItem += " " + finishedDate;
			strHeaderItem = strReportTypeInfo + " " + strHeaderItem;
		}
		kNewRTFFile.AddTitle(strHeaderItem);
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Pen");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		if (true == average) {
			strHeaderItem = tr("Average");
		} else {
			strHeaderItem = tr("Totals");
		}
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
			pPenConfig = (pSETUP->GetPenSetupConfig())->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
			// Get the first report start time from the first pen on report (if one exists)
			reportStartTime = pPenManager->GetReportStartTime(penNo, ZERO_BASED, LAST_REPORT,
					static_cast<T_REPORT_PERIOD>(period - 1));
			if (true == average) {
				Value = pPenManager->GetReportAve(penNo, ZERO_BASED, LAST_REPORT,
						static_cast<T_REPORT_PERIOD>(period - 1));
			} else {
				Value = pPenManager->GetReportTot(penNo, ZERO_BASED, LAST_REPORT,
						static_cast<T_REPORT_PERIOD>(period - 1));
			}
			if (true == average) {
				penRequired = IsReportPenRequired(penNo, reportNo, ptReports);
			} else {
				penRequired = IsTotalReportPenRequired(penNo, reportNo, ptReports);
			}
			// Only process if pen is available and selected for report
			if ((reportStartTime != 0L) && (true == penRequired)) {
				cf->SHADING.shadingBkColor = 3;
				kNewRTFFile.StartRow(iNO_OF_COLS);
				// asprintf paragraph
				pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
				//pf->CHARACTER.boldCharacter = true;
				pf->CHARACTER.boldCharacter = false;
				// Write paragraph text
				kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_PEN, DI_PEN_READING, penNo), false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// Add the units
				if (true == average) {
					strHeaderItem = QString::asprintf("%.2f %s", Value, pPenConfig->Units);
				} else {
					strHeaderItem = QString::asprintf("%.2f %s", Value, pPenConfig->Tot.Units);
				}
				kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
				// End table cell
				kNewRTFFile.rtf_end_tablecell();
				// End table row
				kNewRTFFile.rtf_end_tablerow();
			}
		}
		kNewRTFFile.EndTable();
	} else {
		if (true == average) {
			if (rftHOUR == period) {
				strHeaderItem = tr("Hourly Average Information");
			} else if (rftDAY == period) {
				strHeaderItem = tr("Daily Average Information");
			} else if (rftWEEK == period) {
				strHeaderItem = tr("Weekly Average Information");
			} else if (rftMONTH == period) {
				strHeaderItem = tr("Monthly Average Information");
			}
		} else {
			if (rftHOUR == period) {
				strHeaderItem = tr("Hourly Totals Information");
			} else if (rftDAY == period) {
				strHeaderItem = tr("Daily Totals Information");
			} else if (rftWEEK == period) {
				strHeaderItem = tr("Weekly Totals Information");
			} else if (rftMONTH == period) {
				strHeaderItem = tr("Monthly Totals Information");
			}
		}
		kNewRTFFile.AddTitle(strHeaderItem);
		if (true == average) {
			strHeaderItem = tr("No average values currently available.");
		} else {
			strHeaderItem = tr("No total values currently available.");
		}
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the peroidic based max/min report table
/// @param[in] period - of Hour, Day, Week, Month
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateMaxMinReportPeriodicTable(T_REPORT_FIELD_TIMINGS period, T_PREPORTS ptReports,
		class CRTFLib &kNewRTFFile, const USHORT reportNo) {
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	QString strReportTypeInfo("");
	QString strHeaderItem("");
	QString strHeaderInfo("");
	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PEVENTSYSTEM ptEvents = pkEventCfg->GetEventBlock(CONFIG_COMMITTED);
	T_EVENT *ptEvent = NULL;
	bool tableEntriesFound = false;
	CPenManager *pPenManager = CPenManager::GetHandle();
	float minValue = 0.0;
	float maxValue = 0.0;
	USHORT penNo;
	T_PPEN pPenConfig = NULL;
	LONGLONG maxTimeAcheived = 0L;
	LONGLONG minTimeAcheived = 0L;
	LONGLONG reportStartTime = 0L;
	LONGLONG duration = 0L;
	QString when("");
	QString finished("");
	QString finishedDate("");
	TCHAR time[50];
	kNewRTFFile.rtf_start_section();
	for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
		if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
			// Get the first report start time from the first pen on report (if one exists)
			reportStartTime = pPenManager->GetReportStartTime(penNo, ZERO_BASED, LAST_REPORT,
					static_cast<T_REPORT_PERIOD>(period - 1));
			// Only process if pen is available and selected for report
			if (reportStartTime != 0L) {
				tableEntriesFound = true;
				break;
			}
		}
	}
	// Only add table if there are items to add to the table that are currently valid
	if (true == tableEntriesFound) {
		// add the table title
		strHeaderItem = GetPeriodInformation(period, reportStartTime, duration, when, finished, finishedDate,
				strReportTypeInfo);
		if (strHeaderItem == "") {
			strHeaderItem = QString::asprintf(IDS_REPORT_MAX_MIN_BETWEEN_TITLE, when, finished);
			strHeaderItem = strReportTypeInfo + " " + strHeaderItem;
			if (finishedDate != "")
				strHeaderItem += " " + finishedDate;
		}
		kNewRTFFile.AddTitle(strHeaderItem);
		// Create new section
		kNewRTFFile.StartTable();
		strHeaderInfo = tr("Pen");
		strHeaderInfo += CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Max");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		strHeaderItem = tr("Min");
		strHeaderInfo += strHeaderItem + CStringUtils::ms_strDELIMITTER;
		kNewRTFFile.AddTableHeader(strHeaderInfo);
		const int iNO_OF_COLS = CStringUtils::InstanceOfStr(strHeaderInfo, CStringUtils::ms_strDELIMITTER);
		cf->SHADING.shadingBkColor = 2;
		pf->CHARACTER.boldCharacter = false;
		// indexOf which data item(s) to report from the setup using report ID
		for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
			if (IsReportPenRequired(penNo, reportNo, ptReports) == true) {
				// Get the first report start time from the first pen on report (if one exists)
				reportStartTime = pPenManager->GetReportStartTime(penNo, ZERO_BASED, LAST_REPORT,
						static_cast<T_REPORT_PERIOD>(period - 1));
				// Only process if pen is available and selected for report
				if (reportStartTime != 0L) {
					pPenConfig = (pSETUP->GetPenSetupConfig())->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
					maxValue = pPenManager->GetReportMax(penNo, ZERO_BASED, LAST_REPORT,
							static_cast<T_REPORT_PERIOD>(period - 1), maxTimeAcheived);
					minValue = pPenManager->GetReportMin(penNo, ZERO_BASED, LAST_REPORT,
							static_cast<T_REPORT_PERIOD>(period - 1), minTimeAcheived);
					cf->SHADING.shadingBkColor = 3;
					kNewRTFFile.StartRow(iNO_OF_COLS);
					// asprintf paragraph
					pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
					//pf->CHARACTER.boldCharacter = true;
					pf->CHARACTER.boldCharacter = false;
					// Write paragraph text
					kNewRTFFile.rtf_start_paragraph(DecodeDataItemTag(DI_PEN, DI_PEN_READING, penNo), false);
					// End table cell
					kNewRTFFile.rtf_end_tablecell();
					// Write paragraph text	
					CTVtime WhenMaxAcheived(maxTimeAcheived);
					if (rftHOUR == period) {
						strHeaderInfo = GetSecondsSpanString(maxTimeAcheived);
					} else if (rftDAY == period) {
						strHeaderInfo = GetSecondsSpanString(maxTimeAcheived);
					} else {
						WhenMaxAcheived.TimeToStringNoFracs(time);
						strHeaderInfo = QString::asprintf("%s", time);
					}
					strHeaderItem = QString::asprintf("%.2f %s @", maxValue, pPenConfig->Units);
					kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
					kNewRTFFile.rtf_start_paragraph(strHeaderInfo, true);
					// End table cell
					kNewRTFFile.rtf_end_tablecell();
					CTVtime WhenMinAcheived(minTimeAcheived);
					if (rftHOUR == period) {
						strHeaderInfo = GetSecondsSpanString(minTimeAcheived);
					} else if (rftDAY == period) {
						strHeaderInfo = GetSecondsSpanString(minTimeAcheived);
					} else {
						WhenMinAcheived.TimeToStringNoFracs(time);
						strHeaderInfo = QString::asprintf("%s", time);
					}
					strHeaderItem = QString::asprintf("%.2f %s @", minValue, pPenConfig->Units);
					kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
					kNewRTFFile.rtf_start_paragraph(strHeaderInfo, true);
					// End table cell
					kNewRTFFile.rtf_end_tablecell();
					// End table row
					kNewRTFFile.rtf_end_tablerow();
				}
			}
		}
		kNewRTFFile.EndTable();
	} else {
		if (rftHOUR == period) {
			strHeaderItem = tr("Hourly Max/Mins Information");
		} else if (rftDAY == period) {
			strHeaderItem = tr("Daily Max/Mins Information");
		} else if (rftWEEK == period) {
			strHeaderItem = tr("Weekly Max/Mins Information");
		} else if (rftMONTH == period) {
			strHeaderItem = tr("Monthly Max/Mins Information");
		} else {
			strHeaderItem = tr("System Max/Mins Information");
		}
		kNewRTFFile.AddTitle(strHeaderItem);
		strHeaderItem = tr("No Max/Min values currently available.");
		kNewRTFFile.rtf_start_paragraph(strHeaderItem, false);
	}
	// add some blank lines
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Create the totals, max min & average based reports table for those selected
/// @param[in] ptReports - Reports configuration information.
/// @param[in] kNewRTFFile - The report file handler to update.
/// @param[in] reportNo - Report number that report belongs to.
/// 
//******************************************************
void CReportManager::CreateReportPeriodicTable(T_PREPORTS ptReports, class CRTFLib &kNewRTFFile,
		const USHORT reportNo) {
	// Check for the user defined max mins table required
	if ((rftCURRENT == ptReports->Report[reportNo].IncMaxMins)
			|| ((rssBATCH == ptReports->Report[reportNo].ReportStyle) && (ptReports->Report[reportNo].IncMaxMins))) {
		CreateMaxMinTable(ptReports, kNewRTFFile, reportNo);
	}
	// Check for perodic max mins required
	if ((rssBATCH != ptReports->Report[reportNo].ReportStyle)
			&& ((rftHOUR == ptReports->Report[reportNo].IncMaxMins)
					|| (rftDAY == ptReports->Report[reportNo].IncMaxMins)
					|| (rftWEEK == ptReports->Report[reportNo].IncMaxMins)
					|| (rftMONTH == ptReports->Report[reportNo].IncMaxMins))) {
		CreateMaxMinReportPeriodicTable(static_cast<T_REPORT_FIELD_TIMINGS>(ptReports->Report[reportNo].IncMaxMins),
				ptReports, kNewRTFFile, reportNo);
	}
	// Check for the user defined totals table required
	if ((rftCURRENT == ptReports->Report[reportNo].IncTotals)
			|| ((rssBATCH == ptReports->Report[reportNo].ReportStyle) && (ptReports->Report[reportNo].IncMaxMins))) {
		CreateTotalsTable(ptReports, kNewRTFFile, reportNo);
	}
	// Check for perodic totals required
	if ((rssBATCH != ptReports->Report[reportNo].ReportStyle)
			&& ((rftHOUR == ptReports->Report[reportNo].IncTotals) || (rftDAY == ptReports->Report[reportNo].IncTotals)
					|| (rftWEEK == ptReports->Report[reportNo].IncTotals)
					|| (rftMONTH == ptReports->Report[reportNo].IncTotals))) {
		CreateTotAveReportPeriodicTable(false,
				static_cast<T_REPORT_FIELD_TIMINGS>(ptReports->Report[reportNo].IncTotals), ptReports, kNewRTFFile,
				reportNo);
	}
	// Check for perodic averages required
	if ((rssBATCH != ptReports->Report[reportNo].ReportStyle)
			&& ((rftHOUR == ptReports->Report[reportNo].IncAverages)
					|| (rftDAY == ptReports->Report[reportNo].IncAverages)
					|| (rftWEEK == ptReports->Report[reportNo].IncAverages)
					|| (rftMONTH == ptReports->Report[reportNo].IncAverages))) {
		CreateTotAveReportPeriodicTable(true,
				static_cast<T_REPORT_FIELD_TIMINGS>(ptReports->Report[reportNo].IncAverages), ptReports, kNewRTFFile,
				reportNo);
	}
}
//******************************************************
//
/// Check whether batch mode is enabled for a given report
/// @param[in] reportNo - The report number to be checked (zero based).
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsBatchEnabled(const USHORT reportNo, T_PREPORTS ptReports) {
	return ((rssBATCH == ptReports->Report[reportNo].ReportStyle) &&
	pSYSTEM_INFO->FWOptionBatchAvailable());
}
//******************************************************
//
/// Check whether pen is enabled
/// @param[in] penNo - The pen number to be checked (zero based).
/// 
//******************************************************
const bool CReportManager::IsReportPenEnabled(const USHORT penNo) {
	CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
	T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
	bool bPEN_ENABLED = ( pSYSTEM_INFO->IsPenAvailable(penNo, ZERO_BASED)) && (ptPen->Enabled == TRUE);
	return bPEN_ENABLED;
}
//******************************************************
//
/// Check whether all pens are enabled for report
/// @param[in] reportNo - Report number that report belongs to.
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsReportAllPensSelected(const USHORT reportNo, T_PREPORTS ptReports) {
	bool bAllPensSelected = ((epsALL_PENS == ptReports->Report[reportNo].PenSelType)
			&& (rssNORMAL == ptReports->Report[reportNo].ReportStyle));
	return bAllPensSelected;
}
//******************************************************
//
/// Check whether an individual report pen is selected
/// @note for all pens except totals
/// @param[in] penNo - The pen number to be checked (zero based).
/// @param[in] reportNo - Report number that report belongs to.
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsIndividualReportPenSelected(const USHORT penNo, const USHORT reportNo,
		T_PREPORTS ptReports) {
	bool bIndividualPenChosen = ((epsINDIVIDUAL_SELS == ptReports->Report[reportNo].PenSelType)
			&& (rssNORMAL == ptReports->Report[reportNo].ReportStyle)
			&& (GetBits(ptReports->Report[reportNo].Pens[penNo / 32], penNo % 32, 1) != 0));
	return bIndividualPenChosen;
}
//******************************************************
//
/// Check whether an individual report pen is part of a group
/// @param[in] penNo - The pen number to be checked (zero based).
/// @param[in] reportNo - Report number that report belongs to.
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsIndividualReportPenInGroup(const USHORT penNo, const USHORT reportNo,
		T_PREPORTS ptReports) {
	CPenManager *pPenManager = CPenManager::GetHandle();
	bool bIndividualPenInGroup = ((epsPEN_GROUP == ptReports->Report[reportNo].PenSelType)
			|| ((rssBATCH == ptReports->Report[reportNo].ReportStyle) && pSYSTEM_INFO->FWOptionBatchAvailable()))
			&& pPenManager->IsPenInGroup(static_cast<T_PEN_GROUPS>(ptReports->Report[reportNo].Group + 1), penNo);
	return bIndividualPenInGroup;
}
//******************************************************
//
/// Check whether an individual total report pen is selected
/// @param[in] penNo - The pen number to be checked (zero based).
/// @param[in] reportNo - Report number that report belongs to.
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsIndividualTotalReportPenSelected(const USHORT penNo, const USHORT reportNo,
		T_PREPORTS ptReports) {
	bool bIndividualTotalPenChosen = ((epsINDIVIDUAL_SELS == ptReports->Report[reportNo].PenSelType)
			&& (rssNORMAL == ptReports->Report[reportNo].ReportStyle)
			&& (GetBits(ptReports->Report[reportNo].PenTotals[penNo / 32], penNo % 32, 1) != 0));
	return bIndividualTotalPenChosen;
}
//******************************************************
//
/// Check whether an individual total report pen is enabled and selected
/// @param[in] penNo - The pen number to be checked (zero based).
/// @param[in] reportNo - Report number that report belongs to.
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsTotalReportPenRequired(const USHORT penNo, const USHORT reportNo, T_PREPORTS ptReports) {
	CPenSetupConfig *pkPenConfig = pSETUP->GetPenSetupConfig();
	T_PPEN ptPen = pkPenConfig->GetPen(penNo, ZERO_BASED, CONFIG_COMMITTED);
	return ( /* Is pen and pen totals enabled and any one of the following */
	IsReportPenEnabled(penNo) && (ptPen->Tot.Enabled == TRUE) && ( /* Individual/multiple total pen number(s) selected for report */
	IsIndividualTotalReportPenSelected(penNo, reportNo, ptReports) ||
	/* or All pens selected on report */
	IsReportAllPensSelected(reportNo, ptReports) ||
	/* or Group/Batch selected and Pen is part of selected report group */
	IsIndividualReportPenInGroup(penNo, reportNo, ptReports)));
}
//******************************************************
//
/// Check whether an individual report pen is enabled and selected
/// @note for all pens except totals
/// @param[in] penNo - The pen number to be checked (zero based).
/// @param[in] reportNo - Report number that report belongs to.
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsReportPenRequired(const USHORT penNo, const USHORT reportNo, T_PREPORTS ptReports) {
	return ( /* Is pen enabled and any of the following */
	IsReportPenEnabled(penNo) && ( /* Individual/multiple pen number(s) selected for report */
	IsIndividualReportPenSelected(penNo, reportNo, ptReports) ||
	/* or All pens selected on report */
	IsReportAllPensSelected(reportNo, ptReports) ||
	/* or Group/Batch selected and Pen is part of selected report group */
	IsIndividualReportPenInGroup(penNo, reportNo, ptReports)));
}
//******************************************************
//
/// Check whether an individual total report pen is enabled and selected
/// @param[in] penNo - The pen number to be checked (zero based).
/// @param[in] reportNo - Report number that report belongs to.
/// @param[in] ptReports - The report configuartion.
/// 
//******************************************************
const bool CReportManager::IsReportByGroup(const USHORT reportNo, T_PREPORTS ptReports) {
	return ((rssBATCH == ptReports->Report[reportNo].ReportStyle)
			|| ((rssNORMAL == ptReports->Report[reportNo].ReportStyle)
					&& (epsPEN_GROUP == ptReports->Report[reportNo].PenSelType)));
}
//******************************************************
//
/// Generate the report.
/// @param[in] reportID - Report number that report belongs to.
///
/// @return TRUE if report successful; otherwise FALSE.
/// 
//******************************************************
BOOL CReportManager::GenerateReport(const USHORT reportNo, QString &rstrReportNamePath, QString &rstrErrorMsg,
		HANDLE hCallingThreadHandle /* = NULL */) {
	m_kCritSect.lock();
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ReportGen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// drop the thread priorty if possible so it doesn't hang other processes
	int iOldThreadPriority = 0;
	if (hCallingThreadHandle != NULL) {
		iOldThreadPriority = GetThreadPriority(hCallingThreadHandle);
		SetThreadPriority(hCallingThreadHandle, THREAD_PRIORITY_BELOW_NORMAL);
	}
	// Tidy up the report directory first
	TidyReportDirectory();
	//When parameter hCallingThreadHandle != NULL
	//the report is generated on the main thread.
	//Hence we update the thread counter of OPPanel
	if (pThreadInfo != NULL) {
		if (hCallingThreadHandle != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		} else {
			//Update the Thread Counter for the ReportG enThread
			//We do this at regular intervals so that we can
			//track any hang issues in report generation
			pThreadInfo->UpdateThreadInfo(AM_REPORT_GEN, true);
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
	}
	qDebug("Beginning report generation\n");
	// indicate a report is in the process of being generated
	++m_usReportsInProgressRefCount;
	BOOL retValue = TRUE;
	QString MainFile("");
	QString FileAndDate("");
//	USHORT penTableCols = 0;
	USHORT fileMode = QFile::ReadWrite;
	USHORT penNo = 0;
	LONGLONG timeCreated = 0L;
	CPenManager *pPenManager = CPenManager::GetHandle();
	CEventSetupConfig *pEventCfg = pGlbSetup->GetEventSetupConfig();
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	// Load report configuration, using report ID
	T_PREPORTS ptReports = pEventCfg->GetReportsBlock(CONFIG_COMMITTED);
	T_PGENERALCONFIG ptGenBlk = pkGenCfg->GetSystemGeneralBlock(CONFIG_COMMITTED);
	// Use report tag for report name
	MainFile = QString::fromWCharArray(ptReports->Report[reportNo].Tag);
	// Create the correct report type holder & add file extenstion (only rtf supported currently)
	MainFile += ".rtf";
	// Add the directory and current date and time to report filename to save to internal CF
	timeCreated = AppendTimeDateToReportName(MainFile, FileAndDate);
	AppendInternalReportDirectory(FileAndDate, rstrReportNamePath);
	// get the paper size to use
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	bool bUseLetterPaperSize = false;
	if (ptGeneralData != NULL) {
		bUseLetterPaperSize = (ptGeneralData->Printer.Letter == TRUE);
	}
	CRTFLib kNewRTFFile(bUseLetterPaperSize);
	const QString strFONTS("Times New Roman;Arial;");
	const QString strCOLOURS("0;0;0;255;0;0;192;192;192;255;255;255;");
	// Open RTF file
	kNewRTFFile.rtf_open(rstrReportNamePath, strFONTS, strCOLOURS);
	//kNewRTFFile.rtf_write_header();
	// Add apprioriate header
	AddHeader(kNewRTFFile, reportNo, timeCreated);
	// now add the footer information
	AddFooter(kNewRTFFile, static_cast<T_FOOTER_STYLE_ENUM>(ptReports->Report[reportNo].ReportFooter));
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the ReportGenThread
		//We do this at regular intervals so that we can
		//track any hang issues in report generation
		pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		//When parameter hCallingThreadHandle != NULL
		//the report is generated on the main thread.
		//Hence we update the thread counter of OPPanel
		if (hCallingThreadHandle != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		} else {
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
	}
	// check if this is a TUS report
	if (ptReports->Report[reportNo].ReportStyle == rssTUS) {
		// this is a TUS report therefore populate with the TUS information
		CreateTUSReport(kNewRTFFile);
	} else {
		// check if batch information is required
		if ((rssBATCH == ptReports->Report[reportNo].ReportStyle) && pSYSTEM_INFO->FWOptionBatchAvailable()) {
			BatchInfoReport(ptReports, kNewRTFFile, reportNo);
		}
		// Add current pen values if required
		if (ptReports->Report[reportNo].IncCurrPenVal)
			CreatePenValueTable(ptReports, kNewRTFFile, reportNo);
		// Add digital input states as required 
		if (ptReports->Report[reportNo].IncDigInputs != 0)
			CreateDigitalValueTable(true, ptReports, kNewRTFFile, reportNo);
		// Add digital output states as required 
		if (ptReports->Report[reportNo].IncDigOutputs != 0)
			CreateDigitalValueTable(false, ptReports, kNewRTFFile, reportNo);
		// Add hourly, daily, weekly & monthly max, mins, totals & average
		CreateReportPeriodicTable(ptReports, kNewRTFFile, reportNo);
		// Add counters to report
		if (ptReports->Report[reportNo].IncCounters != 0) {
			CreateCountersTables(ptReports, kNewRTFFile, reportNo);
		}
		// Add messages to report
		if ((IsBatchEnabled(reportNo, ptReports) && (ptReports->Report[reportNo].IncMsgListTypes != 0))
				|| ((rftNONE != ptReports->Report[reportNo].IncMessages)
						&& (ptReports->Report[reportNo].IncMsgListTypes != 0))) {
			MessageInfoReport(ptReports, kNewRTFFile, reportNo);
		}
	}
	// Close RTF file
	kNewRTFFile.rtf_close();
	qDebug("Generated report\n");
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the ReportGenThread
		//We do this at reguler intervals so that we can
		//track any hang issues in report generation
		pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		//When parameter hCallingThreadHandle != NULL
		//the report is generated on the main thread.
		//Hence we update the thread counter of OPPanel
		if (hCallingThreadHandle != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		} else {
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
	}
	// check if the report must be emailed
	if ((ptReports->Report[reportNo].Email) && ( pSYSTEM_INFO->FWOptionEmailAvailable() == TRUE)) {
		qDebug("Begining emailing of report\n");
		EmailReport(rstrReportNamePath, reportNo);
		qDebug("Report emailed\n");
	} else if ((ptReports->Report[reportNo].Email) && ( pSYSTEM_INFO->FWOptionEmailAvailable() == FALSE)) {
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Reports Error - email FW option is not enabled");
	}
	//When parameter hCallingThreadHandle != NULL
	//the report is generated on the main thread.
	//Hence we update the thread counter of OPPanel	
	if (pThreadInfo != NULL) {
		if (hCallingThreadHandle != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		} else {
			//Update the Thread Counter for the ReportGenThread
			//We do this at reguler intervals so that we can
			//track any hang issues in report generation
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
	}
	// check if the report must be export
	if (ptReports->Report[reportNo].ExportDev != LOGDEV_MAX_DEVICES) {
		// E527303
		// Check For Export Device Type - If it is NAS then check for the SharedFolder
		// If Shared Folder exist then call ExportReport() otherwise display error message.
		if (static_cast<T_LOG_DEVICE>(ptReports->Report[reportNo].ExportDev) == LOGDEV_SHARE) {
			CMediaManager *pkMediaManager = CMediaManager::GetHandle();
			if (pkMediaManager->CheckSharedFolder() == 0) {
				qDebug("Begining exporting of report\n");
				ExportReport(rstrReportNamePath, static_cast<T_LOG_DEVICE>(ptReports->Report[reportNo].ExportDev));
				qDebug("Report exported\n");
			} else {
				QString strError("");
				strError = tr("Please check the Folder is shared and network admin settings are correct.");
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			}
		} else {
			qDebug("Begining exporting of report\n");
			ExportReport(rstrReportNamePath, static_cast<T_LOG_DEVICE>(ptReports->Report[reportNo].ExportDev));
			qDebug("Report exported\n");
		}
	}
	//When parameter hCallingThreadHandle != NULL
	//the report is generated on the main thread.
	//Hence we update the thread counter of OPPanel	
	if (pThreadInfo != NULL) {
		if (hCallingThreadHandle != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		} else {
			//Update the Thread Counter for the ReportGenThread
			//We do this at reguler intervals so that we can
			//track any hang issues in report generation
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
		}
	}
	// check if the report must be printed
	if ((ptReports->Report[reportNo].Print == TRUE)
			&& ( pSETUP->GetGeneralSetupConfig()->PrintingIsAllowed() == TRUE)) {
		//m_kPrintCritSect.lock();
		qDebug("Begining printing of report\n");
		CReportDoc kReportDoc;
		kReportDoc.OnOpenDocument(rstrReportNamePath.toLocal8Bit().data());
		// create the print object that will read the list control
		CReportPrint kReportPrint(kReportDoc);
		// pass the document onto the print manager for actual printing
		CPrintManager *pkPrintMgr = CPrintManager::GetHandle();
		// if the calling thread is not null then this has come from the UI thread in which
		// case it is okay to show error messages
		if (hCallingThreadHandle != NULL) {
			// from the UI therefore show error messages
			pkPrintMgr->PrintDoc(&kReportPrint, kReportDoc.GetHeader(), true);
		} else {
			// not from the UI therefore do not show error messages
			pkPrintMgr->PrintDoc(&kReportPrint, kReportDoc.GetHeader(), false);
		}
		qDebug("Report printed\n");
		//m_kPrintCritSect.unlock();
	} else if ((ptReports->Report[reportNo].Print == TRUE) && !pSETUP->GetGeneralSetupConfig()->PrintingIsAllowed()) {
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Reports Error - printing is not allowed/enabled");
	}
	// finished the report so indicate it is no longer in progress
	--m_usReportsInProgressRefCount;
	if (pThreadInfo != NULL) {
		if (hCallingThreadHandle != NULL) {
			// restore the previous thread priority
			SetThreadPriority(hCallingThreadHandle, iOldThreadPriority);
		}
		//When parameter hCallingThreadHandle != NULL
		//the report is generated on the main thread.
		//Hence we update the thread counter of OPPanel
		if (hCallingThreadHandle != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_OPPANEL);
		} else {
			//Update the Thread Counter for the ReportGenThread
			//We do this at reguler intervals so that we can
			//track any hang issues in report generation
			pThreadInfo->UpdateThreadCounter(AM_REPORT_GEN);
			//Report generation thread is exiting
			pThreadInfo->UpdateThreadInfo(AM_REPORT_GEN, false);
		}
	}
	m_kCritSect.unlock();
	return retValue;
}
//**********************************************************************
//	void EmailReport( const QString &rstrREPORT_NAME, const USHORT usREPORT_NO ) const
///
///	Method that triggers the sending of the specified report within an email
///
/// @param[in]		const QString rstrREPORT_NAME - The report name/path that needs to be emailed
///	@param[in]		const USHORT usREPORT_NO - The report number - need so we can get the recipients list
///
//**********************************************************************
void CReportManager::EmailReport(const QString &rsrREPORT_NAME, const USHORT usREPORT_NO) const {
	// Load report configuration, using report ID
	CEventSetupConfig *pEventCfg = pGlbSetup->GetEventSetupConfig();
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_PREPORTS ptReports = pEventCfg->GetReportsBlock(CONFIG_COMMITTED);
	T_PREPORTDATA ptRepData = &ptReports->Report[usREPORT_NO];
	// now send the email necessary
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	CGeneralSetupConfig *pkGenConfig = pGlbSetup->GetGeneralSetupConfig();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	QString strRecipients("");
	// check the FW options allow emails
	if ( pSYSTEM_INFO->FWOptionEmailAvailable() && (pkCommsConfig != NULL) && (pkGenConfig != NULL)) {
		strRecipients = pkCommsConfig->GetEmailAddresses(ptRepData->EmailRecipients);
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
		if ((ptCommsData != NULL) && (strRecipients != "")) {
			T_EMAIL *ptEmail = &ptCommsData->Email;
			QString strUsername("");
			QString strPassword("");
			if (ptEmail->ServerReqAuth != FALSE) {
				strUsername = QString::asprintf("%s", ptEmail->Username);
				CCrypto kCrypto;
				strPassword = kCrypto.Decrypt(ptEmail->Password, EMAIL_PASSWORD_LEN);
			}
			// create the subject
			QString strSubject("");
			QString strMessage("");
			T_PGENERALCONFIG ptGeneral = pkGenConfig->GetSystemGeneralBlock(CONFIG_COMMITTED);
			if (ptGeneral != NULL) {
				strSubject = QString::asprintf(IDS_REPORT_MGR_EMAIL_TITLE, ptGeneral->Name);
			}
			strMessage = QString::asprintf(IDS_REPORT_MGR_EMAIL_MESSAGE, ptGeneral->Name);
#ifndef V6IOTEST
			const CEmailData kMAIL_DATA(strRecipients, ptEmail->UserAddress, ptEmail->UserAddress, strSubject,
					strMessage, ptEmail->ServerName, ptEmail->SecurityMode, ptEmail->STARTTLSSupport, ptEmail->Port,
					strUsername, strPassword, false, rsrREPORT_NAME);
			CSMTPThread::AddEmailToPending(kMAIL_DATA);
#endif
		}
	}
}
//**********************************************************************
///
/// Method that triggers the exporting of the specified report to an external device
///
/// @param[in]		const QString rstrREPORT_NAME - The report name/path that needs to be exported
///	@param[in]		const T_LOG_DEVICE eEXPORT_DEV - The device to attempt to export the report to
///
//**********************************************************************
void CReportManager::ExportReport(const QString &rsrREPORT_NAME, const T_LOG_DEVICE eEXPORT_DEV) const {
	QString strFileName(rsrREPORT_NAME);
	int iCurrPos = strFileName.size();
	if (iCurrPos > 1) {
		while ((strFileName.at(--iCurrPos) != L'\\') && (iCurrPos != 0));
		// the pointer must be looked at the backslashes therefore extract the filename from here
		strFileName.remove(0, iCurrPos + 1);
	}
	// attempt to copy the file
	QString wcaExportPath;
	CLogDeviceStatus *pkLogDevStat = CLogDeviceStatus::GetHandle();
	const T_STORAGE_DEVICE eSTORAGE_DEV = pkLogDevStat->LogDeviceToStorageDevice(eEXPORT_DEV);
	pGlbDal->BuildPath(eSTORAGE_DEV, IDS_ROOT, &strFileName, &wcaExportPath, MAX_PATH);
	// check the path is valid
	if (wcaExportPath[0] != L'\0') {
		// copy the file from internal CF to an external device
		CRecorderStorage kExport;
		if (!kExport.CopyFiles(rsrREPORT_NAME, wcaExportPath, FALSE, FALSE)) {
			// the copy failed therefore report an error
			QString strError("");
			QString strDeviceList("");
			//QString strDeviceList( CRecSetupCfgMgr::CreateExportDevList( CONFIG_MODIFIABLE ) );
			QString strDevice("");
			if (eEXPORT_DEV != LOGDEV_SHARE) {
				//strDeviceList.LoadString( IDS_CFG_SCHEDULE_DEVICE_LIST );
				strDeviceList = tr("Front SD|USB1|USB2|");
				strDevice = CStringUtils::GetItemAtPos(strDeviceList, eEXPORT_DEV);
			} else {
				//strDevice = wcaExportPath;
				strDevice = tr("NAS");
			}
			strError = QString::asprintf(IDS_REPORT_VIEW_DLG_FAILED_TO_EXPORT_MESSAGE, strFileName.toLocal8Bit().data(),
					strDevice.toLocal8Bit().data()/*CStringUtils::GetItemAtPos( strDeviceList, eEXPORT_DEV )*/);
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strError);
		}
	}
}
//****************************************************************************
/// Get text representation of the current data item value or
/// state if the data item has an error status
///
/// @param[in] - type, Type of data item
/// @param[in] - ref, Reference of Data Item
/// @param[in] - instance, Instance of Data Item 
///
/// @return - The data item converted to a string, or error status text
///
//****************************************************************************
QString CReportManager::DecodeDataItemValue(T_DATA_ITEM_TYPE type, USHORT ref, USHORT instance) {
	CPenSetupConfig *pkPenCfg = pSETUP->GetPenSetupConfig();
	class CDataItem *pDataItem = NULL;
	T_DATAITEM_STATUS itemStatus;
	T_PPEN pPen = NULL;
	float value = 0.0F;
	bool displayUnits = false;
	QString dataItemText("");
	QString annotateText("");
	pDataItem = pDIT->GetDataItemPtr(type, ref, instance);
	itemStatus = pDataItem->GetStatus();
	if (itemStatus >= DISTAT_NORMAL) {
		if ((DI_IO == type) && (ref == DI_IO_DIGITAL)) {
			USHORT slotNo = 0;
			USHORT chanNo = 0;
			class CSlotMap *pSlotMap = CSlotMap::GetHandle();
			CIOSetupConfig *pkIOCfg = pSETUP->GetIOSetupConfig();
			pSlotMap->GetSlotAndChannelFromDigitalSysChan(instance, slotNo, chanNo, ZERO_BASED);
			T_PDIGCHANNEL pDigChanCfg = pkIOCfg->GetDigital(slotNo, chanNo, CONFIG_COMMITTED);
			if (pDataItem->GetFPValue() == 0.0) {
				dataItemText = QString::asprintf("%s", pDigChanCfg->InActive);
			} else {
				dataItemText = QString::asprintf("%s", pDigChanCfg->Active);
			}
		} else if (DI_COUNTER == type) {
			// No decimal points for counters; unless user
			value = pDataItem->GetFPValue();
			if ((DI_COUNTTYPE_USER == ref) || (value > 100000)) {
				// Number is too big or could be incremented in non whole steps
				m_tCounterasprintf.Auto = TRUE;
			} else {
				m_tCounterasprintf.Auto = FALSE;
			}
			dataItemText = CStringUtils::FormatFloat(m_tCounterasprintf, value);
		} else {
			dataItemText = CStringUtils::FormatFloat(ms_tNumasprintf, pDataItem->GetFPValue());
			displayUnits = true;
		}
		if (true == displayUnits) {
			// Add the pen units		
			if (type == DI_TOTAL) {
				pPen = pkPenCfg->GetPen(instance, ZERO_BASED, CONFIG_COMMITTED);
				annotateText = QString::asprintf(" %s", pPen->Tot.Units);
			} else {
				annotateText = QString::asprintf(" %s", pDataItem->GetUnits());
			}
			dataItemText += annotateText;
		}
	} else {
		if (itemStatus == DISTAT_INVALID)
			dataItemText = tr("Invalid");
		else if (itemStatus == DISTAT_INPUT_UNDERRANGE)
			dataItemText = tr("Underrange");
		else if (itemStatus == DISTAT_INPUT_OVERRANGE)
			dataItemText = tr("Overrange");
		else if (itemStatus == DISTAT_INPUT_UPSCALE_BURNOUT)
			dataItemText = tr("Upscale burnout");
		else if (itemStatus == DISTAT_INPUT_DOWNSCALE_BURNOUT)
			dataItemText = tr("Downscale burnout");
	}
	return dataItemText;
}
//****************************************************************************
/// Get the current data item tag
///
/// @param[in] - type, Type of data item
/// @param[in] - ref, Reference of Data Item
/// @param[in] - instance, Instance of Data Item 
///
/// @return - The data item converted to a string, or error status text
///
//****************************************************************************
QString CReportManager::DecodeDataItemTag(T_DATA_ITEM_TYPE type, USHORT ref, USHORT instance) {
	class CDataItem *pDataItem = NULL;
	QString dataItemText("");
	// Get the pen's data item tag		
	pDataItem = pDIT->GetDataItemPtr(type, ref, instance);
	dataItemText = QString::asprintf("%s", pDataItem->GetTag());
	// Check if tag field is empty; if it is then add default tag
	return dataItemText;
}
//******************************************************
//
/// Loads the report common configuration from the CMM, inc. stop events,
/// owner report number, header and footer info.
/// @param[in] ptReports - The report config.
/// @param[in] reportNo - The report number to load.
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
USHORT CReportManager::GetMainReportTableColumnCount(T_PREPORTS ptReports, const USHORT reportNo) {
	USHORT colCount = 0;
	if (ptReports->Report[reportNo].Enabled == TRUE) {
		// indexOf which data item(s) to report and therefore number of columns required for table
		// Check for instant pen value required
		if (ptReports->Report[reportNo].IncCurrPenVal == TRUE) {
			colCount++;
		}
		// Check for pen max mins required
		if (ptReports->Report[reportNo].IncMaxMins != rftNONE) {
			colCount++;
		}
		// Check for pen totals required
		if (ptReports->Report[reportNo].IncTotals != rftNONE) {
			colCount++;
		}
		// Add the pen tag column, only if there is some pen data to report
		if (colCount > 0) {
			colCount++;
		}
	}
	// Load report template
	return colCount;
}
//******************************************************
//
/// Append the report filename with the current date and time.
/// @param[in] FileName - Report filename and entension.
/// @param[out] FileNameAndDate - The filename appended with the date and time.
///
/// @return The creation time in micro secs
/// 
//******************************************************
qint64 CReportManager::AppendTimeDateToReportName(const QString FileName, QString &FileNameAndDate) {
	qint64 dtCreationDateTime;
	// PAR RTVIEW-649 Batch Header mismatch issue -Vedant
	dtCreationDateTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
	CTVtime createTime(dtCreationDateTime);
	AnnotateTimeDateToReportName(FileName, createTime, FileNameAndDate);
	return dtCreationDateTime;
}
//******************************************************
//
/// Append the report filename with an old date and time.
/// @param[in] FileName - Report filename and extension.
/// @param[in] TimeAndDate - Report creation time and date.
/// @param[out] FileNameAndDate - The filename appended with the date and time.
///
/// @return Nothing
/// 
//******************************************************
void CReportManager::AppendOldTimeDateToReportName(const QString FileName, const qint64 creationTime,
		QString &FileNameAndDate) {
	CTVtime createTime(creationTime);
	AnnotateTimeDateToReportName(FileName, createTime, FileNameAndDate);
}
//******************************************************
//
/// Append the report filename with an old date and time.
/// @param[in] createTime - Report filename and extension.
/// @param[in] createTime - Report creation time.
/// @param[out] FileNameAndDate - The filename appended with the date and time.
///
/// @return Nothing
/// 
//******************************************************
void CReportManager::AnnotateTimeDateToReportName(const QString FileName, const CTVtime createTime,
		QString &FileNameAndDate) {
	int delimiterPos = 0;
	QString creationAt("");
	TCHAR dateAnnotate[30];
	// Get the time & date as QString 
	createTime.TimeToStringNoFracs(dateAnnotate);
	creationAt = dateAnnotate;
	// Remove the day, if required
	// Replace the spaces and colons
	creationAt.replace(" ", "-");
	creationAt.replace(":", "-");
	// Add leading underscore to date & time
	creationAt.insert(0, '_');
	FileNameAndDate = FileName;
	delimiterPos = FileNameAndDate.indexOf('.');
	if (delimiterPos != -1) {
		FileNameAndDate.insert(delimiterPos, creationAt);
	} else {
		// No file type, so add at end
		FileNameAndDate += creationAt;
	}
}
//******************************************************
//
/// Append the report filename with the report directory.
/// @param[in] FileName - Main report filename.
/// @param[out] PathAndFileName - The filename appended with the report ID & location.
///
/// @return Nothing
/// 
//******************************************************
void CReportManager::AppendExternalReportDirectory(const QString FileName, QString &PathAndFileName) {
	QString wcPathAndFileName = "";
	pDALGLB->BuildPath(IDS_EXTERNAL_SD, IDS_REPORTS, &FileName, &wcPathAndFileName, MAX_PATH);
	PathAndFileName = wcPathAndFileName;
}
//******************************************************
//
/// Append the report filename with the report directory.
/// @param[in] FileName - Main report filename.
/// @param[out] PathAndFileName - The filename appended with the report ID & location.
///
/// @return Nothing
/// 
//******************************************************
void CReportManager::AppendInternalReportDirectory(const QString FileName, QString &PathAndFileName) {
	QString wcPathAndFileName = "";
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_REPORTS, &FileName, &wcPathAndFileName, MAX_PATH);
	PathAndFileName = wcPathAndFileName;
}
//******************************************************
//
/// Deletes the given report file (either temporary or complete) on internal flash.
/// @param[in] reportName - The report file name.
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
BOOL CReportManager::DeleteReportFile(const QString reportName) {
	return TRUE;
}
//******************************************************
//
/// Outputs the report to the printer.
/// @param[in] strTitle - Report title to print.
/// @param[in] FileAndDir - Which report to print (pathname & filename).
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
BOOL CReportManager::PrintReport(const QString strTitle, const QString FileAndDir) {
	/*	CReportStorage *pReport = NULL;
	 // indexOf out what report type is to be printed (only ASCII or Unicode supported currently)
	 pReport = new CReportStorage();
	 CEditPrint EditPrint( pReport, FileAndDir );
	 CPrinter dlg( &EditPrint );
	 dlg.OnPrint(strTitle);*/
	return TRUE;
}
//******************************************************
//
/// Method that tidies up the report directory
/// 
//******************************************************
void CReportManager::TidyReportDirectory() {
	// get the contents of the report directory and delete the oldest files - leave
	// a maximum of 10 files in the directory
	bool bContinueChecking = true;
	WCHAR wcaFullPath[ MAX_PATH];
	memset(wcaFullPath, 0, sizeof(WCHAR) * MAX_PATH);
	SYSTEMTIME tSysTimeNow;
	GetSystemTime(&tSysTimeNow);
	FILETIME tFileTimeNow;
	SystemTimeToFileTime(&tSysTimeNow, &tFileTimeNow);
	// continue with this process until all the extra files are deleted
	while (bContinueChecking) {
		ULONG ulSpaceUsed = 0;
		// build the wildcard path
		pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_REPORTS, CStringUtils::ms_strREPORTS_FILE_EXT, wcaFullPath, MAX_PATH);
		// now loop through getting the filenames and deleting them
		WIN32_FIND_DATA tindexOfFileData;
		QString strOldestFilename("");
		tindexOfFileData.cFileName[0] = '\0';
		HANDLE hindexOf = CStorage::FindFirstFile(wcaFullPath, &tindexOfFileData);
		USHORT usFileCount = 0;
		FILETIME tOldestTime;
		tOldestTime.dwHighDateTime = ULONG_MAX;
		tOldestTime.dwLowDateTime = ULONG_MAX;
		// loop through counting the files found
		while (hindexOf != INVALID_HANDLE_VALUE ) {
			// increment the file count
			++usFileCount;
			// add the file size to our running total - always assume files are less than 4GB in size
			// hence why we are only looking at the low DWORD
			ulSpaceUsed += static_cast<ULONG>(tindexOfFileData.nFileSizeLow);
			// store the oldest time as we will use this for any time based tidy ups later
			if (CompareFileTime(&tindexOfFileData.ftCreationTime, &tOldestTime) == -1) {
				tOldestTime = tindexOfFileData.ftCreationTime;
				// store the filename
				strOldestFilename = tindexOfFileData.cFileName;
			} else if (CompareFileTime(&tindexOfFileData.ftCreationTime, &tFileTimeNow) == 1) {
				// the file has a time ahead of the time now - this would imply the
				// recorder time has been changed - the solution to this will be to
				// set the creation time to the time now so that this will be deleted
				// some time in the future
				pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_REPORTS, tindexOfFileData.cFileName, wcaFullPath, MAX_PATH);
				HANDLE hFile = CreateFile(wcaFullPath, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
				NULL);
				if (hFile != INVALID_HANDLE_VALUE) {
					SetFileTime(hFile, &tFileTimeNow, &tFileTimeNow, &tFileTimeNow);
					//No need to close the mutex in Qt
				}
			}
			// now get the next file (if any)
			if (CStorage::FindNextFile(hindexOf, &tindexOfFileData) == 0) {
				break;
			}
		}
		
		// check if we are required to perform a tidy up
		const ULONG ulDIR_SIZE_LIMIT = 3145728; // Arbitary 3MB limit
		if (((usFileCount >= 10) || (ulSpaceUsed > ulDIR_SIZE_LIMIT)) && (strOldestFilename != "")) {
			// required to perform a tidy up - delete the oldest file
			pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_REPORTS, strOldestFilename, wcaFullPath, MAX_PATH);
			QFile::remove(wcaFullPath);
		} else {
			// all done so break from the loop
			bContinueChecking = false;
		}
	}
}
//******************************************************
//
/// Method that adds the report header
/// 
/// @param[out]		CRTFLib &rkRTFFile - The RTF file we are writing
/// @param[in]		const USHORT usREPORT_NO - The report number
/// @param[in]		const LONGLONG llTIME_CREATED - The time the report was created
///
//******************************************************
void CReportManager::AddHeader(CRTFLib &rkRTFFile, const USHORT usREPORT_NO, const LONGLONG llTIME_CREATED) {
	QString reportCreatedOn;
	QString strReportItemTitle("");
	QString strReportItem("");
	CEventSetupConfig *pEventCfg = pGlbSetup->GetEventSetupConfig();
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	// Load report configuration, using report ID
	T_PREPORTS ptReports = pEventCfg->GetReportsBlock(CONFIG_COMMITTED);
	T_PGENERALCONFIG ptGenBlk = pkGenCfg->GetSystemGeneralBlock(CONFIG_COMMITTED);
	strReportItemTitle = tr("Recorder Name");
	strReportItem = QString::asprintf("%s: %s", strReportItemTitle.toLocal8Bit().data(), ptGenBlk->Name);
	RTF_PARAGRAPH_FORMAT *pf = rkRTFFile.rtf_get_paragraphformat();
	pf->CHARACTER.boldCharacter = false;
	pf->CHARACTER.subscriptCharacter = true;
	pf->newHeader = true;
	// Write paragraph text
	rkRTFFile.rtf_start_paragraph(strReportItem, false);
	// asprintf paragraph
	pf->newHeader = false;
	pf->paragraphTabs = true;
	pf->TABS.tabKind = RTF_PARAGRAPHTABKIND_RIGHT;
	pf->TABS.tabLead = RTF_PARAGRAPHTABLEAD_DOT;
	pf->TABS.tabPosition = 7200;
	// Write paragraph text
	strReportItemTitle = tr("Recorder Serial Number");
	strReportItem = QString::asprintf("%s: %u", strReportItemTitle.toLocal8Bit().data(),
			pSYSTEM_INFO->GetSerialNumber());
	rkRTFFile.rtf_start_paragraph(strReportItem, true);
	pf->paragraphTabs = true;
	pf->TABS.tabKind = RTF_PARAGRAPHTABKIND_RIGHT;
	pf->TABS.tabLead = RTF_PARAGRAPHTABLEAD_DOT;
	pf->TABS.tabPosition = 7200;
	// Write paragraph text
	strReportItemTitle = tr("Recorder ID");
	strReportItem = QString::asprintf("%s: %u", strReportItemTitle.toLocal8Bit().data(), ptGenBlk->ID);
	rkRTFFile.rtf_start_paragraph(strReportItem, true);
	strReportItemTitle = tr("Report name");
	strReportItem = QString::asprintf("%s: %s", strReportItemTitle.toLocal8Bit().data(),
			ptReports->Report[usREPORT_NO].Tag);
	rkRTFFile.rtf_start_paragraph(strReportItem, true);
	strReportItemTitle = tr("Report created on");
	CTVtime ReportCreation(llTIME_CREATED);
	ReportCreation.TimeToStringNoFracs(reportCreatedOn.toLocal8Bit().data());
	strReportItemTitle = tr("Report generated on:");
	strReportItem = strReportItemTitle + reportCreatedOn;
	rkRTFFile.rtf_start_paragraph(strReportItem, true);
	pf->CHARACTER.subscriptCharacter = false;
	rkRTFFile.EndHeader();
}
//******************************************************
//
/// Method that adds the report footer
/// 
/// @param[out]		CRTFLib &rkRTFFile - The RTF file we are writing
///	@param[in]		const T_FOOTER_STYLE_ENUM eFOOTER_STYLE - The footer style - two
///					lines or a single line
/// 
//******************************************************
void CReportManager::AddFooter(CRTFLib &rkRTFFile, const T_FOOTER_STYLE_ENUM eFOOTER_STYLE) {
	RTF_PARAGRAPH_FORMAT *pf = rkRTFFile.rtf_get_paragraphformat();
	QString strReportItemTitle("");
	QString strReportItem("");
	pf->newFooter = true;
	pf->TABS.tabLead = RTF_PARAGRAPHTABLEAD_NONE;
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_LEFT;
	rkRTFFile.rtf_start_paragraph(" ", false);
	pf->newFooter = false;
	RTF_TABLECELL_FORMAT *cf = rkRTFFile.rtf_get_tablecellformat();
	cf->SHADING.shadingFillColor = 0;
	cf->SHADING.shadingBkColor = 3;
	rkRTFFile.StartTable();
	// No header & invisible table
	USHORT iNO_OF_COLS = 3;
	// asprintf paragraph
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
	pf->CHARACTER.boldCharacter = false;
	cf->borderBottom.border = false;
	cf->borderTop.border = false;
	cf->borderright.border = false;
	cf->borderleft.border = false;
	rkRTFFile.StartRow(iNO_OF_COLS);
	QString strCell("");
	strCell = tr("Reviewed By......................");
	rkRTFFile.rtf_start_paragraph(strCell, false);
	// End table cell
	rkRTFFile.rtf_end_tablecell();
	strCell = tr("Date......................");
	rkRTFFile.rtf_start_paragraph(strCell, false);
	// End table cell
	rkRTFFile.rtf_end_tablecell();
	strCell = tr("Comment......................");
	rkRTFFile.rtf_start_paragraph(strCell, false);
	// End table cell
	rkRTFFile.rtf_end_tablecell();
	// End table row
	rkRTFFile.rtf_end_tablerow();
	// check if two lines are desired
	if (eFOOTER_STYLE == fseTWO_LINES) {
		rkRTFFile.StartRow(iNO_OF_COLS);
		strCell = tr("Checked By........................");
		rkRTFFile.rtf_start_paragraph(strCell, false);
		// End table cell
		rkRTFFile.rtf_end_tablecell();
		strCell = tr("Date......................");
		rkRTFFile.rtf_start_paragraph(strCell, false);
		// End table cell
		rkRTFFile.rtf_end_tablecell();
		strCell = tr("Comment......................");
		rkRTFFile.rtf_start_paragraph(strCell, false);
		// End table cell
		rkRTFFile.rtf_end_tablecell();
		// End table row
		rkRTFFile.rtf_end_tablerow();
	}
	rkRTFFile.EndTable();
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_RIGHT;
	strReportItem = tr("Page");
	strReportItem += " ";
	rkRTFFile.rtf_start_paragraph(strReportItem, true);
	pf->bInsertPageNo = true;
	rkRTFFile.rtf_start_paragraph(" ", false);
	pf->bInsertPageNo = false;
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
	rkRTFFile.rtf_start_paragraph(" ", true);
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
	rkRTFFile.rtf_start_paragraph(" ", true);
	rkRTFFile.EndFooter();
}
//******************************************************
//
/// Create a TUS report
///
/// @param[in] kNewRTFFile - The report file handler to update.
/// 
//******************************************************
void CReportManager::CreateTUSReport(CRTFLib &kNewRTFFile) {
	// get the display temerpature units
	QString strTempUnits("");
	switch ( pSYSTEM_INFO->GetDisplayTempUnits()) {
	case TEMP_DEG_C:
		strTempUnits = "C";
		break;
	case TEMP_DEG_F:
		strTempUnits = "F";
		break;
	case TEMP_KELVIN:
		strTempUnits = "K";
		break;
	default:
		strTempUnits = "ERR";
		break;
	}
	QString strMinutes("");
	strMinutes = tr("Mins.");
	RTF_TABLECELL_FORMAT *cf = kNewRTFFile.rtf_get_tablecellformat();
	RTF_PARAGRAPH_FORMAT *pf = kNewRTFFile.rtf_get_paragraphformat();
	// get a pointer ot the TUS manager singlton which will have all the test reulsts
	CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
	// get a pointer to all the test configuration information
	CGeneralSetupConfig *pkGenSetupCfg = pSETUP->GetGeneralSetupConfig();
	T_PGENERALCONFIG ptGenConfig = pkGenSetupCfg->GetSystemGeneralBlock(CONFIG_COMMITTED);
	bool bPortrait = (ptGenConfig->Printer.Portrait == TRUE);
	T_PFURNACESCONFIG ptFurnaces = pkGenSetupCfg->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
	QString strTitle("");
	QString strParagraph("");
	strTitle = tr("Temperature Uniformity Survey Recorder Summary Report");
	kNewRTFFile.AddTitle(strTitle);
	// add the engineer information
	strParagraph = tr("Username:");
	strParagraph += pkTUSMgr->GetEngineer();
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	kNewRTFFile.rtf_start_paragraph("", true);
	// add the number of TC's
	strParagraph = QString::asprintf(IDS_TUS_SCREEN_NO_OF_TC_LABEL, pkTUSMgr->GetNoOfTUSTCs());
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
	// Start a new table
	kNewRTFFile.StartTable();
	cf->SHADING.shadingBkColor = 3;
	// asprintf paragraph
	pf->paragraphAligment = RTF_PARAGRAPHALIGN_JUSTIFY;
	pf->CHARACTER.boldCharacter = false;
	kNewRTFFile.StartRow(2);
	// add the furnace information
	strParagraph = tr("Furnace");
	kNewRTFFile.rtf_start_paragraph(strParagraph, false);
	// add the furnace name
	strParagraph = QString::asprintf(IDS_TUS_SCREEN_NAME_LABEL, ptFurnaces->Furnaces[0].Name);
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// add the furnace model
	strParagraph = QString::asprintf(IDS_TUS_SCREEN_MODEL_NO_LABEL, ptFurnaces->Furnaces[0].ModelNo);
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// add the furnace instrumentation type
	QString strInstTypeList("");
	strInstTypeList = tr("A|B|C|D|E|");
	strParagraph = QString::asprintf(IDS_TUS_SCREEN_INST_TYPE_LABEL,
			CStringUtils::GetItemAtPos(strInstTypeList, ptFurnaces->Furnaces[0].InstType).toLocal8Bit().data());
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// add the furnace class
	QString strClassList("");
	strInstTypeList = tr("1|2|3|4|5|6|");
	strParagraph = QString::asprintf(IDS_TUS_SCREEN_CLASS_LABEL,
			CStringUtils::GetItemAtPos(strInstTypeList, ptFurnaces->Furnaces[0].FurnaceClass).toLocal8Bit().data());
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// insert a blank line
	strParagraph = " ";
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// Add the time information
	strParagraph = tr("Time");
	kNewRTFFile.rtf_start_paragraph(strParagraph, false);
	// add the started time
	strParagraph = tr("Started:");
	strParagraph += " " + pkTUSMgr->GetStartTime();
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// add the elapsed time
	strParagraph = tr("Elapsed:");
	strParagraph += " " + pkTUSMgr->GetElapsedTime();
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// add the stop time
	strParagraph = QString::asprintf(IDS_TUS_SCREEN_STOP_TIME_LABEL, pkTUSMgr->GetStopTime().toLocal8Bit().data());
	strParagraph = strParagraph + pkTUSMgr->GetStopTime();
	kNewRTFFile.rtf_start_paragraph(strParagraph, true);
	// End table cell
	kNewRTFFile.rtf_end_tablecell();
	// End table row
	kNewRTFFile.rtf_end_tablerow();
	pf->CHARACTER.subscriptCharacter = true;
	const int iaCOL_WIDTHS[12] = { 4, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 7 };
	for (int iSetPointCount = -1; iSetPointCount < FURNACESCONFIG_SETPOINTS_SIZE; iSetPointCount++) {
		kNewRTFFile.StartVarWidthRow(12, iaCOL_WIDTHS);
		// check if this is the first row in which case we must do the titles
		if (iSetPointCount == -1) {
			// leave this cell blank
			kNewRTFFile.rtf_start_paragraph("", false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Setpoint (Tol.)");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Status");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Max Sensor");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Min Sensor");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Max Sensor Diff");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Max Sensor SP Diff");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Max Ramp Overshoot");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Ramp duration");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Sensor Lag into Soak");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Stable Soak Duration");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			strParagraph = tr("Meets Class");
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
		} else {
			QString strStatus("");
			// this is the set point information
			switch (pkTUSMgr->GetSPStatus(iSetPointCount)) {
			case SOAK_STATUS_NOTSTARTED:
				strStatus = "";
				break;
			case SOAK_STATUS_SOAK_DETECT:
				strStatus = tr("Detect");
				break;
			case SOAK_STATUS_IN_SOAK:
				strStatus = tr("Soak");
				break;
			case SOAK_STATUS_IN_STABILITY:
				strStatus = tr("Stable");
				break;
			case SOAK_STATUS_PASSED:
				strStatus = tr("Done");
				break;
			case SOAK_STATUS_FAILED:
				strStatus = tr("Failed");
				break;
			case SOAK_STATUS_NOTENABLED:
			default:
				strStatus = "";
				break;
			}
			strParagraph = QString::asprintf("%u", iSetPointCount + 1);
			kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%0.2f%s",
				pSYSTEM_INFO->GetLocalTempFromDegC(ptFurnaces->Setpoints[iSetPointCount].Level),
						strTempUnits.toLocal8Bit().data());
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
				strParagraph = QString::asprintf("(+/-%0.1f)", pkTUSMgr->GetSoakTolerance(iSetPointCount));
				kNewRTFFile.rtf_start_paragraph(strParagraph, true);
			} else {
				strParagraph = tr("NA");
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				kNewRTFFile.rtf_start_paragraph(strStatus, false);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			QString strMaxTC(pkTUSMgr->GetSPMaxTCName(iSetPointCount));
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				kNewRTFFile.rtf_start_paragraph(strMaxTC, false);
			}
			const float fMAX_TC_VAL = pkTUSMgr->GetSPMaxTCValue(iSetPointCount);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%0.2f%s", fMAX_TC_VAL, strTempUnits.toLocal8Bit().data());
				kNewRTFFile.rtf_start_paragraph(strParagraph, true);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			QString strMinTC(pkTUSMgr->GetSPMinTCName(iSetPointCount));
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				kNewRTFFile.rtf_start_paragraph(strMinTC, false);
			}
			const float fMIN_TC_VAL = pkTUSMgr->GetSPMinTCValue(iSetPointCount);
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%0.2f%s", fMIN_TC_VAL, strTempUnits.toLocal8Bit().data());
				kNewRTFFile.rtf_start_paragraph(strParagraph, true);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = strMaxTC + " - " + strMinTC;
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			}
			const float fMAX_MIN_TC_DIFF_VAL = fMAX_TC_VAL - fMIN_TC_VAL;
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%0.2f%s", fMAX_MIN_TC_DIFF_VAL, strTempUnits.toLocal8Bit().data());
				kNewRTFFile.rtf_start_paragraph(strParagraph, true);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = pkTUSMgr->GetSPMaxTCDiffWrtSPName(iSetPointCount);
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			}
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%0.2f%s", pkTUSMgr->GetSPMaxTCDiffWrtSPValue(iSetPointCount),
						strTempUnits.toLocal8Bit().data());
				kNewRTFFile.rtf_start_paragraph(strParagraph, true);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = pkTUSMgr->GetSPMaxRampOvershootTCName(iSetPointCount);
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			}
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%0.2f%s", pkTUSMgr->GetSPMaxRampOvershootTCValue(iSetPointCount),
						strTempUnits.toLocal8Bit().data());
				kNewRTFFile.rtf_start_paragraph(strParagraph, true);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
						static_cast<LONGLONG>(pkTUSMgr->GetSPRampDuration(iSetPointCount)));
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
						static_cast<LONGLONG>(pkTUSMgr->GetSPTCLagIntoSoak(iSetPointCount)));
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%u %s", pkTUSMgr->GetSPMaxTCSoakDuration(iSetPointCount),
						strMinutes.toLocal8Bit().data());
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
			// check this set point is enabled
			if (ptFurnaces->Setpoints[iSetPointCount].Enabled) {
				strParagraph = QString::asprintf("%s", pkTUSMgr->GetSPFurnaceClassMet(iSetPointCount), strMinutes);
				kNewRTFFile.rtf_start_paragraph(strParagraph, false);
			} else {
				kNewRTFFile.rtf_start_paragraph("", false);
			}
			// End table cell
			kNewRTFFile.rtf_end_tablecell();
		}
		// End table row
		kNewRTFFile.rtf_end_tablerow();
	}
	kNewRTFFile.EndTable();
	pf->CHARACTER.subscriptCharacter = false;
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.StartTable();
	kNewRTFFile.StartRow(1);
	kNewRTFFile.rtf_start_paragraph("Comments:", false);
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
	// add some more lines if this is in portrait
	if (bPortrait) {
		kNewRTFFile.rtf_start_paragraph("", true);
		kNewRTFFile.rtf_start_paragraph("", true);
		kNewRTFFile.rtf_start_paragraph("", true);
	}
	kNewRTFFile.rtf_end_tablecell();
	kNewRTFFile.rtf_end_tablerow();
	kNewRTFFile.EndTable();
	// Leave blank lines at end
	kNewRTFFile.rtf_start_paragraph("", true);
	kNewRTFFile.rtf_start_paragraph("", true);
}
//******************************************************
//
/// Get the report started information
/// @param[in] reportStartTime - Report start time information in micro secs
/// @param[out] nTotOfDaysInMonth - Days in a Month [1-31].
/// @param[out] nDayInMonth - Particular Day in a Month. Ex: 5, 8, 18.
/// @param[out] nRepStartTimeHH - Gets the Hour of the report started.
/// @param[out] nRepStartTimeMM - Gets the Minutes of the report started.
/// @param[out] nRepStartTimeSS - Gets the Seconds of the report started.
/// 
/// 
//******************************************************
void CReportManager::GetReportStartInfo(LONGLONG reportStartTime, UINT &nTotOfDaysInMonth, UINT &nDayInMonth,
		UINT &nRepStartTimeHH, UINT &nRepStartTimeMM, UINT &nRepStartTimeSS) {
	CTVtime RemainingDaysInMonth(reportStartTime);
	SYSTEMTIME st;
	RemainingDaysInMonth.GetSYSTEMTIME(&st);
	nDayInMonth = st.wDay;
	nRepStartTimeHH = st.wHour;
	nRepStartTimeMM = st.wMinute;
	nRepStartTimeSS = st.wSecond;
	nTotOfDaysInMonth = RemainingDaysInMonth.GetDaysInMonth(st.wMonth, st.wYear);
}
//PSR - Fix for 1-30DY01Q begin
CReportManager::~CReportManager() {
	if (m_pReportGenThread != NULL) {
		delete m_pReportGenThread;
		m_pReportGenThread = NULL;
	}
}
//This function will be called from EventControl-effect when triggered for report generate request
//The ReportGenThread will be created if it not exist and request will be posted to that thread
BOOL CReportManager::PostReportGenRequest(USHORT usReportIndex) {
	//LOG_INFO(TRACE_ALWAYS, "CReportManager::PostReportGenRequest() - Begin");
	BOOL bRet = TRUE;
	if (m_pReportGenThread == NULL) {
		m_pReportGenThread = (CReportGenThread*) AfxBeginThread(RUNTIME_CLASS(CReportGenThread),
				THREAD_PRIORITY_BELOW_NORMAL, 0, // No change in stack size
				CREATE_SUSPENDED);
		if (m_pReportGenThread != NULL) {
			m_pReportGenThread->m_bAutoDelete = FALSE;
			m_pReportGenThread->start();
			//Wait for the message queue to be created and start posting
			sleep(10);
			//LOG_INFO(TRACE_ALWAYS, "CReportManager::PostReportGenRequest() - Created ReportGenTHread and PostThreadMessage for report %d", usReportIndex);
			m_pReportGenThread->PostThreadMessageW(WM_GENERATE_REPORT, NULL, usReportIndex);
		} else {
			//LOG_INFO(TRACE_ALWAYS, "CReportManager::PostReportGenRequest() - Failed to create ReportGenThread for report %d", usReportIndex);
			bRet = FALSE;
		}
	} else {
		//LOG_INFO(TRACE_ALWAYS, "CReportManager::PostReportGenRequest() - PostThreadMessage for report %d", usReportIndex);
		m_pReportGenThread->PostThreadMessageW(WM_GENERATE_REPORT, NULL, usReportIndex);
	}
	//LOG_INFO(TRACE_ALWAYS, "CReportManager::PostReportGenRequest() - End");
	return bRet;
}
//PSR - Fix for 1-30DY01Q end

//************************************************************************************
// Module  AMS2750
// Filename  AMS2750BuildCalFile.h
// Copyright GA Digital 2021
/// **********************************************************************************
/// @n Module: 	  AMS2750 cal file processing
/// @n Filename:  AMS2750BuildCalFile.h
/// @n Description: Build information into cal data file 
///
// ***********************************************************************************
#include "AMS2750ProcessCalFile.h"
#include "TVtime.h"
#include "Conversion.h"
#include "CStorage.h"
#include <QString>
#ifndef __CAMS2750BUILDCALFILE_H__
#define __CAMS2750BUILDCALFILE_H__
// Build TUS file results
typedef enum {
	BF_OK = 0,					// Generic ok, no errors
	BF_NOT_INITIALISED,	// Not initialised failure, presumably due to a problem with opening the file or not calling InitialiseCalFile
	BF_FAILED,					// Generic Failure
	BF_STRCUTURE_MAP_FULL,	// No more room in structure map, need to add more structure space using NUM_STRUCT_SLOTS
	BF_FILE_ALLOCATION_FULL,	// File allocation is full, exceeded TUS_MAX_FILE_SIZE,
} T_C2750BUILDFILE_RES;
//**CAMS2750BuildTUSFile**************************************************
/// 
/// @brief Responsible for processing cal file building commands
///
/// Responsible for processing cal file building commands
///
//****************************************************************************
class CAMS2750BuildCalFile: public CAMS2750ProcessCalFile {
public:
	// Constructor
	CAMS2750BuildCalFile();
	// Destructor
	~CAMS2750BuildCalFile();
	// Method that adds the general calibration data structure to the file
	T_C2750BUILDFILE_RES AddGeneralCalibrationStructure(T_PAMS2750GENCAL pStruct);
	// Method that adds a sensor calibration results structure to a file
	T_C2750BUILDFILE_RES AddSensorInputCalibrationStructure(T_PSENSORINPUTCALDATA pStruct, int instance);
	// Method that validates (and creates if it does not exist) the cal data file
	const bool InitialiseCalFile(QString rstrCalFilename);
	// Method that clears the cal data file usually at the end of a calibration
	void ClearCalDataFile();
	// Method that updates the CRC in the header of the Cal file
	void UpdateHeaderCRC();
	// Method that writes the header information to disk
	void WriteHeaderToDisk();
private:
	// Method that adds the specified structure to the TUS file
	T_C2750BUILDFILE_RES AddStruct(void *structPtr, int structSize, T_STRUCTURE_IDENT structIdent, int structInstance);
	// Method that updates the CRC in the TUS file following the addition of a structure
	void UpdateCRCOnStructure(int sIndex, void *structPtr);
	// Method that logs a file error and deletes the Cal data file
	void CalDataFileError(const QString &rstrERROR, QString &rstrFilename);
	// Method that validates the file
	T_C2750PROCESSFILE_RES ValidateCalFile(T_STRUCTURE_IDENT &errStruct, int &instance);
	// Flag indicating if the cal file is in an operational state (i.e. the file is open and writeable etc)
	bool m_bInitialised;
	// Storage class for the cal data file
	CStorage m_kCalDataFile;
	// Structure containing a local copy of the file header information 
	T_2750FILEHEADEROVERLAY m_tFileHeader;
};
#endif

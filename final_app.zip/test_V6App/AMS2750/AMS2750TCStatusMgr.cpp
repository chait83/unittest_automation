/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 data processing
/// @n Filename:  ams2750tcstatusmgr.h
/// @n Description: Implementation of the CAMS2750TCStatusMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  7 Stability Project 1.2.1.3 7/2/2011 4:55:23 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.2.1.2 7/1/2011 4:37:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 Stability Project 1.2.1.1 3/17/2011 3:20:08 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  4 Stability Project 1.2.1.0 2/15/2011 3:02:08 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "StringDefinitions.h"
#include "AMS2750TCStatusMgr.h"
#include "EventManager.h"
#include "TVtime.h"
// Static const/initialsation
std::unique_ptr<CAMS2750TCStatusMgr> CAMS2750TCStatusMgr::ms_kAMS2750TCStatusMgr;
QMutex CAMS2750TCStatusMgr::ms_hCreationMutex;
//****************************************************************************
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CAMS2750TCStatusMgr* CAMS2750TCStatusMgr::Instance() {
	// check if the pointer exists yet
	if (ms_kAMS2750TCStatusMgr.get() == NULL) {
		DWORD waitSingleObjectResult = WAIT_OBJECT_0;
		// An instance has yet to be completed
		waitSingleObjectResult = ms_hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == ms_kAMS2750TCStatusMgr.get()) {
				// not been created yet therefore create one now
                ms_kAMS2750TCStatusMgr = std::unique_ptr<CAMS2750TCStatusMgr>(new CAMS2750TCStatusMgr());

			}
			ms_hCreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, "CAMS2750TCStatusMgr WaitForSingleObject Error", "Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
	}
	return ms_kAMS2750TCStatusMgr.get();
}
//****************************************************************************
///
/// Constructor
///
//****************************************************************************
CAMS2750TCStatusMgr::CAMS2750TCStatusMgr() : m_usExpiryWarningUseLimitDays(7), m_usExpiryWarningLimitUses(5), m_usExpiryWarningCalibLimitDays(
		14), m_isInCalMode(FALSE)
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
  ,m_pDebugFileLogger(NULL)
#endif
{
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
		SetDebugLogger(&m_debugFileLogger);
	#endif	
}
//****************************************************************************
/// Intitialise the timers from startup
///
/// @return nothing
//****************************************************************************
void CAMS2750TCStatusMgr::Initialise() {
	m_pTUSMgr = CAMS2750TUSMgr::Instance();
	m_pTCTimersNV = m_pTUSMgr->GetTCTimersNVPtr();
}
//****************************************************************************
/// Configure the timers on startup and after each configuration change
///
/// @return nothing
//****************************************************************************
void CAMS2750TCStatusMgr::Configure() {
	m_processCnt = 0;
	m_processReload = pSYSTIMER->GetProcessSlicesPerSecond() * AMS2750_TCTIMER_PROCESS_SECONDS;
	// Get a handle on the sensors configuration structure
	CIOSetupConfig *pkIOSetupCfg = pSETUP->GetIOSetupConfig();
	T_PAMS2750SENSORS ptSensors = pkIOSetupCfg->GetAMS2750SensorBlock(CONFIG_COMMITTED);
	CDataItemTypeIO *pAIDataItem = NULL;
	T_PAMS2750SENSOR *pSensorCfg = NULL;
	m_FirstIn = TRUE;
	T_TC_INFO *pTCInfo = NULL;
	m_numTCs = 0;
	for (int tcIndex = 0; tcIndex < MAX_ANALOGUE_IN; tcIndex++) {
		m_pTCbyAI[tcIndex] = NULL;
		pTCInfo = &m_TCInfo[m_numTCs];
		pTCInfo->TCIndex = tcIndex;
		pTCInfo->pAIDIT = (CDataItemIO*) pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE, tcIndex);
		pTCInfo->pAIConfig = pkIOSetupCfg->GetAnalogueInput(tcIndex, CONFIG_COMMITTED);
		pTCInfo->pSensorConfig = &ptSensors->Sensors[tcIndex];
		// Get TC category and validity of calibration and usage tracking
		BOOL CalTrackValid, UsageTrackValid;
		pTCInfo->category = GetTCCategory(pTCInfo, CalTrackValid, UsageTrackValid);
		CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
		T_PFURNACESCONFIG pFurnaces = pkGenCfg->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
		// Check if TC is enabled, trackable and usegae tracking is desired
		if (pTCInfo->pAIDIT->IsEnabled() == TRUE &&				// Is the analogue input enabled
				pTCInfo->category != TC_CATEGORY_NONE)			// Make sure it is a trackable category
						{
			// TC is setup to track, do the rule permit tracking?
			if ((CalTrackValid == TRUE && pTCInfo->pSensorConfig->CalTrack == TRUE) ||	// Is calibration tracking valid and required by user OR
					(UsageTrackValid == TRUE && pTCInfo->pSensorConfig->UsageTrack == TRUE))// Is usage tracking allowed and is it requested by user
					{
				// Yes, add the TC as a tracked TC
				// Setup rest of tc info structure
				pTCInfo->pTCNV = &m_pTCTimersNV->tc[tcIndex];
				// Setup calibration tracking information
				if (CalTrackValid == TRUE && pTCInfo->pSensorConfig->CalTrack == TRUE) {
					pTCInfo->trackCal = TRUE;
					pTCInfo->calStatus = TC_STATUS_GOOD;			// Track cal
					pTCInfo->daysRemainingTilCal = 1;
				} else {
					pTCInfo->trackCal = FALSE;
					pTCInfo->calStatus = TC_STATUS_NOT_TRACKED;	// Don't track cal
					pTCInfo->daysRemainingTilCal = 0;
				}
				// Setup usage tracking information
				if (UsageTrackValid == TRUE && pTCInfo->pSensorConfig->UsageTrack == TRUE) {
					pTCInfo->trackUsage = TRUE;				// Track Usage
					pTCInfo->usesStatus = TC_STATUS_GOOD;
				} else {
					pTCInfo->trackUsage = FALSE;		// No usage tracking
					pTCInfo->daysStatus = TC_STATUS_NOT_TRACKED;
					pTCInfo->usesStatus = TC_STATUS_NOT_TRACKED;
				}
				pTCInfo->daysleft = 0;
				CDataItemPen *pPenDIT = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, tcIndex);
				// Get the groupNumber and convert to 0 based index for furnace
				int grpNumber = pPenDIT->GetPenConfig()->GroupNumber - 1;
				// If pen was not in a group then use the fist furnace config
				if (grpNumber == -1)
					grpNumber = 0;
				pTCInfo->pFurnace = &pFurnaces->Furnaces[grpNumber];
				// Get type of sensor
				TC_SENSTYPE sensorType = TC_SENSTYPE_REC;
				if (pTCInfo->pSensorConfig->LoadTC == TRUE) {
					sensorType = TC_SENSTYPE_LOAD;
				} else if (pTCInfo->pSensorConfig->TUSTC == TRUE) {
					sensorType = TC_SENSTYPE_TUS;
				}
				// If the type of TC has changed renew date 
				if (((pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC)
						&& (pTCInfo->pAIConfig->TC.SelectedTC != pTCInfo->pTCNV->TCRTtype))
						|| ((pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_RT)
								&& (pTCInfo->pAIConfig->RT.SelectedRT != pTCInfo->pTCNV->TCRTtype))
						|| pTCInfo->category != pTCInfo->pTCNV->category
						|| pTCInfo->pTCNV->renewDate != pTCInfo->pSensorConfig->DateRenewed
						|| pTCInfo->pTCNV->SensType != sensorType) {
					pTCInfo->pTCNV->lastState = T_TCUSAGE_STATE_NOTSTARTED;				// Reset the TC usage
					if (pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC) {
						pTCInfo->pTCNV->TCRTtype = pTCInfo->pAIConfig->TC.SelectedTC;			// Set TC Type into NV
					} else {
						pTCInfo->pTCNV->TCRTtype = pTCInfo->pAIConfig->RT.SelectedRT;			// Set RT Type into NV
					}
					pTCInfo->pTCNV->category = pTCInfo->category;						// Set category into NV
					pTCInfo->pTCNV->renewDate = pTCInfo->pSensorConfig->DateRenewed;	// Update renew date
					pTCInfo->pTCNV->SensType = sensorType;								// Assign sensor type
					pTCInfo->pTCNV->expiryDate = 0;										// Force calibration to reset
				}
				m_pTCbyAI[tcIndex] = pTCInfo;
				// Increment number of tracked TC's
				m_numTCs++;
			}
		}
	}
	// Configure temperature index for temp limit lookups 
	m_tempIndex = 0;
	if (pSYSTEM_INFO->GetDisplayTempUnits() == TEMP_DEG_C) {
		m_tempIndex = 1;
	}
	// Are there any TC being cal or usage tracked?
	if (m_numTCs == 0 || pSYSTEM_INFO->GetAMS2750Mode() == AMS2750_NONE) {
		m_IsActive = FALSE;	// No TC's being tracked for Cal expiry or Usage or no MAS2750 options set, disable processing
	} else {
		m_IsActive = TRUE;		// At least 1 TC cal or usage tracked.
	}
	// Setup initial display
	QString strDummy("");
	m_ptSensorInfo = pSETUP->GetIOSetupConfig()->GetAMS2750SensorBlock(CONFIG_COMMITTED);
	for (int iCount = 0; iCount < MAX_ANALOGUE_IN; iCount++) {
		GetDaysleftInfo(iCount, strDummy);
		GetUsesleftInfo(iCount, strDummy);
		GetCalInfo(iCount, strDummy);
	}
}
//****************************************************************************
/// Process the timers
///
/// @return nothing
//****************************************************************************
void CAMS2750TCStatusMgr::Process() {
	// Is the process active
	if (m_IsActive == TRUE) {
		// Yes, has a the divide down timer expired
		if (--m_processCnt <= 0) {
			// do not do usage processing if we are in calibration mode
			if (m_isInCalMode == FALSE) {
				// Yes process the timers
				BOOL triggerRefresh = FALSE;
				for (int tcIndex = 0; tcIndex < m_numTCs; tcIndex++) {
					// Update usage checking
					if (UpdateUsage(&m_TCInfo[tcIndex]) == TRUE) {
						triggerRefresh = TRUE;	// Status or timer changed, issue refresh
					}
					// Update calibration countdown
					if (UpdateCal(&m_TCInfo[tcIndex]) == TRUE) {
						triggerRefresh = TRUE;	// Status or timer changed, issue refresh
					}
					if (triggerRefresh == TRUE) {
						// If a change has been detected, issue a refresh to the screen
						/// TODO Repaint the screen
//						AfxGetApp()->GetMainWnd()->PostMessage(WM_OPPANEL_REPAINT, (WPARAM) 0, (LPARAM) 0);
					}
				}
				m_FirstIn = FALSE;
			}
			m_processCnt = m_processReload;
		}
	}
}
//****************************************************************************
/// Determine the category of the TC return type TC_CATEGORY
///
/// @param[in]	pTCInfo - pointer to TC info to determine category for.
///
/// @return TRUE if TC has detected a "use", otherwise FALSE
//****************************************************************************
void CAMS2750TCStatusMgr::ReloadUsageTimes(T_PTC_INFO pTCInfo) {
	pTCInfo->pTCNV->usesleft = 0;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
		strDbgMsg = QString::asprintf(_T("ReloadUsageTimes::pTCInfo->category %d"),pTCInfo->category);
		LogDebugMessage(strDbgMsg);
	#endif
	// Specific use loads 
	switch (pTCInfo->category) {
	case TC_CATEGORY_BASE_EXP_KJTNEM: {
		pTCInfo->pTCNV->usesleft = TC_EXP_BASE_MAXUSE; // All algorithms require unlimited uses if less than 500 degrees F
		pTCInfo->daysStatus = TC_STATUS_GOOD; //AMS2750 - E, Standard - Making Expendable TC usage, also need to be considered to 90 days.
		pTCInfo->pTCNV->dayLimit = TC_EXP_BASE_DAYS; //AMS2750 - E, Standard - Making Expendable TC usage, also need to be considered to 90 days.
		break;
	}
	case TC_CATEGORY_BASE_NONEXP_KJTNEM: {
		if (pTCInfo->pSensorConfig->TUSTC == TRUE) {
			pTCInfo->pTCNV->usesleft = TC_NONEXP_BASE_TUSTC_MAXUSE;	// Unlimited Uses for a Non Expendable base metal TUS TC
			pTCInfo->daysStatus = TC_STATUS_GOOD;
			pTCInfo->pTCNV->dayLimit = TC_NONEXP_BASE_TUSTC_DAYS;
		} else if (pTCInfo->pSensorConfig->LoadTC == TRUE) {
			pTCInfo->pTCNV->usesleft = TC_NONEXP_BASE_LOADTC_BELOW_500F_MAXUSE;	// Unlimited uses for a Non Expendable base metal Load TC
			pTCInfo->daysStatus = TC_STATUS_GOOD;
			pTCInfo->pTCNV->dayLimit = TC_NONEXP_BASE_LOADTC_DAYS_BELOW1800F;
		}
		break;
	}
	}
}
//****************************************************************************
/// Check fort Cal periods on TC's
///
/// @param[in]	pTCInfo - pointer to TC info to check cal for
///
/// @return TRUE if TC cal time left updated
//****************************************************************************
BOOL CAMS2750TCStatusMgr::UpdateCal(T_PTC_INFO pTCInfo) {
	BOOL updateCal = FALSE;
	if (pTCInfo->trackCal == TRUE) {
		int prevDaysleft = pTCInfo->daysRemainingTilCal;
		T_2750TC_STATUS prevStatus = pTCInfo->calStatus;
		// Has the expiry date been changed (or another setting causing epiry date to be 0 )
		if (pTCInfo->pTCNV->expiryDate == 0 || pTCInfo->pTCNV->expiryDate != pTCInfo->pSensorConfig->NextCalibDate) {
			// Yes, reset counters as required
			pTCInfo->pTCNV->calLimiter = 0;
			// Reset Expriy counters
			if (pTCInfo->category == TC_CATEGORY_NOBLE_RSB) {
				pTCInfo->pTCNV->calLimiter = I_SEMIANUALLY;	// 6 months
			} else if (pTCInfo->pSensorConfig->TUSTC == TRUE && pTCInfo->category == TC_CATEGORY_BASE_NONEXP_KJTNEM) {
				pTCInfo->pTCNV->calLimiter = I_QUARTERLY;	// 3 months
			}
			pTCInfo->pTCNV->expiryDate = pTCInfo->pSensorConfig->NextCalibDate;	// Set new calibration date
		}
		if (pTCInfo->pSensorConfig->TUSTC == TRUE && pTCInfo->category == TC_CATEGORY_BASE_NONEXP_KJTNEM) {
			// Get the current reading
			float newReading = pTCInfo->pAIDIT->GetFPValue();
			// If in demo mode then take reading from Pen - otherwise from analogue Input
			if (m_pTUSMgr->IsInDemoMode() == TRUE) {
				CDataItemPen *pPenDIT = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, pTCInfo->TCIndex);
				newReading = pPenDIT->GetFPValue();
			}
			// for TUS TC's on non expendable base types 3 months limit.
			if (pTCInfo->pTCNV->calLimiter > 0 && newReading > GetUsageLimitTemp(TC_TEMPS_BASE_500F)
					&& (pTCInfo->pAIConfig->TC.SelectedTC == AI_THERMO_RANGE_E
							|| pTCInfo->pAIConfig->TC.SelectedTC == AI_THERMO_RANGE_K)) {
				// It's a type E or K so reduce the cal limit now to 0 and remove from TC cal tracking
				pTCInfo->pTCNV->calLimiter = 0;
				QString statusMessage;
				QString sensorName = CAMS2750TUSMgr::buildSensorName(pTCInfo->TCIndex + 1,
						pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC);
				statusMessage = sensorName + " Exceeded temperature, Cal tracking disabled ";
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, statusMessage);
			}
		}
		// Only change status for calibrations with a limit.
		if (pTCInfo->pTCNV->calLimiter != 0) {
			// get the next calibration date
			CTVtime kNextCalDate(static_cast<LONGLONG>(pTCInfo->pSensorConfig->NextCalibDate) * USEC_IN_A_SEC);
			// deduct the time and determine the difference in days
			kNextCalDate -= pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			// check if the time is negative
			if (kNextCalDate.GetSeconds() < 0) {
				LONGLONG roundingAdjust =
						static_cast<LONGLONG>(SEC_TO_USEC(static_cast<LONGLONG>(SECONDS_IN_A_DAY - 1)));
				kNextCalDate -= roundingAdjust;
			}
			// divide by the seconds in a day an we have our number of days
			pTCInfo->daysRemainingTilCal = SEC_TO_DAY(kNextCalDate.GetSeconds());
			if (pTCInfo->daysRemainingTilCal > m_usExpiryWarningCalibLimitDays) {
				pTCInfo->calStatus = TC_STATUS_GOOD;
			} else if (pTCInfo->daysRemainingTilCal >= 0) {
				pTCInfo->calStatus = TC_STATUS_WARNING;
			} else {
				pTCInfo->calStatus = TC_STATUS_EXPIRED;
			}
		} else {
			pTCInfo->daysRemainingTilCal = 0;
			pTCInfo->calStatus = TC_STATUS_NOT_TRACKED;
		}
		// Check if change require update
		if (prevDaysleft != pTCInfo->daysRemainingTilCal || prevStatus != pTCInfo->calStatus) {
			updateCal = TRUE;
			pTCInfo->updateMe = TRUE;
			// If a valid update status post inforation to message list
			if (prevStatus != pTCInfo->calStatus && m_FirstIn != TRUE) {
				PostCalStatusChange(pTCInfo);
			}
		}
	}
	return updateCal;
}
//****************************************************************************
/// Check for usage on TC's
///
/// @param[in]	pTCInfo - pointer to TC info to update usage for.
///
/// @return TRUE if TC has detected a "use", otherwise FALSE
//****************************************************************************
BOOL CAMS2750TCStatusMgr::UpdateUsage(T_PTC_INFO pTCInfo) {
	BOOL usageUpdate = FALSE;
	// Get the current reading
	float newReading = pTCInfo->pAIDIT->GetFPValue();
	// If in demo mode then take reading from Pen - otherwise from analogue Input
	if (m_pTUSMgr->IsInDemoMode() == TRUE) {
		// Demo mode, take form Pen instead of AI.
		CDataItemPen *pPenDIT = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, pTCInfo->TCIndex);
		newReading = pPenDIT->GetFPValue();
	}
	// Is usage tracking enabled and valid for this TC
	if (pTCInfo->trackUsage == TRUE) {
		short prevUsesleft = pTCInfo->pTCNV->usesleft;		// Store uses left to see if change made during update
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
			strDbgMsg = QString::asprintf(_T("prevUsesleft %d"),prevUsesleft);
			LogDebugMessage(strDbgMsg);
		#endif
		T_2750TC_STATUS prevUsesStatus = pTCInfo->usesStatus;
		T_2750TC_STATUS prevDaysStatus = pTCInfo->daysStatus;
		int prevDaysleft = pTCInfo->daysleft;
		// Yes, check to see if the state is set to be intialised
		if (pTCInfo->pTCNV->lastState == T_TCUSAGE_STATE_NOTSTARTED) {
			// Reset the usage information
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
				strDbgMsg = QString::asprintf(_T("Reset the usage information"));
				LogDebugMessage(strDbgMsg);
			#endif
			pTCInfo->pTCNV->lastTempRecorded = 0;
			pTCInfo->pTCNV->peakTempReached = 0;
			pTCInfo->pTCNV->usesCap = TC_USESCAP_RESET;
			pTCInfo->pTCNV->lastState = T_TCUSAGE_STATE_BELOW;
			pTCInfo->pTCNV->runCompleted = FALSE;
			ReloadUsageTimes(pTCInfo);
		}
		// Custome usage tracking for TC's and categories that require spcific algorithm 
		switch (pTCInfo->category) {
		case TC_CATEGORY_NOBLE_RSB: {
			break;
		}
		case TC_CATEGORY_BASE_EXP_KJTNEM: {
			// Usage algorithm for HLD sections 2.4.7.4, 2.4.8.4, and 2.4.9.4
			if (pTCInfo->pTCNV->runCompleted == FALSE) {
				if (pTCInfo->pTCNV->peakTempReached > GetUsageLimitTemp(TC_TEMPS_EXP_BASE_1200F)) {
					// We have gone over 1200F or 650C on this run, register when we drop below( including hysteresis )
					if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_EXP_BASE_1200F)
							&& newReading <= GetUsageHystTemp(TC_TEMPS_EXP_BASE_1200F)) {
						// We have gone above the 1200F mark and dropped back down below 1200F minus hysteresis, thats deemed to be a use
						// at that temperature
						pTCInfo->pTCNV->runCompleted = TRUE;
						// We've gone over 1200F, we can only use this TC once, and this is it.
						pTCInfo->pTCNV->usesleft = 0;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
									strDbgMsg = QString::asprintf(_T("UpdateUsage::pTCInfo->pTCNV->usesleft= 0"));
									LogDebugMessage(strDbgMsg);
								#endif
					}
				} else if (pTCInfo->pTCNV->peakTempReached > GetUsageLimitTemp(TC_TEMPS_BASE_500F)) {
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
								strDbgMsg = QString::asprintf(_T("peakTempReached %f, GetUsageLimitTemp(TC_TEMPS_BASE_500F) %f"), pTCInfo->pTCNV->peakTempReached, GetUsageLimitTemp(TC_TEMPS_BASE_500F));
								LogDebugMessage(strDbgMsg);
							#endif
					// We have gone over 500F or 260C on this run, register when we drop below( including hysteresis )
					if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_BASE_500F)
							&& newReading <= GetUsageHystTemp(TC_TEMPS_BASE_500F)) {
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
									strDbgMsg = QString::asprintf(_T("pTCInfo->pTCNV->lastTempRecorded %f, GetUsageHystTemp(TC_TEMPS_BASE_500F) %f, newReading %f")
															, pTCInfo->pTCNV->lastTempRecorded, GetUsageLimitTemp(TC_TEMPS_BASE_500F),newReading);
									LogDebugMessage(strDbgMsg);
								#endif
						// We have gone above the 500F mark and dropped back down below 500F minus hysteresis, thats deemed to be a use
						// at that temperature
						pTCInfo->pTCNV->runCompleted = TRUE;
						// We've gone over 500F, which means we`re limited to a certain amount of uses
						if (IsJOrNThermo(pTCInfo->pAIConfig->TC.SelectedTC)) {
							// limit the uses
							if (pTCInfo->pTCNV->usesCap > TC_EXP_BASE_JN_MAX_USE_500_1200F) {
								pTCInfo->pTCNV->usesCap = TC_EXP_BASE_JN_MAX_USE_500_1200F;
							}
						} else {
							// must be a M, T, K or E, limit the uses
							if (pTCInfo->pTCNV->usesCap > TC_EXP_BASE_MTKE_MAX_USE_500_1200F) {
								pTCInfo->pTCNV->usesCap = TC_EXP_BASE_MTKE_MAX_USE_500_1200F;
							}
						}
						// now decrement the usage count
						pTCInfo->pTCNV->usesleft--;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
									strDbgMsg = QString::asprintf(_T("P1:usesleft dec %d"), pTCInfo->pTCNV->usesleft);
									LogDebugMessage(strDbgMsg);
								#endif
					}
				}
			}
			break;
		}
		case TC_CATEGORY_BASE_NONEXP_KJTNEM: {
			if (pTCInfo->pSensorConfig->TUSTC == TRUE) {
				// This is a TUS TC - Usage algorithm for HLD section 2.4.7.6
				if (pTCInfo->pTCNV->runCompleted == FALSE) {
					if (pTCInfo->pTCNV->peakTempReached > GetUsageLimitTemp(TC_TEMPS_EXP_BASE_1200F)) {
						// We have gone over 1200F or 650C on this run, register when we drop below( including hysteresis )
						if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_EXP_BASE_1200F)
								&& newReading <= GetUsageHystTemp(TC_TEMPS_EXP_BASE_1200F)) {
							// We have gone above the 1200F mark and dropped back down below 1200F minus hysteresis, thats deemed to be a use
							// at that temperature
							pTCInfo->pTCNV->runCompleted = TRUE;
							// We've gone over 1200F, only 1 use is permitted and this is it
							pTCInfo->pTCNV->usesleft = 0;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
										strDbgMsg = QString::asprintf(_T("UpdateUsage::pTCInfo->pTCNV->usesleft= 0"));
										LogDebugMessage(strDbgMsg);
									#endif
						}
					}
				}
			} else if (pTCInfo->pSensorConfig->LoadTC == TRUE) {
				// This is a Non Expendable base Load TC - Usage algorithm for HLD section 2.4.9.6
				if (pTCInfo->pTCNV->runCompleted == FALSE) {
					if (pTCInfo->pTCNV->peakTempReached >= GetUsageLimitTemp(TC_TEMPS_EXP_BASE_2300F)) {
						// Peak exceeded test	
						if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_EXP_BASE_2300F)
								&& newReading <= GetUsageHystTemp(TC_TEMPS_EXP_BASE_2300F)) // prasad - added this condition to complete cycle and then tc expire.
										{
							pTCInfo->pTCNV->runCompleted = TRUE;
							//pTCInfo->pTCNV->usesleft = TC_NONEXP_BASE_LOADTC_MAXUSE -1;
							pTCInfo->pTCNV->usesleft = 0;
							pTCInfo->pTCNV->usesCap = TC_NONEXP_BASE_LOADTC_OVER_2300F;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
										strDbgMsg = QString::asprintf(_T("UpdateUsage::pTCInfo->pTCNV->usesleft= 0"));
										LogDebugMessage(strDbgMsg);
									#endif
						}
					} else if (pTCInfo->pTCNV->peakTempReached >= GetUsageLimitTemp(TC_TEMPS_EXP_BASE_2200F)) {
						// We have gone over 2200F or 1205C on this run, register when we drop below( including hysteresis )
						if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_EXP_BASE_2200F)
								&& newReading <= GetUsageHystTemp(TC_TEMPS_EXP_BASE_2200F)) {
							// We have gone above the 2200F mark and dropped back down below 2200F minus hysteresis, thats deemed to be a use
							// at that temperature
							pTCInfo->pTCNV->runCompleted = TRUE;
							// Has this temperature range been hit before
							if (pTCInfo->pTCNV->usesCap > TC_NONEXP_BASE_LOADTC_2200_2300F) {
								// No, so adjust usage depending on new range
								pTCInfo->pTCNV->usesCap = TC_NONEXP_BASE_LOADTC_2200_2300F;		// Register range hit
								pTCInfo->pTCNV->dayLimit = TC_NONEXP_BASE_LOADTC_DAYS_BELOW2300F;
							}
							// Register single use at this temperature range
							pTCInfo->pTCNV->usesleft--;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
										strDbgMsg = QString::asprintf(_T("P2:usesleft dec %d"), pTCInfo->pTCNV->usesleft);
										LogDebugMessage(strDbgMsg);
								  #endif
						}
					} else if (pTCInfo->pTCNV->peakTempReached > GetUsageLimitTemp(TC_TEMPS_EXP_BASE_1800F)) {
						// We have gone over 1800F or 980C on this run, register when we drop below( including hysteresis )
						if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_EXP_BASE_1800F)
								&& newReading <= GetUsageHystTemp(TC_TEMPS_EXP_BASE_1800F)) {
							// We have gone above the 1800F mark and dropped back down below 1800F minus hysteresis, thats deemed to be a use
							// at that temperature
							pTCInfo->pTCNV->runCompleted = TRUE;
							// Has this temperature range been hit before
							if (pTCInfo->pTCNV->usesCap > TC_NONEXP_BASE_LOADTC_1800_2200F) {
								// No, so adjust usage depending on new range
								pTCInfo->pTCNV->usesCap = TC_NONEXP_BASE_LOADTC_1800_2200F;		// Register range hit
								pTCInfo->pTCNV->dayLimit = TC_NONEXP_BASE_LOADTC_DAYS_BELOW2200F;
							}
							// Register single use at this temperature range
							pTCInfo->pTCNV->usesleft--;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
										strDbgMsg = QString::asprintf(_T("P3:usesleft dec %d"), pTCInfo->pTCNV->usesleft);
										LogDebugMessage(strDbgMsg);
									#endif
						}
					} else if (pTCInfo->pTCNV->peakTempReached >= GetUsageLimitTemp(TC_TEMPS_EXP_BASE_1200F)) {
						// We have gone over 1200F or 650C on this run, register when we drop below( including hysteresis )
						if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_EXP_BASE_1200F)
								&& newReading <= GetUsageHystTemp(TC_TEMPS_EXP_BASE_1200F)) {
							// We have gone above the 1200F mark and dropped back down below 1200F minus hysteresis, thats deemed to be a use
							// at that temperature
							pTCInfo->pTCNV->runCompleted = TRUE;
							// Has this temperature range been hit before
							if (pTCInfo->pTCNV->usesCap > TC_NONEXP_BASE_LOADTC_1200_1800F) {
								// No, so adjust usage depending on new range
								pTCInfo->pTCNV->usesCap = TC_NONEXP_BASE_LOADTC_1200_1800F;		// Register range hit
							}
							// Register single use at this temperature range
							pTCInfo->pTCNV->usesleft--;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
										strDbgMsg = QString::asprintf(_T("P4:usesleft dec %d"), pTCInfo->pTCNV->usesleft);
										LogDebugMessage(strDbgMsg);
									#endif
						}
					} else if (pTCInfo->pTCNV->peakTempReached >= GetUsageLimitTemp(TC_TEMPS_BASE_500F)) {
						// We have gone over 500F or 260C on this run, register when we drop below( including hysteresis )
						if (pTCInfo->pTCNV->lastTempRecorded > GetUsageHystTemp(TC_TEMPS_BASE_500F)
								&& newReading <= GetUsageHystTemp(TC_TEMPS_BASE_500F)) {
							// We have gone above the 500F mark and dropped back down below 500F minus hysteresis, thats deemed to be a use
							// at that temperature
							pTCInfo->pTCNV->runCompleted = TRUE;
							// Has this temperature range been hit before
							if (pTCInfo->pTCNV->usesCap > TC_NONEXP_BASE_LOADTC_500_1200F) {
								// No, so adjust usage depending on new range
								pTCInfo->pTCNV->usesCap = TC_NONEXP_BASE_LOADTC_500_1200F;		// Register range hit
							}
							// Register single use at this temperature range
							pTCInfo->pTCNV->usesleft--;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
										strDbgMsg = QString::asprintf(_T("P5:usesleft dec %d"), pTCInfo->pTCNV->usesleft);
										LogDebugMessage(strDbgMsg);
									#endif
						}
					}
				}
			}
			break;
		}
		}
		// Update the last reading and peak reading if current reading is greater
		pTCInfo->pTCNV->lastTempRecorded = newReading;
		if (newReading > pTCInfo->pTCNV->peakTempReached) {
			pTCInfo->pTCNV->peakTempReached = newReading;
		}
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
			strDbgMsg = QString::asprintf(_T("Update the last reading- %f & lastState %d"), pTCInfo->pTCNV->lastTempRecorded, pTCInfo->pTCNV->lastState);
			LogDebugMessage(strDbgMsg);
		#endif
		// Is the TC currently in a below state - i.e. not in use
		if (pTCInfo->pTCNV->lastState == T_TCUSAGE_STATE_BELOW) {
			// Yes, check the current TC value with the high temperature value
			if (newReading > pSYSTEM_INFO->GetLocalTempFromDegC(pTCInfo->pFurnace->HighUseTemp)) {
				// TC is now above high value and is deemed to be "in use"
				pTCInfo->pTCNV->lastState = T_TCUSAGE_STATE_ABOVE;
			}
		}
		// If the TC currently in the above state - i.e. in use
		else if (pTCInfo->pTCNV->lastState == T_TCUSAGE_STATE_ABOVE) {
			// Yes, check the current TC value with the low temperature value
			if (newReading < pSYSTEM_INFO->GetLocalTempFromDegC(pTCInfo->pFurnace->LowUseTemp)) {
				// TC is now below low value and that completes one furnace cycle
				// Specific usage logic for the TC might have overriden this run.
				//if( pTCInfo->pTCNV->runCompleted == FALSE ) //Change related to Rev D, Not req for Rev F
				//{
				//	pTCInfo->pTCNV->usesleft--;								// decrement the default usage, as custom loguic has not overriden this
				//}
				pTCInfo->pTCNV->lastState = T_TCUSAGE_STATE_BELOW;			// Mark as back below the threshold
				pTCInfo->pTCNV->runCompleted = FALSE;
				pTCInfo->pTCNV->lastTempRecorded = 0;
				pTCInfo->pTCNV->peakTempReached = 0;
				usageUpdate = TRUE;											// Flag a usage update
			}
		}
		// Set uses status based on uses left
		int NumUsesleft = GetUsesleft(pTCInfo);
		if (NumUsesleft <= 0) {
			pTCInfo->usesStatus = TC_STATUS_EXPIRED;				// no uses left expire
		} else if (NumUsesleft < GetExpiryWarningLimitUses()) {
			pTCInfo->usesStatus = TC_STATUS_WARNING;				// limited uses left , warn user
		} else {
			pTCInfo->usesStatus = TC_STATUS_GOOD;					// TC ok for uses left
		}
		// Update days left only if it is being tracked
		if (pTCInfo->daysStatus != TC_STATUS_NOT_TRACKED) {
			// Update days left logic
			long daysInUse = GetTCDaysInUse(pTCInfo);
			pTCInfo->daysleft = pTCInfo->pTCNV->dayLimit - daysInUse;
			// Update days left status
			if (pTCInfo->daysleft < 0) {
				pTCInfo->daysStatus = TC_STATUS_EXPIRED;			// TC has no days left and has expired
			} else if (pTCInfo->daysleft < GetExpiryWarningUseLimitDays()) {
				pTCInfo->daysStatus = TC_STATUS_WARNING;			// Tc is within 2 weeks, warn user
			} else {
				pTCInfo->daysStatus = TC_STATUS_GOOD;				// TC over 2 weeks usage left, OK
			}
		}
		// Check for an changes
		if (prevUsesleft != pTCInfo->pTCNV->usesleft || prevUsesStatus != pTCInfo->usesStatus
				|| prevDaysStatus != pTCInfo->daysStatus || prevDaysleft != pTCInfo->daysleft) {
			usageUpdate = TRUE;		// Something updated, indicate
			pTCInfo->updateMe = TRUE;
			// If a valid update status post inforation to message list
			if (prevUsesStatus != pTCInfo->usesStatus && m_FirstIn != TRUE) {
				PostUsesStatusChange(pTCInfo);
			}
			// If a valid update status post inforation to message list
			if (prevDaysStatus != pTCInfo->daysStatus && m_FirstIn != TRUE) {
				PostDaysStatusChange(pTCInfo);
			}
		}
	}
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
	strDbgMsg = QString::asprintf(_T("UpdateUsage::usageUpdate %d"), usageUpdate);
		LogDebugMessage(strDbgMsg);
	#endif
	return usageUpdate;
}
//****************************************************************************
/// Determine the category of the TC return type TC_CATEGORY
///
/// @param[in]	pTCInfo - pointer to TC info to determine category for.
/// @param[out]	CalTrackValid - TRUE if TC is valid for calibration tracking, otherwise FALSE for not valid
/// @param[out]	UsageTrackValid - TRUE if TC is valid for USage tracking, otherwise FALSE for not valid
///
/// @return TC_CATEGORY type category of TC
//****************************************************************************
TC_CATEGORY CAMS2750TCStatusMgr::GetTCCategory(T_PTC_INFO pTCInfo, BOOL &CalTrackValid, BOOL &UsageTrackValid) {
	TC_CATEGORY retVal = TC_CATEGORY_NONE;
	// Get the metal Type
	CAMS2750TCStatusMgr::T_AMS2750_TC_METALS metal = GetSensorMetalType(pTCInfo->TCIndex);
	// Is the TC a noble metal?
	if (metal == NOBLE_METAL) {
		// Yes, assign category
		retVal = TC_CATEGORY_NOBLE_RSB;
	}
	// Otherwise is it a verified Base metal?
	else if (metal == BASE_METAL) {
		// Yes, is it expendable or non-expendable
		if (pTCInfo->pSensorConfig->Type == TC_IS_EXPENDABLE) {
			// It's an expendable base metal
			retVal = TC_CATEGORY_BASE_EXP_KJTNEM;
		} else {
			// It's a non-expendable base metal
			retVal = TC_CATEGORY_BASE_NONEXP_KJTNEM;
		}
	}
	CalTrackValid = FALSE;
	UsageTrackValid = FALSE;
	pTCInfo->daysStatus = TC_STATUS_NOT_TRACKED;// Only selective TC are allowed to be days limited even though they are usage tracked
	if (pTCInfo->pSensorConfig->TUSTC == TRUE) {
		// Calibration and Usage tracking permissions for a TUS TC
		switch (retVal) {
		case TC_CATEGORY_NOBLE_RSB: {
			CalTrackValid = TRUE;
			UsageTrackValid = FALSE;
			break;
		}
		case TC_CATEGORY_BASE_EXP_KJTNEM: {
			CalTrackValid = FALSE;
			UsageTrackValid = TRUE;
			pTCInfo->daysStatus = TC_STATUS_GOOD;
			break;
		}
		case TC_CATEGORY_BASE_NONEXP_KJTNEM: {
			CalTrackValid = TRUE;
			if (pTCInfo->pAIConfig->TC.SelectedTC == AI_THERMO_RANGE_T) {
				CalTrackValid = FALSE;		// Only type T's are not tracked
			} else {
				CalTrackValid = TRUE;
			}
			UsageTrackValid = TRUE;
			pTCInfo->daysStatus = TC_STATUS_GOOD;		// Usage limit of 3 years
			break;
		}
		}
	} else if (pTCInfo->pSensorConfig->LoadTC == TRUE) {
		// Calibration and Usage tracking permissions for a Process Load TC
		switch (retVal) {
		case TC_CATEGORY_NOBLE_RSB: {
			CalTrackValid = TRUE;
			UsageTrackValid = FALSE;
			break;
		}
		case TC_CATEGORY_BASE_EXP_KJTNEM: {
			CalTrackValid = FALSE;
			UsageTrackValid = TRUE;
			pTCInfo->daysStatus = TC_STATUS_GOOD; //AMS2750 - E, Standard - Making Expendable TC usage, also need to be considered to 90 days.
			break;
		}
		case TC_CATEGORY_BASE_NONEXP_KJTNEM: {
			CalTrackValid = FALSE;
			UsageTrackValid = TRUE;
			pTCInfo->daysStatus = TC_STATUS_GOOD;		// Usage limit of 90/30 days deopending on temp cycle
			break;
		}
		}
	} else {
		// Calibration and Usage tracking permissions for a Process recording, monitoring, control TC
		switch (retVal) {
		case TC_CATEGORY_NOBLE_RSB: {
			CalTrackValid = FALSE;
			UsageTrackValid = FALSE;
			break;
		}
		case TC_CATEGORY_BASE_EXP_KJTNEM: {
			CalTrackValid = FALSE;
			UsageTrackValid = TRUE;
			break;
		}
		case TC_CATEGORY_BASE_NONEXP_KJTNEM: {
			CalTrackValid = FALSE;
			UsageTrackValid = FALSE;
			break;
		}
		}
	}
	return retVal;
}
//****************************************************************************
///
/// Method that indentifies if a TC is being monitor for AMS2750 purposes (i.e. usage or
/// calibration tracking)
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
/// @param[in]			bool &rbIsTC - indicates if a TC (true) or RT (false)
///
/// @return true if the TC is being tracked (i.e. usage or calibration date)
///
//****************************************************************************
const bool CAMS2750TCStatusMgr::IsMonitoredTC(const USHORT usINSTANCE_NO, bool &rbIsTC) const {
	bool bMonitored = false;
	if (m_pTCbyAI[usINSTANCE_NO] != NULL) {
		if (m_pTCbyAI[usINSTANCE_NO]->trackCal == TRUE || m_pTCbyAI[usINSTANCE_NO]->trackUsage == TRUE) {
			bMonitored = TRUE;
		}
		rbIsTC = m_pTCbyAI[usINSTANCE_NO]->pAIConfig->Type == AI_CHANNEL_TYPE_TC;
	}
	return bMonitored;
}
//****************************************************************************
///
/// Method that determines the sensor (TC/RT) metal type
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC/RT instance number
///
/// @return true if the TC/RT is being tracked (i.e. usage or calibration date)
///
//****************************************************************************
const CAMS2750TCStatusMgr::T_AMS2750_TC_METALS CAMS2750TCStatusMgr::GetSensorMetalType(
		const USHORT usINSTANCE_NO) const {
	T_AMS2750_TC_METALS eTCMetalType = NOT_A_TC;
	// get pointer to the configuration data
	CIOSetupConfig *pkIOConfig = pSETUP->GetIOSetupConfig();
	T_PAICHANNEL ptTCData = pkIOConfig->GetAnalogueInput(usINSTANCE_NO, CONFIG_COMMITTED);
	if (ptTCData != NULL) {
		if (ptTCData->Type == AI_CHANNEL_TYPE_TC) {
			// get the TC information
			if ((ptTCData->TC.SelectedTC == AI_THERMO_RANGE_K) || (ptTCData->TC.SelectedTC == AI_THERMO_RANGE_J)
					|| (ptTCData->TC.SelectedTC == AI_THERMO_RANGE_T) || (ptTCData->TC.SelectedTC == AI_THERMO_RANGE_N)
					|| (ptTCData->TC.SelectedTC == AI_THERMO_RANGE_E)
					|| (ptTCData->TC.SelectedTC == AI_THERMO_RANGE_M)) {
				eTCMetalType = BASE_METAL;
			} else if ((ptTCData->TC.SelectedTC == AI_THERMO_RANGE_R) || (ptTCData->TC.SelectedTC == AI_THERMO_RANGE_S)
					|| (ptTCData->TC.SelectedTC == AI_THERMO_RANGE_B)) {
				eTCMetalType = NOBLE_METAL;
			} else {
				eTCMetalType = UNKNOWN_METAL;
			}
		} else if (ptTCData->Type == AI_CHANNEL_TYPE_RT) {
			if (CAMS2750TUSMgr::IsNobleMetalRT(ptTCData->RT.SelectedRT)) {
				eTCMetalType = NOBLE_METAL;
			} else {
				eTCMetalType = UNKNOWN_METAL;
			}
		} else {
			eTCMetalType = UNKNOWN_METAL;
		}
	}
	return eTCMetalType;
}
//****************************************************************************
/// Method that gets the uses left for a TC expiry
///
/// @param[in]	pTCInfo - pointer to T_PTC_INFO of TC to calulate uses for
///
/// @return number of uses remaining
//****************************************************************************
int CAMS2750TCStatusMgr::GetUsesleft(T_PTC_INFO pTCInfo) {
	int lUsesleft = pTCInfo->pTCNV->usesleft;
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
	strDbgMsg = QString::asprintf(_T("P1: lUsesleft %d"), lUsesleft);
	LogDebugMessage(strDbgMsg);
#endif
	// If there is a usage cap, calculate
	if (pTCInfo->pTCNV->usesCap != TC_USESCAP_RESET) {
		USHORT originalUsesLimit = 0;
		switch (pTCInfo->category) {
		case TC_CATEGORY_BASE_EXP_KJTNEM: {
			originalUsesLimit = TC_EXP_BASE_MAXUSE;
			break;
		}
		case TC_CATEGORY_BASE_NONEXP_KJTNEM: {
			if (pTCInfo->pSensorConfig->TUSTC == TRUE) {
				originalUsesLimit = TC_NONEXP_BASE_TUSTC_MAXUSE;
			} else if (pTCInfo->pSensorConfig->LoadTC == TRUE) {
				originalUsesLimit = TC_NONEXP_BASE_LOADTC_BELOW_500F_MAXUSE;
			}
			break;
		}
		}
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
			strDbgMsg = QString::asprintf(_T("P2: lUsesleft %d"), lUsesleft);
			LogDebugMessage(strDbgMsg);
		#endif
		lUsesleft = pTCInfo->pTCNV->usesCap - (originalUsesLimit - lUsesleft);
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
			strDbgMsg = QString::asprintf(_T("pTCInfo->pTCNV->usesCap %d, originalUsesLimit %d, lUsesleft %d"), pTCInfo->pTCNV->usesCap, originalUsesLimit, lUsesleft);
			LogDebugMessage(strDbgMsg);
		#endif
		if (lUsesleft < 0) {
			// cap it to stop wierd negative numbers in the status output
			lUsesleft = 0;
		}
	}
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
	strDbgMsg = QString::asprintf(_T("P3: lUsesleft %d"), lUsesleft);
	LogDebugMessage(strDbgMsg);
#endif
	return lUsesleft;
}
//****************************************************************************
///
/// Method that gets the uses left tracking info
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
/// @param[out]	QString   &rstrUsesleftInfo - The usage information
///
/// @return The usage info status
///
//****************************************************************************
T_2750TC_STATUS CAMS2750TCStatusMgr::GetUsesleftInfo(const USHORT usINSTANCE_NO, QString &rstrUsesleftInfo) {
	T_2750TC_STATUS status = TC_STATUS_NOT_TRACKED;
	T_PTC_INFO pTCInfo = m_pTCbyAI[usINSTANCE_NO];
	if (pTCInfo != NULL) {
		if (pTCInfo->trackUsage) {
			status = pTCInfo->usesStatus;
			int usesleft = GetUsesleft(pTCInfo);
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
				strDbgMsg = QString::asprintf(_T("usINSTANCE_NO %d usesleft %d & status %d"),usINSTANCE_NO, usesleft, status);
				LogDebugMessage(strDbgMsg);
			#endif
			// put an arbitrary limit of anything over 500 is effectively unlimited (less risk than intefering with the logic
			// by going from not tracked to tracked uses)
			if (usesleft < 500) {
				rstrUsesleftInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_USES_LEFT_TEXT, usesleft);
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
                    strDbgMsg = QString::asprintf(_T("IDS_AMS2750_TC_STATUS_DLG_USES_LEFT_TEXT usesleft %d"), usesleft);
					LogDebugMessage(strDbgMsg);
				#endif
			} else {
				QString strNA("");
				strNA = QWidget::tr("NA");
				QString strUsesleft("");
				rstrUsesleftInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_USES_LEFT_TEXT, 0);
				rstrUsesleftInfo.replace("0", strNA);
			}
		} else {
			// not being tracked
			QString strNA("");
			strNA = QWidget::tr("NA");
			QString strUsesleft("");
			rstrUsesleftInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_USES_LEFT_TEXT, 0);
			rstrUsesleftInfo.replace("0", strNA);
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
				strDbgMsg = QString::asprintf(_T("Not being tracked."));
				LogDebugMessage(strDbgMsg);
			#endif
		}
	}
	return status;
}
//****************************************************************************
///
/// Method that gets the days left tracking info
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
/// @param[out]	QString   &rstrDaysleftInfo - The usage information
///
/// @return The days left info status
///
//****************************************************************************
T_2750TC_STATUS CAMS2750TCStatusMgr::GetDaysleftInfo(const USHORT usINSTANCE_NO, QString &rstrDaysleftInfo) {
	T_2750TC_STATUS status = TC_STATUS_NOT_TRACKED;
	T_PTC_INFO pTCInfo = m_pTCbyAI[usINSTANCE_NO];
	if (pTCInfo != NULL) {
		if (pTCInfo->trackUsage) {
			status = pTCInfo->daysStatus;
			rstrDaysleftInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_DAYS_LEFT_TEXT, pTCInfo->daysleft);
			// check if the days are tracked for this TC type
			if ((status == TC_STATUS_NOT_TRACKED) && (pTCInfo->daysleft == 0)) {
				QString strNA("");
				strNA = QWidget::tr("NA");
				rstrDaysleftInfo.replace("0", strNA);
			}
		} else {
			// not being tracked
			QString strNA("");
			strNA = QWidget::tr("NA");
			rstrDaysleftInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_DAYS_LEFT_TEXT, 0);
			rstrDaysleftInfo.replace("0", strNA);
		}
	}
	return status;
}
//****************************************************************************
/// Method that returns the number of days remaining until the calibration date
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
///
/// @return The number of days until the due calibration date - could be negative
//****************************************************************************
const long CAMS2750TCStatusMgr::GetTCDaysUntilCalExpiry(const USHORT usINSTANCE_NO) {
	long lDaysRemaining = 0;
	// If valid TC being tracked get the days remaining
	if (m_pTCbyAI[usINSTANCE_NO] != NULL) {
		lDaysRemaining = m_pTCbyAI[usINSTANCE_NO]->daysRemainingTilCal;
	}
	return lDaysRemaining;
}
//****************************************************************************
///
/// Method that returns the number of days in use since installation
///
/// @param[in]	pTCInfo - pointer to TC info to get days for
///
/// @return The number of days in use since calibration
///
//****************************************************************************
const long CAMS2750TCStatusMgr::GetTCDaysInUse(T_PTC_INFO pTCInfo) const {
	long lDaysInUse = 0;
	// get the next calibration date
	CTVtime kInstallationDate(static_cast<LONGLONG>(pTCInfo->pSensorConfig->DateRenewed) * USEC_IN_A_SEC);
	// deduct the time and determine the difference in days
	kInstallationDate = pSYSTIMER->GetCurrentProcessTimeInMicroSec() - kInstallationDate.GetMicroSecs();
	// check if the time is negative
	if (kInstallationDate.GetSeconds() < 0) {
		LONGLONG roundingAdjust = static_cast<LONGLONG>(SEC_TO_USEC(static_cast<LONGLONG>(SECONDS_IN_A_DAY - 1)));
		kInstallationDate -= roundingAdjust;
	}
	// divide by the seconds in a day an we have our number of days
	lDaysInUse = SEC_TO_DAY(kInstallationDate.GetSeconds());
	return lDaysInUse;
}
//****************************************************************************
///
/// Method that returns the last renewal date as a string
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
///
/// @return The last renewal date as a string
///
//****************************************************************************
const QString CAMS2750TCStatusMgr::GetLastRenewalDate(const USHORT usINSTANCE_NO) const {
	QString strDate("");
	CTVtime kInstalledOnDate(static_cast<LONGLONG>(m_ptSensorInfo->Sensors[usINSTANCE_NO].DateRenewed) * USEC_IN_A_SEC);
	kInstalledOnDate.DateAsString(strDate);
	return strDate;
}
//****************************************************************************
///
/// Method that returns the calibration expiry date as a string
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
///
/// @return The next calibration date as a string
///
//****************************************************************************
const QString CAMS2750TCStatusMgr::GetCalibrationExpiryDate(const USHORT usINSTANCE_NO) const {
	QString strDate("");
	CTVtime kNextCalDate(static_cast<LONGLONG>(m_ptSensorInfo->Sensors[usINSTANCE_NO].NextCalibDate) * USEC_IN_A_SEC);
	kNextCalDate.DateAsString(strDate);
	return strDate;
}
//****************************************************************************
///
/// Method that returns the number if calibration is being tracked
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
///
/// @return The number of uses remaining - could be negative
///
//****************************************************************************
BOOL CAMS2750TCStatusMgr::IsCalTracking(const USHORT usINSTANCE_NO) {
	BOOL trackCal = FALSE;
	if (m_pTCbyAI[usINSTANCE_NO] != NULL) {
		trackCal = m_pTCbyAI[usINSTANCE_NO]->trackCal;
	}
	return trackCal;
}
//****************************************************************************
///
/// Method that gets the calibration info - this could be a date until next cal due or a
/// number of days in use
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
/// @param[out]	QString   &rstrCalInfo - The cal information
///
/// @return The cal info status
///
//****************************************************************************
T_2750TC_STATUS CAMS2750TCStatusMgr::GetCalInfo(const USHORT usINSTANCE_NO, QString &rstrCalInfo) {
	T_2750TC_STATUS status = TC_STATUS_NOT_TRACKED;
	T_PTC_INFO pTCInfo = m_pTCbyAI[usINSTANCE_NO];
	if (pTCInfo != NULL) {
		const T_DEV_TYPE eDEVICE_TYPE = pDEVICE_INFO->GetDeviceType();
		status = pTCInfo->calStatus;
		// determine whether this TC has a cal expiry date
		if (pTCInfo->trackCal == TRUE) {
			// check if the cal date is seriously out-of-date in which case replace the number of days with 'NA'
			if (pTCInfo->calStatus == TC_STATUS_NOT_TRACKED) {
				QString strNA("");
				strNA = QWidget::tr("NA");
				// check the recorder type as we are short of real-estate on a QX/QXe
				if (eDEVICE_TYPE == DEV_PC_MULTI || eDEVICE_TYPE == DEV_ARISTOS_MULTIPLUS
						|| eDEVICE_TYPE == DEV_SCR_MINITREND) {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_LINE7_TEXT, 0);
				} else {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_LINE7_SHORT_QX_TEXT, 0);
				}
				rstrCalInfo.replace("0", strNA);
			} else {
				// check the recorder type as we are short of real-estate on a QX/QXe
				if (eDEVICE_TYPE == DEV_PC_MULTI || eDEVICE_TYPE == DEV_ARISTOS_MULTIPLUS
						|| eDEVICE_TYPE == DEV_SCR_MINITREND) {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_LINE7_TEXT, pTCInfo->daysRemainingTilCal);
				} else {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_LINE7_SHORT_QX_TEXT,
							pTCInfo->daysRemainingTilCal);
				}
			}
		} else {
			const int iDAYS_IN_USE = GetTCDaysInUse(pTCInfo);
			// check if the renewal date is seriously out-of-date in which case replace the number of days with 'NA'
			if (iDAYS_IN_USE > 2000) {
				QString strNA("");
				strNA = QWidget::tr("NA");
				// check the recorder type as we are short of real-estate on a QX/QXe
				if (eDEVICE_TYPE == DEV_PC_MULTI || eDEVICE_TYPE == DEV_ARISTOS_MULTIPLUS
						|| eDEVICE_TYPE == DEV_SCR_MINITREND) {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_DAYS_IN_USE_TEXT, 0);
				} else {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_DAYS_IN_USE_SHORT_QX_TEXT, 0);
				}
				rstrCalInfo.replace("0", strNA);
			} else {
				// check the recorder type as we are short of real-estate on a QX/QXe
				if (eDEVICE_TYPE == DEV_PC_MULTI || eDEVICE_TYPE == DEV_ARISTOS_MULTIPLUS
						|| eDEVICE_TYPE == DEV_SCR_MINITREND) {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_DAYS_IN_USE_TEXT, iDAYS_IN_USE);
				} else {
					rstrCalInfo = QString::asprintf(IDS_AMS2750_TC_STATUS_DLG_DAYS_IN_USE_SHORT_QX_TEXT, iDAYS_IN_USE);
				}
			}
		}
	}
	return status;
}
//****************************************************************************
///
/// Method that returns the sensor name as a string
///
/// @param[in]	const USHORT usINSTANCE_NO - The zero-based TC instance number
///
/// @return The sensor name as a string
///
//****************************************************************************
const QString CAMS2750TCStatusMgr::GetSensorName(const USHORT usINSTANCE_NO) const {
	QString strSensorName("");
	CIOSetupConfig *pkIOConfig = pSETUP->GetIOSetupConfig();
	// get pointers to the configuration data
	T_PAICHANNEL ptTCData = pkIOConfig->GetAnalogueInput(usINSTANCE_NO, CONFIG_COMMITTED);
	strSensorName = QString::fromWCharArray(ptTCData->Label);
	return strSensorName;
}
//****************************************************************************
///
/// Method that determines if there are any TC's in an expired state
/// 
/// @param[in]		const USHORT usINSTANCE_NO - The zero-based instance no to check (if not all)
/// @param[in]		const bool bALL - Flag indicating if we are to check all TCs
///
/// @return True if any TCs are in an expired state
///
//****************************************************************************
const bool CAMS2750TCStatusMgr::TCInExpiredState(const USHORT usINSTANCE_NO /* = 0 */,
		const bool bALL /* = true */) const {
	bool retVal = FALSE;
	if (bALL) {
		// loop round all the possible analogue inputs
		for (int iCount = 0; iCount < MAX_ANALOGUE_IN; iCount++) {
			if (m_pTCbyAI[iCount] != NULL) {
				if ((m_pTCbyAI[iCount]->calStatus == TC_STATUS_EXPIRED)
						|| (m_pTCbyAI[iCount]->usesStatus == TC_STATUS_EXPIRED)
						|| (m_pTCbyAI[iCount]->daysStatus == TC_STATUS_EXPIRED)) {
					retVal = TRUE;
					break;
				}
			}
		}
	} else {
		if (m_pTCbyAI[usINSTANCE_NO] != NULL) {
			if ((m_pTCbyAI[usINSTANCE_NO]->calStatus == TC_STATUS_EXPIRED)
					|| (m_pTCbyAI[usINSTANCE_NO]->usesStatus == TC_STATUS_EXPIRED)
					|| (m_pTCbyAI[usINSTANCE_NO]->daysStatus == TC_STATUS_EXPIRED)) {
				retVal = TRUE;
			}
		}
	}
	return retVal;
}
//****************************************************************************
///
/// Method that determines if there are any TC's in a warning state or greater (i.e. in an error state)
/// 
/// @param[in]		const USHORT usINSTANCE_NO - The zero-based instance no to check (if not all)
/// @param[in]		const bool bALL - Flag indicating if we are to check all TCs
///
/// @return True if any TCs are in an warning state
///
//****************************************************************************
const bool CAMS2750TCStatusMgr::TCInWarningState(const USHORT usINSTANCE_NO /* = 0 */,
		const bool bALL /* = true */) const {
	bool retVal = FALSE;
	if (bALL) {
		// loop round all the possible analogue inputs
		for (int iCount = 0; iCount < MAX_ANALOGUE_IN; iCount++) {
			if (m_pTCbyAI[iCount] != NULL) {
				if ((m_pTCbyAI[iCount]->calStatus == TC_STATUS_WARNING)
						|| (m_pTCbyAI[iCount]->usesStatus == TC_STATUS_WARNING)
						|| (m_pTCbyAI[iCount]->daysStatus == TC_STATUS_WARNING)) {
					retVal = TRUE;
					break;
				}
			}
		}
	} else {
		if (m_pTCbyAI[usINSTANCE_NO] != NULL) {
			if ((m_pTCbyAI[usINSTANCE_NO]->calStatus == TC_STATUS_WARNING)
					|| (m_pTCbyAI[usINSTANCE_NO]->usesStatus == TC_STATUS_WARNING)
					|| (m_pTCbyAI[usINSTANCE_NO]->daysStatus == TC_STATUS_WARNING)) {
				retVal = TRUE;
			}
		}
	}
	return retVal;
}
//****************************************************************************
///
/// Method that determines if there are no TC's being tracked
/// 
/// @param[in]		const USHORT usINSTANCE_NO - The zero-based instance no to check (if not all)
/// @param[in]		const bool bALL - Flag indicating if we are to check all TCs
///
/// @return True if no TCs are being tracked
///
//****************************************************************************
const bool CAMS2750TCStatusMgr::NoTrackedTCs(const USHORT usINSTANCE_NO /* = 0 */, const bool bALL /* = true */) const {
	bool bTCsTracked = false;
	if (bALL) {
		if (m_numTCs > 0) {
			bTCsTracked = TRUE;
		}
	} else {
		if (m_pTCbyAI[usINSTANCE_NO] == NULL) {
			bTCsTracked = TRUE;
		}
	}
	return !bTCsTracked;
}
//****************************************************************************
/// Has a TC updated and screen needs to be refreshed?
/// 
/// @param[in]		usINSTANCE_NO - The zero-based instance no to check 
///
/// @return TRUE if update required, otherwise FALSE
//****************************************************************************
bool CAMS2750TCStatusMgr::IsTCUpdateRequired(USHORT usINSTANCE_NO) {
	BOOL updateReq = FALSE;
	if (m_pTCbyAI[usINSTANCE_NO] != NULL) {
		updateReq = m_pTCbyAI[usINSTANCE_NO]->updateMe;
		m_pTCbyAI[usINSTANCE_NO]->updateMe = FALSE;
	}
	return updateReq;
}
//****************************************************************************
/// Days sttatus has changed, post message to system messages
/// 
/// @return nothing
//****************************************************************************
void CAMS2750TCStatusMgr::PostDaysStatusChange(T_PTC_INFO pTCInfo) {
	QString statusMessage;
	if (pTCInfo->daysStatus == TC_STATUS_WARNING) {
		statusMessage = IDS_TC_STATUS_MGR_TC_USE_DAYS_LEFT_WARNING
				+ CAMS2750TUSMgr::buildSensorName(pTCInfo->TCIndex + 1, pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaTC_TIMER, eatWarning);
	} else if (pTCInfo->daysStatus == TC_STATUS_EXPIRED) {
		statusMessage = IDS_TC_STATUS_MGR_TC_USE_DAYS_LEFT_EXPIRED
				+ CAMS2750TUSMgr::buildSensorName(pTCInfo->TCIndex + 1, pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaTC_TIMER, eatExpired);
	}
}
//****************************************************************************
/// Uses status has changed, post message to system messages
/// 
/// @return nothing
//****************************************************************************
void CAMS2750TCStatusMgr::PostUsesStatusChange(T_PTC_INFO pTCInfo) {
	QString statusMessage;
	if (pTCInfo->usesStatus == TC_STATUS_WARNING) {
		statusMessage = IDS_TC_STATUS_MGR_TC_NO_OF_USES_WARNING
				+ CAMS2750TUSMgr::buildSensorName(pTCInfo->TCIndex + 1, pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaTC_TIMER, eatWarning);
	} else if (pTCInfo->usesStatus == TC_STATUS_EXPIRED) {
		statusMessage = IDS_TC_STATUS_MGR_TC_NO_OF_USES_EXPIRED
				+ CAMS2750TUSMgr::buildSensorName(pTCInfo->TCIndex + 1, pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaTC_TIMER, eatExpired);
	}
}
//****************************************************************************
/// Calibration status has changed, post message to system messages
/// 
/// @return nothing
//****************************************************************************
void CAMS2750TCStatusMgr::PostCalStatusChange(T_PTC_INFO pTCInfo) {
	QString statusMessage;
	if (pTCInfo->calStatus == TC_STATUS_WARNING) {
		statusMessage = IDS_TC_STATUS_MGR_TC_CAL_DUE_WARNING
				+ CAMS2750TUSMgr::buildSensorName(pTCInfo->TCIndex + 1, pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaTC_TIMER, eatWarning);
	} else if (pTCInfo->calStatus == TC_STATUS_EXPIRED) {
		statusMessage = IDS_TC_STATUS_MGR_TC_CAL_DUE_NOW
				+ CAMS2750TUSMgr::buildSensorName(pTCInfo->TCIndex + 1, pTCInfo->pAIConfig->Type == AI_CHANNEL_TYPE_TC);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaTC_TIMER, eatExpired);
	}
}
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
void CAMS2750TCStatusMgr::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
}
void CAMS2750TCStatusMgr::LogDebugMessage(QString   strDebugMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString   strDiagMsg;
		CTime startTime1 = CTime::GetCurrentTime();
		strDiagMsg = QString::asprintf(_T("AMS %s at- %d:%d:%d\r\n"), strDebugMsg, startTime1.GetHour(),startTime1.GetMinute(),startTime1.GetSecond());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

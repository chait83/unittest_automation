//************************************************************************************
// Module  AMS2750
// Filename  AMS2750ProcessCalFile.cpp
// Copyright GA Digital 2021
/// **********************************************************************************
/// @n Module: 	  AMS2750 file processing
/// @n Filename:  AMS2750ProcessCalFile.cpp
/// @n Description: Process information in Cal file for use in report 
///
// ***********************************************************************************
#include "AMS2750ProcessCalFile.h"
#include "V6globals.h"
//****************************************************************************************
/// Constructor
//****************************************************************************************
CAMS2750ProcessCalFile::CAMS2750ProcessCalFile() {
	m_pCalData = NULL;
}
//****************************************************************************************
/// API - Initialise the internal pointers to the Cal file in provided memory block
/// 
/// @param[in]	pFilePtr - pointer to block of memory containing the Cal file
///
/// @return		nothing
//****************************************************************************************
void CAMS2750ProcessCalFile::InitCalFile(void *pFilePtr) {
	m_pCalData = (T_P2750FILEHEADEROVERLAY) pFilePtr;		// Set the header structure to start of file
}
//****************************************************************************************
/// API - Validates the file within the memory block, running though all available structures 
/// checking the CRC's, if a structure is found to be corrupted then the type of structure
/// and it's instance number will be passed back.
/// 
/// @param[out]	&errStruct - reference to T_STRUCTURE_IDENT used to identify type of corrupted structure
/// @param[out]	&instance - reference to int used to identify the instance number of the corrupted structure
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_FILE_CORRUPT indicates corruption identified in structure on &errStruct and &instance
///					PF_OK file integrity ok, and can be used for further processing
//****************************************************************************************
T_C2750PROCESSFILE_RES CAMS2750ProcessCalFile::ValidateFile(T_STRUCTURE_IDENT &errStruct, int &instance) {
	T_C2750PROCESSFILE_RES retVal = PF_OK;
	// First check the CRC of the header
	if (CrcTest((UCHAR*) m_pCalData, sizeof(T_2750FILEHEADER)) == CRC_TEST_PASSED) {
		// Header CRC ok, Run though all available structures in list, check the CRC's
		for (int sIndex = 0; sIndex < m_pCalData->fh.numStructures; sIndex++) {
			// Check CRC's of structures in list. 
			if (CrcCalc((UCHAR*) m_pCalData + m_pCalData->structList[sIndex].startPos,
					m_pCalData->structList[sIndex].length) != m_pCalData->structList[sIndex].crc) {
				// CRC FAILED , Set information to show a structure in table is corrupted
				errStruct = (T_STRUCTURE_IDENT) m_pCalData->structList[sIndex].ident;
				instance = m_pCalData->structList[sIndex].instance;
				retVal = PF_FILE_CORRUPT;
				break;
			}
		}
	} else {
		// CRC FAILED, Set information to show header is corrupted
		errStruct = ST_2750FILEHEADER;		// Set an indication of the structure which has the problem.
		instance = 0;
		retVal = PF_FILE_CORRUPT;
	}
	return retVal;
}
//****************************************************************************************
/// API - Get a copy of the Cal file header
/// 
/// @param[out]	pCalHeader - pointer to a T_2750FILEHEADER structure to be populated with data from the file
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_FOUND - Cal file header ok and returned in pLogHeader
///					PF_STRUCTURE_NOT_FOUND - Cal file header not found, file invalid.
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES CAMS2750ProcessCalFile::GetCalHeader(T_P2750FILEHEADER pCalHeader) {
	T_C2750PROCESSFILE_RES retVal = PF_STRUCTURE_NOT_FOUND;
	if (m_pCalData != NULL) {
		// Cal file header available, copy into destination structure
		memcpy(pCalHeader, m_pCalData, sizeof(T_2750FILEHEADER));
		retVal = PF_STRUCTURE_FOUND;
	}
	return retVal;
}
//****************************************************************************************
/// API - geta copy of the general calibration structure (T_AMS2750GENCAL) from the Cal file
/// 
/// @param[out]	ptrGenCal - pointer to a T_AMS2750GENCAL structure to be populated with matching structure on file
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES CAMS2750ProcessCalFile::GetGeneralCalibration(T_PAMS2750GENCAL ptrGenCal) {
	return GetStruct(ST_AMSGENCALDATA, 0, ptrGenCal, sizeof(T_AMS2750GENCAL));
}
//****************************************************************************************
/// API - Get a copy of one of the sensor calibration result structures (T_SENSORCALDATA) from the Cal file 
/// 
/// @param[out]	ptrSensorCal - pointer to a T_SENSORCALDATA structure to be populated with matching structure on file
/// @param[in]	SensorID - number of the sensor, sensors available from 1 to 48
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES CAMS2750ProcessCalFile::GetSensorInputCalibrationResults(T_PSENSORINPUTCALDATA ptrSensorCal,
		int SensorID) {
	return GetStruct(ST_AMSSENSORINPUTCALDATA, SensorID, ptrSensorCal, sizeof(T_SENSORINPUTCALDATA));
}
//****************************************************************************************
/// indexOf the required structure within the the structure list in the file, providing the index
/// if successfully found
/// 
/// @param[in]	sType - T_STRUCTURE_IDENT type of structure required
/// @param[in]	sInstance - Instance of structure required
/// @param[out]	&theIndex - reference of the index of the structure in the list if found
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND if the requested structure is not located in the list
///					PF_STRUCTURE_FOUND if structure found with &theIndex conatining index
//****************************************************************************************
T_C2750PROCESSFILE_RES CAMS2750ProcessCalFile::indexOfStruct(T_STRUCTURE_IDENT sType, int sInstance, int &theIndex) {
	theIndex = 0;
	T_C2750PROCESSFILE_RES retVal = PF_STRUCTURE_NOT_FOUND;
	// Run through all structures in list
	for (int sIndex = 0; sIndex < m_pCalData->fh.numStructures; sIndex++) {
		// Test both type and instance with current entry in structure table 
		if (m_pCalData->structList[sIndex].ident == sType && m_pCalData->structList[sIndex].instance == sInstance) {
			// Exact Match is found, set the index and stop searching
			retVal = PF_STRUCTURE_FOUND;
			theIndex = sIndex;
			break;
		}
	}
	return retVal;
}
//****************************************************************************************
/// Generic get structure method, will retrive a structure from the file depending on type and instance and copy it
/// into the container passed in. The method will take care of different structure sizes if newer or older structures
/// are being accessed to that built into the code. There will be a aprtial copy if destination structure is smaller
/// or if destination is larger it will copy akll of source and pad destination with zeros.
/// 
/// @param[in]	sType - T_STRUCTURE_IDENT type of structure required
/// @param[in]	sInstance - Instance of structure required
/// @param[out]	*structData - pointer to a destination structure
/// @param[in]	structSize - the size of the destination structure
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES CAMS2750ProcessCalFile::GetStruct(T_STRUCTURE_IDENT sType, int sInstance, void *structData,
		int structSize) {
	T_C2750PROCESSFILE_RES retVal = PF_STRUCTURE_NOT_FOUND;
	int index = 0;
	retVal = indexOfStruct(sType, sInstance, index);
	if (retVal == PF_STRUCTURE_FOUND) {
		T_PTUSSTRUCTIDENT ptrIndex = &m_pCalData->structList[index];
		int copyLen = ptrIndex->length;
		// test for any size difference within structures
		if (ptrIndex->length < structSize) {
			// the source structure(file) is smaller then the current structure built in codebase, so this would
			// inducate that the source structure is older, so we return all we can and set the rest of the struct to 0
			memset(structData, 0, structSize);
			retVal = PF_STRUCTURE_TOO_SMALL;
		} else if (ptrIndex->length > structSize) {
			// the source structure(file) is bigger then the current structure built in codebase, this would indicate that 
			// the source structure is newer, so we will truncate the source structure to fit in the destination.
			copyLen = structSize;// Set the copy length to struct size as previously it was set to larger source struct size
			retVal = PF_STRUCTURE_TOO_LARGE;
		}
		// Copy the source structure to the destination
		memcpy(structData, (UCHAR*) m_pCalData + ptrIndex->startPos, copyLen);
	}
	return retVal;
}
///****************************************************************************
///
/// Method that confirms the whether the loaded cal is empty
///
/// @returns true if the sensor cal is empty, false if not
///
///****************************************************************************
const bool CAMS2750ProcessCalFile::CalIsEmpty() {
	bool calIsEmpty = true;
	T_2750FILEHEADER tCalHeader;
	if (GetCalHeader(&tCalHeader) == PF_STRUCTURE_FOUND) {
		// check there is at least two structures (gen cal info and at least one sensor)
		if (tCalHeader.numStructures >= 2) {
			calIsEmpty = false;
		}
	}
	return calIsEmpty;
}
//****************************************************************************
///
/// Gets the internal cal file name
///
/// returns	the internal calibration file name
/// 
//****************************************************************************
QString CAMS2750ProcessCalFile::GetInternalCalFilename() {
	/// The cal data filename
	// Static Initlisation
	QString wcaCalDataFilename = "CalDataFile.cal";
	/// The complete cal data filename including path
	QString wcaPathAndFileName;
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_REPORTS, &wcaCalDataFilename, &wcaPathAndFileName, MAX_PATH);
	return wcaPathAndFileName;
}

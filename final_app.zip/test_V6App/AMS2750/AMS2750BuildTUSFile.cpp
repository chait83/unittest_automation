//************************************************************************************
// Module  AMS2750
// Filename  AMS2750buildTUSFile.cpp
// Copyright GA Digital 2008
/// **********************************************************************************
/// @n Module: 	  AMS2750 fie processing
/// @n Filename:  AMS2750buildTUSFile.cpp
/// @n Description: Build information into TUS data file 
///
// ***********************************************************************************
#include "AMS2750buildTUSFile.h"
#include "V6globals.h"
#include "AMS2750TUSMgr.h"
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE )
CDebugFileLogger m_errorFileLogger1(L"\\SDMemory\\AMS_BuildLogFile.txt", TRUE, (15*1024*1024)); //Veeru - DebugFile Logger integration
#endif
// Static Initlisation
const WCHAR C2750BuildTUSFile::m_wcaTUS_DATA_FILENAME[ MAX_PATH] = L"TUSDataFile.tus";
//****************************************************************************************
///
/// Constructor
///
/// @param[in]		const T_MODULE_ID eMODULE_ID - The ID of this active module
///
//****************************************************************************************
C2750BuildTUSFile::C2750BuildTUSFile(const T_MODULE_ID eMODULE_ID) : CV6ActiveModule(eMODULE_ID), m_bInitialised(false) {
    // Initialise Member Variables
    m_eOperationalMode = tfbOPMODE_IDLE;
    m_wcaPathAndFileName[0] = 0;
}
//****************************************************************************************
///
/// Destructor
///
//****************************************************************************************
C2750BuildTUSFile::~C2750BuildTUSFile() {
    SetTUSDataPtr(NULL);
    if (m_bInitialised) {
        m_kTUSDataFile.Close();
    }
}
//****************************************************************************
///
/// Method that validates (and creates if it does not exist) the TUS data file
///
/// @return true if the file was okay, false if the file needs to be wiped
///
//****************************************************************************
const bool C2750BuildTUSFile::InitialiseTUSFile() {
    bool bFileWiped = false;
    bool bSuccess = false;
    QString wcaError;
    QFileDevice::FileError kEx;
    QString path = QString::fromWCharArray(m_wcaTUS_DATA_FILENAME);
    QString filename = QString::fromWCharArray(m_wcaPathAndFileName);
    // check the TUS file exists first
    pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_REPORTS, &path, &filename, MAX_PATH);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
    QString   strLogMessage;
    strLogMessage = QString::asprintf("C2750BuildTUSFile::InitialiseTUSFile - GTC:%d\r\n",GetTickCount() );
    m_errorFileLogger1.WriteToDebugLogFile(strLogMessage);
#endif
    if (!m_kTUSDataFile.exists(filename)) {
        // the file does not exist therefore create it
        // to avoid fragmentation this file is always present and is fixed in length
        if (m_kTUSDataFile.Open(filename.toLocal8Bit().data(),  QFile::ReadWrite, &kEx)) {
            bSuccess = true;
            // allocate the maximum file size
//            m_kTUSDataFile./*SetLength*/(TUS_MAX_FILE_SIZE);
            // write the dummy data to the file so it is correctly populated
            ClearTUSDataFile();
        } else {
            QString strError("");
            // couldn't create the file and open the file for writing
            bSuccess = false;

            wcaError = CStorage::GetErrorMessage(kEx);
            TUSDataFileError(wcaError);
        }
    } else {
        // the file exists already so open it
        if (m_kTUSDataFile.Open(filename.toLocal8Bit().data(), QFile::ReadWrite,&kEx)) {
            bSuccess = true;
        } else {
            // couldn't open the file for writing

            wcaError = CStorage::GetErrorMessage(kEx);
            TUSDataFileError(wcaError);
        }
    }
    // if we get to this point then all should be well and we have the file open and readable
    // we must now validate the file contents so create a buffer bog enough to hold the entire file
    // contents
    const ULONG ulFILE_LENGTH = TUS_MAX_FILE_SIZE;
    UCHAR *pcTUSDataFile = new UCHAR[ulFILE_LENGTH + 1];
    memset(pcTUSDataFile, 0, ulFILE_LENGTH + 1);
    if (pcTUSDataFile) {
        // proceeed with the validition
        m_kTUSDataFile.seek(0);
        m_kTUSDataFile.Read(pcTUSDataFile, ulFILE_LENGTH);
        // update the file pointer so it looks at this memory based copy of the data
        InitTUSFile(pcTUSDataFile);
        // validate the file now
        T_C2750PROCESSFILE_RES result = PF_OK;
        T_STRUCTURE_IDENT errStruct;
        int iInstance;
        // validate the file - failures will not necessarily result in the fiel being wiped as some data is resent
        // by the TUS manager
        result = ValidateTUSFile(errStruct, iInstance);
        // check the validation result
        if (result == PF_OK) {
            bSuccess = true;
        } else {
            // file corrupt - let the there has been a problem which will make is effectively restart the TUS
            LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - wiped TUS file due to corruption. Resetting last TUS!!!");
            // write the empty data to the file so it is correctly populated
            ClearTUSDataFile();
            // carry on normally though
            bSuccess = false;
            bFileWiped = true;
        }
        // now free the memory used for the validation
        delete[] pcTUSDataFile;
        SetTUSDataPtr(&m_tFileHeader);
        // Copy the file header information into our copy of the header
        m_kTUSDataFile.seek(0);
        m_kTUSDataFile.Read(&m_tFileHeader, sizeof(T_2750FILEHEADEROVERLAY));
    } else {
        // couldn't create the memory based buffer
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - Could not validate the TUS data file!");
        V6CriticalMessageBox(NULL, "Cannot validate file as run out of memory", "AMS2750 ERROR", MB_OK );
        bSuccess = false;
    }
    // check everything has been successful
    if (bSuccess) {
        m_bInitialised = true;
    }
    return !bFileWiped;
}
//****************************************************************************************
///
/// Method that adds the specified structure to the TUS file
///
///	@param[in] void *structPtr - Pointer to the structure we wish to add
///	@param[in] int structSize - The length of the structure in bytes
///	@param[in] T_STRUCTURE_IDENT structIdent - The type of the structure
///	@param[in] int structInstance - The instance number of the structure
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES C2750BuildTUSFile::addStruct(void *structPtr, int structSize, T_STRUCTURE_IDENT structIdent,
                                                  int structInstance) {
    int sIndex = m_tFileHeader.fh.numStructures;
    T_C2750BUILDFILE_RES retVal = BF_FAILED;
    if (sIndex < NUM_STRUCT_SLOTS) {
        // check to see if the file exists already
        int theIndex = 0;
        if (PF_STRUCTURE_FOUND == findStruct(structIdent, structInstance, theIndex)) {
            T_PTUSSTRUCTIDENT ptrIndex = &m_tFileHeader.structList[theIndex];
            int copyLen = ptrIndex->length;
            // test for any size difference within structures
            if (ptrIndex->length < structSize) {
                // the source structure(file) is smaller then the current structure built in codebase, so this would
                // inducate that the source structure is older, so we return all we can and set the rest of the struct to 0
                memset(structPtr, 0, structSize);
                //retVal = PF_STRUCTURE_TOO_SMALL;
            } else if (ptrIndex->length > structSize) {
                // the source structure(file) is bigger then the current structure built in codebase, this would indicate that
                // the source structure is newer, so we will truncate the source structure to fit in the destination.
                copyLen = structSize;// Set the copy length to struct size as previously it was set to larger source struct size
                //retVal = PF_STRUCTURE_TOO_LARGE;
            }
            // Copy the source structure to the destination
            m_kTUSDataFile.Seek(ptrIndex->startPos, 0);
            m_kTUSDataFile.Write(structPtr, copyLen);
            UpdateCRCOnStructure(theIndex, structPtr);									// Update the CRC in the table
        } else {
            // this is a new structure therefore insert
            // Get the start point for the new structure
            int structBase = sizeof(T_2750FILEHEADEROVERLAY);
            if (sIndex != 0) {
                // Not the first structure, so take from previous entry
                structBase = m_tFileHeader.structList[sIndex - 1].startPos
                        + m_tFileHeader.structList[sIndex - 1].length;
            }
            // Check if we have room to proceed and add structure
            if ((structBase + structSize) <= TUS_MAX_FILE_SIZE) {
                // Yes we have room, add the structure and update the table
                m_kTUSDataFile.Seek(structBase, 0);
                m_kTUSDataFile.Write(structPtr, structSize);
                m_tFileHeader.structList[sIndex].length = structSize;					// Set the structure table entry
                m_tFileHeader.structList[sIndex].startPos = structBase;
                m_tFileHeader.structList[sIndex].ident = structIdent;
                m_tFileHeader.structList[sIndex].instance = structInstance;
                m_tFileHeader.fh.offSetOfLogData = structBase + structSize;	// Set position where log data can be added
                UpdateCRCOnStructure(sIndex, structPtr);								// Update the CRC in the table
                retVal = BF_OK;
            } else {
                retVal = BF_STRCUTURE_MAP_FULL; // Structure map is full
            }
            m_tFileHeader.fh.numStructures++;		// Increment number of structures in table
            UpdateHeaderCRC();					// Update the CRC on the header after data added.
        }
    } else {
        retVal = BF_STRCUTURE_MAP_FULL;		// Structure map is full
    }
    return retVal;
}
//****************************************************************************************
///
/// Method that updates the CRC in the TUS file following the addition of a structure
///
///	@param[in] void *structPtr - the index point of the added structure
///	@param[in] void *structPtr - the structure to CRC
///
//****************************************************************************************
void C2750BuildTUSFile::UpdateCRCOnStructure(int sIndex, void *structPtr) {
    m_tFileHeader.structList[sIndex].crc = CrcCalc(reinterpret_cast<UCHAR*>(structPtr),
                                                   m_tFileHeader.structList[sIndex].length);
}
//****************************************************************************************
///
/// Method that updates the CRC in the header of the TUS file
///
//****************************************************************************************
void C2750BuildTUSFile::UpdateHeaderCRC() {
    CrcInsert((UCHAR*) &m_tFileHeader, sizeof(T_2750FILEHEADER));
}
//****************************************************************************************
///
/// Method that adds the test configuration structure to the file
///
/// @param[in]	T_PTUSTESTCONFIG pStruct - Pointer to the test configuration
///					structure we wish to add
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES C2750BuildTUSFile::AddTestConfigStructure(T_PTUSTESTCONFIG pStruct) {
    // Add the test config structure to the file space
    return addStruct(pStruct, sizeof(T_TUSTESTCONFIG), ST_TUSTESTCONFIG, 0);
}
//****************************************************************************************
///
/// Method that adds a sensor configuration structure to the file
///
/// @param[in]	T_PTUSSENSORCONFIG pStruct - Pointer to the sensor configuration
///					structure we wish to add
/// @param[in]	int instance - The zero-based instance number of the sensor
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES C2750BuildTUSFile::AddSensorConfigStructure(T_PTUSSENSORCONFIG pStruct, int instance) {
    // Add the sensor config structure to the file space
    return addStruct(pStruct, sizeof(T_TUSSENSORCONFIG), ST_TUSSENSORCONFIG, instance);
}
//****************************************************************************************
///
/// Method that adds a test data structure to the file
///
/// @param[in]	T_PTUSSENSORCONFIG pStruct - Pointer to the test data structure we wish to add
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES C2750BuildTUSFile::AddTestDataStructure(T_PTUSTESTDATA pStruct) {
    // Add the test data structure to the file space
    return addStruct(pStruct, sizeof(T_TUSTESTDATA), ST_TUSTESTDATA, 0);
}
//****************************************************************************************
///
/// Method that adds a test data structure to the file
///
/// @param[in]	T_PTUSSENSORCONFIG pStruct - Pointer to the test data structure we wish to add
/// @param[in]	int instance - The zero-based instance number of the sensor
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES C2750BuildTUSFile::AddSoakDataStructure(T_PTUSSOAKDATA pStruct, int instance) {
    // Add the soak data structure to the file space
    return addStruct(pStruct, sizeof(T_TUSSOAKDATA), ST_TUSSOAKDATA, instance);
}
//****************************************************************************************
///
/// Method that adds the general calibration data structure to the file
///
/// @param[in]	T_PTUSSENSORCONFIG pStruct - Pointer to the general calibration data structure we wish to add
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES C2750BuildTUSFile::AddGeneralCalibrationStructure(T_PAMS2750GENCAL pStruct) {
    // Add the test data structure to the file space
    return addStruct(pStruct, sizeof(T_AMS2750GENCAL), ST_AMSGENCALDATA, 0);
}
//****************************************************************************************
///
/// Method that adds a sensor input calibration results structure to a file (cal or tus file)
///
/// @param[in]	T_PSENSORCALDATA pStruct - Pointer to the sensor input calibration results
///					structure we wish to add
/// @param[in]	int instance - The zero-based instance number of the sensor
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES C2750BuildTUSFile::AddSensorInputCalibrationStructure(T_SENSORINPUTCALDATA *pStruct,
                                                                           int instance) {
    // Add the sensor calibration results structure to the file space
    return addStruct(pStruct, sizeof(T_SENSORINPUTCALDATA), ST_AMSSENSORINPUTCALDATA, instance);
}
//****************************************************************************************
///
/// Method that updates the CRC in the log header
///
/// @param[in]	T_PTUSDATAREADINGHEADER pLogHeader - Pointer to the log header whose CRC we are updating
///
//****************************************************************************************
void C2750BuildTUSFile::UpdateCRCForLogHeader(T_PTUSDATAREADINGHEADER pLogHeader) {
    CrcInsert((UCHAR*) pLogHeader, sizeof(T_TUSDATAREADINGHEADER));
}
//****************************************************************************************
///
/// Method that updates the CRC in a log reading
///
/// @param[in]	T_PTUSDATAREADINGHEADER pLogHeader - Pointer to the log reading whose CRC we are updating
///
//****************************************************************************************
void C2750BuildTUSFile::UpdateCRCForLogReading(T_PTUSDATAREADING pLogReading) {
    CrcInsert((UCHAR*) pLogReading, sizeof(T_TUSDATAREADING));
}
//****************************************************************************
///
/// Method that clears the TUS data file usually at the start of a TUS
///
//****************************************************************************
void C2750BuildTUSFile::ClearTUSDataFile() {
    // the file should already be open and of the correct length - we need to set all the structures back to default
    // Setup the header
    memset(&m_tFileHeader, 0, sizeof(T_2750FILEHEADEROVERLAY));
    m_tFileHeader.fh.version = TUSFILE_VERSION;
    m_tFileHeader.fh.reportNumber = 1;
    CTVtime aTime;
    aTime.TimeNow();
    m_tFileHeader.fh.timeOfReport = aTime.GetMicroSecs();
    SetTUSDataPtr(&m_tFileHeader);
    // finally update the header
    UpdateHeaderCRC();
    WriteHeaderToDisk();
}
//****************************************************************************
///
/// Method that sets up and saves the log data header structure (this will happen once all the configuration 
/// data has been written)
///
//****************************************************************************
void C2750BuildTUSFile::SetupLogHeader() {
    // persist the log header with the current offset
    UpdateHeaderCRC();
    WriteHeaderToDisk();
    // now write the log header to disk - we should already be in the correct position we hope
    memset(&m_tLogHeader, 0, sizeof(T_2750LOGDATAOVERLAY));
    m_tLogHeader.lh.numOfReadings = 0;
    m_tLogHeader.lh.crc = 0;
    m_tLogHeader.logReading[0];
    UpdateCRCForLogHeader(&m_tLogHeader.lh);
    // the log header is prepared - find the correct point and write it to disk
    m_kTUSDataFile.Seek(m_tFileHeader.fh.offSetOfLogData, 0);
    m_kTUSDataFile.Write(&m_tLogHeader, sizeof(T_2750LOGDATAOVERLAY));
}
//****************************************************************************
///
/// Method that writes the header information to disk
///
//****************************************************************************
void C2750BuildTUSFile::WriteHeaderToDisk() {
    m_kTUSDataFile.seek(0);
    m_kTUSDataFile.Write(&m_tFileHeader, sizeof(T_2750FILEHEADEROVERLAY));
}
//****************************************************************************
///
/// Method that logs a file error and deletes the TUS data file
///
/// param[in]	const QString   &rstrERROR - String containing a description of the error
/// 
//****************************************************************************
void C2750BuildTUSFile::TUSDataFileError(const QString &rstrERROR) {
    // log the error message
    QString errString;
    errString = QString::asprintf("AMS2750 Data File Error - %s", rstrERROR.toLocal8Bit().data());
    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, errString);
    // close the file just in case it is still open
    m_kTUSDataFile.Close();
    // delete the file
    m_kTUSDataFile.DeleteFile(QString::fromWCharArray(m_wcaPathAndFileName));
    // halt the program thus forcing a restart which should recreate the TUS data file
    V6CriticalMessageBox(NULL, rstrERROR.toLocal8Bit().data(), "TUS Data File Error", MB_OK );
}
//****************************************************************************
///
/// Method that adds a log reading to the file
/// 
/// @param[in]		T_TUSDATAREADING &rtDataReading - Reference copy of the reading we wish to add
///
//****************************************************************************
void C2750BuildTUSFile::LogReading(T_TUSDATAREADING &rtDataReading) {
    // update the CRC
    UpdateCRCForLogReading(&rtDataReading);
    // seek to the current position of the data in the file
    m_kTUSDataFile.Seek(
                m_tFileHeader.fh.offSetOfLogData + sizeof(T_TUSDATAREADINGHEADER)
                + ((rtDataReading.sequenceNumber - 1) * sizeof(T_TUSDATAREADING)), 0);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
    // write the reading to disk - assume the data reading is already CRC'ed
    for( int sensorIndex = 0; sensorIndex < 3; sensorIndex++ )
    {
        QString   strLogMessage;
        strLogMessage = QString::asprintf("C2750BuildTUSFile LogReading rtDataReading.TCReading[%d] = %0.4f GTC:%d\r\n",sensorIndex,rtDataReading.TCReading[sensorIndex],GetTickCount() );
        m_errorFileLogger1.WriteToDebugLogFile(strLogMessage);
    }
#endif
    m_kTUSDataFile.Write(&rtDataReading, sizeof(T_TUSDATAREADING));
    // update the log header information
    m_tLogHeader.lh.numOfReadings = rtDataReading.sequenceNumber;
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
    QString   strLogMessage;
    strLogMessage = QString::asprintf("CC2750BuildTUSFile::LogReading m_tLogHeader.lh.numOfReadings = %d - GTC:%d\r\n",m_tLogHeader.lh.numOfReadings,GetTickCount() );
    m_errorFileLogger1.WriteToDebugLogFile(strLogMessage);
#endif
    UpdateCRCForLogHeader(&m_tLogHeader.lh);
    // don't forget to seek to the correct position
    m_kTUSDataFile.Seek(m_tFileHeader.fh.offSetOfLogData, 0);
    // the log header is prepared - write it to disk
    m_kTUSDataFile.Write(&m_tLogHeader, sizeof(T_TUSDATAREADINGHEADER));
}
/// ********************* ///
/// ACTIVE MODULE METHODS ///
/// ********************* ///
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation( void )
///
/// Primary Initialisation of the Module
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::PerformPrimaryInitialisation(void) {
    // check the TUS data file exists, create it if necessary and validate the file
    if (!InitialiseTUSFile()) {
        CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
        pkTUSMgr->ResetTUSStatus();
    }
    return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation( void )
///
/// Secondary Initialisation of the Module
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::PerformSecondaryInitialisation(void) {
    // --- Do Nothing --- //
    return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE NormalOperation( void )
///
/// Method called when Module goes into Normal Operation
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::NormalOperation(void) {
    m_eOperationalMode = tfbOPMODE_NORMAL_OPERATION;
    return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation( void )
///
/// Method called when Module is to prepare for Setup Config Change 
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::SetupConfigChangePreparation(void) {
    m_eOperationalMode = tfbOPMODE_IDLE;
    return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete( void )
///
/// Method called when Module is to carry out Setup Change Completion
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::SetupConfigChangeComplete(void) {
    // post setup change code must be carried out here
    return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE ShutdownPreparation( void )
///
/// Method called when a Module is to prepare for Shutdown
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::ShutdownPreparation(void) {
    m_eOperationalMode = tfbOPMODE_IDLE;
    return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
//	T_V6ACTMOD_RETURN_VALUE Shutdown( void )
///
/// Method called when a Module is to Shutdown
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::Shutdown(void) {
    m_eOperationalMode = tfbOPMODE_EXIT;
    return (V6ACTMOD_OK);
} // End of Member Function
//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler( const CMsgQueueMessage *pMsg )
///
/// Carries out the desired function when a message is received
///
/// @param[in] 	  const CMsgQueueMessage *pMsg - Pointer to the received message 
///
/// @return V6ACTMOD_OK - Associated Action with Received Message Undertaken Sucessfully
/// @n V6ACTMOD_MESSAGE_NOT_HANDLED - Message Received is not being handled
/// 
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE C2750BuildTUSFile::ModuleMessageHandler(const CMsgQueueMessage *pMsg) {
    T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_OK;
    switch (pMsg->m_MessageType) {
    case MOD_TUS_CLEAR_TUS:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            // clear the file which will be prior to adding the configuration data
            ClearTUSDataFile();
        }
        break;
    case MOD_TUS_START_TUS:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            // add the latest test data structure
            AddTestDataStructure((T_TUSTESTDATA*) (pMsg->m_MsgData));
            // setup the log header - this will only happen once all the configuration data has been added
            // to the file
            SetupLogHeader();
        }
        break;
    case MOD_TUS_ADD_TEST_CFG:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            AddTestConfigStructure((T_TUSTESTCONFIG*) (pMsg->m_MsgData));
        }
        break;
    case MOD_TUS_ADD_SENSOR_CFG:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            T_PTUSSENSORCONFIG ptSensorCfg = (T_TUSSENSORCONFIG*) (pMsg->m_MsgData);
            AddSensorConfigStructure(ptSensorCfg, ptSensorCfg->TCNumber);
        }
        break;
    case MOD_TUS_ADD_GENERAL_CAL:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            T_PAMS2750GENCAL ptGeneralCal = (T_AMS2750GENCAL*) (pMsg->m_MsgData);
            AddGeneralCalibrationStructure(ptGeneralCal);
        }
        break;
    case MOD_TUS_ADD_SENSOR_INPUT_CAL:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            T_SENSORINPUTCALDATAMSG *ptSensorInputCalDataMsg = (T_SENSORINPUTCALDATAMSG*) (pMsg->m_MsgData);
            AddSensorInputCalibrationStructure(&ptSensorInputCalDataMsg->sensorInputCal,
                                               ptSensorInputCalDataMsg->sensorNo);
        }
        break;
    case MOD_TUS_ADD_SOAK:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            T_PTUSSOAKDATA ptSoakCfg = (T_PTUSSOAKDATA) (pMsg->m_MsgData);
            AddSoakDataStructure(ptSoakCfg, ptSoakCfg->test.Instance);
            WriteHeaderToDisk();
        }
        break;
    case MOD_TUS_ADD_LOG_DATA:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            T_PTUSDATAREADING ptDataReading = (T_TUSDATAREADING*) (pMsg->m_MsgData);
            LogReading(*ptDataReading);
        }
        break;
    case MOD_TUS_STOP_TUS:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            // add the latest test data structure which should contain any end notes and the end time
            AddTestDataStructure((T_TUSTESTDATA*) (pMsg->m_MsgData));
            // now update the header information
            UpdateHeaderCRC();
            WriteHeaderToDisk();
        }
        break;
    case MOD_TUS_EXPORT_TUS:
        // check we are able to update the TUS file
        if (m_bInitialised) {
            // extract the path name from the message
            WCHAR wcaPathname[ MAX_PATH];
            memset(wcaPathname, 0, MAX_PATH * sizeof(WCHAR));
            memcpy(wcaPathname, pMsg->m_MsgData, pMsg->m_MsgSize);
            m_kTUSDataFile.Close();
            // now copy the TUS data file to the selected external device
            m_kTUSDataFile.CopyFiles(QString::fromWCharArray(m_wcaPathAndFileName).toLocal8Bit().data(), QString::fromWCharArray(wcaPathname).toLocal8Bit().data(), FALSE, FALSE);
            // now reopen the data file again
            m_kTUSDataFile.Open(QString::fromWCharArray(m_wcaPathAndFileName).toLocal8Bit().data(), QFile::ReadWrite);
        }
        break;
    default:
        // not a specific method therefore pass on to the standard handler
        retValue = CV6ActiveModule::ModuleMessageHandler(pMsg);
        break;
    } // End of SWITCH
    return (retValue);
} // End of Member Function
//****************************************************************************************
/// API - Validates the file within the memory block, running though all available structures 
/// checking the CRC's, if a structure is found to be corrupted then the type of structure
/// and it's instance number will be passed back.
/// 
/// @param[out]	&errStruct - reference to T_STRUCTURE_IDENT used to identify type of corrupted structure
/// @param[out]	&instance - reference to int used to identify the instance number of the corrupted structure
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_FILE_CORRUPT indicates corruption identified in structure on &errStruct and &instance
///					PF_OK file integrity ok, and can be used for further processing
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750BuildTUSFile::ValidateTUSFile(T_STRUCTURE_IDENT &errStruct, int &instance) {
    T_C2750PROCESSFILE_RES retVal = PF_OK;
    // First check the CRC of the header
    if( CrcTest( (UCHAR *)pTUSData, sizeof(T_2750FILEHEADER) ) == CRC_TEST_PASSED )
    {
        int iFailedSoaks = 0;
        // Header CRC ok, Run though all available structures in list, check the CRC's
        for (int sIndex = 0; sIndex < pTUSData->fh.numStructures; sIndex++) {
            // Check CRC's of structures in list.
            if (CrcCalc((UCHAR*) pTUSData + pTUSData->structList[sIndex].startPos, pTUSData->structList[sIndex].length)
                    != pTUSData->structList[sIndex].crc) {
                // CRC FAILED - check what exactly failed
                // Set information to show a structure in table is corrupted
                errStruct = (T_STRUCTURE_IDENT) pTUSData->structList[sIndex].ident;
                instance = pTUSData->structList[sIndex].instance;
                switch (errStruct) {
                case ST_TUSSOAKDATA:
                    // check if this is the first soak to fail
                    if (iFailedSoaks >= 1) {
                        // two or more soaks failed therefore we are going to have to bail and delete the file
                        retVal = PF_FILE_CORRUPT;
                        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - multiple soaks corrupted!!!");
                    } else {
                        // this is the first soak to fail so assume this is the last soak to be written
                        // the TUS manager will automaitcally send the last soak data again on a resume
                        // report the error
                        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "AMS2750 WARNING - soak data corrupted - will attempt to repair");
                    }
                    break;
                case ST_2750FILEHEADER:
                    // failure of any of this structures is fatal therefore abort
                    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - TUS file header corrupted!!!");
                    retVal = PF_FILE_CORRUPT;
                    break;
                case ST_TUSTESTDATA:
                    // failure of any of this structures is fatal therefore abort
                    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - TUS test data corrupted!!!");
                    retVal = PF_FILE_CORRUPT;
                    break;
                case ST_TUSTESTCONFIG:
                    // failure of any of this structures is fatal therefore abort
                    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
                                           "AMS2750 ERROR - TUS test configuration data corrupted!!!");
                    retVal = PF_FILE_CORRUPT;
                    break;
                case ST_TUSSENSORCONFIG:
                    // failure of any of this structures is fatal therefore abort
                    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
                                           "AMS2750 ERROR - TUS sensor configuration data corrupted!!!");
                    retVal = PF_FILE_CORRUPT;
                    break;
                    // the two items below should not be in this check so do nothing
                case ST_TUSDATAREADINGHEADER:
                case ST_TUSDATAREADING:
                    // do nothing
                    break;
                case ST_AMSGENCALDATA:
                    // failure of any of this structures is fatal therefore abort
                    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - TUS general data corrupted!!!");
                    break;
                case ST_AMSSENSORINPUTCALDATA:
                    // failure of any of this structures is fatal therefore abort
                    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - TUS sensor input calibration data corrupted!!!");
                    break;
                default:
                    // must be an unknown structure therefore log the error but continue anyway
                    LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "AMS2750 WARNING - unknown data structure corrupt. Ignoring...");
                    break;
                }
                // check if there has been a fatal error
                if( retVal == PF_FILE_CORRUPT )
                {
                    break;
                }
            }
        }

        // If structure check is ok we can validate the log data readings
        if( retVal == PF_OK )
        {
            if( pTUSData->fh.offSetOfLogData > 0 )
            {
                pTUSLog = (T_P2750LOGDATAOVERLAY)((UCHAR *)pTUSData + pTUSData->fh.offSetOfLogData);
                // check the header CRC - if corrupt then we need to report the error but it is notr fatal as it
                // will be updated with the correct information by the TUS manager shortly
                if( CrcTest( (UCHAR *)pTUSLog, sizeof(T_TUSDATAREADINGHEADER)) == CRC_TEST_PASSED )
                {
                    // Log header OK, run though all log reading blocks and check the CRC's
                    for( int lIndex = 0; lIndex < pTUSLog->lh.numOfReadings; lIndex++ )
                    {
                        // Test CRC of log block
                        if( CrcTest( (UCHAR *)&pTUSLog->logReading[lIndex], sizeof(T_TUSDATAREADING)) == CRC_TEST_FAILED )
                        {
                            // CRC FAILED, Log Reading is corrupted -  set information and exit
                            errStruct = ST_TUSDATAREADING;
                            instance = lIndex;
                            QString strError( "" );
                            strError.asprintf( "AMS2750 ERROR - TUS data reading %u corrupted!!!", lIndex );
                            LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, strError );
                            retVal = PF_OK;
                            break;
                        }
                    }
                }
                else
                {
                    // CRC FAILED, Log header is corrupted
                    errStruct = ST_TUSDATAREADINGHEADER;
                    instance = 0;
                    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_WARNING, "AMS2750 WARNING - TUS log header corrupted - will attempt to repair" );
                    //retVal = PF_FILE_CORRUPT;
                }
            }
            else
            {
                // no log readings in the file which is OK therfore ignore
            }
        }
    }
    else
    {
        // CRC FAILED, Set information to show header is corrupted
        errStruct = ST_2750FILEHEADER;		// Set an indication of the structure which has the problem.
        instance = 0;
        LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - TUS header corrupted!!!" );
        retVal = PF_FILE_CORRUPT;
    }
    return retVal;
}

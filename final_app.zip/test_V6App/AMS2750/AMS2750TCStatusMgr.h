/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 data processing
/// @n Filename:  AMS2750TCStatusMgr.h
/// @n Description: Definition of the CAMS2750TCStatusMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:55:23 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:25:14 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 9/23/2008 12:12:17 PM  Build Machine  
// $
//
// **************************************************************************
#if !defined(AFX_AMS2750TCSTATUSMGR_H__86572202_C84B_4920_8408_9B49873FB3DD__INCLUDED_)
#define AFX_AMS2750TCSTATUSMGR_H__86572202_C84B_4920_8408_9B49873FB3DD__INCLUDED_
#include "Defines.h"
#include "AMS2750DataStruct.h"
#include "AMS2750TUSMgr.h"
#include "DataItemIO.h"
#include "V6Config.h"
#include <QMutex>
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AMS2750TCStatusMgr.h : header file
//
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
	#include "CStorage.h"
#endif
const int AMS2750_TCTIMER_PROCESS_SECONDS = 1;		// Process the timers every second
const int TC_IS_EXPENDABLE = 0;						// An Expendable TC
const int TC_IS_NON_EXPENDABLE = 1;					// A Non-Expendable TC
// Usage counts for Non-Expendable load base metal thermocouples
const int TC_USESCAP_RESET = 999;
const int TC_NONEXP_BASE_LOADTC_BELOW_500F_MAXUSE = 998;
const int TC_NONEXP_BASE_LOADTC_500_1200F = 270;
const int TC_NONEXP_BASE_LOADTC_1200_1800F = 180;
const int TC_NONEXP_BASE_LOADTC_1800_2200F = 90;
const int TC_NONEXP_BASE_LOADTC_2200_2300F = 10;
const int TC_NONEXP_BASE_LOADTC_OVER_2300F = 1;
const int TC_NONEXP_BASE_TUSTC_MAXUSE = 998;
const short TC_NONEXP_BASE_TUSTC_DAYS = 3 * 365;				// 3 Years usage allowed
const short TC_NONEXP_BASE_LOADTC_DAYS_BELOW1800F = 90;		// 90 Days under 1800F
const short TC_NONEXP_BASE_LOADTC_DAYS_BELOW2200F = 90;		// 90 Days under 2200F
const short TC_NONEXP_BASE_LOADTC_DAYS_BELOW2300F = 90;		// 90 Days under 2300F
const int TC_EXP_BASE_MAXUSE = 998;
const int TC_EXP_BASE_MTKE_MAX_USE_500_1200F = 5;
const int TC_EXP_BASE_JN_MAX_USE_500_1200F = 10;
const short TC_EXP_BASE_DAYS = 90;		// 90 Days
typedef enum {
	TC_TEMPS_HYSTERESIS = 0,
	TC_TEMPS_BASE_500F,
	TC_TEMPS_EXP_BASE_1200F,
	TC_TEMPS_EXP_BASE_1800F,
	TC_TEMPS_EXP_BASE_2200F,
	TC_TEMPS_EXP_BASE_2300F,
	TC_TEMPS_MAX
} T_TC_USAGE_TEMPS;
// Temperatures for usage comparision			Deg F		Deg C	
const float TC_USAGE_TEMPS[TC_TEMPS_MAX][2] = { { 18.0, 10.0 },		// Hysteresis
		{ 500, 260 },		// expendable or non-expendable base metal 500F
		{ 1200, 650 },		// expendable base metal 1200F
		{ 1800, 980 },		// expendable base metal 1800F
		{ 2200, 1205 },		// non-expendable base metal 2200F
		{ 2300, 1260 },		// non-expendable base metal 2300F
		};// End of usage temps
/// Status of an AMS2750 TC cal/usage
typedef enum {
	TC_STATUS_NOT_TRACKED = 0,					//< TC is not being tracked
	TC_STATUS_GOOD,								//< TC is good
	TC_STATUS_WARNING,							//< TC is in warning , approaching cal/end of life
	TC_STATUS_EXPIRED							//< TC expired , needs to be changed or re-calibrated
} T_2750TC_STATUS;
// NV structure for each TC
typedef struct {
	ULONG expiryDate;				//< Expiry date 
	ULONG renewDate;				//< Date TC was renewed
	short calLimiter;				//< Day limiter on calibration
	short dayLimit;					//< Number of days to limit 
	short usesleft;					//< Number of uses remaining
	short usesCap;					//< Cap level reached by non-exp load TC base metal only
	USHORT category;				//< TC_CATEGORY category of TC with repatio to TC tracking
	USHORT SensType;				//< Sensor type, TUS TC, Load TC or rec control monitor
	USHORT TCRTtype;					//< The type of TC connect K, J, R, S etc....		
	USHORT lastState;				//< T_TCUSAGE_STATE to indicate a furnace cycle has been performed
	float peakTempReached;			//< Peak temperature reached on this cycle
	float lastTempRecorded;			//< Last recorded temperature (used to detect breaches)
	BOOL runCompleted;				//< TRUE Run completed, and no more checking on TC's to be done
} T_TCUSAGE_TCINFO;
// Overall NV structure for TC Timers
typedef struct {
	T_TCUSAGE_TCINFO tc[NUM_TCS_PER_SOAK];
} T_TCUSAGE_NV;
// Status of the TC with respect to limit levels
typedef enum {
	T_TCUSAGE_STATE_NOTSTARTED = 0, T_TCUSAGE_STATE_BELOW,//< The TC is below the low level indicating the furnace is between operations
	T_TCUSAGE_STATE_ABOVE,				//< The tc is above the high level, indicating it is in an operation
} T_TCUSAGE_STATE;
// Thermocouple category of TC type, metal type and Exendability
typedef enum {
	TC_CATEGORY_NONE = 0,								//< No Category
	TC_CATEGORY_NOBLE_RSB,							//< Noble metal type R, S or B
	TC_CATEGORY_BASE_EXP_KJTNEM,					//< Exendable Base metal type K, J, T, N or E
	TC_CATEGORY_BASE_NONEXP_KJTNEM,					//< Non-Expendable Base Metal type K, J, T, N or E
} TC_CATEGORY;
// Thermocouple category of TC type, metal type and Exendability
typedef enum {
	TC_SENSTYPE_REC = 0,								//< Sensor type record, control, monitoring
	TC_SENSTYPE_TUS,								//< sensor type TUS
	TC_SENSTYPE_LOAD,								//< Sensor type load
} TC_SENSTYPE;
// Information for TC enabled to be tracked.
typedef struct {
	int TCIndex;						//< Actual index number of the TC 0-47.
	TC_CATEGORY category;				//< Thermocouple category
	BOOL trackCal;						//< TRUE to track the calibration
	BOOL trackUsage;					//< TRUE to track the usage
	BOOL trackExpired;					//< TRUE to track expired usage
	T_TCUSAGE_TCINFO *pTCNV;			//< Pointer to the NV for this TC.
	CDataItemIO *pAIDIT;				//< Pointer to Data item for analogue input.
	T_PAMS2750SENSOR pSensorConfig;		//< Pointer to the sensor configuration for this TC.
	T_PAICHANNEL pAIConfig;				//< Analogue Input configuration
	T_2750TC_STATUS calStatus;			//< Calibration status of TC
	long daysRemainingTilCal;			//< Number of days remaining until calibration required
	T_2750TC_STATUS usesStatus;			//< status of TC number of uses
	T_2750TC_STATUS daysStatus;			//< status of TC days in use
	int daysleft;						//< number of days usage left
	T_PFURNACE pFurnace;				//< Furnace relative to the thermocouple
	BOOL updateMe;						//< Updated flag for TC so allow redraw
} T_TC_INFO, *T_PTC_INFO;
//**CAMS2750TCStatusMgr***********************************************************
///
/// @brief Singleton class used to manage the AMS2750 TC Status information and provide an 
/// interface between the data processing and UI
/// 
/// Singleton class used to manage the AMS2750 TC Status information and provide an 
/// interface between the data processing and UI
///
//****************************************************************************
class CAMS2750TCStatusMgr {
public:
	// Pointer to the committed sensor information structure
	T_PAMS2750SENSORS m_ptSensorInfo;
	/// Enum indicating the possible metal types for AMS2750 TCs
	enum T_AMS2750_TC_METALS {
		NOT_A_TC, UNKNOWN_METAL, NOBLE_METAL, BASE_METAL
	};
	// Method that creates and initialises the singleton
	static CAMS2750TCStatusMgr* Instance();
	// Destructor
	~CAMS2750TCStatusMgr() {
		;
	}
	// Initialise the timers
	void Initialise();
	// Configure the timers
	void Configure();
	// Process ther TC timers
	void Process();
	// Method that indentifies if a TC is being monitor for AMS2750 purposes (i.e. usage or
	// calibration tracking)
	const bool IsMonitoredTC(const USHORT usINSTANCE_NO, bool &rbIsTC) const;
	// Method that determines the TC metal type
	const T_AMS2750_TC_METALS GetSensorMetalType(const USHORT usINSTANCE_NO) const;
	// Method that returns the number of days of use a 'usage tracked' TC has remaining
	const long GetTCDaysRemaining(const USHORT usINSTANCE_NO) const;
	// Method that returns true if the selected TC is being usage tracked
	const bool IsUsageTracking(const USHORT usINSTANCE_NO) const {
		return (m_ptSensorInfo->Sensors[usINSTANCE_NO].UsageTrack == TRUE);
	}
	// Method that gets the uses left tracking info
	T_2750TC_STATUS GetUsesleftInfo(const USHORT usINSTANCE_NO, QString &rstrUsesleftInfo);
	// Method that gets the days left tracking info
	T_2750TC_STATUS GetDaysleftInfo(const USHORT usINSTANCE_NO, QString &rstrDaysleftInfo);
	// Method that returns the number of days remaining until the calibration date
	const long GetTCDaysUntilCalExpiry(const USHORT usINSTANCE_NO);
	// Method that returns the number of days in use since installation
	const long GetTCDaysInUse(T_PTC_INFO pTCInfo) const;
	// Method that returns the last renewal date as a string
	const QString GetLastRenewalDate(const USHORT usINSTANCE_NO) const;
	// Method that returns the calibration expiry date as a string
	const QString GetCalibrationExpiryDate(const USHORT usINSTANCE_NO) const;
	// Method that returns true is the next calibration date of the select TC is being tracked
	BOOL IsCalTracking(const USHORT usINSTANCE_NO);
	// Method that gets the calibration info - this could be a date until next cal due or a
	// number of days in use
	T_2750TC_STATUS GetCalInfo(const USHORT usINSTANCE_NO, QString &rstrCalInfo);
	// Method that returns the TC Name as a string
	const QString GetSensorName(const USHORT usINSTANCE_NO) const;
	// Method that returns the TC position as a string
	const QString GetTCPosition(const USHORT usINSTANCE_NO) const {
		return QString::fromWCharArray(m_ptSensorInfo->Sensors[usINSTANCE_NO].TCPosition);
	}
	// Accessor method that returns the minimum number of days allowable before expiry warnings 
	// are displayed
	const USHORT GetExpiryWarningUseLimitDays() {
		return m_usExpiryWarningUseLimitDays;
	}
	// Accessor method that returns the minimum number of uses allowable before expiry warnings 
	// are displayed
	const USHORT GetExpiryWarningLimitUses() {
		return m_usExpiryWarningLimitUses;
	}
	// Accessor method that retunrs the minimum number of days allowable before calibration
	// expiry warnings are displayed
	const USHORT GetExpiryWarningCalibLimitDays() {
		return m_usExpiryWarningCalibLimitDays;
	}
	// Method that determines if there are any TC's in an expired state
	const bool TCInExpiredState(const USHORT usINSTANCE_NO = 0, const bool bALL = true) const;
	// Method that determines if there are any TC's in a warning state
	const bool TCInWarningState(const USHORT usINSTANCE_NO = 0, const bool bALL = true) const;
	// Method that determines if there are no TC's being tracked
	const bool NoTrackedTCs(const USHORT usINSTANCE_NO = 0, const bool bALL = true) const;
	// Method that determines if TC update is required by front end
	bool IsTCUpdateRequired(USHORT usINSTANCE_NO);
	// Helper method used to indicate the system is in calibration mode and thus temperatures should be ignored
	void EnteredCalMode() {
		m_isInCalMode = TRUE;
	}
	// Helper method used to indicate the system is out of calibration mode
	void ExitedCalMode() {
		m_isInCalMode = FALSE;
	}
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
#endif
private:
	// Constructor
	CAMS2750TCStatusMgr();
	// Get the TC category
	TC_CATEGORY GetTCCategory(T_PTC_INFO pTCInfo, BOOL &CalTrackValid, BOOL &UsageTrackValid);
	// Check the usage of a TC
	BOOL UpdateUsage(T_PTC_INFO pTCInfo);
	// Update the calibration status
	BOOL UpdateCal(T_PTC_INFO pTCInfo);
	float GetUsageLimitTemp(T_TC_USAGE_TEMPS range) {
		return TC_USAGE_TEMPS[range][m_tempIndex];
	}
	;
	float GetUsageHystTemp(T_TC_USAGE_TEMPS range) {
		return TC_USAGE_TEMPS[range][m_tempIndex] - TC_USAGE_TEMPS[TC_TEMPS_HYSTERESIS][m_tempIndex];
	}
	;
	bool IsJOrNThermo(USHORT tcType) {
		return (tcType == AI_THERMO_RANGE_J) || (tcType == AI_THERMO_RANGE_N);
	}
	// Reload usage timers
	void ReloadUsageTimes(T_PTC_INFO pTCInfo);
	// Get number of uses remaining
	int GetUsesleft(T_PTC_INFO pTCInfo);
	// Post status messages to system message lists
	void PostDaysStatusChange(T_PTC_INFO pTCInfo);
	void PostUsesStatusChange(T_PTC_INFO pTCInfo);
	void PostCalStatusChange(T_PTC_INFO pTCInfo);
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
	void LogDebugMessage(QString   strDebugMessage);
#endif
#ifdef DBG_FILE_LOG_AMS_STATUS_MGR
	static CDebugFileLogger m_debugFileLogger;
	CDebugFileLogger* m_pDebugFileLogger;
#endif
private:
	// Singleton auto pointer
	static std::unique_ptr<CAMS2750TCStatusMgr> ms_kAMS2750TCStatusMgr;
	// Handle to the creation mutex
	static QMutex ms_hCreationMutex;
	// Variable indicating the minimum number of days allowable before expiry warnings are displayed
	USHORT m_usExpiryWarningUseLimitDays;
	// Variable indicating the minimum number of uses allowable before expiry warnings are displayed
	USHORT m_usExpiryWarningLimitUses;
	// Variable indicating the minimum number of days allowable before calibration expiry warnings 
	// are displayed
	USHORT m_usExpiryWarningCalibLimitDays;
	T_TCUSAGE_NV *m_pTCTimersNV;			// Pointer to TC timers NV
	T_TC_INFO m_TCInfo[MAX_ANALOGUE_IN];	// Information for each TC enabled to track
	T_PTC_INFO m_pTCbyAI[MAX_ANALOGUE_IN];	// Pointer to relevant m_TCInfo instance by TC number (0 based)
	int m_numTCs;							// Number of TC configured and valid for tracking.
	CAMS2750TUSMgr *m_pTUSMgr;				// Handle on TUS manager singleton
	BOOL m_IsActive;						// Is processing active
	int m_processCnt;						// Countdown for processing 
	int m_processReload;					// Reload time for processing
	int m_tempIndex;						// Temperature Index
	BOOL m_FirstIn;							// Check for first run though
	BOOL m_isInCalMode;
};
#endif

//************************************************************************************
// Module  AMS2750
// Filename  AMS2750ProcessCalFile.h
// Copyright GA Digital 2021
/// **********************************************************************************
/// @n Module: 	  AMS2750 file processing
/// @n Filename:  AMS2750ProcessCalFile.h
/// @n Description: Process information in Cal file for use in report 
///
// ***********************************************************************************
#ifndef _AMS2750PROCCALFILE_H
#define _AMS2750PROCCALFILE_H
#include "AMS2750DataStruct.h"
#include "AMS2750processTUSFile.h"
#include "V6crc.h"
class CAMS2750ProcessCalFile {
protected:
	T_P2750FILEHEADEROVERLAY m_pCalData;		// Pointer to data header at start of file
public:
	CAMS2750ProcessCalFile();
	~CAMS2750ProcessCalFile() {
		if (m_pCalData != NULL)
			delete m_pCalData;
	}
	// API methods
	// Initialise and validate
	void InitCalFile(void *pFilePtr);
	T_C2750PROCESSFILE_RES ValidateFile(T_STRUCTURE_IDENT &errStruct, int &instance);
	// Data and configuration structure access methods
	T_C2750PROCESSFILE_RES GetCalHeader(T_P2750FILEHEADER pCalHeader);
	T_C2750PROCESSFILE_RES GetGeneralCalibration(T_PAMS2750GENCAL ptrGeneralCal);
	T_C2750PROCESSFILE_RES GetSensorInputCalibrationResults(T_PSENSORINPUTCALDATA ptrSensorCal, int SensorID);
	void SetCalDataPtr(T_P2750FILEHEADEROVERLAY ptFileHeader) {
		m_pCalData = ptFileHeader;
	}
	// Method that confirms the whether the loaded cal is empty
	const bool CalIsEmpty();
	// Gets the internal cal file name
	QString GetInternalCalFilename();
protected:
	T_C2750PROCESSFILE_RES indexOfStruct(T_STRUCTURE_IDENT sType, int sInstance, int &theIndex);
	T_C2750PROCESSFILE_RES GetStruct(T_STRUCTURE_IDENT sType, int sInstance, void *structData, int structSize);
};
#endif //_AMS2750PROCCALFILE_H

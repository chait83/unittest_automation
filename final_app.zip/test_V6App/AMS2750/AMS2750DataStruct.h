//<************************************************************************************
//< Module  AMS2750
//< Filename  AMS2750DataStruct.h
//< Copyright GA Digital 2008
//</ **********************************************************************************
//</ @n Module: 	 AMS2750 data structures
//</ @n Filename:  AMS2750DataStruct.h
//</ @n Description: Data structures for the AMS2750 NADCAP TUS report 
//</
//< ***********************************************************************************
#ifndef _AMS2750DATASTRUCT_H
#define _AMS2750DATASTRUCT_H
#include "Defines.h"
// Structures are byte aligned
#pragma pack(push, prepack, 4)
const int TUSFILE_VERSION = 1;				//< Only change this number to check on file versions
const int NUM_SOAKS = 6;					//< Total number of soaks supported
const int NUM_TCS_PER_SOAK = 48;			//< Total number of TC's supported 47 + control TC.
const int NUM_TOTAL_LOGS = 2160;			//< Total number of logs, 2 per minute = 30 per hour = 2160 for 72 hours.
const float TUS_READING_ROGUE = 9999.0F;	//< Rogue reading value, indicates reading is invalid and not populated
// We need to pre-allocate the slots for the structure mappings, so we build up the total possible number of structures here
// in NUM_STRUCT_SLOTS, if adding a new structure then room in the structure map needs to be allocated
const int NUM_STRUCT_SLOTS = 1					//< Test Data main struct ST_TUSTESTDATA
+ NUM_SOAKS			//< Soak Test Data ST_TUSSOAKDATA
		+ 1					//< Test config ST_TUSTESTCONFIG
		+ NUM_TCS_PER_SOAK	//< Sensor config sturctures T_TUSSENSORCONFIG
		+ 1					//< General calibration structure T_AMS2750GENCAL
		+ NUM_TCS_PER_SOAK; //< Sensor calibration structures T_SENSORINPUTCALDATA
const int INVALID_SEQUENCE_NUM = 0;	//< Invalid sequence number used as roguie value, valid sequence numbers 1 to 2160
const float TUS_FURNACE_CLASS_C[] = { 3.0F, 6.0F, 8.0F, 10.0F, 14.0F, 28.0F };
const float TUS_FURNACE_CLASS_F[] = { 5.0F, 10.0F, 15.0F, 20.0F, 25.0F, 50.0F };
const int TUS_MIN_CLASS = 1;	//< Minimum class 1
const int TUS_MAX_CLASS = 6;	//< Maximum class 6
// Each structure held in the TUS file has it's own type, allocate new structure types at the bottom
// and do not change the list, as this is the versioning information for the structures.
typedef enum {
	ST_2750FILEHEADER = 0,//< Ident for T_2750FILEHEADER structure, not included in structure list but required for CRC reporting
	ST_TUSSOAKDATA,				//< Ident for T_TUSSOAKDATA structure
	ST_TUSTESTDATA,				//< Ident for T_TUSTESTDATA structure
	ST_TUSTESTCONFIG,			//< Ident for T_TUSTESTCONFIG test/furnace configuration
	ST_TUSSENSORCONFIG,			//< Ident for T_TUSSENSORCONFIG sensor/input configuration
	ST_TUSDATAREADINGHEADER,	//< Ident for T_TUSDATAREADINGHEADER data readings header
	ST_TUSDATAREADING,//< Ident for T_TUSDATAREADING structure, not included in structure list but required for CRC reporting
	ST_AMSGENCALDATA,			//< Ident for T_TUSGENCALDATA structure
	ST_AMSSENSORINPUTCALDATA	//< Ident for T_TUSSENSORINPUTCALDATA structure
} T_STRUCTURE_IDENT;
// Enum indicating the furnace type
typedef enum {
	ftPARTS, ftRAW_MATERIALS
} T_FURNACE_TYPE;
// Enum indicating the temperature type
typedef enum {
	ttDEG_C, ttDEG_F
} T_TEMPERATURE_TYPE;
// Enum indicating the furnace shape
typedef enum {
	fsRECTANGULAR, fsCYLINDRICAL, fsOTHER
} T_FURNACE_SHAPE;
// Enum indicating the TC/RT type
typedef enum {
	ttEXPENDABLE, ttNONEXPENDABLE, ttEXPENDABLE_RT, // Only used for exported TUS data (but is used internally for calibration data)
	ttNONEXPENDABLE_RT // Only used for exported TUS data (but is used internally for calibration data)
} T_TC_TYPE;
// Enum indicating the Instrument type A to E
typedef enum {
	INST_TYPE_A = 0, INST_TYPE_B, INST_TYPE_C, INST_TYPE_D, INST_TYPE_E,
} T_INST_TYPE;
typedef struct {
	USHORT ident;											//< Structure identifier of type T_STRUCTURE_IDENT
	USHORT instance;										//< Instance of structure
	USHORT length;											//< Length of structure in bytes
	USHORT crc;												//< CRC for structure
	ULONG startPos;									//< Start position of structure within file (bytes from top of file)
} T_TUSSTRUCTIDENT, *T_PTUSSTRUCTIDENT;
//-----------------------------------------------------------------------------------------------
// TUS Header information 
//-----------------------------------------------------------------------------------------------
// Main sections in the data file
// *** To ensure version compatability both forwards and backwards the T_2750FILEHEADER MUST not change after initial release unless "version" is used.
typedef struct {
	LONGLONG timeOfReport;									//< Time report was run
	ULONG offSetOfLogData;									//< Offset into file for the 2 minute Log data
	ULONG offsetOfExpansion;								//< Offset into file for a future expansion block
	USHORT version;											//< Version number of report file
	USHORT reportNumber;									//< report number		
	USHORT numStructures;									//< Number of structures following 
	USHORT crc;
} T_2750FILEHEADER, *T_P2750FILEHEADER;
// Overlay header for easy access to structure list
typedef struct {
	T_2750FILEHEADER fh;									//< File header
	T_TUSSTRUCTIDENT structList[NUM_STRUCT_SLOTS];	//< First element of structure list
} T_2750FILEHEADEROVERLAY, *T_P2750FILEHEADEROVERLAY;
//-----------------------------------------------------------------------------------------------
// Configuration Information
//-----------------------------------------------------------------------------------------------
const int TUSFURNACE_NAME_LEN = 40;						//< Length of Name - Furnace Name
const int TUSFURNACE_MANUFACTURER_LEN = 40;				//< Length of Manufacturer - Manufacturer Name
const int TUSFURNACE_MODELNO_LEN = 40;					//< Length of ModelNo - Model Number
const int TUSFURNACE_SURVINST_LEN = 40;					//< Length of survey instarument 
typedef struct {
	//< Recorder basec content
	ULONG recSerial;									//< Recorder serial number (RTHLD 6.3 Survey Instrument serial)
	USHORT tempasprintf;					//< Temperature units 0=Deg C 1=Deg F 2=Kelvin (RTHLD 6.3 Temperature units)
	USHORT dataInterval;					//< Data Interval in Seconds, fixed default will be 120seconds (2 minutes)
	//< Test based content
	USHORT Type;							//< 0-Parts 1-Raw material	(RTHLD 6.3 used to derive next survey due time )
	USHORT FurnaceClass;	//< Class 1-6				(RTHLD 6.4 and RTHLD 6.3 used to derive next survey due time)
	USHORT InstType;//< Instrument type (1 to 5 corrisponding to A to E) (RTHLD 6.3 used to derive next suggested survey time )
	USHORT padding;										//< 
	WCHAR name[TUSFURNACE_NAME_LEN];					//< Furnace ID/Name (RTHLD 6.4)
	WCHAR manufacturer[TUSFURNACE_MANUFACTURER_LEN];	//< Manufacturer Name( RTHLD 6.4)
	WCHAR modelNo[TUSFURNACE_MODELNO_LEN];				//< Model Number( RTHLD 6.4)
	WCHAR surveyInst[TUSFURNACE_SURVINST_LEN];			//< Survey instrument (RTHLD 6.3 Survey instrument type)
	USHORT Shape;										//< Shape 0-rectangular 1-cylindrical 2-other
	USHORT MeasUnits;						//< Measurement units 0-metres 1-feet 2-millimetres 3-inches (RTHLD 6.10)
	USHORT controlTCNumber;								//< Number of the control TC 1 to 48
	USHORT numberOfSensors;				//< Number of sensors included (will include control TC if configured as such)
	float height;										//< Height in MeasUnits (RTHLD 6.10)
	float width;										//< Width in MeasUnits (RTHLD 6.10)
	float depth;										//< Depth in MeasUnits (RTHLD 6.10)
	float volume;										//< Volume in MeasUnits cubed (RTHLD 6.10)
} T_TUSTESTCONFIG, *T_PTUSTESTCONFIG;
//-----------------------------------------------------------------------------------------------
// Calibration Information
//-----------------------------------------------------------------------------------------------
const int AMS2750GENCAL_RECORDER_NAME_LEN = 32;					  //< Length of the recorder name
const int AMS2750GENCAL_CALIBRATORTYPE_LEN = 32;  //< Length of CalibratorType - Calibrator type
const int AMS2750GENCAL_CALIBRATORSERNO_LEN = 32;  //< Length of CalibratorSerNo - Calibrator serial number
const int AMS2750GENCAL_qDebugABLETO_LEN = 32; //< Length of TraceableTo - Statement of traceability to NIST or other internationally recognized body
const int AMS2750GENCAL_TECHNICIANID_LEN = 32; //< Length of TechnicianId - The ID of the technician performing the calibration
const int AMS2750GENCAL_CALPERFORMEDBY_LEN = 32;  //< Length of CalPerformedBy - Company perfoming the calibration
const int AMS2750GENCAL_CALPERFORMEDFOR_LEN = 32; //< Length of CalPerformedFor - Company the calibration was performed for
const int AMS2750GENCAL_QUALITYORG_LEN = 32;  //< Length of QualityOrg - Quality Organisation
const int AMS2750GENCAL_CALPOINTS_SIZE = 9;  //< Length of CalPoints - Calibration points array
typedef struct {
	float CalPoint;  ///< Sensor calibration point in degrees C
	float Offset; ///< The offset from the cal point
} T_AMS2750CALPOINTS, *T_PAMS2750CALPOINTS;
// Enum indicating the current calibration state
typedef enum {
	GCS_PASSED,				//< The sensor passed it's calibration and is valid
	GCS_FAILED,				//< The sensor was calibrated but it failed, presumably due to a too large cumulative error
	GCS_INVALID,			//< There is one or more invalid sensor calibration that has invalidated the entire cal.
	GCS_NOT_CALED,			//< No cal has been found/performed
} T_GENERAL_CAL_STATE;
typedef struct {
	// general cal information
	ULONG Id;													//< The id of the recorder
	ULONG SerialNo;											//< The recorder serial no.
	WCHAR Name[AMS2750GENCAL_RECORDER_NAME_LEN];				//< The recorder name
	USHORT CalState;//< Indicates if the calibration passed, failed or has another type of error as per T_SENSOR_CAL_STATE
	USHORT CalElements;										//< The number of cal elements currently in use
	WCHAR CalibratorType[AMS2750GENCAL_CALIBRATORTYPE_LEN];	//< Calibrator type
	WCHAR CalibratorSerNo[AMS2750GENCAL_CALIBRATORSERNO_LEN];	//< Calibrator serial number
	WCHAR TraceableTo[AMS2750GENCAL_qDebugABLETO_LEN];//< Statement of traceability to NIST or other internationally recognized body
	WCHAR TechnicianId[AMS2750GENCAL_TECHNICIANID_LEN];		//< The ID of the technician performing the calibration
	WCHAR CalPerformedBy[AMS2750GENCAL_CALPERFORMEDBY_LEN];	//< Company perfoming the calibration
	WCHAR CalPerformedFor[AMS2750GENCAL_CALPERFORMEDFOR_LEN];	//< Company the calibration was performed for
	WCHAR QualityOrg[AMS2750GENCAL_QUALITYORG_LEN];			//< Quality Organisation
	ULONG TestDate;										//< Date the calibration was last performed (stored in seconds)
	ULONG NextCalDate;										//< Date of the next calibration (stored in seconds)
	USHORT TempFormat;											//< Temperature units 0=Deg C 1=Deg F 2=Kelvin
	USHORT AMS2750Mode;				//< The AMS2750 mode when the calibration mode was performed, 0 - TUS, 1 - Process
	T_AMS2750CALPOINTS CalPoints[AMS2750GENCAL_CALPOINTS_SIZE];			//< Calibration points array
} T_AMS2750GENCAL, *T_PAMS2750GENCAL;
// Enum indicating the current calibration state
typedef enum {
	TCS_PASSED,				//< The sensor passed it's calibration and is valid
	TCS_FAILED,			//< The sensor was calibrated but it failed, presumably due to a too large cumulative error
} T_INPUT_TEMP_CAL_STATE;
// Cal data point for each individual sensor input
typedef struct {
	float PrevInputAdjust;		//< The previous input adjustment for the given cal temperature
	float NewInputAdjust;		//< The new (and now presumably current) input adjustment for the given cal temperature
	float MeasuredTemp;	//< The measured temperature during the calibration i.e. with the previous input adjustment applied
	float NewMeasuredTemp;//< The new measured temperature during the calibration i.e. with the new input adjustment applied
	USHORT CalState;		//< Indicates if the sensor passed (0) or failed the calibration (1) at this calibration 
							// <temperature. Has scope for other error codes as per T_SENSOR_TEMP_CAL_STATE
	USHORT Padding;
} T_SENSOR_INPUT_CALPOINTDATA, *T_PSENSOR_INPUT_CALPOINTDATA;
// Enum indicating the current calibration state
typedef enum {
	SCS_PASSED,					//< The input passed it's calibration and is valid
	SCS_FAILED,				//< The input was calibrated but it failed, presumably due to a too large cumulative error
	SCS_SENSOR_DISABLED,	//< The input was calibrated but it has been disabled - not a failure of the overall cal.
	SCS_NO_LONGER_AMS_SENSOR,	//< The sensor is no longer an AMS2750 sensor
	SCS_SENSOR_INPUT_TYPE_CHANGED,//< The sensor type has changes (different TC or RT type, differ sensor type itself etc.)
	SCS_CAL_DATE_CHANGED,//< The input calibration date differs to that of the main calibration - takes precedence over the next value
	SCS_CAL_VALUES_DIFFER,//< The input calibration values differ to those that were cal'ed, thus invalidating the sensors entire cal
	SCS_CAL_NOT_INIT,//< The input is not configured as an AMS sensor, be it due to it being disabled, not an RT/TC etc.
	SCS_CAL_INPUT_NOT_CALED	//< The input is an AMS sensor but it has not been cal'ed, ever, presumably because it was disabled or 
							//< not an AMS sensor during other cal processes
} T_SENSOR_INPUT_CAL_STATE;
// Cal data for each individual sensor
typedef struct {
	USHORT Type;				//< Sensor Type 0-Expendable 1-Non-Expendable, RT 2-Expendable, RT 3-Non-Expendable
	USHORT SensorType;			//< The sensor type i.e. Type K, Type J, PT 100 etc. The above specifies if TC or RT. 
								//< The values of this match those of the recorder i.e. AI_THERMO_RANGE_K, AI_RT_RANGE_PT100 etc.
	USHORT NoOfCalTemps;		//< The number of valid calibration points
	USHORT CalState;//< Indicates if the sensor passed, failed the calibration or is invalid as per T_SENSOR_CAL_STATE
	ULONG LastCalDate;			//< Date the calibration was performed (stored in seconds since epoch)
	T_SENSOR_INPUT_CALPOINTDATA CalPoints[AMS2750GENCAL_CALPOINTS_SIZE];	//< The cal information for each 
} T_SENSORINPUTCALDATA, *T_PSENSORINPUTCALDATA;
/// Stores sensor input cal data along with its sensor number for internal messaging purposes only, not required externally
typedef struct {
	USHORT sensorNo;		//< The sensor number
	USHORT padding;
	T_SENSORINPUTCALDATA sensorInputCal;
} T_SENSORINPUTCALDATAMSG;
const int CAL_MAX_FILE_SIZE = sizeof(T_AMS2750GENCAL) + (NUM_TCS_PER_SOAK * sizeof(T_SENSORINPUTCALDATA)) + 512;//< allocate approx 10K 
const int TUS_MAX_FILE_SIZE = 512 * 1024 + CAL_MAX_FILE_SIZE;	//< allocate a 522 KB or so file buffer
const int TUSSENSOR_SERIALNO_LEN = 40;					//< Length of SerialNo - Batch or serial number
const int TUSSENSOR_TCPOSITION_LEN = 20;  //< Length of TCPosition - TC position
const int TUSSENSOR_MANUFACTURER_LEN = 20; //< Length of Manufacturer - Manufacturer Name
const int TUSSENSOR_CERTNUMBER_LEN = 20;  //< Length of CertNumber - Certificate number
const int TUSMPCALCHANNEL_CALPOINTS_SIZE = 9;			//< The number of multipoint calibration points
/**MultiPoint calibration point*/
typedef struct _tusmpcalpoint {
	float CalPoint;  ///< Calibration point in engineering units
	float Offset; ///< The offset from the cal point
	float PrevOffset; ///< The previous offset from the cal point
} T_TUSMPCALPOINT;
/**MultiPoint calibration for a channel*/
typedef struct _tusmpcalchannel {
	ULONG CalElements;  ///< Number of calibration points/elements
	T_TUSMPCALPOINT CalPoints[TUSMPCALCHANNEL_CALPOINTS_SIZE]; ///< Calibration points array
} T_TUSMPCALCHANNEL;
typedef struct {
	USHORT TCNumber;									//< Internal ident of the TC
	USHORT type;						//< TC Type 0-Expendable 1-Non-Expendable, RT 2-Expendable, RT 3-Non-Expendable
	ULONG colour;										//< Colour of trace as COLORREF
	WCHAR serialNo[TUSSENSOR_SERIALNO_LEN];				//< Batch or serial number (RTHLD 6.7)
	WCHAR TCPosition[TUSSENSOR_TCPOSITION_LEN];			//< TC position (RTHLD 6.10)
	WCHAR manufacturer[TUSSENSOR_MANUFACTURER_LEN];		//< Manufacturer Name (RTHLD 6.7)
	WCHAR certNumber[TUSSENSOR_CERTNUMBER_LEN];			//< Certificate number (RTHLD 6.7)
	T_TUSMPCALCHANNEL multiPointCal;					//< Recorder channel calibration, as found as left
} T_TUSSENSORCONFIG, *T_PTUSSENSORCONFIG;
//-----------------------------------------------------------------------------------------------
// Test Data Information
//-----------------------------------------------------------------------------------------------
// TUS test status
typedef enum {
	TUS_NOTSTARTED = 0,			//< The TUS has not been started yet
	TUS_PASSED,					//< The TUS passed as configured
	TUS_FAIL_USER_ABORT,		//< The TUS failed due to user aborting before run completed
	TUS_FAIL_TIMEDOUT,			//< The TUS failed due to incomplete test after 72 hours
	TUS_FAIL_SOAK_FAIL,			//< The TUS failed due to one or more soaks being out of spec
	TUS_RUNNING,				//< Runtime status, tus is currently running
} T_TUS_TEST_STATUS;
// Test status for each soak.
typedef enum {
	SOAK_STATUS_NOTENABLED = 0,	//< A soak has not been enabled
	SOAK_STATUS_NOTSTARTED,		//< A soak has not been completed
	SOAK_STATUS_PASSED,			//< A soak passed the uniformity test
	SOAK_STATUS_FAILED,			//< A soak failed the uniformity test
	SOAK_STATUS_INCOMPLETE,		//< A soak test was incomplete
	SOAK_STATUS_ABORTED,		//< User aborted during this soak
	SOAK_STATUS_SOAK_DETECT,	//< Runtime status, The next soak to be run, currently being detected
	SOAK_STATUS_IN_SOAK,		//< Runtime status, in soak but not in stability yet
	SOAK_STATUS_IN_STABILITY,	//< Runtime Status, in soak and in stability
} T_SOAK_STATUS;
// Indicator on how stability was achieved.
typedef enum {
	SOAK_STABILITY_NONE = 0,	//< Stability for this soak not achieved
	SOAK_STABILITY_MANUAL,		//< Stability achieved by user manually setting
	SOAK_STABILITY_AUTO,		//< Stability in soak achieved using the automatic algorithm
	SOAK_STABILITY_TIMED		//< Stability achieved using the timer
} T_SOAK_STABILITY;
// Results for a soak
typedef struct {
	LONGLONG rampTime;							//< the ramp time for the soak as a TVTime (RTHLD 6.15)
	LONGLONG lagTime;							//< the lag time for the soak as a TVTime (RTHLD 6.16)
	LONGLONG soakTime;							//< Total soak length
	LONGLONG stabilityAchieved;	//< Point in time that stability was achieved or set (use stabilityStatus for how it was achieved)
	USHORT soakStatus;							//< overall status of the soak of type T_SOAK_STATUS
	USHORT stabilityStatus;						//< How stability was achieved of type T_SOAK_STABILITY
	float setPoint;								//< The set point for the soak in degrees (RTHLD 6.6 Temperature column)
	float tolerance;							//< the tolerance for the soak +/- degrees (RTHLD 6.6 tolerance column)
	float maxTempDiffAcrossTCs;					//< Max temp diff across all TC's during stabilised soak (RTHLD 6.12)
	float maxTempDiffTCtoSetP;		//< Max temp diff across all TC's to set point during stabilised soak (RTHLD 6.13)
	float maxOvershootVal;						//< Maximum overshoot value.
	USHORT maxTempDiffTCtoSetPNum;				//< Number OF TC who's deviation was greatest from SP
	USHORT overShootTCNum;						//< Number of TC who's overshoot was greatest
	USHORT maxTCnum;				//< Number of TC that recorded max temperature during soak stability (limit TC 6.11)
	USHORT minTCnum;				//< Number of TC that recorded max temperature during soak stability (limit TC 6.11)
	float maxTCval;							//< Max temperature value hit during soak stability (limit TC value 6.11)
	float minTCval;							//< Min temperature value hit during soak stability (limit TC value 6.11)
	USHORT classMet;							//< Class of furnace achived (RTHLD 6.17)
	USHORT Instance;							//< Self referencing instance number
	USHORT startSeqNo;		//< Sequence number of T_TUSDATAREADING for start of logged data for the soak (0 = Invalid)
	USHORT endSeqNo;		//< Sequence number of T_TUSDATAREADING for end of logged data for the soak (0 = Invalid)
} T_TUSSOAKTEST, *T_PTUSSOAKTEST;
// Data for each individual TC for each soak
typedef struct {
	float maxInSoak;	//< The max value of the TC in soak and in stability (not overshoot) (RTHLD 6.11 Max column)
	float minInSoak;	//< The min value of the TC in soak and in stability (not undershoot) (RTHLD 6.11 Min column)
	float shootValue;//< Under or overshoot value (i.e the max value obtained before entering stability mode) (RTHLD 6.14)
	float tcAccuracy;	//< the applied calibration level for the TC at this set point, from the cal table (RTHLD 6.8)
	float recAccuracy;//< the applied calibration level for the instrument at this set point, from the single/dial point cal (RTHLD 6.9)
} T_TCDATAFORSOAK, *T_PTCDATAFORSOAK;
// Data for single soak.
typedef struct {
	T_TUSSOAKTEST test;							//< Test Data for the soak
	T_TCDATAFORSOAK tcData[NUM_TCS_PER_SOAK];	//< TC data for soak
} T_TUSSOAKDATA, *T_PTUSSOAKDATA;
const int TUS_ENGINEER_NAME_LEN = 20;			//< Length of survey engineer name
const int TUS_NOTES = 150;						//< Length of start and end notes in survey
// Test data section header
typedef struct {
	LONGLONG startTime;							//< Start time of TUS (RTHLD 6.3 Start time and date)
	LONGLONG endTime;							//< End time and Dtae ( RTHLD 6.3 end time and date )
	LONGLONG newSurveyDue;						//< Due date of next survey ( RTHLD 6.3 new survey due )
	WCHAR userName[TUS_ENGINEER_NAME_LEN];	//< name of survey engineer, logged in user ( RTHLD 6.3 Survey engineer )
	WCHAR startNotes[TUS_NOTES];		//< free format notes taken from user at start of TUS (RTHLD 6.18 pre-comments)
	WCHAR endNotes[TUS_NOTES];			//< Free format notes taken from user at end of TUS (RTHLD 6.18 post-comments)
	USHORT overallStatus;						//< Overall test status of type T_TUS_TEST_STATUS
	USHORT numSoaks;							//< Total number of soaks available
} T_TUSTESTDATA, *T_PTUSTESTDATA;
//-----------------------------------------------------------------------------------------------
// Log Data section 
//-----------------------------------------------------------------------------------------------
// Status for each log reading
typedef enum {
	LOG_STATUS_INVALID = 0,					//< LOg record is not valid		
	LOG_STATUS_RESTART,				//< Log record is caused after a restart (power failure so time will be different)
	LOG_STATUS_NORMAL						//< Log record is normal and in sequence		
} T_LOGREADING_STATUS;
// Data reading header, 
// *** the T_TUSDATAREADINGHEADERstructure cannot change after initial release ***
typedef struct {
	USHORT numOfReadings;	//< Number of lines of data readings (i.e. number of T_TUSDATAREADING structures to follow )
	USHORT crc;								//< crc of log data block
} T_TUSDATAREADINGHEADER, *T_PTUSDATAREADINGHEADER;
// Log data redings for a single time (every 2 mins)
typedef struct {
	LONGLONG logTimeStamp;					//< Timestamp of readings (every 2 minutes, aligned to the even minute)
	float TCReading[NUM_TCS_PER_SOAK];		//< A row of readings for all possible TC's ( RTHLD 6.19 )
	USHORT sequenceNumber;					//< Sequence number from 1 to 2160 ( 72 hours worth of 2 minute readings )
	USHORT status;							//< Status of log record, of type T_LOGREADING_STATUS
	USHORT paddingExp;//< PAdding but also usable for expansion if additional information is required in future (events etc..)
	USHORT crc;
} T_TUSDATAREADING, *T_PTUSDATAREADING;
// Overlay header for easy access to structure list
typedef struct {
	T_TUSDATAREADINGHEADER lh;				//< Log header
	T_TUSDATAREADING logReading[1];			//< Log readings overlay
} T_2750LOGDATAOVERLAY, *T_P2750LOGDATAOVERLAY;
// Put back the original packing from the stack				 
#pragma pack(pop, prepack)
#endif // _AMS2750DATASTRUCT_H

//************************************************************************************
// Module  AMS2750
// Filename  AMS2750buildTUSFile.h
// Copyright GA Digital 2008
/// **********************************************************************************
/// @n Module: 	  AMS2750 fie processing
/// @n Filename:  AMS2750buildTUSFile.h
/// @n Description: Build information into TUS data file 
///
// ***********************************************************************************
#include "AMS2750processTUSFile.h"
#include "TVtime.h"
#include "Conversion.h"
#include "V6ActiveModule.h"
#include "CStorage.h"
#include "ModuleConstants.h"
#ifndef __C2750BUILDTUSFILE_H__
#define __C2750BUILDTUSFILE_H__
// Build TUS file results
typedef enum {
	BF_OK = 0,					// Generic ok, no errors
	BF_FAILED,					// Generic Failure
	BF_STRCUTURE_MAP_FULL,	// No more room in structure map, need to add more structure space using NUM_STRUCT_SLOTS
	BF_FILE_ALLOCATION_FULL,	// File allocation is full, exceeded TUS_MAX_FILE_SIZE
} T_C2750BUILDFILE_RES;
/// Enumeration for the Operational mode of the Message List Processing Module
typedef enum _eTUSFileBuilderOperationalMode {
	tfbOPMODE_IDLE, tfbOPMODE_NORMAL_OPERATION, tfbOPMODE_EXIT
} T_TUS_FILE_BUILDER_OPERATIONAL_MODE;
//**C2750BuildTUSFile**************************************************
/// 
/// @brief V6 Active module responsible for processing TUS file building
/// commands
///
/// V6 Active module responsible for processing TUS file building commands
///
//****************************************************************************
class C2750BuildTUSFile: C2750parseTUSFile, public CV6ActiveModule {
private:
public:
	// Constructor
	C2750BuildTUSFile(const T_MODULE_ID eMODULE_ID);
	// Destructor
	~C2750BuildTUSFile();
	// Method that initialises the file space
	T_C2750BUILDFILE_RES initFileSpace();
	// Method that adds the test configuration structure to the file
	T_C2750BUILDFILE_RES AddTestConfigStructure(T_PTUSTESTCONFIG pStruct);
	// Method that adds a sensor configuration structure to the file
	T_C2750BUILDFILE_RES AddSensorConfigStructure(T_PTUSSENSORCONFIG pStruct, int instance);
	// Method that adds the test data structure to the file
	T_C2750BUILDFILE_RES AddTestDataStructure(T_PTUSTESTDATA pStruct);
	// Method that adds a soak test data structure to the file
	T_C2750BUILDFILE_RES AddSoakDataStructure(T_PTUSSOAKDATA pStruct, int instance);
	// Method that adds the general calibration data structure to the file
	T_C2750BUILDFILE_RES AddGeneralCalibrationStructure(T_PAMS2750GENCAL pStruct);
	// Method that adds a sensor input calibration results structure to a file
	T_C2750BUILDFILE_RES AddSensorInputCalibrationStructure(T_SENSORINPUTCALDATA *pStruct, int instance);
	// Method that updates the CRC in the log header
	void UpdateCRCForLogHeader(T_PTUSDATAREADINGHEADER pLogHeader);
	// Method that updates the CRC in the log readings
	void UpdateCRCForLogReading(T_PTUSDATAREADING pLogReading);
	// Method that validates (and creates if it does not exist) the TUS data file
	const bool InitialiseTUSFile();
	// Method that clears the TUS data file usually at the start of a TUS
	void ClearTUSDataFile();
	// Method that sets up and saves the log data header structure (this will happen once all the configuration 
	// data has been written)
	void SetupLogHeader();
	/// ********************* ///
	/// ACTIVE MODULE METHODS ///
	/// ********************* ///
	// Get the Operational State of the TUS file builder
	inline const T_TUS_FILE_BUILDER_OPERATIONAL_MODE GetOperationalState(void) const {
		return (m_eOperationalMode);
	}
	// Primary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	// Secondary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	// Method called when Module goes into Normal Operation
	virtual T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	// Method called when Module is to prepare for Setup Config Change 
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	// Method called when Module is to carry out Setup Change Completion
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	// Method called when a Module is to prepare for Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	// Method called when a Module is to Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE Shutdown(void);
	// Carries out the desired function when a message is received
	virtual T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler(const CMsgQueueMessage *pMsg);
private:
	// Method that adds the specified structure to the TUS file
	T_C2750BUILDFILE_RES addStruct(void *structPtr, int structSize, T_STRUCTURE_IDENT structIdent, int structInstance);
	// Method that updates the CRC in the TUS file following the addition of a structure
	void UpdateCRCOnStructure(int sIndex, void *structPtr);
	// Method that updates the CRC in the header of the TUS file
	void UpdateHeaderCRC();
	// Method that writes the header information to disk
	void WriteHeaderToDisk();
	// Method that logs a file error and deletes the TUS data file
	void TUSDataFileError(const QString &rstrERROR);
	// Method that adds a log reading to the file
	void LogReading(T_TUSDATAREADING &rtDataReading);
	// Method that validates the file
	T_C2750PROCESSFILE_RES ValidateTUSFile(T_STRUCTURE_IDENT &errStruct, int &instance);
	///< Operational Mode for the Module
	T_TUS_FILE_BUILDER_OPERATIONAL_MODE m_eOperationalMode;
	/// The TUS data filename
	static const WCHAR m_wcaTUS_DATA_FILENAME[ MAX_PATH];
	/// The complete TUS data filename including path
	WCHAR m_wcaPathAndFileName[MAX_PATH];
	// Flag indicating if the TUS file is in an operational state (i.e. the file is open and writeable etc)
	bool m_bInitialised;
	// Storage class for the TUS data file
	CStorage m_kTUSDataFile;
	// Structure containing a local copy of the file header information 
	T_2750FILEHEADEROVERLAY m_tFileHeader;
	// Structure containing a local copy of the log header information
	T_2750LOGDATAOVERLAY m_tLogHeader;
};
#endif

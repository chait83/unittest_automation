/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 data processing
/// @n Filename:  AMS2750TimerCtrlMgr.h
/// @n Description: Implementation of the CAMS2750TimerCtrlMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Aristos  1.0.1.3.1.0 9/19/2011 4:51:06 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  5 Stability Project 1.0.1.3 7/2/2011 4:55:23 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:37:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:08 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "StringDefinitions.h"
#include "AMS2750TimerCtrlMgr.h"
#include "EventManager.h"
#include "ThreadInfo.h"

// Static const/initialsation
std::unique_ptr<CAMS2750TimerCtrlMgr> CAMS2750TimerCtrlMgr::ms_kAMS2750TimerCtrlMgr;
QMutex CAMS2750TimerCtrlMgr::ms_hCreationMutex;
//****************************************************************************
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CAMS2750TimerCtrlMgr* CAMS2750TimerCtrlMgr::Instance() {
	// check if the pointer exists yet
	if (ms_kAMS2750TimerCtrlMgr.get() == NULL) {
		DWORD waitSingleObjectResult = WAIT_OBJECT_0;
		// An instance has yet to be completed
		waitSingleObjectResult = ms_hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == ms_kAMS2750TimerCtrlMgr.get()) {
				// not been created yet therefore create one now
                ms_kAMS2750TimerCtrlMgr  = std::unique_ptr<CAMS2750TimerCtrlMgr>(new CAMS2750TimerCtrlMgr());
			}
			ms_hCreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, "CAMS2750TimerCtrlMgr WaitForSingleObject Error", "Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return ms_kAMS2750TimerCtrlMgr.get();
}
//****************************************************************************
///
/// Constructor
///
//****************************************************************************
CAMS2750TimerCtrlMgr::CAMS2750TimerCtrlMgr() : m_usEXPIRY_WARNING_CALIB_LIMIT_DAYS(5) {
}
//****************************************************************************
/// Intitialise the timers from startup
///
/// @return nothing
//****************************************************************************
void CAMS2750TimerCtrlMgr::Initialise() {
	m_pTUSMgr = CAMS2750TUSMgr::Instance();
	m_pTimerNV = m_pTUSMgr->GetTimersNVPtr();
	CTVtime defaultTime;
	defaultTime.TimeNow();
	for (int GroupIndex = 0; GroupIndex < BATCH_GROUPINFO_SIZE; GroupIndex++) {
		for (int typeIndex = 0; typeIndex < AMS2750_TIMER_TYPE_MAX_TIMERS; typeIndex++) {
			// If dueDate has been zeroed - set it up.
			if (m_pTimerNV->timer[GroupIndex][typeIndex].dueDate == 0) {
				m_pTimerNV->timer[GroupIndex][typeIndex].dueDate = USEC_TO_SEC(defaultTime.GetMicroSecs());
			}
			m_daysleft[GroupIndex][typeIndex] = 0;
		}
	}
}
//****************************************************************************
/// Configure the timers on startup and after each configuration change
///
/// @return nothing
//****************************************************************************
void CAMS2750TimerCtrlMgr::Configure() {
	m_processCnt = 1;
	m_processReload = pSYSTIMER->GetProcessSlicesPerSecond() * AMS2750_TIMER_PROCESS_SECONDS;
	// Check that AMS2750 mode is available
	if (pSYSTEM_INFO->GetAMS2750Mode() == AMS2750_NONE) {
		m_IsActive = FALSE;		// No AMS2750 option selected, do not process
	} else {
		m_IsActive = TRUE;		// AMS2750 option selected, allow processing
	}
}
//****************************************************************************
/// Process the timers
///
/// @return nothing
//****************************************************************************
void CAMS2750TimerCtrlMgr::Process() {
	// Is the process active
	if (m_IsActive == TRUE) {
		// Yes, has a the divide down timer expired
		if (--m_processCnt <= 0) {
			// Process the timers
			if (ProcessTimers() == TRUE) {
				// If a change has been detected, issue a refresh to the screen
				/// TODO repaint the screen
				AfxGetApp()->GetMainWnd()->PostMessage(WM_OPPANEL_REPAINT, (WPARAM) 0, (LPARAM) 0);
			}
			m_processCnt = m_processReload;
		}
	}
}
//****************************************************************************
/// Process all timers for each furnace (group)
///
/// @return TRUE if a timer has changed state or number of days changed
//****************************************************************************
BOOL CAMS2750TimerCtrlMgr::ProcessTimers() {
	BOOL updateRequired = FALSE;
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// Yes process the timers
	for (int GroupIndex = 0; GroupIndex < BATCH_GROUPINFO_SIZE; GroupIndex++) {
		for (int typeIndex = 0; typeIndex < AMS2750_TIMER_TYPE_MAX_TIMERS; typeIndex++) {
			// Store previous states to detect a change
			short prevDaysleft = m_daysleft[GroupIndex][typeIndex];
			USHORT prevTimerStatus = m_pTimerNV->timer[GroupIndex][typeIndex].status;
			// Calculate the number of days left.
			CTVtime kNextCalDate(
					static_cast<LONGLONG>(GetTimerCalDate((T_AMS2750_TIMER_TYPES) typeIndex, GroupIndex))
							* USEC_IN_A_SEC);
			kNextCalDate -= pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			// check if the time is negative
			if (kNextCalDate.GetSeconds() < 0) {
				LONGLONG roundingAdjust = static_cast<LONGLONG>(SEC_TO_USEC(
						static_cast< LONGLONG >( SECONDS_IN_A_DAY-1 )));
				kNextCalDate -= roundingAdjust;
			}
			m_daysleft[GroupIndex][typeIndex] = SEC_TO_DAY(kNextCalDate.GetSeconds());
			// Check for status on the timers.
			if (m_pTimerNV->timer[GroupIndex][typeIndex].status != TIMER_DISABLED) {
				if (m_daysleft[GroupIndex][typeIndex] > m_usEXPIRY_WARNING_CALIB_LIMIT_DAYS) {
					m_pTimerNV->timer[GroupIndex][typeIndex].status = TIMER_GOOD;
				} else if (m_daysleft[GroupIndex][typeIndex] >= 0) {
					m_pTimerNV->timer[GroupIndex][typeIndex].status = TIMER_WARNING;
				} else {
					m_pTimerNV->timer[GroupIndex][typeIndex].status = TIMER_EXPIRED;
				}
			}
			// If number of dyas change or a timer status changes, set an update required
			if (prevDaysleft != m_daysleft[GroupIndex][typeIndex]
					|| prevTimerStatus != m_pTimerNV->timer[GroupIndex][typeIndex].status) {
				updateRequired = TRUE;
				// If status has changed, post message and trigger event cause
				if (prevTimerStatus != m_pTimerNV->timer[GroupIndex][typeIndex].status) {
					PostStatusChange(GroupIndex, (T_AMS2750_TIMER_TYPES) typeIndex,
							(T_AMS2750_TIMER_STATUS) m_pTimerNV->timer[GroupIndex][typeIndex].status);
				}
			}
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the DataProcessing
				//thread 
				pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
			}
		}
	}
	return updateRequired;
}
//****************************************************************************
///
/// Method that returns the number of days remaining until the calibration date
///
/// @param[in]	const T_AMS2750_TIMER_TYPES eTIMER_TYPE - The timer type we are checking
/// @param[in]	const USHORT usGROUP_NO - The timers group number
///
/// @return The number of days until the due calibration date - could be negative
///
//****************************************************************************
const long CAMS2750TimerCtrlMgr::GetDaysUntilCalExpiry(const T_AMS2750_TIMER_TYPES eTIMER_TYPE,
		const USHORT usGROUP_NO) {
	return m_daysleft[usGROUP_NO][eTIMER_TYPE];
}
//****************************************************************************
///
/// Method that enables the selected timer
///
/// @param[in]	const T_AMS2750_TIMER_TYPES eTIMER_TYPE - The timer type we are checking
/// @param[in]	const USHORT usGROUP_NO - The timers group number
///
//****************************************************************************
void CAMS2750TimerCtrlMgr::EnableTimer(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO) {
	m_pTimerNV->timer[usGROUP_NO][eTIMER_TYPE].status = TIMER_GOOD;
}
//****************************************************************************
///
/// Method that disables the selected timer
///
/// @param[in]	const T_AMS2750_TIMER_TYPES eTIMER_TYPE - The timer type we are checking
/// @param[in]	const USHORT usGROUP_NO - The timers group number
///
//****************************************************************************
void CAMS2750TimerCtrlMgr::DisableTimer(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO) {
	m_pTimerNV->timer[usGROUP_NO][eTIMER_TYPE].status = TIMER_DISABLED;
}
//****************************************************************************
/// Get the furnace class tolerance achieved for each soak.
///
/// @param[in]	IsTUS - TRUE if required for TUS , otrherwise it's a SAT
/// @param[in]	pFurnace - pointer to furnace config for interval calculations
///
/// @return		Interval in seconds for next sat or tus
//****************************************************************************
ULONG CAMS2750TimerCtrlMgr::GetNextTestInterval(BOOL IsTUS, T_PFURNACE pFurnace) {
	return m_pTUSMgr->GetNextTestInterval(IsTUS, pFurnace);
}
//****************************************************************************
/// Get the furnace class tolerance achieved for each soak.
///
/// @param[in]	IsTUS - TRUE if required for TUS , otrherwise it's a SAT
/// @param[in]	pFurnace - pointer to furnace config for interval calculations
///
/// @return		Interval in seconds for next sat or tus
//****************************************************************************
void CAMS2750TimerCtrlMgr::PostStatusChange(int GroupIndex, T_AMS2750_TIMER_TYPES typeIndex,
		T_AMS2750_TIMER_STATUS status) {
	// Get the name of the timer
	QString typeName;
	switch (typeIndex) {
	case AMS2750_TIMER_TYPE_TUS:
		typeName = "TUS Timer";
		break;
	case AMS2750_TIMER_TYPE_SAT:
		typeName = "SAT Timer";
		break;
	case AMS2750_TIMER_TYPE_INST_CAL:
		typeName = "Instrument Cal Timer";
		break;
	case AMS2750_TIMER_TYPE_CONTROL_TC:
		typeName = "Control TC Timer";
		break;
	}
	QString statusMessage;
	char *pstr = typeName.toLocal8Bit().data();
	if (status == TIMER_WARNING) {
		// Message on warning and trigger event cause
		statusMessage = QString::asprintf(IDS_TIMER_STATUS_MGR_TIMER_WARNING, pstr, GroupIndex + 1);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaPROCESS_TIMER, eatWarning);
	} else if (status == TIMER_EXPIRED) {
		// Message on expired and trigger event cause
		statusMessage = QString::asprintf(IDS_TIMER_STATUS_MGR_TIMER_EXPIRED, pstr, GroupIndex + 1);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, statusMessage);
		pEVENTS->AMS2750TimerEventTrigger(ecaPROCESS_TIMER, eatExpired);
	}
}

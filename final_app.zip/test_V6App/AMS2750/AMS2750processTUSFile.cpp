//************************************************************************************
// Module Ã¯¿½ AMS2750
// Filename Ã¯¿½ AMS2750processTUSFile.cpp
// Copyright GA Digital 2008
/// **********************************************************************************
/// @n Module: 	  AMS2750 file processing
/// @n Filename:  AMS2750processTUSFile.cpp
/// @n Description: Process information in TUS file for use in report 
///
// ***********************************************************************************
#include "AMS2750processTUSFile.h"
//****************************************************************************************
/// Constructor
//****************************************************************************************
C2750parseTUSFile::C2750parseTUSFile() {
	pTUSData = NULL;
	pTUSLog = NULL;
}
//****************************************************************************************
/// API - Initialise the internal pointers to the TUS file in provided memory block
/// 
/// @param[in]	pFilePtr - pointer to block of memory containing the TUS file
///
/// @return		nothing
//****************************************************************************************
void C2750parseTUSFile::InitTUSFile(void *pFilePtr) {
	pTUSData = (T_P2750FILEHEADEROVERLAY) pFilePtr;		// Set the header structure to start of file
	pTUSLog = NULL;										// Set the log data to null until validated. 
}
//****************************************************************************************
/// API - Validates the file within the memory block, running though all available structures 
/// checking the CRC's, if a structure is found to be corrupted then the type of structure
/// and it's instance number will be passed back.
/// 
/// @param[out]	&errStruct - reference to T_STRUCTURE_IDENT used to identify type of corrupted structure
/// @param[out]	&instance - reference to int used to identify the instance number of the corrupted structure
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_FILE_CORRUPT indicates corruption identified in structure on &errStruct and &instance
///					PF_OK file integrity ok, and can be used for further processing
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::ValidateFile(T_STRUCTURE_IDENT &errStruct, int &instance) {
	T_C2750PROCESSFILE_RES retVal = PF_OK;
	// First check the CRC of the header
	if (CrcTest((UCHAR*) pTUSData, sizeof(T_2750FILEHEADER)) == CRC_TEST_PASSED) {
		// Header CRC ok, Run though all available structures in list, check the CRC's
		for (int sIndex = 0; sIndex < pTUSData->fh.numStructures; sIndex++) {
			// Check CRC's of structures in list. 
			if (CrcCalc((UCHAR*) pTUSData + pTUSData->structList[sIndex].startPos, pTUSData->structList[sIndex].length)
					!= pTUSData->structList[sIndex].crc) {
				// CRC FAILED , Set information to show a structure in table is corrupted
				errStruct = (T_STRUCTURE_IDENT) pTUSData->structList[sIndex].ident;
				instance = pTUSData->structList[sIndex].instance;
				retVal = PF_FILE_CORRUPT;
				break;
			}
		}
		// If structure check is ok we can validate the log data readings
		if (retVal == PF_OK) {
			if (pTUSData->fh.offSetOfLogData > 0) {
				pTUSLog = (T_P2750LOGDATAOVERLAY) ((UCHAR*) pTUSData + pTUSData->fh.offSetOfLogData);
				// First test the CRC of the log header		
				if (CrcTest((UCHAR*) pTUSLog, sizeof(T_TUSDATAREADINGHEADER)) == CRC_TEST_PASSED) {
					// LOg header OK, run though all log reading blocks and check the CRC's
					for (int lIndex = 0; lIndex < pTUSLog->lh.numOfReadings; lIndex++) {
						// Test CRC of log block
						if (CrcTest((UCHAR*) &pTUSLog->logReading[lIndex], sizeof(T_TUSDATAREADING))
								== CRC_TEST_FAILED) {
							// CRC FAILED, Log Reading is corrupted, set information and exit
							errStruct = ST_TUSDATAREADING;
							instance = lIndex;
							retVal = PF_FILE_CORRUPT;
							break;
						}
					}
				} else {
					// CRC FAILED, Log header is corrupted
					errStruct = ST_TUSDATAREADINGHEADER;
					instance = 0;
					retVal = PF_FILE_CORRUPT;
				}
			} else {
				// no log readings in the file which is OK therfore ignore
			}
		}
	} else {
		// CRC FAILED, Set information to show header is corrupted
		errStruct = ST_2750FILEHEADER;		// Set an indication of the structure which has the problem.
		instance = 0;
		retVal = PF_FILE_CORRUPT;
	}
	return retVal;
}
//****************************************************************************************
/// API - Get a copy of the TUS file header
/// 
/// @param[out]	pTUSHeader - pointer to a T_2750FILEHEADER structure to be populated with data from the file
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_FOUND - TUS file header ok and returned in pLogHeader
///					PF_STRUCTURE_NOT_FOUND - TUS file header not found, file invalid.
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getTUSHeader(T_P2750FILEHEADER pTUSHeader) {
	T_C2750PROCESSFILE_RES retVal = PF_STRUCTURE_NOT_FOUND;
	if (pTUSData != NULL) {
		// TUS file header available, copy into destination structure
		memcpy(pTUSHeader, pTUSData, sizeof(T_2750FILEHEADER));
		retVal = PF_STRUCTURE_FOUND;
	}
	return retVal;
}
//****************************************************************************************
/// API - get a copy the test data structure (T_TUSTESTDATA) from the TUS file
/// 
/// @param[out]	ptrTestData - pointer to a T_TUSTESTDATA structure to be populated with matching structure on file
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getTestData(T_PTUSTESTDATA ptrTestData) {
	return getStruct(ST_TUSTESTDATA, 0, ptrTestData, sizeof(T_TUSTESTDATA));
}
//****************************************************************************************
/// API - get a copy one of the soak data structures (T_TUSSOAKDATA) from the TUS file 
/// 
/// @param[out]	ptrSoakData - pointer to a T_TUSSOAKDATA structure to be populated with matching structure on file
/// @param[in]	soakNumber - number of the soak structure, soaks available from 1 to 6
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getSoakData(T_PTUSSOAKDATA ptrSoakData, int soakNumber) {
	return getStruct(ST_TUSSOAKDATA, soakNumber, ptrSoakData, sizeof(T_TUSSOAKDATA));
}
//****************************************************************************************
/// API - geta copy of the test configuration structure (T_TUSTESTCONFIG) from the TUS file
/// 
/// @param[out]	ptrTestConfig - pointer to a T_TUSTESTCONFIG structure to be populated with matching structure on file
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getTestConfig(T_PTUSTESTCONFIG ptrTestConfig) {
	return getStruct(ST_TUSTESTCONFIG, 0, ptrTestConfig, sizeof(T_TUSTESTCONFIG));
}
//****************************************************************************************
/// API - Get a copy of one of the sensor config structures (T_TUSSENSORCONFIG) from the TUS file 
/// 
/// @param[out]	ptrSensorConfig - pointer to a T_TUSSENSORCONFIG structure to be populated with matching structure on file
/// @param[in]	SensorID - number of the sensor, sensors available from 1 to 48
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getSensorConfig(T_PTUSSENSORCONFIG ptrSensorConfig, int SensorID) {
	return getStruct(ST_TUSSENSORCONFIG, SensorID, ptrSensorConfig, sizeof(T_TUSSENSORCONFIG));
}
//****************************************************************************************
/// API - Get a copy of the log block header
/// 
/// @param[out]	pLogHeader - pointer to a T_TUSDATAREADINGHEADER structure to be populated with data from the file
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_FOUND - log header ok and returned in pLogHeader
///					PF_STRUCTURE_NOT_FOUND - log header not found, file invalid.
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getLogHeader(T_PTUSDATAREADINGHEADER pLogHeader) {
	T_C2750PROCESSFILE_RES retVal = PF_STRUCTURE_NOT_FOUND;
	if (pTUSLog != NULL) {
		// Log header available, copy into destination structure
		memcpy(pLogHeader, &pTUSLog->lh, sizeof(T_TUSDATAREADINGHEADER));
		retVal = PF_STRUCTURE_FOUND;
	}
	return retVal;
}
//****************************************************************************************
/// API - Get a copy of a log data block (readings for a single time) from the file using the sequnce number 
/// 
/// @param[in]	seqNumber - Sequence number, runs form 1 to 2160 (72 hours in total) 
/// @param[out]	pLogReading - pointer to a T_TUSDATAREADING structure to be populated with data from the file
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_LOG_BLOCK_FOUND - the log block found and copied into destination structure pLogReading for use
///					PF_LOG_BLOCK_NOT_FOUND - log block not found, sequence number is not in range, pLogReading not affected
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getLogDataBlock(int seqNumber, T_PTUSDATAREADING pLogReading) {
	T_C2750PROCESSFILE_RES retVal = PF_LOG_BLOCK_NOT_FOUND;
	// Check that the sequnce number requested is within range
	if (seqNumber > 0 && seqNumber <= pTUSLog->lh.numOfReadings) {
		// Sequnce number ok, copy log data from source file to destination structure
		memcpy(pLogReading, &pTUSLog->logReading[seqNumber - 1], sizeof(T_TUSDATAREADING));
		retVal = PF_LOG_BLOCK_FOUND;
	} else {
		// Sequnce number invalid for this file, indicate no block found
		retVal = PF_LOG_BLOCK_NOT_FOUND;
	}
	return retVal;
}
//****************************************************************************************
/// indexOf the required structure within the the structure list in the file, providing the index
/// if successfully found
/// 
/// @param[in]	sType - T_STRUCTURE_IDENT type of structure required
/// @param[in]	sInstance - Instance of structure required
/// @param[out]	&theIndex - reference of the index of the structure in the list if found
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND if the requested structure is not located in the list
///					PF_STRUCTURE_FOUND if structure found with &theIndex conatining index
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::findStruct(T_STRUCTURE_IDENT sType, int sInstance, int &theIndex) {
	theIndex = 0;
	T_C2750PROCESSFILE_RES retVal = PF_STRUCTURE_NOT_FOUND;
	// Run through all structures in list
	for (int sIndex = 0; sIndex < pTUSData->fh.numStructures; sIndex++) {
		// Test both type and instance with current entry in structure table 
		if (pTUSData->structList[sIndex].ident == sType && pTUSData->structList[sIndex].instance == sInstance) {
			// Exact Match is found, set the index and stop searching
			retVal = PF_STRUCTURE_FOUND;
			theIndex = sIndex;
			break;
		}
	}
	return retVal;
}
//****************************************************************************************
/// Generic get structure method, will retrive a structure from the file depending on type and instance and copy it
/// into the container passed in. The method will take care of different structure sizes if newer or older structures
/// are being accessed to that built into the code. There will be a aprtial copy if destination structure is smaller
/// or if destination is larger it will copy akll of source and pad destination with zeros.
/// 
/// @param[in]	sType - T_STRUCTURE_IDENT type of structure required
/// @param[in]	sInstance - Instance of structure required
/// @param[out]	*structData - pointer to a destination structure
/// @param[in]	structSize - the size of the destination structure
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_STRUCTURE_NOT_FOUND - structure type/instance not found
///					PF_STRUCTURE_FOUND - structure found and size matches, copied into *structData
///					PF_STRUCTURE_TOO_SMALL - structure found but source is smaller then destination (source older)
///												so *structData conatains source structure and additional space is set to 0.
///					PF_STRUCTURE_TOO_LARGE - structure found but source is larger, so *structData conatains partial copy of source 
///												this could indicate an newer source structure
///												
//****************************************************************************************
T_C2750PROCESSFILE_RES C2750parseTUSFile::getStruct(T_STRUCTURE_IDENT sType, int sInstance, void *structData,
		int structSize) {
	T_C2750PROCESSFILE_RES retVal = PF_STRUCTURE_NOT_FOUND;
	int index = 0;
	retVal = findStruct(sType, sInstance, index);
	if (retVal == PF_STRUCTURE_FOUND) {
		T_PTUSSTRUCTIDENT ptrIndex = &pTUSData->structList[index];
		int copyLen = ptrIndex->length;
		// test for any size difference within structures
		if (ptrIndex->length < structSize) {
			// the source structure(file) is smaller then the current structure built in codebase, so this would
			// inducate that the source structure is older, so we return all we can and set the rest of the struct to 0
			memset(structData, 0, structSize);
			retVal = PF_STRUCTURE_TOO_SMALL;
		} else if (ptrIndex->length > structSize) {
			// the source structure(file) is bigger then the current structure built in codebase, this would indicate that 
			// the source structure is newer, so we will truncate the source structure to fit in the destination.
			copyLen = structSize;// Set the copy length to struct size as previously it was set to larger source struct size
			retVal = PF_STRUCTURE_TOO_LARGE;
		}
		// Copy the source structure to the destination
		memcpy(structData, (UCHAR*) pTUSData + ptrIndex->startPos, copyLen);
	}
	return retVal;
}

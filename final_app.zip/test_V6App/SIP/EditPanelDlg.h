/// @file EditPanelDlg.h
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 EditPanel
/// @n Filename: EditPanelDlg.h
/// @n Desc:	 Functions Definitions of the Single line Edit Panel
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:57:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:26:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 5/18/2005 12:01:02 PM  Sanjeev (HTSL) 
//  Added the doxygen comments
//  1 V6 Firmware 1.0 5/17/2005 8:26:49 PM  Sanjeev (HTSL) 
// $
//
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if !defined(AFX_EDITPANELDLG_H__B1317ABC_4515_4D88_8B30_DD54429706AF__INCLUDED_)
#define AFX_EDITPANELDLG_H__B1317ABC_4515_4D88_8B30_DD54429706AF__INCLUDED_
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
/////////////////////////////////////////////////////////////////////////////
// CEditPanelDlg dialog
#include <QDialog>
#include "SIPGlobal.h"
class CEditPanelDlg: public QDialog {
// Construction
public:
	CEditPanelDlg(CWidget *pParent = NULL);	///< standard constructor
	~CEditPanelDlg();						// Destructor
	//Public Function definitions will be call by the client of the SIP
	BOOL
	WINAPI InitializeIP(POSITION_INFO*, const SIZE_POSITION*, const KEY_MAP_INFO*, BITMAP_INFO*, DISPLAY_INFO*);
	BOOL
	WINAPI ShowIP(BUFFERINFO*, glbpCallbackFunction, OTHERINFO*, BYTE*, BYTE*);
protected:
//	CEditPanelDlg(CWidget* pParent = NULL);	///< standard constructor
	BITMAPINFO *m_pBMInfo;				///< Store the bitmap information 
	QRect m_ObjRect; ///< contain SIP layout size coordinates in the screen
	HBRUSH m_HbrEdit; ///< Brush to draw the edit box 
	HBRUSH m_HbrDialog;  ///< Brush to draw the dialog 
	QBrush m_EditBrush;			///< Used to create the edit box brush  
	QImage m_hOldBitmapSel, m_OldOrgBitmapSel;
	// First time initialization parameters 
	POSITION_INFO m_PositionInfo;	///< contains the starting position of the SIP in the recorder screen
	const SIZE_POSITION *m_pkSizePosition; ///< contains the size and position map 
	const KEY_MAP_INFO *m_pkKeyMapInfo; ///< contains the key map - points to a resource so it does not need to be deleted
	DISPLAY_INFO m_DisplayInfo; ///< contains the font information, description field string
	BITMAP_INFO m_BitmapInfo;  ///< contains the Bmp file related information
	//Flags for the capslock,shift and AU key
	BOOL m_Capslock, m_Shift, m_AU;
	WORD m_KeyID;		///< KeyID of the pressed key
	WORD m_Index;		///< index of the size and position map
	WORD m_KeyIndex;		///< index of the key map 
	CFont m_DrawFont;		///< font to draw the character in the SIP layout
	CFont m_EditFont;		///< font to write the character in the edit box
	QTextEdit *m_pEdit;  ///< A pointer variable to create the edit box in the SIP layout
	//Memory DC object pointers
	CDC *m_pMemDC;  ///< Memory DC 
	CDC *m_pMainBitmapDC;  ///< Memory DC
	QString m_pValidationBuffer;  ///< Buffer to store the string written by the client
	QString m_pOldBuffer;  ///< Saving the buffer information at the starting
	BYTE m_IsUpdate; ///< Using as a flag
	BYTE m_IsTimeOut;  ///< Using as a flag 
	CClientDC *m_pClientDC;		///< Client DC object pointer
	WORD m_EditboxIndex; ///< Edit box index in the size and position map
	QImage m_BMHandle;			///< Bitmap handle
	QImage m_BMOrgHandle;		///< bitmap handles 
	//Runtime initialization parameters
	BUFFERINFO m_BufferInfo;	 ///<Contain Buffer information 
	OTHERINFO m_OtherInfo;	 ///<Contain other information 
	glbpCallbackFunction pCallbackPointer;	 ///<Callback function pointer to validate the string
	CFont descriptionFont; ///< Description field font info
	// Size and position map is divided in the four region
	QList<WORD> m_List1;
	QList<WORD> m_List2;
	QList<WORD> m_List3;
	QList<WORD> m_List4;
	POSITION m_Position;		///< Position in the size and position list
	WORD m_OnceDraw;		///< Used as the flag	
	WORD m_OnceCreate;	///< Used as the flag
	//Not required in Desktop 
#ifdef UNDER_CE
		HCURSOR m_Hcursor;		///< Handle of the cursor
	#endif
	WORD GetKeyID(WORD, WORD, BOOL);	// function giving the pressed key keyID
	void PrintKeyHandler();				// Draw the character in the screen
	void KeyHandler(BOOL KeyDown);		// handle the special key functionality
	QImage LoadDIBBitmap(void *pBmpFile, DWORD BufferLength);		// Return the handle of the bitmap
	void DrawIP();							// Draw the SIP layout in the screen
	// Add for the double click and repeat thing
	UINT m_DoubleClkTime;		///< Store the double click time 
	WORD m_DoubleClkKeyID;  ///< Double click Key ID 
	WORD m_DblClkFlag;			///< Double click flag
	WORD m_RepeatFlag;			///< Auto Repeat flag
	WORD m_DoNothing;  ///< Flag indication action is required or not
	bool m_bInitialised;
	//Virtual function declaration
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	// Generated message map functions
	//{{AFX_MSG(CEditPanelDlg)
	void OnPaint();
	HBRUSH OnCtlColor(CDC *pDC, CWidget *pWnd, UINT nCtlColor);
	void OnLButtonDown(UINT nFlags, QPoint point);
	void OnLButtonUp(UINT nFlags, QPoint point);
	void OnMouseMove(UINT nFlags, QPoint point);
	void OnTimer(UINT_PTR nIDEvent);
	void OnLButtonDblClk(UINT nFlags, QPoint point);
};
//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_EDITPANELDLG_H__B1317ABC_4515_4D88_8B30_DD54429706AF__INCLUDED_)

// NumEditDlg.cpp : implementation file
//
#include "NumEditDlg.h"
#include "OEMInfo.h"
#include "V6ResConstants.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
// CNumEditDlg( CWidget* pkParent )
///
/// Constructor
///
/// @param[in] 	  CWidget* pkParent - A pointer to the parent window
/// 
//****************************************************************************
CNumEditDlg::CNumEditDlg(CWidget *pParent /*=NULL*/) : CEditPanelDlg(L"NUM_EDIT_DLG", pParent) {
	InitializeIP();
}
//****************************************************************************
// ~CNumEditDlg( )
///
/// Destructor
/// 
//****************************************************************************
CNumEditDlg::~CNumEditDlg() {
}
//****************************************************************************
// DoDataExchange()
///
/// Data Exchange method
///
//****************************************************************************
void CNumEditDlg::DoDataExchange(CDataItem *pDX) {
	CEditPanelDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNumEditDlg)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}
BEGIN_MESSAGE_MAP(CNumEditDlg, CEditPanelDlg)
//{{AFX_MSG_MAP(CNumEditDlg)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//****************************************************************************
// BOOL OnInitDialog() 
///
/// OnInitDialog event handler
///
//****************************************************************************
BOOL CNumEditDlg::OnInitDialog()
{
	CEditPanelDlg::OnInitDialog();
	return TRUE; // return TRUE unless you set the focus to a control
				 // EXCEPTION: OCX Property Pages should return FALSE
}
//****************************************************************************
// void InitializeIP()
///
/// Method that initialises the edit panel member variables such as the bitmap and keymap
/// 
//****************************************************************************
void CNumEditDlg::InitializeIP() {
	BOOL bOK = FALSE;
	// Fill the POSITION_INFO structure
	POSITION_INFO PositionInfo;
	PositionInfo.XCoordinate = 0;	//x coordinate of the SIP
	PositionInfo.YCoordinate = 0;  //y coordinate of the SIP
	// get a handle on the OEM info class
	COEMInfo *pkOEMInfo = COEMInfo::Instance();
	SIZE_POSITION *pkSizePosInfo = NULL;
	pkSizePosInfo = reinterpret_cast<SIZE_POSITION*>(pkOEMInfo->GetPanelSPMap(V6RES_PANEL_GRAPHIC_NUMPANEL));
	KEY_MAP_INFO *pkKeyMapInfo = NULL;
	pkKeyMapInfo = reinterpret_cast<KEY_MAP_INFO*>(pkOEMInfo->GetPanelKeyMap(V6RES_PANEL_GRAPHIC_NUMPANEL));
	//bitmap information
	BITMAP_INFO BitmapInfo;
	BitmapInfo.pBmp = pkOEMInfo->GetPanelUpImage(V6RES_PANEL_GRAPHIC_NUMPANEL);
	ResPanel *ptPaneInfo = pkOEMInfo->GetPanelInfo(V6RES_PANEL_GRAPHIC_NUMPANEL);
	BitmapInfo.size = ptPaneInfo->graUp.size;
	// Temporary vairable used to hold colour information
	ResColour *pkColourInfo = NULL;
	//Display information
	DISPLAY_INFO DisplayInfo;
	T_DEV_TYPE devType = pGlbDal->GetDeviceType();
	wcscpy_s(DisplayInfo.TextFontInfo.FontName, sizeof(DisplayInfo.TextFontInfo.FontName) / sizeof(WCHAR),
			_T("Tahoma")); //SIP layout text font name
	DisplayInfo.TextFontInfo.FontSize = 25; //Font size of the text for the SIP layout 
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		DisplayInfo.TextFontInfo.FontSize = 32; //Font size of the text for the SIP layout 
	else if (devType == DEV_ARISTOS_MINITREND)
		DisplayInfo.TextFontInfo.FontSize = 34; //Font size of the text for the SIP layout 
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_SIPKEYTXT); // font color of text for the SIP layout
	DisplayInfo.TextFontInfo.FontColor = pkColourInfo->pColor;
	wcscpy_s(DisplayInfo.EditFontInfo.FontName, sizeof(DisplayInfo.EditFontInfo.FontName) / sizeof(WCHAR),
			_T("Tahoma")); // Edit box text font name
	DisplayInfo.EditFontInfo.FontSize = 26; //Font size of the text for the edit box 
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		DisplayInfo.EditFontInfo.FontSize = 32; //Font size of the text for the edit box 
	else if (devType == DEV_ARISTOS_MINITREND)
		DisplayInfo.EditFontInfo.FontSize = 38; //Font size of the text for the edit box 
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_SIPEDITTXT); // Font color of text for the edit box
	DisplayInfo.EditFontInfo.FontColor = pkColourInfo->pColor;
	wcscpy_s(DisplayInfo.DescriptionFontInfo.FontName, sizeof(DisplayInfo.DescriptionFontInfo.FontName) / sizeof(WCHAR),
			_T("Tahoma")); //Description field font name
	DisplayInfo.DescriptionFontInfo.FontSize = 16; //Font size of the text for the description field
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		DisplayInfo.DescriptionFontInfo.FontSize = 20; //Font size of the text for the description field
	else if (devType == DEV_ARISTOS_MINITREND)
		DisplayInfo.DescriptionFontInfo.FontSize = 28; //Font size of the text for the description field
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_SIPDESC); // Font color of text for description field
	DisplayInfo.DescriptionFontInfo.FontColor = pkColourInfo->pColor;
	DisplayInfo.OffsetInfo.XOffset = 2; //X coordinate offset value 
	DisplayInfo.OffsetInfo.YOffset = 2; //Y coordinate offset value
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_SIPEDITBG); // Background color of the edit box
	DisplayInfo.Background = pkColourInfo->pColor;
	// Now initialise the base object with our custom parameters
	CEditPanelDlg::InitializeIP(&PositionInfo, pkSizePosInfo, pkKeyMapInfo, &BitmapInfo, &DisplayInfo);
}

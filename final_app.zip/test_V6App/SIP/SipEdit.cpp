/// @file SipEdit.cpp
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 EditPanel
/// @n Filename: SipEdit.cpp
/// @n Desc:	 Implementation of the edit control
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 5:01:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:38:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:47 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:03:56 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#include "SipEdit.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
/////////////////////////////////////////////////////////////////////////////
// CSipEdit
CSipEdit::CSipEdit() {
}
CSipEdit::~CSipEdit() {
}
/////////////////////////////////////////////////////////////////////////////
// CSipEdit message handlers
//**********************************************************************
/// CSipEdit OnEraseBkgnd()
///
/// This method is called by the framework when the CWidget object background 
/// needs erasing. Calling the default implementation of the OnEraseBkgnd
/// function of the QTextEdit class otherwise returning TRUE.
///
/// @param[in] pDC  - device context object pointer. 
///							 
/// @return The default implementation of edit control.
///  
//**********************************************************************
BOOL CSipEdit::OnEraseBkgnd(CDC* pDC)
{
	return QTextEdit::OnEraseBkgnd(pDC);
}
//**********************************************************************
/// CSipEdit OnGetDlgCode()
///
/// This method is called by the framework when the CWidget object background 
/// needs erasing. Calling the default implementation of the OnEraseBkgnd
/// function of the QTextEdit class otherwise returning TRUE.
///
/// @return The Tab key and arrow key, those edit control want to process.
///  
//**********************************************************************
UINT CSipEdit::OnGetDlgCode() {
	return DLGC_WANTTAB | DLGC_WANTARROWS | DLGC_WANTCHARS;
}

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOChanHandler.cpp
/// @n implementation for the abstract CIOChanHandler class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 84	Stability Project 1.79.1.3	7/2/2011 4:58:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 83	Stability Project 1.79.1.2	7/1/2011 4:38:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 82	Stability Project 1.79.1.1	3/17/2011 3:20:26 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 81	Stability Project 1.79.1.0	2/15/2011 3:03:10 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "AICard.h"
#include "DigPulseCard.h"
#include "AOCard.h"
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#include "PPQManager.h"
#include "V6globals.h"
//#include "DataItem.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "IOChanHandler.h"
#include "PPIOService.h"
#include "PPAIChannel.h"
#include "PPAOChannel.h"
#include "PPDOChannel.h"
#include "PPPulseChannel.h"
#include "PPIOServiceManager.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CIOChanHandler::CIOChanHandler() {
//	qDebug("Create new CIOChanHandler\n");
	memset(&m_ChanInfo, 0xdd, sizeof(m_ChanInfo));
	m_ChanInfo.PPService = PP_SERVICE_UNKNOWN;
	m_ChanInfo.m_firstValueLoaded = FALSE;
	m_ChanInfo.m_noOfReadings = 0;
	m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo = NULL;
	m_ChanInfo.chanInfo.AIChanInfo.pChanWrkInfo = NULL;
	m_ChanInfo.m_chanRTCal.ValidValue = FALSE;
	m_ChanInfo.m_chanRTComp.ValidValue = FALSE;
	m_ChanInfo.m_pRangeScale = NULL;
	m_ChanInfo.pCommon = NULL;
	m_ChanInfo.m_burnOutReportPrfrmd = CInputConditioning::BURNOUT_OK;
}
CIOChanHandler::~CIOChanHandler() {
//	qDebug("Delete CIOChanHandler class\n");
}
//******************************************************
// InitialiseChanService()
///
/// Initialises a channel to connect to the approriate Data Item table
/// or data queue for data extraction/processing.
/// Also sets the global system system known channel number.
///
/// @param[in] pBoardInfo - The board specific service parameter data.
/// @param[in] pChanInfo - The channel specific service parameter data.
/// @param[in] acqRate - The current channel acqusition rate.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::InitialiseChanService(T_COMMONPROCESSINFO *const pBoardInfo, T_CHANPROCESSINFO *const pChanInfo,
		const UCHAR acqRate) {
	class CInputConditioning *pCondition = NULL;
	class CPPAIChannel *pAIChannel = NULL;
	class CPPPulseChannel *pPulseChannel = NULL;
	class CAICard *pAICard = NULL;
	class CAOCard *pAOCard = NULL;
	class CDigPulseCard *pDigCard = NULL;
	class CPPIOServiceManager *pServiceManager = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	BOOL retValue = TRUE;
	m_ChanInfo = *pChanInfo;
	m_ChanInfo.m_pRangeScale = NULL;
	m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo = NULL;
	m_ChanInfo.chanInfo.AIChanInfo.pChanWrkInfo = NULL;
	m_ChanInfo.m_burnOutReportPrfrmd = CInputConditioning::BURNOUT_OK;
	pServiceManager = GetServiceManager();
	pBrdInfoObj = CBrdInfo::GetHandle();
	switch (pBrdInfoObj->WhatSelectedChannelType(pBoardInfo->CardSlotNo, m_ChanInfo.channelNo)) {
	case CHANNEL_AI:
		pAICard = static_cast<class CAICard*>(pBoardInfo->pCard);
		if (pAICard != NULL) {
			pAICard->GetChannelConfigRef(m_ChanInfo.channelNo, &m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo,
					&m_ChanInfo.chanInfo.AIChanInfo.pChanWrkInfo);
		}
		break;
	case CHANNEL_AO:
		pAOCard = static_cast<class CAOCard*>(pBoardInfo->pCard);
		if (pAOCard != NULL) {
			pAOCard->GetChannelConfigRef(m_ChanInfo.channelNo, &m_ChanInfo.chanInfo.AOChanInfo.pChanCfgInfo,
					&m_ChanInfo.chanInfo.AOChanInfo.pChanWrkInfo);
		}
		break;
	case CHANNEL_PULSE:
	case CHANNEL_DIG_PULSE:
	case CHANNEL_DO:
	case CHANNEL_DI:
		pDigCard = static_cast<class CDigPulseCard*>(pBoardInfo->pCard);
		if (pDigCard != NULL) {
			pDigCard->GetChannelConfigRef(m_ChanInfo.channelNo, &m_ChanInfo.chanInfo.DigChanInfo.pChanCfgInfo);
		}
		break;
	};
	// Only a pulse & AI channel have an acqusition frequency
	if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN)
		m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->ChanCfgInfo.acqRate = acqRate;
	else if (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN)
		m_ChanInfo.chanInfo.DigChanInfo.pChanCfgInfo->ChanCfgInfo.acqRate = acqRate;
	m_ChanInfo.hPPQ = INVALID_PPQ_HANDLE;
	retValue = CIOHandler::InitialiseChanService(pBoardInfo);
	m_ChanInfo.pCommon = CIOHandler::GetBoardProcessInfo();
	m_ChanInfo.m_firstValueLoaded = FALSE;
	m_ChanInfo.m_noOfReadings = 0;
	if ((m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled == TRUE)
			|| (IsRunningAsATEEquipment() == TRUE)) {
		if ((m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) || (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN)) {
			USHORT usTB = pBrdInfoObj->GetBoardTimebase(pBoardInfo->CardSlotNo);
			if (usTB == 0) {
				usTB = 400; // Default 400hz card rate; Rahul; added for recorder slow down issues as the readings required calculated are 65535 (Too Many...)
			}
			m_ChanInfo.timestampInterval = static_cast<USHORT>(usTB / acqRate);
			//m_ChanInfo.timestampInterval = static_cast<USHORT> ( pBrdInfoObj->GetBoardTimebase(pBoardInfo->CardSlotNo) / acqRate);
		}
		// Calculate board count to enginnering scale conversion info structure for AI channels only
		if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) {
			//Get The AI Board Rev Number
			UCHAR ucBoardRev = V6AI_ISSUE_1;
			pBrdInfoObj->GetBoardHardwareRevision(pBoardInfo->CardSlotNo, &ucBoardRev);
//			m_ChanInfo.m_burnOutReportPrfrmd = TRUE;
			if (pServiceManager != NULL) {
				pCondition = pServiceManager->GetICService();
			} else {
				LogInternalError("InitialiseChanService variable pServiceManager is NULL");
			}
			// Get Analogue in card handler
			pAIChannel = GetServiceManager()->GetAIService();
			if (pAIChannel != NULL) {
				// Initailise any service required
				retValue = pAIChannel->InitialiseChanService(&m_ChanInfo);
				if (retValue == FALSE)
					LogInternalError("Could not initialise AI channel");
			} else {
				LogInternalError("Could not obtain AI channel handle");
				retValue = FALSE;
			}
			if (pCondition != NULL) {
				m_ChanInfo.m_pRangeScale = pCondition->GetBaseRangeConversionInfo(
						static_cast<UCHAR>(m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->BaseRange.RangeInfo.RangeEnum),
						ucBoardRev);
			} else {
				LogInternalError("InitialiseChanService variable pCondition is NULL");
				retValue = FALSE;
			}
			// Pre-calculate the range to pen engineering value conversion info
			m_ChanInfo.EngScale.CalcFConvInfo(m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->mcElecRangeZero,
					m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->mcElecRangeSpan,
					m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->mcEngZero,
					m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->mcEngSpan);
		} else if (m_ChanInfo.PPService == PP_SERVICE_AO_CHAN) {
			// Calculate pen scales to board count
			// Pre-calculate pen engineering to mA value conversion info
			m_ChanInfo.EngScale.CalcFConvInfo(m_ChanInfo.chanInfo.AOChanInfo.pChanCfgInfo->mcEngZero,
					m_ChanInfo.chanInfo.AOChanInfo.pChanCfgInfo->mcEngSpan,
					m_ChanInfo.chanInfo.AOChanInfo.pChanCfgInfo->AOChanEngZero,
					m_ChanInfo.chanInfo.AOChanInfo.pChanCfgInfo->AOChanEngSpan);
		} else if (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN) {
			// Get Pulse in card handler
			pPulseChannel = GetServiceManager()->GetPulseService();
			// Initailise any service required
			if (pPulseChannel != NULL) {
				retValue = pPulseChannel->InitialiseChanService(&m_ChanInfo);
				if (retValue == FALSE)
					LogInternalError("Could not initialise pulse channel");
			} else {
				LogInternalError("Could not initialise pulse channel");
				retValue = FALSE;
			}
		}
	}
	return retValue;
}
//******************************************************
// StartChanService()
///
/// Synchronises the data queues and starts data acqusition
/// @param[in] pBoardInfo - The board specific service parameter data.
/// @param[in] pChanInfo - The channel specific service parameter data.
/// @param[in] pChanInfo - The channel specific service parameter data.
///
/// @return TRUE on successful starting of the queues; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::StartChanService(T_COMMONPROCESSINFO *const pBoardInfo, T_CHANPROCESSINFO *const pChanInfo,
		const UCHAR acqRate) {
	class CInputConditioning *pCondition = NULL;
	class CPPAIChannel *pAIChannel = NULL;
	class CPPPulseChannel *pPulseChannel = NULL;
	class CAICard *pAICard = NULL;
	class CAOCard *pAOCard = NULL;
	class CDigPulseCard *pDigCard = NULL;
	class CPPIOServiceManager *pServiceManager = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	BOOL retValue = TRUE;
	m_ChanInfo = *pChanInfo;
//	m_ChanInfo.m_pRangeScale = NULL;
	m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo = NULL;
	m_ChanInfo.chanInfo.AIChanInfo.pChanWrkInfo = NULL;
	pServiceManager = GetServiceManager();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if ((m_ChanInfo.chanInfo.AIChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled == TRUE)
			&& (IsRunningAsATEEquipment() == FALSE)) {
		// Calculate board count to enginnering scale conversion info structure for AI channels only
		if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) {
			m_ChanInfo.m_burnOutReportPrfrmd = CInputConditioning::BURNOUT_OK;
			// Get Analogue in card handler
			pAIChannel = GetServiceManager()->GetAIService();
			if (pAIChannel != NULL) {
				// Initailise any service required
				retValue = pAIChannel->InitialiseChanService(&m_ChanInfo);
				if (retValue == FALSE)
					LogInternalError("Could not initialise AI channel");
			} else {
				LogInternalError("Could not obtain AI channel handle");
				retValue = FALSE;
			}
		} else if (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN) {
			// Get Pulse in card handler
			pPulseChannel = GetServiceManager()->GetPulseService();
			// Initailise any service required
			if (pPulseChannel != NULL) {
				retValue = pPulseChannel->InitialiseChanService(&m_ChanInfo);
				if (retValue == FALSE)
					LogInternalError("Could not initialise pulse channel");
			} else {
				LogInternalError("Could not obtain pulse channel handle");
				retValue = FALSE;
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Obtains the type of reading support required for channel
///
/// @return The channel's service required
/// 
//******************************************************
UCHAR CIOChanHandler::GetChannelServiceRequired(void) {
	return m_ChanInfo.PPService;
}
//**********************************************************************
/// Stores the raw RT Cal readings for a channel.
///
/// @param[in] RTComp - The RT Comp reading.
/// @param[in] highCurrent - TRUE if using high current otherwise FALSE.
///
/// @return		TRUE if reading stored; otherwise FALSE
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			29/Mar/2019		Shankar Rao	Pendyala	Compatibility with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//**********************************************************************
BOOL CIOChanHandler::StoreRawRTComp(const T_RANGE_COUNTS RTComp, const BOOL highCurrent, const USHORT cardSubType,
		const USHORT chanType) {
	class CDataItem *pDataItem = NULL;
	QString errLog;
	// Error codes can be returned instead of an RT comp value
	if (m_pICService == NULL)
		return FALSE;
	m_ChanInfo.m_chanRawRTComp = RTComp;
	// Scale and store in the scaled RT comp holder
//	m_Info.m_chanRTComp = m_pICService->PerformResistanceConvert( m_ChanInfo.pCommon->CardSlotNo, RTComp, m_Info.m_chanRTCal );
	if (m_pICService->LimitAnalogueChannel(m_ChanInfo.pCommon->CardSlotNo, m_ChanInfo.channelNo, FALSE, RTComp,
			&(m_ChanInfo.m_chanRTComp.Value), chanType) == FALSE) {
		// Error from channel
		m_ChanInfo.m_chanRTComp.ValidValue = FALSE;
	} else {
		// Convert RT count to mV
		if (AI_CARD_TYPE_V7AI == cardSubType) {
			m_ChanInfo.m_chanRTComp.Value = ((RTComp - 0x800000) * 2500.0) / (8 * 0x800000);
		} else {
			m_ChanInfo.m_chanRTComp.Value = m_pICService->NormaliseRTComp(m_ChanInfo.pCommon->CardSlotNo, RTComp,
					highCurrent);
		}
		m_ChanInfo.m_chanRTComp.ValidValue = TRUE;
	}
//	if( m_ChanInfo.m_chanRTComp.ValidValue == TRUE )
//	{
//		errLog = QString::asprintf( L"RT Comp: %d I/O board %d: chan %d", m_ChanInfo.m_chanRawRTComp, m_ChanInfo.pCommon->CardSlotNo, m_ChanInfo.channelNo);
//		LogInternalError(errLog.toLocal8Bit().data());
//	}
	// Store copy in the data item table
	pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_RT_COMP, m_ChanInfo.glbchannelNo - 1);
	if (pDataItem != NULL) {
		pDataItem->SetValue(m_ChanInfo.m_chanRTComp.Value);
		if (m_ChanInfo.m_chanRTComp.ValidValue == TRUE)
			pDataItem->SetStatus(DISTAT_NORMAL);
		else
			pDataItem->SetStatus(DISTAT_INVALID);
	}
	return m_ChanInfo.m_chanRTComp.ValidValue;
}
//**********************************************************************
/// Stores the RT Cal readings for a channel.
///
/// @param[in] RTComp - The RT Cal reading.
/// @param[in] highCurrent - TRUE if using high current otherwise FALSE.
///
/// @return		TRUE if reading stored; otherwise FALSE
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			05/Apr/2019		Shankar Rao	Pendyala	Compatibility with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//**********************************************************************
BOOL CIOChanHandler::StoreRawRTCal(const T_RANGE_COUNTS RTCal, const BOOL highCurrent) {
	class CDataItem *pDataItem = NULL;
	QString errLog;
	// No error codes are ever returned instead of an RT cal value
	if (m_pICService == NULL)
		return FALSE;
	m_ChanInfo.m_chanRawRTCal = RTCal;
	m_ChanInfo.m_chanRTCal.ValidValue = TRUE;
	// Scale and store in the scaled RT cal holder
	if (m_pICService->NormaliseExcitationCurrent(m_ChanInfo.glbchannelNo, RTCal, highCurrent,
			&(m_ChanInfo.m_chanRTCal.Value)) == FALSE) {
		// RT cal has failed (the last reading, assumming one good one taken, is still available but useless)
		m_ChanInfo.m_chanRTCal.ValidValue = FALSE;
	}
//	if( m_ChanInfo.m_chanRTCal.ValidValue == TRUE )
//	{
//		errLog = QString::asprintf( L"RT Cal %f: I/O board %d: chan %d", m_ChanInfo.m_chanRTCal.Value, m_ChanInfo.pCommon->CardSlotNo, m_ChanInfo.channelNo);
//		LogInternalError(errLog.toLocal8Bit().data());
//	}
	// Store copy in the data item table
	pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_RT_CAL, m_ChanInfo.glbchannelNo - 1);
	if (pDataItem != NULL) {
		pDataItem->SetValue(m_ChanInfo.m_chanRTCal.Value);
		if (m_ChanInfo.m_chanRTCal.ValidValue == TRUE)
			pDataItem->SetStatus(DISTAT_NORMAL);
		else
			pDataItem->SetStatus(DISTAT_INVALID);
	}
	return m_ChanInfo.m_chanRTCal.ValidValue;
}
//**********************************************************************
/// Stores the default RT Cal readings for a channel.
///
/// @param[in] highCurrentSet - TRUE if high current option is selected
///
/// @return		TRUE if reading stored; otherwise FALSE
//**********************************************************************
BOOL CIOChanHandler::StoreDefaultRTCal(const BOOL highCurrentSet) {
	if (highCurrentSet == TRUE) {
		m_ChanInfo.m_chanRTCal.Value = DEFAULT_CONSTANT_CURRENT_HIGH_MA;
		m_ChanInfo.m_chanRTCal.ValidValue = FALSE;
	} else {
		m_ChanInfo.m_chanRTCal.Value = DEFAULT_CONSTANT_CURRENT_LOW_MA;
		m_ChanInfo.m_chanRTCal.ValidValue = FALSE;
	}
	return TRUE;
}
//**********************************************************************
/// Gets the RT Comp readings for a channel.
///
/// @param[out] pRTCal - The RT Comp reading as a float.
///
/// @return	TRUE if reading obtained; otherwise FALSE
//**********************************************************************
BOOL CIOChanHandler::GetLatestRTComp(float *const pRTComp) const {
	*pRTComp = m_ChanInfo.m_chanRTComp.Value;
	/// Check that a RTCal & RTComp read has been completed, otherwise reading is invalid
	return m_ChanInfo.m_chanRTComp.ValidValue;
}
//**********************************************************************
/// Gets the RT Cal readings for a channel.
///
/// @param[out] pRTComp - The RT Cal reading.
///
/// @return	TRUE if reading obtained; otherwise FALSE
//**********************************************************************
BOOL CIOChanHandler::GetLatestRTCal(float *const pRTCal) const {
	*pRTCal = m_ChanInfo.m_chanRTCal.Value;
	/// Check that a RTCal read has been completed, otherwise reading is invalid
	return m_ChanInfo.m_chanRTCal.ValidValue;
}
//******************************************************
// SyncService()
///
/// Synchronises a channel's pre-process queue
///
/// @param[in] IOCardTick - I/O card tick to sync to.
/// @param[in] systemTick - The global system time to sync to.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::SyncService(const USHORT IOCardTick, const LONGLONG systemTick) {
	class CPPAIChannel *pAIChannel = NULL;
	class CPPPulseChannel *pPulseChannel = NULL;
	BOOL retValue = FALSE;
	if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) {
		// Get Analogue in card handler
		pAIChannel = GetServiceManager()->GetAIService();
		retValue = pAIChannel->SyncChannelQueue(&m_ChanInfo, IOCardTick, systemTick);
	} else if (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN) {
		// Get Pulse in card handler
		pPulseChannel = GetServiceManager()->GetPulseService();
		retValue = pPulseChannel->SyncChannelQueue(&m_ChanInfo, IOCardTick, systemTick);
	}
	return retValue;
}
//**********************************************************************
/// Sets all services on a setup commit change preperation
///
/// @return TRUE on successful commit; otherwise FALSE
/// 
//**********************************************************************
BOOL CIOChanHandler::SetupConfigChangePreparation(void) {
	class CPPAIChannel *pAIChanHandler = NULL;
	class CPPPulseChannel *pPulseChanHandler = NULL;
	BOOL retValue = TRUE;
	if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) {
		// Get Analogue in card handler
		pAIChanHandler = GetServiceManager()->GetAIService();
		if (pAIChanHandler != NULL)
			pAIChanHandler->DisableService(&m_ChanInfo);
	} else if (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN) {
		// Get Pulse in card handler
		pPulseChanHandler = GetServiceManager()->GetPulseService();
		if (pPulseChanHandler != NULL)
			pPulseChanHandler->DisableService(&m_ChanInfo);
	}
	return retValue;
}
//******************************************************
// SetGlobalChannelID()
///
/// Sets the global system system known channel number.
///
/// @param[in] glbChannelNo - Card slot channel number, globally known to system.
///
/// @return TRUE if the global channel number is succesfully set; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::SetGlobalChannelID(const USHORT glbChannelNo) {
	m_ChanInfo.glbchannelNo = glbChannelNo;
	return TRUE;
}
//******************************************************
// GetGlobalChannelID()
///
/// Gets the global system system known channel number.
///
/// @return Card slot channel number, globally known to system
/// 
//******************************************************
USHORT CIOChanHandler::GetGlobalChannelID(void) const {
	return m_ChanInfo.glbchannelNo;
}
//******************************************************
// OutputDigital()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
///
/// @param[out] pNewState - System channel digital states.
///
/// @return TRUE on output change; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::OutputDigital(BOOL *pNewState) {
	class CPPDOChannel *pDigOutChan = NULL;
	BOOL retValue = FALSE;
	// Ensure service is only performed on correct I/O channel type
	if (m_ChanInfo.PPService == PP_SERVICE_DO_CHAN) {
		// Get digital output channel handler
		pDigOutChan = GetServiceManager()->GetDOService();
		retValue = pDigOutChan->OutputDigital(&m_ChanInfo, pNewState);
	}
	return retValue;
}
//******************************************************
// UpdateOutputDigital()
///
/// Performs a channel service to update the output state.
///
/// @param[in] NewState - System channel digital states.
///
/// @return TRUE on output change; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::UpdateOutputDigital(const BOOL NewState) {
	class CPPDOChannel *pDigOutChan = NULL;
//	class CDataItem *pDigHolder = NULL;
	BOOL retValue = FALSE;
	// Ensure service is only performed on correct I/O channel type
	if (m_ChanInfo.PPService == PP_SERVICE_DO_CHAN) {
		// Get digital output channel handler
		pDigOutChan = GetServiceManager()->GetDOService();
		retValue = pDigOutChan->UpdateOutputDigital(&m_ChanInfo, NewState);
	}
	/*
	 else if( m_ChanInfo.PPService == PP_SERVICE_DI_CHAN )
	 {
	 // Stub to allow individual digital input channels to be set
	 if( pDIT != NULL )
	 {
	 // Set the digital data item table value and register it as a change
	 pDigHolder = pDIT->GetDataItemPtr( DI_IO, DI_IO_DIGITAL, m_ChanInfo.glbchannelNo-1 );
	 if( pDigHolder != NULL )
	 {
	 pDigHolder->SetValue( static_cast<float> (NewState));
	 if( NewState != m_ChanInfo.LastOPState)
	 {
	 m_ChanInfo.LastOPState = NewState;
	 retValue = TRUE;
	 }
	 }
	 }
	 }
	 */
	return retValue;
}
//******************************************************
// OutputAnalogue()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
///
/// @param[out] pOutputVal - System channel 16-bit anslogue data.
/// @param[out] pChanNo - Card channel number.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::OutputAnalogue( USHORT *pOutputVal, UCHAR *pChanNo) {
	class CPPAOChannel *pAOChan = NULL;
	BOOL retValue = FALSE;
	// Ensure service is only performed on correct I/O channel type
	if (m_CSInfo.PPService == PP_SERVICE_AO_CHAN) {
		// Get AO channel handler
		pAOChan = GetServiceManager()->GetAOService();
		retValue = pAOChan->OutputAnalogue(&m_ChanInfo, pOutputVal);
		*pChanNo = m_ChanInfo.channelNo;
	}
	return retValue;
}
//******************************************************
// ProcessChannelReadings()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
///
/// @param[in] pServiceData - Pointer to a data buffer holding the channel data.
/// @param[in] timestamp - The timestamp of the newest reading.
/// @param[in] noOfReadings - Number of readings in buffer to be processed.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::ProcessAIChannelReadings(const UCHAR *pServiceData, const USHORT timestamp,
		const USHORT noOfReadings) {
	BOOL retValue = FALSE;
	class CPPAIChannel *pAIChan = NULL;
	// Ensure service is only performed on correct I/O channel type
	if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) {
		// Get AI channel handler
		pAIChan = GetServiceManager()->GetAIService();
		if (pAIChan != NULL)
			retValue = pAIChan->ProcessAIChannelReadings(&m_CSInfo, &m_ChanInfo, pServiceData, timestamp, noOfReadings);
	}
	return retValue;
}
//******************************************************
// AIProcessMissingChannelReadings()
///
/// Process a set of unavailable board channel readings according to the channel setup
///
/// @param[in] lastProcTime - The system time currently processed.
/// @param[in] procTime - The system time to process upto.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
LONGLONG CIOChanHandler::AIProcessMissingChannelReadings(const LONGLONG lastProcTime, const LONGLONG procTime) {
	LONGLONG processedTime = 0;
	class CPPAIChannel *pAIChan = NULL;
	// Ensure service is only performed on correct I/O channel type
	if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) {
		// Get AI channel handler
		pAIChan = GetServiceManager()->GetAIService();
		if (pAIChan != NULL)
			processedTime = pAIChan->AIProcessMissingChannelReadings(&m_CSInfo, &m_ChanInfo, lastProcTime, procTime);
	}
	return processedTime;
}
//******************************************************
// ResetRawVoltageReadings()
///
/// Reset raw reading holders to show no valid data
/// 
//******************************************************
void CIOChanHandler::ResetRawVoltageReadings(void) {
	class CPPAIChannel *pAIChan = NULL;
	class CPPPulseChannel *pPIChan = NULL;
	// Ensure service is only performed on correct I/O channel type
	if (m_ChanInfo.PPService == PP_SERVICE_AI_CHAN) {
		// Get AI channel handler
		pAIChan = GetServiceManager()->GetAIService();
		if (pAIChan != NULL)
			pAIChan->ResetRawVoltageReadings(&m_ChanInfo);
	}
}
//******************************************************
// ResetDigPulseDITValues()
///
/// Reset the digital DIT reading holders to default
/// 
//******************************************************
void CIOChanHandler::ResetDigPulseDITValues(void) {
	class CPPDOChannel *pDigChan = NULL;
	// Get pulse channel handler
	pDigChan = GetServiceManager()->GetDOService();
	if (pDigChan != NULL)
		pDigChan->ResetPulseValueHolder(&m_ChanInfo);
}
//******************************************************
// ResetDigitalDITValues()
///
/// Reset the digital DIT reading holders to default
/// 
//******************************************************
void CIOChanHandler::ResetDigitalDITValues(void) {
	class CPPDOChannel *pDigChan = NULL;
	// Get pulse channel handler
	pDigChan = GetServiceManager()->GetDOService();
	if (pDigChan != NULL)
		pDigChan->ResetDigitalCounter(&m_ChanInfo);
}
//******************************************************
// ResetPulseDITValues()
///
/// Reset the accumulated pulse DIT reading holders to default
/// 
//******************************************************
void CIOChanHandler::ResetPulseDITValues(void) {
	class CPPPulseChannel *pPIChan = NULL;
	// Get pulse channel handler
	pPIChan = GetServiceManager()->GetPulseService();
	if (pPIChan != NULL)
		pPIChan->ResetPulseCountAccumulation(&m_ChanInfo);
}
//******************************************************
// AIProcessMissingChannelReadings()
///
/// Process a set of unavailable board channel readings according to the channel setup
///
/// @param[in] lastProcTime - The system time currently processed.
/// @param[in] procTime - The system time to process upto.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
LONGLONG CIOChanHandler::PulseProcessMissingChannelReadings(const LONGLONG lastProcTime, const LONGLONG procTime) {
	LONGLONG processedTime = FALSE;
	class CPPPulseChannel *pPulseChan = NULL;
	// Ensure service is only performed on correct I/O channel type
	if (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN) {
		// Get AI channel handler
		pPulseChan = GetServiceManager()->GetPulseService();
		if (pPulseChan != NULL)
			processedTime = pPulseChan->ProcessMissingChannelReadings(&m_CSInfo, &m_ChanInfo, lastProcTime, procTime);
	}
	return processedTime;
}
//******************************************************
// ProcessPulseChannelReadings()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
///
/// @param[in] pServiceData - Service message data.
/// @param[in] timestamp - Timestamp of the latest reading in buffer.
/// @param[in] noOfReadings - Number of readings in buffer to be processed.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
BOOL CIOChanHandler::ProcessPulseChannelReadings(const UCHAR *pServiceData, const USHORT timestamp,
		const USHORT noOfReadings) {
	BOOL retValue = FALSE;
	class CPPPulseChannel *pPulseChan = NULL;
	// Ensure service is only performed on correct I/O channel type
	if (m_ChanInfo.PPService == PP_SERVICE_PULSE_CHAN) {
		// Get Pulse channel handler
		pPulseChan = GetServiceManager()->GetPulseService();
		if (pPulseChan != NULL)
			retValue = pPulseChan->ProcessPulseChannelReadings(&m_ChanInfo, pServiceData, timestamp, noOfReadings);
	}
	return retValue;
}

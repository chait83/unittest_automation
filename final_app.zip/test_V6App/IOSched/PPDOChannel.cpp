/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n Protocol.cpp
/// @n implementation for the abstract CAIChannel class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 39	Stability Project 1.34.1.3	7/2/2011 4:59:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 38	Stability Project 1.34.1.2	7/1/2011 4:38:39 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 37	Stability Project 1.34.1.1	3/17/2011 3:20:34 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 36	Stability Project 1.34.1.0	2/15/2011 3:03:41 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "PPQManager.h"
#include "DataItemManager.h"
#include "DataItemIO.h"
#include "V6globals.h"
#include "V6IOErrorCodes.H"
#include "IOCard.h"
#include "DigPulseCard.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "PPIOService.h"
#include "PPDOChannel.h"
#include "TraceDefines.h"
#include "PPL.h"
#include <math.h>
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define MAX_DO_RETURN_READINGS 256
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPPDOChannel::CPPDOChannel(BOOL chanInput) : CPPIOService(chanInput) {
//	qDebug("Create new CPPDOChannel\n");
//	m_LastOPState = DEFAULT_DIGITAL_IO_STATE;
}
CPPDOChannel::~CPPDOChannel() {
//	qDebug("Delete CPPDOChannel class\n");
}
/////////////////////////////////////////////////////
/// Create the default definition of an DO channel
/// @param[in] pboardInfo - The board process info.
/// @param[in] pchanInfo - The channel process info.
/// @param[in] pCard - The I/O board class.
/// @param[in] chanNo - The board channel number.
///
/// @return TRUE if channel configured; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPDOChannel::CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
		class CCardSlot *pCard,
		USHORT chanNo) {
	static BOOL powerUp = TRUE;	//MarkD
	BOOL retValue = FALSE;
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	pSlotMapObj = CSlotMap::GetHandle();
	if (pSlotMapObj != NULL) {
		pboardInfo->input = FALSE;
		pboardInfo->pCard = pCard;
		pboardInfo->CardSlotNo = static_cast<UCHAR>(pCard->BoardSlotInstance());
		pchanInfo->PPService = PP_SERVICE_DO_CHAN;
		pchanInfo->channelNo = static_cast<UCHAR>(chanNo);
		pchanInfo->glbchannelNo = pSlotMapObj->GetSysChannelFromDigIOChannel(pboardInfo->CardSlotNo, chanNo, ONE_BASED);
		if (powerUp == TRUE) {
			pchanInfo->LastOPState = DEFAULT_DIGITAL_IO_STATE;	//MarkD: do this first time only, ie on power-up		
			powerUp = FALSE;
		}
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
// ResetPulseValueHolder()
///
/// Reset digital reading holder to default state
/// @param[in] pChanInfo - The channel process info.
/// 
//******************************************************
void CPPDOChannel::ResetPulseValueHolder(T_PCHANPROCESSINFO pChanInfo) {
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	class CDataItem *pDataItem = NULL;
	pSlotMapObj = CSlotMap::GetHandle();
	// Reset the accumulated pulse count value
	if (pSlotMapObj->IsCardInTopSlot(pChanInfo->pCommon->CardSlotNo) == TRUE)
		pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_HCOUNT, pChanInfo->glbchannelNo - 1);
	else
		pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_LCOUNT, pChanInfo->glbchannelNo - 1);
	if (NULL != pDataItem) {
		pDataItem->SetValue(0.0F);
		pDataItem->SetStatus(DISTAT_NORMAL);
	}
}
//******************************************************
// ResetDigitalCounter()
///
/// Reset digital reading holder to default state
/// @param[in] pChanInfo - The channel process info.
/// 
//******************************************************
void CPPDOChannel::ResetDigitalCounter(T_PCHANPROCESSINFO pChanInfo) {
	class CDataItem *pDataItem = NULL;
	// Reset the accumulated pulse count value
	pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_IO, pChanInfo->glbchannelNo - 1);
	if (NULL != pDataItem) {
		pDataItem->SetValue(0.0F);
		pDataItem->SetStatus(DISTAT_NORMAL);
	}
}
//******************************************************
// OutputDigital()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
/// @param[in] pChanInfo - System channel data.
/// @param[out] pNewOPState - System channel digital O/P states.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CPPDOChannel::OutputDigital(T_PCHANPROCESSINFO pChanInfo, BOOL *pNewOPState) {
	class CDataItem *pDigHolder = NULL;
	class CDigPulseCard *pDigCard = NULL;
	CNVBasicVar *pOPStateVar = NULL;
	COMBO_VAR4 OPStateVar;
	BOOL retValue = FALSE;
	if ( pDIT != NULL) {
		pDigHolder = pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, pChanInfo->glbchannelNo - 1);
		if (pDigHolder != NULL) {
			*pNewOPState = static_cast<BOOL>(pDigHolder->GetFPValue());
			if (*pNewOPState != pChanInfo->LastOPState) {
				// Output has changed therfore update I/O card
				pChanInfo->LastOPState = *pNewOPState;
				// Log state change to the message list
				pDigCard = reinterpret_cast<class CDigPulseCard*>(pChanInfo->pCommon->pCard);
				pDigCard->LogDigitalState(pChanInfo->glbchannelNo, *pNewOPState);
				if (IsRunningAsATEEquipment() == FALSE) {
					// Update the number of digital activation history in Non volatile
					if (*pNewOPState == TRUE) {
						pOPStateVar = pNV_VARS->GetBasicVarNVObject(
								static_cast<NVVAR_IDENT>(NVV_RELAY_OPS_FIRST + pChanInfo->glbchannelNo - 1));
						OPStateVar = pOPStateVar->GetFromNV()->value;
						OPStateVar.ul++;
						pOPStateVar->SetToNV(OPStateVar);	// Store back to NV
					}
				}
				// Update the digital I/O counter
				if (*pNewOPState == TRUE) {
					// Increment the accumulated pulse count value
					pDigHolder = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_IO, pChanInfo->glbchannelNo - 1);
					if (NULL != pDigHolder) {
						pDigHolder->SetValue(pDigHolder->GetFPValue() + 1.0F);
						pDigHolder->SetStatus(DISTAT_NORMAL);
					}
				}
				retValue = TRUE;
			}
			if ((pChanInfo->chanInfo.DigChanInfo.pChanCfgInfo->OutputLatched == FALSE) && (*pNewOPState == TRUE)) {
				// If the channel is a pulsed output and has just been selected;
				pDigHolder = pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, pChanInfo->glbchannelNo - 1);
				// Automatically deselect to prempt that the I/O card will automatically deselect
				// relay after the required time
				pDigHolder->SetValue(static_cast<float>(FALSE));
				pChanInfo->LastOPState = FALSE;
			}
		}
	}
	return retValue;
}
//******************************************************
// UpdateOutputDigital()
///
/// Update the output cache with the new output state.
/// @param[in] pChanInfo - System channel data.
/// @param[in] NewOPState - System channel digital O/P state.
///
/// @return TRUE on a O/P change being made; otherwise FALSE
/// 
//******************************************************
BOOL CPPDOChannel::UpdateOutputDigital(T_PCHANPROCESSINFO pChanInfo, const BOOL NewOPState) {
	class CDataItem *pDigHolder = NULL;
	BOOL retValue = FALSE;
	if ( pDIT != NULL) {
		pDigHolder = pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, pChanInfo->glbchannelNo - 1);
		if (pDigHolder != NULL) {
			pDigHolder->SetValue(static_cast<float>(NewOPState));
			if (NewOPState != pChanInfo->LastOPState)
				retValue = TRUE;
		}
	}
	return retValue;
}

//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AICard.h
/// @n interface for the AI card class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 36	Stability Project 1.33.1.1	7/2/2011 4:55:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 35	Stability Project 1.33.1.0	7/1/2011 4:27:03 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 34	V6 Firmware 1.33		1/19/2007 5:11:50 PM	Graham Waterfield
//		Allow AO load status check message to be scheduled
// 33	V6 Firmware 1.32		6/9/2006 1:11:43 PM	Graham Waterfield
//		Merged phase 2 development
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _AOCARD_H
#define _AOCARD_H
#if !defined(AFX_AOCARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_AOCARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#include "AOConfig.h"
#define AO_CHAN_NOT_ENABLED					0x00		///< Not enabled
#define AO_CHAN_CURRENT_LOOP_OK				0x01		///< Current loop OK
#define AO_CHAN_CURRENT_LOOP_OC				0x02		///< Current loop open circuit
#define AO_CHAN_RAW_MODE_CURRENT_LOOP_OK	0x03		///< In raw mode but current loop OK
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// #define MAX_AO_BOARD_CHANNELS	4
class CAOCard: public CIOCard {
	// Allow the protocol to query boards
	friend class CProtocol;
public:
	virtual BOOL RunProcess(void);
	BOOL ScheduleBoardProcess(void);
	BOOL ScheduleNextChannelProcess(void);
	BOOL Initialise(void);
	virtual BOOL InitialiseCard(const USHORT cardNo);
	BOOL GetChannelConfigRef(UCHAR ChanNo, T_AOCFGCHANNEL **ppChanCfgInfo, T_AOWRKCHANNELCFG **ppChanWrkInfo);
	BOOL OperateTransactionSM(class CProtocol *const pProtocol);
	BOOL PerformSMModeChange(class CProtocol *const pProtocol);
	BOOL ScheduleFactoryCalUpload(void);
	BOOL ScheduleChannelStatusCheck(void);
	BOOL ProcessOutputChannel( USHORT *pCardData, const UCHAR nextToService, UCHAR *pChanNo);
	virtual IOCARDSTAT IOCardCommand(const USHORT newCmd);
	virtual USHORT GetChannelAcqRate(const UCHAR chanNo) const;
	virtual USHORT CalculateChannelReadRate(const UCHAR chanNo);
	virtual BOOL SetSpecialTestMode(const BOOL state);
	virtual BOOL DoesBoardRqSched(void);
	virtual USHORT ChannelsToService(void);
	virtual BOOL InitialiseCardConfig(void);
	virtual BOOL CMMCreateLocalConfig(void);
	virtual void GetIOCardStrID(QString *pIDText) const;
	virtual void GetIOCardStrDescription(QString *IDText);
	virtual BOOL GetIOLifeHistory(class CProtocol *const pProtocol);
	BOOL SaveIOLifeHistory(class CProtocol *const pProtocol);
	CAOCard(USHORT CardSlotID);
	virtual ~CAOCard();
protected:
	void PrioritizeSchedule(void);
private:
	class CIOConfigManager *m_pConfigMngrObj;	///< Configuration manager
	class CAOConfig *m_pAOConfigObj;			///< AO board configuration
	BOOL m_OutputUpdateRqd;	///< Tracks whether output on this board is required
	BOOL m_StatusCheckRqd;		///< TRUE if channel status check is required
};
#endif // !defined(AFX_AOCARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#endif // _AOCARD_H

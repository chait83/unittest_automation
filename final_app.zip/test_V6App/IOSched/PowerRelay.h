//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PowerRelay.h
/// @n interface for the CPowerRelay class.
///	The power relay board is a single channel output relay only
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 21	Stability Project 1.18.1.1	7/2/2011 4:59:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 20	Stability Project 1.18.1.0	7/1/2011 4:27:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 19	V6 Firmware 1.18		6/8/2006 6:30:19 PM	Graham Waterfield
//		Phase 2 development changes merged
// 18	V6 Firmware 1.17		2/21/2006 4:26:33 PM	Graham Waterfield
//		Interim check-in to allow removal of unwanted CMM variables
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _POWERRELAY_H
#define _POWERRELAY_H
#if !defined(AFX_POWERRELAY_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_POWERRELAY_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#include "Defines.h"
#include "CardSlot.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CPowerRelay: public CCardSlot {
public:
//		BOOL RunProcess(void *pNextAction);
	BOOL ScheduleProcess(void);
	virtual BOOL InitialiseCard(const USHORT cardNo);
	BOOL ScheduleBoardProcess(void);
	BOOL SetupConfigChangePreparation(void);
	BOOL RunProcess(void);
	virtual IOCARDSTAT IOCardCommand(const USHORT newCmd);
	virtual USHORT GetChannelAcqRate(const UCHAR chanNo) const;
	virtual USHORT CalculateChannelReadRate(const UCHAR chanNo);
	virtual BOOL SetSpecialTestMode(const BOOL state);
	virtual BOOL IsCMMConfigValid(void);
	virtual BOOL DoesBoardRqSched(void);
	virtual USHORT ChannelsToService(void);
	virtual BOOL ScheduleErrorDownload(void);
	virtual BOOL InitialiseCardConfig(void);
	BOOL CMMCreateLocalConfig(void);
	CPowerRelay(USHORT CardSlotID);
	virtual ~CPowerRelay();
private:
	BOOL m_RTState;							///< Relay run-time state
	BOOL m_OPUpdateRequired;				///< Is startup update required
	class CIOConfigManager *m_pConfigMngrObj;	///< Configuration manager
};
#endif // !defined(AFX_POWERRELAY_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#endif // _POWERRELAY_H

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: IOCardHandler.h
/// @n Desc:	interface for the I/O card class
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 17	Stability Project 1.14.1.1	7/2/2011 4:58:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 16	Stability Project 1.14.1.0	7/1/2011 4:27:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 15	V6 Firmware 1.14		10/4/2005 7:23:31 PM	Graham Waterfield
//		Implement ohms auto 2-wire and 3-wire measurement selection
// 14	V6 Firmware 1.13		8/24/2005 3:25:16 PM	Graham Waterfield
//		Ensure all queues are reset, disabled and removed when configuration
//		is changed
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _IOCARDHANDLER_H
#define _IOCARDHANDLER_H
#if !defined(AFX_IOCARDHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_IOCARDHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "PPQManager.h"
class CIOCardHandler: public CIOHandler {
public:
	CIOCardHandler();
	virtual ~CIOCardHandler();
//		T_PPQC_DIGITAL_PPQ_TYPE GetDigitalPPQReference( void );
	BOOL InitialiseCardService(T_COMMONPROCESSINFO *const pBoardInfo);
	BOOL SetupConfigChangePreparation(void);
	BOOL ProcessDigitalInReadings(const UCHAR *pServiceData, const USHORT noOfBytesToProcess);
	BOOL SyncService(const USHORT IOCardTick, const LONGLONG systemTick);
	BOOL ResyncService(const USHORT IOCardTick, const LONGLONG systemTick);
	BOOL SetLastReadingCoverage(const LONGLONG systemTick);
	BOOL StartChanService(T_COMMONPROCESSINFO *const pBoardInfo);
protected:
	T_COMMONPROCESSINFO m_Info;			///< Card specific process information
};
#endif // !defined(AFX_IOCARDHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _IOCARDHANDLER_H

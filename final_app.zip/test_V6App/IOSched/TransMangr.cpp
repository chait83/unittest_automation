/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n TransMangr.cpp
/// @n implementation for the CTransMangr class.
/// transactions are passed to the transaction manager that checks the status of all I/O board transactions
/// If no transactions are currently being processed then the required transaction(s) are passed to the
/// transaction layer.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  30  Stability Project 1.25.1.3 7/2/2011 5:02:10 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  29  Stability Project 1.25.1.2 7/1/2011 4:39:03 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  28  Stability Project 1.25.1.1 3/17/2011 3:20:51 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  27  Stability Project 1.25.1.0 2/15/2011 3:04:06 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "BoardManager.h"
#include "BaseProtocol.h"
#include "Protocol.h"
#include "IOCard.h"
#include "PPQCommon.h"
#include "V6IOBoardTypes.H"
// #include "tv6timer.h"
#include "TransMngr.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//******************************************************
///
/// Constructor for the transaction manager
///
//******************************************************
CTransMangr::CTransMangr() {
	USHORT cardNo;
//	qDebug("Create new CTransMangr\n");
	m_ProcessingTransaction = FALSE;
	// No card transactions to date.
	for (cardNo = 0; cardNo < MAX_SCHED_SERVICES; cardNo++) {
//		m_pSPICardTransHndlr[cardNo] = NULL;
		m_pBoard[cardNo] = NULL;
	}
}
//******************************************************
///
/// Destructor for the transaction manager
///
//******************************************************
CTransMangr::~CTransMangr() {
//	USHORT cardNo;
//	qDebug("Deleting CTransMangr class\n");
	// Delete the common protocol module
	if (m_pProtocol != NULL) {
		delete m_pProtocol;
		m_pProtocol = NULL;
	}
	// Remove each of the cards transaction handlers
//	for(cardNo = 0; cardNo < MAX_SCHED_SERVICES; cardNo++)
//	{
//		if( m_pSPICardTransHndlr[cardNo] != NULL )
//		{
//			delete m_pSPICardTransHndlr[cardNo];
//			m_pSPICardTransHndlr[cardNo] = NULL;
//		}
//	}
	//deletion of mutex not required
}
//******************************************************
///
/// Initialise the current transaction manager process.
///
//******************************************************
BOOL CTransMangr::InitialiseTransManager(void) {
	BOOL retValue = FALSE;
	m_pProtocol = new CProtocol;		// Create the single protocol instances
	if (m_pProtocol != NULL)
		retValue = m_pProtocol->InitialiseProtocol();
	else {
		/// @todo: Failed to create the main protocol message generator and decoder
	}
	return retValue;
}
//******************************************************
// InitialiseTransProcess()
///
/// Initialise the current transaction process.
/// @param[in] cardNo - The transaction's slot number to initialise.
///
//******************************************************
BOOL CTransMangr::InitialiseTransProcess( USHORT cardNo) {
//	m_pSPICardTransHndlr[cardNo]->ResetTransProcess();
	return TRUE;
}
//******************************************************
// InitialiseTransaction()
///
/// Initialise a transaction for a particular board.
/// @param[in] pBoard - Board that the transaction is destined for.
///
/// @return TRUE if successfully initialised; otherwise FALSE
/// 
//******************************************************
BOOL CTransMangr::InitialiseTransaction(class CIOCard *pBoard) {
	USHORT cardNo;
	UCHAR boardType;
	BOOL retValue = FALSE;
	class CProtocol *pProtocol = NULL;
	if (pBoard == NULL) {
		return FALSE;
	}
	cardNo = pBoard->BoardSlotInstance();
//	m_pSPICardTransHndlr[cardNo] = new CTransaction;
	m_pBoard[cardNo] = pBoard;
	boardType = m_pBoard[cardNo]->GetBoardType();
	pProtocol = RequestTransToken(pBoard);
//	if( (boardType == BOARD_AI) || (boardType == BOARD_PI) )
//		retValue = pProtocol->CalculateQueueGearingRatio( PPQC_TIME_BASE );
	TransactionTerminated();
	return retValue;
}
//******************************************************
// StartTransaction()
///
/// Starts a card protocol transaction to gather required data.
/// @param[in] transactionType - The type of transaction to start.
/// @param[in] slotNo - The slot number that the transaction will handle.
///
/// @return TRUE if transaction request is started; otherwise return FALSE
/// 
//******************************************************
class CProtocol* CTransMangr::RequestTransToken(class CIOCard *pBoard) {
//	class CIOCard *pBoard = m_pBoard[slotNo];
	class CChanList *pChanSched = NULL;
	class CProtocol *pRetValue = NULL;
	USHORT slotNo;
	m_csVariable.lock();
	// Can't process more than a single transaction at any instance
	if (m_ProcessingTransaction == TRUE) {
		m_csVariable.lock();
		return NULL;
	}
	pChanSched = pBoard->GetChanSchedule();
	slotNo = pBoard->BoardSlotInstance();
	if ((m_pProtocol != NULL) && (m_pProtocol->SelectBoard(pBoard) != FALSE)) {
		m_ProcessingTransaction = TRUE;
	}
	/*
	 if( m_pSPICardTransHndlr[slotNo] != NULL )
	 {
	 /// @todo: If multiple processes then need to lock/unlock
	 
	 // Start transaction, if transaction handler exists
	 m_ProcessingTransaction = TRUE;
	 TransactionStarted = 
	 m_pSPICardTransHndlr[slotNo]->StartTransaction( transactionType, pBoard );
	 if( TransactionStarted == FALSE )
	 {
	 m_ProcessingTransaction = FALSE;
	 }
	 }
	 */
	if (m_ProcessingTransaction == TRUE) {
		pRetValue = m_pProtocol;
	}
	m_csVariable.lock();
	return pRetValue;
}
//******************************************************
// TransactionTerminated()
///
/// Log that the current transaction has terminated.
/// 
//******************************************************
void CTransMangr::TransactionTerminated(void) {
	m_ProcessingTransaction = FALSE;
}
//******************************************************
// IsTransMangBusy()
///
/// Is a board currently being processed
///
/// @return TRUE if the transaction manager is busy; otherwise return FALSE
/// 
//******************************************************
BOOL CTransMangr::IsTransMangBusy(void) const {
	return m_ProcessingTransaction;
}
//******************************************************
// AITransSchedule()
///
/// Main AI transaction scheduler.
/// @param[in] slotNo - The slot number that the transaction will handle.
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
BOOL CTransMangr::AITransSchedule( USHORT slotNo) {
	class CIOCard *pBoard = m_pBoard[slotNo];
	// If last transction sequence has finished then start the next schedule
	if (IsTransMangBusy() == FALSE) {
//		m_pSPICardTransHndlr[slotNo]->StartTransaction( SETID, pBoard );
	}
	return TRUE;
}

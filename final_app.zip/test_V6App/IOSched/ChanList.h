/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n CardList.h
/// @n interface of the CChanList class.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 30	Stability Project 1.27.1.1	7/2/2011 4:56:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 29	Stability Project 1.27.1.0	7/1/2011 4:27:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 28	V6 Firmware 1.27		11/22/2006 5:34:40 PM Graham Waterfield
//		Output the current digital DIT values to digital output channels on
//		configuration change
// 27	V6 Firmware 1.26		11/10/2006 2:17:33 PM Graham Waterfield
//		Integrate digital I/O counters
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_CHANLIST_H__ADE513C3_9F85_442D_A2A6_6B8E312021EF__INCLUDED_)
#define AFX_CHANLIST_H__ADE513C3_9F85_442D_A2A6_6B8E312021EF__INCLUDED_
#include "Defines.h"
const UCHAR MAXIOCHANS = 16;
class CChanList {
private:
	class CIOHandler *m_pIOHndlr[MAXIOCHANS]; ///< Base class I/O channel holder for common schedule query
	UCHAR m_BoardInstance;						///< Board instance number
	UCHAR m_ChannelCount;						///< Number of channels on card
	UCHAR m_ChannelListCount;		///< Number of channels in this channel list
	/// Data for card stats and info
	class CBrdInfo *m_pBrdInfoObj;			///< Board info holder
	class CBrdStats *m_pBrdStatsObj;		///< Board stats holder
	class CSlotMap *m_pSlotMapObj;			///< Slot map holder
	class CPPIOServiceManager *m_pServiceManagerObj;		///< Service manager
	BOOL m_OPUpdateRequired;		///< Is output update required from saved ouput state
	BOOL m_ForceCardUpdate;	///< Is the first output update required from the DIT table
public:
	CChanList(const UCHAR slotNo);
	virtual ~CChanList();
	BOOL Initialise(void);
	BOOL ChannelFactory(class CCardSlot *const pCard, const BOOL refurbish);
	UCHAR GetListCount();
	void SetChannelCount(UCHAR noOfChannels);
	BOOL SetGlobalChannelID(const USHORT channelNo, const USHORT glbChannelNo);
	BOOL AddChanToSchedule(USHORT chanNo, class CIOHandler *const pChan);
	class CIOChanHandler* GetChannelRef(const USHORT chanNo);
	BOOL DestroyChannels(void);
	BOOL RemoveChanFromSchedule(const USHORT chanNo);
	BOOL SetSpecialTestMode(const USHORT cardNo);
	UCHAR GetBoardID(void);
	USHORT GetChannelCount(void);
	BOOL ScheduleChannelRead(const USHORT channelNo);
	USHORT GetChannelReadRate(const USHORT channelNo) const;
	USHORT GetChannelAcqRate(const USHORT channelNo) const;
	LONGLONG GetTimeServiceRqd(const USHORT channelNo);
	BOOL GetEarliestServiceRqd(USHORT *const pchannelNo, LONGLONG *const pearliestTime);
	BOOL ResetPersistedDigitalPersistChannels(const USHORT chanMask);
	BOOL ResetPersistedDigitalDITValues();
	BOOL ProcessOutputChannels(USHORT *pCardData);
	BOOL ProcessOutputChannel(USHORT *pCardData, const UCHAR nextToService, UCHAR *pChanNo);
	BOOL SetupConfigChangePreparation(void);
};
#endif // !defined(AFX_CHANLIST_H__ADE513C3_9F85_442D_A2A6_6B8E312021EF__INCLUDED_)

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: BaseProtocol.h
/// @n Desc:	interface of the CBaseProtocol class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//	28-07-17	Shankar Rao		Added Sub Error Code detection to process error data patterns and identify detailed errors in IO
// 18-09-15	Rajanbabu M			Updated GetSecondaryFwVersion() method to get secondary firmware version dynamically
// 69	Stability Project 1.65.1.2	7/5/2011 5:04:06 PM	Hemant(HAIL) 
//		Fixed provided for recorder getting hanged after data reset, if 96
//		Pens are enabled for logging.
// 68	Stability Project 1.65.1.1	7/2/2011 4:55:37 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 67	Stability Project 1.65.1.0	7/1/2011 4:27:03 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 66	V6 Firmware 1.65		2/2/2009 12:34:47 PM	Build Machine cr
//		3078 -- increased startup time for fixing slow recorder unit for
//		specific setup with 6 io cards
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _BASEPROTOCOL_H
#define _BASEPROTOCOL_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// #define ECHO_IO_COMMAND		1		///< Ensure all commands sent are echo'd to the qDebug log
#include "V6IOConstraints.H"
#include "IOCardStats.h"
#include "StoragePaths.h"
#include "TVtime.h"
#include "V6Config.h"
#if defined (DBG_FILE_LOG_IO_DBG_ENABLE) || defined (DBG_FILE_LOG_IO_ERR_ENABLE)
#include "CStorage.h" //PSR - Debug File Logger integration
#endif
#define MAXBUFFERSIZE 500		// Actual max return from IOCard is 491
#define REV_B_PROCESSOR_BOARD	0							///< Rev B processor board revision number
#define MAX_SPI_WRITE_TRIES		1							///< Retries for writing to SPI
#define MAX_SPI_MSG_TRIES		1/*3*/							///< Retries for writing messages to SPI
// Byte swapping functions
#define SWAP_BYTE_0		0
#define SWAP_BYTE_1		1
#define SWAP_BYTE_2		2
#define SWAP_BYTE_3		3
#define IO_MESSAGE_START_BYTE			0
// TX Header defines
#define TX_FUNCTION_CODE_BYTE			0
#define TX_INV_FUNCTION_CODE_BYTE		1
#define TX_HIGH_BYTES_TO_FOLLOW_BYTE	2
#define TX_LOW_BYTES_TO_FOLLOW_BYTE		3
// RX Header defines
#define RX_FX_CODE					0
#define RX_MESS_EC_BYTE				1
#define RX_MESS_HI_BYTE_COUNT		2
#define RX_MESS_LO_BYTE_COUNT		3
#define RX_START_OF_DATA			4
#define NO_MESSAGE_DATA_BYTES		0
#define MESSAGE_DATA_1_BYTE			1
#define MESSAGE_DATA_2_BYTES		2
#define MESSAGE_DATA_3_BYTES		3
#define MESSAGE_DATA_4_BYTES		4
#define MESSAGE_DATA_5_BYTES		5
#define MESSAGE_DATA_6_BYTES		6
#define MESSAGE_DATA_9_BYTES		9
#define MESSAGE_DATA_16_BYTES		16
#define MESSAGE_DATA_17_BYTES		17
#define MESSAGE_DATA_45_BYTES		45
#define NO_RESPONSE_IO_TICK_DEFAULT		1			///< Default I/O card tick to sync PPQ with if no response found
const UCHAR IO_CARD_CHANNEL_1 = 0;
const UCHAR IO_CARD_CHANNEL_2 = 1;
const UCHAR IO_CARD_CHANNEL_3 = 2;
const UCHAR IO_CARD_CHANNEL_4 = 3;
const UCHAR IO_CARD_CHANNEL_5 = 4;
const UCHAR IO_CARD_CHANNEL_6 = 5;
const UCHAR IO_CARD_CHANNEL_7 = 6;
const UCHAR IO_CARD_CHANNEL_8 = 7;
const UCHAR IO_CARD_CHANNEL_9 = 8;
const UCHAR IO_CARD_CHANNEL_10 = 9;
const UCHAR IO_CARD_CHANNEL_11 = 10;
const UCHAR IO_CARD_CHANNEL_12 = 11;
const UCHAR IO_CARD_CHANNEL_13 = 12;
const UCHAR IO_CARD_CHANNEL_14 = 13;
const UCHAR IO_CARD_CHANNEL_15 = 14;
const UCHAR IO_CARD_CHANNEL_16 = 15;
const UCHAR IO_CARD_ARGUMENT_1 = 0;
const UCHAR IO_CARD_ARGUMENT_2 = 1;
const UCHAR IO_CARD_ARGUMENT_3 = 2;
const UCHAR IO_CARD_ARGUMENT_4 = 3;
const UCHAR IO_CARD_ARGUMENT_5 = 4;
const UCHAR IO_CARD_ARGUMENT_6 = 5;
const UCHAR IO_CARD_ARGUMENT_7 = 6;
const UCHAR IO_CARD_ARGUMENT_8 = 7;
const UCHAR IO_CARD_ARGUMENT_9 = 8;
const UCHAR IO_CARD_ARGUMENT_10 = 9;
const UCHAR IO_CARD_ARGUMENT_11 = 10;
const UCHAR IO_CARD_ARGUMENT_12 = 11;
const UCHAR IO_CARD_ARGUMENT_13 = 12;
const UCHAR IO_CARD_ARGUMENT_14 = 13;
const UCHAR IO_CARD_ARGUMENT_15 = 14;
const UCHAR IO_CARD_ARGUMENT_16 = 15;
const USHORT WAIT_1ms = 1;
const USHORT WAIT_8ms = 8;
const USHORT WAIT_10ms = 10;
const USHORT WAIT_20ms = 20;
const USHORT WAIT_30ms = 30;
const USHORT WAIT_50ms = 50;
const USHORT WAIT_80ms = 80;
const USHORT WAIT_100ms = 100;
const USHORT WAIT_150ms = 150;
const USHORT WAIT_300ms = 300;
const USHORT WAIT_350ms = 350;
const USHORT WAIT_750ms = 750;
const USHORT WAIT_1000ms = 1000;
const USHORT WAIT_1250ms = 1250;
const USHORT WAIT_2000ms = 2000;
const USHORT WAIT_2500ms = 2500;
const USHORT WAIT_3000ms = 3000;
const USHORT WAIT_15sec = 15000;
const USHORT WAIT_20sec = 20000;
const USHORT WAIT_25sec = 25000;
const USHORT WAIT_30sec = 30000;
//Recorder gets hang because of Timeout.so changed Timeout to 6 sec. instead of 4 sec.
const USHORT WAIT_60sec = 60000; //40000; //bpcode
const UCHAR NO_OF_BYTES_IN_SHORT = 2;
const UCHAR NO_OF_SHORTS_IN_FLOAT = 2;
const UCHAR NO_OF_BYTES_IN_FLOAT = 4;
#define MAX_BYTE_VALUE			256
#define STD_TX_MESS_LENGTH		6
#include "BoardManager.h"
// Structure to aid byte swapping of card data
union DataItem2bytes {
	USHORT USData;			///< Native data item
	UCHAR UCData[NO_OF_BYTES_IN_SHORT];
};
union DataItem4bytes {
	float FData;			///< Native data item
	ULONG ULData;			///< Native data item
	USHORT USData[NO_OF_SHORTS_IN_FLOAT];
	UCHAR UCData[NO_OF_BYTES_IN_FLOAT];
};
//New sub error codes to detect IO Bufferover flows etc on specific error patterns received from IO Module
typedef enum {
	SUB_ERR_NOTHING = 0, SUB_ERR_PARTIAL_DATA, SUB_ERR_AI_BUFFER_OVER_FLOW,
	//Add new detailed or sub err codes here
	ERR_DET_UNKNOWN,
} E_IO_MOD_SUB_ERROR_CODE;
class CSimpleLog {
private:
	WCHAR m_filePathAndFileName[MAX_PATH];
//  CStor m_Storage;
	T_STORAGE_DEVICE m_Location;
	BOOL m_logOn;
};
//**Class*********************************************************************
///
/// @brief Manage communications protocol to and from I/O boards
/// 
/// This class handles the generice(non-board specific) commands to and from I/O boards
///
/// This class is the base module for all I/O boards
///
//****************************************************************************
class CBaseProtocol {
public:
	CSimpleLog m_HotSoakLog;
	BOOL InitialiseProtocol(void);
	// I/O car and slot select
	BOOL SelectBoard(class CIOCard *const pBoard);
	BOOL SelectSlot(const UCHAR slotInstance);
	void DeselectAllBoards(void);
	// Process message returns
	BOOL DisplayCommandReturn(void);
	BOOL DecodeBoardCapability(UCHAR *pData, USHORT count);
	E_ERROR_REPORT_STAT CheckBoardErrorReportStatus(const UCHAR errorCode, const UCHAR param1, const UCHAR param2,
			const BOOL errorStrReturn, const USHORT newFailureCount, E_ERROR_TYPE &rErrorType);
	BOOL DecodeBoardError(const UCHAR **ppErrorStr, UCHAR &StrLen, const USHORT failureInc, const BOOL errorStrReturn,
			E_ERROR_TYPE &rErrorType);
	// Commands common to all boards
	BOOL CreateTXHeader(const UCHAR functionNo, const USHORT paramBytes);
	BOOL GetErrors(void);
	BOOL CalculateQueueGearingRatio( USHORT queueTimeBase);
	BOOL SetCardTestData(void);
	BOOL ResetBoardData(void);
	BOOL ResetBoardDataAndTimeStamp(void);
	BOOL SetCardSerialNo(void);
	BOOL SaveLifeHistory( USHORT brdSpfcHistorySize);
	BOOL GetLifeHistory(void);
	BOOL GetSessionHistory(void);
	BOOL ResetCard(void);
	BOOL SetConfigCRC(void);
	BOOL GetTimestamp(void);
	BOOL GetConfigCRC(void);
	BOOL GetCardSerialNo(void);
	BOOL GetBoardChannels(const BOOL forceUpdate);
	BOOL GetBoardType(const BOOL forceUpdate);
	BOOL GetCommsChannelStats(void);
	BOOL GetCardTimeBase(void);
	BOOL GetCardVersionNo(void);
	BOOL GetCardTestData(void);
	BOOL GetCardCalStatus(void);
	int GetSecondaryFwVersion(void);
	BOOL SetTimeNowSecs(UCHAR *pStart);
	const UCHAR GetInstance(void) const;
	void SetInstance(const UCHAR Instance);
	CBaseProtocol();
	virtual ~CBaseProtocol();
protected:
	ULONG m_TXMessCnt;						///< Number of messages sent
	ULONG m_RXMessCnt;						///< Number of messages received
	ULONG m_RxSize;						///< Number of bytes in receive buffer
	UCHAR *m_pData;					///< Pointer to the start of message data
	class CIOCard *m_pBoard;					///< Board which is currently being communicated with
	class CIOConfigManager *m_pConfigManager; ///< Configuration manager holder
	//		class CBrdInfo *m_pBrdInfoObj;			///< Board info holder
	class CBrdStats *m_pBrdStatsObj;		///< Board stats holder
	UCHAR m_TxMessage[MAXBUFFERSIZE];	///< Transmit message, including header
	UCHAR m_RxMessage[MAXBUFFERSIZE];	///< Received message, including header
	UCHAR m_LastBoard;	///< The board No that the last command was executed on
	UCHAR m_CurrentBoard;	///< The board No that the current command is being executed on
	UCHAR m_LastProcCommmand;				///< Command last processed
	UCHAR m_ProcCommmand;				///< Command currently being processed
	UCHAR m_ErrorStat;						///< Last error state
	UCHAR m_Instance;		///< Port instance number (0xff if not supported)
	USHORT ByteSwapUSHORT(USHORT value) const;
	ULONG ByteSwapULONG(ULONG value) const;
	void UploadedNewConfig(void);
	void DecodeIOCardFx(const UCHAR fx, const UCHAR boardID, const UCHAR MessageBuf[]);
	//e836320_tvgr_asterisk_1_0617 (singature changed with new def arg errType(definition)
	BOOL LogIOError(const UCHAR *pError, UCHAR ucErrDef = 0);
	BOOL WaitSendMessage(const USHORT TxRxmSDelay, bool bToWait = false, BOOL ignoreTimeouts = FALSE);
	BOOL ResendWaitOnIOError(const UCHAR *const pError);
	void DecodeCmdName(const UCHAR cmd, wchar_t *pBuffer, int pBufferSize) const;
	BOOL CheckReplyByte(const UCHAR messPos);
	BOOL GetSubErrorCode(E_IO_MOD_SUB_ERROR_CODE &eIoModSubErrCode);
	BOOL CheckReply(const UCHAR MessID, UCHAR *const pErrorType, const BOOL ignoreTimeouts);
	void DebugIOMessage(BYTE *pBuffer, ULONG size, BOOL IsAWrite);
private:
	ULONG m_TxSize;						///< Number of bytes in transmit buffer
	USHORT CalculateSerialisedErrorCode(const UCHAR errorCode, const UCHAR param1in, const UCHAR param2in,
			const BOOL errorStrReturn, E_ERROR_TYPE *pErrType);
	E_ERROR_REPORT_STAT SerialisedErrorStatusCheck(const E_ERROR_TYPE elementType, const USHORT element,
			const BOOL errorStrReturn);
	void FlushIOErrors(void);
	//PSR fix for IO Comaptibility - with star star star changes
	void PerformCardReset(UCHAR ucV6IOERRCode);
#if defined( DBG_FILE_LOG_IO_DBG_ENABLE) || defined (DBG_FILE_LOG_IO_ERR_ENABLE)
#if defined( DBG_FILE_LOG_IO_DBG_ENABLE)
	CDebugFileLogger m_debugFileLogger; //PSR - DebugFile Logger integration
#endif
#if defined (DBG_FILE_LOG_IO_ERR_ENABLE )
	CDebugFileLogger m_errorFileLogger; //PSR - DebugFile Logger integration
#endif
	void LogIOMessageToFile(BYTE *pBuffer, ULONG size, BOOL IsAWrite, BOOL bIntoErrorLog = FALSE);
#endif
};
#endif		// _BASEPROTOCOL_H

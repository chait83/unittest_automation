/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PPIOService.cpp
/// @n implementation for the abstract Pre-process channel class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 22	Stability Project 1.17.1.3	7/2/2011 4:59:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 21	Stability Project 1.17.1.2	7/1/2011 4:38:39 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 20	Stability Project 1.17.1.1	3/17/2011 3:20:34 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 19	Stability Project 1.17.1.0	2/15/2011 3:03:41 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "PPL.h"
#include "IOHandler.h"
#include "PPQManager.h"
#include "PPIOService.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPPIOService::CPPIOService(const BOOL chanInput) {
//	qDebug("Create new CPPIOService\n");
}
CPPIOService::~CPPIOService() {
//	qDebug("Delete CPPIOService class\n");
}
//******************************************************
// InitialiseChanService()
///
/// Initialises a channel to connect to the approriate Data Item table
/// or data queue for data extraction/processing.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CPPIOService::InitialiseChanService(void) {
	BOOL retValue = TRUE;
	return retValue;
}
//******************************************************
///
/// Convert I/O board acqusition rate into Pre-process queue rate
/// @param[in] PPService - The queue service required.
/// @param[in] ConfigAcqRate - The configuration acqusition rate.
///
/// @return The equialent pre-process queue acqusition rate
/// 
//******************************************************
T_PPQC_ACQUSITION_RATE CPPIOService::ConvertToPPQ(const UCHAR PPService, const USHORT ConfigAcqRate) const {
	if (PPService == PP_SERVICE_AI_CHAN) {
		switch (ConfigAcqRate) {
		case AI_ACQ_RATE_2HZ:
			return PPQC_2HZ;
		case AI_ACQ_RATE_5HZ:
			return PPQC_5HZ;
		case AI_ACQ_RATE_10HZ:
			return PPQC_10HZ;
		case AI_ACQ_RATE_50HZ:
			return PPQC_50HZ;
		default:
			return PPQC_1HZ;
		};
	}
	else if (PPService == PP_SERVICE_PULSE_CHAN) {
		switch (ConfigAcqRate) {
		case PULSE_ACQ_RATE_1HZ:
			return PPQC_1HZ;
		case PULSE_ACQ_RATE_2HZ:
			return PPQC_2HZ;
		case PULSE_ACQ_RATE_5HZ:
			return PPQC_5HZ;
		case PULSE_ACQ_RATE_10HZ:
			return PPQC_10HZ;
		};
	}
	return PPQC_1HZ;
}
#define PPIO_UNKNOWN_GLB_CHANNEL 0xdd
/////////////////////////////////////////////////////
/// Create the default definition of an AO channel
/// @param[in/out] pboardInfo - The board process info.
/// @param[in/out] pchanInfo - The channel process info.
/// @param[in] pCard - The I/O board class.
/// @param[in] chanNo - The board channel number.
///
/// @return TRUE if channel configured; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPIOService::CreateDefaultChannelServiceData(T_COMMONPROCESSINFO *pboardInfo, T_CHANPROCESSINFO *pchanInfo,
		class CCardSlot *const pCard, const USHORT chanNo) {
	pboardInfo->input = FALSE;
	pboardInfo->pCard = pCard;
	pboardInfo->CardSlotNo = static_cast<UCHAR>(pCard->BoardSlotInstance());
	pboardInfo->PPService = PP_SERVICE_UNKNOWN;
	pchanInfo->channelNo = static_cast<UCHAR>(chanNo);
	pchanInfo->glbchannelNo = PPIO_UNKNOWN_GLB_CHANNEL;	// Unknown channel number
	pchanInfo->m_DampLoaded = FALSE;
	pchanInfo->m_prevReading = 0;
	return TRUE;
}
//******************************************************
///
/// Disconnects the Pre-Process queue
/// @param[in] pChanInfo - I/O channel process information.
///
/// @return TRUE on successful removal; otherwise FALSE
/// 
//******************************************************
BOOL CPPIOService::DisableService(T_CHANPROCESSINFO *const pChanInfo) {
	BOOL retValue = TRUE;
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	pPPQManager = CPPQManager::GetHandle();
	// Disable all pre-process queues or data items (as required)
	if (IsRunningAsATEEquipment() == FALSE) {
		// Disable the relevant channel pre-process queue, for all channels enabled;
		// if we have a handle on the Pre-process queue manager
		if (pPPQManager != NULL) {
			if (pChanInfo->hPPQ != INVALID_PPQ_HANDLE) {
				if (pPPQManager->m_APPPQServices.DisablePPQ(pChanInfo->hPPQ) != PPQSER_OK)
					retValue = FALSE;
				if (pPPQManager->m_APPPQServices.ResetPPQ(pChanInfo->hPPQ) != PPQSER_OK)
					retValue = FALSE;
			}
//			pPPQManager->ResetToDefault( );
		}
	}
#endif
	return retValue;
}
//******************************************************
///
/// Disconnects a Pre-Process queue from an I/O board
/// @param[in] pBoardInfo - I/O board process information.
///
/// @return TRUE on successful removal; otherwise FALSE
/// 
//******************************************************
BOOL CPPIOService::DisableService(T_COMMONPROCESSINFO *const pBoardInfo) {
	BOOL retValue = TRUE;
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	pPPQManager = CPPQManager::GetHandle();
	// Disable all pre-process queues or data items (as required)
	if (IsRunningAsATEEquipment() == FALSE) {
		// Disable the relevant channel pre-process queue, for all channels enabled;
		// if we have a handle on the Pre-process queue manager
		if (pPPQManager != NULL) {
			if (pBoardInfo->hPPQ != INVALID_PPQ_HANDLE) {
				if (pPPQManager->m_DPPQServices.DisablePPQ(pBoardInfo->hPPQ) != PPQSER_OK)
					retValue = FALSE;
				if (pPPQManager->m_DPPQServices.ResetPPQ(pBoardInfo->hPPQ) != PPQSER_OK)
					retValue = FALSE;
			}
		}
	}
#endif
	return retValue;
}

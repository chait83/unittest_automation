/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AIConfig.h
/// @n interface for the CAIConfig class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 83	Stability Project 1.80.1.1	7/2/2011 4:55:16 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 82	Stability Project 1.80.1.0	7/1/2011 4:27:03 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 81	V6 Firmware 1.80		7/31/2006 1:42:28 PM	Graham Waterfield
//		Added ezTrend mods and input GCA damping. Some work done on
//		linearisation tables (but parked until setup UI done)
// 80	V6 Firmware 1.79		7/19/2006 12:59:16 PM Graham Waterfield
//		Added user linearisation device to config
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_AICONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)
#define AFX_AICONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V6defines.h"
#include "CMMDefines.h"
#include "V6Config.h"
#include "IOSetupConfig.h"
#include "PenSetupConfig.h"
#include "Config.h"
#include "AIRanges.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#if defined (DBG_FILE_LOG_AI_CFG_ERR_ENABLE) || defined (DBG_FILE_LOG_AI_CFG_DBG_ENABLE)
	#include "CStorage.h" //PSR - Debug File Logger integration
#endif
const UCHAR V6_AI_NO_CAL = 0;		///< No AI calibration being performed
const UCHAR V6_AI_FACTORY_CAL = 1;	///< AI Factory calibration being performed
const UCHAR V6_AI_USER_CAL = 2;		///< AI User calibration being performed
// AI card TC configuration
typedef struct AITCChanItem {
	BOOL UpScaleBurnOut;		///< Scale goes over-range or under-range if inputs go O/C (Upscale default)
	BOOL BurnOutSelect;	///< Wheather Burn-out is acknowledged if input is O/C (On by default)
	UCHAR CJCompMethod;	///< 0 = Int automatic 1 = Ext 0 deg C 2 = Ext with specified temp 3 = Ext input
	BOOL ActiveBurnout;							///< 0 = Passive 1 = Active
	USHORT CJCompAI;						///< Associated CJC Analogue Input
	float ExtSpecifiedCJ;					///< Externally specified CJ temp
} T_AITCCHANITEM, *T_PAITCCHANITEM;
typedef struct _aicfgchannelconfig {
	T_COMMONCFGCHANNEL ChanCfgInfo;		///< Universal channel configuration
	float mcEngZero;			///< Main channel engineering Zero
	float mcEngSpan;			///< Main channel engineering Span
	float mcRangeNomZero;		///< Main range nominal Zero
	float mcRangeNomSpan;		///< Main range nominal Span
	float mcRangeAbsZero;		///< Main range absolute Zero
	float mcRangeAbsSpan;		///< Main range absolute Span
	float mcSubRangeZero;		///< Main range subrange Zero
	float mcSubRangeSpan;		///< Main range subrange Span
	float mcElecRangeZero;		///< Main channel range Zero (taking into account the above subrange)
	float mcElecRangeSpan;		///< Main channel range Span (taking into account the above subrange)
	float userLowerSubRange;		///< Buffer for normalised user entered zero sub range
	float userUpperSubRange;		///< Buffer for normalised user entered span sub range
	USHORT userSubRangeUnits;		///< Entered subrange units - note both zero and span must be entered in the same
	USHORT TiedTo;				///< Pen that analagoue input is tied to
	BOOL FieldCal;			///< Is field calibrate selected
	BOOL SqrtExtract;		///< Is square root extract selected for channel
	BOOL UserRangeSelected;	///< Is user defined range selected
	BOOL InputLinearisation;	///< Is linearisation table defined in input units
	UCHAR UserLinearisation;	///< User linearisation table
	float DampLevel;			///< Level of user damping for channel
	float shuntValue;			///< Shunt resistor value
	T_AIRANGEDEF UserRange;			///< AI Card range selected
	T_AIRANGEDEF BaseRange;			///< AI Card base range selected
	T_AITCCHANITEM TCCfg;				///< TC specific configuration
} T_AICFGCHANNEL, *T_PAICFGCHANNEL;
typedef struct _aiwrkchannelconfig {
	USHORT nextTimeStamp;				///< The time that the next block reading timestamps are expected
	UCHAR ChanRange;		/// Channel range type selected
	UCHAR RangeGain;		///< Channel range gain setup info
	UCHAR RangeUnits;		///< Range units
	UCHAR ChanSetup;		///< Channel setup info
	BOOL highSource;		///< TRUE if high current is selected
} T_AIWRKCHANNELCFG, *T_PAIWRKCHANNELCFG;
typedef struct _aichancfgupload {
	UCHAR RangeGain;		///< Channel range gain setup info
	UCHAR ChanSetup;		///< Channel setup info
} T_AICHANCFGUPLOAD, *T_PAICHANCFGUPLOAD;
// Overall board configuration holder
typedef struct _aiboardconfig {
	T_AICFGCHANNEL CfgChan[TOPSLOT_AICHAN_SIZE];		///< Downloadable setup for all board channels
	T_AIWRKCHANNELCFG WrkChan[TOPSLOT_AICHAN_SIZE];	///< Working downloadable setup for all board channels
	UCHAR RangeRevision;					///< Boards range revision number
	UCHAR Calibration;					///< TRUE if board is being calibrated
	BOOL RawMode;					///< Set raw mode on a board level (overrides channel setting)
	USHORT ConfigCRC;		/// Board configuration CRC
	// Uploaded board config
	USHORT CfgVersion;					///< Version number of the configuration
	T_AICHANCFGUPLOAD UploadedCfg[TOPSLOT_AICHAN_SIZE];	///< Uploaded setup and range information
} T_AIBOARDCONFIG, *T_PAIBOARDCONFIG;
class CAIConfig: public CConfig {
	// Allow the Card manager class only to create new instances of the AI configuration
	friend class CIOConfigManager;
public:		//Singleton 
	virtual BOOL CMMCreateLocalConfig(void);
	USHORT CalculateChannelReadRate(UCHAR chanNo);
	USHORT GetChannelAcqRate(const UCHAR chanNo) const;
	// Configure local setup
	BOOL TCConfigDefault(const USHORT chanNo);
	BOOL SelectAIChanRawMode(const USHORT ChannelNo, const BOOL rawModeOn);
	BOOL SelectAIChanAcqRate(const USHORT ChannelNo, const USHORT Rate);
	BOOL SelectAIChanVoltageRange(const USHORT ChannelNo, const USHORT Range);
	BOOL SelectAIChanCurrentRange(const USHORT ChannelNo, const USHORT Range);
	BOOL SelectAIChanResistanceRange(const USHORT ChannelNo, const USHORT Range);
	BOOL SelectAIChanTCRange(const USHORT ChannelNo, const USHORT Range);
	BOOL SelectAIChanRTRange(const USHORT ChannelNo, const USHORT Range);
	// Set state machine
	BOOL ScheduleFactoryCalUpload(void);
	BOOL ScheduleUserCalUpload(void);
	BOOL ScheduleActBrnStatusDownload(void);
	BOOL SetAICalibPair(const USHORT chanNo, const UCHAR mode);
	// Runtime query of local configuration
	CInputConditioning::IO_CAL_OPTIONS QueryIOBoardChanRangeCalInfo(const USHORT chanNo) const;
	BOOL QueryHighConstantCurrent(const USHORT chanNo) const;
	BOOL QuerySlotChannelEnabled(const USHORT chanNo, BOOL *pEnabled) const;
	USHORT QueryAnySlotChannelEnabled(void) const;
	BOOL QueryAISlotChannelSelection(const USHORT ChanNo,
	USHORT *pSelection) const;
	BOOL QuerySlotAcqRate(const USHORT ChanNo, USHORT *pRate) const;
	BOOL QuerySlotVoltageRange(const USHORT ChanNo, USHORT *pRange) const;
	BOOL QuerySlotCurrentRange(const USHORT ChanNo, USHORT *pRange) const;
	BOOL QuerySlotResistanceRange(const USHORT ChanNo, USHORT *pRange) const;
	BOOL QuerySlotTCRange(const USHORT ChanNo, USHORT *pRange) const;
	BOOL QuerySlotRTRange(const USHORT ChanNo, USHORT *pRange) const;
	BOOL QuerySlotEngValues(const USHORT chanNo, float *pEngZero, float *pEngSpan) const;
	BOOL QuerySlotTiedToPen(const USHORT chanNo, USHORT *pPenNo) const;
	BOOL QuerySlotSQRTExtractState(const USHORT chanNo) const;
	BOOL QueryChanBurnOutSelected(const USHORT chanNo, BOOL *pBurnOutSelected) const;
	BOOL QueryChanActiveBurnout(const USHORT chanNo, BOOL *pActiveBurnOutSelected) const;
	BOOL QueryChanCJCompMethodSelect(const USHORT chanNo, UCHAR *pCJCompMethod) const;
	BOOL QueryChanUpscaleBurnoutSelect(const USHORT chanNo, BOOL *pUpsaleBurnoutSelect) const;
	BOOL QueryCardRawScaleSetting(void) const;
	BOOL QueryIsChanATC(const USHORT chanNo) const;
	BOOL QuerySlotTCCJChan(const USHORT chanNo, USHORT *pCJChan) const;
	BOOL QueryChanExternalSpecifiedCJ(const USHORT chanNo, float *pCJValue) const;
	BOOL GetWorkingChannelConfig(const UCHAR chanNo, UCHAR *pRangeComp, UCHAR *pRangeGain, UCHAR *pRangePair) const;
	void SetUploadedVersion(const USHORT version);
	void SetUploadedCfg(UCHAR chanNo, UCHAR setupInfo, UCHAR rangeInfo);
	// Runtime conversion between local & working configuration
//	BOOL ConvertLocalConfig( void );
	USHORT IOEnumConvert(const USHORT acqRate) const;
	BOOL GetChannelConfigRef(const UCHAR ChanNo, T_AICFGCHANNEL **ppChanCfgInfo, T_AIWRKCHANNELCFG **ppChanWrkInfo);
	// Runtime query of working configuration
	UCHAR GetWrkSetupInfo(const UCHAR chanNo) const;
	UCHAR GetWrkRangeInfo(const UCHAR chanNo) const;
	BOOL GetWrkChannelDetails(UCHAR ChanNo, UCHAR *ChanSetupInfo, UCHAR *pChanRangeInfo);
	BOOL SetChannelRange(const USHORT ChanNo, const USHORT ChanType, const USHORT Range);
	BOOL UploadConfig(void);
	const T_AIBOARDCONFIG* GetAIconfig(void);
	BOOL CMMSlotLoad(void);
	BOOL CMMSlotTransfer(T_PTOPSLOT pAICMMConfig);
	BOOL CMMChannelTransfer(const USHORT chanNo, const T_PAICHANNEL pAIChanCMMConfig);
	BOOL CalStructTransfer(const class CATECal *const pCalStruct);
	BOOL CalStructDirectTransfer(const class CATECal *const pCalStruct);
	BOOL InitialiseCardConfigHolder(class CIOCard *const pIOCard);
	BOOL IOCardLocalConfigCommit(void);
	BOOL CompareUploadedDownloadedCfg(const UCHAR chanNo);
	void CleanUp();
private:
	CAIConfig();
	CAIConfig(const CAIConfig&);
	CAIConfig& operator=(const CAIConfig&) {
		return *this;
	}
	;
	~CAIConfig();
	class CAIRanges *m_pAIBrdRangesObj;				///< AI board ranges holder
	T_AIBOARDCONFIG m_Config;			///< Downloadable AI board configuration
	USHORT m_calMask;							///< Calibration channel mask
	// Singleton handlers
	static CAIConfig *m_pInstance;
	static QMutex m_CreationMutex;
#ifdef DBG_FILE_LOG_AI_CFG_DBG_ENABLE
	CDebugFileLogger m_debugFileLogger; //PSR - DebugFile Logger integration
#endif
};
#endif // !defined(AFX_AICONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)

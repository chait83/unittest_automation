/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AIConfig.cpp
/// @n implementation of the CAIConfig class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 46	Stability Project 1.41.1.3	7/2/2011 4:55:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 45	Stability Project 1.41.1.2	7/1/2011 4:37:57 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 44	Stability Project 1.41.1.1	3/17/2011 3:20:10 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 43	Stability Project 1.41.1.0	2/15/2011 3:02:12 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "V6IOBoardTypes.H"
#include "V6IO_AI_InputRanges.H"
#include "V6IOProtocol.h"
#include "FFConversionInfo.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "AOCard.h"
#include "AOConfig.h"
#include "SetupConfiguration.h"
#include "V6globals.h"
#include "V6defines.h"
#include "V6crc.h"
#include "TraceDefines.h"
#include "PenSetupConfig.h"
#include "ATECal.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define MAX_AI_READ_RATE 10
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAOConfig::CAOConfig() {
	USHORT chanNo;
//	qDebug("Create new CAOConfig\n");
	for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
		m_Config.WrkChan[chanNo].pPen = NULL;
		m_Config.WrkChan[chanNo].pPenDataItem = NULL;
	}
}
CAOConfig::~CAOConfig() {
	USHORT chanNo;
//	qDebug("Deleting CAOConfig class\n");
	for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
		if (m_Config.WrkChan[chanNo].pPen != NULL) {
			delete m_Config.WrkChan[chanNo].pPen;
		}
	}
}
//**********************************************************************
/// CalculateChannelReadRate()
///
/// Calculates the channel read rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between reads on this channel
//**********************************************************************
USHORT CAOConfig::CalculateChannelReadRate(UCHAR chanNo) {
	USHORT rate = 0;
	return rate;
}
//******************************************************
// ScheduleBoardProcess()
///
/// Allow write output from state machine.
///
/// @return TRUE if successful scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAOConfig::ScheduleBoardProcess(void) {
	return (static_cast<class CAOCard*>(m_pIOCard))->ScheduleBoardProcess();
}
//**********************************************************************
///
/// Query whether overrange (21mA) is allowed for a given channel.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		TRUE if overrange is allowed; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::QueryChannelOverrangeCapability(UCHAR chanNo) {
	return m_Config.AOCfg.CfgChan[chanNo].Overrange;
}
//**********************************************************************
///
/// Query whether limit (4mA) is selected for a given channel.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		TRUE if limit is selected; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::QueryChannelLimitSelected(UCHAR chanNo) {
	return m_Config.AOCfg.CfgChan[chanNo].Limit;
}
//**********************************************************************
///
/// Query whether channel is enabled.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		TRUE if channel is enabled; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::QueryChannelEnabled(UCHAR chanNo) {
	return m_Config.AOCfg.CfgChan[chanNo].ChanCfgInfo.Enabled;
}
//**********************************************************************
///
/// Query whether channel raw mode is enabled.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		TRUE if channel raw mode is enabled; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::QueryChannelRawSelected(UCHAR chanNo) {
	return m_Config.AOCfg.CfgChan[chanNo].ChanCfgInfo.RawReadings;
}
//******************************************************
///
/// Schedule a upload of factory Cal points for selected channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAOConfig::ScheduleFactoryCalUpload(void) {
	return (static_cast<class CAOCard*>(m_pIOCard))->ScheduleFactoryCalUpload();
}
//**********************************************************************
//
/// Converts the pen output to mA representation.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The scaled value to output to AO card
//**********************************************************************
float CAOConfig::CalcChanScaledValue(const UCHAR chanNo) {
	return m_Config.WrkChan[chanNo].pPen->CalcSourceToDestCapped(m_Config.WrkChan[chanNo].pPenDataItem->GetFPValue());
}
//**********************************************************************
///
/// Get reference to channel local configuration as channel service data
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] pChanCfgInfo - Channel configuration info
/// @param[out] pChanWrkInfo - Channel working info
///
/// @return		TRUE if the cahannel has configuration data available; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::GetChannelConfigRef(const UCHAR ChanNo, T_AOCFGCHANNEL **pChanCfgInfo,
		T_AOWRKCHANNELCFG **pChanWrkInfo) {
	BOOL retValue = FALSE;
	// Ensure channel is legal
	if (ChanNo < TOPSLOT_AOCHAN_SIZE) {
		*pChanCfgInfo = &m_Config.AOCfg.CfgChan[ChanNo];
		*pChanWrkInfo = &m_Config.WrkChan[ChanNo];
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Converts calibration structure config into card channel local downloadable
/// configuration holder, for all channels
///
/// @param[in] pCalStruct - The calibration structure with details of the mode required.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::CalStructTransfer(class CATECal *pCalStruct) {
	USHORT chanNo = 0;
	if (pCalStruct->m_calMode == CM_ATE_FACTORY_CAL)
		m_Config.Calibration = AO_FACTORY_CAL;
	else
		m_Config.Calibration = AO_NO_CAL;
	for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
		m_Config.AOCfg.CfgChan[chanNo].Limit = FALSE;
		m_Config.AOCfg.CfgChan[chanNo].Overrange = TRUE;
		m_Config.AOCfg.CfgChan[chanNo].ChanCfgInfo.Enabled =
				static_cast<BOOL>(pCalStruct->m_cfgAO.CfgChan[chanNo].ChanCfgInfo.Enabled);
		m_Config.AOCfg.CfgChan[chanNo].ChanCfgInfo.RawReadings =
				static_cast<BOOL>(pCalStruct->m_cfgAO.CfgChan[chanNo].ChanCfgInfo.RawReadings);
	}
	return TRUE;
}
//**********************************************************************
/// CMMSlotLoad()
///
/// Converts CMM config into card downloadable configuration
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::CMMSlotLoad(void) {
	BOOL LoadOK = TRUE;
#ifndef ATE_BUILD
	T_PAOCHANNEL pAOCMMConfig = NULL;
	USHORT chanNo = 0;
	USHORT channelType;
	USHORT channelCap;
	WCHAR boardSlotStr[4];
	class CIOSetupConfig *pIOSetupConfig = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	pIOSetupConfig = pSETUP->GetIOSetupConfig();
	if (pIOSetupConfig != NULL) {
		// Load configuration for each AO channel
		chanNo = 0;
		do {
			channelType = pSlotMap->GetHWChannelSelectedType(m_pIOCard->BoardSlotInstance(), chanNo);
			channelCap = pBrdInfo->WhatAvailableChannelType(m_pIOCard->BoardSlotInstance(), chanNo);
			// Channel can either be digital in/out or under certain conditions a pulse channel
			if (channelCap == CHANNEL_CAP_UNKNOWN) {
				// Channel does not exist, so we can except any setup
			} else if (channelType == CHANNEL_AO) {
				pAOCMMConfig = pIOSetupConfig->GetAnalogueOutput(m_pIOCard->BoardSlotInstance(), chanNo,
						CONFIG_COMMITTED);
				if (pAOCMMConfig != NULL) {
					m_Config.AOCfg.CfgChan[chanNo].ChanCfgInfo.Enabled = pAOCMMConfig->Enabled;
					m_Config.AOCfg.CfgChan[chanNo].RetransPenNo = pAOCMMConfig->PenNo;
					pAOCMMConfig->RetransRate; ///< Different retransmission rates are not yet supported
					m_Config.AOCfg.CfgChan[chanNo].Overrange = pAOCMMConfig->Overrange;
					m_Config.AOCfg.CfgChan[chanNo].Limit = !pAOCMMConfig->ZeroOutput;
				} else
					LoadOK = FALSE;
			} else {
				// Illegal channel found
				pSlotMap->GetSlotStrID(m_pIOCard->BoardSlotInstance(), boardSlotStr);
				LOG_ERR(TRACE_IO_SCHED, "ILLEGAL CHANNNEL %d CONFIGURATION FOUND ON AO BOARD %s", chanNo, boardSlotStr);
			}
			chanNo++;
		} while ((chanNo < pBrdInfo->GetNoOfChannels(m_pIOCard->BoardSlotInstance())) && (LoadOK == TRUE));
	} else
		LoadOK = FALSE;
//	if( LoadOK == TRUE )
//		CrcInsert(reinterpret_cast<UCHAR *> (&m_Config.AOCfg), sizeof(m_Config.AOCfg));
#endif
	return LoadOK;
}
//**********************************************************************
///
/// Converts CMM config into card channel local downloadable configuration holder
///
/// @return		TRUE if the commit is successful; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::IOCardLocalConfigCommit(void) {
	BOOL retValue = TRUE;
	// Calculate the current setup configuration CRC value and store
	CrcInsert(reinterpret_cast<UCHAR*>(&m_Config.AOCfg), sizeof(m_Config.AOCfg));
	m_pBrdInfoObj->SetCalcConfigCRC(m_pIOCard->BoardSlotInstance(), m_Config.AOCfg.ConfigCRC);
	return retValue;
}
//**********************************************************************
/// InitialiseCardConfigHolder()
///
/// Initialises the I/O board configuration from the CMM.
///
/// @param[in] pIOCard - The I/O card to which this configuration belongs.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAOConfig::InitialiseCardConfigHolder(class CIOCard *const pIOCard) {
	BOOL retValue = TRUE;
	retValue = InitialiseConfig();
	m_pIOCard = pIOCard;
	if (m_pBrdInfoObj == NULL) {
		// @todo: Unable to get handle/create board info
		retValue = FALSE;
	}
	if (m_pBrdStatsObj == NULL) {
		// @todo: Unable to get handle/create board stats
		retValue = FALSE;
	}
	if (retValue != FALSE)
		retValue = m_pIOCard->CMMCreateLocalConfig();
//		retValue = CMMSlotLoad( );
	return retValue;
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Load the global configuration from the CMM and create the locally held one.
///
/// @return TRUE if successful created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CAOConfig::CMMCreateLocalConfig(void) {
	BOOL retValue = FALSE;
#ifndef ATE_BUILD
	USHORT chanNo;
	class CPenSetupConfig *pPenSetupConfig = NULL;
	T_PPEN pPen = NULL;
	retValue = CMMSlotLoad();
	if (retValue != FALSE)
		retValue = IOCardLocalConfigCommit();
	if (retValue != FALSE) {
		for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
			// Build local setup for channel
			// Get pen scales for 100%
			pPenSetupConfig = pSETUP->GetPenSetupConfig();
			pPenSetupConfig->GetPenLimits(CONFIG_COMMITTED, m_Config.AOCfg.CfgChan[chanNo].RetransPenNo,
					&m_Config.AOCfg.CfgChan[chanNo].mcEngZero, &m_Config.AOCfg.CfgChan[chanNo].mcEngSpan);
			if (m_Config.AOCfg.CfgChan[chanNo].Limit == TRUE)
				m_Config.AOCfg.CfgChan[chanNo].AOChanEngZero = INTERNAO4mA_0;
			else
				m_Config.AOCfg.CfgChan[chanNo].AOChanEngZero = INTERNAO0mA_0;
			m_Config.AOCfg.CfgChan[chanNo].AOChanEngSpan = INTERNAO20mA_100;
			// Create the conversion info and connect to the relevant pen's data item table
			if (m_Config.WrkChan[chanNo].pPen == NULL) {
				m_Config.WrkChan[chanNo].pPen = new CFFConversionInfo;
			}
			m_Config.WrkChan[chanNo].pPen->CalcFConvInfo(m_Config.AOCfg.CfgChan[chanNo].mcEngZero,
					m_Config.AOCfg.CfgChan[chanNo].mcEngSpan, m_Config.AOCfg.CfgChan[chanNo].AOChanEngZero,
					m_Config.AOCfg.CfgChan[chanNo].AOChanEngSpan);
			m_Config.WrkChan[chanNo].pPenDataItem = static_cast<CDataItemPen*>(pDIT->GetDataItemPtr(DI_PEN,
					DI_PEN_READING, m_Config.AOCfg.CfgChan[chanNo].RetransPenNo));
		}
	}
#endif
	// If successful place the I/O card into run mode
	if (TRUE == retValue)
		m_pIOCard->ScheduleIOBoardRunMode(TRUE);
	return retValue;
}

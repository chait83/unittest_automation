/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n CardSlot.h
/// @n interface of the CCardSlot class.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 58	Stability Project 1.55.1.1	7/2/2011 4:55:54 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 57	Stability Project 1.55.1.0	7/1/2011 4:27:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 56	V6 Firmware 1.55		1/5/2007 3:36:11 PM	Graham Waterfield
//		Add ability to check whether data has yet been obtained from I/O card
// 55	V6 Firmware 1.54		12/1/2006 5:01:00 PM	Graham Waterfield
//		Seperate history and board stats upload information
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_CARDSLOT_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_CARDSLOT_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#ifndef _CARDSLOT_H
#define _CARDSLOT_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Defines.h"
#include "SlotMap.h"
#include "PPIOServiceManager.h"
#include "ChanList.h"
#include "BoardManager.h"
// Number of board channels
#define TWO_IO_BOARD_CHANNELS			2
#define FOUR_IO_BOARD_CHANNELS			4
#define EIGHT_IO_BOARD_CHANNELS			8
#define SIXTEEN_IO_BOARD_CHANNELS		16
// I/O Card command mode selection
const USHORT IO_RESET = 0x8000;		// Value set if reset pending
const USHORT IO_CONFIGCHECK = 0x4000;		// Value set if configuration check pending
const USHORT IO_CONFIGDOWNLOAD = 0x2000;		// Value set if configuration download to board is pending
const USHORT IO_CALIBRATION = 0x1000;		// Value set if calibration pending
const USHORT IO_CONFIGUPLOAD = 0x0800;		// Value set if configuration upload to recorder is pending
const USHORT IO_HISTORYUPLOAD = 0x0400;	// Value set if history upload to recorder is pending
const USHORT IO_ACQUIRE = 0x0200;	// Value set if normal acquisition is required
const USHORT IO_IDLE = 0x0000;		// Module must enter IDLE mode
struct BoardCmdPendingFlags_t {
	// Priority is in decending order - TRUE if command is pending or in progress
	USHORT Reset :1;			// TRUE if reset pending
	USHORT ConfigCheck :1;			// TRUE if configuration check pending
	USHORT ConfigDownload :1;			// TRUE if configuration download to board is pending
	USHORT UserCalibration :1;			// TRUE if calibration pending
	USHORT FactoryCalibration :1;			// TRUE if calibration pending
	USHORT ConfigUpload :1;	// TRUE if configuration upload to recorder is pending
	USHORT HistoryUpload :1;	// TRUE if history upload to recorder is pending
	USHORT Acquire :1;			// TRUE if normal acquisition is required
	USHORT CardIDUpload :1;			// TRUE if card ID info upload is required
	USHORT CardTestStatUpload :1;			// TRUE if card test status upload is required
	USHORT AIRTChanCal :1;			// TRUE if RT channel calibration download is required
	USHORT AICalQuery :1;	// TRUE if AI calibration info download is required
	USHORT BoardInfoUpload :1;	// TRUE if board info upload to recorder is pending
	USHORT Unused :3;			// Unused for future use
};
//******************************************************
/// @brief Abstract class providing the scheduling ability for 'cards' of all types.
/// 
/// Provides the scheduling ability for 'cards' of all types
///
//******************************************************
class CCardSlot {
	// Allow the card factory to update protected board RTTI
	friend class CCardList;
public:
	virtual BOOL RunProcess(void) = 0;
	virtual BOOL ScheduleBoardProcess(void) = 0;
	virtual BOOL CMMCreateLocalConfig(void) = 0;
	virtual BOOL InitialiseCard(const USHORT cardNo) = 0;
	virtual BOOL IsCMMConfigValid(void);
	virtual BOOL InitialiseCardConfig(void) = 0;
	virtual BOOL SetSpecialTestMode(const BOOL state) = 0;
	virtual USHORT CalculateChannelReadRate(const UCHAR chanNo) = 0;
	virtual USHORT GetChannelAcqRate(const UCHAR chanNo) const = 0;
	virtual IOCARDSTAT IOCardCommand(const USHORT newCmd) = 0;
	virtual BOOL DoesBoardRqSched(void) = 0;
	virtual USHORT ChannelsToService(void) = 0;
	virtual BOOL ScheduleErrorDownload(void) = 0;
	virtual BOOL CardBoardHandlerFactory(void);
	virtual class CIOCardHandler* GetProcessHandle(void);
	//There can be subtypes for few boards for example AI card(V6AI & V7AI)
	//This function returns the sub type
	virtual UCHAR WhatBoardSubType(void);
	// Query general board items stored in BrdInfo
	UCHAR WhatBoardType(void);
	USHORT GetBoardTimebase(void);
	BOOL ConfigCRCCheck(void);
	USHORT GetCalcConfigCRC(void);
	USHORT GetBoardConfigCRC(void);
	ULONG GetDateFirstTested(void);
	ULONG GetDateLastTested(void);
	BOOL GetBoardFirmwareRevision(UCHAR *const pBoardRevision, int pBuffSize) const;
	UCHAR GetLastTestStatus(void);
	UCHAR WhatSelectedChannelType(const USHORT channelNo) const;
	UCHAR WhatAvailableChannelType(const USHORT channelNo) const;
	USHORT GetQueueGearing(void);
	ULONG GetQueueRollover(void);
	BOOL ScheduleIOBoardRunMode(BOOL runMode);
	BOOL IsIOBoardInRunMode() const;
	BOOL HasIdleModeBeenOrdered() const;
	BOOL ProcessDataReturned(const BOOL dataObtained);
	BOOL HasProcessDataBeenReturned();
	BOOL ScheduleConfigUpload(void);
	BOOL ScheduleConfigDownload(void);
	BOOL ScheduleHistoryUpload(void);
	BOOL ScheduleBoardInfoUpload(void);
	BOOL RegisterCard(USHORT cardNo);
	BOOL InitialiseChannels(void);
	BOOL ScheduleProcess(void);
	BOOL AddChanToSchedule(const USHORT chanNo, class CIOHandler *const pChan);
	BOOL SetGlobalChannelID(const USHORT channelNo, const USHORT glbChannelNo);
	class CChanList* GetChanSchedule(void);
//		class CChanList * GetBoardDetails( void );
	USHORT BoardSlotInstance(void);
	UCHAR GetBoardType(void) const;				///< Get board RTTI
	void ClearAckChannelRecieved(void);
	USHORT AckChannelRecieved(const USHORT chanNo);
	USHORT GetBlockTransChansToAck(void);
	// Countdown until next board scheduled request is required
//		LONGLONG TimeToNextRun( void );		/// @todo: should this be passed current time
	LONGLONG GetTimeServiceRqd(void);
	BOOL SetNextRunTime(void);
	CCardSlot(const USHORT CardSlotID);
	virtual ~CCardSlot();
	virtual void UpdateCardReset(bool isResetNeeded);
	virtual bool IsResetRequired();
	virtual void PerformReset();
protected:
	class CBrdInfo *m_pBrdInfoObj;			///< Board info holder
	class CBrdStats *m_pBrdStatsObj;		///< Board stats holder
	USHORT m_thisStateMCCycles;				///< Machine cycles this baord
	USHORT m_Instance;						///< Board slot instance
	USHORT m_totalChanMask;				///< Mask covering all channels on board
	USHORT m_chanReadMask;					///< Channel read mask
	BOOL m_CardOperational;					///< I/O card operational?
//		void SetBoardType( const UCHAR BoardType );	///< Set board RTTI
	T_MOD_IO_COMMAND Request;				///< Current command being processed
	struct BoardCmdPendingFlags_t m_BoardCmd;				///< Board command actions pending for state machine
	class CChanList m_ChanList;	///< Info on board board I/O channels (slot no and channels reference)
	LONGLONG m_timeToRead;				///< Time to read next block data
	BOOL m_ChannelsCreated;				///< Channel list for board created yet?
	BOOL m_BoardScheduled;				///< Is board setup for scheduled reads
	BOOL m_FirstReadRqd;				///< Is the startup data dump required
	BOOL m_DataFromCard;				///< TRUE if a channel from the card has returned data
	LONGLONG m_nextRunTime;				///< Time till next run
	//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) begin
	bool m_bIsResetNeeded; //Check if card reset required
	//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) end
private:
	USHORT m_chanAckMask;				///< Channel acknowledge mask
//		UCHAR m_BoardType;					/// I/O board RTTI
};
#endif // _CARDSLOT_H
#endif // !defined(AFX_CARDSLOT_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)

/// @file 
/// ****************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	 I/O Scheduler
/// @n Filename: BaseProtocol.cpp
/// @n Desc:	implementation of the CBaseProtocol class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  162  Stability Project 1.157.1.3  7/2/2011 4:55:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  161  Stability Project 1.157.1.2  7/1/2011 4:37:59 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  160  Stability Project 1.157.1.1  3/17/2011 3:20:11 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  159  Stability Project 1.157.1.0  2/15/2011 3:02:16 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include <wchar.h>
#include "IOCard.h"
#include "V6IOConstraints.H"
#include "V6IOStats.H"
#include "V6IOBoardTypes.H"
#include "IOCardInfo.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "BrdInfo.h"
#include "DAL.h"
#include "BoardManager.h"
#include "BaseProtocol.h"
#include <wchar.h>
#include "ATECal.h"
#include "V6globals.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#include "V6crc.h"
#include "V6IOProtocol.h"
#include "V6IOCommandCodes.H"
#include "V6IOErrorCodes.H"
#include "ConfigManager.h"
#include "PPL.h"
#include "AIRanges.h"
#include "TV6Timer.h"
#include "TVtime.h"
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//#define READ_TIMMINGS_RQD 1
#define BOARD_SELECTION_INVALID		0x55
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
extern HWND g_hWnd;
CBaseProtocol::CBaseProtocol() {
//	qDebug("Create new CBaseProtocol\n");
	m_pBoard = NULL;
	m_TXMessCnt = 0;
	m_RXMessCnt = 0;
	m_ProcCommmand = 0;
	m_LastProcCommmand = 0;
	m_LastBoard = BOARD_SELECTION_INVALID;
	m_CurrentBoard = BOARD_SELECTION_INVALID;
	SecureZeroMemory(m_TxMessage, sizeof(m_TxMessage)); SecureZeroMemory(m_RxMessage, sizeof(m_RxMessage));
	m_pData = 0;
	m_RxSize = 0;
	m_TxSize = 0;
	m_pBrdStatsObj = NULL;
//	m_pBrdInfoObj = NULL;
}
CBaseProtocol::~CBaseProtocol() {
//	qDebug("Deleting CBaseProtocol class\n");
}
BOOL CBaseProtocol::InitialiseProtocol(void) {
	BOOL HoldersAqd = TRUE;
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	pDevAbs = CDeviceAbstraction::GetHandle();
	// Get a handle on board info, stats and abstraction layer
	m_pConfigManager = CIOConfigManager::GetHandle();
//	m_pBrdInfoObj = CBrdInfo::GetHandle();
	m_pBrdStatsObj = CBrdStats::GetHandle();
	if (pDevAbs == NULL) {
		// Unable to get handle/create device abstraction layer
		HoldersAqd = FALSE;
	}
	if (m_pBrdStatsObj == NULL) {
		// @todo: Unable to get handle/create board stats
		HoldersAqd = FALSE;
	}
	return HoldersAqd;
}
//******************************************************
// ByteSwapUSHORT()
///
/// Byte swap a word/usigned short.
/// @param[in] value - The value to byte swap.
///
/// @return The byte swapped value.
///
//******************************************************
USHORT CBaseProtocol::ByteSwapUSHORT(USHORT value) const {
	return (((value >> 8)) | (value << 8));
}
//******************************************************
// ByteSwapULONG()
///
/// Byte swap an usigned long.
/// @param[in] value - The value to byte swap.
///
/// @return The byte swapped value.
///
//******************************************************
ULONG CBaseProtocol::ByteSwapULONG(ULONG value) const {
	return (((value & 0x000000FF) << 24) + ((value & 0x0000FF00) << 8) + ((value & 0x00FF0000) >> 8)
			+ ((value & 0xFF000000) >> 24));
}
//******************************************************
// SelectSlot()
///
/// Select a board for the SPI to communicate with.
/// @param[in] slotInstance - Slot instance to select.
///
/// @return TRUE if board can be selected; or FALSE if board out of range.
///
/// @note Should only be used before board type has been identified
///
//******************************************************
BOOL CBaseProtocol::SelectSlot(const UCHAR slotInstance) {
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	BOOL retValue = FALSE;
	pDevAbs = CDeviceAbstraction::GetHandle();
	m_Instance = slotInstance;
	m_pBoard = NULL;		///< No associated board instance
	if (pDevAbs != NULL) {
		if (m_Instance <= RECORDER_SLOT_I) {
			// Cannot address anything other than physical slots
			retValue = pDevAbs->IOCardSelect(m_Instance);
		} else {
			CDeviceAbstraction::GetHandle()->FatalError((L"1: SPI failed to select device %d\n"), m_Instance);
		}
	}
	return retValue;
}
//******************************************************
// SelectBoard()
///
/// Select a board for the SPI to communicate with.
/// @param[in] pBoard - Board that the transaction is destined for.
///
/// @return TRUE if board can be selected; or FALSE if board out of range.
///
//******************************************************
BOOL CBaseProtocol::SelectBoard(class CIOCard *const pBoard) {
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	BOOL retValue = FALSE;
	pDevAbs = CDeviceAbstraction::GetHandle();
	if (pBoard != NULL) {
		m_Instance = static_cast<UCHAR>(pBoard->BoardSlotInstance());
		m_pBoard = pBoard;
		if (pDevAbs != NULL) {
			if (m_Instance <= RECORDER_SLOT_I) {
				// Cannot address anything other than physical slots
				retValue = pDevAbs->IOCardSelect(m_Instance);
			} else {
				CDeviceAbstraction::GetHandle()->FatalError((L"2: SPI failed to select device %d\n"), m_Instance);
			}
		}
	} else {
		m_pBoard = NULL;		///< No associated board instance
	}
	return retValue;
}
//******************************************************
// DeselectAllBoards()
///
/// Deselect all boards from SPI communications.
///
//******************************************************
void CBaseProtocol::DeselectAllBoards(void) {
/// @todo: Cannot deselect all SPI devices at present
//	pDevAbs->SPISelectDevice( );
}
//******************************************************
// GetInstance()
///
/// Recover objects board instance number.
///
/// @return Instance number of board
/// 
//******************************************************
const UCHAR CBaseProtocol::GetInstance(void) const {
	return m_Instance;
}
//******************************************************
// GetInstance()
///
/// Sets objects board instance number.
/// @param[in] Instance - Instance number of board.
///
/// @return Nothing
/// 
//******************************************************
void CBaseProtocol::SetInstance(const UCHAR Instance) {
	m_Instance = Instance;
}
//******************************************************
// DecodeBoardCapability()
///
/// Retrieves the details of each channel on the IO card
/// @param[in] pData - Pointer to a data buffer to be used for the board channel data.
/// @param[in] count - Number of channels defined.
///
/// @return True on success of decoding channel configuration, else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::DecodeBoardCapability(UCHAR *pData, USHORT count) {
	USHORT loc = 0;
	/*
	 m_pBrdStatsObj->SetBoardPresent( GetInstance(), TRUE );
	 m_pBrdStatsObj->SetBoardOpState( GetInstance(), TRUE );
	 m_pBrdInfoObj->SetBoardType( GetInstance(), *(pData + loc) );
	 m_pBrdInfoObj->SetNoOfChannels( GetInstance(), *(pData + (++loc)) );
	 // Work through the data block finding out what channels are available
	 //	pData[
	 */
	return TRUE;
}
//******************************************************
///
/// Sets the time now in seconds in the buffer provided.
///
/// @return TRUE on Msg Tx successfully loaded; else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::SetTimeNowSecs(UCHAR *pStart) {
	DataItem4bytes PresentTime;			// Present system time in millisec (union cannot initialise).
	CTVtime time;							// Time routines instance (structure - cannot initialise).
	BOOL retValue = TRUE;
	// Get the present day time in seconds.		
	time.TimeNow();
	PresentTime.ULData = static_cast<ULONG>(USEC_TO_SEC(time.GetMicroSecs()));
	*pStart++ = PresentTime.UCData[SWAP_BYTE_0];
	*pStart++ = PresentTime.UCData[SWAP_BYTE_1];
	*pStart++ = PresentTime.UCData[SWAP_BYTE_2];
	*pStart++ = PresentTime.UCData[SWAP_BYTE_3];
	return retValue;
}
#define MAXIMUM_IO_ERROR_MESS_LEN	80
//******************************************************
// LogIOError()
///
/// Decodes the I/O card communications structure IOCARDERR
/// @param[in] pError - Pointer to a data buffer holder the error structure.
///
/// @return True on an error being logged, else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::LogIOError(const UCHAR *pError, UCHAR ucErrDef) {
	wchar_t MessText[MAXIMUM_IO_ERROR_MESS_LEN];
	const T_IOCARDERR *const pIOErr = reinterpret_cast<const T_IOCARDERR* const >(pError);// Extract error information;
	E_ERROR_REPORT_STAT reportStat = EERS_NO_REPORT_RQD;
	WCHAR cmdStr[30];
	WCHAR boardSlotStr[4];
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	class CBrdStats *pBrdStats = NULL;
	class CSlotMap *pSlotMap = NULL;
	UCHAR failCount = 0;
	QString strasprintf;
	pSlotMap = CSlotMap::GetHandle();
	pBrdStats = CBrdStats::GetHandle();
	pDevAbs = CDeviceAbstraction::GetHandle();
	if (pIOErr != NULL) {
		switch (pIOErr->ErrorNo) {
		case AP8_IOCARD_ERROR_SETLOC_FAILED:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:AU cannot set %02x SPI driver Holding",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:AU cannot set %02x LM3S Holding", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_MESS_TO_LONG:
			swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:Tx'd message from too long its %d bytes",
					pIOErr->ErrorNo, pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_AP8_NOT_READY:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x not ready", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x not ready", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_TIMEOUT_AP8_SENDMESS:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x Timeout sending message",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x Timeout sending message", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_TIMEOUT_AP8_GETMESS:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x Timeout getting message",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x Timeout getting message", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_NO_MESSAGE_RXD:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x No message from IO Card",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x No message from IO Card", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_FAILED_MESSAGE_RXD:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x message failed from IO Card",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x message failed from IO Card",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_UNKNOWN_RESPONSE_ON_READ:
			swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x Unknown code from LM3S", pIOErr->ErrorNo,
					pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_MESS_IN_TO_LONG:
			swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:Message Rx'd too long according to header (%d bytes)",
					pIOErr->ErrorNo, pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_MESSAGE_IN_DP_FAILED:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x CRC on message from IO failed",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x CRC on message from IO failed",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_SPI_NOT_READY:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x SPI Not ready", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x SPI Not ready", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_NO_DATA:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:SPI driver=%02x SPI data not returned",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"%d:LM3S=%02x SPI data not returned", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		case AP8_IOCARD_ERROR_PREAMBLE_FAIL:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN,
						L"%d:SPI driver=%02x Preamble returned form the card was too much", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN,
						L"%d:LM3S=%02x Preamble returned form the card was too much", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		default:
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"Unknown SPI driver Error No %d data:%d",
						pIOErr->ErrorNo, pIOErr->ErrorData);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"Unknown LM3S Error No %d data:%d", pIOErr->ErrorNo,
						pIOErr->ErrorData);
			break;
		}
	} else {
		swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"");
	}
	if (pIOErr->ErrorNo != 0) {
		if ((pBrdStats->CheckFailCount(m_Instance, EERT_AP8_DRIVER, pIOErr->ErrorNo, &failCount) == TRUE)
				&& (failCount <= ERROR_REPORT_CONTINUOUS)) {
			pBrdStats->LogFailure(m_Instance, EERT_AP8_DRIVER, pIOErr->ErrorNo);
		}
		reportStat = pBrdStats->CheckReportStatus(m_Instance, EERT_AP8_DRIVER, pIOErr->ErrorNo);
		if (reportStat != EERS_NO_REPORT_RQD) {
			if (reportStat == EERS_REPORT_MANY) {
				strasprintf.sprintf(L">%d failures: %s", ERROR_REPORT_MANY, MessText);
			} else if (reportStat == EERS_REPORT_CONTINUOUS) {
				strasprintf = QString::asprintf(">%d failures: %s", ERROR_REPORT_CONTINUOUS, MessText);
			} else {
				strasprintf = QString::asprintf("%s", MessText);
			}
			AddErrorToReport(strasprintf.toLocal8Bit().data());
			DecodeCmdName(m_ProcCommmand, &cmdStr[0], sizeof(cmdStr) / sizeof(WCHAR));
			pSlotMap->GetSlotStrID(m_Instance, boardSlotStr);
			if (m_pBoard == NULL)
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"Unknown I/O Card in %s, Cmd=%s", boardSlotStr, cmdStr);
			else
				swprintf(MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"I/O Card=%s, Cmd=%s", boardSlotStr, cmdStr);
			AddErrorToReport(MessText);
			//if(pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
			//	swprintf( MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"SPI driver Cmd(0x3FC)=%02x State(0x3FE)=%02x", pIOErr->AP8Mess, pIOErr->AP8CmdReady );
			//else
			//	swprintf( MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"AP8 Cmd(0x3FC)=%02x State(0x3FE)=%02x", pIOErr->AP8Mess, pIOErr->AP8CmdReady );
			//AddErrorToReport(MessText);
			//swprintf( MessText, MAXIMUM_IO_ERROR_MESS_LEN, L"AU1100 Cmd(0x3FD)=%02x State(0x3FF)=%02x", pIOErr->AUMess, pIOErr->AUCmdReady );
			//AddErrorToReport(MessText);
		}
		return TRUE;
	}
	return FALSE;
}
//******************************************************
// ResendWaitOnIOError()
///
/// Delays processing on given AP8 errors
/// @param[in] pError - Pointer to a data buffer holder the error structure.
///
/// @return True on an error wait, else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::ResendWaitOnIOError(const UCHAR *const pError) {
	const T_IOCARDERR *const pIOErr = reinterpret_cast<const T_IOCARDERR* const >(pError);// Extract error information;
	BOOL retValue = FALSE;
	if (pIOErr != NULL) {
		switch (pIOErr->ErrorNo) {
		case AP8_IOCARD_ERROR_NO_MESSAGE_RXD:
		case AP8_IOCARD_ERROR_FAILED_MESSAGE_RXD:
		case AP8_IOCARD_ERROR_MESSAGE_IN_DP_FAILED:
			sleep(WAIT_750ms);		// Give the AP8 time to recover
			retValue = TRUE;
			break;
		}
	}
	return retValue;
}
//******************************************************
// GetCommsChannelStats()
///
/// Gets status information for the communications channel handler.
///
/// @return True on message available to decode, else FALSE.
/// 
/// @note: Can only run on Rev C processor boards and higher
//******************************************************
BOOL CBaseProtocol::GetCommsChannelStats(void) {
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	pDevAbs = CDeviceAbstraction::GetHandle();
	if (pDevAbs != NULL) {
		return pDevAbs->IOCardExtendedOperation(IOCARD_EXT_OP_GET_AP8_STATS);
	}
	return FALSE;
}
//******************************************************
// WaitSendMessage()
///
/// CRC's the TX buffer, sends the message and gets the repsonse.
/// TX & RX errors are all logged internally
/// @param[in] TxRxmSDelay (Only required on Rev B boards -
/// The number of mS to delay before clocking a response, after sending a command.
///
/// @return True on message available to decode, else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::WaitSendMessage(const USHORT TxRxmSDelay) {
#ifdef READ_TIMMINGS_RQD
	CTV6Timer sendTimer(TIMER_HIGH_RES);	 	 // Total time in this 'timeslice'
	CTV6Timer readTimer(TIMER_HIGH_RES);	 	 // Total time in this 'timeslice'
  LONGLONG timetaken = (LONGLONG) 0L;
#endif
	QString err;
	class CSlotMap *pSlotMap = NULL;
	WCHAR boardSlotStr[4];
	BOOL retValue = FALSE;
	BOOL msgSuccess = FALSE;
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	BOOL reportCommsError = TRUE;
//	if( pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
//		reportCommsError = FALSE;
	pSlotMap = CSlotMap::GetHandle();
	pSlotMap->GetSlotStrID(m_Instance, boardSlotStr);
	pDevAbs = CDeviceAbstraction::GetHandle();
	if (pDevAbs != NULL) {
		// Log last two commands processed
		m_LastProcCommmand = m_ProcCommmand;
		m_LastBoard = m_CurrentBoard;
		m_CurrentBoard = static_cast<UCHAR>(m_Instance);
		m_ProcCommmand = m_TxMessage[TX_FUNCTION_CODE_BYTE];
		CrcInsert(static_cast<UCHAR*>(m_TxMessage), m_TxSize);
		BOOL writeSuccess = FALSE;
		int writeRetry = MAX_SPI_WRITE_TRIES;
		int msgRetry = MAX_SPI_MSG_TRIES;
#ifdef READ_TIMMINGS_RQD
		// Tranaction timer reset
		sendTimer.ResetAllTimers();
		sendTimer.StartTimer();
#endif
		BOOL bGetLastGoodData = FALSE;
		UCHAR TXMsgCopy[500] = { 0 };	// copy prev Tx buffer before sending last godd data command
		do {
			do {
				sleep(WAIT_1ms);
#ifdef ECHO_IO_COMMAND
				DecodeIOCardFx( m_TxMessage[TX_FUNCTION_CODE_BYTE], m_Instance, &m_TxMessage[TX_FUNCTION_CODE_BYTE] );
#endif
				writeSuccess = pDevAbs->IOCardWrite(m_TxMessage, &m_TxSize, m_Instance);
				m_TXMessCnt++;
				if (writeSuccess == FALSE) {
					// If the board has already been communicated with it is a failure; otherwise board not fitted
					if (m_pBoard != NULL) {
						// Write error status that is logged at start of TX buffer
						if ( TRUE == reportCommsError)
							LogIOError(m_TxMessage);		///< Board I/O error has occurred
//						ResendWaitOnIOError( m_TxMessage );
					} else {
//						err = QString::asprintf(IDS_NO_BOARD_FITTED, boardSlotStr);
//						AddErrorToReport(err.toLocal8Bit().data());		//< I/O board not found
						writeRetry = 0;			///< Never retry a board that fails on it's first communication
					}
					writeRetry--;
					m_RxSize = 0;
					/// For Rev B boards only we need to flush any response message held
					if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
						FlushIOErrors();
				}
			} while ((writeSuccess == FALSE) && (writeRetry > 0));
			if (writeSuccess == TRUE) {
				m_RxSize = MAXBUFFERSIZE;
				/// Communications without a comuunications processor, i.e. Rev B boards, eZtrend
				/// and RS232 communications need time delay of at least 30mS between commands and read.
				/// Some commands that write to E2 on the I/O board, such as Write config & write life stats
				/// can take nearer a second though, so delay is command dependant.
				if ((pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD) || (IsRunningAsATEEquipment() == TRUE))
					sleep(TxRxmSDelay);
#ifdef READ_TIMMINGS_RQD
				// Transaction timer reset
				readTimer.ResetAllTimers();
				readTimer.StartTimer();
#endif
				if (pDevAbs->IOCardRead(m_RxMessage, &m_RxSize, m_Instance) == FALSE) {
					// If the board has already been communicated with, then it is a failure; otherwise board not fitted
					if (m_pBoard != NULL) {
						// Read error status that is logged at start of RX buffer
						if ( TRUE == reportCommsError)
							LogIOError(m_RxMessage);		///< Board I/O error has occurred
//						ResendWaitOnIOError( m_RxMessage );
					} else {
//						err = QString::asprintf(IDS_NO_BOARD_FITTED, boardSlotStr);
//						AddErrorToReport(err.toLocal8Bit().data());		//< I/O board not found
						writeRetry = 0;			///< Never retry a board that fails on it's first communication
					}
					m_RxSize = 0;
					/// For Rev B boards only we need to flush any response message held
					if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
						FlushIOErrors();
//					retValue = FALSE;
				} else {
#ifdef READ_TIMMINGS_RQD
					// Calculate the time that the read was active
					readTimer.StopTimer();
					timetaken = readTimer.GetTimeInMicroSec(TIMER_SINGLE);
					qDebug("Read took %duS\n", static_cast<int> (timetaken));
					// Calculate the total send time
					sendTimer.StopTimer();
					timetaken = sendTimer.GetTimeInMicroSec(TIMER_SINGLE);
					qDebug("Send took %duS\n", static_cast<int> (timetaken));
#endif
					m_RXMessCnt++;
					// Yes there are 6 characters reported; even though there is no board on a Rev B
					if (m_RxSize > 0) {
						if (bGetLastGoodData) {
							// if the response is for Last good data cmd then this is response of the original cmd that was failed 
							// so copy original TXMessage buffer back 
							memcpy_s(m_TxMessage, sizeof(m_TxMessage), TXMsgCopy, sizeof(TXMsgCopy));
							m_ProcCommmand = m_TxMessage[TX_FUNCTION_CODE_BYTE]; // restore original function code....
						}
						m_ErrorStat = 0;
						retValue = CheckReply(m_TxMessage[TX_FUNCTION_CODE_BYTE], &m_ErrorStat);
						if (retValue == TRUE)
							msgSuccess = TRUE;
						// For CRC errors retry msg...commented
						/*if ( retValue == FALSE && m_ErrorStat == ERR_IO_SCHED_INVALID_CRC && msgRetry > 1 )
						 {
						 
						 // Only send last good data for this error code.....			
						 memcpy_s(TXMsgCopy, sizeof (TXMsgCopy), m_TxMessage,sizeof (m_TxMessage));
						 // creat Last Good Data cmd
						 CreateTXHeader( iMX53_FAILED_RESEND, NO_MESSAGE_DATA_BYTES );
						 CrcInsert(static_cast<UCHAR *> (m_TxMessage), m_TxSize);
						 memset(m_RxMessage, 0, sizeof(m_RxMessage));
						 m_RxSize			= 0;
						 bGetLastGoodData	= TRUE;
						 m_ProcCommmand		= iMX53_FAILED_RESEND;	// set this cmd, so that if it fails it will be reported in LogIOErrors correctly...
						 
						 QString   strasprintf	= QString   ::fromWCharArray("");
						 strasprintf = QString::asprintf("Sending iMX53_FAILED_RESEND command on slot %d", m_Instance);
						 AddErrorToReport(strasprintf.toLocal8Bit().data());
						 }
						 else
						 bGetLastGoodData = FALSE;*/
					}
				}
			} else {
				// Write error status that is logged at start of TX buffer,
				// if the command is not the first to be sent to the board
				// (otherwise timeout is resonable if card not fitted)
				LogIOError(m_TxMessage);
			}
			msgRetry--;
		} while ((msgSuccess == FALSE) && (msgRetry > 0));
	} else {
		m_RxSize = 0;
	}
	return msgSuccess;
}
#define TOTAL_FLUSH_OF_IO_RX_CHARS 200		///< The maximum buffer size that may need to be flushed on an error
//******************************************************
///
/// Flush errors from the I/O card by clocking all possible 192 response
/// characters from the buffer
///
//******************************************************
void CBaseProtocol::FlushIOErrors(void) {
	UCHAR responseCnt = 0;
	BOOL charRxd = FALSE;
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	// Not required if in test eqipment mode
	if (IsRunningAsATEEquipment() == TRUE)
		return;					///< Cannot flush errors from an asynchronous port
	pDevAbs = CDeviceAbstraction::GetHandle();
	if (pDevAbs != NULL) {
//		qDebug("*** Flushing card error\n");
		m_RxSize = 1;
		do {
			charRxd = pDevAbs->IOCardRead(m_RxMessage, &m_RxSize, m_Instance);
			responseCnt++;
		} while ((responseCnt < TOTAL_FLUSH_OF_IO_RX_CHARS) && (charRxd == TRUE));
	}
}
#define STD_TX_MESS_LENGTH				6
#define MAX_BYTE_VALUE					256
//******************************************************
///
/// Sets up a TX header for I/O board sends
/// @param[in] functionNo - The function number to send.
/// @param[in] paramBytes - Number of parameter bytes to follow.
///
/// @return TRUE on success of decoding channel configuration, else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::CreateTXHeader(const UCHAR functionNo, const USHORT paramBytes) {
	BOOL retValue = FALSE;
	m_TxMessage[TX_FUNCTION_CODE_BYTE] = functionNo;
	m_TxMessage[TX_INV_FUNCTION_CODE_BYTE] = ~functionNo;
	m_TxMessage[TX_HIGH_BYTES_TO_FOLLOW_BYTE] = paramBytes / MAX_BYTE_VALUE;
	m_TxMessage[TX_LOW_BYTES_TO_FOLLOW_BYTE] = paramBytes % MAX_BYTE_VALUE;
	m_TxSize = STD_TX_MESS_LENGTH + paramBytes;
	retValue = TRUE;
	return retValue;
}
// Read Board Capability message byte positions & sizes
#define RBC_BOARD_TYPE						4
#define RBC_HW_REVISION						5
#define RBC_NON_CHAN_DATA_MESSAGE_SIZE		5
#define RBC_BOARD_NO_OF_CHANS				6
#define RBC_START_OF_CHAN_CAPABILITY_DATA	9
#define RBC_START_OF_CHAN_SELECTED_DATA		10
#define RBC_DAT_SKIP_SIZE					2
//******************************************************
// GetBoardChannels()
///
/// Retrieves the details of each channel on the IO card
/// @param[in] forceUpdate - If TRUE forces update of the local device capability table.
///
/// @return TRUE on success of decoding channel configuration, else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::GetBoardChannels(const BOOL forceUpdate) {
	BOOL retValue = FALSE;
	USHORT chanNo;
	USHORT chanOffset = 0;
	UCHAR chanTypeSelected = CHANNEL_UNKNOWN;
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	class CAIRanges *pAIRange = NULL;
	WCHAR boardSlotStr[4];
	class CSlotMap *pSlotMap = NULL;
	QString errStr;
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( RD_BD_CAPABILITY, NO_MESSAGE_DATA_BYTES);
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL)
		pSlotMap->GetSlotStrID(GetInstance(), boardSlotStr);
	retValue = WaitSendMessage(WAIT_30ms);
	if (retValue == TRUE) {
		if (m_RxMessage[RX_MESS_LO_BYTE_COUNT]
				!= ((m_RxMessage[RBC_BOARD_NO_OF_CHANS] * sizeof(USHORT)) + RBC_NON_CHAN_DATA_MESSAGE_SIZE)) {
			// If illegal message then fail board by setting invalid board type
			pBrdInfoObj->SetBoardType(GetInstance(), BOARD_INVALID);
			errStr = QString::asprintf("Board %s type illegal message", boardSlotStr);
			LogInternalError(errStr.toLocal8Bit().data());
			retValue = FALSE;		// If we have failed this early, then no hope
		}
		if (retValue == TRUE) {
			// Board found, so set/test board type
			if ((forceUpdate == FALSE) && (m_RxMessage[RX_FX_CODE] != pBrdInfoObj->WhatBoardType(GetInstance()))) {
				pBrdInfoObj->SetBoardType(GetInstance(), BOARD_INVALID);// If the board types don't match then invalidate board
				errStr = QString::asprintf("Board %s type has changed", boardSlotStr);
				LogInternalError(errStr.toLocal8Bit().data());
				retValue = FALSE;		// If we have failed this early, then no hope
			} else {
				// Update local capabilities table for the board support
				if (pBrdInfoObj->TestNoOfChannels(GetInstance(), m_RxMessage[RBC_BOARD_TYPE],
						m_RxMessage[RBC_BOARD_NO_OF_CHANS]) == TRUE) {
					m_pBrdStatsObj->SetBoardPresent(GetInstance(), TRUE);
					m_pBrdStatsObj->SetBoardOpState(GetInstance(), TRUE);
					pBrdInfoObj->SetBoardType(GetInstance(), m_RxMessage[RBC_BOARD_TYPE]);
					pBrdInfoObj->SetBoardHardwareRevision(GetInstance(), m_RxMessage[RBC_HW_REVISION]);
					pAIRange = CAIRanges::GetHandle();
					if (pAIRange != NULL) {
						pBrdInfoObj->SetBoardRangeRevision(GetInstance(),
								pAIRange->GetRangeRevision(m_RxMessage[RBC_BOARD_TYPE], m_RxMessage[RBC_HW_REVISION]));
					}
					pBrdInfoObj->SetNoOfChannels(GetInstance(), m_RxMessage[RBC_BOARD_NO_OF_CHANS]);
					// Update local capabilities table for each channel selection
					for (chanNo = 0; chanNo < m_RxMessage[RBC_BOARD_NO_OF_CHANS]; chanNo++) {
						chanTypeSelected = CHANNEL_UNKNOWN;
						// Update selected channel type
						switch (m_RxMessage[RBC_START_OF_CHAN_CAPABILITY_DATA + chanOffset]) {
						case CHANNEL_CAP_DI:
							chanTypeSelected = CHANNEL_DI;
							break;
						case CHANNEL_CAP_DO:
							chanTypeSelected = CHANNEL_DO;
							break;
						case CHANNEL_CAP_AO:
							chanTypeSelected = CHANNEL_AO;
							break;
						case CHANNEL_CAP_AI:
							chanTypeSelected = CHANNEL_AI;
							break;
						case CHANNEL_CAP_PULSE:
							if (m_RxMessage[RBC_BOARD_TYPE] == BOARD_PI)
								chanTypeSelected = CHANNEL_PULSE;
							else
								chanTypeSelected = CHANNEL_DIG_PULSE;
							break;
						};
						pBrdInfoObj->SetSelectedChannelType(GetInstance(), chanNo, chanTypeSelected);
						// Update local capability table for each channel possible
						pBrdInfoObj->SetAvailableChannelType(GetInstance(), chanNo,
								m_RxMessage[RBC_START_OF_CHAN_SELECTED_DATA + chanOffset]);
						chanOffset += RBC_DAT_SKIP_SIZE;
						retValue = TRUE;
					}
				} else {
					pBrdInfoObj->SetBoardType(GetInstance(), BOARD_INVALID);// If the board types don't match then invalidate board
					errStr = QString::asprintf("Board %s type has too many channels for type", boardSlotStr);
					LogInternalError(errStr.toLocal8Bit().data());
					retValue = FALSE;		// If we have failed this early, then no hope
				}
			}
		}
	}
	return retValue;
}
#define RE_ERROR_STAT_BYTE		5
#define RE_ERROR_START_BYTE		6
//******************************************************
// GetErrors()
///
/// Retrieves available error history data from the IO card
///
/// @return TRUE on success of decoding errors return message, else FALSE.
/// 
//******************************************************
BOOL CBaseProtocol::GetErrors(void) {
	BOOL retValue = FALSE;
	UCHAR msgOffset = 0;
	UCHAR size = 0;
	QString reportStr;
	USHORT failureCnt = ERROR_REPORT_SINGLE;
	class CSlotMap *pSlotMap = NULL;
	WCHAR boardSlotStr[4];
	const UCHAR *pErrorStr = NULL;
	CreateTXHeader( REPORT_ERRORS, NO_MESSAGE_DATA_BYTES);
	pSlotMap = CSlotMap::GetHandle();
	pSlotMap->GetSlotStrID(GetInstance(), boardSlotStr);
	retValue = WaitSendMessage(WAIT_30ms);
	if (retValue == TRUE) {
		// Only process if some data has been returned by response
		size = m_RxMessage[RX_MESS_LO_BYTE_COUNT];
		if (size > 0) {
			// Did the error buffer overrun more than 20 times
			if (GetBits(m_RxMessage[RE_ERROR_STAT_BYTE], 1, 1) != 0) {
				failureCnt = ERROR_REPORT_CONTINUOUS;
				reportStr = QString::asprintf(L">%d failures reported from I/O slot %s", failureCnt, boardSlotStr);
				AddErrorToReport(reportStr.toLocal8Bit().data());
			} else if (GetBits(m_RxMessage[RE_ERROR_STAT_BYTE], 0, 1) != 0) {
				// No but the error buffer overrun more than 5 times
				failureCnt = ERROR_REPORT_MANY;
				reportStr = QString::asprintf(L">%d failures reported from I/O slot %s", failureCnt, boardSlotStr);
				AddErrorToReport(reportStr.toLocal8Bit().data());
			}
			// Process all returned errors
			size = m_RxMessage[RX_MESS_LO_BYTE_COUNT] - 2;
			pErrorStr = &m_RxMessage[RE_ERROR_START_BYTE];
			while (size > 0)
				DecodeBoardError(&pErrorStr, size, failureCnt, TRUE);
		}
	}
	return retValue;
}
//******************************************************
///
/// Gets the board cal & version status.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetCardCalStatus(void) {
	BOOL opState = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL) {
		opState = GetCardVersionNo();		 // Get current firmware revision label
		if (opState == TRUE) {
			// Get the rig and date that board was first tested on, this will match what has just been set if accepted;
			// otherwise the board will retain original serial number
			opState = GetCardSerialNo();
			if (opState == TRUE) {
				opState = GetCardTestData();		 // Get the board test info
//				if( (opState == TRUE) && (IsRunningAsATEEquipment() == TRUE) )
//				if( (opState == TRUE) )
//				{
//					opState = m_pBoard->GetIOLifeHistory( this );;
//				}
				if (opState == TRUE) {
					pBrdInfoObj->BoardInfoBeenUploaded(m_Instance, TRUE);// Register that board info has been downloaded from board
				}
			}
		}
	}
	return opState;
}
//******************************************************
///
/// Gets the board version number.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetCardVersionNo(void) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( GET_VERSION, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_30ms);
	if (retValue == TRUE) {
		// Process returned data
		pBrdInfoObj->SetBoardFirmwareRevision(GetInstance(), &m_RxMessage[4]);
	}
	return retValue;
}
#define GBTD_DATE_START_BYTE	4
#define GBTD_RIG_ID_BYTE		8
#define GBTD_PASSED_BYTE		9
//******************************************************
///
/// Gets the board test data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetCardTestData(void) {
	DataItem4bytes CrdTimeData;		// (union cannot initialise)
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( GET_BD_TEST_DATA, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_30ms);
	if ((pBrdInfoObj != NULL) && (retValue == TRUE)) {
		// Process returned data
		if (CheckReplyByte(GBTD_DATE_START_BYTE + SWAP_BYTE_3) == TRUE) {
			// Log the last tested card test date, time, Rig ID and last test status saved
			CrdTimeData.UCData[SWAP_BYTE_3] = m_RxMessage[GBTD_DATE_START_BYTE + SWAP_BYTE_0];
			CrdTimeData.UCData[SWAP_BYTE_2] = m_RxMessage[GBTD_DATE_START_BYTE + SWAP_BYTE_1];
			CrdTimeData.UCData[SWAP_BYTE_1] = m_RxMessage[GBTD_DATE_START_BYTE + SWAP_BYTE_2];
			CrdTimeData.UCData[SWAP_BYTE_0] = m_RxMessage[GBTD_DATE_START_BYTE + SWAP_BYTE_3];
			pBrdInfoObj->SetDateLastTested(GetInstance(), CrdTimeData.ULData);	///< Date rig last passed on
		}
		if (CheckReplyByte(GBTD_RIG_ID_BYTE) == TRUE) {
			pBrdInfoObj->SetLastRigID(GetInstance(), m_RxMessage[GBTD_RIG_ID_BYTE]);	///< Rig ID board last passed on
		}
		if (CheckReplyByte(GBTD_PASSED_BYTE) == TRUE) {
			pBrdInfoObj->SetLastTestStatus(GetInstance(), m_RxMessage[GBTD_PASSED_BYTE]);		///< Has board passed
		}
	}
	return retValue;
}
#define SBTD_DATE_START_BYTE	4
#define SBTD_RIG_ID_BYTE		8
#define SBTD_PASSED_BYTE		9
//******************************************************
///
/// Sets the board current test data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::SetCardTestData(void) {
	DataItem4bytes CrdTimeData;		// (union cannot initialise)
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL) {
		CreateTXHeader( SET_BD_TEST_DATA, MESSAGE_DATA_6_BYTES);
		// Send the last tested card test date, time, Rig ID and last test status saved to the I/O board for persistance
		CrdTimeData.ULData = pBrdInfoObj->GetDateLastTested(GetInstance());	///< Get date rig last passed on
		m_TxMessage[SBTD_DATE_START_BYTE] = CrdTimeData.UCData[SWAP_BYTE_3];
		m_TxMessage[SBTD_DATE_START_BYTE + 1] = CrdTimeData.UCData[SWAP_BYTE_2];
		m_TxMessage[SBTD_DATE_START_BYTE + 2] = CrdTimeData.UCData[SWAP_BYTE_1];
		m_TxMessage[SBTD_DATE_START_BYTE + 3] = CrdTimeData.UCData[SWAP_BYTE_0];
		m_TxMessage[SBTD_RIG_ID_BYTE] = pBrdInfoObj->GetCurrentTestRigID(GetInstance());///< Rig ID board last passed on
		m_TxMessage[SBTD_PASSED_BYTE] = pBrdInfoObj->GetLastTestStatus(GetInstance());	///< Board present test status
		retValue = WaitSendMessage(WAIT_150ms);
	}
	return retValue;
}
#define SBI_DATE_START_BYTE	4
#define SBI_RIG_ID_BYTE		8
//******************************************************
//  SetCardSerialNo()
///
/// Sets the board serial number and the rig No stored in CBrdInfo.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::SetCardSerialNo(void) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;
	DataItem4bytes CrdSerialNo;		// (union cannot initialise)
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL) {
		CreateTXHeader( SET_BOARD_ID, MESSAGE_DATA_5_BYTES);
		// Use the last date, time and rig ID
		CrdSerialNo.ULData = pBrdInfoObj->GetDateLastTested(GetInstance());
		m_TxMessage[SBI_DATE_START_BYTE] = CrdSerialNo.UCData[SWAP_BYTE_3];
		m_TxMessage[SBI_DATE_START_BYTE + SWAP_BYTE_1] = CrdSerialNo.UCData[SWAP_BYTE_2];
		m_TxMessage[SBI_DATE_START_BYTE + SWAP_BYTE_2] = CrdSerialNo.UCData[SWAP_BYTE_1];
		m_TxMessage[SBI_DATE_START_BYTE + SWAP_BYTE_3] = CrdSerialNo.UCData[SWAP_BYTE_0];
		m_TxMessage[SBI_RIG_ID_BYTE] = pBrdInfoObj->GetCurrentTestRigID(GetInstance());
		retValue = WaitSendMessage(WAIT_150ms);
	}
	return retValue;
}
#define GLH_LIFE_STATS_ONLY				0x01
#define GLH_SESSION_STATS_ONLY			0x02
#define GLH_HISTORY_TYPE_TX_BYTE		4
#define GLH_HISTORY_TYPE_RX_BYTE		6
//******************************************************
//  GetSessionHistory()
///
/// Retrieves the IO card session history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetSessionHistory(void) {
	BOOL MsgSuccess = FALSE;
	CreateTXHeader( GET_LIFE_HIST, MESSAGE_DATA_1_BYTE);
	m_TxMessage[GLH_HISTORY_TYPE_TX_BYTE] = GLH_LIFE_STATS_ONLY;		///< Get session history only
	MsgSuccess = WaitSendMessage(WAIT_150ms);
	if (MsgSuccess == TRUE) {
		// Process the history data
	}
	return MsgSuccess;
}
#define SINGLE_HISTORY_TYPE_RETURNED		1
#define GLH_HISTORY_BOARD_TYPE_RX_BYTE		4
#define GLH_HISTORY_TYPE_NUMS_RX_BYTE		5
#define GLH_GENERAL_HISTORY_SIZE_RX_BYTE	7
#define GLH_SPI_MESSAGES_RX_START_BYTE		8
#define GLH_SPI_MESSAGES_TX_START_BYTE		12
#define GLH_SPI_ERRORS_START_BYTE			16
#define GLH_CONFIG_CHANGES_START_BYTE		20
#define GLH_OPERATING_TIME_START_BYTE		24
#define GLH_POWER_CYCLE_START_BYTE			28
//******************************************************
//  GetLifeHistory()
///
/// Retrieves the IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetLifeHistory(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR historySize = 0;
	UCHAR genHistorySize = 0;
	UCHAR cardHistorySize = 0;
	WCHAR boardSlotStr[4];
	class CSlotMap *pSlotMap = NULL;
	class CBrdStats *pBrdStats = NULL;
	QString errStr;
	DataItem4bytes SPIMessagesRx;		// (union cannot initialise)
	DataItem4bytes SPIMessagesTx;		// (union cannot initialise)
	DataItem4bytes SPIErrors;			// (union cannot initialise)
	DataItem4bytes ConfigChanges;		// (union cannot initialise)
	DataItem4bytes OperatingTime;		// (union cannot initialise)
	DataItem4bytes PowerCycles;			// (union cannot initialise)
	pBrdStats = CBrdStats::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL)
		pSlotMap->GetSlotStrID(GetInstance(), boardSlotStr);
	CreateTXHeader( GET_LIFE_HIST, MESSAGE_DATA_1_BYTE);
	m_TxMessage[GLH_HISTORY_TYPE_TX_BYTE] = GLH_LIFE_STATS_ONLY;		///< Get life stats only
	MsgSuccess = WaitSendMessage(WAIT_150ms);
	if (MsgSuccess == TRUE) {
		// Process the history data
		historySize = m_RxMessage[RX_MESS_LO_BYTE_COUNT];		// Number of bytes of data to process
		m_RxMessage[GLH_HISTORY_BOARD_TYPE_RX_BYTE];			// Board type
		// Should be only one board data type returned
		if (m_RxMessage[GLH_HISTORY_TYPE_NUMS_RX_BYTE] != SINGLE_HISTORY_TYPE_RETURNED) {
			errStr = QString::asprintf("Incorrect history data returned from board %s", boardSlotStr);
			LogInternalError(errStr.toLocal8Bit().data());
			MsgSuccess = FALSE;
		}
		if (m_RxMessage[GLH_HISTORY_TYPE_RX_BYTE] == m_TxMessage[GLH_HISTORY_TYPE_TX_BYTE]) {
			if (CheckReplyByte(GLH_GENERAL_HISTORY_SIZE_RX_BYTE) == TRUE) {
				genHistorySize = m_RxMessage[GLH_GENERAL_HISTORY_SIZE_RX_BYTE];
			}
			// Copy over General I/O history
			// -----------------------------
			if (CheckReplyByte(GLH_SPI_ERRORS_START_BYTE + SWAP_BYTE_3) == TRUE) {
				SPIMessagesRx.UCData[SWAP_BYTE_3] = m_RxMessage[GLH_SPI_MESSAGES_RX_START_BYTE];
				SPIMessagesRx.UCData[SWAP_BYTE_2] = m_RxMessage[GLH_SPI_MESSAGES_RX_START_BYTE + SWAP_BYTE_1];
				SPIMessagesRx.UCData[SWAP_BYTE_1] = m_RxMessage[GLH_SPI_MESSAGES_RX_START_BYTE + SWAP_BYTE_2];
				SPIMessagesRx.UCData[SWAP_BYTE_0] = m_RxMessage[GLH_SPI_MESSAGES_RX_START_BYTE + SWAP_BYTE_3];
				SPIMessagesTx.UCData[SWAP_BYTE_3] = m_RxMessage[GLH_SPI_MESSAGES_TX_START_BYTE];
				SPIMessagesTx.UCData[SWAP_BYTE_2] = m_RxMessage[GLH_SPI_MESSAGES_TX_START_BYTE + SWAP_BYTE_1];
				SPIMessagesTx.UCData[SWAP_BYTE_1] = m_RxMessage[GLH_SPI_MESSAGES_TX_START_BYTE + SWAP_BYTE_2];
				SPIMessagesTx.UCData[SWAP_BYTE_0] = m_RxMessage[GLH_SPI_MESSAGES_TX_START_BYTE + SWAP_BYTE_3];
				SPIErrors.UCData[SWAP_BYTE_3] = m_RxMessage[GLH_SPI_ERRORS_START_BYTE];
				SPIErrors.UCData[SWAP_BYTE_2] = m_RxMessage[GLH_SPI_ERRORS_START_BYTE + SWAP_BYTE_1];
				SPIErrors.UCData[SWAP_BYTE_1] = m_RxMessage[GLH_SPI_ERRORS_START_BYTE + SWAP_BYTE_2];
				SPIErrors.UCData[SWAP_BYTE_0] = m_RxMessage[GLH_SPI_ERRORS_START_BYTE + SWAP_BYTE_3];
				pBrdStats->SetGenBoardSPIHistoryStats(GetInstance(), SPIMessagesRx.ULData, SPIMessagesTx.ULData,
						SPIErrors.ULData);
			}
			if (CheckReplyByte(GLH_POWER_CYCLE_START_BYTE + SWAP_BYTE_3) == TRUE) {
				ConfigChanges.UCData[SWAP_BYTE_3] = m_RxMessage[GLH_CONFIG_CHANGES_START_BYTE];
				ConfigChanges.UCData[SWAP_BYTE_2] = m_RxMessage[GLH_CONFIG_CHANGES_START_BYTE + SWAP_BYTE_1];
				ConfigChanges.UCData[SWAP_BYTE_1] = m_RxMessage[GLH_CONFIG_CHANGES_START_BYTE + SWAP_BYTE_2];
				ConfigChanges.UCData[SWAP_BYTE_0] = m_RxMessage[GLH_CONFIG_CHANGES_START_BYTE + SWAP_BYTE_3];
				OperatingTime.UCData[SWAP_BYTE_3] = m_RxMessage[GLH_OPERATING_TIME_START_BYTE];
				OperatingTime.UCData[SWAP_BYTE_2] = m_RxMessage[GLH_OPERATING_TIME_START_BYTE + SWAP_BYTE_1];
				OperatingTime.UCData[SWAP_BYTE_1] = m_RxMessage[GLH_OPERATING_TIME_START_BYTE + SWAP_BYTE_2];
				OperatingTime.UCData[SWAP_BYTE_0] = m_RxMessage[GLH_OPERATING_TIME_START_BYTE + SWAP_BYTE_3];
				PowerCycles.UCData[SWAP_BYTE_3] = m_RxMessage[GLH_POWER_CYCLE_START_BYTE];
				PowerCycles.UCData[SWAP_BYTE_2] = m_RxMessage[GLH_POWER_CYCLE_START_BYTE + SWAP_BYTE_1];
				PowerCycles.UCData[SWAP_BYTE_1] = m_RxMessage[GLH_POWER_CYCLE_START_BYTE + SWAP_BYTE_2];
				PowerCycles.UCData[SWAP_BYTE_0] = m_RxMessage[GLH_POWER_CYCLE_START_BYTE + SWAP_BYTE_3];
				pBrdStats->SetGenBoardHistoryStats(GetInstance(), ConfigChanges.ULData, OperatingTime.ULData,
						PowerCycles.ULData);
			}
			if ((genHistorySize + cardHistorySize) > historySize) {
				// Error - returned history sizes do not match
				errStr = QString::asprintf("Returned history sizes on board %s do not match", boardSlotStr);
				LogInternalError(errStr.toLocal8Bit().data());
			}
		} else {
			// Card has returned incorrect life history data
			errStr = QString::asprintf("Card %s has returned incorrect life history data", boardSlotStr);
			LogInternalError(errStr.toLocal8Bit().data());
		}
		// Although the command sent to each board type is the same, most of the history data returned is board specific
		// therefore must be decoded and saved on a board by board basis
	}
	return MsgSuccess;
}
#define US_DONT_RESET_SESSION_STATS				0
#define US_RESET_SESSION_STATS					1
#define US_DONT_REWRITE_LIFE_STATS				0
#define US_REWRITE_LIFE_STATS					1
#define GENERAL_HISTORY_SIZE					(31-6)
#define US_RESET_SESSION_STATS_BYTE				4
#define US_REWRITE_LIFE_STATS_BYTE				5
#define US_GENERIC_HISTORY_DATA_START_BYTE		6
#define US_SPI_MESSAGES_RX_START_BYTE			US_GENERIC_HISTORY_DATA_START_BYTE
#define US_SPI_MESSAGES_TX_START_BYTE			(GLH_SPI_MESSAGES_RX_START_BYTE+4)
#define US_SPI_ERRORS_START_BYTE				(GLH_SPI_MESSAGES_TX_START_BYTE+4)
#define US_CONFIG_CHANGES_START_BYTE			(GLH_SPI_ERRORS_START_BYTE+4)
#define US_OPERATING_TIME_START_BYTE			(GLH_CONFIG_CHANGES_START_BYTE+4)
#define US_POWER_CYCLE_START_BYTE				(GLH_OPERATING_TIME_START_BYTE+4)
//******************************************************
//  SaveLifeHistory()
///
/// Saves the IO card life history data to the card.
/// @param[in] brdSpfcHistorySize - The size of the board specific history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::SaveLifeHistory( USHORT brdSpfcHistorySize) {
	BOOL MsgSuccess = FALSE;
	UCHAR historySize = 0;
	UCHAR genHistorySize = 0;
	UCHAR cardHistorySize = 0;
	WCHAR boardSlotStr[4];
	class CSlotMap *pSlotMap = NULL;
	class CBrdStats *pBrdStats = NULL;
	QString errStr;
	DataItem4bytes SPIMessagesRx;		// (union cannot initialise)
	DataItem4bytes SPIMessagesTx;		// (union cannot initialise)
	DataItem4bytes SPIErrors;			// (union cannot initialise)
	DataItem4bytes ConfigChanges;		// (union cannot initialise)
	DataItem4bytes OperatingTime;		// (union cannot initialise)
	DataItem4bytes PowerCycles;			// (union cannot initialise)
	pBrdStats = CBrdStats::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL)
		pSlotMap->GetSlotStrID(GetInstance(), boardSlotStr);
	// Although the command sent to each board type is the same, most of the history data returned is board specific
	// therefore must be encoded and saved on a board by board basis
	m_TxMessage[US_REWRITE_LIFE_STATS] = US_DONT_RESET_SESSION_STATS;
	m_TxMessage[US_REWRITE_LIFE_STATS_BYTE] = US_REWRITE_LIFE_STATS;
	// Copy over General I/O history
	// -----------------------------
	pBrdStats->GetGenBoardSPIHistoryStats(GetInstance(), SPIMessagesRx.ULData, SPIMessagesTx.ULData, SPIErrors.ULData);
	m_TxMessage[US_SPI_MESSAGES_RX_START_BYTE] = SPIMessagesRx.UCData[SWAP_BYTE_3];
	m_TxMessage[US_SPI_MESSAGES_RX_START_BYTE + SWAP_BYTE_1] = SPIMessagesRx.UCData[SWAP_BYTE_2];
	m_TxMessage[US_SPI_MESSAGES_RX_START_BYTE + SWAP_BYTE_2] = SPIMessagesRx.UCData[SWAP_BYTE_1];
	m_TxMessage[US_SPI_MESSAGES_RX_START_BYTE + SWAP_BYTE_3] = SPIMessagesRx.UCData[SWAP_BYTE_0];
	m_TxMessage[US_SPI_MESSAGES_TX_START_BYTE] = SPIMessagesTx.UCData[SWAP_BYTE_3];
	m_TxMessage[US_SPI_MESSAGES_TX_START_BYTE + SWAP_BYTE_1] = SPIMessagesTx.UCData[SWAP_BYTE_2];
	m_TxMessage[US_SPI_MESSAGES_TX_START_BYTE + SWAP_BYTE_2] = SPIMessagesTx.UCData[SWAP_BYTE_1];
	m_TxMessage[US_SPI_MESSAGES_TX_START_BYTE + SWAP_BYTE_3] = SPIMessagesTx.UCData[SWAP_BYTE_0];
	m_TxMessage[US_SPI_ERRORS_START_BYTE] = SPIErrors.UCData[SWAP_BYTE_3];
	m_TxMessage[US_SPI_ERRORS_START_BYTE + SWAP_BYTE_1] = SPIErrors.UCData[SWAP_BYTE_2];
	m_TxMessage[US_SPI_ERRORS_START_BYTE + SWAP_BYTE_2] = SPIErrors.UCData[SWAP_BYTE_1];
	m_TxMessage[US_SPI_ERRORS_START_BYTE + SWAP_BYTE_3] = SPIErrors.UCData[SWAP_BYTE_0];
	pBrdStats->GetGenBoardHistoryStats(GetInstance(), ConfigChanges.ULData, OperatingTime.ULData, PowerCycles.ULData);
	m_TxMessage[US_CONFIG_CHANGES_START_BYTE] = ConfigChanges.UCData[SWAP_BYTE_3];
	m_TxMessage[US_CONFIG_CHANGES_START_BYTE + SWAP_BYTE_1] = ConfigChanges.UCData[SWAP_BYTE_2];
	m_TxMessage[US_CONFIG_CHANGES_START_BYTE + SWAP_BYTE_2] = ConfigChanges.UCData[SWAP_BYTE_1];
	m_TxMessage[US_CONFIG_CHANGES_START_BYTE + SWAP_BYTE_3] = ConfigChanges.UCData[SWAP_BYTE_0];
	m_TxMessage[US_OPERATING_TIME_START_BYTE] = OperatingTime.UCData[SWAP_BYTE_3];
	m_TxMessage[US_OPERATING_TIME_START_BYTE + SWAP_BYTE_1] = OperatingTime.UCData[SWAP_BYTE_2];
	m_TxMessage[US_OPERATING_TIME_START_BYTE + SWAP_BYTE_2] = OperatingTime.UCData[SWAP_BYTE_1];
	m_TxMessage[US_OPERATING_TIME_START_BYTE + SWAP_BYTE_3] = OperatingTime.UCData[SWAP_BYTE_0];
	m_TxMessage[US_POWER_CYCLE_START_BYTE] = PowerCycles.UCData[SWAP_BYTE_3];
	m_TxMessage[US_POWER_CYCLE_START_BYTE + SWAP_BYTE_1] = PowerCycles.UCData[SWAP_BYTE_2];
	m_TxMessage[US_POWER_CYCLE_START_BYTE + SWAP_BYTE_2] = PowerCycles.UCData[SWAP_BYTE_1];
	m_TxMessage[US_POWER_CYCLE_START_BYTE + SWAP_BYTE_3] = PowerCycles.UCData[SWAP_BYTE_0];
	CreateTXHeader( UPDATE_STATS, (GENERAL_HISTORY_SIZE + brdSpfcHistorySize));
	MsgSuccess = WaitSendMessage(WAIT_150ms);
	return MsgSuccess;
}
//******************************************************
//  ResetCard()
///
/// ResetCard performs a soft reset of the IO card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::ResetCard(void) {
	BOOL retValue = FALSE;
	CreateTXHeader( RESET, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_50ms);
	// No return data to process
	return retValue;
}
#define RBT_RESET_DATA_ONLY					0
#define RBT_RESET_DATA_AND_TIMESTAMP		1
#define RBT_DATA_TIMESTAP_RESET_BYTE		4
//******************************************************
//  ResetBoardData()
///
/// Resets all board data currently buffered on the card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::ResetBoardData(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	BOOL retValue = FALSE;
	pBrdStatsObj = CBrdStats::GetHandle();
	CreateTXHeader( RESET_BUFF_TS, MESSAGE_DATA_1_BYTE);
	m_TxMessage[RBT_DATA_TIMESTAP_RESET_BYTE] = RBT_RESET_DATA_ONLY;		// Do not reset the timestamp as well
	retValue = WaitSendMessage(WAIT_30ms);
	// There is no returned data to process
	if (retValue == TRUE) {
		// Reset the status of each board in turn
		pBrdStatsObj->ResetCardStats(GetInstance());
	}
	return retValue;
}
//******************************************************
//  ResetBoardDataAndTimeStamp()
///
/// Resets all board data currently buffered on the card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::ResetBoardDataAndTimeStamp(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	BOOL retValue = FALSE;
	pBrdStatsObj = CBrdStats::GetHandle();
	CreateTXHeader( RESET_BUFF_TS, MESSAGE_DATA_1_BYTE);
	m_TxMessage[RBT_DATA_TIMESTAP_RESET_BYTE] = RBT_RESET_DATA_AND_TIMESTAMP;		// Reset the timestamp as well
	retValue = WaitSendMessage(WAIT_30ms);
	// There is no returned data to process
	if (retValue == TRUE) {
		// Reset the status of each board in turn
		pBrdStatsObj->ResetCardStats(GetInstance());
	}
	return retValue;
}
#define SG_GUID_START_BYTE		4
//******************************************************
//  SetConfigCRC()
///
/// Sets the CRC for the config on the card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::SetConfigCRC(void) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	DataItem2bytes CrdGUID;		// (union cannot initialise)
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( SET_GUID, MESSAGE_DATA_4_BYTES);
	// Copy over CRC to message buffer and zero extra CRC bytes; as we are only using two bytes
	CrdGUID.USData = pBrdInfoObj->GetCalcConfigCRC(GetInstance());
	m_RxMessage[SG_GUID_START_BYTE] = 0;
	m_RxMessage[SG_GUID_START_BYTE + SWAP_BYTE_1] = 0;
	m_RxMessage[SG_GUID_START_BYTE + SWAP_BYTE_2] = CrdGUID.UCData[SWAP_BYTE_1];
	m_RxMessage[SG_GUID_START_BYTE + SWAP_BYTE_3] = CrdGUID.UCData[SWAP_BYTE_0];
	retValue = WaitSendMessage(WAIT_150ms);
	// There is no returned data to process
	return retValue;
}
//******************************************************
//  UploadedNewConfig()
///
/// Registers that the new configuration has been succesfully uploaded to the I/O board.
///
//******************************************************
void CBaseProtocol::UploadedNewConfig(void) {
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		pBrdInfoObj->SetBoardConfigCRC(GetInstance(), pBrdInfoObj->GetCalcConfigCRC(GetInstance()));
}
#define GG_CRC_START_BYTE			4
//******************************************************
//  GetConfigCRC()
///
/// Gets the CRC for the config on the card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetConfigCRC(void) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	DataItem2bytes ConfigCRC;		// (union cannot initialise)
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( GET_GUID, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_50ms);
	if ((retValue == TRUE) && (CheckReplyByte(GG_CRC_START_BYTE + SWAP_BYTE_1) == TRUE)) {
		ConfigCRC.UCData[SWAP_BYTE_0] = m_RxMessage[GG_CRC_START_BYTE + SWAP_BYTE_1];
		ConfigCRC.UCData[SWAP_BYTE_1] = m_RxMessage[GG_CRC_START_BYTE + SWAP_BYTE_0];
		// Store the board CRC config in the local capabilities table
		pBrdInfoObj->SetBoardConfigCRC(GetInstance(), ConfigCRC.USData);
	}
	return retValue;
}
#define GTSB_TIMEBASE_DATA_BYTE			4
//******************************************************
//  GetTimestamp()
///
/// retrievs the current IO card timestamp in I/O card ticks.
///
/// @note: The tick rate for each I/O card varies
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetTimestamp(void) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	class CATECal *pATECal = NULL;
	DataItem2bytes CrdTicks;		// (union cannot initialise)
	pBrdInfoObj = CBrdInfo::GetHandle();
	pATECal = CATECal::GetHandle();
	CreateTXHeader( GET_TIMESTAMP, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_30ms);
	if ((retValue == TRUE) && (CheckReplyByte(GTSB_TIMEBASE_DATA_BYTE + SWAP_BYTE_1) == TRUE)) {
		// Process returned data
		CrdTicks.UCData[SWAP_BYTE_0] = m_RxMessage[GTSB_TIMEBASE_DATA_BYTE + SWAP_BYTE_1];
		CrdTicks.UCData[SWAP_BYTE_1] = m_RxMessage[GTSB_TIMEBASE_DATA_BYTE + SWAP_BYTE_0];
		pBrdInfoObj->SetBoardTicks(GetInstance(), CrdTicks.USData);
	} else {
		// Set board ticks to default value
		pBrdInfoObj->SetBoardTicks(GetInstance(), NO_RESPONSE_IO_TICK_DEFAULT);
	}
	return retValue;
}
//******************************************************
//  GetCardTimeBase()
///
/// Gets the board timebase.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetCardTimeBase(void) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	DataItem2bytes CrdTimeBase;		// (union cannot initialise)
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( GET_TS_BASE, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_30ms);
	if ((retValue == TRUE) && (CheckReplyByte(GTSB_TIMEBASE_DATA_BYTE + SWAP_BYTE_1) == TRUE)) {
		// Process returned data
		CrdTimeBase.UCData[SWAP_BYTE_0] = m_RxMessage[GTSB_TIMEBASE_DATA_BYTE + SWAP_BYTE_1];
		CrdTimeBase.UCData[SWAP_BYTE_1] = m_RxMessage[GTSB_TIMEBASE_DATA_BYTE + SWAP_BYTE_0];
		pBrdInfoObj->SetBoardTimebase(GetInstance(), CrdTimeBase.USData);
	}
	return retValue;
}
#define GBID_CARD_SERIAL_NUMBER		4
#define GBID_RIG_ID_BYTE			8
//******************************************************
//  GetCardSerialNo()
///
/// Gets the board serial number and the rig No and stores in CBrdInfo.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetCardSerialNo(void) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	DataItem4bytes CrdSerialNo;		// (union cannot initialise)
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( GET_BOARD_ID, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_30ms);
	if ((retValue == TRUE) && (CheckReplyByte(GBID_CARD_SERIAL_NUMBER + SWAP_BYTE_3) == TRUE)) {
		// Process returned data
		CrdSerialNo.UCData[SWAP_BYTE_0] = m_RxMessage[GBID_CARD_SERIAL_NUMBER + SWAP_BYTE_3];
		CrdSerialNo.UCData[SWAP_BYTE_1] = m_RxMessage[GBID_CARD_SERIAL_NUMBER + SWAP_BYTE_2];
		CrdSerialNo.UCData[SWAP_BYTE_2] = m_RxMessage[GBID_CARD_SERIAL_NUMBER + SWAP_BYTE_1];
		CrdSerialNo.UCData[SWAP_BYTE_3] = m_RxMessage[GBID_CARD_SERIAL_NUMBER + SWAP_BYTE_0];
		pBrdInfoObj->SetDateFirstTested(GetInstance(), CrdSerialNo.ULData);
		pBrdInfoObj->SetFirstRigID(GetInstance(), m_RxMessage[GBID_RIG_ID_BYTE]);
	}
	return retValue;
}
#define GBT_BOARD_TYPE_BYTE					4
#define GBT_BOARD_NO_OF_CHANNELS_BYTE		5
//******************************************************
//  GetBoardType()
///
/// Retrieves the IO board type.
/// @param[in] forceUpdate - If TRUE forces update of the local device capability table.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::GetBoardType(const BOOL forceUpdate) {
	WCHAR boardSlotStr[4];
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	class CSlotMap *pSlotMap = NULL;
	QString errStr;
	BOOL retValue = FALSE;
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL)
		pSlotMap->GetSlotStrID(GetInstance(), QString::fromWCharArray(boardSlotStr));
	pBrdInfoObj = CBrdInfo::GetHandle();
	CreateTXHeader( GET_BOARD_TYPE, NO_MESSAGE_DATA_BYTES);
	retValue = WaitSendMessage(WAIT_30ms);
	if (retValue == TRUE) {
		// Board found, so set/test board type
		if ((forceUpdate == FALSE) && (m_RxMessage[0] != pBrdInfoObj->WhatBoardType(GetInstance()))) {
			pBrdInfoObj->SetBoardType(GetInstance(), BOARD_INVALID);// If the board types don't match then invalidate board
			errStr = QString::asprintf(L"I/O board %s type has changed", boardSlotStr);
			LogInternalError(errStr.toLocal8Bit().data());
			retValue = FALSE;		// If we have failed this early, then no hope
		} else if (CheckReplyByte(GBT_BOARD_NO_OF_CHANNELS_BYTE) == TRUE) {
			// Update local capabilities table
			if (pBrdInfoObj->TestNoOfChannels(GetInstance(), m_RxMessage[GBT_BOARD_TYPE_BYTE],
					m_RxMessage[GBT_BOARD_NO_OF_CHANNELS_BYTE]) == TRUE) {
				m_pBrdStatsObj->SetBoardPresent(GetInstance(), TRUE);
				m_pBrdStatsObj->SetBoardOpState(GetInstance(), TRUE);
				pBrdInfoObj->SetBoardType(GetInstance(), m_RxMessage[GBT_BOARD_TYPE_BYTE]);
				pBrdInfoObj->SetNoOfChannels(GetInstance(), m_RxMessage[GBT_BOARD_NO_OF_CHANNELS_BYTE]);
				retValue = TRUE;
			} else {
				// Board types don't match on this run, so invalidate board
				pBrdInfoObj->SetBoardType(GetInstance(), BOARD_INVALID);
				errStr = QString::asprintf(L"Board %s type has too many channels for type", boardSlotStr);
				LogInternalError(errStr.toLocal8Bit().data());
				retValue = FALSE;		// If we have failed this early, then no hope
			}
		}
	}
	return retValue;
}
#define ERR_AI_NO_CHAN_SPECIFIED_PARAM_NO_5		5
#define ERR_AI_NO_CHAN_SPECIFIED_PARAM_NO_8		8
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_0		0
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_1		1
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_2		2
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_3		3
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_4		4
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_5		5
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_6		6
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_7		7
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_9		9
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_10		10
#define ERR_AI_CHAN_SPECIFIED_PARAM_NO_13		13
#define ERROR_DOWNLOAD_ERR_CODE		0
#define ERROR_DOWNLOAD_PARAM_1		1
#define ERROR_DOWNLOAD_PARAM_2		2
#define ERROR_DOWNLOAD_STRUCT_SIZE	3
//******************************************************
//  DecodeBoardError()
///
/// Decodes errors returned in all parts of the I/O card return data.
/// @param[in] ppErrorStr - The pointer to array of errors.
/// @param[in] StrLen - The number of error bytes that the array of errors holds.
/// @param[in] failureInc - The number of times the error has been reported.
/// @param[in] errorStrReturn - TRUE if error represents an array, and StrLen is used;
///								FLASE if single error (no data).
///
/// @return TRUE on Msg decode success, otherwise FALSE.
///
//******************************************************
BOOL CBaseProtocol::DecodeBoardError(const UCHAR **ppErrorStr, UCHAR &StrLen, const USHORT failureInc,
		const BOOL errorStrReturn) {
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	class CSlotMap *pSlotMap = NULL;
	class CATECal *pATECal = NULL;
	WCHAR boardSlotStr[4];
	WCHAR errorStr[100];
	BOOL retValue = TRUE;
	USHORT chanNo = 0;
	USHORT sysChanNo = 0;
	QString strasprintf;
	errorStr[0] = '\0';
	pBrdInfoObj = CBrdInfo::GetHandle();
	pATECal = CATECal::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	pSlotMap->GetSlotStrID(GetInstance(), QString::fromWCharArray(boardSlotStr));
	if ( TRUE == errorStrReturn) {
		chanNo = ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_1]);		// Note:- Only valid with certain error codes
		if (GetInstance() < RECORDER_SLOT_G) {
			sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel(GetInstance(), chanNo, ONE_BASED);
		} else {
			sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(GetInstance(), chanNo, ONE_BASED);
		}
	}
	if (pBrdInfoObj != NULL) {
		switch ((*ppErrorStr)[ERROR_DOWNLOAD_ERR_CODE]) {
		case ERR_HW_NO_ID:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Cannot read board hardware identity");
			} else {
				swprintf(errorStr, 100, L"Cannot read board hardware identity slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_HW_ID_CHECK:
			if (errorStrReturn == TRUE) {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Incompatible hardware ID : code: %d",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Incompatible hardware ID slot %s : code: %d", boardSlotStr,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Incompatible hardware ID");
				} else {
					swprintf(errorStr, 100, L"Incompatible hardware ID slot %s", boardSlotStr);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_HW_NO_REVISION:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to read board revision");
			} else {
				swprintf(errorStr, 100, L"Unable to read board revision slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_HW_BAD_REVISION:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Invalid board revision");
			} else {
				swprintf(errorStr, 100, L"Invalid board revision slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_HW_NOT_PASSED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Board not marked as having passed post-mfr test");
			} else {
				swprintf(errorStr, 100, L"Board not marked as having passed post-mfr test slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			break;
		case ERR_READING_CONFIG:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to read valid configuration from E2");
			} else {
				swprintf(errorStr, 100, L"Unable to read valid configuration from E2 slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_READING_STATS:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to read history/stats from E2");
			} else {
				swprintf(errorStr, 100, L"Unable to read history/stats from E2 slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_FATAL_SU_ERR:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Fatal startup error");
			} else {
				swprintf(errorStr, 100, L"Fatal startup error slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_HW_OTHER:
			if (errorStrReturn == TRUE) {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"H/W error prevents execution of command : code: %d",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"H/W error prevents execution of command slot %s: code: %d", boardSlotStr,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Other H/W error prevents execution of a command");
				} else {
					swprintf(errorStr, 100, L"Other H/W error prevents execution of a command on slot %s",
							boardSlotStr);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_UNKNOWN_FC:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Function code received unknown");
			} else {
				swprintf(errorStr, 100, L"Function code received unknown slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_INVALID_FC:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"The 2 fn code bytes failed validation test");
			} else {
				swprintf(errorStr, 100, L"The 2 fn code bytes failed validation test: slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case BUSY_PROCESSING_MSG:
			if (errorStrReturn == TRUE) {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Slave still processing previous message: code: %d",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Slave still processing previous message: slot %s: code: %d", boardSlotStr,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Slave still processing previous message");
				} else {
					swprintf(errorStr, 100, L"Slave still processing previous message: slot %s", boardSlotStr);
				}
			}
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_WRITING_VAL:
			if (errorStrReturn == TRUE) {
				if ((pBrdInfoObj->WhatBoardType(GetInstance()) == BOARD_AI)
						|| (pBrdInfoObj->WhatBoardType(GetInstance()) == BOARD_EZ_AI)) {
					if (((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_NO_CHAN_SPECIFIED_PARAM_NO_5)
							|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_NO_CHAN_SPECIFIED_PARAM_NO_8)) {
						if (IsRunningAsATEEquipment() == TRUE) {
							swprintf(errorStr, 100, L"Failure writing output value to AI : code: %d",
									(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
						} else {
							swprintf(errorStr, 100, L"Failure writing output value to AI slot %s : code: %d",
									boardSlotStr, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
						}
					} else {
						if (IsRunningAsATEEquipment() == TRUE) {
							swprintf(errorStr, 100, L"Failure writing output value to AI chan %d: code: %d", chanNo,
									(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
						} else {
							swprintf(errorStr, 100, L"Failure writing output value to AI slot %s chan %d: code: %d",
									boardSlotStr, sysChanNo, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
						}
					}
				} else if (pBrdInfoObj->WhatBoardType(GetInstance()) == BOARD_AO) {
					if (IsRunningAsATEEquipment() == TRUE) {
						swprintf(errorStr, 100, L"Unable to write an output value to AO : code: %d",
								(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
					} else {
						swprintf(errorStr, 100, L"Unable to write an output value to AO slot %s: code: %d",
								boardSlotStr, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
					}
				} else {
					if (IsRunningAsATEEquipment() == TRUE) {
						swprintf(errorStr, 100, L"Unable to write to card");
					} else {
						swprintf(errorStr, 100, L"Unable to write a value to slot %s", boardSlotStr);
					}
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Unable to write to card");
				} else {
					swprintf(errorStr, 100, L"Unable to write a value to slot %s", boardSlotStr);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_OUT_OF_SEQUENCE:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Cannot execute this command in present state");
			} else {
				swprintf(errorStr, 100, L"Cannot execute this command in present state slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_NUM_ARGS:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"I/O card: message wrong number of arguments");
			} else {
				swprintf(errorStr, 100, L"I/O card: message wrong number of arguments slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_ARGS_INVALID:
			if (((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4)
					|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_5)) {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Arguments of the message were invalid chan %d: code: %d", chanNo,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Arguments of the message were invalid slot %s chan %d: code: %d",
							boardSlotStr, sysChanNo, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Arguments of the message were invalid : code: %d",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Arguments of the message were invalid slot %s: code: %d", boardSlotStr,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_INVALID_CRC:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"I/O card: invalid CRC");
			} else {
				swprintf(errorStr, 100, L"I/O card: invalid CRC slot %s", boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_INCOMPLETE_MSG:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"I/O card: message incomplete.");
			} else {
				swprintf(errorStr, 100, L"I/O card: message incomplete slot %s", boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_CONFIG_MISMATCH:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"The configuration comparison failed");
			} else {
				swprintf(errorStr, 100, L"The configuration comparison failed on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CONFIG_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"The configuration operation was not successful");
			} else {
				swprintf(errorStr, 100, L"The configuration operation was not successful on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_NO_VER:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to determine firmware version number");
			} else {
				swprintf(errorStr, 100, L"Unable to determine firmware version number on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_NO_BUILD:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to determine firmware build number");
			} else {
				swprintf(errorStr, 100, L"Unable to determine firmware build number on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_NO_SN:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to determine the firmware serial number");
			} else {
				swprintf(errorStr, 100, L"Unable to determine the firmware serial number on slot %s", boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == FALSE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_NO_GUID:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to determine the board's GUID");
			} else {
				swprintf(errorStr, 100, L"Unable to determine the board's GUID on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_LIFE_HIST:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to determine the life history");
			} else {
				swprintf(errorStr, 100, L"Unable to determine the life history on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_READING_VAL:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to return an input value");
			} else {
				swprintf(errorStr, 100, L"Unable to return an input value on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CALIBRATING:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"An error has occurred during calibration");
			} else {
				swprintf(errorStr, 100, L"An error has occurred during calibration on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_IN_CAL:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to return all or part of cal - may be corrupt");
			} else {
				swprintf(errorStr, 100, L"Unable to return all or part of cal - may be corrupt on slot %s",
						boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_AT_STARTUP:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Error during I/O board startup");
			} else {
				swprintf(errorStr, 100, L"Error during I/O board startup on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_PARTIAL_DATA:
			// Not an error until data is lost; which this does not tell you
			/*
			 if( IsRunningAsATEEquipment() == TRUE )
			 {
			 swprintf( errorStr, 100, L"Partial data returned" );
			 }
			 else
			 {
			 swprintf( errorStr, 100, L"Partial data returned on slot %s", boardSlotStr );
			 }
			 */
			break;
		case ERR_NO_DATA:
			// Should never happen due to timings used in the IO Scheduler
			/*
			 if( IsRunningAsATEEquipment() == TRUE )
			 {
			 swprintf( errorStr, 100, L"There are no readings to return" );
			 }
			 else
			 {
			 swprintf( errorStr, 100, L"There are no readings to return on slot %s", boardSlotStr );
			 }
			 */
			break;
		case ERR_MESS_TOO_BIG:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"The reply message larger than buffer");
			} else {
				swprintf(errorStr, 100, L"The reply message larger than buffer on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_RD_CONFIG_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to read configuration : code: %d",
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"Unable to read configuration slot %s : code: %d", boardSlotStr,
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_WR_CONFIG_FAILED:
			if (((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7)
					|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_13)) {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Unable to write configuration chan %d: code: %d", chanNo,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Unable to write configuration slot %s chan %d: code: %d", boardSlotStr,
							sysChanNo, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Unable to write configuration : code: %d",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Unable to write configuration slot %s : code: %d", boardSlotStr,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CMD_HW_INVALID:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Command cannot be executed on this hardware");
			} else {
				swprintf(errorStr, 100, L"Command cannot be executed on this hardware on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_WATCHDOG_TIMEOUT:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Watchdog timer timed out");
			} else {
				swprintf(errorStr, 100, L"Watchdog timer timed out on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_RD_NV_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Error reading NV (EEPROM): code: %d", (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"Error reading NV (EEPROM): slot %s : code: %d", boardSlotStr,
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_WR_NV_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Error writing to NV (EEPROM): code: %d",
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"Error writing to NV (EEPROM): slot %s : code: %d", boardSlotStr,
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_NV_CRC:
			if (IsRunningAsATEEquipment() == TRUE) {
				if ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 0) {
					swprintf(errorStr, 100, L"No board serial number on power-up");
				} else {
					swprintf(errorStr, 100, L"CRC error on reading setup from NV memory (EEPROM)");
				}
			} else {
				if ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 0) {
					swprintf(errorStr, 100, L"No board serial number on power-up on slot %s", boardSlotStr);
				} else {
					swprintf(errorStr, 100, L"CRC error on reading setup from NV memory (EEPROM) on slot %s",
							boardSlotStr);
				}
			}
			// Correctly report the status of the error
			if ((IsRunningAsATEEquipment() == FALSE) && ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 0)) {
				// This error in the recorder is always an error - the board must have a serial number
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else if ((IsRunningAsATEEquipment() == TRUE) && ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 0)) {
				// This error will occur on the ATE due to two resets being applied to the UUT
				// on 1st reset, this error is correctly suppressed
				// on 2nd reset, this error is reported
			} else {
				// Any other NV CRC error is a warning no matter what system it is running on
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_LOST_DATA:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"There are readings missing from channel %d", chanNo);
			} else {
				swprintf(errorStr, 100, L"There are readings missing from slot %s channel %d", boardSlotStr, sysChanNo);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_PARTIAL_LOST_DATA:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"More data than buffer can hold; some overwritten");
			} else {
				swprintf(errorStr, 100, L"More data than buffer can hold; some overwritten on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_INVALID_STATE:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Can't execute: invalid state : code: %d",
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"Can't execute: invalid state slot %s : code: %d", boardSlotStr,
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_NO_CAN_DO:
			if (((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4)
					|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_5)
					|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_6)
					|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7)) {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Unable to execute: unspecified reason chan %d: code: %d", chanNo,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Unable to execute: unspecified reason slot %s chan %d: code: %d",
							boardSlotStr, sysChanNo, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Unable to execute: unspecified reason : code: %d",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				} else {
					swprintf(errorStr, 100, L"Unable to execute: unspecified reason slot %s : code: %d", boardSlotStr,
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_OTHER:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unspecified error has occurred");
			} else {
				swprintf(errorStr, 100, L"Unspecified error has occurred on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_ACQ_TIMER:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to enable or disable timer interrupts");
			} else {
				swprintf(errorStr, 100, L"Unable to enable or disable timer interrupts on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_RS232:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Error with RS232 port");
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				swprintf(errorStr, 100, L"Error with RS232 port on slot %s", boardSlotStr);
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_HOST_SPI:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Error with Host SPI");
			} else {
				swprintf(errorStr, 100, L"Error with Host SPI on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_FULL_BUFFER:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Master SPI (ADC or DAC) Receive buffer overflowed");
			} else {
				swprintf(errorStr, 100, L"Master SPI (ADC or DAC) Receive buffer overflowed on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CLOCK_MONITOR:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Clock monitor failure occurred");
			} else {
				swprintf(errorStr, 100, L"Clock monitor failure occurred on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_OLD_HW_REVISION:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Hardware is not the latest revision");
			} else {
				swprintf(errorStr, 100, L"Hardware is not the latest revision on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CHAN_DISABLED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Tried to write to a disabled channel");
			} else {
				swprintf(errorStr, 100, L"Tried to write to a disabled channel on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_MASTER_SPI:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Error with master SPI (ADC or DAC) code %d",
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"Error with master SPI (ADC or DAC) code d on slot %s",
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2], boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_TIMED_OUT:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Waited too long without response");
			} else {
				swprintf(errorStr, 100, L"Waited too long without response on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_IN_LIST:
			// Error  will be logged as the list is decoded
			/*
			 if( IsRunningAsATEEquipment() == TRUE )
			 {
			 swprintf( errorStr, 100, L"Un-read error in the error buffer found" );
			 }
			 else
			 {
			 swprintf( errorStr, 100, L"Un-read error in the error buffer found on slot %s", boardSlotStr );
			 }
			 */
//				pATECal->SetIOCardCommsErrorReported( GetInstance(), CESS_WARNING );
			break;
		case ERR_ARG_OOR:			// Not used currently
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Argument n out of range (argument n is 0-based)");
			} else {
				swprintf(errorStr, 100, L"Argument n out of range (argument n is 0-based) on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CHAN_NO + IO_CARD_CHANNEL_1:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_2:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_3:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_4:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_5:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_6:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_7:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_8:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_9:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_10:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_11:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_12:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_13:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_14:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_15:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_16:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"An error has occurred with channel %d", chanNo);
			} else {
				swprintf(errorStr, 100, L"An error has occurred with channel %d on slot %s", sysChanNo, boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CAL_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Calib vals not written properly in factory or field cal");
			} else {
				swprintf(errorStr, 100, L"Calib vals not written properly in factory or field cal on slot %s",
						boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_RANGE_NOT_SET:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to set the range requested");
			} else {
				swprintf(errorStr, 100, L"Unable to set the range requested on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CJC_DRIVER:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"CJC port error detected: code: %d", (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"CJC port error detected slot %s : code: %d", boardSlotStr,
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_ADC_ENABLE:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Cannot enable ADC chip: code: %d", (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"Cannot enable ADC chip on slot %s : code: %d", boardSlotStr,
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_ADC_SPI_INIT:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Can't initialise the SPI for ADCs");
			} else {
				swprintf(errorStr, 100, L"Can't initialise the SPI for ADCs on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_ADC_CHANS_INIT:
			if (errorStrReturn == TRUE) {
				if (((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_0)
						|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_1)
						|| ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == ERR_AI_CHAN_SPECIFIED_PARAM_NO_2)) {
					if (IsRunningAsATEEquipment() == TRUE) {
						swprintf(errorStr, 100, L"Can't initialise ADC speeds, ranges, etc chan %d: code: %d", chanNo,
								(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
					} else {
						swprintf(errorStr, 100, L"Can't initialise ADC speeds, ranges, etc chan %d: code: %d",
								boardSlotStr, sysChanNo, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
					}
				} else {
					if (IsRunningAsATEEquipment() == TRUE) {
						swprintf(errorStr, 100, L"Can't initialise ADC speeds, ranges, etc: code: %d",
								(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
					} else {
						swprintf(errorStr, 100, L"Can't initialise ADC speeds, ranges, etc on slot %s: code: %d",
								boardSlotStr, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
					}
				}
			} else {
				if (IsRunningAsATEEquipment() == TRUE) {
					swprintf(errorStr, 100, L"Can't initialise ADC speeds, ranges, etc");
				} else {
					swprintf(errorStr, 100, L"Can't initialise ADC speeds, ranges, etc on slot %s", boardSlotStr);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_CJC_INIT:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Can't initialise the CJC");
			} else {
				swprintf(errorStr, 100, L"Can't initialise the CJC on slot %s", boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_WRONG_MODE:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"ADC not ready for requested op chan %d", chanNo);
			} else {
				swprintf(errorStr, 100, L"ADC not ready for requested op slot %s chan %d", boardSlotStr, sysChanNo);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_RESET_ADC:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Failed to reset ADC converters");
			} else {
				swprintf(errorStr, 100, L"Failed to reset ADC converters on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_FACT_CAL:
			if (IsRunningAsATEEquipment() == TRUE) {
				if ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 0) {
					swprintf(errorStr, 100, L"Factory cal read from EEPROM was corrupt on power-up");
				} else if ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 1) {
					swprintf(errorStr, 100, L"Factory RT cal read from EEPROM was corrupt on power-up");
				} else {
					swprintf(errorStr, 100, L"Illegal code: %d cal EEPROM found",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
				}
			} else {
				if ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 0) {
					swprintf(errorStr, 100, L"Factory cal read from EEPROM was corrupt on power-up; slot %s",
							boardSlotStr);
				} else if ((*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2] == 1) {
					swprintf(errorStr, 100, L"Factory RT cal read from EEPROM was corrupt on power-up; slot %s",
							boardSlotStr);
				} else {
					swprintf(errorStr, 100, L"Illegal code %d cal EEPROM found; slot %s",
							(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2], boardSlotStr);
				}
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_USER_CAL:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"User cal read from EEPROM was corrupt on power-up; code %d",
						(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			} else {
				swprintf(errorStr, 100, L"User cal read from EEPROM was corrupt on power-up; slot %s; code %d",
						boardSlotStr, (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2]);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_BOTH_CAL:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Both cals read from EEPROM were corrupt");
			} else {
				swprintf(errorStr, 100, L"Both cals read from EEPROM were corrupt on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_NO_CJC_AVAIL:
			if (IsRunningAsATEEquipment() == FALSE) {
				swprintf(errorStr, 100, L"There is no CJC reading available on slot %s", boardSlotStr);
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			} else {
				// This error will occur on the ATE due to the CJC defaulting to 'ready to read'
				// on reset, errors and config changes, thus indicating a new value available
				// before the actual value is read.
			}
			break;
		case ERR_LAST_CJC_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"The last CJC value was not read correctly");
			} else {
				swprintf(errorStr, 100, L"The last CJC value was not read correctly on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			break;
		case ERR_ADC_SELF_TEST:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"ADC chip failed self test chan %d", chanNo);
			} else {
				swprintf(errorStr, 100, L"ADC chip failed self test slot %s chan %d", boardSlotStr, sysChanNo);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_RD_CAL_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to read AI calibration");
			} else {
				swprintf(errorStr, 100, L"Unable to read AI calibration on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_WR_CAL_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to write AI calibration");
			} else {
				swprintf(errorStr, 100, L"Unable to write AI calibration on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_IO_SCHED_INCOMPLETE_MSG:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"I/O Scheduler message incomplete");
			} else {
				swprintf(errorStr, 100, L"I/O Scheduler message incomplete on slot %s", boardSlotStr);
			}
			break;
		case ERR_IO_SCHED_INVALID_FC:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"I/O Scheduler message invalid function code");
			} else {
				swprintf(errorStr, 100, L"I/O Scheduler message invalid function code on slot %s", boardSlotStr);
			}
			break;
		case ERR_IO_SCHED_INVALID_CRC:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"I/O Scheduler message CRC error");
			} else {
				swprintf(errorStr, 100, L"I/O Scheduler message CRC error on slot %s", boardSlotStr);
			}
			break;
		case ERR_RD_AIBOARD_FAILED:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unable to read per-board info");
			} else {
				swprintf(errorStr, 100, L"Unable to read per-board info on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_AMBIENT_OFFLIMITS:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Ambient temperature out of limits");
			} else {
				swprintf(errorStr, 100, L"Ambient temperature out of limits on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		case ERR_OUT_OF_RANGE:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Requested more than 21mA output");
			} else {
				swprintf(errorStr, 100, L"Requested more than 21mA output on slot %s", boardSlotStr);
			}
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			break;
		case ERR_OPEN_CIRCUIT:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Detected open circuit load on an enabled AO channel");
			} else {
				swprintf(errorStr, 100, L"Detected open circuit load on an enabled AO channel on slot %s",
						boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == FALSE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			} else {
				// Load is often removed in ATE, and is correct operation
			}
			break;
		case ERR_LM3S1621_FAILED_RESEND:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Secondary processor message CRC failed, iMX53 shall resend the command.");
			} else {
				swprintf(errorStr, 100,
						L"Secondary processor message CRC failed, iMX53 shall resend the command on slot %s",
						boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_MESS_FAILED_FROM_CARD:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Secondary processor received incorrect message for all retries.");
			} else {
				swprintf(errorStr, 100, L"Secondary processor received incorrect message for all retries on slot %s",
						boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		case ERR_NO_RESP_FROM_CARD:
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100,
						L"Secondary processor timeout occurred. Probably card is not fitted or damaged.");
			} else {
				swprintf(errorStr, 100,
						L"Secondary processor timeout occurred. Probably card is not fitted or damaged on slot %s",
						boardSlotStr);
			}
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			} else {
				pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_WARNING);
			}
			break;
		default:
			retValue = FALSE;		///< Cannot continue processing error
			if (IsRunningAsATEEquipment() == TRUE) {
				swprintf(errorStr, 100, L"Unknown error %d returned", (*ppErrorStr)[ERROR_DOWNLOAD_ERR_CODE]);
			} else {
				swprintf(errorStr, 100, L"Unknown error %d returned from slot %s",
						(*ppErrorStr)[ERROR_DOWNLOAD_ERR_CODE], boardSlotStr);
			}
			// Need to report this directly; otherwise problem will not be logged
			strasprintf = QString::asprintf(L"%s", errorStr);
			AddErrorToReport(strasprintf.toLocal8Bit().data());
			pATECal->SetIOCardCommsErrorReported(GetInstance(), CESS_ERROR);
			break;
		}
	} else {
		// Could not get neccersary singleton references
		retValue = FALSE;
	}
	if (retValue == TRUE) {
		E_ERROR_REPORT_STAT reportStat = EERS_NO_REPORT_RQD;
		reportStat = CheckBoardErrorReportStatus((*ppErrorStr)[ERROR_DOWNLOAD_ERR_CODE],
				(*ppErrorStr)[ERROR_DOWNLOAD_PARAM_1], (*ppErrorStr)[ERROR_DOWNLOAD_PARAM_2], errorStrReturn,
				failureInc);
		if (reportStat != EERS_NO_REPORT_RQD) {
			if (reportStat == EERS_REPORT_MANY) {
				strasprintf = QString::asprintf(IDS_DIAG_MULTIPLE_FAILURE_REPORT, ERROR_REPORT_MANY, errorStr);
			} else if (reportStat == EERS_REPORT_CONTINUOUS) {
				strasprintf = QString::asprintf(IDS_DIAG_MULTIPLE_FAILURE_REPORT, ERROR_REPORT_CONTINUOUS, errorStr);
			} else {
				strasprintf = QString::asprintf(L"%s", errorStr);
			}
			AddErrorToReport(strasprintf.toLocal8Bit().data());
		}
		if (errorStrReturn == TRUE) {
			// Safeguard incorrect parsing, because failure would be very bad (just in case - should not happen)
			if (StrLen >= ERROR_DOWNLOAD_STRUCT_SIZE) {
				*ppErrorStr += ERROR_DOWNLOAD_STRUCT_SIZE;
				StrLen -= ERROR_DOWNLOAD_STRUCT_SIZE;
			} else {
				*ppErrorStr += StrLen;
				StrLen = 0;
			}
		} else {
			StrLen = 0;
		}
	}
	if (pBrdInfoObj == NULL) {
		AddErrorToReport("Could not get stats holder");
	}
	return retValue;
}
//******************************************************
//  CheckBoardErrorReportStatus()
///
/// Checks how many times a given serialised error has been reported
/// @param[in] element - The I/O  board's error code (serialised).
/// @param[in] errorStrReturn - TRUE if error represents an array, and param 1 & param 2 are available;
///								FLASE if single error (no extra data).
///
/// @return Report status of error message if report required, otherwise EERS_NO_REPORT_RQD.
///
//******************************************************
E_ERROR_REPORT_STAT CBaseProtocol::SerialisedErrorStatusCheck(const E_ERROR_TYPE elementType, const USHORT element,
		const BOOL errorStrReturn) {
	E_ERROR_REPORT_STAT retValue = EERS_NO_REPORT_RQD;
	UCHAR failCount = 0;
	// Check serialised entry list
	if ((m_pBrdStatsObj->CheckFailCount(GetInstance(), elementType, element, &failCount) == TRUE)
			&& (failCount <= ERROR_REPORT_CONTINUOUS)) {
		m_pBrdStatsObj->LogFailure(GetInstance(), elementType, element);
	}
	retValue = m_pBrdStatsObj->CheckReportStatus(GetInstance(), elementType, element);
	return retValue;
}
//******************************************************
//  CalculateSerialisedErrorCode()
///
/// Decodes errors returned in all parts of the I/O card return data.
/// @param[in] errorCode - The I/O  board's error code.
/// @param[in] param1 - The I/O  board's error code param 1 value if errorStrReturn == TRUE.
/// @param[in] param2 - The I/O  board's error code param 2 value  if errorStrReturn == TRUE.
/// @param[in] errorStrReturn - TRUE if error represents an array, and param 1 & param 2 are available;
///								FLASE if single error (no extra data).
/// @param[out] pErrType - The I/O  serialised error code error type.
///
/// @return The serialised error code.
///
//******************************************************
USHORT CBaseProtocol::CalculateSerialisedErrorCode(const UCHAR errorCode, const UCHAR param1in, const UCHAR param2in,
		const BOOL errorStrReturn, E_ERROR_TYPE *pErrType) {
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	UCHAR param1 = param1in;
	UCHAR param2 = param2in;
	USHORT multiplier = 0;
	USHORT errRef = 0;
	E_ERROR_TYPE errorType = EERT_PARAMETERISED;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL) {
		switch (errorCode) {
		case ERR_HW_ID_CHECK:
			// 13 Parameters to sequence
			errRef += ERR_HW_ID_CHECK_START + param2;
			break;
		case ERR_HW_OTHER:
			// 5 Parameters to sequence
			errRef += ERR_HW_OTHER_CHECK_START + param2;
			break;
		case ERR_RD_CONFIG_FAILED:
			// 4 Parameterised codes to sequence
			errRef += ERR_RD_CONFIG_FAILED_START + param2;
			break;
		case ERR_RD_NV_FAILED:
			// 8 Parameters to sequence
			errRef += ERR_RD_NV_FAILED_START + param2;
			break;
		case ERR_WR_NV_FAILED:
			// 22 Parameters to sequence
			errRef += ERR_WR_NV_FAILED_START + param2;
			break;
		case ERR_INVALID_STATE:
			// 9 Parameterised codes to sequence
			errRef += ERR_INVALID_STATE_START + param2;
			break;
		case ERR_CJC_DRIVER:
			// 6 Parameterised codes to sequence
			errRef += ERR_CJC_DRIVER_START + param2;
			break;
		case BUSY_PROCESSING_MSG:
			// 3 Parameterised codes to sequence
			errRef += BUSY_PROCESSING_MSG_START + param2;
			break;
		case ERR_NV_CRC:
			// 2 Parameterised codes to sequence
			errRef += ERR_NV_CRC_START + param2;
			break;
		case ERR_MASTER_SPI:
			// 2 Parameterised codes to sequence
			errRef += ERR_MASTER_SPI_START + param2;
			break;
		case ERR_FACT_CAL:
			// 2 Parameterised codes to sequence
			errRef += ERR_FACT_CAL_START + param2;
			break;
		case ERR_USER_CAL:
			// 2 Parameterised codes to sequence
			errRef += ERR_USER_CAL_START + param2;
			break;
		case ERR_ADC_ENABLE:
			// 2 Parameterised codes to sequence
			errRef += ERR_ADC_ENABLE_START + param2;
			break;
		case ERR_WRONG_MODE:
			/// 8 AI Channels to sequence
			errRef += ERR_WRONG_MODE_START;
			errRef += param1;			///< Channel number
			break;
		case ERR_ADC_SELF_TEST:
			/// 8 AI Channels to sequence
			errRef += ERR_ADC_SELF_TEST_START;
			errRef += param1;			///< Channel number
			break;
		case ERR_LOST_DATA:
			/// 8 AI Channels to sequence
			errRef += ERR_LOST_DATA_START;
			errRef += param1;			///< Channel number
			break;
		case ERR_WRITING_VAL:
			// 11 Parameterised codes to sequence, 6 with AI channels
			errRef += ERR_WRITING_VAL_START;
			if (errorStrReturn == TRUE) {
				if ((param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_3) || (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4)
						|| (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_6) || (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7)
						|| (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_9)
						|| (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_10)) {
					/// Note: param1 - Channel number
					/// Note: param2 - Error code number
					errRef += ERR_WRITING_VAL_SEQ_COUNT;
					if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_3)
						multiplier = 0;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4)
						multiplier = 1;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_6)
						multiplier = 2;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7)
						multiplier = 3;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_9)
						multiplier = 4;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_10)
						multiplier = 5;
					errRef += multiplier * HW_ANA_IN_CHAN_PER_BOARD + param1;
				} else {
					// Treat as a single error code
					errRef += param2;
				}
			}
			break;
		case ERR_ADC_CHANS_INIT:
			// 5 Parameterised codes to sequence, 3 with AI channels
			errRef += ERR_ADC_CHANS_INIT_START;
			if (errorStrReturn == TRUE) {
				if ((param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_0) || (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_1)
						|| (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_2)) {
					/// Note: param1 - Channel number
					/// Note: param2 - Error code number
					errRef += ERR_ADC_CHANS_INIT_SEQ_COUNT;
					if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_0)
						multiplier = 0;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_1)
						multiplier = 1;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_2)
						multiplier = 2;
					errRef += multiplier * HW_ANA_IN_CHAN_PER_BOARD + param1;
				} else {
					// Treat as a single error code
					errRef += param2;
				}
			}
			break;
		case ERR_ARGS_INVALID:
			// 6 Parameterised codes to sequence, 2 with AI channels
			errRef += ERR_ARGS_INVALID_START;
			if (errorStrReturn == TRUE) {
				if ((param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4) || (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_5)) {
					/// Note: param1 - Channel number
					/// Note: param2 - Error code number
					errRef += ERR_ARGS_INVALID_SEQ_COUNT;
					if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4)
						multiplier = 0;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_5)
						multiplier = 1;
					errRef += multiplier * HW_ANA_IN_CHAN_PER_BOARD + param1;
				} else {
					// Treat as a single error code
					errRef += param2;
				}
			}
			break;
		case ERR_WR_CONFIG_FAILED:
			// 19 Parameterised codes to sequence, 2 with AI channels
			errRef += ERR_WR_CONFIG_FAILED_START;
			if (errorStrReturn == TRUE) {
				if ((param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7) || (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_13)) {
					/// Note: param1 - Channel number
					/// Note: param2 - Error code number
					errRef += ERR_WR_CONFIG_FAILED_SEQ_COUNT;
					if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7)
						multiplier = 0;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_13)
						multiplier = 1;
					errRef += multiplier * HW_ANA_IN_CHAN_PER_BOARD + param1;
				} else {
					// Treat as a single error code
					errRef += param2;
				}
			}
			break;
		case ERR_NO_CAN_DO:
			// 8 Parameterised codes to sequence, 4 with AI channels
			errRef += ERR_NO_CAN_DO_START;
			if (errorStrReturn == TRUE) {
				if ((param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4) || (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_5)
						|| (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_6)
						|| (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7)) {
					/// Note: param1 - Channel number
					/// Note: param2 - Error code number
					errRef += ERR_NO_CAN_DO_SEQ_COUNT;
					if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_4)
						multiplier = 0;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_5)
						multiplier = 1;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_6)
						multiplier = 2;
					else if (param2 == ERR_AI_CHAN_SPECIFIED_PARAM_NO_7)
						multiplier = 3;
					errRef += multiplier * HW_ANA_IN_CHAN_PER_BOARD + param1;
				} else {
					// Treat as a single error code
					errRef += param2;
				}
			}
			break;
		case ERR_UNKNOWN_FC:
		case ERR_HW_NO_ID:
		case ERR_INVALID_FC:
		case ERR_PARTIAL_LOST_DATA:
		case ERR_OTHER:
		case ERR_ACQ_TIMER:
		case ERR_RS232:
		case ERR_HOST_SPI:
		case ERR_FULL_BUFFER:
		case ERR_CLOCK_MONITOR:
		case ERR_OLD_HW_REVISION:
		case ERR_CHAN_DISABLED:
		case ERR_TIMED_OUT:
		case ERR_ARG_OOR:
		case ERR_FATAL_SU_ERR:
		case ERR_HW_NO_REVISION:
		case ERR_HW_BAD_REVISION:
		case ERR_HW_NOT_PASSED:
		case ERR_READING_CONFIG:
		case ERR_READING_STATS:
		case ERR_OUT_OF_SEQUENCE:
		case ERR_NUM_ARGS:
		case ERR_INVALID_CRC:
		case ERR_INCOMPLETE_MSG:
		case ERR_CONFIG_MISMATCH:
		case ERR_CONFIG_FAILED:
		case ERR_NO_VER:
		case ERR_NO_BUILD:
		case ERR_NO_SN:
		case ERR_NO_GUID:
		case ERR_LIFE_HIST:
		case ERR_READING_VAL:
		case ERR_CALIBRATING:
		case ERR_IN_CAL:
		case ERR_AT_STARTUP:
		case ERR_PARTIAL_DATA:
		case ERR_NO_DATA:
		case ERR_MESS_TOO_BIG:
		case ERR_CMD_HW_INVALID:
		case ERR_WATCHDOG_TIMEOUT:
		case ERR_CAL_FAILED:
		case ERR_RANGE_NOT_SET:
		case ERR_ADC_SPI_INIT:
		case ERR_CJC_INIT:
		case ERR_RESET_ADC:
		case ERR_BOTH_CAL:
		case ERR_NO_CJC_AVAIL:
		case ERR_LAST_CJC_FAILED:
		case ERR_RD_CAL_FAILED:
		case ERR_IO_SCHED_INCOMPLETE_MSG:
		case ERR_IO_SCHED_INVALID_FC:
		case ERR_IO_SCHED_INVALID_CRC:
		case ERR_WR_CAL_FAILED:
		case ERR_RD_AIBOARD_FAILED:
		case ERR_AMBIENT_OFFLIMITS:
		case ERR_OUT_OF_RANGE:
		case ERR_OPEN_CIRCUIT:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_1:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_2:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_3:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_4:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_5:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_6:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_7:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_8:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_9:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_10:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_11:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_12:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_13:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_14:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_15:
		case ERR_CHAN_NO + IO_CARD_CHANNEL_16:
			errorType = EERT_NON_PARAMETERISED;
			errRef = errorCode;
			break;
		}
	}
	*pErrType = errorType;
	return errRef;
}
//******************************************************
//  CheckBoardErrorReportStatus()
///
/// Decodes errors returned in all parts of the I/O card return data.
/// @param[in] errorCode - The I/O  board's error code.
/// @param[in] param1 - The I/O  board's error code param 1 value if errorStrReturn == TRUE.
/// @param[in] param2 - The I/O  board's error code param 2 value  if errorStrReturn == TRUE.
/// @param[in] errorStrReturn - TRUE if error represents an array, and param 1 & param 2 are available;
///								FLASE if single error (no extra data).
/// @param[in] newFailureCount - The number of failures of this error code has been obtained.
///
/// @return Report status of error message if report required, otherwise EERS_NO_REPORT_RQD.
///
//******************************************************
E_ERROR_REPORT_STAT CBaseProtocol::CheckBoardErrorReportStatus(const UCHAR errorCode, const UCHAR param1in,
		const UCHAR param2in, const BOOL errorStrReturn, const USHORT newFailureCount) {
	UCHAR param1 = param1in;
	UCHAR param2 = param2in;
	E_ERROR_REPORT_STAT retValue = EERS_NO_REPORT_RQD;
	USHORT errRef = 0;
	USHORT multiplier = 0;
	UCHAR failCount = 0;
	E_ERROR_TYPE errType;
	if (errorStrReturn == FALSE) {
		// Neither parameter is avaliable
		param1 = 0;
		param2 = 0;
	} else {
		// Seperate parameter fail reports from non parameter versions
		errRef = 1;
	}
	errRef = CalculateSerialisedErrorCode(errorCode, param1in, param2in, errorStrReturn, &errType);
	retValue = SerialisedErrorStatusCheck(errType, errRef, errorStrReturn);
	return retValue;
}
/////////////////////////////////////////////////////
/// Display the return from a message
///
/// @return TRUE on success, else FALSE.
/////////////////////////////////////////////////////
BOOL CBaseProtocol::DisplayCommandReturn(void) {
	BOOL retValue = FALSE;
	USHORT msgByte = 0;
	if (m_RxSize > 0) {
		for (msgByte = 0; msgByte < m_RxSize; msgByte++) {
			qDebug("0X%x,", m_RxMessage[msgByte]);
		}
		qDebug("0X%x\n", m_RxMessage[msgByte]);
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  DecodeIOCardFx()
///
/// Decodes the IO card command function and displays the function sent.
/// @param[in] fx - ID of message to be deoded.
/// @param[in] boardID - ID of I/O board command is being sent to.
///
//******************************************************
void CBaseProtocol::DecodeIOCardFx(const UCHAR fx, const UCHAR boardID, const UCHAR MessageBuf[]) {
	switch (fx) {
	case RESET:
		qDebug("Cmd: RESET to card %d\n", boardID);
		break;
	case GET_BOARD_TYPE:
		qDebug("Cmd: GET_BOARD_TYPE to card %d\n, boardID");
		break;
	case GET_BOARD_ID:
		qDebug("Cmd: GET_BOARD_ID to card %d\n", boardID);
		break;
	case GET_TIMESTAMP:
		qDebug("Cmd: GET_TIMESTAMP to card %d\n", boardID);
		break;
	case GET_LIFE_HIST:
		qDebug("Cmd: GET_LIFE_HIST to card %d\n", boardID);
		break;
	case GET_VERSION:
		qDebug("Cmd: GET_VERSION to card %d\n", boardID);
		break;
	case GET_ID_VER:
		qDebug("Cmd: GET_ID_VER to card %d\n", boardID);
		break;
	case GET_GUID:
		qDebug("Cmd: GET_GUID to card %d\n", boardID);
		break;
	case SET_BD_TEST_DATA:
		qDebug("Cmd: SET_BD_TEST_DATA to card %d\n", boardID);
		break;
	case GET_BD_TEST_DATA:
		qDebug("Cmd: GET_BD_TEST_DATA to card %d\n", boardID);
		break;
	case SET_GUID:
		qDebug("Cmd: SET_GUID to card %d\n", boardID);
		break;
	case SET_BOARD_ID:
		qDebug("Cmd: SET_BOARD_ID to card %d\n", boardID);
		break;
	case SET_DIAG_INTVL:
		qDebug("Cmd: SET_DIAG_INTVL to card %d\n", boardID);
		break;
	case GET_TS_BASE:
		qDebug("Cmd: GET_TS_BASE to card %d\n", boardID);
		break;
	case SET_MAINS_F:
		qDebug("Cmd: SET_MAINS_F to card %d\n", boardID);
		break;
	case RESET_BUFF_TS:
		qDebug("Cmd: RESET_BUFF_TS to card %d\n", boardID);
		break;
	case WR_BOARD_SETUP:
		qDebug("Cmd: WR_BOARD_SETUP to card %d\n", boardID);
		break;
	case RD_BOARD_SETUP:
		qDebug("Cmd: RD_BOARD_SETUP to card %d\n", boardID);
		break;
	case RD_AICAL_REC:
		qDebug("Cmd: RD_AICAL_REC to card %d\n", boardID);
		break;
	case GET_CJC:
		qDebug("Cmd: GET_CJC to card %d\n", boardID);
		break;
	case RD_ANAL_INPUT:
		qDebug("Cmd: RD_ANAL_INPUT to card %d\n", boardID);
		break;
	case RD_ANAL_BLOCK:
		qDebug("Cmd: RD_ANAL_BLOCK to card %d\n", boardID);
		break;
	case ACK_GOOD_AIBLOCK:
		qDebug("Cmd: ACK_GOOD_AIBLOCK 0x%x to card %d\n", MessageBuf[4], boardID);
		break;
	case FACT_CALIB:
		qDebug("Cmd: FACT_CALIB to card %d\n", boardID);
		break;
	case USER_CALIB:
		qDebug("Cmd: USER_CALIB to card %d\n", boardID);
		break;
	case RD_FACT_CAL:
		qDebug("Cmd: RD_FACT_CAL to card %d\n", boardID);
		break;
	case RD_USER_CAL:
		qDebug("Cmd: RD_USER_CAL to card %d\n", boardID);
		break;
	case SET_RAW_MODE:
		qDebug("Cmd: SET_RAW_MODE to card %d\n", boardID);
		break;
	case GET_RT_CAL:
		qDebug("Cmd: GET_RT_CAL to card %d\n", boardID);
		break;
	case GET_RT_COMP:
		qDebug("Cmd: GET_RT_COMP to card %d\n", boardID);
		break;
	case SET_RANGE:
		qDebug("Cmd: SET_RANGE to card %d\n", boardID);
		break;
	case SET_ACQ_FREQ:
		qDebug("Cmd: SET_ACQ_FREQ to card %d\n", boardID);
		break;
	case RD_AICHAN_CONFIG:
		qDebug("Cmd: RD_AICHAN_CONFI to card %dG\n", boardID);
		break;
	case RD_AI_CONFIG:
		qDebug("Cmd: RD_AI_CONFIG to card %d\n", boardID);
		break;
	case RD_DIG_IN_BLK:
		qDebug("Cmd: RD_DIG_IN_BLK to card %d\n", boardID);
		break;
	case ACK_GOOD_DIG_BLK:
		qDebug("Cmd: ACK_GOOD_DIG_BLK 0x%x to card %d\n", MessageBuf[4], boardID);
		break;
	case RD_DIG_INPUT:
		qDebug("Cmd: RD_DIG_INPUT to card %d\n", boardID);
		break;
	case WR_DIG_OUTPUT:
		qDebug("Cmd: WR_DIG_OUTPUT to card %d\n", boardID);
		break;
	case RD_PULSE_IN_BLK:
		qDebug("Cmd: RD_PULSE_IN_BLK to card %d\n", boardID);
		break;
	case RD_DIG_CONFIG:
		qDebug("Cmd: RD_DIG_CONFIG to card %d\n", boardID);
		break;
	case WR_ANAL_OUTPUT:
		qDebug("Cmd: WR_ANAL_OUTPUT to card %d\n", boardID);
		break;
	case SET_AO_RAWMODE:
		qDebug("Cmd: SET_AO_RAWMODE to card %d\n", boardID);
		break;
	case SET_AO_CALIB:
		qDebug("Cmd: SET_AO_CALIB to card %d\n", boardID);
		break;
	case RD_AO_CALIB:
		qDebug("Cmd: RD_AO_CALIB to card %d\n", boardID);
		break;
	case RD_AO_CONFIG:
		qDebug("Cmd: RD_AO_CONFIG to card %d\n", boardID);
		break;
	case GET_AO_STATUS:
		qDebug("Cmd: GET_AO_STATUS to card %d\n", boardID);
		break;
	case RD_AOCAL_REC:
		qDebug("Cmd: RD_AOCAL_REC to card %d\n", boardID);
		break;
	case RD_BD_CAPABILITY:
		qDebug("Cmd: RD_BD_CAPABILITY to card %d\n", boardID);
		break;
	case REPORT_ERRORS:
		qDebug("Cmd: REPORT_ERRORS to card %d\n", boardID);
		break;
	case WR_AICHAN_CONFIG:
		qDebug("Cmd: WR_AICHAN_CONFIG to card %d\n", boardID);
		break;
	case WR_AI_CONFIG:
		qDebug("Cmd: WR_AI_CONFIG to card %d\n", boardID);
		break;
	case WR_AO_CONFIG:
		qDebug("Cmd: WR_AO_CONFIG to card %d\n", boardID);
		break;
	case WR_DIG_CONFIG:
		qDebug("Cmd: WR_DIG_CONFIG to card %d\n", boardID);
		break;
	default:
		qDebug("Cmd: -- Unknown to card %d\n", boardID);
		break;
	}
}
//**********************************************************************
/// Output debug info on IO board protocol, QUAD for debug purposes only
///
/// @param[in]  pBuffer - Pointer to the data buffer
/// @param[in]	size - pointer to the buffer size
///	@param[in]	IsAWrite - TRUE if "Write" FALSE if "Read"
/// @return nothing
///
//**********************************************************************
void CBaseProtocol::DecodeCmdName(const UCHAR cmd, wchar_t *pBuffer, int pBufferSize) const {
	switch (cmd) {
	case RESET:
		wcscpy(pBuffer, L"RESET");
		break;
	case GET_BOARD_TYPE:
		wcscpy(pBuffer, L"GET_BOARD_TYPE");
		break;
	case GET_BOARD_ID:
		wcscpy(pBuffer, L"GET_BOARD_ID");
		break;
	case GET_TIMESTAMP:
		wcscpy(pBuffer, L"GET_TIMESTAMP");
		break;
	case GET_LIFE_HIST:
		wcscpy(pBuffer, L"GET_LIFE_HIST");
		break;
	case GET_VERSION:
		wcscpy(pBuffer, L"GET_VERSION");
		break;
	case GET_ID_VER:
		wcscpy(pBuffer, L"GET_ID_VER");
		break;
	case GET_GUID:
		wcscpy(pBuffer, L"GET_GUID");
		break;
	case SET_BD_TEST_DATA:
		wcscpy(pBuffer, L"SET_BD_TEST_DATA");
		break;
	case GET_BD_TEST_DATA:
		wcscpy(pBuffer, L"GET_BD_TEST_DATA");
		break;
	case SET_GUID:
		wcscpy(pBuffer, L"SET_GUID");
		break;
	case SET_BOARD_ID:
		wcscpy(pBuffer, L"SET_BOARD_ID");
		break;
	case SET_DIAG_INTVL:
		wcscpy(pBuffer, L"SET_DIAG_INTVL");
		break;
	case GET_TS_BASE:
		wcscpy(pBuffer, L"GET_TS_BASE");
		break;
	case SET_MAINS_F:
		wcscpy(pBuffer, L"SET_MAINS_F");
		break;
	case RESET_BUFF_TS:
		wcscpy(pBuffer, L"RESET_BUFF_TS");
		break;
	case WR_BOARD_SETUP:
		wcscpy(pBuffer, L"WR_BOARD_SETUP");
		break;
	case RD_BOARD_SETUP:
		wcscpy(pBuffer, L"RD_BOARD_SETUP");
		break;
	case RD_AICAL_REC:
		wcscpy(pBuffer, L"RD_AICAL_REC");
		break;
	case GET_CJC:
		wcscpy(pBuffer, L"GET_CJC");
		break;
	case RD_ANAL_INPUT:
		wcscpy(pBuffer, L"RD_ANAL_INPUT");
		break;
	case RD_ANAL_BLOCK:
		wcscpy(pBuffer, L"RD_ANAL_BLOCK");
		break;
	case ACK_GOOD_AIBLOCK:
		wcscpy(pBuffer, L"ACK_GOOD_AIBLOCK");
		break;
	case FACT_CALIB:
		wcscpy(pBuffer, L"FACT_CALIB");
		break;
	case USER_CALIB:
		wcscpy(pBuffer, L"USER_CALIB");
		break;
	case RD_FACT_CAL:
		wcscpy(pBuffer, L"RD_FACT_CAL");
		break;
	case RD_USER_CAL:
		wcscpy(pBuffer, L"RD_USER_CAL");
		break;
	case SET_RAW_MODE:
		wcscpy(pBuffer, L"SET_RAW_MODE");
		break;
	case GET_RT_CAL:
		wcscpy(pBuffer, L"GET_RT_CAL");
		break;
	case GET_RT_COMP:
		wcscpy(pBuffer, L"GET_RT_COMP");
		break;
	case SET_RANGE:
		wcscpy(pBuffer, L"SET_RANGE");
		break;
	case SET_ACQ_FREQ:
		wcscpy(pBuffer, L"SET_ACQ_FREQ");
		break;
	case RD_AICHAN_CONFIG:
		wcscpy(pBuffer, L"RD_AICHAN_CONFIG");
		break;
	case RD_AI_CONFIG:
		wcscpy(pBuffer, L"RD_AI_CONFIG");
		break;
	case RD_DIG_IN_BLK:
		wcscpy(pBuffer, L"RD_DIG_IN_BLK");
		break;
	case ACK_GOOD_DIG_BLK:
		wcscpy(pBuffer, L"ACK_GOOD_DIG_BLK");
		break;
	case RD_DIG_INPUT:
		wcscpy(pBuffer, L"RD_DIG_INPUT");
		break;
	case WR_DIG_OUTPUT:
		wcscpy(pBuffer, L"WR_DIG_OUTPUT");
		break;
	case RD_PULSE_IN_BLK:
		wcscpy(pBuffer, L"RD_PULSE_IN_BLK");
		break;
	case RD_DIG_CONFIG:
		wcscpy(pBuffer, L"RD_DIG_CONFIG");
		break;
	case WR_ANAL_OUTPUT:
		wcscpy(pBuffer, L"WR_ANAL_OUTPUT");
		break;
	case SET_AO_RAWMODE:
		wcscpy(pBuffer, L"SET_AO_RAWMODE");
		break;
	case SET_AO_CALIB:
		wcscpy(pBuffer, L"SET_AO_CALIB");
		break;
	case RD_AO_CALIB:
		wcscpy(pBuffer, L"RD_AO_CALIB");
		break;
	case RD_AO_CONFIG:
		wcscpy(pBuffer, L"RD_AO_CONFIG");
		break;
	case GET_AO_STATUS:
		wcscpy(pBuffer, L"GET_AO_STATUS");
		break;
	case RD_AOCAL_REC:
		wcscpy(pBuffer, L"RD_AOCAL_REC");
		break;
	case RD_BD_CAPABILITY:
		wcscpy(pBuffer, L"RD_BD_CAPABILITY");
		break;
	case REPORT_ERRORS:
		wcscpy(pBuffer, L"REPORT_ERRORS");
		break;
	case WR_AICHAN_CONFIG:
		wcscpy(pBuffer, L"WR_AICHAN_CONFIG");
		break;
	case WR_AI_CONFIG:
		wcscpy(pBuffer, L"WR_AI_CONFIG");
		break;
	case WR_AO_CONFIG:
		wcscpy(pBuffer, L"WR_AO_CONFIG");
		break;
	case WR_DIG_CONFIG:
		wcscpy(pBuffer, L"WR_DIG_CONFIG");
		break;
	case iMX53_FAILED_RESEND:
		wcscpy(pBuffer, L"iMX53_FAILED_RESEND");
		break;
	default:
		wcscpy(pBuffer, L"Unknown Cmd");
		break;
	}
}
//**********************************************************************
/// Output debug info on IO board protocol; (for debug purposes only)
///
/// @param[in]  pBuffer - Pointer to the data buffer
/// @param[in]	size - pointer to the buffer size
///	@param[in]	IsAWrite - TRUE if "Write" FALSE if "Read"
/// @return nothing
///
//**********************************************************************
void CBaseProtocol::DebugIOMessage(BYTE *pBuffer, ULONG size, BOOL IsAWrite) {
// #ifdef DEBUG						// Only do if debugging
	const int PROT_OUT_LIMIT = 20;
	WCHAR commandText[40];
	ULONG byteNum = 0;				// Start at beginning of message
	// It's a command so decipher
	switch (*pBuffer) {
	case RESET:
		swprintf(commandText, 40, L"Reset");
		break;
	case GET_BOARD_TYPE:
		swprintf(commandText, 40, L"GetBoardType");
		break;
	case GET_BOARD_ID:
		swprintf(commandText, 40, L"GetBoardId");
		break;
	case GET_TIMESTAMP:
		swprintf(commandText, 40, L"GetTimeStamp");
		break;
	case GET_LIFE_HIST:
		swprintf(commandText, 40, L"GetLifeHist");
		break;
	case UPDATE_STATS:
		swprintf(commandText, 40, L"UpdateStats");
		break;
	case GET_VERSION:
		swprintf(commandText, 40, L"GetVersion");
		break;
	case GET_ID_VER:
		swprintf(commandText, 40, L"GetIDVer");
		break;
	case GET_GUID:
		swprintf(commandText, 40, L"GetGUID");
		break;
	case REPORT_ERRORS:
		swprintf(commandText, 40, L"ReportErrors");
		break;
	case SET_BD_TEST_DATA:
		swprintf(commandText, 40, L"SetBDTestData");
		break;
	case GET_BD_TEST_DATA:
		swprintf(commandText, 40, L"GetBDTestData");
		break;
	case SET_GUID:
		swprintf(commandText, 40, L"SetGuid");
		break;
	case SET_BOARD_ID:
		swprintf(commandText, 40, L"SetBoardId");
		break;
	case SET_DIAG_INTVL:
		swprintf(commandText, 40, L"SetDiagInterval");
		break;
	case GET_TS_BASE:
		swprintf(commandText, 40, L"GetTSBase");
		break;
	case SET_MAINS_F:
		swprintf(commandText, 40, L"SetMainFreq");
		break;
	case RESET_BUFF_TS:
		swprintf(commandText, 40, L"ResetBuffTS");
		break;
	case WR_BOARD_SETUP:
		swprintf(commandText, 40, L"WriteBoardSetup");
		break;
	case RD_BOARD_SETUP:
		swprintf(commandText, 40, L"ReadBoardSetup");
		break;
	case RD_BD_CAPABILITY:
		swprintf(commandText, 40, L"ReadBoardCaps");
		break;
		// Analogue card
	case RD_AICAL_REC:
		swprintf(commandText, 40, L"ReadAICalRec");
		break;
	case GET_CJC:
		swprintf(commandText, 40, L"GetCJC");
		break;
	case RD_ANAL_INPUT:
		swprintf(commandText, 40, L"ReadAnalIn");
		break;
	case RD_ANAL_BLOCK:
		swprintf(commandText, 40, L"ReadAnaBlock");
		break;
	case ACK_GOOD_AIBLOCK:
		swprintf(commandText, 40, L"AckGoodAIBlock");
		break;
	case FACT_CALIB:
		swprintf(commandText, 40, L"FactCalib");
		break;
	case USER_CALIB:
		swprintf(commandText, 40, L"UserCalib");
		break;
	case RD_FACT_CAL:
		swprintf(commandText, 40, L"ReadFactCal");
		break;
	case RD_USER_CAL:
		swprintf(commandText, 40, L"ReadUserCal");
		break;
	case SET_RAW_MODE:
		swprintf(commandText, 40, L"SetRawMode");
		break;
	case GET_RT_CAL:
		swprintf(commandText, 40, L"GetRTCal");
		break;
	case GET_RT_COMP:
		swprintf(commandText, 40, L"GetRTComp");
		break;
	case SET_RANGE:
		swprintf(commandText, 40, L"SetRange");
		break;
	case SET_ACQ_FREQ:
		swprintf(commandText, 40, L"SetAcqFreq");
		break;
	case WR_AICHAN_CONFIG:
		swprintf(commandText, 40, L"WriteAIChanConfig");
		break;
	case RD_AICHAN_CONFIG:
		swprintf(commandText, 40, L"ReadAiChanConfig");
		break;
	case WR_AI_CONFIG:
		swprintf(commandText, 40, L"WriteAIBoardConfig");
		break;
	case RD_AI_CONFIG:
		swprintf(commandText, 40, L"ReadAIBoardConfig");
		break;
	case SET_ACTIVE_BNOUT:
		swprintf(commandText, 40, L"SetActiveBurnout");
		break;
	case GET_BNOUT_STATUS:
		swprintf(commandText, 40, L"GetBurnoutStatus");
		break;
	case CHK_BNOUT_WIRING:
		swprintf(commandText, 40, L"CheckBurnoutWiring");
		break;
	case TURN_RT_CURR_OFF:
		swprintf(commandText, 40, L"TurnRTCurrentOff");
		break;
		// Digital IO card
	case RD_DIG_IN_BLK:
		swprintf(commandText, 40, L"ReadDigInBlock");
		break;
	case ACK_GOOD_DIG_BLK:
		swprintf(commandText, 40, L"AckGoodDigBlock");
		break;
	case RD_DIG_INPUT:
		swprintf(commandText, 40, L"ReadDigInput");
		break;
	case WR_DIG_OUTPUT:
		swprintf(commandText, 40, L"WriteDigOutput");
		break;
	case RD_PULSE_IN_BLK:
		swprintf(commandText, 40, L"ReadPulseInBlock");
		break;
	case WR_DIG_CONFIG:
		swprintf(commandText, 40, L"WriteDigConfig");
		break;
	case RD_DIG_CONFIG:
		swprintf(commandText, 40, L"ReadDigConfig");
		break;
		// Analogue Output
	case WR_ANAL_OUTPUT:
		swprintf(commandText, 40, L"WriteAnalOutput");
		break;
	case SET_AO_RAWMODE:
		swprintf(commandText, 40, L"SetAORawMode");
		break;
	case SET_AO_CALIB:
		swprintf(commandText, 40, L"SetAOCalib");
		break;
	case RD_AO_CALIB:
		swprintf(commandText, 40, L"ReadAOCalib");
		break;
	case WR_AO_CONFIG:
		swprintf(commandText, 40, L"WriteAOConfig");
		break;
	case RD_AO_CONFIG:
		swprintf(commandText, 40, L"ReadAOConfig");
		break;
	case GET_AO_STATUS:
		swprintf(commandText, 40, L"GetAOStatus");
		break;
	case RD_AOCAL_REC:
		swprintf(commandText, 40, L"ReadAOCalRec");
		break;
	default:
		swprintf(commandText, 40, L"Unknown command %d ", *pBuffer);
		break;
	}
	// Trace out leader
//	swprintf(commandText, L"IOP %s(%d):%s(%d)", IsAWrite ? L"Write" : L"Read ", GetInstance(), commandText, size );
//	LogInternalError( commandText.toLocal8Bit().data() );
	// Trace out data characters
	wcscpy(commandText, L"");
	for ( /*byteNum already set */; (byteNum < size) && (byteNum < PROT_OUT_LIMIT); byteNum++) {
		swprintf(commandText, 40, L"%s%02x ", commandText, *pBuffer++);
	}
	LogInternalError(commandText);
	/// Finish off debug statement
	if (byteNum == PROT_OUT_LIMIT) {
//		swprintf(commandText, L" <Limited to %d>", PROT_OUT_LIMIT );
//		LogInternalError( commandText.toLocal8Bit().data() );
	}
// #endif
}
//******************************************************
//  CheckReplyByte()
///
/// Checks whether the reply byte is still within the number of bytes read from the card.
/// @param[in] messPos - Byte position in message being checked.
///
/// @return TRUE if byte still within returned message length (less CRC), otherwise FALSE.
///
//******************************************************
BOOL CBaseProtocol::CheckReplyByte(const UCHAR messPos) {
//	WCHAR failureText [40];
	BOOL retValue = FALSE;
	if (messPos < m_RxSize - 2) {
		retValue = TRUE;
	} else {
//		swprintf( failureText, L"Diagnostic - Reduced length message found (%d)", messPos);
//		LogInternalError( failureText.toLocal8Bit().data() );
//		sleep(10);
//		DebugIOMessage( static_cast<BYTE *>(&m_RxMessage[0]), m_RxSize, FALSE);
	}
	return retValue;
}
#define MINIMUM_LEGAL_RX_MESSAGE_LENGTH	6
//******************************************************
//  CheckReply()
///
/// Checks whether the CRC of the reply is correct.
/// @param[in] MessID - ID of message expected returned.
/// @param[out] ErrorType - Error status of response, reported by response.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CBaseProtocol::CheckReply(const UCHAR MessID, UCHAR *const pErrorType) {
	USHORT msgLength = 0;
	BOOL retValue = TRUE;
	BOOL knownError = FALSE;
	BOOL suspectReturn = FALSE;
	const UCHAR *pErrorStr = NULL;
	UCHAR errorCode = ERR_NO_ERROR;	///< Place holder for error generated by incorrect verification of return message
	UCHAR size = 0;
	UCHAR failCount = ERROR_REPORT_NONE;
	E_ERROR_REPORT_STAT reportStat = EERS_NO_REPORT_RQD;
	class CBrdStats *pBrdStats = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;						///< Board info holder
	class CSlotMap *pSlotMap = NULL;
	class CDeviceAbstraction *pDevAbs = NULL;	///< Device abstraction layer
	pSlotMap = CSlotMap::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	pBrdStats = CBrdStats::GetHandle();
	*pErrorType = ERR_NO_ERROR;					///< Assume success
	m_pData = NULL;
	errorCode = ERR_NO_ERROR;					///< Assume success
	msgLength = ((m_RxMessage[RX_MESS_HI_BYTE_COUNT] * 256) + m_RxMessage[RX_MESS_LO_BYTE_COUNT] + SPI_HDR_PLUS_CRC);
	pDevAbs = CDeviceAbstraction::GetHandle();
	// Check for illegal messages or if too few characters have been received for the number of data bytes expected
	if ((m_RxSize < MINIMUM_LEGAL_RX_MESSAGE_LENGTH) || (m_RxSize < msgLength)) {
		errorCode = ERR_IO_SCHED_INCOMPLETE_MSG;		// Unknown/invalid response
		/// For Rev B boards only we need to flush any response message held
		if (pDevAbs != NULL) {
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				FlushIOErrors();
		} else {
			/// Cannot flush errors, so many more commands will fail
			LogInternalError(L"Cannot flush errors");
		}
		retValue = FALSE;		///< No further processing possible on message
	}
	// Is message CRC OK
	if ((retValue == TRUE) && CrcTest(static_cast<UCHAR*>(&m_RxMessage[IO_MESSAGE_START_BYTE]), msgLength) == FALSE) {
		errorCode = ERR_IO_SCHED_INVALID_CRC;		// CRC failure
		retValue = FALSE;		///< No further processing possible on message
		UCHAR *pBuff = new UCHAR[m_RxSize];
		memcpy(pBuff, m_RxMessage, m_RxSize);
		PostMessage(g_hWnd, WM_APP + 46, (WPARAM) pBuff, (LPARAM) m_RxSize);
	}
	if (retValue == TRUE) {
		// Check for incorrect FC returned
		if (m_RxMessage[RX_FX_CODE] != MessID) {
			errorCode = ERR_IO_SCHED_INVALID_FC;		// Invalid FC returned in response
			/// For Rev B boards only we need to flush any response message held
			if (pDevAbs->GetSPIProcFW() == REV_B_PROCESSOR_BOARD)
				FlushIOErrors();
			retValue = FALSE;		///< No further processing possible on message
		}
		if (m_RxMessage[RX_MESS_EC_BYTE] == ERR_LM3S1621_FAILED_RESEND
				|| m_RxMessage[RX_MESS_EC_BYTE] == ERR_MESS_FAILED_FROM_CARD) {
			errorCode = m_RxMessage[RX_MESS_EC_BYTE];
			retValue = FALSE;
		}
	}
	if (retValue == TRUE) {
		/// Are there errors generated by the message response failure
		if (m_RxSize == 6) {
//			*pErrorType = m_RxMessage[1];
			/// Check for message responses with no actual return data, but include reference to a data buffer
			if (m_RxMessage[RX_MESS_LO_BYTE_COUNT] != 0)
				suspectReturn = TRUE;// Return is possibly missing vital return data - need to confirm based on the message number.
		}
	}
	if (errorCode == ERR_NO_ERROR) {
		if ((retValue != FALSE)) {
			// Check for messages responses with no return data
			*pErrorType = m_RxMessage[RX_MESS_EC_BYTE];
			m_pData = &m_RxMessage[RX_START_OF_DATA];
		}
		// As yet a read digital block data that returns no data overrides any errors;
		// so the only way to get errors is to schedule in a read errors; just in case
		if ((m_RxMessage[RX_FX_CODE] == RD_DIG_IN_BLK) && (*pErrorType != ERR_NO_DATA)) {
			m_pBoard->ScheduleErrorDownload();
		}
		/// If errors then set the approriate status and perform the neccersary error downloads
		if ((*pErrorType != ERR_NO_ERROR) && (*pErrorType != ERR_PARTIAL_DATA) && (*pErrorType != ERR_NO_DATA)) {
			// Schedule a read of all board errors on read; if the board has been identified and created
			if (m_pBoard != NULL) {
				/// Subsequent errors may have bee generated by failure of the command message, so schedule download
				/// Note there may be no errors returned, but we must clear the bufer for any chance of recovery
				m_pBoard->ScheduleErrorDownload();
			}
			//		if( (m_RxMessage[RX_FX_CODE] != REPORT_ERRORS) && (*pErrorType != ERR_IN_LIST) )
			if (*pErrorType != ERR_IN_LIST) {
				// Decode the error that we already have (even though there may be more it will not be repeated)
				size = 1;
				pErrorStr = &m_RxMessage[RX_MESS_EC_BYTE];
				errorCode = m_RxMessage[RX_MESS_EC_BYTE];
				knownError = DecodeBoardError(&pErrorStr, size, ERROR_REPORT_SINGLE, FALSE);
				// Log low level failure (but not the non command specific failure code)
				// Check single entry list
				if ((pBrdStats->CheckFailCount(GetInstance(), EERT_NON_PARAMETERISED, errorCode, &failCount) == TRUE)
						&& (failCount <= ERROR_REPORT_CONTINUOUS)) {
					pBrdStats->LogFailure(GetInstance(), EERT_NON_PARAMETERISED, errorCode);
				}
				reportStat = pBrdStats->CheckReportStatus(m_Instance, EERT_NON_PARAMETERISED, errorCode);
				if (reportStat != EERS_NO_REPORT_RQD) {
					QString err;
					QString MessText;
					WCHAR cmdStr[30];
					WCHAR boardSlotStr[4];
					DecodeCmdName(m_ProcCommmand, &cmdStr[RX_FX_CODE], sizeof(cmdStr) / sizeof(WCHAR));
					pSlotMap->GetSlotStrID(m_Instance, boardSlotStr);
					if (retValue == TRUE)
						MessText = QString::asprintf("Failure reported by board cmd %s Card %s : Error 0x%X", cmdStr,
								boardSlotStr, errorCode);
					else
						MessText = QString::asprintf("Failure from cmd %s Card %s : Error 0x%X", cmdStr, boardSlotStr,
								errorCode);
					if (reportStat == EERS_REPORT_MANY) {
						err = QString::asprintf(L">%d failures: %s", ERROR_REPORT_MANY, MessText);
					} else if (reportStat == EERS_REPORT_CONTINUOUS) {
						err = QString::asprintf(L">%d failures: %s", ERROR_REPORT_CONTINUOUS, MessText);
					} else {
						err = QString::asprintf(L"%s", MessText);
					}
					// Log which command reported the failure
					AddErrorToReport(err.toLocal8Bit().data());
				}
			}
			// If it's a test equipment build then we may want to carry on trying, rather than declaring the board unusable
			// Identify the high level function that has failed.
			switch (m_RxMessage[RX_FX_CODE]) {
			case RESET:
			case GET_BOARD_TYPE:
			case GET_BOARD_ID:
			case GET_TIMESTAMP:
			case GET_LIFE_HIST:
				//				case RESET_STATS:
			case GET_VERSION:
			case GET_ID_VER:
			case GET_GUID:
			case SET_BD_TEST_DATA:
			case GET_BD_TEST_DATA:
			case SET_GUID:
			case SET_BOARD_ID:
			case SET_DIAG_INTVL:
			case GET_TS_BASE:
			case SET_MAINS_F:
			case RESET_BUFF_TS:
			case RD_BOARD_SETUP:
			case RD_AICAL_REC:
			case GET_CJC:
			case RD_ANAL_INPUT:
			case RD_ANAL_BLOCK:
			case ACK_GOOD_AIBLOCK:
			case FACT_CALIB:
			case USER_CALIB:
			case RD_FACT_CAL:
			case RD_USER_CAL:
			case SET_RAW_MODE:
			case GET_RT_CAL:
			case GET_RT_COMP:
			case SET_RANGE:
			case SET_ACQ_FREQ:
			case RD_AICHAN_CONFIG:
			case RD_AI_CONFIG:
			case RD_DIG_IN_BLK:
			case ACK_GOOD_DIG_BLK:
			case RD_DIG_INPUT:
			case WR_DIG_OUTPUT:
			case RD_PULSE_IN_BLK:
			case RD_DIG_CONFIG:
			case WR_ANAL_OUTPUT:
			case SET_AO_RAWMODE:
			case SET_AO_CALIB:
			case RD_AO_CALIB:
			case RD_AO_CONFIG:
			case GET_AO_STATUS:
			case RD_AOCAL_REC:
				break;
			case RD_BD_CAPABILITY:
				pBrdInfoObj->SetBoardType(GetInstance(), BOARD_INVALID);
				break;
			case REPORT_ERRORS:
				// Give up if we can't even download what errors have occurred
			case WR_AICHAN_CONFIG:
			case WR_AI_CONFIG:
			case WR_AO_CONFIG:
			case WR_DIG_CONFIG:
				// If it is any of the write configurations then the board is in an unknown state,
				// therefore is unusable
				m_pBrdStatsObj->SetBoardOpState(GetInstance(), FALSE);
				break;
			default:
				// Unknown command, so cannot believe any of that return
				break;
			}
		} else {
			switch (m_RxMessage[RX_FX_CODE]) {
			case RD_BD_CAPABILITY:
			case WR_BOARD_SETUP:
			case WR_AI_CONFIG:
			case WR_AO_CONFIG:
			case WR_DIG_CONFIG:
				// Correct operation ensures board is operational again
				m_pBrdStatsObj->SetBoardOpState(GetInstance(), TRUE);
				break;
			}
		}
		// Ensure we acknowledge no data from digital card - otherwise we continue getting the same 'empty' data returned
		if ((*pErrorType != ERR_NO_DATA)
				&& ((pBrdInfoObj->WhatBoardType(GetInstance()) == BOARD_DIO)
						|| (pBrdInfoObj->WhatBoardType(GetInstance()) == BOARD_AR))) {
			retValue = TRUE;
		}
	} else {
		// Decode the error discovered from decoding the message return
		size = 1;
		*pErrorType = errorCode;
		pErrorStr = &errorCode;
		DecodeBoardError(&pErrorStr, size, ERROR_REPORT_SINGLE, FALSE);
	}
	return retValue;
}

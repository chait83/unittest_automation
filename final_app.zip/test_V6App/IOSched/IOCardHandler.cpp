/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOCardHandler.cpp
/// @n implementation for the I/O Card Handler class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 34	Stability Project 1.29.1.3	7/2/2011 4:58:00 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 33	Stability Project 1.29.1.2	7/1/2011 4:38:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 32	Stability Project 1.29.1.1	3/17/2011 3:20:25 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 31	Stability Project 1.29.1.0	2/15/2011 3:03:10 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "PPQManager.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "IOCardHandler.h"
#include "PPIOService.h"
#include "PPDICard.h"
#include "PPIOServiceManager.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "DigPulseCard.h"
#include "SlotMap.h"
#include "PPL.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CIOCardHandler::CIOCardHandler() {
//	qDebug("Create new CIOCardHandler\n");
	memset(&m_Info, 0xdd, sizeof(m_Info));
	m_Info.PPService = PP_SERVICE_UNKNOWN;
}
CIOCardHandler::~CIOCardHandler() {
//	qDebug("Delete CIOCardHandler class\n");
}
//******************************************************
// InitialiseChanService()
///
/// Initialises a channel to connect to the approriate Data Item table
/// or data queue for data extraction/processing.
/// @param[in] pBoardInfo - I/O board process information.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOCardHandler::InitialiseCardService(T_COMMONPROCESSINFO *const pBoardInfo) {
	BOOL retValue = FALSE;
	class CPPDICard *pDICard = NULL;
	class CPPIOServiceManager *pServiceMngr = NULL;
	retValue = CIOHandler::InitialiseChanService(pBoardInfo);
	// Initialise digital in service,
	// Initialise the digital card services
	pServiceMngr = GetServiceManager();
	if (pServiceMngr != NULL) {
		pDICard = pServiceMngr->GetDIService();
	}
	if (pDICard != NULL) {
		// Initialise all channels at once
		retValue = pDICard->InitialiseChanService(pBoardInfo);
	} else {
		LogInternalError("CIOCardHandler::InitialiseService failed");
	}
	memcpy(&m_Info, pBoardInfo, sizeof(T_COMMONPROCESSINFO));
	return retValue;
}
//******************************************************
// StartChanService()
///
/// Synchronises the data queues and starts data acqusition
/// @param[in] pBoardInfo - I/O board process information.
///
/// @return TRUE on successful starting of the queues; otherwise FALSE
/// 
//******************************************************
BOOL CIOCardHandler::StartChanService(T_COMMONPROCESSINFO *const pBoardInfo) {
	BOOL retValue = TRUE;
	class CPPDICard *pDICard = NULL;
	class CPPIOServiceManager *pServiceMngr = NULL;
	if ((IsRunningAsATEEquipment() == FALSE) && (pBoardInfo->PPService == PP_SERVICE_DI_CARD)) {
		// Initialise the digital card services
		pServiceMngr = GetServiceManager();
		if (pServiceMngr != NULL) {
			pDICard = pServiceMngr->GetDIService();
			if (pDICard != NULL) {
				// Initialise all channels at once
				retValue = pDICard->InitialiseChanService(pBoardInfo);
			} else {
				LogInternalError("CIOCardHandler::InitialiseService failed");
				retValue = FALSE;
			}
		}
	}
	return retValue;
}
//**********************************************************************
/// Sets all services on a setup commit change preperation
///
/// @return TRUE on successful commit; otherwise FALSE
/// 
//**********************************************************************
BOOL CIOCardHandler::SetupConfigChangePreparation(void) {
	class CPPIOServiceManager *pServiceMngr = NULL;
	class CPPDICard *pDICardHandler = NULL;
	BOOL retValue = TRUE;
	if (m_Info.PPService == PP_SERVICE_DI_CARD) {
		pServiceMngr = GetServiceManager();
		if (pServiceMngr != NULL) {
			// Get Digital in card handler
			pDICardHandler = pServiceMngr->GetDIService();
			if (pDICardHandler != NULL)
				pDICardHandler->DisableService(&m_CSInfo);
		}
	}
	return retValue;
}
//******************************************************
// ResyncService()
///
/// Synchronises a card's digital input pre-process queue
/// @param[in] IOCardTick - I/O card tick to sync to.
/// @param[in] systemTick - The global system time to sync to.
///
/// @return TRUE on successful sync; otherwise FALSE
/// 
//******************************************************
BOOL CIOCardHandler::ResyncService(const USHORT IOCardTick, const LONGLONG systemTick) {
	class CPPDICard *pDICard = NULL;
	BOOL retValue = FALSE;
	if (m_Info.PPService == PP_SERVICE_DI_CARD) {
		// Get Digital in card handler (will not be one if there are no digital inputs selected)
		pDICard = GetServiceManager()->GetDIService();
		if (pDICard != NULL)
			retValue = pDICard->ResyncPPQueue(&m_Info, IOCardTick, systemTick);
	} else
		retValue = TRUE; //MarkD: for now, if no inputs, return true so there is no failure reported
	return retValue;
}
//******************************************************
// ResyncService()
///
/// Synchronises a channel's pre-process queue
/// @param[in] IOCardTick - I/O card tick to sync to.
/// @param[in] systemTick - The global system time to sync to.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOCardHandler::SyncService(const USHORT IOCardTick, const LONGLONG systemTick) {
	class CPPDICard *pDICard = NULL;
	BOOL retValue = FALSE;
	if (m_Info.PPService == PP_SERVICE_DI_CARD) {
		// Get Digital in card handler
		pDICard = GetServiceManager()->GetDIService();
		if (pDICard != NULL)
			retValue = pDICard->SyncPPQueue(&m_Info, IOCardTick, systemTick);
	}
	return retValue;
}
//******************************************************
// SetLastReadingCoverage()
///
/// Set the continued coverage of the digital last reading.
/// @param[in] systemTick - The system tick time.
///
/// @return TRUE
/// 
//******************************************************
BOOL CIOCardHandler::SetLastReadingCoverage(const LONGLONG systemTick) {
	BOOL retValue = FALSE;
	class CPPDICard *pDICard = NULL;
	if (m_Info.PPService == PP_SERVICE_DI_CARD) {
		// Get Digital in card handler
		pDICard = GetServiceManager()->GetDIService();
		if (pDICard != NULL)
			retValue = pDICard->SetLastReadingCoverage(&m_Info, systemTick);
	}
	return retValue;
}
//******************************************************
// ProcessDigitalInReadings()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
/// @param[in] pServiceData - Service message data.
/// @param[in] noOfBytesToProcess - Number of digital reading data bytes to process.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
BOOL CIOCardHandler::ProcessDigitalInReadings(const UCHAR *pServiceData, const USHORT noOfBytesToProcess) {
	BOOL retValue = FALSE;
	class CPPIOServiceManager *pServiceManager = NULL;
	class CPPDICard *pDICard = NULL;
	// if( m_Info.PPService == PP_SERVICE_DI_CARD )
	{
		// Get Digital in card handler
		pServiceManager = GetServiceManager();
		if (pServiceManager != NULL)
			pDICard = pServiceManager->GetDIService();
		if (pDICard != NULL)
			retValue = pDICard->ProcessDigitalInReadings(&m_Info, pServiceData, noOfBytesToProcess);
	}
	return retValue;
}

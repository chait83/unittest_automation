/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n BrdStats.cpp
/// @n implementation of the CBrdStats class.
/// Database holding the current board status information
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 63	Stability Project 1.58.1.3	7/2/2011 4:55:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 62	Stability Project 1.58.1.2	7/1/2011 4:38:00 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 61	Stability Project 1.58.1.1	3/17/2011 3:20:12 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 60	Stability Project 1.58.1.0	2/15/2011 3:02:20 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "IOCardInfo.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "Timer.h"
#include "PPL.h"
#include "V6globals.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CBrdStats::CBrdStats() {
	class CInputConditioning *pICService = NULL; ///< Input conditioning service
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	USHORT slotNo = 0;
	USHORT chanNo = 0;
//	qDebug("Create new CBrdStats\n");
	memset(&m_BrdStat, 0, sizeof(m_BrdStat));
	// Reset all board status variables to their default condition
	m_FirstRunAfterPowerUp = TRUE;
#ifdef V6IOTEST
	m_SetIdleMode = FALSE;		// Start-up straight away if test equipment build
#else
	m_SetIdleMode = TRUE;
#endif
	m_SetLimitedRunMode = FALSE;
	m_ShutdownOrdered = FALSE;
	m_RunModeType = ERMT_NORMAL;
	// Reset all board status variables to their default condition
	// Reset the status of each board in turn
	for (slotNo = 0; slotNo < MAX_SCHED_SERVICES; slotNo++) {
		ResetCardStats(slotNo);
		for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) //coverity fix id 773760
				{
			SetIOTimesync(slotNo, chanNo, 0, 0);
			ResetChanStatMonitor(slotNo, chanNo);
			// If channel is an AI channel then reset active burnout wiring test status
			SetChanTCWiringState(slotNo, chanNo, WIRING_NOT_TESTED);
			SetChanTCBurnoutState(slotNo, chanNo, CInputConditioning::BURNOUT_OK);	// Assume all is well
		}
	}
	m_isSecondaryReset = FALSE;
	// Start the global timer for board acquisition
	m_schedTimer.starttimer();
}
CBrdStats::~CBrdStats() {
//	qDebug("Delete CBrdStats\n");
	m_schedTimer.stoptimer();
}
CBrdStats *CBrdStats::m_pInstance = NULL;
QMutex CBrdStats::m_CreationMutex;
void CBrdStats::ResetChanStatMonitor(const USHORT slotNo, int chanNo) {
	m_BrdStat[slotNo].ChanStatMonitor[chanNo].PPQOpStatus = 0;
	m_BrdStat[slotNo].ChanStatMonitor[chanNo].MissedReadings = 0;
	m_BrdStat[slotNo].ChanStatMonitor[chanNo].RepeatedReadings = 0;
	m_BrdStat[slotNo].ChanStatMonitor[chanNo].LostTimeTicks = 0;
	m_BrdStat[slotNo].ChanStatMonitor[chanNo].GainTimeTicks = 0;
	m_BrdStat[slotNo].ChanStatMonitor[chanNo].RTCalFailures = 0;
	m_BrdStat[slotNo].ChanStatMonitor[chanNo].RTCompFailures = 0;
}
//******************************************************
// ResetCardStats()
///
/// Defaults a board slots status.
/// @param[in] slotNo - Card slot number identification.
///
//******************************************************
void CBrdStats::ResetCardStats(const USHORT slotNo) {
	USHORT errorCode = 0;
	// Reset all the non parameter/channel error codes
	for (errorCode = 0; errorCode < MAX_ERRORS; errorCode++) {
		m_BrdStat[slotNo].singleFail[errorCode].exceededLogged = FALSE;
		m_BrdStat[slotNo].singleFail[errorCode].failCount = 0;
	}
	// Reset all the parameter &/or channel error codes
	for (errorCode = 0; errorCode < ERR_ADC_CHANS_INIT_END; errorCode++) {
		m_BrdStat[slotNo].serialised[errorCode].exceededLogged = FALSE;
		m_BrdStat[slotNo].serialised[errorCode].failCount = 0;
	}
	// Reset all AP8 error codes
	for (errorCode = 0; errorCode < AP8_IOCARD_ERROR_COUNT; errorCode++) {
		m_BrdStat[slotNo].AP8Failure[errorCode].exceededLogged = FALSE;
		m_BrdStat[slotNo].AP8Failure[errorCode].failCount = 0;
	}
	// Reset all I/O reading error codes
	for (errorCode = 0; errorCode < IO_READING_CHAN_LOG; errorCode++) {
		m_BrdStat[slotNo].IOreading[errorCode].exceededLogged = FALSE;
		m_BrdStat[slotNo].IOreading[errorCode].failCount = 0;
	}
}
//**********************************************************************
///
/// Instance creation of CBrdStats singleton
///
/// @return		pointer to single instance of CBrdStats
/// 
//**********************************************************************
CBrdStats* CBrdStats::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance)
				m_pInstance = new CBrdStats;
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			/// Handle Error
			LogInternalError("Could not create BrdStats");
			V6WarningMessageBox(NULL, "BoardStats WaitForSingleObject Error", "CBrdStats Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
/// @return		pointer to single instance of CBrdStats
//**********************************************************************
void CBrdStats::CleanUp() {
	if (NULL != m_pInstance) {
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//******************************************************
///
/// Resets the fact that this is the first execution since power-up.
/// 
//******************************************************
void CBrdStats::ResetFirstPowerUp(void) {
	m_FirstRunAfterPowerUp = FALSE;
}
//******************************************************
///
///Query whether this is the first execution since power-up.
/// 
/// @return TRUE if this is the first execution after power-up; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::QueryFirstPowerUp(void) const {
	return m_FirstRunAfterPowerUp;
}
//******************************************************
// SetBoardPresent()
///
/// Sets whether a card is present.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] present - TRUE if card is present; otherwise FALSE.
///
/// @return TRUE if card has been found; otherwise FALSE
/// 
//******************************************************
void CBrdStats::SetBoardPresent(const USHORT cardNo, const BOOL present) {
	m_BrdStat[cardNo].GenStat.Summary.BoardIdentified = present;
}
//******************************************************
// SetBoardOpState()
///
/// Sets whether a card is present.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] operational - TRUE if card is operation; otherwise FALSE.
///
//******************************************************
void CBrdStats::SetBoardOpState(const USHORT cardNo, const BOOL operational) {
	m_BrdStat[cardNo].GenStat.Summary.BoardFailed = static_cast<BOOL>(operational == FALSE);
}
//******************************************************
// IsSecondaryReset()
///
/// Checks whether the secondary has been reset
//******************************************************
BOOL CBrdStats::IsConfigChangeRequired(void) {
	return m_isSecondaryReset;
}
//******************************************************
// SetSecondaryReset()
///
/// Sets the Secondary Processor state
/// @param[in] setvalue - Set (FALSE) or Reset (TRUE)
/// @param[in] operational - TRUE if card is operation; otherwise FALSE.
///
//******************************************************
void CBrdStats::SetConfigChange(BOOL setvalue) {
	m_isSecondaryReset = setvalue;
}
//******************************************************
// SetAnaOutValue()
///
/// Sets the mA being output on an analogue output channel.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] mA - The mA being output by the AO channel.
///
//******************************************************
void CBrdStats::SetAnaOutValue(const USHORT slotNo, const USHORT chanNo, const float mA) {
	m_BrdStat[slotNo].AOStats[chanNo].chanmA = mA;
}
//******************************************************
// GetAnaOutValue()
///
/// Sets whether a TC channel on the card is wired correctly.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
///
/// @return The mA being output by the AO channel
///
//******************************************************
float CBrdStats::GetAnaOutValue(const USHORT slotNo, const USHORT chanNo) {
	return m_BrdStat[slotNo].AOStats[chanNo].chanmA;
}
//**********************************************************************
/// Sets whether the channel load is O/C
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - The card slot channel number that is being queried.
/// @param[in] chanOC - TRUE if the channel is O/C; otherwise FALSE.
///
/// @return TRUE if the channel was O/C; otherwise FALSE
/// 
//**********************************************************************
BOOL CBrdStats::SetAOChanOPState(const USHORT slotNo, const USHORT chanNo, const BOOL chanOC) {
	BOOL previousState;
	previousState = m_BrdStat[slotNo].AOStats[chanNo].OP_OC;
	m_BrdStat[slotNo].AOStats[chanNo].OP_OC = chanOC;
	return previousState;
}
//**********************************************************************
/// Query whether the channel load is O/C
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - The card slot channel number that is being queried.
///
/// @return TRUE if the channel is O/C; otherwise FALSE
/// 
//**********************************************************************
BOOL CBrdStats::GetAOChanOPState(const USHORT slotNo, const USHORT chanNo) const {
	return m_BrdStat[slotNo].AOStats[chanNo].OP_OC;
}
//******************************************************
// SetChanTCWiringState()
///
/// Sets whether a TC channel on the card is wired correctly.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] wiringState - The state of the wiring.
///
//******************************************************
void CBrdStats::SetChanTCWiringState(const USHORT cardNo, const USHORT chanNo, const BRNOUT_WIRING_STATUS wiringState) {
	m_BrdStat[cardNo].ChanBrnSat[chanNo].WiringState = wiringState;
}
//******************************************************
// GetChanTCWiringState()
///
/// Gets whether a TC channel on the card is wired correctly.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
///
/// @return wiring state
/// 
//******************************************************
BRNOUT_WIRING_STATUS CBrdStats::GetChanTCWiringState(const USHORT cardNo, const USHORT chanNo) {
	return static_cast<BRNOUT_WIRING_STATUS>(m_BrdStat[cardNo].ChanBrnSat[chanNo].WiringState);
}
//******************************************************
// SetUserCalDate()
///
/// Sets the user calibration date for a given slot/channel.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] Date - The date that the user calibration was performed on for a given channel.
///
//******************************************************
void CBrdStats::SetUserCalDate(const USHORT cardNo, const USHORT chanNo, const ULONG Date) {
	m_BrdStat[cardNo].ChanStatMonitor[chanNo].UserCalDate = Date;
}
//******************************************************
// SetFactoryCalDate()
///
/// Sets the user calibration date for a given slot/channel.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] Date - The date that the factory calibration was performed on for a given card.
/// @param[in] rigID - The rig number that perfored the factory calibration for a given card.
///
//******************************************************
void CBrdStats::SetFactoryCalDate(const USHORT cardNo, const ULONG Date, const UCHAR rigID) {
	m_BrdStat[cardNo].FactoryCalDate = Date;
	m_BrdStat[cardNo].rigID = rigID;
}
//******************************************************
// GetUserCalDate()
///
/// Gets the user calibration date for a given slot/channel.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] Date - The date that the user calibration was performed on for a given channel.
///
//******************************************************
void CBrdStats::GetUserCalDate(const USHORT cardNo, const USHORT chanNo, ULONG &Date) {
	Date = m_BrdStat[cardNo].ChanStatMonitor[chanNo].UserCalDate;
}
//******************************************************
// GetFactoryCalDate()
///
/// Gets the user calibration date for a given slot/channel.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] Date - The date that the factory calibration was performed on for a given card.
/// @param[in] rigID - The rig number that perfored the factory calibration for a given card.
///
//******************************************************
void CBrdStats::GetFactoryCalDate(const USHORT cardNo, ULONG &Date, UCHAR &rigID) {
	Date = m_BrdStat[cardNo].FactoryCalDate;
	rigID = m_BrdStat[cardNo].rigID;
}
//******************************************************
// SetChanTCBurnoutState()
///
/// Sets the state of a T/C for a given slot/channel.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] State - The state of the T/C.
///
//******************************************************
void CBrdStats::SetChanTCBurnoutState(const USHORT cardNo, const USHORT chanNo,
		const CInputConditioning::IO_BURNOUT_STATUS State) {
	m_BrdStat[cardNo].ChanBrnSat[chanNo].Status = State;
}
//******************************************************
// GetChanTCBurnoutState()
///
/// Gets whether a TC channel on the card is wired correctly.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
///
/// @return The T/C burnout state
/// 
//******************************************************
CInputConditioning::IO_BURNOUT_STATUS CBrdStats::GetChanTCBurnoutState(const USHORT cardNo, const USHORT chanNo) {
	return static_cast<CInputConditioning::IO_BURNOUT_STATUS>(m_BrdStat[cardNo].ChanBrnSat[chanNo].Status);
}
//******************************************************
// CheckFailCount()
///
/// Checks the report status of the I/O board error.
/// @param[in] slotNo - Card slot number identification.
/// @param[in] errorType - Type of error being checked.
/// @param[in] errorCode - Error code.
///
/// @Note: If errorType == EERT_PARAMETERISED then errors must already be serialised
///
/// @return Number of errors already logged against failcode
///
//******************************************************
BOOL CBrdStats::CheckFailCount(const USHORT slotNo, const E_ERROR_TYPE errorType, const USHORT errorCode,
		UCHAR *pFailCount) const {
	BOOL retValue = FALSE;
	USHORT normErrorCode = errorCode;
	if (errorType == EERT_AP8_DRIVER) {
		// It is an AP8 error
		if (errorCode <= AP8_IOCARD_ERROR_COUNT) {
			*pFailCount = m_BrdStat[slotNo].AP8Failure[errorCode].failCount;
			retValue = TRUE;
		} else
			qDebug("Error EERT_LM3S_DRIVER lookup out of bounds\n");
	} else if (errorType == EERT_IO_READING_FAILURE) {
		// It is an I/O reading error
		normErrorCode -= MISSING_RT_CAL;
		//PSR - Coverity issue fix --#773919
		if (normErrorCode < IO_READING_CHAN_LOG) {
			*pFailCount = m_BrdStat[slotNo].IOreading[normErrorCode].failCount;
			retValue = TRUE;
		} else
			qDebug("Error EERT_IO_READING_FAILURE lookup out of bounds\n");
	} else if (errorType == EERT_PARAMETERISED) {
		// I/O board has returned a standard error with parameters and/or channels
		if (errorCode <= ERR_ADC_CHANS_INIT_END) {
			*pFailCount = m_BrdStat[slotNo].serialised[errorCode].failCount;
			retValue = TRUE;
		} else
			qDebug("Error EERT_PARAMETERISED lookup out of bounds\n");
	} else if (errorType == EERT_NON_PARAMETERISED) {
		// I/O board has returned a standard error that has no parameters (or parameters cannot be evaluated)
		if (errorCode <= MAX_ERRORS) {
			*pFailCount = m_BrdStat[slotNo].singleFail[errorCode].failCount;
			retValue = TRUE;
		} else
			qDebug("Error EERT_NON_PARAMETERISED lookup out of bounds\n");
	}
	return retValue;
}
//******************************************************
// LogFailure()
///
/// Logs that a failure has occurred.
/// @param[in] slotNo - Card slot number identification.
/// @param[in] errorType - Type of error being checked.
/// @param[in] errorCode - Error code.
///
/// @Note: If errorType == EERT_PARAMETERISED then errors must already be serialised
///
//******************************************************
void CBrdStats::LogFailure(const USHORT slotNo, const E_ERROR_TYPE errorType, const USHORT errorCode) {
	USHORT normErrorCode = errorCode;
	if (errorType == EERT_AP8_DRIVER) {
		// It is an AP8 error
		if (errorCode <= AP8_IOCARD_ERROR_COUNT) {
			m_BrdStat[slotNo].AP8Failure[errorCode].failCount++;
		} else {
			qDebug("Error EERT_LM3S_DRIVER lookup out of bounds\n");
		}
	} else if (errorType == EERT_IO_READING_FAILURE) {
		// It is an I/O reading error
		normErrorCode -= MISSING_RT_CAL;
		if (normErrorCode < IO_READING_CHAN_LOG) {
			m_BrdStat[slotNo].IOreading[normErrorCode].failCount++;
		} else {
			qDebug("Error EERT_IO_READING_FAILURE lookup out of bounds\n");
		}
	} else if (errorType == EERT_PARAMETERISED) {
		// I/O board has returned a standard error with parameters and/or channels
		if (errorCode <= ERR_ADC_CHANS_INIT_END) {
			m_BrdStat[slotNo].serialised[errorCode].failCount++;
		} else {
			qDebug("Error EERT_PARAMETERISED lookup out of bounds\n");
		}
	} else if (errorType == EERT_NON_PARAMETERISED) {
		// I/O board has returned a standard error that has no parameters (or parameters cannot be evaluated)
		if (errorCode <= MAX_ERRORS) {
			m_BrdStat[slotNo].singleFail[errorCode].failCount++;
		} else {
			qDebug("Error EERT_NON_PARAMETERISED lookup out of bounds\n");
		}
	}
}
//******************************************************
// LogFailure()
///
/// Logs that a failure has occurred.
/// @param[in] slotNo - Card slot number identification.
/// @param[in] errorType - Type of error being checked.
/// @param[in] errorCode - Error code.
/// @param[in] failCount - The number of times the code has failed.
///
/// @Note: If errorType == EERT_PARAMETERISED then errors must already be serialised
///
//******************************************************
void CBrdStats::LogMultipleFailures(const USHORT slotNo, const E_ERROR_TYPE errorType, const USHORT errorCode,
USHORT failCount) {
	USHORT normErrorCode = errorCode;
	if (errorType == EERT_AP8_DRIVER) {
		// It is an AP8 error
		if (errorCode <= AP8_IOCARD_ERROR_COUNT)
			m_BrdStat[slotNo].AP8Failure[errorCode].failCount += failCount;
		else
			qDebug("Error EERT_LM3S_DRIVER lookup out of bounds\n");
	} else if (errorType == EERT_IO_READING_FAILURE) {
		// It is an I/O reading error
		normErrorCode -= MISSING_RT_CAL;
		if (normErrorCode < IO_READING_CHAN_LOG) //coverity fix 780190
			m_BrdStat[slotNo].IOreading[normErrorCode].failCount += failCount;
		else
			qDebug("Error EERT_IO_READING_FAILURE lookup out of bounds\n");
	} else if (errorType == EERT_PARAMETERISED) {
		// I/O board has returned a standard error with parameters and/or channels
		if (errorCode <= ERR_ADC_CHANS_INIT_END)
			m_BrdStat[slotNo].serialised[errorCode].failCount += failCount;
		else
			qDebug("Error EERT_PARAMETERISED lookup out of bounds\n");
	} else if (errorType == EERT_NON_PARAMETERISED) {
		// I/O board has returned a standard error that has no parameters (or parameters cannot be evaluated)
		if (errorCode <= MAX_ERRORS)
			m_BrdStat[slotNo].singleFail[errorCode].failCount += failCount;
		else
			qDebug("Error EERT_NON_PARAMETERISED lookup out of bounds\n");
	}
}
//******************************************************
// CheckReportStatus()
///
/// Checks the report status of the I/O board error.
/// @param[in] slotNo - Card slot number identification.
/// @param[in] errorType - Type of error being checked.
/// @param[in] errorCode - Error code.
///
/// @Note: If errorType == EERT_PARAMETERISED then errors must already be serialised
///
/// @return The report status of the report
///
//******************************************************
E_ERROR_REPORT_STAT CBrdStats::CheckReportStatus(const USHORT slotNo, const E_ERROR_TYPE errorType,
		const USHORT errorCode) const {
	UCHAR failCount = ERROR_REPORT_NONE;
	E_ERROR_REPORT_STAT retValue = EERS_NO_REPORT_RQD;
	if (CheckFailCount(slotNo, errorType, errorCode, &failCount) == TRUE) {
		if (failCount == ERROR_REPORT_SINGLE)
			retValue = EERS_REPORT_FIRST;
		else if (failCount == ERROR_REPORT_CONTINUOUS)
			retValue = EERS_REPORT_CONTINUOUS;
		else if (failCount == ERROR_REPORT_MANY)
			retValue = EERS_REPORT_MANY;
	} else
		retValue = EERS_REPORT_FIRST;
	return retValue;
}
//******************************************************
// MoveCardCapabilitiesToNewSlot()
///
/// Moves the board capabilities form one card slot to another.
/// @param[in] OrigCardSlot - Card slot number identification data originally placed in.
/// @param[in] newCardSlot - Card slot number to move data into.
///
//******************************************************
void CBrdStats::MoveCardCapabilitiesToNewSlot(const USHORT OrigCardSlot, const USHORT newCardSlot) {
	// Move the existing board
	m_BrdStat[newCardSlot].GenStat.Summary.BoardIdentified = m_BrdStat[OrigCardSlot].GenStat.Summary.BoardIdentified;
	m_BrdStat[newCardSlot].GenStat.Summary.BoardFailed = m_BrdStat[OrigCardSlot].GenStat.Summary.BoardFailed;
	// Clear the existing reference
	m_BrdStat[newCardSlot].GenStat.Summary.BoardIdentified = FALSE;
	m_BrdStat[newCardSlot].GenStat.Summary.BoardFailed = FALSE;
}
//******************************************************
// IsBoardPresent()
///
/// Checks whether a card is present.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE if card is present; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::IsBoardPresent( USHORT cardNo) const {
	return static_cast<BOOL>(m_BrdStat[cardNo].GenStat.Summary.BoardIdentified);
}
//******************************************************
// IsBoardOperational()
///
/// Checks whether a card is operational.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE if card is operational; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::IsBoardOperational(const USHORT cardNo) const {
	return static_cast<BOOL>(m_BrdStat[cardNo].GenStat.Summary.BoardFailed == 0);
}
//******************************************************
// SetChannelRTCompRqdState()
///
/// Checks whether a card channel requires RT Comp service.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] state - TRUE - Card slot channel RT comp required.
///
//******************************************************
void CBrdStats::SetChannelRTCompRqdState(const USHORT cardNo, const USHORT chanNo, const BOOL state) {
	m_BrdStat[cardNo].ChanStat[chanNo].RTCompRqd = state;
}
//******************************************************
// SetChannelRTCalRqdState()
///
/// Checks whether a card channel requires RT Cal service.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] state - TRUE - Card slot channel RT comp required.
///
//******************************************************
void CBrdStats::SetChannelRTCalRqdState(const USHORT cardNo, USHORT chanNo, const BOOL state) {
	m_BrdStat[cardNo].ChanStat[chanNo].RTCalRqd = state;
}
//******************************************************
// IsChannelRTCompRqd()
///
/// Checks whether a card channel requires RT Comp service.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
///
/// @return TRUE if card is operational; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::IsChannelRTCompRqd(const USHORT cardNo, const USHORT chanNo) const {
	return static_cast<BOOL>(m_BrdStat[cardNo].ChanStat[chanNo].RTCompRqd != 0);
}
//******************************************************
// IsChannelRTCalRqd()
///
/// Checks whether a card channel requires RT Cal service.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
///
/// @return TRUE if card is operational; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::IsChannelRTCalRqd(const USHORT cardNo, const USHORT chanNo) const {
	return static_cast<BOOL>(m_BrdStat[cardNo].ChanStat[chanNo].RTCalRqd != 0);
}
//******************************************************
// ShutdownOrdered()
///
/// Instructs the I/O scheduler to shutdown.
///
/// @return Nothing
/// 
//******************************************************
void CBrdStats::ShutdownOrdered(void) {
	m_ShutdownOrdered = TRUE;
}
//******************************************************
// HasShutdownBeenOrdered()
///
/// Queries whether the I/O scheduler shutdown command has been processed.
///
/// @return TRUE if shutdown is ordered; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::HasShutdownBeenOrdered(void) const {
	return m_ShutdownOrdered;
}
//******************************************************
// SetIdleMode()
///
/// Instructs the I/O scheduler to shutdown.
///
/// @return Nothing
/// 
//******************************************************
void CBrdStats::SetIdleMode(void) {
	m_SetIdleMode = TRUE;
}
//******************************************************
// CancelIdleMode()
///
/// Instructs the I/O scheduler to shutdown.
///
/// @return Nothing
/// 
//******************************************************
void CBrdStats::CancelIdleMode(void) {
	m_SetIdleMode = FALSE;
}
//******************************************************
// SetLimitedRunMode()
///
/// Instructs the I/O scheduler to enter limited run mode (for calibration).
///
/// @return Nothing
/// 
//******************************************************
void CBrdStats::SetLimitedRunMode(void) {
	m_SetLimitedRunMode = TRUE;
}
//******************************************************
// SetRunModeType()
///
/// Instructs the I/O scheduler which run mode to enter.
/// @param[in] mode - The I/O run mode selected.
///
/// @return Nothing
/// 
//******************************************************
void CBrdStats::SetRunModeType(const E_RUN_MODE_TYPE mode) {
	m_RunModeType = mode;
}
//******************************************************
// CancelLimitedRunMode()
///
/// Instructs the I/O scheduler to cancel limited run mode.
///
/// @return Nothing
/// 
//******************************************************
void CBrdStats::CancelLimitedRunMode(void) {
	m_SetLimitedRunMode = FALSE;
}
//******************************************************
// SetCardBeingCalibrated()
///
/// Instructs the I/O scheduler to cancel limited run mode.
/// @param[in] slotNo - Card slot number identification.
///
/// @return Nothing
/// 
//******************************************************
void CBrdStats::SetCardBeingCalibrated(const USHORT slotNo) {
	m_BoardBeingCalibrated = slotNo;
}
//******************************************************
// HasLimitedRunModeBeenOrdered()
///
/// Queries whether the I/O scheduler limited run request has been processed.
/// @param[in] slotNo - Card slot number identification.
///
/// @return TRUE if limited mode has been ordered; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::HasLimitedRunModeBeenOrderedOnCard(const USHORT slotNo) const {
	BOOL retValue = FALSE;
	if ((m_SetLimitedRunMode == TRUE) && (m_BoardBeingCalibrated == slotNo))
		retValue = TRUE;
	return retValue;
}
//******************************************************
// HasIdleModeBeenOrdered()
///
/// Queries whether the I/O scheduler shutdown command has been processed.
///
/// @return TRUE if shutdown is ordered; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::HasIdleModeBeenOrdered(void) const {
	return m_SetIdleMode;
}
//******************************************************
// HasLimitedRunModeBeenOrdered()
///
/// Queries whether the I/O scheduler limited run request has been processed.
///
/// @return TRUE if limited mode has been ordered; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::HasLimitedRunModeBeenOrdered(void) const {
	return m_SetLimitedRunMode;
}
//******************************************************
// QueryRunModeType()
///
/// Queries which mode to run the I/O scheduler in.
///
/// @return The current run mode
/// 
//******************************************************
E_RUN_MODE_TYPE CBrdStats::QueryRunModeType(void) const {
	return m_RunModeType;
}
//******************************************************
///
/// Sets the IO time sync command.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] chanNo - Card channel number identification.
/// @param[in] IOTicks - Number of IO ticks at timesync.
/// @param[in] SysTicks - Number of system ticks (before I/O get ticks sent).
///
/// @return TRUE if time sync accepted; otherwise FALSE
/// 
//******************************************************
BOOL CBrdStats::SetIOTimesync(const USHORT cardNo, const USHORT chanNo, const USHORT IOTicks, const LONGLONG sysTicks) {
	if (cardNo < MAX_SCHED_SERVICES) {
		m_BrdStat[cardNo].ChanStatMonitor[chanNo].QueueTS.IOQueueSyncTime = IOTicks;
		m_BrdStat[cardNo].ChanStatMonitor[chanNo].QueueTS.SysQueueSyncTime = sysTicks;
		return TRUE;
	}
	return FALSE;
}
//******************************************************
///
/// Sets the IO time sync command.
/// @param[in] cardNo - Cardrd

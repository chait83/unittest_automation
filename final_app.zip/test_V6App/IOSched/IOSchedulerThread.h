//////////////////////////////////////////////////////////////////////
/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: IOSchedulerThread.h
/// @n Desc:	interface for the IOSchedulerThread class.
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log:
// 5	Stability Project 1.2.1.1	7/2/2011 4:58:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 4	Stability Project 1.2.1.0	7/1/2011 4:27:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 3	V6 Firmware 1.2		12/16/2004 10:15:56 PM Graham Waterfield
//		Allow channels to be read one at a time
// 2	V6 Firmware 1.1		11/26/2004 8:51:59 PM Graham Waterfield
//		Creating running I/O scheduler process
// 1	V6 Firmware 1.0		9/28/2004 4:20:02 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_IOSCHEDULERTHREAD_H__0F4A7993_2C6B_4158_B84E_4F1064B43BB0__INCLUDED_)
#define AFX_IOSCHEDULERTHREAD_H__0F4A7993_2C6B_4158_B84E_4F1064B43BB0__INCLUDED_
#include "Defines.h"
/////////////////////////////////////////////////////////////////////////////
// CIOSchedulerThread thread
class CIOSchedulerThread: public QThread {
	// DECLARE_DYNCREATE (CIOSchedulerThread)
protected:
	CIOSchedulerThread();	// protected constructor used by dynamic creation
// Attributes
public:
// Operations
public:
	static UINT ThreadFunc(LPVOID lpParam);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIOSchedulerThread)
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL
// Implementation
protected:
	virtual ~CIOSchedulerThread();
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_IOSCHEDULERTHREAD_H__0F4A7993_2C6B_4158_B84E_4F1064B43BB0__INCLUDED_)

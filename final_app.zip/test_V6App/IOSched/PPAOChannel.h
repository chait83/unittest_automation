/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PPAOChannel.h
/// @n Desc:	Interface of the Pre-process AO channel class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 11	Stability Project 1.8.1.1	7/2/2011 4:59:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 10	Stability Project 1.8.1.0	7/1/2011 4:27:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 9	V6 Firmware 1.8		10/4/2005 7:23:31 PM	Graham Waterfield
//		Implement ohms auto 2-wire and 3-wire measurement selection
// 8	V6 Firmware 1.7		9/22/2005 4:15:39 PM	Graham Waterfield
//		Debugging the analogue output, current measurement, RT fault
//		reporting and RT 50Hz operation
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PPAOCHANNEL_H
#define _PPAOCHANNEL_H
#if !defined(AFX_PPAOCHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PPAOCHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#include "Defines.h"
#include "PPIOService.h"
class CPPAOChannel: public CPPIOService {
public:
	CPPAOChannel(BOOL isChanInput);
	virtual ~CPPAOChannel();
	BOOL InitialiseChanService(T_CHANPROCESSINFO *const pChanInfo);
	BOOL OutputAnalogue(T_CHANPROCESSINFO *const pChanInfo, USHORT *pOutputVal);
	BOOL IsAOUpdateRqd(T_CHANPROCESSINFO *const pChanInfo);
	BOOL CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
			class CCardSlot *pCard,
			USHORT chanNo);
private:
	USHORT m_LastOPValue;		///< Last value output to card
	// Places were channel data needs to be placed (and form it should take?)
};
#endif // !defined(AFX_PPAOCHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif // _PPAOCHANNEL_H

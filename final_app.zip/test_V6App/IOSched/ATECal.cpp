/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n ATECal.cpp
/// @n implementation of the CATECal class.
/// Contains the current board status information
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 146 Stability Project 1.141.1.3	7/2/2011 4:55:29 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 145 Stability Project 1.141.1.2	7/1/2011 4:37:57 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 144 Stability Project 1.141.1.1	3/17/2011 3:20:10 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 143 Stability Project 1.141.1.0	2/15/2011 3:02:12 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "DataItemIO.h"
#include "DataItemManager.h"
#include "Conversion.h"
#include "V6IO_AI_InputRanges.H"
#include "V6defines.h"
#include "V6globals.h"
#include "CMMDefines.h"
#include "V6Config.h"
#include "AIConfig.h"
#include "ConfigManager.h"
#include "InputConditioning.h"
#include "IOCard.h"
#include "ATECal.h"
#include "PPL.h"
#include "ModuleMsgManagerClient.h"
#include "TV6Timer.h"
#include <math.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CATECal::CATECal() {
	USHORT chanNo;
//	qDebug("Create new CATECal\n");
	memset(&m_cfgAI, 0, sizeof(m_cfgAI));
	memset(&m_AICal, 0, sizeof(m_AICal));
	memset(&m_cfgAO, 0, sizeof(m_cfgAO));
	memset(&m_cfgDigPulse, 0, sizeof(m_cfgDigPulse));
	memset(&m_wrkDigBoard, 0, sizeof(m_wrkDigBoard));
	m_RTIOffChanMask = 0;
	m_lastChanSet = 0;
	DigitalInChanState = 0;
	// Default to normal operation mode, with no card selected
	m_calAbort = FALSE;
	m_calMode = CM_ATE_TEST;
	m_opMode = CTOM_ATE_READ;
	m_cardSlot = ILLEGAL_CARD_SELECTED;
	// No setups or output states updated
	m_ComitSetup = TRUE;
	m_setupUpdated = FALSE;
	m_OPUpdated = TRUE;
	m_runtimeUpdated = FALSE;
	m_StatusCheckRqd = FALSE;
	// No failues currently
	m_commsError = CESS_NO_ERROR;
	// Default the AI configuration
	ResetAllAIChannelsToPrecise();
	for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
		m_cfgAI.CfgChan[chanNo].TCCfg.ActiveBurnout = FALSE;
		m_cfgAI.CfgChan[chanNo].TCCfg.BurnOutSelect = TRUE;
		m_cfgAI.CfgChan[chanNo].TCCfg.CJCompAI = 0;
		m_cfgAI.CfgChan[chanNo].TCCfg.CJCompMethod = AIN_CJC_INTERNAL_AUTO;
		m_cfgAI.CfgChan[chanNo].TCCfg.UpScaleBurnOut = TRUE;
		m_cfgAI.CfgChan[chanNo].TCCfg.ExtSpecifiedCJ = 0.0F;
		AICJValidChanRTOffset[chanNo] = FALSE; ///< No valid RT channel calibrations available
		AICJValidSavedChanRTOffset[chanNo] = FALSE;	///< No saved RT channel calibration data available
		AIChanRawReadingAvailable[chanNo] = FALSE;	///< Raw readings not available
		AIChanVReadingAvailable[chanNo] = FALSE;	///< Range voltage readings not available
		AIChanVoltageReading[chanNo] = 0.0F;	///< AI Channel voltage readings
		AIChanRawReading[chanNo] = 0;				///< AI Channel raw readings
	}
	for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
		m_OP_OC[chanNo] = FALSE;
	}
	for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
		m_cfgDigPulse.CfgChan[chanNo].PulseIn = FALSE;
		m_cfgDigPulse.CfgChan[chanNo].DigOut = FALSE;
		m_cfgDigPulse.CfgChan[chanNo].DigIn = FALSE;
//		m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled = FALSE;
	}
	// Analogue out uses pens rather than direct calibration structure
	m_DirectOP = FALSE;
	m_directRTReadMode = FALSE;
	// Clear the Pulse readings
	ResetAllPulseChannelsReadings();
}
CATECal::~CATECal() {
//	qDebug("Delete CATECal\n");
}
CATECal *CATECal::m_pInstance = NULL;
QMutex CATECal::m_CreationMutex;
//**********************************************************************
///
/// Instance creation of CATECal singleton
///
/// @return		pointer to single instance of CATECal
/// 
//**********************************************************************
CATECal* CATECal::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance)
				m_pInstance = new CATECal;
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			/// Handle Error
			LogInternalError("Could not create ATECal");
			V6WarningMessageBox(NULL, L"ATECal WaitForSingleObject Error", L"ATECal Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
/// @return		pointer to single instance of CATECal
//**********************************************************************
void CATECal::CleanUp() {
	if (NULL != m_pInstance) {
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//****************************************************************************
///	RegisterClientWindow()
///
/// Registers the window which will receive AddString and WriteString messages
/// 
///	@param[in]	clientWnd - the client display window handle
///
/// @return		TRUE if succesfully registered; otherwise FALSE
//****************************************************************************
BOOL CATECal::RegisterClientWindow(HWND clientWnd) {
	m_hWnd = clientWnd;
	return TRUE;
}
//****************************************************************************
///	void AddString(const QString   & csDispString)
///
/// Adds a string to the progress dlg
/// 
///	@param[in]	const QString   & csDispString - the string to display
///
/// @return		None
//****************************************************************************
void CATECal::AddString(const QString &csDispString) const {
	T_MESSAGE_DETAILS *pMess = new T_MESSAGE_DETAILS;
	pMess->csDispMess = csDispString;
	pMess->csErrMess = "";
	//write the current display string to the progress dlg
	::PostMessage(m_hWnd, WM_DISPLAY_MESSAGE, 0, (LPARAM) pMess);
}
//****************************************************************************
///	void WriteErrorFileString(const QString   &csFileMess)
///
/// Writes a string to the error file
/// 
///	@param[in]	const QString   & csFileMess - the string to write
///
/// @return		None
//****************************************************************************
void CATECal::WriteErrorFileString(const QString &csFileMess) const {
	T_MESSAGE_DETAILS *pMess = new T_MESSAGE_DETAILS;
	pMess->csDispMess.Empty();
	pMess->csErrMess = csFileMess;
	// write the current error message to the progress dlg
	::PostMessage(m_hWnd, WM_ERROR_MESSAGE, 0, (LPARAM) pMess);
}
//******************************************************
///
/// Save the calibration status to NV
/// @param[in] slotNo - Card slot number (0 based).
/// @param[in] chanNo - Channel number on card slot (zero based).
/// @param[in] rangeNo - Range number being calibrated.
/// @param[in] state - The new calibration state to be saved.
///
/// @return TRUE if no problems were detected otherwise FALSE.
/// 
//******************************************************
BOOL CATECal::SaveUserCalStatToNV(const USHORT slotNo, const USHORT chanNo, const USHORT rangeNo,
		const CInputConditioning::IO_CAL_OPTIONS state) {
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	return pICService->SaveUserCalStatToNV(slotNo, chanNo, rangeNo, state);
}
//******************************************************
///
/// Obtains the working copy of the I/O board calibration requirement/status info
/// from the NV RAM copy.
/// @param[in] slotNo - The slot number being queried.
///
/// @return The I/O board calibration structure.
/// 
//******************************************************
T_IORANGECAL* CATECal::GetLocalAIBoardCalInfo(const USHORT slotNo, const USHORT range) {
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	m_cardSlot = static_cast<UCHAR>(slotNo);
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	return pICService->GetIOBoardCalInfo(m_cardSlot, range);
}
//******************************************************
///
/// Obtains the working copy of the I/O board calibration requirement/status info
/// from the CMM modifiable.
/// @param[in] slotNo - The slot number being queried.
///
/// @return The I/O board calibration structure.
/// 
//******************************************************
T_IORANGECAL* CATECal::GetAIBoardCalInfo(const USHORT slotNo, const USHORT range) {
	class CIOSetupConfig *pIOModSetupConfig = NULL;
	T_RECORDERCAL *pCMMRecorderCal = NULL;
	pIOModSetupConfig = pSETUP->GetIOSetupConfig();
	if (pIOModSetupConfig != NULL) {
		pCMMRecorderCal = pIOModSetupConfig->GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
	}
	return &(pCMMRecorderCal->RecorderCals[slotNo].RangeCals[range]);
}
const USHORT ATE_CHANNEL_RETRIES = 20;
const USHORT ATE_CHANNEL_RETRY_DELAY = 100;
//**********************************************************************
/// Obtains the raw value from the card for specified channel
/// @param[in] chanNo - The card slot channel number that is being queried.
/// @param[in] pReading - The channel reading.
///
/// @return TRUE if all channels were acquired; otherwise FALSE
/// 
//**********************************************************************
BOOL CATECal::GetChannelVoltages(const USHORT chanNo,
T_RANGE_COUNTS *pReading) {
	BOOL retVal = FALSE;
	USHORT readAttempts = 0;
	// Continue looping until timeout, or a successful reading is obtained
	while ((retVal == FALSE) && (readAttempts < ATE_CHANNEL_RETRIES) && (m_calAbort == FALSE)) {
		retVal = GetAIChanRawReadings(chanNo, pReading);
		//only pause if no retVal was given
		if (FALSE == retVal) {
			sleep(ATE_CHANNEL_RETRY_DELAY);
			readAttempts++;
		}
	}
	return retVal;
}
//**********************************************************************
/// Abort obtaining the raw value from the card for all channels
/// @param[in] abort - TRUE if abort is ordered; otherwise FALSE.
///
/// @return TRUE if abort is succesfully ordered; otherwise FALSE
/// 
//**********************************************************************
BOOL CATECal::SetAbortCalibrationState(const BOOL abort) {
	m_calAbort = abort;
	return m_calAbort;
}
//**********************************************************************
/// Obtains the raw value from the card for all selected card channels
/// @param[in] chanMask - The channel mask.
///
/// @return TRUE if all channels were acquired; otherwise FALSE
/// 
//**********************************************************************
BOOL CATECal::ReadAnalogueInChannelValues(const USHORT chanMask) {
	T_RANGE_COUNTS reading;
	BOOL retVal = TRUE;
	UCHAR chanNo = 0;
//	QString   strReport( QString   ::fromWCharArray("") );
//	strReport = QString::asprintf( L"Reading channel %u values", chanMask );
//	AddSystemWarningToReport( strReport.toLocal8Bit().data() );
	//Get the channel voltages for each channel
	for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
		if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
			retVal = GetChannelVoltages(chanNo, &reading);
		}
		if (FALSE == retVal)
			break;			// Any channel fails then abort
	}
	return retVal;
}
//**********************************************************************
/// Query whether the channel load is O/C
/// @param[in] chanNo - The card slot channel number that is being queried.
/// @param[in] chanOC - TRUE if the channel is O/C; otherwise FALSE.
///
/// @return TRUE if the channel was O/C; otherwise FALSE
/// 
//**********************************************************************
BOOL CATECal::SetAOChanState(const USHORT chanNo, const BOOL chanOC) {
	BOOL previousState;
	previousState = m_OP_OC[chanNo];
	m_OP_OC[chanNo] = chanOC;
	return previousState;
}
//**********************************************************************
/// Query whether the channel load is O/C
/// @param[in] chanNo - The card slot channel number that is being queried.
///
/// @return TRUE if the channel is O/C; otherwise FALSE
/// 
//**********************************************************************
BOOL CATECal::GetAOChanState(const USHORT chanNo) const {
	return m_OP_OC[chanNo];
}
//**********************************************************************
///
/// Check whether it is time to commit the the set cal points
///
/// @return		TRUE if commit is required; otherwise FALSE
//**********************************************************************
BOOL CATECal::TimeToCommitCalPoints(void) {
	return static_cast<BOOL>(m_opMode == CTOM_ATE_CAL_COMMIT_SET_POINTS);
}
//**********************************************************************
///
/// Check whether it is time to commit the the set cal points
///
/// @return		TRUE if commit is required; otherwise FALSE
//**********************************************************************
T_CAL_TEST_OP_MODE CATECal::GetOperationalMode(void) const {
	return m_opMode;
}
//**********************************************************************
///
/// Reset all AI channnels to precise (slowest) acqusition mode
///
/// @return		TRUE if the relevant configuration is defaulted; otherwise FALSE
//**********************************************************************
BOOL CATECal::ResetAllAIChannelsToPrecise(void) {
	USHORT chanNo;
	for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
		m_cfgAI.CfgChan[chanNo].ChanCfgInfo.acqEnum = AI_ACQ_RATE_2HZ;
	}
	m_setupUpdated = TRUE;
	return TRUE;
}
//**********************************************************************
///
/// Reset all AI channnels to precise (slowest) acqusition mode
///
/// @return		TRUE if the relevant configuration is defaulted; otherwise FALSE
//**********************************************************************
void CATECal::ConfirmDownloadCompleted(void) {
	m_setupUpdated = FALSE;
	m_ComitSetup = TRUE;
}
//**********************************************************************
///
/// Reset all pulse channel readings
///
/// @return		TRUE if the relevant configuration is defaulted; otherwise FALSE
//**********************************************************************
BOOL CATECal::ResetAllPulseChannelsReadings(void) {
	USHORT chanNo;
	for (chanNo = 0; chanNo < TOPSLOT_PULSECHAN_SIZE; chanNo++) {
		PulseInChanCount[chanNo] = ILLEGAL_PULSE_READING;
	}
	m_runtimeUpdated = TRUE;
	return TRUE;
}
//**********************************************************************
///
/// Set the volt reading expected
/// @param[in] chanMask - The mask of the channels to be read.
/// @param[in] desiredVoltage - The voltage which should be read.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::TestModeAIVRead(const USHORT chanMask, const float desiredVoltage) {
	BOOL retValue = TRUE;
	m_calMode = CM_ATE_TEST;
	m_opMode = CTOM_ATE_READ;
	m_chanMask = chanMask;
	m_testCalOutput = desiredVoltage;
	m_CalOPUnits = UNITS;
	m_runtimeUpdated = TRUE;
	return retValue;
}
//**********************************************************************
///
/// Set the milli-volt reading expected
/// @param[in] chanMask - The mask of the channels to be read.
/// @param[in] desiredVoltage - The voltage which should be read.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::TestModeAImVRead(const USHORT chanMask, const float desiredVoltage) {
	BOOL retValue = TRUE;
	m_calMode = CM_ATE_TEST;
	m_opMode = CTOM_ATE_READ;
	m_chanMask = chanMask;
	m_testCalOutput = desiredVoltage;
	m_CalOPUnits = MILLI;
	m_runtimeUpdated = TRUE;
	return retValue;
}
//**********************************************************************
///
/// Set the rig number
/// @param[in] rigNo - The rig number.
///
/// @return		TRUE if the rig number; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetRigNo(const UCHAR rigNo) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	m_rigNo = rigNo;
	if (pBrdInfo != NULL) {
		pBrdInfo->SetCurrentRigID(m_cardSlot, m_rigNo);
		m_runtimeUpdated = TRUE;
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// To create the cards serial number
/// @param[in] passState - Current test status.
///
/// @return		TRUE if the rest status could be set; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetTestStatus(const UCHAR passState) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		pBrdInfo->SetLastTestStatus(m_cardSlot, passState);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
/// DefaultChannel()
///
/// Sets the channel type & range in the locally held configuration.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		TRUE if the configuration is successful defaulted; otherwise FALSE
//**********************************************************************
BOOL CATECal::DefaultChannel(const USHORT ChanNo) {
	BOOL ConfigChanged = TRUE;
	// Change the current channel configuration
	m_cfgAI.CfgChan[ChanNo].DampLevel = 0.0F;
	m_cfgAI.CfgChan[ChanNo].InputLinearisation = FALSE;
	m_cfgAI.CfgChan[ChanNo].SqrtExtract = FALSE;
	return ConfigChanged;
}
//**********************************************************************
/// Checks user calibration points
///
/// @return - TRUE if the user calibration points are within limits; otherwise FALSE.
///
//**********************************************************************
bool CATECal::CheckUserCalibration() {
	bool retValue = true;
	UCHAR chanNo;
	UCHAR chanCount = 0; //coverity fix chanCount = 0 h350726 CID:778232
	UCHAR RangeRev;
	USHORT ChanType;
	USHORT RangeEnum;
	T_RANGE_COUNTS Intern0;
	T_RANGE_COUNTS Intern0V;
	T_RANGE_COUNTS Intern100;
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	const T_AICHANNELCAL *pAIChanCal = NULL;
	class CAIRanges *pAIRange = NULL;
	pAIRange = CAIRanges::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		chanCount = pBrdInfoObj->GetNoOfChannels(m_cardSlot);
	else
		//coverity fix h350726 CID:778232
		retValue = false;
	for (chanNo = 0; chanNo < chanCount; chanNo++) {
		if (GetAIChannelRange(chanNo, &ChanType, &RangeEnum) == TRUE) {
			pBrdInfoObj->GetBoardRangeRevision(m_cardSlot, &RangeRev);
			pAIRange->GetBaseInternValues(RangeEnum, RangeRev, &Intern0, &Intern0V, &Intern100);
		}
		// Check each channels cal data in turn
		pAIChanCal = GetAIChanCal(chanNo);
		if (pAIChanCal != NULL) {
			if (pAIChanCal->zeroCount >= pAIChanCal->spanCount) {
				// Reject this channel if selected and reverse voltages 
				// or no change is detected between span and zero calibration voltages
				retValue = false;
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// To create the cards serial number
/// @param[in] time - The number of seconds used to create the serial number.
///
/// @return		TRUE if the serial number could be set; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetTestDateTime(const LONG time) const {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		pBrdInfo->SetDateLastTested(m_cardSlot, time);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Get the rig number
///
/// @return		TRUE if the rig number; otherwise FALSE
//**********************************************************************
UCHAR CATECal::GetRigNo(void) {
	return m_rigNo;
}
//**********************************************************************
///
/// Set all I/O board channels into calibrate mode
///
/// @return		TRUE if the mode accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetToCalibrateMode(void) {
	BOOL retValue = TRUE;
	USHORT chanNo = 0;
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		// Set raw mode on
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			// Get the board type
			switch (pBrdInfo->WhatBoardType(m_cardSlot)) {
			case BOARD_AI:
			case BOARD_EZ_AI:
				m_cfgAI.CfgChan[chanNo].ChanCfgInfo.RawReadings = TRUE;
				break;
			case BOARD_AO:
				m_cfgAO.CfgChan[chanNo].ChanCfgInfo.RawReadings = TRUE;
				break;
			default:
				retValue = FALSE;
				break;
			};
		}
	} else
		retValue = FALSE;
	if (retValue == TRUE)
		m_setupUpdated = TRUE;
	return retValue;
}
//**********************************************************************
///
/// Set all I/O board channels into or out of calibrate mode
/// @param[in] chanNo - The card channel number.
/// @param[in] rawOn - TRUE if raw mode is on for channel; otherwise FALSE
///
/// @return		TRUE if the mode accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetRawReadingMode(const USHORT chanNo, const BOOL rawOn) {
	BOOL retValue = TRUE;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		// Get the board type
		switch (pBrdInfo->WhatBoardType(m_cardSlot)) {
		case BOARD_AI:
		case BOARD_EZ_AI:
			m_cfgAI.CfgChan[chanNo].ChanCfgInfo.RawReadings = rawOn;				// Set raw mode state
			break;
		case BOARD_AO:
			m_cfgAO.CfgChan[chanNo].ChanCfgInfo.RawReadings = rawOn;				// Set raw mode state
			break;
		default:
			retValue = FALSE;
			break;
		}
	} else {
		retValue = FALSE;
	}
	if (retValue == TRUE)
		m_setupUpdated = TRUE;
	return retValue;
}
//**********************************************************************
///
/// Enable all I/O board channels present on the card
///
/// @return		TRUE if the mode accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EnableAllCardChannels(void) {
	USHORT chanNo = 0;
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		// Get the board type
		switch (pBrdInfo->WhatBoardType(m_cardSlot)) {
		case BOARD_AI:
		case BOARD_EZ_AI:
			for (chanNo = 0; chanNo < HW_ANA_IN_CHAN_PER_BOARD; chanNo++) {
				// Enable all channels present on AI card, disable the rest
				if (chanNo < chanCount)
					m_cfgAI.CfgChan[chanNo].ChanCfgInfo.Enabled = TRUE;
				else
					m_cfgAI.CfgChan[chanNo].ChanCfgInfo.Enabled = FALSE;
			}
			break;
		case BOARD_AO:
			for (chanNo = 0; chanNo < HW_ANA_OUT_CHAN_PER_BOARD; chanNo++) {
				// Enable all channels present on card, disable the rest
				if (chanNo < chanCount)
					m_cfgAO.CfgChan[chanNo].ChanCfgInfo.Enabled = TRUE;
				else
					m_cfgAO.CfgChan[chanNo].ChanCfgInfo.Enabled = FALSE;
			}
			break;
		case BOARD_AR:
			for (chanNo = 0; chanNo < HW_DIG_IO_CHAN_PER_BOARD; chanNo++) {
				// Enable all channels present on card, disable the rest
				if (chanNo < chanCount)
					m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.Enabled = TRUE;
				else {
					//special requirement for a 4 channel AR card that channel 8 enabled as an input too
					if (chanNo == HW_INPUT_NO_4_CHAN_EXTA) {
						m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.Enabled =
						TRUE;
					} else {
						m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.Enabled =
						FALSE;
					}
				}
			}
			break;
		case BOARD_DIO:
			for (chanNo = 0; chanNo < HW_DIG_IO_CHAN_PER_BOARD; chanNo++) {
				// Enable all channels present on DIO card, disable the rest
				if (chanNo < chanCount)
					m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.Enabled = TRUE;
				else
					m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.Enabled = FALSE;
			}
			break;
		case BOARD_PI:
			for (chanNo = 0; chanNo < HW_PULSE_CHAN_PER_BOARD; chanNo++) {
				// Enable all channels present on pulse card, disable the rest
				if (chanNo < chanCount)
					m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.Enabled = TRUE;
				else
					m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.Enabled = FALSE;
			}
			break;
		}
	}
	m_setupUpdated = TRUE;
	return TRUE;
}
//**********************************************************************
///
/// Removes all I/O board channels from calibrate mode
///
/// @return		TRUE if the mode accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::RemoveCalibrateMode(void) {
	BOOL retValue = TRUE;
	USHORT chanNo = 0;
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	// Get the maximum channel count
	chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
	// Set raw mode off
	for (chanNo = 0; chanNo < chanCount; chanNo++) {
		// Get the board type
		switch (pBrdInfo->WhatBoardType(m_cardSlot)) {
		case BOARD_AI:
		case BOARD_EZ_AI:
			m_cfgAI.CfgChan[chanNo].ChanCfgInfo.RawReadings = FALSE;
			break;
		case BOARD_AO:
			m_cfgAO.CfgChan[chanNo].ChanCfgInfo.RawReadings = FALSE;
			break;
		default:
			retValue = FALSE;
			break;
		};
	}
	if (retValue == TRUE)
		m_setupUpdated = TRUE;
	return retValue;
}
//**********************************************************************
///
/// Store the AI channel readings
/// @param[in] chanMask - The mask of the channels to be read.
///
/// @note: Calibration is performed on current range selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::AIStoreRawChannels(const USHORT chanMask) {
	BOOL retValue = FALSE;
	USHORT chanNo = 0;
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		// Get the raw values from the relevant holder and save calibration value
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
				AIChanStoredRawReading[chanNo] = AIChanRawReading[chanNo];
			}
		}
	}
	m_runtimeUpdated = TRUE;
	// Download the calibration values to the AI board
	return retValue;
}
//**********************************************************************
///
/// Load an AI channel raw reading
/// @param[in] chanNo - The channel number being loaded.
/// @param[in] rawValue - The raw value to load to the channel.
///
/// @note: Calibration is performed on current range selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::AILoadRawChannel(const USHORT chanNo, const T_RANGE_COUNTS rawValue) {
	BOOL retValue = FALSE;
	USHORT chanCount = 0;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		// Get the raw values from the relevant holder and save calibration value
		if (chanNo < chanCount) {
			AIChanRawReading[chanNo] = rawValue;
			retValue = TRUE;
		}
	}
	m_runtimeUpdated = TRUE;
	// Download the calibration values to the AI board
	return retValue;
}
//**********************************************************************
///
/// Gets the channel calibration info.
///
/// @param[in] chanNo - Card slot channel number.
///
/// @return		An AO channels calibration data
//**********************************************************************
const T_AOCHANCAL* CATECal::GetAOChanCal(const UCHAR chanNo) const {
	if (chanNo < TOPSLOT_AOCHAN_SIZE)
		return &m_AOCalInfo[chanNo];
	return NULL;
}
//**********************************************************************
///
/// Gets the channel calibration info.
///
/// @param[in] chanNo - Card slot channel number.
/// @param[in] cal - Card slot channel calibration data.
///
/// @return		TRUE if the channel calibration data can be set; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetAOChanCal(const UCHAR chanNo, const T_AOCHANCAL cal) {
	BOOL retValue = FALSE;
	if (chanNo < TOPSLOT_AOCHAN_SIZE) {
		m_AOCalInfo[chanNo].Offset = cal.Offset;
		m_AOCalInfo[chanNo].RawCount20mA = cal.RawCount20mA;
		retValue = TRUE;
	}
	return retValue;
}
const USHORT ATE_RT_CURRENT_ACTUAL = 25008;	/// The voltage in microvolts which would be returned by the DVM 
/// if exactly 0.25mA was flowing. Was 25000 when the 100R +/- 0.01% resistor
/// was assumed to be perfect, but now allows for 100.03 ohms nominal 
/// due to testbox wiring (for mini/multi test box)
const USHORT ATE_RT_CURRENT_IDEAL = 25000;	/// The voltage in microvolts which would be returned by the DVM 
/// if exactly 0.25mA was flowing.
//**********************************************************************
///
/// Issue the command to factory calibrate the AI RT cal for each channel
/// @param[in] chanMask - The mask of the channels to be read.
///
/// @note: Calibration is performed on current working configuration selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::AIFactoryCalRTCalPoints(const USHORT chanMask) {
	BOOL retValue = TRUE;
	USHORT chanNo = 0;
	USHORT chanCount = 0;
	USHORT modCount = 0;
	float factor = 0.0F;
	float RTCurrent = 0.0F;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		if (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI)
			RTCurrent = static_cast<float>(ATE_RT_CURRENT_ACTUAL);
		else
			RTCurrent = static_cast<float>(ATE_RT_CURRENT_IDEAL);
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		// Get the raw values from the relevant holder and calculate the calibration value
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
				// Get the microvolts measured by the DVM and calculate the offset from the ideal
				factor = (static_cast<float>(m_AICal.rtCalInfo[chanNo])) / RTCurrent;
				// Check that m_AICal.rtCalInfo[chanNo] is not zero
				if (factor != 0.0) {
					modCount = static_cast<USHORT>(static_cast<float>(m_AICal.calInfo[chanNo].spanCount -=
							m_AICal.calInfo[chanNo].zeroCount) / factor);
					m_AICal.calInfo[chanNo].spanCount = modCount + m_AICal.calInfo[chanNo].zeroCount;
					m_AICal.calDownload[chanNo].spanCount = m_AICal.calInfo[chanNo].spanCount;
					m_AICal.calDownload[chanNo].zeroCount = m_AICal.calInfo[chanNo].zeroCount;
					swab(reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].spanCount),
							reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].spanCount), sizeof(USHORT));
					swab(reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount),
							reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount), sizeof(USHORT));
				} else {
					retValue = FALSE;
				}
			}
		}
	} else {
		retValue = FALSE;
	}
	m_runtimeUpdated = TRUE;
	return retValue;
}
//**********************************************************************
///
/// Calculate the RT channel zero value from the span
/// @param[in] chanMask - The mask of the channels to be read.
///
/// @note: Calibration is performed on current range selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CalculateRTChanZero(const USHORT chanMask) {
	BOOL retValue = TRUE;
	USHORT chanNo = 0;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
			for (chanNo = 0; chanNo < pBrdInfo->GetNoOfChannels(m_cardSlot); chanNo++) {
				if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
					// Calculation is required for this channel
					if (m_AICal.calInfo[chanNo].spanCount > RAW_VALUES_MID_POINT) {
						m_AICal.calInfo[chanNo].zeroCount = RAW_VALUES_MID_POINT
								- (m_AICal.calInfo[chanNo].spanCount - RAW_VALUES_MID_POINT);
						m_AICal.calDownload[chanNo].zeroCount = m_AICal.calInfo[chanNo].zeroCount;
						swab(reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount),
								reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount), sizeof(USHORT));
					}
				}
			}
		}
	} else {
		retValue = FALSE;
	}
	return retValue;
}
//**********************************************************************
///
/// Calculate the RT channel zero value from the span
///
/// @note: Calibration is performed on current range selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CalculateRTCalChanZero(void) {
	return CalculateRTChanZero(m_RTIChanReadMask);
}
//**********************************************************************
///
/// Issue the command to factory calibrate the AI channels
/// @param[in] chanMask - The mask of the channels to be read.
/// @param[in] spanSet - TRUE if this is the span setting otherwise FALSE
///						 for Zero (low range) setting
/// @param[in] poffset - Array with offsets provided (not currently used).
///
/// @note: Calibration is performed on current range selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::AIStoreChannelCalPoints(const USHORT chanMask, const BOOL spanSet, const float *poffset) {
	BOOL retValue = FALSE;
	USHORT chanNo = 0;
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		// Get the raw values from the relevant holder and save calibration value
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
				// Value is required from this channel
				qDebug("Value caled chan %d, 0x%X\n", chanNo, AIChanRawReading[chanNo]);
				if (poffset != NULL) {
					qDebug("Offset Value chan %d, 0x%X\n", chanNo, *(poffset + chanNo));
				}
				if (spanSet == TRUE) {
					// Span value being set
					m_AICal.calInfo[chanNo].spanCount = AIChanRawReading[chanNo];
					if (poffset != NULL) {
						m_AICal.calInfo[chanNo].spanCount = m_AICal.calInfo[chanNo].spanCount
								- static_cast<USHORT>(*(poffset + chanNo));
					}
					qDebug("Offset Value caled chan %d, 0x%X\n", chanNo, m_AICal.calInfo[chanNo].spanCount);
					m_AICal.calDownload[chanNo].spanCount = m_AICal.calInfo[chanNo].spanCount;
					swab(reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].spanCount),
							reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].spanCount), sizeof(USHORT));
					retValue = TRUE;
				} else {
					// Zero value being set
					m_AICal.calInfo[chanNo].zeroCount = AIChanRawReading[chanNo];
					if (poffset != NULL) {
						m_AICal.calInfo[chanNo].zeroCount = m_AICal.calInfo[chanNo].zeroCount
								- static_cast<USHORT>(*(poffset + chanNo));
					}
					qDebug("Offset Value caled chan %d, 0x%X\n", chanNo, m_AICal.calInfo[chanNo].zeroCount);
					m_AICal.calDownload[chanNo].zeroCount = m_AICal.calInfo[chanNo].zeroCount;
					swab(reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount),
							reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount), sizeof(USHORT));
					retValue = TRUE;
				}
			}
		}
	}
	m_runtimeUpdated = TRUE;
	// Download the calibration values to the AI board
	return retValue;
}
//**********************************************************************
///
/// Store the cal points into relevant data holders
/// @param[in] chanMask - The mask of the channels to be read.
/// @param[in] spanSet - TRUE if this is the span setting otherwise FALSE
///						 for Zero (low range) setting
/// @param[in] container - Container reference number.
/// @param[in] poffset - Array with offsets provided (not currently used).
///
/// @note: Calibration is performed on current range selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAIStoreChannelCalPoints(const USHORT chanMask, const BOOL spanSet, const UCHAR container,
		const float *poffset) {
	BOOL retValue = FALSE;
	USHORT chanNo = 0;
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		// Get the raw values from the relevant holder and save calibration value
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
				// Value is required from this channel
				if (poffset != NULL) {
					qDebug("Offset Value chan %d, 0x%X\n", chanNo, *(poffset + chanNo));
				}
				if (spanSet == TRUE) {
					// Span value being set
					m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount = AIChanRawReading[chanNo];
					if (poffset != NULL) {
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount =
								m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount
										- static_cast<USHORT>(*(poffset + chanNo));
					}
					qDebug("span value caled chan %d, 0x%X\n", chanNo,
							m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount);
					retValue = TRUE;
				} else {
					// Zero value being set
					m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount = AIChanRawReading[chanNo];
					if (poffset != NULL) {
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount =
								m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount
										- static_cast<USHORT>(*(poffset + chanNo));
					}
					qDebug("zero value caled chan %d, 0x%X\n", chanNo,
							m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount);
					retValue = TRUE;
				}
			}
		}
	}
	m_runtimeUpdated = TRUE;
	// Download the calibration values to the AI board
	return retValue;
}
//**********************************************************************
///
/// Calculate the cal points for an eZtrend, using the relevant data holders
/// @param[in] chanNo - The board channel number being tested.
/// @param[in] spanSet - TRUE if this is the span setting otherwise FALSE
///						 for Zero (low range) setting
/// @param[in] container - The container number being tested.
/// @param[in] upper - The upper limit to test to.
/// @param[in] lower - The lower limit to test to.
/// @param[out] pValue - The failing value.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAICheckCalPoints(const USHORT chanNo, const BOOL spanSet, const UCHAR container,
		const T_RANGE_COUNTS upper, const T_RANGE_COUNTS lower, T_RANGE_COUNTS *pValue) {
	BOOL retValue = TRUE;
	if ( TRUE == spanSet) {
		if ((m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount > upper)
				|| (m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount < lower)) {
			*pValue = m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount;
			retValue = FALSE;
		}
	} else {
		if ((m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount > upper)
				|| (m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount < lower)) {
			*pValue = m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount;
			retValue = FALSE;
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Calculate the cal points for an eZtrend, using the relevant data holders
/// @param[in] chanNo - The board channel number being tested.
/// @param[in] spanSet - TRUE if this is the span setting otherwise FALSE
///						 for Zero (low range) setting
/// @param[in] checkContainer - The container number being tested.
/// @param[in] refContainer - The container number to test the checkContainer contents against.
/// @param[in] upper - The upper limit to test to.
/// @param[in] lower - The lower limit to test to.
/// @param[out] pValue - The failing value.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAICheckRelativeCalPoints(const USHORT chanNo, const BOOL spanSet, const UCHAR checkContainer,
		const UCHAR refContainer, const T_RANGE_COUNTS upper, const T_RANGE_COUNTS lower, T_RANGE_COUNTS *pValue) {
	BOOL retValue = TRUE;
	if ( TRUE == spanSet) {
		if ((m_AICal.eZRTCalInfo[chanNo].ezChanCal[refContainer].spanCount
				> m_AICal.eZRTCalInfo[chanNo].ezChanCal[checkContainer].spanCount + upper)
				|| (m_AICal.eZRTCalInfo[chanNo].ezChanCal[refContainer].spanCount
						< m_AICal.eZRTCalInfo[chanNo].ezChanCal[checkContainer].spanCount - lower)) {
			*pValue = m_AICal.eZRTCalInfo[chanNo].ezChanCal[checkContainer].spanCount;
			retValue = FALSE;
		}
	} else {
		if ((m_AICal.eZRTCalInfo[chanNo].ezChanCal[refContainer].zeroCount
				> m_AICal.eZRTCalInfo[chanNo].ezChanCal[checkContainer].zeroCount + upper)
				|| (m_AICal.eZRTCalInfo[chanNo].ezChanCal[refContainer].zeroCount
						< m_AICal.eZRTCalInfo[chanNo].ezChanCal[checkContainer].zeroCount - lower)) {
			*pValue = m_AICal.eZRTCalInfo[chanNo].ezChanCal[checkContainer].zeroCount;
			retValue = FALSE;
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Rescale the given container cal points for an eZtrend
/// @param[in] chanNo - The board channel number being tested.
/// @param[in] srcContainer - The source container number being copied.
/// @param[in] destContainer - The destination container number to be copied to.
/// @param[in] spanSet - TRUE if this is the span setting otherwise FALSE
///						 for Zero (low range) setting
///
/// @return		TRUE if the container is copied; otherwise FALSE
//**********************************************************************
BOOL CATECal::CopyAIHolders(const USHORT chanNo, const UCHAR srcContainer, const UCHAR destContainer,
		const BOOL spanSet) {
	BOOL retValue = TRUE;
	if ( TRUE == spanSet) {
		m_AICal.eZRTCalInfo[chanNo].ezChanCal[destContainer].spanCount =
				m_AICal.eZRTCalInfo[chanNo].ezChanCal[srcContainer].spanCount;
	} else {
		m_AICal.eZRTCalInfo[chanNo].ezChanCal[destContainer].zeroCount =
				m_AICal.eZRTCalInfo[chanNo].ezChanCal[srcContainer].zeroCount;
	}
	return retValue;
}
//**********************************************************************
///
/// Rescale the given container cal points for an eZtrend
/// @param[in] chanNo - The board channel number being tested.
/// @param[in] spanSet - TRUE if this is the span setting otherwise FALSE
///						 for Zero (low range) setting
/// @param[in] container - The container number being rescaled.
/// @param[in] scaleFactor - The scale factor to use.
///
//**********************************************************************
void CATECal::EzAIReScaleCalPoints(const USHORT chanNo, const BOOL spanSet, const UCHAR container,
		const float scaleFactor) {
	if ( TRUE == spanSet) {
		m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount =
				static_cast<USHORT>(((m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].spanCount
						- m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount) * scaleFactor)
						+ m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount);
	} else {
		m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount =
				static_cast<USHORT>(((m_AICal.eZRTCalInfo[chanNo].ezChanCal[container].zeroCount
						- m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount) * scaleFactor)
						+ m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount);
	}
}
//**********************************************************************
///
/// Calculate the cal mid-points for an eZtrend, using the relevant data holders
/// @param[in] bank - Either bank 1 or bank 2.
///
/// @return		TRUE if the bank exists and is calculated; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAICalculateBankAverages(const T_EZ_BANK_ID bank) {
	USHORT chanNo = BANK_1_START_CHANNEL;
	USHORT startChanNo = BANK_1_START_CHANNEL;
	USHORT chanCount;
	USHORT holderRefNo = 0;
	class CBrdInfo *pBrdInfo = NULL;
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		if (bank == BANK_2_ID) {
			startChanNo = BANK_2_START_CHANNEL;
			if (chanCount < BANK_2_END_CHANNEL)
				retValue = FALSE;		// If bank 2 requested then fail if there are not at least 6 channels
		}
		m_AICal.RTBankFactor[bank] = 0.0F;
		if (retValue == TRUE) {
			// Zero all average holders
			for (holderRefNo = 0; holderRefNo < MAX_EZ_RT_CAL_REFS; holderRefNo++) {
				m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].spanCount = 0;
				m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].zeroCount = 0;
			}
			for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
				// Sum the bank channels
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].zeroCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_25MV_STORE].zeroCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_25MV_STORE].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_RT_CURR].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_RT_CURR].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_RT_CURR].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_RT_CURR].spanCount;
			}
			// Calculate the +25mV A3A4 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].zeroCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].zeroCount / NO_OF_CHANS_IN_BANK;
			// Calculate the -25mV A3A4 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate the +25mV A7A8 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount / NO_OF_CHANS_IN_BANK;
			// Calculate the -25mV A7A8 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate average raw count with no current flow on Pair A1A2 for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate average raw count with current flow on Pair A1A2 for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_RT_CURR].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_RT_CURR].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate average raw count with current flow on Pair A3A4 for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_RT_CURR].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_RT_CURR].spanCount / NO_OF_CHANS_IN_BANK;
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Sometimes there is on duff channel read (probably due to the CJC read)
/// therefore this channel must be identified and removed from the calibration
/// information or calibration will be messed up for channel/bank
/// @param[in] bank - Either bank 1 or bank 2.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAIHWRemoveDuffBankChannel(const T_EZ_BANK_ID bank) {
	USHORT chanNo = BANK_1_START_CHANNEL;
	USHORT startChanNo = BANK_1_START_CHANNEL;
	USHORT chanCount;
	USHORT holderRefNo = 0;
	class CBrdInfo *pBrdInfo = NULL;
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		if (BANK_2_ID == bank) {
			startChanNo = BANK_2_START_CHANNEL;
			if (chanCount < BANK_2_END_CHANNEL)
				retValue = FALSE;		// If bank 2 requested then fail if there are not at least 6 channels
		}
		if ( TRUE == retValue) {
			// Zero all average holders
			for (holderRefNo = 0; holderRefNo < MAX_EZ_RT_CAL_REFS; holderRefNo++) {
				m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].spanCount = 0;
				m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].zeroCount = 0;
			}
			for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
				// Sum the bank channels
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].zeroCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_25MV_STORE].zeroCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_25MV_STORE].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_RT_CURR].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_RT_CURR].spanCount;
				m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_RT_CURR].spanCount +=
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_RT_CURR].spanCount;
			}
			// Calculate the +25mV A3A4 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].zeroCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].zeroCount / NO_OF_CHANS_IN_BANK;
			// Calculate the -25mV A3A4 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate the +25mV A7A8 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount / NO_OF_CHANS_IN_BANK;
			// Calculate the -25mV A7A8 averages of the counts for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate average raw count with no current flow on Pair A1A2 for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate average raw count with current flow on Pair A1A2 for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_RT_CURR].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_RT_CURR].spanCount / NO_OF_CHANS_IN_BANK;
			// Calculate average raw count with current flow on Pair A3A4 for each bank and save
			m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_RT_CURR].spanCount =
					m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_RT_CURR].spanCount / NO_OF_CHANS_IN_BANK;
			float maxSpanDiff;
			float currSpanDiff;
			USHORT failSpanChanNo;
			float maxZeroDiff;
			float currZeroDiff;
			USHORT failZeroChanNo;
			// Now look for the channel that is furtherest away from the average and replace with the average
			for (holderRefNo = 0; holderRefNo < MAX_EZ_RT_CAL_REFS; holderRefNo++) {
				// Reset the running zero total
				maxZeroDiff = 0.0F;
				currZeroDiff = 0.0F;
				failZeroChanNo = startChanNo;
				// Reset the running span total
				maxSpanDiff = 0.0F;
				currSpanDiff = 0.0F;
				failSpanChanNo = startChanNo;
				for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
					// Only the span is used for most containers
					if ((EZ_A7_A8_25MV_INVERTED_STORE == holderRefNo) || (EZ_A3_A4_25MV_STORE == holderRefNo)) {
						currZeroDiff = fabs(
								m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].zeroCount
										- m_AICal.eZRTCalInfo[chanNo].ezChanCal[holderRefNo].zeroCount);
						// Save the largest deviation, from the norm and the channel with the largest deviation
						if (currZeroDiff > maxZeroDiff) {
							maxZeroDiff = currZeroDiff;
							failZeroChanNo = chanNo;
						}
					}
					currSpanDiff = fabs(
							m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].spanCount
									- m_AICal.eZRTCalInfo[chanNo].ezChanCal[holderRefNo].spanCount);
					// Save the largest deviation, from the norm and the channel with the largest deviation
					if (currSpanDiff > maxSpanDiff) {
						maxSpanDiff = currSpanDiff;
						failSpanChanNo = chanNo;
					}
				}
				qDebug("Worst span chan %d: holder %d = %f; sub %d with %d\n", failSpanChanNo, holderRefNo, maxSpanDiff,
						m_AICal.eZRTCalInfo[failSpanChanNo].ezChanCal[holderRefNo].spanCount,
						static_cast<USHORT>(m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].spanCount));
				m_AICal.eZRTCalInfo[failSpanChanNo].ezChanCal[holderRefNo].spanCount =
						static_cast<USHORT>(m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].spanCount);
				if ((EZ_A7_A8_25MV_INVERTED_STORE == holderRefNo) || (EZ_A3_A4_25MV_STORE == holderRefNo)) {
					qDebug("Worst zero chan %d: holder %d = %f; sub %d with %d\n", failZeroChanNo, holderRefNo,
							maxZeroDiff, m_AICal.eZRTCalInfo[failSpanChanNo].ezChanCal[holderRefNo].zeroCount,
							static_cast<USHORT>(m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].zeroCount));
					m_AICal.eZRTCalInfo[failZeroChanNo].ezChanCal[holderRefNo].zeroCount =
							static_cast<USHORT>(m_AICal.bankAveCal[bank].ezBankCal[holderRefNo].zeroCount);
				}
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Calculate the cal points for a given channel bank for an eZtrend, using the average data holders
/// @param[in] bank - Either bank 1 or bank 2.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAICalculateBankCalPoints(const T_EZ_BANK_ID bank) {
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	BOOL retValue = TRUE;
	m_AICal.RTBankFactor[bank] = 0.0F;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		if (BANK_2_ID == bank) {
			if (chanCount < BANK_2_END_CHANNEL)
				retValue = FALSE;		// If bank 2 requested then fail if there are not at least 6 channels
		}
		if ( TRUE == retValue) {
			// Calculate the cal mid-point for the given bank
			m_AICal.calBankmidPoint[bank] = ((m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].zeroCount
					+ m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount) / 2)
					- RAW_VALUES_MID_POINT_FLOAT;
			// Calculate the RT factor for the given bank
			m_AICal.RTBankFactor[bank] =
					static_cast<float>(m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_RT_CURR].spanCount
							- RAW_VALUES_MID_POINT_FLOAT - m_AICal.calBankmidPoint[bank])
							/ static_cast<float>(m_AICal.bankAveCal[bank].ezBankCal[EZ_A3_A4_25MV_STORE].spanCount
									- RAW_VALUES_MID_POINT_FLOAT - m_AICal.calBankmidPoint[bank]);
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Calculate the cal points for a given channel bank for an eZtrend, using the relevant data holders
/// @param[in] bank - Either bank 1 or bank 2.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAICalculateBankChanCalPoints(const T_EZ_BANK_ID bank) {
	USHORT chanCount;
	USHORT chanNo = 0;
	USHORT startChanNo = BANK_1_START_CHANNEL;
	USHORT endChanNo = BANK_1_START_CHANNEL + NO_OF_CHANS_IN_BANK;
	class CBrdInfo *pBrdInfo = NULL;
	QString csCalInfo = "";
	BOOL retValue = TRUE;
	m_AICal.RTBankFactor[bank] = 0.0F;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		if (BANK_2_ID == bank) {
			startChanNo = BANK_2_START_CHANNEL;
			endChanNo = BANK_2_END_CHANNEL;
			if (chanCount < BANK_2_END_CHANNEL)
				retValue = FALSE;		// If bank 2 requested then fail if there are not at least 6 channels
		}
		if (retValue == TRUE) {
			for (chanNo = startChanNo; chanNo < endChanNo; chanNo++) {
				// Calculate the cal mid-point for the given bank
				m_AICal.calmidPointA3A4[chanNo] = ((m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_25MV_STORE].zeroCount
						+ m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_25MV_STORE].spanCount) / 2)
						- RAW_VALUES_MID_POINT_FLOAT;
				csCalInfo = QString::asprintf("mid point A3A4 chan %d: = %f", chanNo + 1,
						m_AICal.calmidPointA3A4[chanNo]);
				AddString(csCalInfo);
				WriteErrorFileString(csCalInfo);
				// Calculate the cal mid-point for the given bank
				m_AICal.calmidPointA7A8[chanNo] =
						((m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount
								+ m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount) / 2)
								- RAW_VALUES_MID_POINT_FLOAT;
				csCalInfo = QString::asprintf("mid point A7A8 chan %d: = %f", chanNo + 1,
						m_AICal.calmidPointA7A8[chanNo]);
				AddString(csCalInfo);
				WriteErrorFileString(csCalInfo);
				// Calculate the RT factor for the given bank
				m_AICal.RTFactor[chanNo] =
						static_cast<float>((m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_RT_CURR].spanCount
								* EZ_A3_A4_RT_CURR_RESCALE_FACTOR) - RAW_VALUES_MID_POINT_FLOAT
								- (m_AICal.calmidPointA3A4[chanNo] / 2))
								/ static_cast<float>(m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A3_A4_25MV_STORE].spanCount
										- RAW_VALUES_MID_POINT_FLOAT - m_AICal.calmidPointA3A4[chanNo]);
				// Adjust the RT factor to compensate for test box resistance (unproven)
				m_AICal.RTFactor[chanNo] = m_AICal.RTFactor[chanNo] * EZ_RT_TEST_BOX_CORRECTION;
				csCalInfo = QString::asprintf("RT factor chan %d: = %f", chanNo + 1, m_AICal.RTFactor[chanNo]);
				AddString(csCalInfo);
				WriteErrorFileString(csCalInfo);
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Calculate the calibration upload points for a given channel bank for an eZtrend,
/// using the average bank data holders
/// @param[in] bank - Either bank 1 or bank 2.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAICalculateBankCalUploadPoints(const T_EZ_BANK_ID bank) {
	USHORT startChanNo = BANK_1_START_CHANNEL;
	USHORT chanNo = BANK_1_START_CHANNEL;
	USHORT chanCount = 0;
	USHORT chanMask = 0;
	class CBrdInfo *pBrdInfo = NULL;
	USHORT bankRTCal[NO_OF_BANKS];
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		chanMask = GetChannelSelectionMask();
		if (BANK_2_ID == bank) {
			startChanNo = BANK_2_START_CHANNEL;
			if (chanCount < BANK_2_END_CHANNEL)
				retValue = FALSE;		// If bank 2 requested then fail if there are not at least 6 channels
		}
		if ( TRUE == retValue) {
			// Calculate and save the RTCal span value for card calibration of each bank
			bankRTCal[bank] =
					static_cast<USHORT>((static_cast<float>(m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_RT_CURR].spanCount
							- m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount)
							/ m_AICal.RTBankFactor[bank])
							+ m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount);
			// Save the calculated RTCal span value for card calibration of each bank
			for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
				m_AICal.savedEzRTCalInfo[chanNo].spanCount = bankRTCal[bank];
			}
			// Save the RTCal zero value for card calibration of each bank
			for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
				m_AICal.savedEzRTCalInfo[chanNo].zeroCount =
						static_cast<USHORT>(m_AICal.bankAveCal[bank].ezBankCal[EZ_A1_A2_NULL_STORE].spanCount);
			}
			// Save the RT span value for card calibration of each bank
			for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
				m_AICal.savedEzRTInfo[chanNo].spanCount =
						static_cast<USHORT>(m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount);
			}
			// Save the RT zero value for card calibration of each bank
			for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
				m_AICal.savedEzRTInfo[chanNo].zeroCount =
						static_cast<USHORT>(m_AICal.bankAveCal[bank].ezBankCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount);
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Calculate the calibration upload points for a given channel bank for an eZtrend,
/// @param[in] bank - Either bank 1 or bank 2.
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzAICalculateBankChanCalUploadPoints(const T_EZ_BANK_ID bank) {
	USHORT startChanNo = BANK_1_START_CHANNEL;
	USHORT chanNo = BANK_1_START_CHANNEL;
	USHORT chanCount = 0;
	USHORT chanMask = 0;
	class CBrdInfo *pBrdInfo = NULL;
	USHORT RTChanCal[TOPSLOT_AICHAN_SIZE];
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		chanMask = GetChannelSelectionMask();
		if (bank == BANK_2_ID) {
			startChanNo = BANK_2_START_CHANNEL;
			if (chanCount < BANK_2_END_CHANNEL)
				retValue = FALSE;		// If bank 2 requested then fail if there are not at least 6 channels
		}
		if (retValue == TRUE) {
			for (chanNo = startChanNo; chanNo < startChanNo + NO_OF_CHANS_IN_BANK; chanNo++) {
				// Calculate and save the RTCal span value for card calibration of each bank
				RTChanCal[chanNo] =
						static_cast<USHORT>((static_cast<float>(m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_RT_CURR].spanCount
								- m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount)
								/ m_AICal.RTFactor[chanNo])
								+ m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount);
				qDebug("ezChanCal[EZ_A1_A2_RT_CURR].spanCount chan %d = %d\n", chanNo,
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_RT_CURR].spanCount);
				qDebug("ezChanCal[EZ_A1_A2_NULL_STORE].spanCount chan %d = %d\n", chanNo,
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount);
				qDebug("m_AICal.RTFactor chan %d = %f\n", chanNo, m_AICal.RTFactor[chanNo]);
				qDebug("RTChanCal chan %d = %d\n", chanNo, RTChanCal[chanNo]);
				// Save the calculated RTCal span value for card calibration of each channel
				m_AICal.savedEzRTCalInfo[chanNo].spanCount = RTChanCal[chanNo];
				// Save the RTCal zero value for card calibration of each bank
				m_AICal.savedEzRTCalInfo[chanNo].zeroCount =
						m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A1_A2_NULL_STORE].spanCount;
				// Save the RT span value for card calibration of each bank
				m_AICal.savedEzRTInfo[chanNo].spanCount =
						static_cast<USHORT>(m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].spanCount
								- (m_AICal.calmidPointA7A8[chanNo] / 2));
				// Save the RT zero value for card calibration of each bank
				m_AICal.savedEzRTInfo[chanNo].zeroCount =
						static_cast<USHORT>(m_AICal.eZRTCalInfo[chanNo].ezChanCal[EZ_A7_A8_25MV_INVERTED_STORE].zeroCount
								- (m_AICal.calmidPointA7A8[chanNo] / 2));
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Upload the ez RT calibration points
///
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::EzUploadAICalPoints(void) {
	class CBrdInfo *pBrdInfo = NULL;
	USHORT chanNo = BANK_1_START_CHANNEL;
	USHORT chanCount = 0;
	USHORT chanMask = 0;
	BOOL loadChanSuccess = FALSE;
	BOOL bFail = FALSE;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		chanMask = GetChannelSelectionMask();
		// set each channel to calibrate RT Cal
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			SetAIAuxDirectRead(chanNo, DRM_READ_EZ_INPUT_RTCAL, TRUE);
		}
		NotifyCalOrSetupChange();
		sleep(3500);
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			loadChanSuccess = AISaveCalcDownload(chanNo, m_AICal.savedEzRTCalInfo[chanNo].spanCount,
					m_AICal.savedEzRTCalInfo[chanNo].zeroCount);
			if (loadChanSuccess == FALSE)
				bFail = TRUE;
		}
		// Download the RTCal calibration points to A1A2 at Gain32
		// -------------------------------------------------------
		if ( FALSE == bFail) {
			SetCalModeState(CTOM_ATE_CAL_COMMIT_SET_RT_POINTS);
			NotifyCalOrSetupChange();
			sleep(2500);
		}
		// Return to normal mode
		SetCalModeState(CTOM_ATE_READ);
		// set each channel to calibrate RT
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			SetAIAuxDirectRead(chanNo, DRM_READ_EZ_INPUT_RTCOMP, TRUE);
		}
		NotifyCalOrSetupChange();
		sleep(3500);
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			loadChanSuccess = AISaveCalcDownload(chanNo, m_AICal.savedEzRTInfo[chanNo].spanCount,
					m_AICal.savedEzRTInfo[chanNo].zeroCount);
			if (loadChanSuccess == FALSE)
				bFail = TRUE;
		}
		// Download the RT calibration points to A7A8 at Gain32
		// ----------------------------------------------------
		if ( FALSE == bFail) {
			SetCalModeState(CTOM_ATE_CAL_COMMIT_SET_RT_POINTS);
			NotifyCalOrSetupChange();
			sleep(2500);
		}
		// Return to normal mode
		SetCalModeState(CTOM_ATE_READ);
	}
	return !bFail;
}
//**********************************************************************
///
/// Issue the command to factory calibrate the AI RT channels
/// @param[in] spanSet - TRUE if this is the span setting otherwise FALSE
///						 for Zero (low range) setting
///
/// @note: Calibration is performed on current range selected
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::AIFactoryCalRTChannels(const BOOL spanSet, const float *poffset) {
	return AIStoreChannelCalPoints(m_RTIChanReadMask, spanSet, poffset);
}
//**********************************************************************
///
/// Save the calculated values to the relevant download structure
/// @param[in] chanNo - The mask of the channels to be read.
/// @param[in] calcSpanSet - The calculated span value to set
/// @param[in] calcSpanSet - The calculated span value to set
///
/// @return		TRUE if the calculated values saved; otherwise FALSE
//**********************************************************************
BOOL CATECal::AISaveCalcDownload(const USHORT chanNo, const T_RANGE_COUNTS calcSpanSet,
		const T_RANGE_COUNTS calcZeroSet) {
	BOOL retValue = FALSE;
	USHORT chanCount;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		// Get the maximum channel count
		chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
		m_AICal.calInfo[chanNo].spanCount = calcSpanSet;
		m_AICal.calDownload[chanNo].spanCount = m_AICal.calInfo[chanNo].spanCount;
		swab(reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].spanCount),
				reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].spanCount), sizeof(USHORT));
		m_AICal.calInfo[chanNo].zeroCount = calcZeroSet;
		m_AICal.calDownload[chanNo].zeroCount = m_AICal.calInfo[chanNo].zeroCount;
		swab(reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount),
				reinterpret_cast<char*>(&m_AICal.calDownload[chanNo].zeroCount), sizeof(USHORT));
		m_runtimeUpdated = TRUE;
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Issue the command to factory calibrate AO or AI channels
/// @param[in] chanMask - The mask of the channels to be read.
///
/// @note: Calibration is performed on current range selected,
/// using the saved calpoints
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CommitFactoryCalRange(const USHORT chanMask) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)
			|| (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AO)) {
		SetCalMode(CM_ATE_FACTORY_CAL);
		m_chanMask = chanMask;
		// Download the calibration values to the AI board
		SetCalModeState(CTOM_ATE_CAL_COMMIT_SET_POINTS);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Issue the command to factory calibrate RT chan for given AI channels
/// @param[in] chanMask - The mask of the channels to be read.
///
/// @note: Calibration is performed on current range selected,
/// using the saved calpoints
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CommitFactoryRTChanCalRange(const USHORT chanMask) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		SetCalMode(CM_ATE_FACTORY_RT_CHAN_CAL);
		m_chanMask = chanMask;
		// Download the calibration values to the AI board
		SetCalModeState(CTOM_ATE_CAL_COMMIT_SET_POINTS);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Issue the command to user calibrate the AI channels
/// @param[in] chanMask - The mask of the channels to be read.
///
/// @note: Calibration is performed on current range selected,
/// using the saved calpoints
/// @return		TRUE if the relevant voltage accepted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CommitUserCalRange(const USHORT chanMask) {
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfo = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		SetCalMode(CM_ATE_USER_CAL);
		m_chanMask = chanMask;
		// Download the calibration values to the AI board
		SetCalModeState(CTOM_ATE_CAL_COMMIT_SET_POINTS);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Sets the calibration mode state
/// @param[in] calMode - The current calibration mode being set.
///
/// @return		TRUE if the mode is set; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetCalModeState(const T_CAL_TEST_OP_MODE calMode) {
	class CConfig *pConfig = NULL;
	class CIOConfigManager *pConfigManager = NULL;
	BOOL retValue = FALSE;
	m_opMode = calMode;
	pConfigManager = CIOConfigManager::GetHandle();
	if (pConfigManager != NULL) {
		pConfig = pConfigManager->GetCommonLocalConfig(static_cast<UCHAR>(m_cardSlot));
		retValue = TRUE;
	}
	// Set the scheduler to ignore readings only if mode == CTOM_ATE_CAL_COMMIT_SET_POINTS
	if (CTOM_ATE_CAL_COMMIT_SET_POINTS == calMode) {
//		pConfig->SetAcquireModeActiveState( FALSE );
	} else {
//		pConfig->SetAcquireModeActiveState( TRUE );
	}
	return retValue;
}
//**********************************************************************
///
/// Sets the calibration mode
/// @param[in] calMode - The current calibration mode being set.
///
/// @return		TRUE if the mode is set; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetCalMode(const T_CAL_MODE calMode) {
	m_calMode = calMode;
	m_runtimeUpdated = TRUE;
	return TRUE;
}
//**********************************************************************
///
/// Gets the calibration mode
///
/// @return		The current calibration mode set
//**********************************************************************
T_CAL_MODE CATECal::GetCalMode(void) const {
	return m_calMode;
}
//**********************************************************************
///
/// Queries the output updated state
///
/// @return		TRUE if the output has been updated since the last I/O card update; otherwise FALSE
//**********************************************************************
BOOL CATECal::IsOutputUpdated(void) const {
	return m_OPUpdated;
}
//**********************************************************************
///
/// Sets whether the board output has been updated
/// @param[in] state - If TRUE state is set (active); otherwise inactive.
///
/// @return		TRUE if the output has been updated; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetOutputUpdated(const BOOL state) {
	m_OPUpdated = state;
	return m_OPUpdated;
}
//**********************************************************************
///
/// Queries whether the board setup has been updated
///
/// @return		TRUE if the setup has been updated; otherwise FALSE
//**********************************************************************
BOOL CATECal::IsSetupUpdated(void) const {
	return m_setupUpdated;
}
//**********************************************************************
///
/// Queries whether the board setup has been updated
///
/// @return		TRUE if the setup has been updated; otherwise FALSE
//**********************************************************************
BOOL CATECal::IsSetupDownloadable(void) const {
	return m_ComitSetup;
}
//**********************************************************************
///
/// Sets whether the board setup has been updated, and needs to be downloaded
/// @param[in] state - If TRUE state is set and needs to be downloaded (active); otherwise inactive.
///
/// @return		TRUE if the setup has been updated; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetCommitMode(const BOOL state) {
	m_ComitSetup = state;
	return m_ComitSetup;
}
//**********************************************************************
///
/// Queries whether the runtime information in the ATECal structure has been updated
///
/// @return		TRUE if the run-time info has been updated; otherwise FALSE
//**********************************************************************
BOOL CATECal::IsRuntimeUpdated(void) const {
	return m_runtimeUpdated;
}
//**********************************************************************
///
/// Queries the ATECal structure channel selection mask
///
/// @return		TRUE if channel selected; otherwise FALSE
//**********************************************************************
USHORT CATECal::GetChannelSelectionMask(void) const {
	return m_chanMask;
}
//**********************************************************************
///
/// Queries the ATECal structure channel RT current disable mask
///
/// @return		TRUE if channel selected; otherwise FALSE
//**********************************************************************
USHORT CATECal::GetRTISrcChannelDisableMask(void) const {
	return m_RTIOffChanMask;
}
//**********************************************************************
///
/// Restores the channels currently being read and those current sourcing
/// the current for the RT calibration to all sourcing and all being read
///
/// @return		TRUE if the configuration is comitted; otherwise FALSE
//**********************************************************************
BOOL CATECal::RestoreAllChannelsToRTRead(void) {
	m_RTIOffChanMask = 0x0;
	SetBits(&m_RTIChanReadMask, MAX_OF_ALL_16_CHANNELS, 0, QueryATECardNoOfChannel());
	return TRUE;
}
#define LAST_TWO_CHANNELS				2
#define TWO_IO_CHANNELS					2
#define ALL_CHANNELS_EXCEPT_FIRST_TWO	0xfffc
//**********************************************************************
///
/// Selects the channels currently being read and those current sourcing
/// the current for the RT calibration
/// @param[in] highChannelsTest - TRUE - If the high channels are being tested (Low channels sourcing);
///								  FALSE if the low end channels are being tested (High channels sourcing).
///
/// @return		TRUE if the configuration is comitted; otherwise FALSE
//**********************************************************************
BOOL CATECal::SelectRTReadChannels(const BOOL highChannelsTest) {
	BOOL retValue = TRUE;
	USHORT m_tRTIChanReadMask = 0;
	m_RTIOffChanMask = 0;
	if (highChannelsTest == TRUE) {
		/// Channels 1 & 2 are always sourcing; so disable current source on all remaining channels
		SetBits(&m_RTIOffChanMask, ALL_CHANNELS_EXCEPT_FIRST_TWO, 0, QueryATECardNoOfChannel());
		// Now sort out the channels that are to be read
		// and limit read selection to channels present on board
		SetBits(&m_RTIChanReadMask, ALL_CHANNELS_EXCEPT_FIRST_TWO, 0, QueryATECardNoOfChannel());
	} else {
		if (QueryATECardNoOfChannel() <= TWO_IO_CHANNELS) {
			// Illegal board fitted
			retValue = FALSE;
		}
		/// Last two channels present on board are always sourcing;
		/// so disable current source on all preceeding channels
		if (retValue == TRUE) {
			m_RTIOffChanMask = 0;
			m_tRTIChanReadMask = MAX_OF_ALL_16_CHANNELS;
			SetBits(&m_tRTIChanReadMask, 0x00, QueryATECardNoOfChannel() - LAST_TWO_CHANNELS, LAST_TWO_CHANNELS);
			///< Limit read selection to channels present on board
			SetBits(&m_RTIOffChanMask, m_tRTIChanReadMask, 0, QueryATECardNoOfChannel());
		}
		// Now sort out the remainder of the channels that need to be read
		m_RTIChanReadMask = 0x3;
	}
	return retValue;
}
//**********************************************************************
///
/// Commits the correct ATE calibration structure to approriate the local I/O board configuration
///
/// @return		TRUE if the configuration is comitted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CommitIOATECalStruct(void) {
	class CATECal *pATECalStruct = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	UCHAR boardType = BOARD_INVALID;
	BOOL retValue = TRUE;
	pATECalStruct = CATECal::GetHandle();
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL)
		boardType = pBrdInfo->WhatBoardType(m_cardSlot);
	switch (boardType) {
	case BOARD_AI:
	case BOARD_EZ_AI:
		retValue = CommitAIATECalStruct();
		// Get a handle on the relevant board's AI configuration
		break;
	case BOARD_AO:
		retValue = CommitAOATECalStruct();
		break;
	case BOARD_DIO:
	case BOARD_PI:
	case BOARD_AR:
		retValue = CommitDigPulseATECalStruct();
		break;
	}
	if (pATECalStruct != NULL) {
		// Reset the fact that no readings have yet been taken
		pATECalStruct->NoAIChanRawReadingsTaken();
	}
	return retValue;
}
//**********************************************************************
///
/// Commits the AI ATE calibration structure to the local AI configuration
///
/// @return		TRUE if the configuration is comitted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CommitAIATECalStruct(void) {
	class CIOConfigManager *pConfigMngr = NULL;
	class CAIConfig *pAIConfig = NULL;
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;
	m_AICal.chanMask = 0;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		SetBits(&m_AICal.chanMask, MAX_OF_ALL_16_CHANNELS, 0, pBrdInfoObj->GetNoOfChannels(m_cardSlot));
	// Get a handle on the configuration manager
	pConfigMngr = CIOConfigManager::GetHandle();
	if (pConfigMngr != NULL) {
		// Get a handle on the relevant board's AI configuration
		pAIConfig = pConfigMngr->GetAILocalConfig(m_cardSlot);
		if (pAIConfig != NULL) {
			// Only commit the cal structure through the local to the working if
			// we have not directly written to the working configuration
			if (m_directRTReadMode == FALSE) {
				// Copy over the calibration structure to the local AI configuration
				retValue = pAIConfig->CalStructTransfer(this);
				if (retValue == TRUE) {
					// Commit the local AI configuration to the I/O card
					retValue = pAIConfig->IOCardLocalConfigCommit();
				}
			} else {
				// Transfer the ATE structure to the local AI configuration of the I/O card
				retValue = pAIConfig->CalStructDirectTransfer(this);
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Commits the AO ATE calibration structure to the local AI configuration
///
/// @return		TRUE if the configuration is comitted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CommitAOATECalStruct(void) {
	class CIOConfigManager *pConfigMngr = NULL;
	class CAOConfig *pAOConfig = NULL;
	BOOL retValue = FALSE;
	class CBrdInfo *pBrdInfoObj = NULL;
//	m_AOCal.chanMask = 0;
	pBrdInfoObj = CBrdInfo::GetHandle();
//	if( pBrdInfoObj != NULL )
//		SetBits( &m_AOCal.chanMask, MAX_OF_ALL_16_CHANNELS, 0, pBrdInfoObj->GetNoOfChannels( m_cardSlot ) );
	// Get a handle on the configuration manager
	pConfigMngr = CIOConfigManager::GetHandle();
	if (pConfigMngr != NULL) {
		// Get a handle on the relevant board's AI configuration
		pAOConfig = pConfigMngr->GetAOLocalConfig(m_cardSlot);
		if (pAOConfig != NULL) {
			// Copy over the calibration structure to the local AI configuration
			retValue = pAOConfig->CalStructTransfer(this);
			if (retValue == TRUE) {
				// Commit the local AI configuration to the I/O card
				retValue = pAOConfig->IOCardLocalConfigCommit();
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Commits the pulse ATE calibration structure to the local pulse configuration
///
/// @return		TRUE if the configuration is comitted; otherwise FALSE
//**********************************************************************
BOOL CATECal::CommitDigPulseATECalStruct(void) {
	class CIOConfigManager *pConfigMngr = NULL;
	class CDigConfig *pPulseConfig = NULL;
	BOOL retValue = FALSE;
	// Get a handle on the configuration manager
	pConfigMngr = CIOConfigManager::GetHandle();
	if (pConfigMngr != NULL) {
		// Get a handle on the relevenat board's pulse configuration
		pPulseConfig = pConfigMngr->GetDigLocalConfig(m_cardSlot);
		if (pPulseConfig != NULL) {
			// Copy over the calibration structure to the local pulse configuration
			retValue = pPulseConfig->PulseCalStructTransfer(this);
			if (retValue == TRUE) {
				// Commit the local pulse configuration to the I/O card
				retValue = pPulseConfig->IOCardLocalConfigCommit();
			}
		}
	}
	return retValue;
}
//******************************************************
//  GetAIChannelCJCUserCalPoint()
///
/// Gets a channel calibration points.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[out] userCJCOffset - The user cal offset of the channel.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAIChannelCJCUserCalPoint(const USHORT cardNo, const USHORT chanNo, float &userCJCOffset) const {
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	float factCJCOffset = 0.0F;
	BOOL retValue = FALSE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (pICService != NULL) {
		retValue = pICService->GetAIChannelCJCCalPoints(cardNo, chanNo, factCJCOffset, userCJCOffset);
	}
	return retValue;
}
//******************************************************
//  SetCJCCalValueUsage()
///
/// Set the type current CMM configuration type for an analogue board.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetCJCCalValueUsage(USHORT slotNumber, REFERENCE cfgType) {
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	BOOL retValue = FALSE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (pICService != NULL) {
		retValue = pICService->SetCJCCalValueUsage(slotNumber, cfgType);
	}
	return retValue;
}
//******************************************************
//  GetAIChannelCJCCaledValue()
///
/// Gets a channel calibration points.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[out] factCJCValue - The factory cal'ed channel value.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAIChannelCJCCaledValue(const USHORT cardNo, const USHORT chanNo, float &factCJCValue) const {
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	BOOL retValue = FALSE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (pICService != NULL) {
		retValue = pICService->GetAIChannelCJCFactoryCaledValue(cardNo, chanNo, factCJCValue);
	}
	return retValue;
}
//******************************************************
//  SetAIChannelCJCUserCalPoint()
///
/// Sets a channel user calibration point.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[in] factCJCOffset - The factory cal offset of the channel.
/// @param[in] userCJCOffset - The user cal offset of the channel.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetAIChannelCJCUserCalPoint(const USHORT cardNo, const USHORT chanNo, float userCJCOffset) {
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	BOOL retValue = FALSE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (pICService != NULL) {
		retValue = pICService->SetAIChannelCJCUserCalPoint(cardNo, chanNo, userCJCOffset);
	}
	return retValue;
}
//******************************************************
//  SetAIChannelCalPoints()
///
/// Sets a channel calibration points.
/// @param[in] ChanNo - The system channel number.
/// @param[in] zeroCount - The lower cal point of the channel.
/// @param[in] spanCount - The upper cal point of the channel.
///
/// @return TRUE if the given cal points could be saved; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetAIChannelCalPoints(const USHORT chanNo, const T_RANGE_COUNTS zeroCount,
		const T_RANGE_COUNTS spanCount) {
	BOOL retValue = FALSE;
	if (GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
		m_AICal.calInfo[chanNo].zeroCount = zeroCount;
		m_AICal.calInfo[chanNo].spanCount = spanCount;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  GetAIChannelCalPoints()
///
/// Gets a channel calibration points.
/// @param[in] ChanNo - The system channel number.
/// @param[out] zeroCount - The lower cal point of the channel.
/// @param[out] spanCount - The upper cal point of the channel.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAIChannelCalPoints(const USHORT chanNo, T_RANGE_COUNTS &zeroCount, T_RANGE_COUNTS &spanCount) const {
	BOOL retValue = FALSE;
	if (GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
		zeroCount = m_AICal.calInfo[chanNo].zeroCount;
		spanCount = m_AICal.calInfo[chanNo].spanCount;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  SetAIChannelSavedCalPoints()
///
/// Sets a channel saved calibration points.
/// @param[in] ChanNo - The system channel number.
/// @param[in] zeroCount - The lower cal point of the channel.
/// @param[in] spanCount - The upper cal point of the channel.
///
/// @return TRUE if the given cal points could be saved; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetAIChannelSavedCalPoints(const USHORT chanNo, const T_RANGE_COUNTS zeroCount,
		const T_RANGE_COUNTS spanCount) {
	BOOL retValue = FALSE;
	if (GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
		m_AICal.savedCalInfo[chanNo].zeroCount = zeroCount;
		m_AICal.savedCalInfo[chanNo].spanCount = spanCount;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  GetAIChannelSavedCalPoints()
///
/// Gets a channel saved calibration points.
/// @param[in] ChanNo - The system channel number.
/// @param[in] zeroCount - The lower cal point of the channel.
/// @param[in] spanCount - The upper cal point of the channel.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAIChannelSavedCalPoints(const USHORT chanNo, T_RANGE_COUNTS &zeroCount,
		T_RANGE_COUNTS &spanCount) const {
	BOOL retValue = FALSE;
	if (GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
		zeroCount = m_AICal.savedCalInfo[chanNo].zeroCount;
		spanCount = m_AICal.savedCalInfo[chanNo].spanCount;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  SetRTISrcChannelDisableMask()
///
/// Used to set a channel RT source channels.
/// @param[in] chanMask - The system channel mask.
///
//******************************************************
void CATECal::SetRTISrcChannelDisableMask(const USHORT chanMask) {
	m_RTIOffChanMask = chanMask;
}
//******************************************************
//  SetChannelSelection()
///
/// Used to set a channel calibration channels.
/// @param[in] chanMask - The system channel mask.
///
//******************************************************
void CATECal::SetChannelSelection(const USHORT chanMask) {
	m_chanMask = chanMask;
}
//******************************************************
//  IllegalRawValueData()
///
/// Queries whether the raw data is legal.
/// @param[in] ChanNo - The system channel number.
/// @param[in] data - The data point to be tested.
/// @param[out] pErrorCode - The error code if applicable.
///
/// @return TRUE if the given data point was illegal; otherwise FALSE
///
//******************************************************
BOOL CATECal::IllegalRawValueData(const USHORT chanNo, const T_RANGE_COUNTS data, float *const pErrorCode) const {
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	BOOL retValue = FALSE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (data == ADC_RAW_UNDER_RANGE_VALUE) {
		// Raw value is underrange
		if (pICService != NULL)
			pICService->CreateFloatingPointRepresentation( IO_SCHED_ADC_VALUE_UNDER, pErrorCode);
		retValue = TRUE;
	}
	if (data == ADC_RAW_OVER_RANGE_VALUE) {
		// Raw value is overrange
		if (pICService != NULL)
			pICService->CreateFloatingPointRepresentation( IO_SCHED_ADC_VALUE_OVER, pErrorCode);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
/// GetRangeReadTolerence
///
/// indexOfs the read voltage tolerance for a range on the board currently being calibrated
///
/// @param[in] rangeNo - Range number to use.
/// @param[in] factoryCal - TRUE if factory calibration tolerences are required; otherwise FALSE for user calibration.
///
/// @return		The tolerence percentage to test the returned raw value against.
//**********************************************************************
float CATECal::GetRangeRawReadTolerence(const USHORT range, const BOOL factoryCal) const {
	class CBrdInfo *pBrdInfo = NULL;
	UCHAR hardwareRevision;
	float rawTolerence = RAW_CAL_TOLERANCE;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		if (pBrdInfo->GetBoardHardwareRevision(QueryATECardNo(), &hardwareRevision) == TRUE) {
			// If it's a 50V range the tolerance needs to be higher for revision 0 boards
			if ((LINEAR_VOLTS_50V == range) && (REV_A_BOARD == hardwareRevision)) {
				rawTolerence = REV_A_RAW_CAL_50V_TOLERANCE;
			}
		}
	}
	return rawTolerence;
}
//**********************************************************************
/// TestCardRawCalibrationTolerences
///
/// Checks that the read calibration range is within tolerance for each channel
///
/// @param[in] rangeNo - Range number to use.
/// @param[in] factoryCal - TRUE if factory calibration tolerences are required; otherwise FALSE for user calibration.
/// @param[in] inChanMask - The mask of the channels to be read/written.
/// @param[out] pOutChanMask - The mask of the channels that passed and can be written.
///
///
/// @return		TRUE if all the range limits were within tolerence; otherwise FALSE
//**********************************************************************
BOOL CATECal::TestCardRawCalibrationTolerences(const USHORT range, const BOOL factoryCal, const USHORT inChanMask,
		USHORT *pOutChanMask) const {
	float rawTolerance;
	USHORT chanNo;
	BOOL retValue = TRUE;
	T_RANGE_COUNTS zeroUpperLimit;
	T_RANGE_COUNTS zeroLowerLimit;
	T_RANGE_COUNTS spanUpperLimit;
	T_RANGE_COUNTS spanLowerLimit;
	*pOutChanMask = 0;
	rawTolerance = GetRangeRawReadTolerence(range, factoryCal);
	if (GetRangeReadTolerence(range, rawTolerance, &zeroUpperLimit, &zeroLowerLimit, &spanUpperLimit,
			&spanLowerLimit) == TRUE) {
		for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
			if (GetBits(inChanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
				// Check the tolerences of each card channel
				if (CheckCalibrationTolerences(zeroUpperLimit, zeroLowerLimit, spanUpperLimit, spanLowerLimit,
						chanNo) == TRUE) {
					// Notify user that channel calibration has been succesful
					SetBits(pOutChanMask, 1, chanNo, 1);
				} else {
					retValue = FALSE;
				}
			}
		}
	} else {
		retValue = FALSE;
	}
	return retValue;
}
//******************************************************
//  SetAIRTChannelCalPoints()
///
/// Sets a channel calibration points.
/// @param[in] chanNo - The system channel number.
/// @param[in] count - The cal point of the channel.
///
/// @return TRUE if the given cal points could be saved; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetAIRTChannelCalPoints(const USHORT chanNo, const USHORT count) {
	BOOL retValue = FALSE;
	if (GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
		m_AICal.rtCalInfo[chanNo] = count;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  GetAIRTChannelCalPoints()
///
/// Gets a channel calibration points.
/// @param[in] ChanNo - The system channel number.
/// @param[out] Count - The cal point of the channel.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAIRTChannelCalPoints(const USHORT chanNo, USHORT &Count) const {
	BOOL retValue = FALSE;
	if (GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
		Count = m_AICal.rtCalInfo[chanNo];
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  SelectAcqRate()
///
/// Sets the current channel acqsistion rate for any input channel.
/// @param[in] ChanNo - The system channel number.
/// @param[in] rateEnum - The acquisition rate of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectAIChanAcqRate(const USHORT ChanNo, const USHORT rateEnum) {
	BOOL retValue = TRUE;
	// Make AI board channel configured for acquiring at the specified rate
	m_cfgAI.CfgChan[ChanNo].ChanCfgInfo.acqEnum = static_cast<UCHAR>(rateEnum);
	m_setupUpdated = TRUE;
	return retValue;
}
//******************************************************
//  GetAIChanReadings()
///
/// Sets the current channel acqsistion rate for any input channel.
/// @param[in] chanNo - The system channel number.
/// @param[out] pRawReading - The raw 16 bit number from the channel.
///
/// @return TRUE if a reading is available; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAIChanRawReadings(const USHORT chanNo, T_RANGE_COUNTS *pRawReading) const {
	BOOL retValue = AIChanRawReadingAvailable[chanNo];
	if (retValue == TRUE) {
		*pRawReading = AIChanRawReading[chanNo];
	}
	return retValue;
}
//******************************************************
//  GetAIChanVolatageReadings()
///
/// Sets the current channel acqsistion rate for any input channel.
/// @param[in] chanNo - The system channel number.
/// @param[out] pRangeReading - The channels voltage
///
/// @return TRUE if a reading is available; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAIChanVoltageReadings(const USHORT chanNo, float *pRangeReading) const {
	BOOL retValue = AIChanVReadingAvailable[chanNo];
	if (retValue == TRUE) {
		*pRangeReading = AIChanVoltageReading[chanNo];
	}
	return retValue;
}
//******************************************************
//  NoAIChanRawReadingsTaken()
///
/// Clear staus that raw readings have been taken.
///
//******************************************************
void CATECal::NoAIChanRawReadingsTaken(void) {
	USHORT chanNo;
	for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++)
		AIChanRawReadingAvailable[chanNo] = FALSE;
}
//******************************************************
//  ReadingCheckRqd()
///
/// Checks whether a reading check is required.
///
/// @return TRUE if a reading check is required; otherwise FALSE
///
//******************************************************
BOOL CATECal::ReadingCheckRqd(void) const {
	return m_ReadingCheckRqd;
}
//******************************************************
//  SetReadingCheckRqdState()
///
/// Sets the reading required state.
/// @param[in] state - TRUE if reading check is required; otherwise FALSE.
///
/// @return Input returned
///
//******************************************************
BOOL CATECal::SetReadingCheckRqdState(const BOOL state) {
	m_ReadingCheckRqd = state;
	return m_ReadingCheckRqd;
}
//******************************************************
//  StoreAIChanRawReadings()
///
/// Stores the current AI channel readings.
/// @param[in] chanNo - The system channel number.
/// @param[in] RawReading - The channel raw reading.
///
/// @return TRUE if a reading is available; otherwise FALSE
///
//******************************************************
BOOL CATECal::StoreAIChanRawReadings(const USHORT chanNo, const T_RANGE_COUNTS RawReading) {
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	BOOL retValue = TRUE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	AIChanRawReading[chanNo] = RawReading;
	if (pICService->IsValueAScheduledMissing(RawReading) == FALSE)
		AIChanRawReadingAvailable[chanNo] = TRUE;
	return retValue;
}
//******************************************************
//  TestAIChanRawReadingsCompleted()
///
/// Tests whether all AI channel raw readings have been completed.
///
/// @return TRUE if all channels readings are available; otherwise FALSE
///
//******************************************************
BOOL CATECal::TestAIChanRawReadingsCompleted(void) const {
	class CPPIOServiceManager *pServiceManagerObj = NULL;
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	USHORT chanNo = 0;
	BOOL retValue = TRUE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (pICService != NULL) {
		for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
			if (m_cfgAI.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE) {
				if (AIChanRawReadingAvailable[chanNo] == FALSE) {
					retValue = FALSE;
					break;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
//  TestAIChanReadingsCompleted()
///
/// Tests whether all AI channel readings have been completed.
///
/// @return TRUE if all channels readings are available; otherwise FALSE
///
//******************************************************
BOOL CATECal::TestAIChanReadingsCompleted(void) const {
	class CPPIOServiceManager *pServiceManagerObj = NULL;
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	USHORT chanNo = 0;
	BOOL retValue = TRUE;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (pICService != NULL) {
		for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
			if (m_cfgAI.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE) {
				if ((AIChanRawReadingAvailable[chanNo] == FALSE)
						|| (pICService->IsValueAScheduledMissing(AIChanRawReading[chanNo]) == TRUE)) {
					retValue = FALSE;
					break;
				}
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Gets the channel calibration info.
///
/// @param[in] chanNo - Card slot channel number.
///
/// @return	 	An AI channels calibration data
//**********************************************************************
const T_AICHANNELCAL* CATECal::GetAIChanCal(const UCHAR chanNo) const {
	if ((GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) && (chanNo < TOPSLOT_AICHAN_SIZE))
		return &m_AICal.calInfo[chanNo];
	return NULL;
}
//**********************************************************************
///
/// Gets the channel saved calibration info.
///
/// @param[in] chanNo - Card slot channel number.
///
/// @return	 	An AI channels calibration data
//**********************************************************************
const T_AICHANNELCAL* CATECal::GetAISavedChanCal(const UCHAR chanNo) const {
	if ((GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) && (chanNo < TOPSLOT_AICHAN_SIZE))
		return &m_AICal.savedCalInfo[chanNo];
	return NULL;
}
//**********************************************************************
///
/// Gets the channel calibration info for download to the board.
///
/// @param[in] chanNo - Card slot channel number.
///
/// @return	 	An AI channels calibration data
//**********************************************************************
const T_AICHANNELCAL* CATECal::GetAIChanDownloadCal(const UCHAR chanNo) const {
	if ((GetBits(m_chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) && (chanNo < TOPSLOT_AICHAN_SIZE))
		return &m_AICal.calDownload[chanNo];
	return NULL;
}
//**********************************************************************
///
/// Queries whether the CJC for a given slot is valid
///
/// @param[in] slotNo - Card slot number.
///
/// @return	 	TRUE if the CJC for the given slot is legal; otherwise FALSE
//**********************************************************************
BOOL CATECal::QueryIsCJCValid(const UCHAR slotNo) const {
	class CSlotMap *pSlotMap = NULL;
	CDataItem *pDataItem = NULL;
	BOOL retValue = FALSE;
	USHORT CJCNo;
	USHORT CJCDegCNo;
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL) {
		// Initiliase the CJC data items for card
		if (pSlotMap->ObtainBoardsDICJCRef(slotNo, &CJCNo, &CJCDegCNo) == TRUE) {
			pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCNo);
			if (pDataItem != NULL) {
				if (pDataItem->GetStatus() != DISTAT_INVALID) {
					retValue = TRUE;
				}
			}
		}
	}
	return retValue;
}
//**********************************************************************
///
/// Sets a channel's calibration info.
///
/// @param[in] chanNo - Card slot channel number.
/// @param[in] cal - Card slot channel calibration data.
///
/// @return	 	TRUE if the channel calibration data can be set; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetAIChanCal(const UCHAR chanNo, const T_AICHANNELCAL cal) {
	BOOL retValue = TRUE;
	if ((GetBits(m_chanMask, chanNo, 1) != 0) && (chanNo < TOPSLOT_AICHAN_SIZE)) {
		retValue = AISaveCalcDownload(chanNo, cal.spanCount, cal.zeroCount);
	}
	return retValue;
}
//**********************************************************************
/// CheckCalibrationTolerences
///
/// Checks that the calibration info is within tolerance
///
/// @param[in] zeroUpperLimit - The AI boards zero upper limit allowed.
/// @param[in] zeroLowerLimit - The AI boards zero lower limit allowed.
/// @param[in] spanUpperLimit - The AI boards span upper limit allowed.
/// @param[in] spanLowerLimit - The AI boards span lower limit allowed.
/// @param[out] usChan - The board channel number that failed.
///
/// @return		TRUE if the range limits were within tolerence; otherwise FALSE
//**********************************************************************
BOOL CATECal::CheckCalibrationTolerences( T_RANGE_COUNTS zeroUpperLimit, T_RANGE_COUNTS zeroLowerLimit,
T_RANGE_COUNTS spanUpperLimit, T_RANGE_COUNTS spanLowerLimit, USHORT &usChan) const {
	USHORT usChanNo;
	QString csCalFail = "";
	BOOL spanCheck = TRUE;
	BOOL zeroCheck = TRUE;
	BOOL retValue = TRUE;
	for (usChanNo = 0; ((usChanNo < QueryATECardNoOfChannel()) && (TRUE == retValue)); usChanNo++) {
		retValue = CheckTolerenceLimits(m_AICal.calInfo[usChanNo].zeroCount, m_AICal.calInfo[usChanNo].spanCount,
				zeroUpperLimit, zeroLowerLimit, spanUpperLimit, spanLowerLimit, usChanNo);
		if ( FALSE == retValue)
			usChan = usChanNo;
	}
	return retValue;
}
//**********************************************************************
/// CheckTolerenceLimits
///
/// Checks that the calibration info is within tolerance
///
/// @param[in] zeroPoint - The AI boards zero point to be tested.
/// @param[in] spanPoint - The AI boards span point to be tested.
/// @param[in] zeroUpperLimit - The AI boards zero upper limit allowed.
/// @param[in] zeroLowerLimit - The AI boards zero lower limit allowed.
/// @param[in] spanUpperLimit - The AI boards span upper limit allowed.
/// @param[in] spanLowerLimit - The AI boards span lower limit allowed.
/// @param[in] usChanNo - The board channel number.
///
/// @return		TRUE if the range limits were within tolerence; otherwise FALSE
//**********************************************************************
BOOL CATECal::CheckTolerenceLimits(const T_RANGE_COUNTS zeroPoint, const T_RANGE_COUNTS spanPoint,
		const T_RANGE_COUNTS zeroUpperLimit, const T_RANGE_COUNTS zeroLowerLimit, const T_RANGE_COUNTS spanUpperLimit,
		const T_RANGE_COUNTS spanLowerLimit, const USHORT usChanNo) const {
	QString csCalFail = "";
	BOOL spanCheck = TRUE;
	BOOL zeroCheck = TRUE;
	BOOL retValue = TRUE;
	spanCheck = TRUE;
	zeroCheck = TRUE;
	csCalFail = L"";
	// Fail if span or zero measurement is outside of respective limits
	if ((spanPoint < spanLowerLimit) || (spanPoint > spanUpperLimit))
		spanCheck = FALSE;
	if ((zeroPoint < zeroLowerLimit) || (zeroPoint > zeroUpperLimit))
		zeroCheck = FALSE;
	// Now log the results
	if ( TRUE == spanCheck) {
		csCalFail = QString::asprintf("chan %d pass span %d >> %d << %d", usChanNo + 1, spanLowerLimit, spanPoint,
				spanUpperLimit);
//		csCalFail = QString::asprintf(IDS_CHAN_RAW_READING_PASSED, range);
	} else {
		csCalFail = QString::asprintf("chan %d fail span %d >> %d << %d", usChanNo + 1, spanLowerLimit, spanPoint,
				spanUpperLimit);
//		csCalFail = QString::asprintf(IDS_CHAN_RAW_READING_FAILURE, range);
	}
	if (csCalFail != L"") {
		AddString(csCalFail);
		WriteErrorFileString(csCalFail);
	}
	csCalFail = L"";
	if ( TRUE == zeroCheck) {
		csCalFail = QString::asprintf("chan %d pass zero %d >> %d << %d", usChanNo + 1, zeroLowerLimit, zeroPoint,
				zeroUpperLimit);
//		csCalFail = QString::asprintf(IDS_CHAN_RAW_READING_PASSED, range);
	} else {
		csCalFail = QString::asprintf("chan %d fail zero %d >> %d << %d", usChanNo + 1, zeroLowerLimit, zeroPoint,
				zeroUpperLimit);
//		csCalFail = QString::asprintf(IDS_CHAN_RAW_READING_FAILURE, range);
	}
	if (csCalFail != L"") {
		AddString(csCalFail);
		WriteErrorFileString(csCalFail);
	}
	if ((FALSE == spanCheck) || (FALSE == zeroCheck))
		retValue = FALSE;
	return retValue;
}
//**********************************************************************
/// GetRangeReadTolerence
///
/// indexOfs the read voltage tolerance for a range on the board currently being calibrated
///
/// @param[in] rangeNo - Range number to use.
/// @param[in] tolerence - The AI boards range tolerence desired.
/// @param[out] pzeroUpperLimit - The AI boards zero upper limit allowed.
/// @param[out] pzeroLowerLimit - The AI boards zero lower limit allowed.
/// @param[out] pspanUpperLimit - The AI boards span upper limit allowed.
/// @param[out] pspanLowerLimit - The AI boards span lower limit allowed.
///
/// @return		TRUE if the range limits were calculated; otherwise FALSE
//**********************************************************************
BOOL CATECal::GetRangeReadTolerence(const USHORT Range, const float tolerence,
T_RANGE_COUNTS *pzeroUpperLimit, T_RANGE_COUNTS *pzeroLowerLimit,
T_RANGE_COUNTS *pspanUpperLimit, T_RANGE_COUNTS *pspanLowerLimit) const {
	BOOL retValue = FALSE;
//	UCHAR BoardRev;
	UCHAR RangeRev;
	class CAIRanges *pAIRange = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	if ((pBrdInfoObj->WhatBoardType(m_cardSlot) == BOARD_AI)
			|| (pBrdInfoObj->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		pAIRange = CAIRanges::GetHandle();
		if (pAIRange != NULL) {
			/// Get board range configuration issue
//			pBrdInfoObj->GetBoardHardwareRevision( m_cardSlot, &BoardRev );
//			RangeRev = pAIRange->GetRangeRevision( BoardRev );
			pBrdInfoObj->GetBoardRangeRevision(m_cardSlot, &RangeRev);
			retValue = pAIRange->GetRangeReadTolerence(Range, RangeRev, tolerence, pzeroUpperLimit, pzeroLowerLimit,
					pspanUpperLimit, pspanLowerLimit);
		}
	}
	return retValue;
}
//**********************************************************************
/// GetRangeClosestMatch
///
/// indexOfs the read voltage tolerance for a range on the board currently being calibrated
///
/// @param[in] rangeNo - Range number to use.
/// @param[out] pUpperLimit - The AI boards range upper limit desired.
/// @param[out] pLowerLimit - The AI boards range lower limit desired.
///
/// @return		TRUE if the range limits were calculated; otherwise FALSE
//**********************************************************************
BOOL CATECal::GetChannelCalPoints(const USHORT Range, T_RANGE *pUpperRange, T_RANGE *pLowerRange,
		IO_MEASURE_UNITS *pUnits) const {
	BOOL retValue = FALSE;
//	UCHAR BoardRev;
	UCHAR RangeRev;
	class CAIRanges *pAIRange = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	if ((pBrdInfoObj->WhatBoardType(m_cardSlot) == BOARD_AI)
			|| (pBrdInfoObj->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
		pAIRange = CAIRanges::GetHandle();
		if (pAIRange != NULL) {
			/// Get board range configuration issue
			pBrdInfoObj->GetBoardRangeRevision(m_cardSlot, &RangeRev);
			retValue = pAIRange->GetBaseRangeChannelCalPoints(Range, RangeRev, pUpperRange, pLowerRange, pUnits);
		}
	}
	return retValue;
}
//**********************************************************************
/// SetAIAuxDirectRead()
///
/// Places the configuration into special read mode
/// Sets the channel type & range directly in the working copys.
/// @note: (configuration is invalid for normal correct board operation)
///
/// @param[in] chanNo - Card slot channel number.
/// @param[in] DirectMode - Type of direct reading to take
/// @param[in] rawMode - TRUE if raw mode is selected; otherwise FALSE
///
/// @return	 	 TRUE if the range selection is successful; otherwise FALSE
/// @note	 	 Use of this routine must be limited to use on the test equipment
//**********************************************************************
BOOL CATECal::SetAIAuxDirectRead(const USHORT chanNo, const T_DIRECT_READ_MODE DirectMode, const BOOL rawMode) {
	BOOL ConfigChanged = TRUE;
	UCHAR RangeRev;
	UCHAR RangeComp;
	UCHAR RangeGain;
	UCHAR RangePair;
	USHORT forBitManipulation = 0;
	class CAIRanges *pAIRange = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	switch (DirectMode) {
	case DRM_READ_EZ_INPUT_RTCAL:
	case DRM_READ_EZ_INPUT_RTCOMP:
	case DRM_READ_EZ_INPUT_RTCAL_FACT:
	case DRM_READ_INPUT_RTCAL:
	case DRM_READ_INPUT_RTCOMP:
	case DRM_READ_INPUT_RTCAL_HIGH:
	case DRM_READ_INPUT_RTCOMP_HIGH:
		ConfigChanged = TRUE;		///< To operate in this mode means we must always send the config to the board
		break;
	case DRM_READ_INPUT_RT_CHAN:
		ConfigChanged = TRUE;		///< To operate in this mode means we must always send the config to the board
		break;
	default:
		ConfigChanged = FALSE;
		break;
	}
	if (ConfigChanged == TRUE) {
		m_directRTReadMode = TRUE;		///< Shortcut to allow direct loading of the board working configuration
		// Change the current channel configuration
		forBitManipulation = 0;	///< Select mV input
		SetBits(&forBitManipulation, TRUE, 0, 1);		///< Force the channel to be enabled
		SetBits(&forBitManipulation, rawMode, 1, 1);
		SetBits(&forBitManipulation, ACQ_FREQ2, 2, 3);
		if ((DirectMode == DRM_READ_EZ_INPUT_RTCAL) && (rawMode == TRUE))
			SetBits(&forBitManipulation, 1, 5, 1);// Set to field calibration mode (reuse to allow different inputs to be selected - yuk)
		m_cfgAI.WrkChan[chanNo].ChanSetup = static_cast<UCHAR>(forBitManipulation);
		forBitManipulation = CtrlP1;	///< Select mV input
		if ((DirectMode == DRM_READ_INPUT_RTCAL_HIGH) || (DirectMode == DRM_READ_INPUT_RTCOMP_HIGH)) {
			m_cfgAI.WrkChan[chanNo].highSource = TRUE;
		} else {
			m_cfgAI.WrkChan[chanNo].highSource = FALSE;
		}
		SetBits(&forBitManipulation, m_cfgAI.WrkChan[chanNo].highSource, 7, 1);
		if (DirectMode == DRM_READ_EZ_INPUT_RTCOMP) {
			SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
			SetBits(&forBitManipulation, Gain32, 0, 3);
		} else if ((DirectMode == DRM_READ_INPUT_RTCAL_HIGH) || (DirectMode == DRM_READ_INPUT_RTCOMP_HIGH)) {
			SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
			SetBits(&forBitManipulation, Gain1, 0, 3);
		} else if (DirectMode == DRM_READ_INPUT_RT_CHAN) {
			pBrdInfoObj = CBrdInfo::GetHandle();
			pAIRange = CAIRanges::GetHandle();
			if ((pAIRange != NULL) && (pBrdInfoObj != NULL)) {
				SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
				// indexOf out what the selected gain should be
				pBrdInfoObj->GetBoardRangeRevision(m_cardSlot, &RangeRev);
				pAIRange->GetBaseChannelConfig(m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum, RangeRev,
						&RangeComp, &RangeGain, &RangePair);
				SetBits(&forBitManipulation, RangeGain, 0, 3);
			}
		} else {
			SetBits(&forBitManipulation, (PairA1A2 >> 4), 4, 2);
			SetBits(&forBitManipulation, Gain32, 0, 3);
		}
		m_cfgAI.WrkChan[chanNo].RangeGain = static_cast<UCHAR>(forBitManipulation);
		m_setupUpdated = TRUE;
	}
	return ConfigChanged;
}
//******************************************************
//  GetNextATEAnalOut()
///
/// Get next ATE value to write to analogue output, only on enabled card channels requiring an update.
/// @param[out] pChanNo - Card slot channel number.
/// @param[out] pAOOutput - Card slot channel value to write.
///
/// @return TRUE if there is a channel to process; otherwise FALSE.
///
//******************************************************
BOOL CATECal::GetNextATEAnalOut(UCHAR *pChanNo, USHORT *pAOOutput) {
	BOOL retValue = FALSE;
	class CIOConfigManager *pConfigMngr = NULL;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CAOConfig *pAOConfig = NULL;
	UCHAR firstChan = 0;
	UCHAR chanNo = 0;
	pBrdStatsObj = CBrdStats::GetHandle();
	if (m_OPUpdated == TRUE) {
		// Get a handle on the configuration manager
		pConfigMngr = CIOConfigManager::GetHandle();
		if (pConfigMngr != NULL) {
			// Get a handle on the relevant board's AI configuration
			pAOConfig = pConfigMngr->GetAOLocalConfig(m_cardSlot);
		}
		if (pAOConfig != NULL) {
			// indexOf the channel that completes the cycle covering all channels
			chanNo = firstChan = m_lastChanSet + 1;
			chanNo %= TOPSLOT_AOCHAN_SIZE;			// Limit to maximum possible channels
			do {
				// Check whether channel is enabled; if so possible canidate
				if (pAOConfig->QueryChannelEnabled(chanNo) == TRUE) {
					if ((IsRunningAsATEEquipment() == TRUE)
							|| (pBrdStatsObj->HasLimitedRunModeBeenOrderedOnCard(m_cardSlot) == TRUE)) {
						// Set board channel as processed this this cycle
						m_lastChanSet = chanNo;
						// If running ATE equipment we will always output to an enabled channel
						*pAOOutput = m_AODirectOP[chanNo];	 	// Set value to output
						*pChanNo = chanNo;
						retValue = TRUE;
						break;
					}
					chanNo++;
				} else {
					chanNo++;
				}
				// indexOf which board channel requires an output next
				chanNo %= TOPSLOT_AOCHAN_SIZE;
			} while (chanNo != m_lastChanSet);
		}
	}
	return retValue;
}
//**********************************************************************
/// SetAICalibPair()
///
/// Places the configuration into special calibration mode
/// Sets the channel type & range directly in the working copys.
/// @note: (configuration is invalid for normal correct board operation)
///
/// @param[in] chanNo - Card slot channel number.
/// @param[in] DirectMode - Type of direct reading to take
///
/// @return	 	 TRUE if the range selection is successful; otherwise FALSE
/// @note	 	 Use of this routine must be limited to use on the test equipment
//**********************************************************************
BOOL CATECal::SetAICalibPair(const USHORT chanNo, const T_DIRECT_READ_MODE DirectMode, const BOOL rawMode) {
	BOOL ConfigChanged = FALSE;
	UCHAR RangeRev;
	UCHAR RangeComp;
	UCHAR RangeGain;
	UCHAR RangePair;
	USHORT forBitManipulation = 0;
	class CAIRanges *pAIRange = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	pAIRange = CAIRanges::GetHandle();
	switch (DirectMode) {
	case DRM_READ_INPUT_RTCAL_HIGH:
	case DRM_READ_INPUT_RTCOMP_HIGH:
		m_directRTReadMode = TRUE;
		forBitManipulation = m_cfgAI.WrkChan[chanNo].RangeGain;
		SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
		m_cfgAI.WrkChan[chanNo].RangeGain = static_cast<UCHAR>(forBitManipulation);
		ConfigChanged = TRUE;
		if ((DirectMode == DRM_READ_INPUT_RTCAL_HIGH) || (DirectMode == DRM_READ_INPUT_RTCOMP_HIGH)) {
			m_cfgAI.WrkChan[chanNo].highSource = TRUE;
		} else {
			m_cfgAI.WrkChan[chanNo].highSource = FALSE;
		}
		SetBits(&forBitManipulation, m_cfgAI.WrkChan[chanNo].highSource, 7, 1);
		if ((pAIRange != NULL) && (pBrdInfoObj != NULL)) {
			// indexOf out what the selected gain should be
			pBrdInfoObj->GetBoardRangeRevision(m_cardSlot, &RangeRev);
			pAIRange->GetBaseChannelConfig(m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum, RangeRev, &RangeComp,
					&RangeGain, &RangePair);
			SetBits(&forBitManipulation, RangeGain, 0, 3);
			SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
			m_cfgAI.WrkChan[chanNo].RangeGain = static_cast<UCHAR>(forBitManipulation);
		}
		break;
	case DRM_READ_INPUT_RT_CHAN:
		m_directRTReadMode = TRUE;		///< Shortcut to allow direct loading of the board working configuration
		// Change the current channel configuration
		forBitManipulation = 0;	///< Select mV input
		SetBits(&forBitManipulation, TRUE, 0, 1);		///< Force the channel to be enabled
		SetBits(&forBitManipulation, rawMode, 1, 1);
		SetBits(&forBitManipulation, ACQ_FREQ2, 2, 3);
		m_cfgAI.WrkChan[chanNo].ChanSetup = static_cast<UCHAR>(forBitManipulation);
		forBitManipulation = CtrlP1;	///< Select mV input
		SetBits(&forBitManipulation, m_cfgAI.WrkChan[chanNo].highSource, 7, 1);
		if ((pAIRange != NULL) && (pBrdInfoObj != NULL)) {
			// indexOf out what the selected gain should be
			pBrdInfoObj->GetBoardRangeRevision(m_cardSlot, &RangeRev);
			pAIRange->GetBaseChannelConfig(m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum, RangeRev, &RangeComp,
					&RangeGain, &RangePair);
			SetBits(&forBitManipulation, RangeGain, 0, 3);
			SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
			m_cfgAI.WrkChan[chanNo].RangeGain = static_cast<UCHAR>(forBitManipulation);
		}
		break;
	case DRM_READ_EZ_INPUT_RTCAL:
	case DRM_READ_EZ_INPUT_RTCOMP:
	case DRM_READ_EZ_INPUT_RTCAL_FACT:
	case DRM_READ_INPUT_RTCAL:
	case DRM_READ_INPUT_RTCOMP:
	default:
		break;
	}
	return ConfigChanged;
}
//******************************************************
//  StoreAIChanVoltageReadings()
///
/// Stores the current AI channel readings.
/// @param[in] chanNo - The system channel number.
/// @param[in] RawReading - Write the raw reading.
///
/// @return TRUE if a reading is available; otherwise FALSE
///
//******************************************************
BOOL CATECal::StoreAIChanVoltageReadings(const USHORT chanNo, const float Reading) {
	BOOL retValue = TRUE;
	AIChanVoltageReading[chanNo] = Reading;
	AIChanVReadingAvailable[chanNo] = TRUE;
	return retValue;
}
//**********************************************************************
/// SetCalcChannelRange()
///
/// Sets the channel type & range in the locally held configuration.
/// Without setting the setup changed flag
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[in] ChanType - Channel selected type (Linear	 RT or TC)
/// @param[in] Range - Range 50V, 25V etc, TC or RT selection Info
///
/// @return	 	 TRUE if the range selection is successful; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetCalcChannelRange(const USHORT ChanNo, const USHORT ChanType, const USHORT RangeEnum) {
	BOOL ConfigChanged = TRUE;
	// Change the current channel configuration
	m_cfgAI.CfgChan[ChanNo].UserRange.RangeInfo.ChanType = ChanType;
	m_cfgAI.CfgChan[ChanNo].UserRange.RangeInfo.RangeEnum = RangeEnum;
	m_cfgAI.CfgChan[ChanNo].UserRange.EngUnits = SetChannelEngUnits(ChanType, RangeEnum);
	m_directRTReadMode = FALSE;
	m_setupUpdated = TRUE;
	SetCommitMode( FALSE);
	return ConfigChanged;
}
//******************************************************
//  SelectAICalcChanVoltageRange()
///
/// Sets the current channel range for any calculated voltage channel on any card in the local configuration.
/// Without setting the setup changed flag
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The voltage range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectAICalcChanVoltageRange(const USHORT ChannelNo, const USHORT Range) {
	return SetCalcChannelRange(ChannelNo, AI_CHANNEL_TYPE_LINEAR_VOLTS, Range);
}
//**********************************************************************
/// SetChannelEngUnits()
///
/// Sets the channel engineering units for any selected range.
///
/// @param[in] ChanType - Channel selected type (Linear	 RT or TC)
/// @param[in] RangeEnum - Range 50V, 25V etc, TC or RT selection Info
///
/// @return	 	 Channel engineering units
//**********************************************************************
IO_MEASURE_UNITS CATECal::SetChannelEngUnits(const USHORT ChanType, const USHORT RangeEnum) const {
	IO_MEASURE_UNITS engUnits;
	if (ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) {
		if (RangeEnum <= LINEAR_VOLTS_0_3V)
			engUnits = UNITS;
		else
			engUnits = MILLI;
	} else if (ChanType == AI_CHANNEL_TYPE_LINEAR_AMPS) {
		engUnits = MILLI;
	} else {
		engUnits = UNITS;
	}
	return engUnits;
}
//**********************************************************************
/// SetChannelRange()
///
/// Sets the channel type & range in the locally held configuration.
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[in] ChanType - Channel selected type (Linear	 RT or TC)
/// @param[in] RangeEnum - Range 50V, 25V etc, TC or RT selection Info
///
/// @return	 	 TRUE if the range selection is successful; otherwise FALSE
//**********************************************************************
BOOL CATECal::SetChannelRange(const USHORT ChanNo, const USHORT ChanType, const USHORT RangeEnum) {
	BOOL ConfigChanged = TRUE;
	// Change the current channel configuration
	m_cfgAI.CfgChan[ChanNo].UserRange.RangeInfo.ChanType = ChanType;
	m_cfgAI.CfgChan[ChanNo].UserRange.RangeInfo.RangeEnum = RangeEnum;
	m_cfgAI.CfgChan[ChanNo].UserRange.EngUnits = SetChannelEngUnits(ChanType, RangeEnum);
	m_directRTReadMode = FALSE;
	m_setupUpdated = TRUE;
	return ConfigChanged;
}
//**********************************************************************
/// SetChannelRange()
///
/// Sets the channel type & range in the locally held configuration.
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] ChanType - Channel selected type (Linear, RT or TC)
/// @param[out] Range - Range 50V, 25V etc, TC or RT selection Info
///
/// @return TRUE if the given range could be obtained; otherwise FALSE
///
//**********************************************************************
BOOL CATECal::GetAIChannelRange(const USHORT ChanNo, USHORT *pChanType, USHORT *pRangeEnum) const {
	BOOL retValue = FALSE;
	if (m_directRTReadMode == FALSE) {
		// Query the current channel configuration
		*pChanType = m_cfgAI.CfgChan[ChanNo].UserRange.RangeInfo.ChanType;
		*pRangeEnum = m_cfgAI.CfgChan[ChanNo].UserRange.RangeInfo.RangeEnum;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//  SelectVoltageRange()
///
/// Sets the current channel range for any voltage channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The voltage range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectAIChanVoltageRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_LINEAR_VOLTS, Range);
}
//******************************************************
//  SelectCurrentRange()
///
/// Sets the current channel range for any current channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The current range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectAIChanCurrentRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_LINEAR_AMPS, Range);
}
//******************************************************
//  SelectResistanceRange()
///
/// Sets the current channel range for any resistance channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The rsistance range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectAIChanResistanceRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_LINEAR_OHMS, Range);
}
//******************************************************
//  SelectTCRange()
///
/// Sets the current channel range for any voltage channel on any card in the local configuration.
/// @param[in] sysChannelNo - The TC channel number.
/// @param[in] Range - The TC range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectAIChanTCRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_TC, Range);
}
//******************************************************
//  SelectRTRange()
///
/// Sets the current channel range for any RT channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The RT range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectAIChanRTRange(const USHORT ChannelNo, const USHORT Range) {
	m_directRTReadMode = FALSE;
	m_cfgAI.WrkChan[ChannelNo].RangeGain;
	m_cfgAI.WrkChan[ChannelNo].ChanSetup;
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_RT, Range);
}
//******************************************************
///
/// Sets the digital board Output pulse duration
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] pulseDuration - The Output pulse duration
/// @param[in] pulseDirection - The Output pulse direction
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetBoardCfgOutputPulseDuration(const USHORT chanNo, const USHORT pulseDuration) {
	m_cfgDigPulse.CfgChan[chanNo].PulseDuration = pulseDuration;
	m_setupUpdated = TRUE;
	return TRUE;
}
//******************************************************
///
/// Defaults all channels to ensure that no channel offsets currently exist
///
//******************************************************
void CATECal::CopyRTChanOffsetStatus(void) {
	UCHAR chanNo;
	for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
		AISavedCJChanRTOffsets[chanNo] = AICJChanRTOffsets[chanNo];
		AICJValidSavedChanRTOffset[chanNo] = AICJValidChanRTOffset[chanNo];
	}
}
//******************************************************
///
/// Defaults all channels to ensure that no channel offsets currently exist
///
//******************************************************
void CATECal::ResetRTChanOffsetStatus(void) {
	UCHAR chanNo;
	for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
		AICJValidChanRTOffset[chanNo] = FALSE;
		AICJValidSavedChanRTOffset[chanNo] = FALSE;
	}
}
//******************************************************
///
/// Stores a CJ channel temperature offset for a given channel
/// @param[in] CJdifference - The I/O card channel temperature difference from the CJC.
///
/// @return TRUE if the given card could be selected; otherwise FALSE
///
//******************************************************
void CATECal::StoreCalcRTChanOffset(UCHAR chanNo, float CJdifference) {
	AISavedCJChanRTOffsets[chanNo] = CJdifference;
	AICJValidSavedChanRTOffset[chanNo] = TRUE;
}
//******************************************************
///
/// Stores a CJ channel temperature offset for a given channel
/// @param[in] CJdifference - The I/O card channel temperature difference from the CJC.
///
/// @return TRUE if the given card could be selected; otherwise FALSE
///
//******************************************************
void CATECal::StoreRTChanOffset(UCHAR chanNo, float CJdifference) {
	AICJChanRTOffsets[chanNo] = CJdifference;
	AICJValidChanRTOffset[chanNo] = TRUE;
}
//******************************************************
///
/// Obtains a CJ channel temperature offset for a given channel
/// @param[out] pCJdifference - The I/O card channel temperature difference from the CJC.
///
/// @return TRUE if offset is available; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetRTChanOffset(UCHAR chanNo, float *pCJdifference) {
	BOOL retValue = FALSE;
	retValue = AICJValidChanRTOffset[chanNo];
	if (retValue == TRUE)
		*pCJdifference = AICJChanRTOffsets[chanNo];
	return retValue;
}
//******************************************************
///
/// Sets the card slot number of the board currently being tested
/// @param[in] slotNo - The I/O card slot number.
///
/// @return TRUE if the given card could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SelectATECardNo(const UCHAR slotNo) {
	class CBrdStats *pBrdStatsObj = NULL;
	BOOL retValue = FALSE;
	pBrdStatsObj = CBrdStats::GetHandle();
	m_runtimeUpdated = TRUE;
	m_cardSlot = slotNo;
	if (pBrdStatsObj != NULL) {
		pBrdStatsObj->SetCardBeingCalibrated(m_cardSlot);
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
///
/// Gets the card slot number of the board currently being tested
///
/// @return The I/O card slot number.
///
//******************************************************
UCHAR CATECal::QueryATECardNo(void) const {
	return m_cardSlot;
}
//******************************************************
///
/// Gets the number of channels on the card in the slot number previously set
/// as the one being tested
///
/// @return The number of channels on the I/O card.
///
//******************************************************
UCHAR CATECal::QueryATECardNoOfChannel(void) const {
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	UCHAR noOfChans = 0;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if ((pBrdInfoObj != NULL) && (QueryATECardNo() != ILLEGAL_CARD_SELECTED)) {
		noOfChans = pBrdInfoObj->GetNoOfChannels(QueryATECardNo());
	}
	return noOfChans;
}
//******************************************************
///
/// Sets the digital board Output pulse direction
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] pulseDirection - The Output pulse direction
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetDigBoardCfgOutputPulseDirection(const USHORT chanNo, const UCHAR pulseDirection) {
	m_cfgDigPulse.CfgChan[chanNo].PulseDirection = pulseDirection;
	m_setupUpdated = TRUE;
	return TRUE;
}
//******************************************************
///
/// Sets the digital/pulse board input acqusition rate (enum)
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] acqRate - The input acqusition rate (enum)
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
/// @Note: Also sets current input to be pulse
//******************************************************
BOOL CATECal::SetPulseBoardCfgAcqRate(const USHORT chanNo, const UCHAR acqRateEnum) {
	m_cfgDigPulse.CfgChan[chanNo].PulseIn = TRUE;
	m_cfgDigPulse.CfgChan[chanNo].DigOut = FALSE;
	m_cfgDigPulse.CfgChan[chanNo].DigIn = FALSE;
	m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.acqEnum = acqRateEnum;
	m_setupUpdated = TRUE;
	return TRUE;
}
//******************************************************
///
/// Sets the digital board channel as an output
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] failSafe - Whether the output is failsafe or not
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetDigBoardCfgOutput(const USHORT chanNo, const BOOL failSafe) {
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	m_cfgDigPulse.CfgChan[chanNo].DigOut = TRUE;
	m_cfgDigPulse.CfgChan[chanNo].PulseIn = FALSE;
	m_cfgDigPulse.CfgChan[chanNo].DigIn = FALSE;
	m_cfgDigPulse.CfgChan[chanNo].FailSafe = failSafe;
	pBrdInfoObj->SetSelectedChannelType(m_cardSlot, chanNo, CHANNEL_DO);
	m_setupUpdated = TRUE;
	m_OPUpdated = TRUE;
	return TRUE;
}
//******************************************************
///
/// Sets the digital board channel as an input
/// @param[in] chanNo - The I/O card channel number.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetDigBoardCfgInput(const USHORT chanNo) {
	class CBrdInfo *pBrdInfoObj = NULL;
	class CBrdStats *pBrdStatsObj = NULL;
	class CSlotMap *pSlotMap = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	m_cfgDigPulse.CfgChan[chanNo].DigIn = TRUE;
	m_cfgDigPulse.CfgChan[chanNo].PulseIn = FALSE;
	m_cfgDigPulse.CfgChan[chanNo].DigOut = FALSE;
	pBrdInfoObj->SetSelectedChannelType(m_cardSlot, chanNo, CHANNEL_DI);
	if ((IsRunningAsATEEquipment() == TRUE) || (pBrdStatsObj->HasLimitedRunModeBeenOrderedOnCard(m_cardSlot) == TRUE)) {
		pSlotMap = CSlotMap::GetHandle();
		// If running in ATE mode then force reset the digital input value
		if (pSlotMap != NULL)
			SetDigBoardOutputState(pSlotMap->GetSysChannelFromDigIOChannel(m_cardSlot, chanNo, ONE_BASED), TRUE, FALSE);
		m_setupUpdated = TRUE;
	}
	return TRUE;
}
//******************************************************
///
/// Sets the AO board channel to a value
/// @param[in] chanNo - The I/O card channel number.
///
/// @return TRUE if the given output could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetAOChan(const USHORT chanNo, const USHORT setting) {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	if (setting > pBrdInfo->HighestAllowedmAOutput(m_cardSlot, TRUE))
		retValue = FALSE;
	if (pBrdInfo == NULL) {
		retValue = FALSE;
	} else {
		if (chanNo > pBrdInfo->GetNoOfChannels(m_cardSlot))
			retValue = FALSE;
		if (pBrdInfo->WhatBoardType(m_cardSlot) != BOARD_AO)
			retValue = FALSE;
		if (retValue != FALSE) {
			m_DirectOP = TRUE;
			m_AODirectOP[chanNo] = setting;
			m_OPUpdated = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Gets the AI board CJ value
///
/// @return The reading of the CJ in deg C
///
//******************************************************
float CATECal::GetAICJReading(void) const {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
#ifdef USE_DATA_ITEM_TABLE
  class CDataItem *pDataItem = NULL;
#endif
	BOOL Success = FALSE;
	USHORT CJCNo = 0;
	USHORT CJCDegCNo = 0;
	float CJCValue = 0.0F;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		if ((pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_AI) || (pBrdInfo->WhatBoardType(m_cardSlot) == BOARD_EZ_AI)) {
#ifdef USE_DATA_ITEM_TABLE
  pSlotMap = CSlotMap::GetHandle();
  if( pSlotMap != NULL )
  {
  if( pSlotMap->ObtainBoardsDICJCRef( m_cardSlot, &CJCNo, &CJCDegCNo ) == TRUE )
  {
  pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCDegCNo);
  if( pDataItem != NULL )
  {
  if( pDataItem->GetStatus() == DISTAT_NORMAL)
  {
  CJCValue = pDataItem->GetFPValue();
  Success = TRUE;
  }
  else
  CJCValue = 0.0F;
  }
  }
  }
#else
			CJCValue = pBrdInfo->GetDegCCJCReading(m_cardSlot);
			Success = TRUE;
#endif
		}
	}
	if (Success == FALSE) {
		LogInternalError("Could not get internal handles or wrong board type for CJC Reading");
	}
	return CJCValue;
}
//******************************************************
///
/// Gets all digital channel states (only valid for channels set as digital input)
///
/// @return Digital in state bit mask
///
//******************************************************
USHORT CATECal::GetDigitalInState(void) const {
	return DigitalInChanState;
}
//******************************************************
//  ScheduleChannelStatusCheck()
///
/// Schedules channel status download.
///
/// @return TRUE if successfully scheduled
///
//******************************************************
BOOL CATECal::ScheduleChannelStatusCheck(void) {
	m_StatusCheckRqd = TRUE;
	return m_StatusCheckRqd;
}
//******************************************************
//  ScheduleChannelStatusCheck()
///
/// Schedules channel status download.
///
/// @return TRUE if successfully scheduled
///
//******************************************************
BOOL CATECal::IsChannelStatusCheckScheduled(void) {
	return m_StatusCheckRqd;
}
//******************************************************
///
/// Gets the AO board channel to a value
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] pSetting - The I/O card channel setting in mA's.
///
/// @return TRUE if the given output could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAOChan(const USHORT chanNo, USHORT *pSetting) {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CDataItem *pDataItem = NULL;
	class CPPIOServiceManager *pServiceMngr = NULL;
	class CInputConditioning *pCond = NULL;
	UCHAR sysChanNo = 0;
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	pServiceMngr = CPPIOServiceManager::GetHandle();
	if (pServiceMngr != NULL)
		pCond = pServiceMngr->GetICService();
	if ((pBrdInfo == NULL) || (m_DirectOP == FALSE)) {
		retValue = FALSE;
	} else {
		if (chanNo > pBrdInfo->GetNoOfChannels(m_cardSlot))
			retValue = FALSE;
		if (pBrdInfo->WhatBoardType(m_cardSlot) != BOARD_AO)
			retValue = FALSE;
		if (retValue != FALSE) {
			m_DirectOP = FALSE;
			pSlotMap = CSlotMap::GetHandle();
			if (pSlotMap != NULL) {
				m_DirectOP = TRUE;
				sysChanNo = pSlotMap->GetSysChannelFromAnaOutChannel(m_cardSlot, chanNo, ONE_BASED);
				pDataItem = pDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, sysChanNo - 1);
//				*psetting = pDataItem->GetFPValue( );
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Sets the AO board channel to a user defined mA value
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] setting - The I/O card channel value in mA's.
///
/// @return TRUE if the given output could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetAOChan(const USHORT chanNo, const float setting) {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CDataItem *pDataItem = NULL;
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	USHORT AOOutput;
	UCHAR sysChanNo = 0;
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if ((pBrdInfo != NULL) && (pServiceManagerObj != NULL))
		pICService = pServiceManagerObj->GetICService();
	if (pICService == NULL) {
		retValue = FALSE;
	} else {
		if (chanNo > pBrdInfo->GetNoOfChannels(m_cardSlot))
			retValue = FALSE;
		if (pBrdInfo->WhatBoardType(m_cardSlot) != BOARD_AO)
			retValue = FALSE;
		if (retValue != FALSE) {
			m_DirectOP = FALSE;
			pSlotMap = CSlotMap::GetHandle();
			if (pSlotMap != NULL) {
				m_DirectOP = TRUE;
				sysChanNo = pSlotMap->GetSysChannelFromAnaOutChannel(m_cardSlot, chanNo, ONE_BASED);
				pDataItem = pDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, sysChanNo - 1);
				AOOutput = pICService->ConvertDVMAmpsToAOCount(setting);
				pDataItem->SetValue(static_cast<float>(setting));
				if (setting > pBrdInfo->HighestAllowedmAOutput(m_cardSlot, TRUE))
					retValue = FALSE;
				else {
					m_AODirectOP[chanNo] = AOOutput;
					m_OPUpdated = TRUE;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Gets the AO board channel user defined mA value
/// @param[in] chanNo - The I/O card channel number.
///
/// @return TRUE if the given output could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetAOChan(const USHORT chanNo, float *pSetting) {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CDataItem *pDataItem = NULL;
	UCHAR sysChanNo = 0;
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		if (chanNo > pBrdInfo->GetNoOfChannels(m_cardSlot))
			retValue = FALSE;
		if (pBrdInfo->WhatBoardType(m_cardSlot) != BOARD_AO)
			retValue = FALSE;
		if (retValue != FALSE) {
			pSlotMap = CSlotMap::GetHandle();
			if (pSlotMap != NULL) {
				sysChanNo = pSlotMap->GetSysChannelFromAnaOutChannel(m_cardSlot, chanNo, ONE_BASED);
				pDataItem = pDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, sysChanNo - 1);
				if (pDataItem != NULL) {
					*pSetting = static_cast<USHORT>(pDataItem->GetFPValue());
					retValue = TRUE;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Sets a digital output channel state
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] force - TRUE if inputs to be force; otherwise FALSE.
/// @param[in] digiState - TRUE if the output is set.
///
/// @return TRUE if the given output could be selected; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetDigBoardOutputState(const USHORT chanNo, const BOOL force, const BOOL digiState) {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CDataItem *pDataItem = NULL;
	UCHAR channelType;
	UCHAR sysChanNo = 0;
	BOOL retValue = FALSE;
	if (force == TRUE) {
		channelType = CHANNEL_DI;
	} else {
		channelType = CHANNEL_DO;
	}
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		// Channel type must be a digital output
		if (pBrdInfo->WhatSelectedChannelType(m_cardSlot, chanNo) == channelType) {
			pSlotMap = CSlotMap::GetHandle();
			if (pSlotMap != NULL) {
				sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(m_cardSlot, chanNo, ONE_BASED);
				pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo - 1);
				if (pDataItem != NULL) {
					pDataItem->SetValue(static_cast<float>(digiState));
					m_OPUpdated = TRUE;
					retValue = TRUE;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Gets a digital channel output state
/// @param[in] chanNo - The I/O card channel number.
///
/// @return TRUE if the output is set; otherwise FALSE
///
//******************************************************
BOOL CATECal::GetDigBoardActiveState(const USHORT chanNo) {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CDataItem *pDataItem = NULL;
	UCHAR sysChanNo = 0;
	BOOL retValue = TRUE;
	BOOL digiState = FALSE;
	pBrdInfo = CBrdInfo::GetHandle();
	if (pBrdInfo != NULL) {
		// Channel type must be a digital output
		if (pBrdInfo->WhatSelectedChannelType(m_cardSlot, chanNo) == CHANNEL_DO) {
			pSlotMap = CSlotMap::GetHandle();
			if (pSlotMap != NULL) {
				sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(m_cardSlot, chanNo, ONE_BASED);
				pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChanNo - 1);
				if (pDataItem != NULL) {
					digiState = static_cast<BOOL>(pDataItem->GetFPValue());
					retValue = TRUE;
				}
			}
		}
	}
	return digiState;
}
/////////////////////////////////////////////////////
/// Inform the the I/O scheduler that the calibration info has been updated
///
/// @return TRUE if the request was successfully processed; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CATECal::NotifyCalOrSetupChange(void) {
	T_MMMCLIENT_RETURN_VALUE msgStatus = MMMCLIENT_MESSAGE_COMPLETED;
	BOOL noTimeOutReached = FALSE;
	//commit the setup to the Module message manager, using the registered consumer
	msgStatus = m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
	INFINITE, MODULE_IO_SCHEDULER, m_ModuleID, MOD_CAL_INFO_UPDATED, 0,
	NULL);
	// Test for commit accepted, succesful or timeout reached
	if (msgStatus == MMMCLIENT_MESSAGE_COMPLETED)
		noTimeOutReached = TRUE;
	return noTimeOutReached;
}
//****************************************************************************
/// Posts a message to wait for the control sequencer to shut down
///
//****************************************************************************
void CATECal::CalibrationFinishShutDown(void) {
	// Post a message to the MMM to shut down the control sequencer, using the registered consumer
	m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
	INFINITE, MODULE_CONTROL_SEQUENCER, m_ModuleID, MOD_SYSTEM_SHUTDOWN, 0,
	NULL);
}
//****************************************************************************
/// Posts a message to inform ATE module that readings are available
///
//****************************************************************************
void CATECal::InformCalibrationReadingsAvailable(void) {
	m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
	INFINITE, m_ModuleID, MODULE_IO_SCHEDULER, MOD_ATE_ALL_CHANNELS_READY, 0,
	NULL);
}
//**********************************************************************
/// Registers the ATE Cal with a consumer
/// @param[in] Consumer - The module to be registered with.
/// @param[in] moduleNotification - The module notification type.
///
/// @return TRUE if module is succesfully registered (or nor required to be registered); otherwise FALSE
///
//**********************************************************************
BOOL CATECal::RegisterWithCalibrationHolder(CModuleMsgManagerClient &Consumer, const T_MODULE_ID moduleID,
		const T_MODULE_MSG_NOTIFICATION moduleNotification) {
	BOOL retValue = TRUE;
	m_ModuleMsgManagerClient = Consumer;
	m_ModuleID = moduleID;
	if (IsRunningAsATEEquipment() == TRUE) {
		// Register with the MMM - either allowing us to be triggered on an event or not as required
		if (m_ModuleMsgManagerClient.MMMClientRegister(moduleID, moduleNotification, CAMQ_QUEUE_WRAP_DISABLED)
				!= MMMCLIENT_REGISTRATION_SUCCESSFUL)
			retValue = FALSE;
	}
	return retValue;
}
#define CALIBRATION_ATTEMPT_TIMEOUT		6000
//******************************************************
//
/// Calibrate one or more channels for a given range.
/// @param[in] spanPoint -	TRUE if the span point is being calibrated;
///							otherwise zero point being calibrated.
/// @param[in] chanMask -	The channel selection mask.
///
/// @return TRUE if successful; otherwise FALSE
///
//******************************************************
BOOL CATECal::PerformBoardRangeCal(const BOOL spanPoint, const USHORT chanMask) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	BOOL retValue = FALSE;
	BOOL allChannelsRead = FALSE;
	BOOL timeout = FALSE;
	CTV6Timer transTimer(TIMER_NORMAL_RES);	 	 // Total time attempting to get readings
	UCHAR chanNo = 0;
	pBrdStatsObj = CBrdStats::GetHandle();
	// Start card transaction timer
	transTimer.ResetAllTimers();
	transTimer.StartTimer();
	// Clear the data buffer on the AI card
	NoAIChanRawReadingsTaken();
	do {
		if ( FALSE == spanPoint) {
			allChannelsRead = ReadAnalogueInChannelValues(chanMask);			// Get some readings
			if (allChannelsRead == TRUE) {
				retValue = AIStoreChannelCalPoints(chanMask, FALSE, NULL);			// Calibrate zero point
				if ((TRUE == retValue) && (CheckUserCalibration() == true)) {
					// Save the calibration data, only the user has not been warned on incorrect calibration
					retValue = CommitBoardUserCal(chanMask);
				}
			}
		} else {
			allChannelsRead = ReadAnalogueInChannelValues(chanMask);			// Get some readings
			if ( TRUE == allChannelsRead) {
				retValue = AIStoreChannelCalPoints(chanMask, TRUE, NULL);			// Calibrate span point
			}
		}
		if ((transTimer.ElapsedTimeInMilliSeconds()) > CALIBRATION_ATTEMPT_TIMEOUT)
			timeout = TRUE;
	} while ((timeout != TRUE) && (allChannelsRead != TRUE));
//	if( (retValue == TRUE) && (allChannelsRead == TRUE) )
//	{
	//Commit the Cal Values
//		NotifyCalOrSetupChange();
//	}
	return retValue;
}
//******************************************************
//
/// Commit the selected channel user calibrated points.
/// @param[in] chanMask -	The channel selection mask.
///
/// @return TRUE if successful; otherwise FALSE
///
//******************************************************
BOOL CATECal::CommitBoardUserCal(const USHORT chanMask) {
//	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	BOOL retValue = FALSE;
//	pBrdStatsObj = CBrdStats::GetHandle();
	// Commit the user calibration data to the AI board
	retValue = CommitUserCalRange(chanMask);
	if (retValue == TRUE)
		retValue = NotifyCalOrSetupChange();
//	pBrdStatsObj->CancelLimitedRunMode();
	return retValue;
}
//******************************************************
//  SetLimitedRunMode()
///
/// Instructs the I/O scheduler to enter limited run mode (for calibration).
///
/// @return TRUE if limited mode is succesfully instructed; otherwise FALSE
///
//******************************************************
BOOL CATECal::SetLimitedRunMode(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	BOOL retValue = FALSE;
	pBrdStatsObj = CBrdStats::GetHandle();
	if (pBrdStatsObj != NULL) {
		// Allow the I/O scheduler to run again, but in restricted mode
		pBrdStatsObj->SetLimitedRunMode();
		pBrdStatsObj->CancelIdleMode();
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
//
/// Performs the initialisation for calibrating one or more channels for a given range.
/// @param[in] cardNo - The I/O card slot number to calibrate.
/// @param[in] range - The I/O card range to calibrate.
/// @param[in] chanMask - The channel selection mask.
///
/// @return TRUE if successful; otherwise FALSE
///
/// @Note requires ATE card to be selectde before calling
//******************************************************
BOOL CATECal::InitialiseBoardRangeCalMode(const USHORT range, const USHORT chanMask) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	BOOL retValue = FALSE;
	UCHAR chanNo = 0;
	// Connect to the relevant service, if not already connected
	pBrdStatsObj = CBrdStats::GetHandle();
	m_chanMask = chanMask;
	// Already in 'restricted' calibration mode, but need to register the current card is the one being calibrated
	SetCalModeState(CTOM_ATE_READ);
	EnableAllCardChannels();
	SetToCalibrateMode();
	// Select the required range, precision & raw mode for each selected channel
	for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
		if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
			// Calibrating channel, so set correct options
			DefaultChannel(chanNo);
			SelectAIChanVoltageRange(chanNo, range);
			SelectAIChanAcqRate(chanNo, AI_ACQ_RATE_2HZ);
			SetRawReadingMode(chanNo, TRUE);
		} else {
			// Not calibrating, so set to safe range just in case it is wired to the calibrator too -
			// no need for other changes
			SelectAIChanVoltageRange(chanNo, LINEAR_VOLTS_12V);
		}
	}
	// Commit the configuration to this single board
	retValue = NotifyCalOrSetupChange();
	// Release IOScheduler from idle mode and place into limited run mode
	pBrdStatsObj->CancelIdleMode();
	pBrdStatsObj->SetLimitedRunMode();
	return retValue;
}
//******************************************************
///
/// Obtains the channel calibrate mask for a given range for the card currently
/// being calibrated
/// @param[in] Range - The I/O card range to calibrate.
///
/// @return The channel mask of those channels selected for calibration
///
//******************************************************
USHORT CATECal::CreateChanMaskFromAIBoardCalInfo(const USHORT range) {
	T_IORANGECAL *pIORangeCal = NULL;
	USHORT chanNo = 0;
	USHORT chanMask = 0;
	pIORangeCal = GetAIBoardCalInfo(m_cardSlot, range);
	for (chanNo = 0; chanNo < QueryATECardNoOfChannel(); chanNo++) {
		// Only calibrate if the user mode is selected and recalibration is selected
		if (pIORangeCal->Channel[chanNo] == CInputConditioning::V6_IO_USER_AND_RECALIBRATE)
			SetBits(&chanMask, 1, chanNo, 1);
	}
	return chanMask;
}
//******************************************************
///
/// Queries whether I/O board has failed due to returned errors
/// @param[in] slotNo - The I/O card slot number.
/// @param[in] errorLevel - The I/O card error level.
///
/// @return TRUE if I/O board has failed; otherwise FALSE
///
//******************************************************
void CATECal::SetIOCardCommsErrorReported(UCHAR slotNo, T_COMMS_ERR_STATUS_SUMMARY errorLevel) {
	if (static_cast<UCHAR>(m_slotCommsError[slotNo]) > static_cast<UCHAR>(m_commsError))
		m_slotCommsError[slotNo] = errorLevel;
	if (static_cast<UCHAR>(errorLevel) > static_cast<UCHAR>(m_commsError))
		m_commsError = errorLevel;
}
//******************************************************
///
/// Queries the level of I/O board failure due to returned errors
///
/// @return TRUE if I/O board has failed; otherwise FALSE
///
//******************************************************
T_COMMS_ERR_STATUS_SUMMARY CATECal::QueryIOCardCommsErrorReported() {
	return m_commsError;
}
//******************************************************
///
/// Performs a single range calibrate on the channels selected in the channel mask
/// @param[in] cardNo - The I/O card slot number to calibrate.
/// @param[in] Range - The I/O card range to calibrate.
/// @param[in] spanPoint -	TRUE if the span point is being calibrated;
///							otherwise zero point being calibrated.
/// @param[in] chanMask - The channel selection mask.
/// @param[out] Instruction - The operator instructions.
///
/// @return TRUE if range successfully calibrated; otherwise FALSE
///
//******************************************************
BOOL CATECal::ManualRangeCalibrate(const USHORT cardNo, const USHORT Range, const BOOL spanPoint, const USHORT chanMask,
		QString &Instruction) {
	class CBrdInfo *pBrdInfo = NULL;
	T_RANGE UpperCalPoint;
	T_RANGE LowerCalPoint;
	IO_MEASURE_UNITS RangeUnits;			///< Range units
	float CalPoint;
	USHORT chanCount;
	USHORT chanNo = 0;
	QString chanMap;
	BOOL firstChannelFound = FALSE;
	BOOL retValue = FALSE;
	m_cardSlot = static_cast<UCHAR>(cardNo);
	// Get the maximum channel count
	pBrdInfo = CBrdInfo::GetHandle();
	chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
	// Get the calibration point
	retValue = GetChannelCalPoints(Range, &UpperCalPoint, &LowerCalPoint, &RangeUnits);
	if (retValue == TRUE) {
		// Instruct the user to connect the relevant channels and set the relevant span or zero voltage
		if (spanPoint == TRUE)
			CalPoint = static_cast<float>(UpperCalPoint);
		else
			CalPoint = static_cast<float>(LowerCalPoint);
		// Build the channel list on the end of the string
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			if (GetBits(chanMask, chanNo, 1) != CHANNEL_NOT_SELECTED) {
				if (firstChannelFound == TRUE) {
					chanMap = QString::asprintf(", %d", chanNo + 1);
					Instruction += chanMap;
				} else {
					// Annotate with the appropriate engineering units, for range selected
					if (RangeUnits == MILLI)
						Instruction = QString::asprintf(L"Apply %fmV to channels", CalPoint);
					else
						Instruction = QString::asprintf(L"Apply %fV to channels", CalPoint);
					chanMap = QString::asprintf(" %d", chanNo + 1);
					Instruction += chanMap;
					firstChannelFound = TRUE;
				}
			}
		}
		// Ensure that report also includes report if no ligal channels are selected
		if (firstChannelFound == FALSE) {
			// Set no I/O card channels selected
			Instruction = QString::asprintf("No I/O channels selected");
			retValue = FALSE;
		}
	} else {
		// Set unknown range error text
		Instruction = QString::asprintf("Do not know how to calibrate selected range");
		retValue = FALSE;
	}
	return retValue;
}
#define CHAN_READING_READY 2000
/////////////////////////////////////////////////////
/// Automatically calibrate each card channel offset to the CJC sensor
/// @param[in/out] pTempSetPoint - The temperature at which calibration is being performed.
///
/// @return The current status of CJC auto calibrate
/////////////////////////////////////////////////////
BOOL CATECal::AIAutoCalibrateCJC(float TempSetPoint) {
	class CBrdInfo *pBrdInfo = NULL;			///< Slot map holder
	UCHAR chanCount;
	BOOL retValue = TRUE;
	pBrdInfo = CBrdInfo::GetHandle();
	chanCount = pBrdInfo->GetNoOfChannels(m_cardSlot);
	sleep( CHAN_READING_READY);
	// Read Channel 1 temp via channel 2
	// If at least 4 channels on AI board (there should always be)
	if (chanCount > 3) {
		// Read Channel 4 temp via channel 3
	}
	// If at least 6 channels on AI board
	if (chanCount > 5) {
		// Read Channel 5 temp via channel 6
		// Need to calculate channel 6's value separately;
		// we have not got the last channel reading so need to project
	}
	// If at least 8 channels on AI board
	if (chanCount > 7) {
		// Read Channel 8 temp via channel 7
	}
	// Calculate scale between 1st block of four channels; always at least 4 channels
	if (chanCount == 8) {
		// If fully populated board, then calculate scale between 2nd block of four channels
	} else if (chanCount == 6) {
		// Need to project channels 5 temperature onto channel 6 using the profile from channels 1 - 4
	}
	return retValue;
}
//****************************************************************************
//  void RegisterMMC()
///
/// Method that registers the module message manager client
///
//****************************************************************************
void CATECal::RegisterMMC() {
	m_ModuleMsgManagerClient.MMMClientRegister(MODULE_ATE_CAL, MODULE_USE_EVENT, CAMQ_QUEUE_WRAP_DISABLED);
	m_ModuleID = MODULE_ATE_CAL;
}

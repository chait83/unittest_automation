/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PPIOServiceManager.h
/// @n Desc:	interface for the pre-process I/O service manager
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 11	Stability Project 1.8.1.1	7/2/2011 4:59:46 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 10	Stability Project 1.8.1.0	7/1/2011 4:27:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 9	V6 Firmware 1.8		8/17/2006 8:21:22 PM	Graham Waterfield
//		Allow user linearisattion tables to be commited without the need to
//		restart the recorder
// 8	V6 Firmware 1.7		10/12/2005 7:18:21 PM Graham Waterfield
//		Provide outside of linerisation table error code & ensure AO channels
//		work if all retransmitting the same value
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PPIOSERVICEMANAGER_H
#define _PPIOSERVICEMANAGER_H
#if !defined(AFX_PPIOSERVICEMANAGER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PPIOSERVICEMANAGER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#include "PassiveModule.h"
#include "Defines.h"
#include <QMutex>
class CPPIOServiceManager: public CPassiveModule {
public:
	static CPPIOServiceManager* GetHandle();
	void CleanUp();
	void Initialise(void);
	BOOL InitialiseServiceManager(void);
	BOOL CommitServiceManager(void);
//		void SetupConfigChangeComplete( void );
	class CPPDICard* GetDIService(void) const;
	class CPPPulseChannel* GetPulseService(void) const;
	class CPPDOChannel* GetDOService(void) const;
	class CPPAOChannel* GetAOService(void) const;
	class CPPAIChannel* GetAIService(void) const;
	class CInputConditioning* GetICService(void) const;
	BOOL ResetAllPPQsToDefault(void);
private:	// Singleton
	CPPIOServiceManager();
	CPPIOServiceManager(const CPPIOServiceManager&);
	CPPIOServiceManager& operator=(const CPPIOServiceManager&) {
		return *this;
	}
	;
	~CPPIOServiceManager();
	static CPPIOServiceManager *m_pInstance;
	static QMutex m_CreationMutex;
	class CPPAIChannel *m_pAIChanHandler;
	class CPPAOChannel *m_pAOChanHandler;
	class CPPDOChannel *m_pDOChanHandler;
	class CPPPulseChannel *m_pPulseChanHandler;
	class CPPDICard *m_pDICardHandler;
	class CInputConditioning *m_pInputConditioning;
};
#endif // !defined(AFX_PPIOSERVICEMANAGER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _PPIOSERVICEMANAGER_H

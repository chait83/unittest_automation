//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AICard.h
/// @n interface for the AI card class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 71	Stability Project 1.68.1.1	7/2/2011 4:55:16 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 70	Stability Project 1.68.1.0	7/1/2011 4:27:03 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 69	V6 Firmware 1.68		4/25/2007 4:10:38 PM	Graham Waterfield
//		Correct issue to allow correct channel startup delay for ohms & RT's
// 68	V6 Firmware 1.67		1/12/2007 2:06:42 PM	Graham Waterfield
//		Increase setup commit timeout to allow for addition of LCM recovery.
//		Also split acqusition schedule so that more lower speed channels can
//		be acquired together.
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _AICARD_H
#define _AICARD_H
#include "DataItemBase.h"
#include "PPL.h"
#include "Defines.h"
#include "IOCard.h"
#include "AIConfig.h"
#include "CMMDefines.h"
#include "V6Config.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define MAX_AI_BOARD_CHANNELS	TOPSLOT_AICHAN_SIZE		///< Max AI channels on a board
#define INVALID_RANGE			0xFF	///< Invalid channel range
#define INVALID_CHANNEL			0xFF	///< Invalid channel
#define TOTAL_AI_BOARD_PRIORITIES		2
#define T_RANGE		float		///< Range type
struct ChanActionPendingFlags_t {
	UCHAR RTCal :1;			///< TRUE if RTCal read pending 
	UCHAR RTComp :1;			///< TRUE if RTComp read pending
	UCHAR RdPending :1;			///< TRUE if channel reading pending
	UCHAR RdTaken :1;			///< TRUE if channel reading just taken
	UCHAR Unused :4;			///< Unused for future use
};
struct ChanAction_t {
	// RTCal, RTComp & CJC performed on demand
	// Reading is scheduled on a time basis
	double RdInterval;
	LONGLONG RdLastScheduledTime;
	LONGLONG RdNextScheduledTime;
	struct ChanActionPendingFlags_t ChannelPending;
};
#define NO_MONITOR_BANKS_ON_STARTUP		1
#define AQUIRE_HOLDER					0
typedef struct _cardList {
	UCHAR ChanList[MAX_AI_BOARD_CHANNELS];			///< List of primary channels that require startup
	UCHAR Count;						///< Number of primary elements in list
} CARDLIST;
typedef struct _startupList {
	BOOL startUpNeeded;							///< TRUE if startup is needed
	BOOL startupCompleted;						///< Startup sequence completed
	CARDLIST ChanList[NO_MONITOR_BANKS_ON_STARTUP];	///< List of channels that require monitoring startup
} STARTUPLIST;
struct AIPending_t {
	USHORT CommandModeToProc;		// Board mode selection / recovery command
//	struct BoardActionPendingFlags_t Board;				// Board actions pending for state machine
	struct ChanAction_t Channel[MAX_AI_BOARD_CHANNELS];	// Channel actions pending for state machine
};
class CAICard: public CIOCard {
	// Allow the protocol to query boards
	friend class CProtocol;
public:
	virtual BOOL RunProcess(void);
	BOOL ScheduleBoardProcess(void);
	BOOL ScheduleNextChannelProcess(void);
//		BOOL Initialise(void);
//		BOOL InitialiseCardConfigHolder(void);
	virtual BOOL InitialiseCard(const USHORT cardNo);
	BOOL SetupConfigChangePreparation(void);
	virtual IOCARDSTAT IOCardCommand(const USHORT newCmd);
	virtual BOOL SetSpecialTestMode(const BOOL state);
	virtual BOOL InitialiseCardConfig(void);
	virtual USHORT CalculateChannelReadRate(const UCHAR chanNo);
	virtual USHORT GetChannelAcqRate(const UCHAR chanNo) const;
	virtual BOOL DoesBoardRqSched(void);
	virtual USHORT ChannelsToService(void);
	virtual BOOL CMMCreateLocalConfig(void);
	virtual void GetIOCardStrID(QString *pIDText) const;
	virtual void GetIOCardStrDescription(QString *IDText);
	virtual BOOL GetIOLifeHistory(class CProtocol *const pProtocol);
	BOOL SaveIOLifeHistory(class CProtocol *const pProtocol);
	class CAIConfig* GetLocalConfigHandle(void);
	// Get card channel capabilities
	CAICard(USHORT CardSlotID);
	virtual ~CAICard();
	// AI error board status update
	BOOL ReportCJCFailureRecovery( USHORT usBoardNo);
	BOOL ReportCJCFailureDiagnostics( USHORT usBoardNo);
	BOOL FailBoardCJC(void);
	// Schedule the I/O board comms state machine on next run-time
	BOOL ScheduleCJCDownload(void);
	BOOL ScheduleRTCalDownload(void);
	BOOL ScheduleRTCompDownload(void);
	BOOL ScheduleFactoryCalUpload(void);
	BOOL ScheduleUserCalUpload(void);
	BOOL ScheduleActBrnStatusDownload(void);
	// Check & set RT cal & comp times
	void SetLastRTCalReadTime(UCHAR chanNo, LONGLONG timeRead);
	void SetLastRTCompReadTime(UCHAR chanNo, LONGLONG timeRead);
	BOOL CheckLastRTCalReadTime(LONGLONG timeNow);
	BOOL CheckLastRTCompReadTime(LONGLONG timeNow);
	BOOL GetAnalRTCalChan(const USHORT cardNo, UCHAR *pChanNo) const;
	BOOL GetAnalRTCompChan(const USHORT cardNo, UCHAR *pChanNo) const;
	// Methods to provide RT & ohms startup processing delay
	BOOL EmptyStartupList();
	BOOL IsStartupListEmpty();
	BOOL RemoveChannelFromStartupList(const UCHAR listTypeNo, const UCHAR boardChanNo);
	BOOL GenerateChannelStartupList();
	BOOL IsStartupSeqRqd();
	void StartupSeqCompleted();
	USHORT QueryAnySlotChannelEnabled(void) const;
	void ResetRawVoltageReadings(void);
	BOOL ProcessMissingAnalBlockTransfer(LONGLONG time);
	// Get board revision range capabilities
	UCHAR GetRangeClosestMatch(const UCHAR RangeRev, const UCHAR RangeType, const T_RANGE UpperRange,
			const T_RANGE LowerRange, const USHORT engUnits) const;
	T_PAIRANGEDEF GetChannelRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev, T_RANGE *const pUpperRange,
	T_RANGE *const pLowerRange) const;
	BOOL GetRangeConfig(T_PAIRANGE pRangeCode, const UCHAR RangeRev, UCHAR *pRangeGain, UCHAR *pRangeUnits) const;
	T_PAIRANGEDEF GetChannelCalPoints(T_PAIRANGE pRangeCode, const UCHAR RangeRev, T_RANGE *pUpperRange,
	T_RANGE *pLowerRange, IO_MEASURE_UNITS *pUnits) const;
	UCHAR GetRangeRevision(const UCHAR boardType, const UCHAR BoardRev) const;
	BOOL QueryIsChanATC(const USHORT chanNo) const;
//		BOOL CheckUserCalibration( );
	BOOL GetChannelConfigRef(const UCHAR ChanNo, T_AICFGCHANNEL **ppChanCfgInfo,
			T_AIWRKCHANNELCFG **ppChanWrkInfo) const;
	BOOL AIAutoCalibrateCJC(void);
	void ResetRTReadingState(void);
	BOOL ResetAICardDataItems();
	void ResetCardChanDataItems(void);
	BOOL ResetCardDataItems(void);
	BOOL GetNextProcessChannel(const UCHAR noOfChans, const USHORT allBitMask, const USHORT processBitMask,
	USHORT &newProcessBitMask) const;
	//AI card has subtypes based on their revision number (V6AI & V7AI)
	virtual UCHAR WhatBoardSubType(void);
	static UCHAR WhatBoardSubType(const UCHAR ucBoardRev);
	static UCHAR WhatIsRawReadingLength(const UCHAR ucBoardSubType);
	void UpdateCJCDataItems(CDataItem *pCJCDataItem, CDataItem *pCJC_C_DataItem, float cjcVal);
protected:
	void ResetStateMachine(void);
	void PrioritizeSchedule(void);
private:
	BOOL PerformSMModeChange(class CProtocol *const pProtocol);
	BOOL OperateTransactionSM(class CProtocol *const pProtocol);
	BOOL UpdateCJCDataItemInvalidStatus(CDataItem *pCJCDataItem, CDataItem *pCJC_C_DataItem);
	class CAIRanges *m_pAIRanges;			///< AI card ranges
	class CAIConfig *m_pAIConfigObj;		///< AI board configuration (allowing fast direct access to configuration)
	struct AIPending_t m_AINormOpPending;			///< AI board state machine pending action run time variables
	class CPPIOServiceManager *m_pServiceManagerObj;		///< Service manager
	class CInputConditioning *m_pICService;	///< Input conditioning service
	BOOL m_CJCFailed;				///< TRUE if CJC has failed otherwise FALSE
	UCHAR m_PriorityScheduleRqd;				///< Priority schedule number being processed
	USHORT m_PriorityChanMask[TOTAL_AI_BOARD_PRIORITIES];///< Mask covering all enabled channels on board for a given priority
	USHORT m_numPartialErrors;//At times the secondary processor is failing. Doing a reset and recovery resulting in Partial Errors.
//		USHORT m_chanAckMask;								///< Channel acknowledge mask
	UCHAR m_chanInitPriority[MAX_AI_BOARD_CHANNELS];				///< Channel priority for cards initialising
	UCHAR m_chanRunPriority[MAX_AI_BOARD_CHANNELS];	///< Channel priority for running cards
	LONGLONG m_AILastRTCalSystemTick[MAX_AI_BOARD_CHANNELS];	///< System tick that RT cal was last saved
	LONGLONG m_AILastRTCompSystemTick[MAX_AI_BOARD_CHANNELS];	///< System tick that RT comp was last saved
	BOOL m_startRTCalCheckRqd[MAX_AI_BOARD_CHANNELS];	///< Startup check of RT Cal required if TRUE
	BOOL m_startRTCompCheckRqd[MAX_AI_BOARD_CHANNELS];	///< Startup check of RT Comp required if TRUE
	STARTUPLIST m_startupList;								///< Startup list
};
#endif // _AICARD_H

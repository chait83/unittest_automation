/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n m_BrdInfo.cpp
/// @n implementation of the CBrdInfo class.
/// Contains all the information detailing a board and its capabilities
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 67	Stability Project 1.62.1.3	7/2/2011 4:55:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 66	Stability Project 1.62.1.2	7/1/2011 4:38:00 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 65	Stability Project 1.62.1.1	3/17/2011 3:20:12 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 64	Stability Project 1.62.1.0	2/15/2011 3:02:19 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "BoardManager.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "CardList.h"
#include "V6IOBoardTypes.H"
#include "BaseProtocol.h"
#include "ATECal.h"
#include "InputConditioning.h"
#include "PPL.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
const UCHAR EarliestEnsure21mARevision[3] = "AK";
const UCHAR EarliestEnsure21mABuild = 7;
bool CBrdInfo::ms_bUseAverageCJC = false;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CBrdInfo::CBrdInfo() {
	USHORT channelNo = 0;
	//	qDebug("Create new CBrdInfo\n");
	for (USHORT cardNo = 0; cardNo < MAXIOCARDS; cardNo++) {
		// Init all board info locations to 0
		memset(&m_BrdInfo[cardNo], 0, sizeof(T_OVERALLBOARDINFO));
		m_BrdInfo[cardNo].infoUploaded = FALSE;
		m_BrdInfo[cardNo].CardType = BOARD_POS_NOT_TESTED;
		m_BrdInfo[cardNo].DateFirstTested = IO_DEFAULT_SERIAL_NUMBER;
		m_BrdInfo[cardNo].DateLastTested = IO_DEFAULT_SERIAL_NUMBER;
		m_BrdInfo[cardNo].Channels = 0;
		// Default all channels
		for (channelNo = 0; channelNo < MAX_IOBOARDCHANS; channelNo++) {
			m_BrdInfo[cardNo].chan[channelNo].ChanSet = CHANNEL_UNKNOWN;
			m_BrdInfo[cardNo].chan[channelNo].ChanCap = CHANNEL_CAP_UNKNOWN;
		}
	}
}
CBrdInfo::~CBrdInfo() {
	// qDebug("Delete CBrdInfo\n");
}
CBrdInfo *CBrdInfo::m_pInstance = NULL;
//**********************************************************************
///
/// Instance creation of CBrdInfo singleton
///
/// @return, , pointer to single instance of CBrdInfo
/// 
//**********************************************************************
CBrdInfo* CBrdInfo::GetHandle() {
	if (NULL == m_pInstance) {
		m_CreationMutex.lock();
		m_pInstance = new CBrdInfo;
		m_CreationMutex.unlock();
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
/// @return, , pointer to single instance of CDeviceAbstraction
//**********************************************************************
void CBrdInfo::CleanUp() {
	if (NULL != m_pInstance) {
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//******************************************************
// WhatBoardType()
///
/// Queries what type of board is in a current slot.
/// @param[in] cardNo - Card slot number identification.
///
/// @return Card slot board type
/// 
//******************************************************
UCHAR CBrdInfo::WhatBoardType(const USHORT cardNo) const {
	if (cardNo < MAX_SCHED_SERVICES)
		return m_BrdInfo[cardNo].CardType;
	return BOARD_INVALID;
}
//******************************************************
// IsAIChannelLinear()
///
/// Queries whether channel type is a linear channel
/// @param[in] chanType - Type of channel being testec.
///
/// @return true if channel is a linear channel; otherwise false
/// 
//******************************************************
const bool CBrdInfo::IsAIChannelLinear(const USHORT chanType) const {
	return (AI_CHANNEL_TYPE_LINEAR_VOLTS == chanType) || (AI_CHANNEL_TYPE_LINEAR_AMPS == chanType)
			|| (AI_CHANNEL_TYPE_LINEAR_OHMS == chanType);
}
//******************************************************
// AIAcqRatePrimaryChannel()
///
/// Queries what type of board is in a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] usBoardChanNo - Card slot number channel number identification.
/// @param[out] pPrimaryChanNo - The primary channel channel number.
/// @param[out] pBankNo - The bank that the channel channel number is part of
///							or BANK_NA if bank is not part of setup.
///
/// @return TRUE if channel acqusition rate can be set up;
///			FALSE if channel acqusistion rate is obtained from another channel
/// 
//******************************************************
BOOL CBrdInfo::AIAcqRatePrimaryChannel(const USHORT cardNo, const USHORT usBoardChanNo, USHORT *pPrimaryChanNo,
USHORT *pBankNo) const {
	BOOL retValue = TRUE;
	*pPrimaryChanNo = usBoardChanNo;
	*pBankNo = BANK_NA;				///< Bank is not applicable
	if (cardNo < MAX_SCHED_SERVICES) {
		if ( BOARD_EZ_AI == m_BrdInfo[cardNo].CardType) {
			// Which bank are we operating on
			if (usBoardChanNo < BANK_2_START_CHANNEL) {
				*pBankNo = static_cast<USHORT>(BANK_1_ID);
				*pPrimaryChanNo = IO_CARD_CHANNEL_1;
				if (IO_CARD_CHANNEL_1 != usBoardChanNo) {
					retValue = FALSE;
				}
			} else {
				*pBankNo = static_cast<USHORT>(BANK_2_ID);
				*pPrimaryChanNo = IO_CARD_CHANNEL_4;
				if (IO_CARD_CHANNEL_4 != usBoardChanNo) {
					retValue = FALSE;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
// GetDegCCJCReading()
///
/// Gets the deg C CJC reading of a current slot.
/// @param[in] cardNo - Card slot number identification.
///
/// @return Card slot board current timebase frequency
///
//******************************************************
float CBrdInfo::GetDegCCJCReading(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].CJCReading;
}
//******************************************************
// SetDegCCJCReading()
///
/// Gets the deg C CJC reading of a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] value - The CJC value to set
///
/// @return Card slot board current timebase frequency
///
//******************************************************
void CBrdInfo::SetDegCCJCReading(const USHORT cardNo, const float value) {
	m_BrdInfo[cardNo].CJCReading = value;
}
//******************************************************
// GetDegCCJCReading()
///
/// Gets the deg C CJC reading of a current slot.
/// @param[in] cardNo - Card slot number identification.
///
/// @return Card slot board current timebase frequency
///
//******************************************************
float CBrdInfo::GetDegCCJCReading(const USHORT cardNo, const USHORT usBoardChanNo) const {
	if (ms_bUseAverageCJC) {
		return m_BrdInfo[cardNo].CJCReading;
	} else {
		int cjcNo = usBoardChanNo / 2;
		return m_BrdInfo[cardNo].CJCReadings[cjcNo];
	}
}
//******************************************************
// SetDegCCJCReading()
///
/// Gets the deg C CJC reading of a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] usCJCNo - the CJC number per slot, 0 for the old AI CJC or averge CJC on the new AI card, 1-4 for the new AI CJC's
/// @param[in] value - The CJC value to set
///
/// @return Card slot board current timebase frequency
///
//******************************************************
void CBrdInfo::SetDegCCJCReading(const USHORT cardNo, const USHORT usCJCNo, const float value) {
	m_BrdInfo[cardNo].CJCReadings[usCJCNo] = value;
}
//******************************************************
// GetBoardTimebase()
///
/// Gets the boards timebase reference.
/// @param[in] cardNo - Card slot number identification.
///
/// @return Card slot board current timebase frequency
///
//******************************************************
USHORT CBrdInfo::GetBoardTimebase(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].BoardTBRef;
}
//******************************************************
// SetBoardTimebase()
///
/// Sets the boards timebase reference.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] timebase - Card slot board current timebase frequency (Number of ticks per second).
///
//******************************************************
void CBrdInfo::SetBoardTimebase(const USHORT cardNo, const USHORT timebase) {
	m_BrdInfo[cardNo].BoardTBRef = timebase;
}
//******************************************************
///
/// Sets the I/O current tick reference.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] IOCardTicks - IO card ticks.
///
//******************************************************
void CBrdInfo::SetBoardTicks(const USHORT cardNo, const USHORT IOCardTicks) {
	m_BrdInfo[cardNo].IOTicks = IOCardTicks;
}
//******************************************************
///
/// Sets the I/O current tick reference.
/// @param[in] cardNo - Card slot number identification.
///
/// @return IO card ticks on the last read.
///
//******************************************************
USHORT CBrdInfo::GetBoardTicks(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].IOTicks;
}
//******************************************************
///
/// Sets the queue gearing for the I/O card.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] queueGearing - Card slot gearing ratio.
///
//******************************************************
void CBrdInfo::SetQueueGearing(const USHORT cardNo, const USHORT queueGearing) {
	m_BrdInfo[cardNo].queueGearing = static_cast<UCHAR>(queueGearing);
}
//******************************************************
///
/// Sets the queue rollover value for the I/O card.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] queueRollover - Card slot queue rollover.
///
//******************************************************
void CBrdInfo::SetQueueRollover(const USHORT cardNo, const ULONG queueRollover) {
	m_BrdInfo[cardNo].queueRollover = queueRollover;
}
//******************************************************
// SetBoardType()
///
/// Sets what type of board is in a current slot and board ID.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] boardType - Card slot board type.
///
//******************************************************
void CBrdInfo::SetBoardType(const USHORT cardNo, const UCHAR boardType) {
	// Set board ID as well as board type
	m_BrdInfo[cardNo].CardNo = static_cast<UCHAR>(cardNo);
	m_BrdInfo[cardNo].CardType = boardType;
}
//******************************************************
// SetNoOfChannels()
///
/// Gets the number of board channels in a current slot.
/// @param[in] cardNo - Card slot number identification.
///
/// @return Number of channels on card.
///
//******************************************************
UCHAR CBrdInfo::GetNoOfChannels(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].Channels;
}
//******************************************************
// SetNoOfChannels()
///
/// Sets the number of board channels in a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] noOfChans - Number of channels on card.
///
/// @return TRUE if the number of channels could be set; otherwise FALSE
//******************************************************
BOOL CBrdInfo::SetNoOfChannels(const USHORT cardNo, const UCHAR noOfChans) {
	BOOL retValue = TRUE;
	m_BrdInfo[cardNo].Channels = noOfChans;
	return retValue;
}
//******************************************************
///
/// Limits the current in the current loop with the range limits.
/// @param[in] slotNo - The I/O card number.
/// @param[in] overRangeAllowed - 4% overrange (i.e. 20-21mA) allowed.
///
/// @return The mA absolute top limit allowed by AO card.
/// 
//******************************************************
USHORT CBrdInfo::HighestAllowedmAOutput(const USHORT slotNo, const BOOL overRangeAllowed) const {
	USHORT AOTopLimit = 0;
	if (overRangeAllowed == FALSE) {
		// If upper limit is 20 mA then we can always ensure that 20mA is met
		AOTopLimit = AO_ENSURE_20mA;
	} else {
		// If upper limit is 21 mA then ensure no greater current is output dependant upon board
		// revision error limit
		if (IsFirmwareAtLeastRevision(slotNo, EarliestEnsure21mARevision, EarliestEnsure21mABuild) == TRUE) {
			AOTopLimit = AO_ENSURE_21mA;
		} else {
			AOTopLimit = AO_SELECT_21mA;
		}
	}
	return AOTopLimit;
}
//******************************************************
// TestNoOfChannels()
///
/// Tests the number of board channels in a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] boardType - I/O board type.
/// @param[in] noOfChans - Number of channels on card.
///
/// @return TRUE if the channel count does not exceed maximum permisable for board; otherwise FALSE
//******************************************************
BOOL CBrdInfo::TestNoOfChannels(const USHORT cardNo, const UCHAR boardType, const UCHAR noOfChans) {
	BOOL retValue = FALSE;
	switch (boardType) {
	case BOARD_AI:
		if (noOfChans <= TOPSLOT_AICHAN_SIZE)
			retValue = TRUE;
		break;
	case BOARD_EZ_AI:
		if (noOfChans <= (TOPSLOT_AICHAN_SIZE - 2))
			retValue = TRUE;
		break;
	case BOARD_AR:
		if (noOfChans <= BOTTOMSLOT_DIGCHAN_SIZE / 2)
			retValue = TRUE;
		break;
	case BOARD_DIO:
		if (noOfChans <= BOTTOMSLOT_DIGCHAN_SIZE)
			retValue = TRUE;
		break;
	case BOARD_AO:
		if (noOfChans <= TOPSLOT_AOCHAN_SIZE)
			retValue = TRUE;
		break;
	case BOARD_PI:
		if (noOfChans <= TOPSLOT_PULSECHAN_SIZE)
			retValue = TRUE;
		break;
	default:
		break;
	}
	return retValue;
}
//******************************************************
// SetReferenceConfigCRC()
///
/// Sets the board configuration downloaded to a current slot.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE if the calculated CRC and actual CRC match; otherwise FALSE
//******************************************************
BOOL CBrdInfo::ConfigCRCCheck(const USHORT cardNo) const {
	return static_cast<BOOL>(m_BrdInfo[cardNo].CalcConfigCRC == m_BrdInfo[cardNo].BdConfigCRC);
}
//******************************************************
///
/// Gets the queue gearing for the I/O card.
/// @param[in] cardNo - Card slot number identification.
///
/// @return The main queue gearing ratio
//******************************************************
USHORT CBrdInfo::GetQueueGearing(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].queueGearing;
}
//******************************************************
///
/// Gets the queue rollover value for the I/O card.
/// @param[in] cardNo - Card slot number identification.
///
/// @return The value at which the main queue will rollover
//******************************************************
ULONG CBrdInfo::GetQueueRollover(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].queueRollover;
}
//******************************************************
// SetCalcConfigCRC()
///
/// Sets the calculated board configuration downloaded to a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] ConfigCRC - The calculated CRC of the local configuration stored/to be stored on the board.
///
//******************************************************
void CBrdInfo::SetCalcConfigCRC(const USHORT cardNo, const USHORT configCRC) {
	m_BrdInfo[cardNo].CalcConfigCRC = configCRC;
}
//******************************************************
// GetCalcConfigCRC()
///
/// Gets the board configuration CRC that has been calculated for a current slot.
/// @param[in] cardNo - Card slot number identification.
///
/// @return The calculated CRC of the local configuration
/// 
//******************************************************
USHORT CBrdInfo::GetCalcConfigCRC(const USHORT cardNo) {
	return m_BrdInfo[cardNo].CalcConfigCRC;
}
//******************************************************
// SetBoardConfigCRC()
///
/// Sets the board configuration downloaded to a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] ConfigCRC - The CRC of the configuration stored on the board.
///
//******************************************************
void CBrdInfo::SetBoardConfigCRC(const USHORT cardNo, const USHORT configCRC) {
	m_BrdInfo[cardNo].BdConfigCRC = configCRC;
}
//******************************************************
// GetBoardConfigCRC()
///
/// Gets the board configuration downloaded to a current slot.
/// @param[in] cardNo - Card slot number identification.
///
/// @return The CRC of the configuration stored on the board
/// 
//******************************************************
USHORT CBrdInfo::GetBoardConfigCRC(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].BdConfigCRC;
}
//******************************************************
// SetLastTestStatus()
///
/// Gets the card last test pass status.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] LastTestStatus - Last test status.
///
//******************************************************
void CBrdInfo::SetLastTestStatus(const USHORT cardNo, const UCHAR LastTestStatus) {
	m_BrdInfo[cardNo].LastTestStatus = LastTestStatus;
}
//******************************************************
// MoveCardCapabilitiesToNewSlot()
///
/// Moves the board capabilities form one card slot to another.
/// @param[in] OrigCardSlot - Card slot number identification data originally placed in.
/// @param[in] newCardSlot - Card slot number to move data into.
///
//******************************************************
void CBrdInfo::MoveCardCapabilitiesToNewSlot(const USHORT OrigCardSlot, const USHORT newCardSlot) {
	// Move the existing board
	//	m_BrdInfo[newCardSlot].CardNo = m_BrdInfo[OrigCardSlot].CardNo;
	m_BrdInfo[newCardSlot].CardNo = static_cast<UCHAR>(newCardSlot);
	m_BrdInfo[newCardSlot].CardType = m_BrdInfo[OrigCardSlot].CardType;
	m_BrdInfo[newCardSlot].Channels = m_BrdInfo[OrigCardSlot].Channels;
	for (UCHAR chanNo = 0; chanNo < MAX_IOBOARDCHANS; chanNo++) {
		m_BrdInfo[newCardSlot].chan[chanNo].ChanCap = m_BrdInfo[OrigCardSlot].chan[chanNo].ChanCap;
		m_BrdInfo[newCardSlot].chan[chanNo].ChanSet = m_BrdInfo[OrigCardSlot].chan[chanNo].ChanSet;
		// Clear the existing channel set
		m_BrdInfo[OrigCardSlot].chan[chanNo].ChanCap = CHANNEL_CAP_UNKNOWN;
		m_BrdInfo[OrigCardSlot].chan[chanNo].ChanSet = CHANNEL_UNKNOWN;
	}
	// Clear the existing reference
	m_BrdInfo[OrigCardSlot].CardType = BOARD_INVALID;
	m_BrdInfo[OrigCardSlot].Channels = 0;
}
//******************************************************
// GetLastTestStatus()
///
/// Gets whether the card passed the last test performed.
/// @param[in] cardNo - Card slot number identification.
///
/// @return last test status
///
//******************************************************
UCHAR CBrdInfo::GetLastTestStatus(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].LastTestStatus;
}
//******************************************************
// SetFirstRigID()
///
/// Sets the current rig ID that the board is being tested on.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] rigID - Rig ID.
///
//******************************************************
void CBrdInfo::SetCurrentRigID(const USHORT cardNo, const UCHAR rigID) {
	m_BrdInfo[cardNo].CurrentTestRig = rigID;
}
//******************************************************
// SetFirstRigID()
///
/// Sets the first rig ID that the board was tested on.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] rigID - Rig ID.
///
//******************************************************
void CBrdInfo::SetFirstRigID(const USHORT cardNo, const UCHAR rigID) {
	m_BrdInfo[cardNo].FirstTestRig = rigID;
}
//******************************************************
// SetLastRigID()
///
/// Sets the last rig ID that the board was tested on.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] rigID - Rig ID.
///
//******************************************************
void CBrdInfo::SetLastRigID(const USHORT cardNo, const UCHAR rigID) {
	m_BrdInfo[cardNo].LastTestRig = rigID;
}
//******************************************************
// SetDateFirstTested()
///
/// Sets the date first tested (part of ID) of the chosen card.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] date - Date first tested.
///
//******************************************************
void CBrdInfo::SetDateFirstTested(const USHORT cardNo, const ULONG date) {
	m_BrdInfo[cardNo].DateFirstTested = date;
}
//******************************************************
// SetDateLastTested()
///
/// Sets the date first tested (part of ID) of the chosen card.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] date - Date first tested.
///
//******************************************************
void CBrdInfo::SetDateLastTested(const USHORT cardNo, const ULONG date) {
	m_BrdInfo[cardNo].DateLastTested = date;
}
//******************************************************
// GetDateLastTested()
///
/// Gets the date first tested (part of ID) of the chosen card.
/// @param[in] cardNo - Card slot number identification.
///
//******************************************************
ULONG CBrdInfo::GetDateLastTested(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].DateLastTested;
}
//******************************************************
// GetDateFirstTested()
///
/// Sets the date first tested (part of ID) of the chosen card.
/// @param[in] cardNo - Card slot number identification.
///
//******************************************************
ULONG CBrdInfo::GetDateFirstTested(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].DateFirstTested;
}
//******************************************************
// GetBoardFirstTestRig()
///
/// Queries what rig performed the first test on the I/O board.
/// @param[in] cardNo - Card slot number identification.
///
/// @return The rig no the I/O board was first tested on
/// 
//******************************************************
UCHAR CBrdInfo::GetBoardFirstTestRig(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].FirstTestRig;
}
//******************************************************
// GetBoardLastTestRig()
///
/// Queries what rig performed the last test on the I/O board.
/// @param[in] cardNo - Card slot number identification.
///
/// @return The rig no the I/O board was last tested on
/// 
//******************************************************
UCHAR CBrdInfo::GetBoardLastTestRig(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].LastTestRig;
}
//******************************************************
// GetBoardCurrentTestRig()
///
/// Queries what rig performed the last test on the I/O board.
/// @param[in] cardNo - Card slot number identification.
///
/// @return The rig no the I/O board was last tested on
/// 
//******************************************************
UCHAR CBrdInfo::GetCurrentTestRigID(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].CurrentTestRig;
}
//******************************************************
// SetBoardFirmwareRevision()
///
/// Sets the Revision of the chosen card.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] boardRevision - Card revision number to set.
///
//******************************************************
void CBrdInfo::SetBoardFirmwareRevision(const USHORT cardNo, UCHAR *pFirmwareRevision) {
	m_BrdInfo[cardNo].FirmwareRev[0] = pFirmwareRevision[0];
	m_BrdInfo[cardNo].FirmwareRev[1] = pFirmwareRevision[1];
	m_BrdInfo[cardNo].FirmwareRev[2] = '\0';
	if (m_BrdInfo[cardNo].BoardRev >= V7AI_ISSUE_A) {
		m_BrdInfo[cardNo].buildNo = (static_cast<ULONG>(pFirmwareRevision[6]
				+ (static_cast<ULONG>(pFirmwareRevision[7])) + (static_cast<ULONG>(pFirmwareRevision[8]))
				+ (static_cast<ULONG>(pFirmwareRevision[9]))));
		m_BrdInfo[cardNo].rootBuildNo = (static_cast<ULONG>(pFirmwareRevision[2]
				+ (static_cast<ULONG>(pFirmwareRevision[3])) + (static_cast<ULONG>(pFirmwareRevision[4]))
				+ (static_cast<ULONG>(pFirmwareRevision[5]))));
	} else {
		m_BrdInfo[cardNo].buildNo = (static_cast<ULONG>(pFirmwareRevision[2]
				+ (static_cast<ULONG>(pFirmwareRevision[3])) + (static_cast<ULONG>(pFirmwareRevision[4]))
				+ (static_cast<ULONG>(pFirmwareRevision[5]))));
	}
}
//******************************************************
// IsFirmwareAtLeastRevision()
///
/// Checks whether the Revision of the selected card is at least a certain level.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] pRefBoardRevision - Card reference revision number.
/// @param[in] refBoardBuildNo - Card reference build number.
///
/// @return TRUE if reference card I/O firmware release is at least as new as the
///		reference release otherwise FALSE
///
//******************************************************
BOOL CBrdInfo::IsFirmwareAtLeastRevision(const USHORT cardNo, const UCHAR *pRefBoardRevision,
		const ULONG refBoardBuildNo) const {
	ULONG refRevision = 0L;
	ULONG boardRevision = 0L;
	BOOL firmwareAtLeast = FALSE;
	refRevision = ((toupper(pRefBoardRevision[0]) - 'A' + 1) * 27) + (toupper(pRefBoardRevision[1]) - 'A' + 1);
	boardRevision = ((toupper(m_BrdInfo[cardNo].FirmwareRev[0]) - 'A' + 1) * 27)
			+ (toupper(m_BrdInfo[cardNo].FirmwareRev[1]) - 'A' + 1);
	if ((boardRevision > refRevision)
			|| ((boardRevision == refRevision) && (m_BrdInfo[cardNo].buildNo >= refBoardBuildNo))) {
		firmwareAtLeast = TRUE;
	}
	return firmwareAtLeast;
}
//******************************************************
// HasBoardInfoBeenUploaded()
///
/// Sets what type of channels are available.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE if the info load has been attempted
///
//******************************************************
BOOL CBrdInfo::HasBoardInfoBeenUploaded(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].infoUploaded;
}
//******************************************************
// GetFirmwareBuildNo()
///
/// Gets the firmware build number.
/// @param[in] cardNo - Card slot number identification.
///
/// @return Firmware build number
///
//******************************************************
ULONG CBrdInfo::GetFirmwareBuildNo(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].buildNo;
}
//******************************************************
// GetRootFirmwareBuildNo()
///
/// Gets the App firmware build number.
/// @param[in] cardNo - Card slot number identification.
///
/// @return App Firmware build number
///
//******************************************************
ULONG CBrdInfo::GetRootFirmwareBuildNo(const USHORT cardNo) const {
	return m_BrdInfo[cardNo].rootBuildNo;
}
//******************************************************
// BoardInfoBeenUploaded()
///
/// Sets whether the history and calibration info has been had an upload attempted.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] InfoUploaded - TRUE if the info has been obtained.
///
//******************************************************
void CBrdInfo::BoardInfoBeenUploaded(const USHORT cardNo, const BOOL InfoUploaded) {
	m_BrdInfo[cardNo].infoUploaded = InfoUploaded;
}
//******************************************************
// GetBoardFirmwareRevision()
///
/// Queries what the I/O board revision is.
/// @param[in] cardNo - Card slot number identification.
/// @param[out] pBoardRevision - Board revision letters.
///
/// @return TRUE if the boards revision is available; otherwise FALSE
///
//******************************************************
BOOL CBrdInfo::GetBoardFirmwareRevision(const USHORT cardNo, UCHAR *const pBoardRevision, int pBuffSize) {
	if (m_BrdInfo[cardNo].infoUploaded == TRUE) {
#if _MSC_VER < 1400 
		strncpy(reinterpret_cast<char*>(pBoardRevision), reinterpret_cast<char*>(&m_BrdInfo[cardNo].FirmwareRev),
		BOARD_REVISION_STR_LEN);
#else
		strncpy_s( reinterpret_cast<char *> (pBoardRevision), pBuffSize,
				reinterpret_cast<char *> (&m_BrdInfo[cardNo].FirmwareRev), BOARD_REVISION_STR_LEN );
#endif
	}
	return m_BrdInfo[cardNo].infoUploaded;
}
//******************************************************
// SetBoardHardwareRevision()
///
/// Sets what the I/O board hardware revision is.
/// @param[in] cardNo - Card slot number identification.
/// @param[out] RangeRevision - I/O Board hardware revision.
///
//******************************************************
void CBrdInfo::SetBoardRangeRevision(const USHORT cardNo, const UCHAR RangeRevision) {
	m_BrdInfo[cardNo].RangeRev = RangeRevision;
}
//******************************************************
// SetBoardHardwareRevision()
///
/// Sets what the I/O board hardware revision is.
/// @param[in] cardNo - Card slot number identification.
/// @param[out] HWRevision - Board hardware revision.
///
//******************************************************
void CBrdInfo::SetBoardHardwareRevision(const USHORT cardNo, const UCHAR HWRevision) {
	m_BrdInfo[cardNo].BoardRev = HWRevision;
}
//******************************************************
// GetBoardHardwareRevision()
///
/// Queries what the I/O board hardware revision is.
/// @param[in] cardNo - Card slot number identification.
/// @param[out] pHWRevision - Board hardware revision.
///
/// @return TRUE if the boards hardware revision is available; otherwise FALSE
///
//******************************************************
BOOL CBrdInfo::GetBoardHardwareRevision(const USHORT cardNo, UCHAR *const pHWRevision) const {
	*pHWRevision = m_BrdInfo[cardNo].BoardRev;
	return static_cast<BOOL>((WhatBoardType(cardNo) != BOARD_INVALID) && (WhatBoardType(cardNo) != BOARD_IMPOSSIBLE)
			&& (WhatBoardType(cardNo) != BOARD_NOT_FITTED));
}
//******************************************************
// GetBoardHardwareRevision()
///
/// Queries what the I/O board range revision is.
/// @param[in] cardNo - Card slot number identification.
/// @param[out] pRangeRevision - Board hardware revision.
///
/// @return TRUE if the boards hardware revision is available; otherwise FALSE
///
//******************************************************
BOOL CBrdInfo::GetBoardRangeRevision(const USHORT cardNo, UCHAR *const pRangeRevision) const {
	*pRangeRevision = m_BrdInfo[cardNo].RangeRev;
	return static_cast<BOOL>((WhatBoardType(cardNo) != BOARD_INVALID) && (WhatBoardType(cardNo) != BOARD_IMPOSSIBLE)
			&& (WhatBoardType(cardNo) != BOARD_NOT_FITTED));
}
//******************************************************
// WhatSelectedChannelType()
///
/// Queries what type of channel is currently selected.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] channelNo - Card slot channel number.
///
/// @return The channel type currently selected
///
//******************************************************
UCHAR CBrdInfo::WhatSelectedChannelType(const USHORT cardNo, const USHORT channelNo) const {
	// Ensure card and channel is in range
	if ((cardNo >= MAX_SCHED_SERVICES) || (channelNo >= MAX_IOBOARDCHANS))
		return CHANNEL_UNKNOWN;
	return m_BrdInfo[cardNo].chan[channelNo].ChanSet;
}
//******************************************************
///
/// Modbus query what type of channel is currently selected in the top slots.
/// @param[in] sysChannelNo - System channel number.
///
/// @return The channel type currently selected (if pulse or analogue input)
///			otherwise CHANNEL_UNKNOWN
///
//******************************************************
UCHAR CBrdInfo::WhatModbusSelectedAnalChannelType(const USHORT sysChannelNo, const T_PENBASE base) const {
	class CSlotMap *pSlotMapObj = NULL;					///< Board info holder
	USHORT slotNo;
	USHORT chanNo;
	UCHAR chanType = CHANNEL_UNKNOWN;
	pSlotMapObj = CSlotMap::GetHandle();
	if (pSlotMapObj != NULL) {
		// Pulse channels on digital cards are not included
		// Check for dedicated pulse channels
		if (pSlotMapObj->GetSlotAndChannelFromDedicatedPulseSysChan(sysChannelNo, slotNo, chanNo, base) == TRUE)
			chanType = WhatSelectedChannelType(slotNo, chanNo);
		if (chanType != CHANNEL_PULSE) {
			// If not a pulse channel check for analogue input channel
			if (pSlotMapObj->GetSlotAndChannelFromAnalSysChan(sysChannelNo, &slotNo, &chanNo, base) == TRUE)
				chanType = WhatSelectedChannelType(slotNo, chanNo);
		}
	}
	return chanType;
}
//******************************************************
///
/// Modbus query what type of channel is currently selected in the bottom slots.
/// @param[in] sysChannelNo - System channel number.
///
/// @return The channel type currently selected (if digital input or output)
///			otherwise CHANNEL_UNKNOWN
///
//******************************************************
UCHAR CBrdInfo::WhatModbusSelectedDigChannelType(const USHORT sysChannelNo, const T_PENBASE base) const {
	class CSlotMap *pSlotMapObj = NULL;					///< Board info holder
	USHORT slotNo;
	USHORT chanNo;
	UCHAR chanType = CHANNEL_UNKNOWN;
	pSlotMapObj = CSlotMap::GetHandle();
	if (pSlotMapObj != NULL) {
		// Check for
		if (pSlotMapObj->GetSlotAndChannelFromDigitalSysChan(sysChannelNo, slotNo, chanNo, base) == TRUE)
			chanType = WhatSelectedChannelType(slotNo, chanNo);
		if ((chanType != CHANNEL_DI) && (chanType != CHANNEL_DO))
			chanType = CHANNEL_UNKNOWN;
	}
	return chanType;
}
//******************************************************
// SetSelectedChannelType()
///
/// Sets what type of channel is currently selected.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] channelNo - Card slot channel number.
/// @param[in] channelType - Channel type selected.
///
//******************************************************
void CBrdInfo::SetSelectedChannelType(const USHORT cardNo, const USHORT channelNo, const UCHAR channelType) {
	m_BrdInfo[cardNo].chan[channelNo].ChanSet = channelType;
}
//******************************************************
// GetIOCardChannelRangeSelection()
///
/// Gets what I/O card channel range is currently selected.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] channelNo - Card slot channel number.
///
/// @return The I/O card selected channel range
//******************************************************
T_AIRANGE CBrdInfo::GetIOCardChannelRangeSelection(const USHORT cardNo, const USHORT channelNo) const {
	return m_BrdInfo[cardNo].chan[channelNo].BaseRangeInfo;
}
//******************************************************
// SetIOCardChannelSelection()
///
/// Logs what type of channel is currently selected on the I/O board.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] channelNo - Card slot channel number.
/// @param[in] BaseRangeInfo - IO card Channel selection.
///
//******************************************************
void CBrdInfo::SetIOCardChannelSelection(const USHORT cardNo, const USHORT channelNo, const T_AIRANGE BaseRangeInfo) {
	m_BrdInfo[cardNo].chan[channelNo].BaseRangeInfo = BaseRangeInfo;
}
//******************************************************
// WhatAvailableChannelType()
///
/// Queries what type of are available from a given board channel.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] channelNo - Card slot channel number.
///
/// @return The channel capabilities - i.e. types currently available for selection
///
//******************************************************
UCHAR CBrdInfo::WhatAvailableChannelType(const USHORT cardNo, const USHORT channelNo) const {
	// Ensure card and channel is in range
	if ((cardNo >= MAX_SCHED_SERVICES) || (channelNo >= MAX_IOBOARDCHANS))
		return CHANNEL_CAP_UNKNOWN;
	return m_BrdInfo[cardNo].chan[channelNo].ChanCap;
}
//******************************************************
// SetAvailableChannelType()
///
/// Sets what type of channels are available.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] channelNo - Card slot channel number.
/// @param[in] channelCap - Channel capabilities or typse available.
///
//******************************************************
void CBrdInfo::SetAvailableChannelType(const USHORT cardNo, const USHORT channelNo, const UCHAR channelCap) {
	m_BrdInfo[cardNo].chan[channelNo].ChanCap = channelCap;
}
//******************************************************
// IsCardResetSupported()
///
/// This function verifies the AI card FW version/Build number
/// that supports ADC reset thru perform RESET function code
/// @param[in] cardNo - Card slot number identification.
///
/// @return value - TRUE if FW is at least version supported for ADC reset
/// Rev History
/// @Version	@Date			@Author			@Remarks
/// 1.0			10/Apr/2018		Shankar Rao		Fix for IO compatibility for star star star changes
//******************************************************
BOOL CBrdInfo::IsCardResetSupported(const USHORT cardNo) {
	BOOL bRet = FALSE;
	//The ADC Reset is supported from AK-17 Version of the IO FW for AI board
	const UCHAR EarliestEnsureADCResetRevision[3] = "AK";
	const UCHAR EarliestEnsureADCResetBuild = 17;
	bRet = IsFirmwareAtLeastRevision(cardNo, EarliestEnsureADCResetRevision, EarliestEnsureADCResetBuild);
	return bRet;
}

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOHandler.cpp
/// @n implementation for the abstract CIOHandler class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 25	Stability Project 1.20.1.3	7/2/2011 4:58:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 24	Stability Project 1.20.1.2	7/1/2011 4:38:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 23	Stability Project 1.20.1.1	3/17/2011 3:20:26 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 22	Stability Project 1.20.1.0	2/15/2011 3:03:11 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "AIConfig.h"
#include "IOHandler.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "PPIOServiceManager.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CIOHandler::CIOHandler() {
//	qDebug("Create new CIOHandler\n");
//	m_CSInfo = CPInfo;
//	m_input = chanInput;
	m_nextRunTime = (LONGLONG) 0L;
//	m_readRate = 0;
//	m_pBrdInfoObj = NULL;
//	m_pBrdStatsObj = NULL;
	m_pSM = NULL;
	m_pICService = NULL;
	m_CSInfo.pCard = NULL;
}
CIOHandler::~CIOHandler() {
//	qDebug("Delete CIOHandler class\n");
}
//******************************************************
///
/// Obtains the handle on the service manager
///
/// @return the service manager on successful initialisation; otherwise NULL
/// 
//******************************************************
class CPPIOServiceManager* CIOHandler::GetServiceManager(void) {
	return CIOHandler::m_pSM;
}
//******************************************************
// InitialiseIOHandler()
///
/// Initialises an I/O handler
/// @note - Must be run after the constructor
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOHandler::InitialiseIOHandler(void) {
	BOOL retValue = FALSE;
	// Get a handle on board info, stats and I/O conditioning
//	m_pBrdInfoObj = CBrdInfo::GetHandle();
//	m_pBrdStatsObj = CBrdStats::GetHandle();
	m_pSM = CPPIOServiceManager::GetHandle();		///< Service manager
	if (m_pSM != NULL) {
		m_pICService = m_pSM->GetICService();
		if (m_pICService != NULL)
			retValue = TRUE;
	} else
		m_pICService = NULL;
	return retValue;
}
//******************************************************
// InitialiseChanService()
///
/// Initialises a channel to connect to the approriate Data Item table
/// or data queue for data extraction/processing.
/// @param[in] pBoardInfo - I/O board process information.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOHandler::InitialiseChanService(T_COMMONPROCESSINFO *const pBoardInfo) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	class CBrdStats *pBrdStatsObj = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	m_CSInfo = *pBoardInfo;
	// Only initialise service if channel is enabled
	if (1) {
		m_CSInfo.timestampfreq = pBrdInfoObj->GetBoardTimebase(m_CSInfo.CardSlotNo);
//		m_CSInfo.PPQGearing = m_pBrdInfoObj->GetQueueGearing(m_CSInfo.CardSlotNo);
//		m_CSInfo.PPQmaxWrap = m_pBrdInfoObj->GetQueueRollover(m_CSInfo.CardSlotNo);
		if (m_CSInfo.input == TRUE) {
			// If channel is an input then connect to the approriate data queue for batch processing.
			// Schedule I/O channel acqusition		if channel is input and enabled
			m_nextRunTime = pBrdStatsObj->m_schedTimer.scheduleRuntime(0);
		} else {
			// Otherwise channel is an output then connect to the approriate Data Item table for data extraction
		}
	}
	return TRUE;
}
//******************************************************
///
/// Gets the board process info structure reference.
///
/// @return The board process info structure reference
/// 
//******************************************************
T_COMMONPROCESSINFO* CIOHandler::GetBoardProcessInfo(void) {
	return &m_CSInfo;
}
//******************************************************
// SetServiceReadRate()
///
/// Sets the rate at which the readings are acquired from the card / channel.
/// @param[in] readRate - The rate at which the readings are acquired from the card
///
/// @return Nothing
/// 
//******************************************************
void CIOHandler::SetServiceReadRate(const USHORT readRate) {
	class CBrdStats *pBrdStatsObj = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	m_CSInfo.readRate = readRate;
	// Calculate first run time
	m_nextRunTime = pBrdStatsObj->m_schedTimer.scheduleRuntime(m_CSInfo.readRate);
}
//******************************************************
// ScheduleNextServiceRead()
///
/// Schedules the next time readings are to be acquired from the card / channel.
///
/// @return Nothing
/// 
//******************************************************
void CIOHandler::ScheduleNextServiceRead(void) {
	class CBrdStats *pBrdStatsObj = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	// Recalculate next run time
	if (pBrdStatsObj != NULL)
		m_nextRunTime = pBrdStatsObj->m_schedTimer.scheduleReferencedRuntime(m_nextRunTime, m_CSInfo.readRate);
}
//******************************************************
// SetServiceAcqRate()
///
/// Sets the actual acqusition rate of the card / channel (number of readings per second).
/// @param[in] acqRate - The actual acqusition rate of the card / channel
///
/// @return Nothing
/// 
//******************************************************
void CIOHandler::SetServiceAcqRate(const USHORT acqRate) {
//	m_CSInfo.pChanCfgInfo->acqRate = acqRate;
}
//******************************************************
// GetServiceReadRate()
///
/// Sets the rate at which the readings are acquired from the service.
///
/// @return The rate at which the readings are acquired from the service
/// 
//******************************************************
USHORT CIOHandler::GetServiceReadRate(void) const {
	return m_CSInfo.readRate;
}
//******************************************************
// IsServiceAnInput()
///
/// Queries whether pre-process service is configured as an input or output.
///
/// @return TRUE if channel is configured as an input; otherwise FALSE
/// 
//******************************************************
BOOL CIOHandler::IsServiceAnInput(void) {
	return m_CSInfo.input;
}
//******************************************************
// GetServiceAcqRate()
///
/// Sets the actual acqusition rate of the channel (number of readings per second).
///
/// @return The actual acqusition rate of the card / channel service
/// 
//******************************************************
USHORT CIOHandler::GetServiceAcqRate(void) {
//	return m_CSInfo.pChanCfgInfo->acqRate;
	return 1;
}
//******************************************************
// GetTimeServiceRqd()
///
/// Gets the time the channel next needs servicing.
///
/// @return the time that the first I/O next requires servicing
/// 
//******************************************************
LONGLONG CIOHandler::GetTimeServiceRqd(void) {
	return m_nextRunTime;
}

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n SlotMap.cpp
/// @n implement the I/O Card slot and channel mapping.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 52	Stability Project 1.47.1.3	7/2/2011 5:01:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 51	Stability Project 1.47.1.2	7/1/2011 4:38:55 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 50	Stability Project 1.47.1.1	3/17/2011 3:20:47 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 49	Stability Project 1.47.1.0	2/15/2011 3:03:57 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "DataItemIO.h"
#include "hw_defs.h"
#include "CMMDefines.h"
#include "V6Config.h"
#include "V6IOConstraints.H"
#include "BoardManager.h"
#include "SlotMap.h"
#include "V6globals.h"
#include "BrdInfo.h"
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CSlotMap::CSlotMap() {
	//	qDebug("Create new CSlotMap\n");
	m_LastTopSlotQueue = (RECORDER_SLOT_G * TOPSLOT_AICHAN_SIZE) - 1;
	m_LastBottomSlotPulseQueue = (((RECORDER_SLOT_I - RECORDER_SLOT_G) * HW_BOTTOMSLOT_PULSECHAN_SIZE) - 1)
			+ m_LastTopSlotQueue;
	m_LastQueue = m_LastBottomSlotPulseQueue + (RECORDER_SLOT_I - RECORDER_SLOT_G);
}
CSlotMap::~CSlotMap() {
	//	qDebug("Deleting CSlotMap\n");
}
CSlotMap *CSlotMap::m_pInstance = NULL;
QMutex m_CreationMutex;
//**********************************************************************
///
/// Instance creation of CSlotMap singleton
///
/// @return		pointer to single instance of CSlotMap
/// 
//**********************************************************************
CSlotMap* CSlotMap::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		if (waitSingleObjectResult) {
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CSlotMap;
			}
			m_CreationMutex.unlock();
		} else {
			/// Handle Error
			LogInternalError("Could not create SlotMap");
			V6WarningMessageBox(NULL, L"SlotMap WaitForSingleObject Error", L"CSlotMap Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
/// @return		nothing
//**********************************************************************
void CSlotMap::CleanUp() {
	// Delete the slot manager
	if (NULL != m_pInstance) {
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//**********************************************************************
/// Queries whether the card is in the top slot 
///
/// @param[in] cardNo - Card slot number.
///
/// @return		TRUE if card position is in top slot; otherwise FALSE
//**********************************************************************
BOOL CSlotMap::IsCardInTopSlot(const USHORT cardNo) const {
	switch (cardNo) {
	case RECORDER_SLOT_A:
	case RECORDER_SLOT_B:
	case RECORDER_SLOT_C:
	case RECORDER_SLOT_D:
	case RECORDER_SLOT_E:
	case RECORDER_SLOT_F:
		return TRUE;
	}
	return FALSE;
}
//**********************************************************************
/// Obtains the maximum number of channels that a particular slot number can support
///
/// @param[in] cardNo - Card slot number.
///
/// @return		The maximum number of channels supported on slot; otherwise 0 channels
//**********************************************************************
UCHAR CSlotMap::GetIOSlotMaxChannels(const USHORT cardNo) const {
	switch (cardNo) {
	case RECORDER_SLOT_A:
	case RECORDER_SLOT_B:
	case RECORDER_SLOT_C:
	case RECORDER_SLOT_D:
	case RECORDER_SLOT_E:
	case RECORDER_SLOT_F:
		return TOPSLOT_AICHAN_SIZE;
	case RECORDER_SLOT_G:
	case RECORDER_SLOT_H:
	case RECORDER_SLOT_I:
		return BOTTOMSLOT_DIGCHAN_SIZE;
	}
	return 0;
}
//**********************************************************************
/// Obtains the slot number from a digital channel
///
/// @param[in] AnaChannel - Digital channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board slot number; otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetDigitalChannelSlotNo(const USHORT IOChannelIn, const T_PENBASE base) const {
	USHORT IOChannel = IOChannelIn;
	if (base == ZERO_BASED)
		IOChannel++;
	if ((IOChannel >= SLOT_G_DIGITAL_IO_START_CHAN) && (IOChannel <= SLOT_G_DIGITAL_IO_END_CHAN)) {
		return RECORDER_SLOT_G;
	} else if ((IOChannel >= SLOT_H_DIGITAL_IO_START_CHAN) && (IOChannel <= SLOT_H_DIGITAL_IO_END_CHAN)) {
		return RECORDER_SLOT_H;
	} else if ((IOChannel >= SLOT_I_DIGITAL_IO_START_CHAN) && (IOChannel <= SLOT_I_DIGITAL_IO_END_CHAN)) {
		return RECORDER_SLOT_I;
	}
	return SMAP_ILLEGAL_INDEX;			// Illegal slot
}
//**********************************************************************
/// Obtains the slot number from a pulse channel
///
/// @param[in] PulseChannel - Pulse channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board slot number; otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetDedicatedPulseInChannelSlotNo(const USHORT PulseChannel, const T_PENBASE base) const {
	USHORT IOChannel = PulseChannel;
	if (ZERO_BASED == base)
		++IOChannel;
	if ((IOChannel >= SLOT_A_PULSE_IN_START_CHAN) && (IOChannel <= SLOT_A_PULSE_IN_END_CHAN)) {
		return RECORDER_SLOT_A;
	} else if ((IOChannel >= SLOT_B_PULSE_IN_START_CHAN) && (IOChannel <= SLOT_B_PULSE_IN_END_CHAN)) {
		return RECORDER_SLOT_B;
	} else if ((IOChannel >= SLOT_C_PULSE_IN_START_CHAN) && (IOChannel <= SLOT_C_PULSE_IN_END_CHAN)) {
		return RECORDER_SLOT_C;
	} else if ((IOChannel >= SLOT_D_PULSE_IN_START_CHAN) && (IOChannel <= SLOT_D_PULSE_IN_END_CHAN)) {
		return RECORDER_SLOT_D;
	} else if ((IOChannel >= SLOT_E_PULSE_IN_START_CHAN) && (IOChannel <= SLOT_E_PULSE_IN_END_CHAN)) {
		return RECORDER_SLOT_E;
	} else if ((IOChannel >= SLOT_F_PULSE_IN_START_CHAN) && (IOChannel <= SLOT_F_PULSE_IN_END_CHAN)) {
		return RECORDER_SLOT_F;
	}
	return SMAP_ILLEGAL_INDEX;			// Illegal slot
}
//**********************************************************************
/// Obtains the slot number from a digital pulse channel
///
/// @param[in] PulseChannel - Pulse channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board slot number; otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetPulseInChannelSlotNo(const USHORT PulseChannelIn, const T_PENBASE base) const {
	USHORT PulseChannel = PulseChannelIn;
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if (base == ZERO_BASED)
		PulseChannel++;
	if ((PulseChannel >= SLOT_G_PULSE_IN_START_CHAN) && (PulseChannel <= SLOT_G_PULSE_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_G;
	} else if ((PulseChannel >= SLOT_H_PULSE_IN_START_CHAN) && (PulseChannel <= SLOT_H_PULSE_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_H;
	} else if ((PulseChannel >= SLOT_I_PULSE_IN_START_CHAN) && (PulseChannel <= SLOT_I_PULSE_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_I;
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the slot number from an analogue out channel
///
/// @param[in] AnaChannel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board slot number; otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetAnaOutChannelSlotNo(const USHORT AnaChannelIn, const T_PENBASE base) const {
	USHORT AnaChannel = AnaChannelIn;
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if (base == ZERO_BASED)
		AnaChannel++;
	if ((AnaChannel >= SLOT_A_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_A_ANAL_OUT_END_CHAN)) {
		slotNo = RECORDER_SLOT_A;
	} else if ((AnaChannel >= SLOT_B_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_B_ANAL_OUT_END_CHAN)) {
		slotNo = RECORDER_SLOT_B;
	} else if ((AnaChannel >= SLOT_C_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_C_ANAL_OUT_END_CHAN)) {
		slotNo = RECORDER_SLOT_C;
	} else if ((AnaChannel >= SLOT_D_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_D_ANAL_OUT_END_CHAN)) {
		slotNo = RECORDER_SLOT_D;
	} else if ((AnaChannel >= SLOT_E_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_E_ANAL_OUT_END_CHAN)) {
		slotNo = RECORDER_SLOT_E;
	} else if ((AnaChannel >= SLOT_F_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_F_ANAL_OUT_END_CHAN)) {
		slotNo = RECORDER_SLOT_F;
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the slot number from an analogue in channel
///
/// @param[in] AnaChannel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board slot number; otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetAnaInChannelSlotNo(const USHORT AnaChannelIn, const T_PENBASE base) const {
	USHORT AnaChannel = AnaChannelIn;
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if (base == ZERO_BASED)
		AnaChannel++;
	if ((AnaChannel >= SLOT_A_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_A_ANAL_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_A;
	} else if ((AnaChannel >= SLOT_B_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_B_ANAL_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_B;
	} else if ((AnaChannel >= SLOT_C_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_C_ANAL_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_C;
	} else if ((AnaChannel >= SLOT_D_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_D_ANAL_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_D;
	} else if ((AnaChannel >= SLOT_E_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_E_ANAL_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_E;
	} else if ((AnaChannel >= SLOT_F_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_F_ANAL_IN_END_CHAN)) {
		slotNo = RECORDER_SLOT_F;
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the board channel number from an analogue in channel
///
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetBoardChannelFromAnaInChannel(const USHORT AnaChannelIn, const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	USHORT AnaChannel = AnaChannelIn;
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if (base == ZERO_BASED)
		AnaChannel++;
	if ((AnaChannel >= SLOT_A_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_A_ANAL_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_B_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_B_ANAL_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_C_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_C_ANAL_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_D_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_D_ANAL_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_E_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_E_ANAL_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_F_ANAL_IN_START_CHAN) && (AnaChannel <= SLOT_F_ANAL_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		slotNo = static_cast<UCHAR>((AnaChannel - 1) % SYS_ANA_IN_CHAN_PER_BOARD);
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the digital board channel number from a pulse in channel
///
/// @param[in] Channel - pulse channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetBoardChannelFromPulseInChannel(const USHORT PulseChannelIn, const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	USHORT PulseChannel = PulseChannelIn;
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if (base == ZERO_BASED)
		PulseChannel++;
	if ((PulseChannel >= SLOT_G_PULSE_IN_START_CHAN) && (PulseChannel <= SLOT_G_PULSE_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((PulseChannel >= SLOT_H_PULSE_IN_START_CHAN) && (PulseChannel <= SLOT_H_PULSE_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((PulseChannel >= SLOT_I_PULSE_IN_START_CHAN) && (PulseChannel <= SLOT_I_PULSE_IN_END_CHAN)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		slotNo = static_cast<UCHAR>((PulseChannel - 1) % SYS_DIG_PULSE_CHAN_PER_BOARD);
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the board channel number from a pulse in channel
///
/// @param[in] Channel - pulse channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetBoardChannelFromDedicatedPulseInChannel(const USHORT ChannelIn, const T_PENBASE base) const {
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	USHORT Channel = ChannelIn;
	if (base == ZERO_BASED)
		Channel++;
	if (((Channel >= SLOT_A_PULSE_IN_START_CHAN) && (Channel <= SLOT_A_PULSE_IN_END_CHAN))
			|| ((Channel >= SLOT_B_PULSE_IN_START_CHAN) && (Channel <= SLOT_B_PULSE_IN_END_CHAN))
			|| ((Channel >= SLOT_C_PULSE_IN_START_CHAN) && (Channel <= SLOT_C_PULSE_IN_END_CHAN))
			|| ((Channel >= SLOT_D_PULSE_IN_START_CHAN) && (Channel <= SLOT_D_PULSE_IN_END_CHAN))
			|| ((Channel >= SLOT_E_PULSE_IN_START_CHAN) && (Channel <= SLOT_E_PULSE_IN_END_CHAN))
			|| ((Channel >= SLOT_F_PULSE_IN_START_CHAN) && (Channel <= SLOT_F_PULSE_IN_END_CHAN))) {
		slotNo = static_cast<UCHAR>((Channel - 1) % SYS_PULSE_CHAN_PER_BOARD);
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the board channel number from an analogue in channel
///
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetBoardChannelFromDigitalChannel(const USHORT IOChannelIn, const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	USHORT IOChannel = IOChannelIn;
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if (base == ZERO_BASED)
		IOChannel++;
	if ((IOChannel >= SLOT_G_DIGITAL_IO_START_CHAN) && (IOChannel <= SLOT_G_DIGITAL_IO_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((IOChannel >= SLOT_H_DIGITAL_IO_START_CHAN) && (IOChannel <= SLOT_H_DIGITAL_IO_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((IOChannel >= SLOT_I_DIGITAL_IO_START_CHAN) && (IOChannel <= SLOT_I_DIGITAL_IO_END_CHAN)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		slotNo = static_cast<UCHAR>((IOChannel - 1) % SYS_DIG_IO_CHAN_PER_BOARD);
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the board channel number from an analogue out channel
///
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetBoardChannelFromAnaOutChannel(const USHORT AnaChannelIn, const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	USHORT AnaChannel = AnaChannelIn;
	UCHAR slotNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if (base == ZERO_BASED)
		AnaChannel++;
	if ((AnaChannel >= SLOT_A_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_A_ANAL_OUT_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_B_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_B_ANAL_OUT_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_C_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_C_ANAL_OUT_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_D_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_D_ANAL_OUT_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_E_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_E_ANAL_OUT_END_CHAN)) {
		illegalChanNo = FALSE;
	} else if ((AnaChannel >= SLOT_F_ANAL_OUT_START_CHAN) && (AnaChannel <= SLOT_F_ANAL_OUT_END_CHAN)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		slotNo = static_cast<UCHAR>((AnaChannel - 1) % SYS_ANA_OUT_CHAN_PER_BOARD);
	}
	return slotNo;
}
//**********************************************************************
/// Obtains the system channel number from board and channel number
/// for an analogue out channel
///
/// @param[in] SlotNo - Slot number.
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The system channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetSysChannelFromAnaOutChannel(const USHORT SlotNo, const USHORT AnaChannel,
		const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	UCHAR cardChanNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if ((AnaChannel >= 0) && (AnaChannel <= HW_ANA_OUT_CHAN_PER_BOARD)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		if (base == ZERO_BASED)
			cardChanNo = (SlotNo * SYS_ANA_OUT_CHAN_PER_BOARD) + AnaChannel;
		else
			cardChanNo = (SlotNo * SYS_ANA_OUT_CHAN_PER_BOARD) + AnaChannel + 1;
	}
	return cardChanNo;
}
//******************************************************
// IsBoardTypeLegal()
///
/// Queries whether a given board type is legal
/// @param[in] boardType - Card type
///
/// @return TRUE if the board is known; otherwise FALSE
//******************************************************
const BOOL CSlotMap::IsBoardIOTypeLegal(const USHORT boardType) const {
	BOOL retValue = FALSE;
	if (((boardType >= BOARD_AI) && (boardType <= BOARD_PI)) || (boardType == BOARD_EZ_AI)) {
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
/// Obtains the system channel number from board and channel number
/// for an analogue in channel
///
/// @param[in] SlotNo - Slot number.
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetSysChannelFromAnaInChannel(const USHORT SlotNo, const USHORT AnaChannel,
		const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	UCHAR cardChanNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if ((AnaChannel >= 0) && (AnaChannel <= HW_ANA_IN_CHAN_PER_BOARD)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		if (base == ZERO_BASED)
			cardChanNo = (SlotNo * SYS_ANA_IN_CHAN_PER_BOARD) + AnaChannel;
		else
			cardChanNo = (SlotNo * SYS_ANA_IN_CHAN_PER_BOARD) + AnaChannel + 1;
	}
	return cardChanNo;
}
//**********************************************************************
/// Obtains the system channel number from board and channel number
/// for a pulse card pulse channel
///
/// @param[in] SlotNo - Slot number.
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetSysChannelFromDedicatedPulseChannel(const USHORT SlotNo, const USHORT Channel,
		const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	UCHAR cardChanNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if ((Channel >= 0) && (Channel <= HW_PULSE_CHAN_PER_BOARD)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		if (base == ZERO_BASED)
			cardChanNo = (SlotNo * SYS_PULSE_CHAN_PER_BOARD) + Channel;
		else
			cardChanNo = (SlotNo * SYS_PULSE_CHAN_PER_BOARD) + Channel + 1;
	}
	return cardChanNo;
}
//**********************************************************************
/// Obtains the system channel number from board and channel number
/// for a pulse channel on a digital I/O board
///
/// @param[in] SlotNo - Slot number.
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetSysChannelFromDigIOPulseChannel(const USHORT SlotNo, const USHORT IOChannel,
		const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	UCHAR cardChanNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if ((IOChannel >= 0) && (IOChannel <= HW_PULSE_CHAN_PER_BOARD)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		if (base == ZERO_BASED)
			cardChanNo = ((SlotNo - RECORDER_SLOT_G) * SYS_DIG_PULSE_CHAN_PER_BOARD) + IOChannel;
		else
			cardChanNo = ((SlotNo - RECORDER_SLOT_G) * SYS_DIG_PULSE_CHAN_PER_BOARD) + IOChannel + 1;
	}
	return cardChanNo;
}
//**********************************************************************
/// Obtains the system channel number from board and channel number
/// for a digital I/O channel
///
/// @param[in] SlotNo - Slot number.
/// @param[in] Channel - Analogue channel number.
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return		The board channel number (zero based); otherwise SMAP_ILLEGAL_INDEX
//**********************************************************************
UCHAR CSlotMap::GetSysChannelFromDigIOChannel(const USHORT SlotNo, const USHORT IOChannel, const T_PENBASE base) const {
	BOOL illegalChanNo = TRUE;
	UCHAR cardChanNo = SMAP_ILLEGAL_INDEX;			// Illegal slot
	if ((IOChannel >= 0) && (IOChannel <= HW_DIG_IO_CHAN_PER_BOARD)) {
		illegalChanNo = FALSE;
	}
	if (illegalChanNo == FALSE) {
		if (base == ZERO_BASED)
			cardChanNo = ((SlotNo - RECORDER_SLOT_G) * SYS_DIG_IO_CHAN_PER_BOARD) + IOChannel;
		else
			cardChanNo = ((SlotNo - RECORDER_SLOT_G) * SYS_DIG_IO_CHAN_PER_BOARD) + IOChannel + 1;
	}
	return cardChanNo;
}
//**********************************************************************
/// Obtains the digital pre process queue number from the digital board slot number
///
/// @param[in] SlotNo - Slot number.
/// @param[out] QueueNo - Pre-process queue number.
///
/// @return TRUE if card & channel have been succesfully identified; otherwise FALSE
///			Does not actually check that card and channel are actually fitted
//**********************************************************************
BOOL CSlotMap::GetDigitalPreProcessQueueFromDigitalBoard(const USHORT SlotNo, USHORT *pQueueNo) const {
	BOOL retValue = FALSE;
	if ((SlotNo >= RECORDER_SLOT_H) && (SlotNo <= RECORDER_SLOT_I)) {
		*pQueueNo = (SlotNo - RECORDER_SLOT_H) + m_LastBottomSlotPulseQueue;
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
/// Obtains the pre process queue number from the board and board channel number
///
/// @param[in] SlotNo - Slot number.
/// @param[in] Channel - Analogue channel number.
/// @param[out] QueueNo - Pre-process queue number.
///
/// @return TRUE if card & channel have been succesfully identified; otherwise FALSE
///			Does not actually check that card and channel are actually fitted
//**********************************************************************
BOOL CSlotMap::GetPreProcessQueueFromBoardChannel(const USHORT SlotNo, const USHORT Channel, USHORT *pQueueNo) const {
	BOOL retValue = FALSE;
	if ((SlotNo >= RECORDER_SLOT_A) || (SlotNo <= RECORDER_SLOT_I)) {
		if ((SlotNo >= RECORDER_SLOT_A) && (SlotNo < RECORDER_SLOT_G)) {
			*pQueueNo = (SlotNo * TOPSLOT_AICHAN_SIZE) + Channel;
			retValue = TRUE;
		} else {
			*pQueueNo = ((SlotNo - RECORDER_SLOT_G) * HW_BOTTOMSLOT_PULSECHAN_SIZE) + m_LastTopSlotQueue + 1 + Channel;
			retValue = TRUE;
		}
	}
	return retValue;
}
//**********************************************************************
/// Obtains the system channel number from the pre process queue number
///
/// @param[in] SlotNo - Slot number.
/// @param[out] QueueNo - Pre-process queue number.
/// @param[in] SysChannel - Analogue system channel number.
///
/// @return TRUE if card & channel have been succesfully identified; otherwise FALSE
///			Does not actually check that card and channel are actually fitted
//**********************************************************************
BOOL CSlotMap::GetSysChannelFromPreProcessQueue(const USHORT QueueNo, USHORT *pSysChannel) const {
	USHORT tempChan = 0;
	BOOL retValue = FALSE;
	if (QueueNo <= m_LastTopSlotQueue) {
		*pSysChannel = QueueNo;
		retValue = TRUE;
	} else {
		// Remap from sequential pulse channel queue numbering to match digital pulse
		tempChan = QueueNo - 1 - m_LastTopSlotQueue;
		if (tempChan < HW_BOTTOMSLOT_PULSECHAN_SIZE)
			*pSysChannel = tempChan;
		else if (tempChan < (HW_BOTTOMSLOT_PULSECHAN_SIZE * 2))
			*pSysChannel = tempChan - HW_BOTTOMSLOT_PULSECHAN_SIZE + SYS_DIG_PULSE_CHAN_PER_BOARD;
		else
			*pSysChannel = tempChan - (2 * HW_BOTTOMSLOT_PULSECHAN_SIZE) + (2 * SYS_DIG_PULSE_CHAN_PER_BOARD);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Gets the Data item CJC number from the slot number.
///
/// @param[in] chanNo - Card slot number.
/// @param[out] pCJCDIRef - CJC DI reference number.
/// @param[out] pCJCDegCDIRef - CJC DI reference number for Deg C.
///
/// @return		TRUE if valid CJC DI reference returned; otherwise FALSE
//**********************************************************************
BOOL CSlotMap::ObtainBoardsDICJCRef(const USHORT cardSlot, USHORT *pCJCDIRef, USHORT *pCJCDegCDIRef) const {
	BOOL retValue = TRUE;
	switch (cardSlot) {
	case RECORDER_SLOT_A:
		*pCJCDIRef = DI_IO_MISC_CJC1;
		*pCJCDegCDIRef = DI_IO_MISC_CJC1_C;
		break;
	case RECORDER_SLOT_B:
		*pCJCDIRef = DI_IO_MISC_CJC2;
		*pCJCDegCDIRef = DI_IO_MISC_CJC2_C;
		break;
	case RECORDER_SLOT_C:
		*pCJCDIRef = DI_IO_MISC_CJC3;
		*pCJCDegCDIRef = DI_IO_MISC_CJC3_C;
		break;
	case RECORDER_SLOT_D:
		*pCJCDIRef = DI_IO_MISC_CJC4;
		*pCJCDegCDIRef = DI_IO_MISC_CJC4_C;
		break;
	case RECORDER_SLOT_E:
		*pCJCDIRef = DI_IO_MISC_CJC5;
		*pCJCDegCDIRef = DI_IO_MISC_CJC5_C;
		break;
	case RECORDER_SLOT_F:
		*pCJCDIRef = DI_IO_MISC_CJC6;
		*pCJCDegCDIRef = DI_IO_MISC_CJC6_C;
		break;
	default:
		retValue = FALSE;
	}
	return retValue;
}
//**********************************************************************
/// Obtains the board and board channel number from the pre process queue number
///
/// @param[in] QueueNo - Pre-process queue number.
/// @param[out] SlotNo - Slot number.
/// @param[out] Channel - Analogue channel number.
///
/// @return TRUE if card & channel have been succesfully identified; otherwise FALSE
///			Does not actually check that card and channel are actually fitted
//**********************************************************************
BOOL CSlotMap::GetBoardChannelFromPreProcessQueue(const USHORT QueueNo, USHORT *pSlotNo, USHORT *pChannel) const {
	BOOL retValue = FALSE;
	USHORT normQueueNo = 0;
	if (QueueNo <= m_LastTopSlotQueue) {
		// This covers AI and pulse queues for cards in the top 6 slots.
		*pSlotNo = QueueNo / TOPSLOT_AICHAN_SIZE;
		*pChannel = QueueNo % TOPSLOT_AICHAN_SIZE;
		retValue = TRUE;
	} else {
		if (QueueNo <= m_LastBottomSlotPulseQueue) {
			// Bottom slot pulse channel queue
			normQueueNo = QueueNo - m_LastTopSlotQueue;
			*pSlotNo = (normQueueNo / HW_BOTTOMSLOT_PULSECHAN_SIZE) + RECORDER_SLOT_G;
			*pChannel = normQueueNo % HW_BOTTOMSLOT_PULSECHAN_SIZE;
			retValue = TRUE;
		} else if (QueueNo <= m_LastQueue) {
			// Digital I/P queue handles all board I/P channels
			normQueueNo = QueueNo - m_LastBottomSlotPulseQueue;
			*pSlotNo = normQueueNo + RECORDER_SLOT_G;
			*pChannel = 0;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Obtain card slot number and channel number from system channel number.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pSlotNo - The recorder I/O board slot number.
/// @param[out] pChanNo - The recorder I/O board slot channel number
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return TRUE if the slot & channel is legal; otherwise FALSE
//******************************************************
BOOL CSlotMap::GetSlotAndChannelFromAnalSysChan(const USHORT sysChannelNo, USHORT *pSlotNo, USHORT *pChanNo,
		const T_PENBASE base) const {
	BOOL retValue = FALSE;
	/// Otherwise cannot map config to recorder channels
	*pSlotNo = GetAnaInChannelSlotNo(sysChannelNo, base);
	*pChanNo = GetBoardChannelFromAnaInChannel(sysChannelNo, base);
	if ((*pSlotNo != SMAP_ILLEGAL_INDEX) && (*pChanNo != SMAP_ILLEGAL_INDEX))
		retValue = TRUE;
	return retValue;
}
//******************************************************
///
/// Obtain card slot number and channel number from system digital channel number.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] rSlotNo - The recorder I/O board slot number.
/// @param[out] rChanNo - The recorder I/O board slot channel number
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return TRUE if the slot & channel is legal; otherwise FALSE
//******************************************************
BOOL CSlotMap::GetSlotAndChannelFromDigitalSysChan(const USHORT sysChannelNo, USHORT &rSlotNo, USHORT &rChanNo,
		const T_PENBASE base) const {
	BOOL retValue = FALSE;
	rSlotNo = GetDigitalChannelSlotNo(sysChannelNo, base);
	rChanNo = GetBoardChannelFromDigitalChannel(sysChannelNo, base);
	if ((rSlotNo != SMAP_ILLEGAL_INDEX) && (rChanNo != SMAP_ILLEGAL_INDEX))
		retValue = TRUE;
	return retValue;
}
//******************************************************
///
/// Obtain card slot number and channel number from system channel number.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pSlotNo - The recorder pulse board slot number.
/// @param[out] pChanNo - The recorder pulse board slot channel number
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return TRUE if the slot & channel is legal; otherwise FALSE
//******************************************************
BOOL CSlotMap::GetSlotAndChannelFromPulseSysChan(const USHORT sysChannelNo, USHORT &rSlotNo, USHORT &rChanNo,
		const T_PENBASE base) const {
	BOOL retValue = FALSE;
	rSlotNo = GetPulseInChannelSlotNo(sysChannelNo, base);
	rChanNo = GetBoardChannelFromPulseInChannel(sysChannelNo, base);
	if ((rSlotNo != SMAP_ILLEGAL_INDEX) && (rChanNo != SMAP_ILLEGAL_INDEX))
		retValue = TRUE;
	return retValue;
}
//******************************************************
///
/// Obtain dedicated pulse card slot number and channel number from system channel number.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pSlotNo - The recorder pulse board slot number.
/// @param[out] pChanNo - The recorder pulse board slot channel number
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return TRUE if the slot & channel is legal; otherwise FALSE
//******************************************************
BOOL CSlotMap::GetSlotAndChannelFromDedicatedPulseSysChan(const USHORT sysChannelNo, USHORT &rSlotNo, USHORT &rChanNo,
		const T_PENBASE base) const {
	BOOL retValue = FALSE;
	rSlotNo = GetDedicatedPulseInChannelSlotNo(sysChannelNo, base);
	rChanNo = GetBoardChannelFromDedicatedPulseInChannel(sysChannelNo, base);
	if ((rSlotNo != SMAP_ILLEGAL_INDEX) && (rChanNo != SMAP_ILLEGAL_INDEX))
		retValue = TRUE;
	return retValue;
}
//******************************************************
///
/// Obtain card slot number and channel number from system channel number.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pSlotNo - The recorder I/O board slot number.
/// @param[out] pChanNo - The recorder I/O board slot channel number
/// @param[in] base - The base that the channel is referred to by (ZERO_BASED or ONE_BASED)
///
/// @return TRUE if the slot & channel is legal; otherwise FALSE
//******************************************************
BOOL CSlotMap::GetSlotAndChannelFromAnaOutSysChan(const USHORT sysChannelNo, USHORT *pSlotNo, USHORT *pChanNo,
		const T_PENBASE base) const {
	BOOL retValue = FALSE;
	/// Otherwise cannot map config to recorder channels
	*pSlotNo = GetAnaOutChannelSlotNo(sysChannelNo, base);
	*pChanNo = GetBoardChannelFromAnaOutChannel(sysChannelNo, base);
	if ((*pSlotNo != SMAP_ILLEGAL_INDEX) && (*pChanNo != SMAP_ILLEGAL_INDEX))
		retValue = TRUE;
	return retValue;
}
//**********************************************************************
/// Obtains the slot designator from slot number
///
/// @param[in] Slot - Slot number.
/// @param[out] IDText - Slot designator ID text.
///
//**********************************************************************
void CSlotMap::GetSlotStrID(const USHORT Slot, WCHAR *IDText) const {
	static WCHAR SlotId[MAX_SCHED_SERVICES][2] = { L"A", L"B", L"C", L"D", L"E", L"F", L"G", L"H", L"I" };
	if (Slot < MAXIOCARDS) {
#if _MSC_VER < 1400
		wcscpy(IDText, SlotId[Slot]);
#else
  wcscpy_s( IDText, 4, SlotId[Slot] );
#endif
		// right now IDText size is 4 WCHARS everywhere....
	} else {
#if _MSC_VER < 1400
		wcscpy(IDText, L"");
#else
  wcscpy_s( IDText, 4, L"" );
#endif
	}
}
//**********************************************************************
/// Obtains the I/O board designator
///
/// @param[in] boardType - Board type in the slot.
/// @param[out] IDText - Card designator ID text.
///
//**********************************************************************
void CSlotMap::GetIOCardStrID(const UCHAR boardType, QString *pIDText) const {
	switch (boardType) {
	case BOARD_AI:
	case BOARD_EZ_AI:
		*pIDText = QWidget::tr("AI");
		break;
	case BOARD_AO:
		*pIDText = QWidget::tr("AO");
		break;
	case BOARD_AR:
		*pIDText = QWidget::tr("Alarm");
		break;
	case BOARD_DIO:
		*pIDText = QWidget::tr("Digital I/O");
		break;
	case BOARD_PI:
		*pIDText = QWidget::tr("Pulse");
		break;
	}
}
//******************************************************
// GetBottomSlotChannelSelectedType()
///
/// Get the current channel type for any channel on any card from the CMM and qualify it with the current DevCaps.
/// I.e. Report the setup in the CMM that is currently selected on this configuration
/// @param[in] sysChanNumber - The board channel number.
///
/// @return Slot selected channel type
///
//******************************************************
USHORT CSlotMap::GetBottomSlotChannelSelectedType(const USHORT sysChanNumber, const T_PENBASE base) const {
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	USHORT chanType = CHANNEL_UNKNOWN;
	if (GetSlotAndChannelFromDigitalSysChan(sysChanNumber, slotNo, chanNo, base) == TRUE) {
		chanType = GetChannelSelectedType(slotNo, chanNo);
	}
	return chanType;
}
//******************************************************
// GetChannelSelectedType()
///
/// Get the current channel type for any channel on any card from the CMM and qualify it with the current DevCaps.
/// I.e. Report the setup in the CMM that is currently selected on this configuration
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The board channel number.
///
/// @return Slot selected channel type
///
//******************************************************
USHORT CSlotMap::GetChannelSelectedType(const USHORT slotNumber, const USHORT chanNumber) const {
	class CIOSetupConfig *pIOSetupConfig = NULL;
	USHORT chanType = CHANNEL_UNKNOWN;
	// Get what the CMM thinks it should be
	pIOSetupConfig = pSETUP->GetIOSetupConfig();
	if (pIOSetupConfig != NULL)
		chanType = pIOSetupConfig->GetChannelSelectedType(slotNumber, chanNumber, CONFIG_COMMITTED);
	// Now qualify it with the I/O card channel capabilities in the current device caps (if required)
	/*
	 if( IsCardInTopSlot( slotNumber ) == TRUE )
	 {
	 // Channel type will still be unknown if in the top slot
	 if( DEVICE_INFO.GetChannelCaps( slotNumber, chanNumber ) & CHANNEL_CAP_AI )
	 chanType = CHANNEL_AI;
	 else if( DEVICE_INFO.GetChannelCaps( slotNumber, chanNumber ) & CHANNEL_CAP_AO )
	 chanType = CHANNEL_AO;
	 else if( DEVICE_INFO.GetChannelCaps( slotNumber, chanNumber ) & CHANNEL_CAP_PULSE )
	 chanType = CHANNEL_PULSE;
	 }
	 else
	 */
	{
		// Channel will still need qualifying if the bottom slot; the CMM may not match the actual device capabilities
		if ((chanType == CHANNEL_DI) && !(DEVICE_INFO.GetChannelCaps(slotNumber, chanNumber) & CHANNEL_CAP_DI)) {
			chanType = CHANNEL_MISTMATCH;
		} else if ((chanType == CHANNEL_DO) && !(DEVICE_INFO.GetChannelCaps(slotNumber, chanNumber) & CHANNEL_CAP_DO)) {
			chanType = CHANNEL_MISTMATCH;
		}
		if ((chanType == CHANNEL_DIG_PULSE)
				&& !(DEVICE_INFO.GetChannelCaps(slotNumber, chanNumber) & CHANNEL_CAP_PULSE)) {
			chanType = CHANNEL_MISTMATCH;
		}
	}
	return chanType;
}
//******************************************************
// GetChannelSelectedType()
///
/// Get the current channel type for any channel on any card from the CMM and qualify it with the current
/// hardware identified by the I/O scheduler.
/// I.e. Report the setup in the CMM that is currently selected on this H/W configuration
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The board channel number.
///
/// @return Slot selected channel type
///
//******************************************************
USHORT CSlotMap::GetHWChannelSelectedType(const USHORT slotNumber, const USHORT chanNumber) const {
	class CIOSetupConfig *pIOSetupConfig = NULL;
	USHORT chanType = CHANNEL_UNKNOWN;
	// Get what the CMM thinks it should be
	pIOSetupConfig = pSETUP->GetIOSetupConfig();
	if (pIOSetupConfig != NULL) {
		// Get the selection from the CMM
		chanType = pIOSetupConfig->GetChannelSelectedType(slotNumber, chanNumber, CONFIG_COMMITTED);
	}
	// Qualify selection with actual hardware fitted
	chanType = QualifyChanWithIOSchedHW(slotNumber, chanNumber, chanType);
	return chanType;
}
//****************************************************************************
// const bool AICardsAvailable() const
///
/// Method that determines if any AI cards are available
///
/// @return True if there is at least one AI card available
///
//****************************************************************************
const BOOL CSlotMap::AICardsAvailable() const {
	BOOL bCardFound = FALSE;
	CBrdInfo *pkBrdInfo = CBrdInfo::GetHandle();
	for (USHORT usSlotNo = 0; usSlotNo < MAXIOCARDS; usSlotNo++) {
		if ( DEVICE_INFO.GetSlotType(usSlotNo) != BOARD_IMPOSSIBLE) {
			if ((pkBrdInfo->WhatBoardType(usSlotNo) == BOARD_AI)
					|| (pkBrdInfo->WhatBoardType(usSlotNo) == BOARD_EZ_AI)) {
				bCardFound = TRUE;
			}
		}
	}
	return bCardFound;
}
//****************************************************************************
// AOCardsAvailable()
///
/// Method that determines if any AO cards are available
///
/// @return True if there is at least one AO card available
///
//****************************************************************************
const BOOL CSlotMap::AOCardsAvailable() const {
	BOOL bCardFound = FALSE;
	CBrdInfo *pkBrdInfo = CBrdInfo::GetHandle();
	for (USHORT usSlotNo = 0; usSlotNo < MAXIOCARDS; usSlotNo++) {
		if ( DEVICE_INFO.GetSlotType(usSlotNo) != BOARD_IMPOSSIBLE) {
			if (pkBrdInfo->WhatBoardType(usSlotNo) == BOARD_AO) {
				bCardFound = TRUE;
			}
		}
	}
	return bCardFound;
}
//****************************************************************************
// DIOCardsAvailable()
///
/// Method that determines if any digital IO cards are available
///
/// @return True if there is at least one digital IO card available
///
//****************************************************************************
const BOOL CSlotMap::DIOCardsAvailable() const {
	BOOL bCardFound = FALSE;
	CBrdInfo *pkBrdInfo = CBrdInfo::GetHandle();
	for (USHORT usSlotNo = 0; usSlotNo < MAXIOCARDS; usSlotNo++) {
		if ( DEVICE_INFO.GetSlotType(usSlotNo) != BOARD_IMPOSSIBLE) {
			if (pkBrdInfo->WhatBoardType(usSlotNo) == BOARD_DIO) {
				bCardFound = TRUE;
			}
		}
	}
	return bCardFound;
}
//****************************************************************************
// const bool RelayCardsAvailable() const
///
/// Method that determines if any relay cards are available
///
/// @return True if there is at least one relay card available
///
//****************************************************************************
const BOOL CSlotMap::RelayCardsAvailable() const {
	BOOL bCardFound = FALSE;
	CBrdInfo *pkBrdInfo = CBrdInfo::GetHandle();
	for (USHORT usSlotNo = 0; usSlotNo < MAXIOCARDS; usSlotNo++) {
		if ( DEVICE_INFO.GetSlotType(usSlotNo) != BOARD_IMPOSSIBLE) {
			if (pkBrdInfo->WhatBoardType(usSlotNo) == BOARD_AR) {
				bCardFound = TRUE;
			}
		}
	}
	return bCardFound;
}
//****************************************************************************
// const bool PulseCardsAvailable() const
///
/// Method that determines if any pulse cards are available
///
/// @return True if there is at least one pulse card available
///
//****************************************************************************
const BOOL CSlotMap::PulseCardsAvailable() const {
	USHORT usSlotNo = 0;
	BOOL bCardFound = FALSE;
	CBrdInfo *pkBrdInfo = CBrdInfo::GetHandle();
	// Check whether pulse cards are fitted first
	for (usSlotNo = 0; usSlotNo < MAXIOCARDS; usSlotNo++) {
		if ( DEVICE_INFO.GetSlotType(usSlotNo) != BOARD_IMPOSSIBLE) {
			if (pkBrdInfo->WhatBoardType(usSlotNo) == BOARD_PI) {
				bCardFound = TRUE;
			}
		}
	}
	if ( FALSE == bCardFound) {
		// Now check DIO boards for any pulse channels
		for (usSlotNo = 0; usSlotNo < MAXIOCARDS; usSlotNo++) {
			if ( DEVICE_INFO.GetSlotType(usSlotNo) != BOARD_IMPOSSIBLE) {
				if (pkBrdInfo->WhatBoardType(usSlotNo) == BOARD_DIO) {
					bCardFound = TRUE;
				}
			}
		}
	}
	return bCardFound;
}
/* End of file */

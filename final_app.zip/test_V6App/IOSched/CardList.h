/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n CardList.h
/// @n interface of the CCardList class.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 44	Stability Project 1.41.1.1	7/2/2011 4:55:53 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 43	Stability Project 1.41.1.0	7/1/2011 4:27:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 42	V6 Firmware 1.41		12/1/2006 5:01:00 PM	Graham Waterfield
//		Seperate history and board stats upload information
// 41	V6 Firmware 1.40		11/28/2006 7:55:17 PM Graham Waterfield
//		Improve of description by name change and remove history reset fro
//		AO, digital & pulse boards
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_CARDLIST_H__ADE513C3_9F85_442D_A2A6_6B8E312021EF__INCLUDED_)
#define AFX_CARDLIST_H__ADE513C3_9F85_442D_A2A6_6B8E312021EF__INCLUDED_
#include "DevCaps.h"
#include "BoardManager.h"
#include "CardSlot.h"
#include "AOCard.h"
#include "TransMngr.h"
struct ServiceFirst_t {
	LONGLONG TimeCount;		///< Time command requires or required activation
	BOOL Found;					///< Has any board to service been found yet
	USHORT BoardID;	///< Board number, in array list, that needs servicing first
};
class CCardList {
private:
	BOOL m_scheduledAcqRqd[MAX_SCHED_SERVICES];	///< Sceduled acqsition is required from card
	UCHAR m_NoOfAICards;							///< AI board count
	UCHAR m_NoOfDigPulseCards;					///< Digital & pulse board count
	UCHAR m_NoOfAOCards;							///< AO board count
	USHORT m_DataReadyIOCard[RECORDER_SLOT_I + 1];
	// Base class I/O board holder for rapid common schedule query
	CCardSlot *m_pIOCard[MAX_SCHED_SERVICES];
	UCHAR m_SlotPosition[MAX_SCHED_SERVICES];						///< Derived class position of each slot position
	struct ServiceFirst_t m_PriorityService;
	///< Factory protocol to create concrete board types
	class CBaseProtocol *m_pInterrogateBoard;							///< Base protocol to allow query of I/O boards
	class CTransMangr *m_pTransMngr;			///< Associated transaction manager
	/// Data for card stats and info
	class CBrdInfo *m_pBrdInfoObj;			///< Board info holder
	class CBrdStats *m_pBrdStatsObj;		///< Board stats holder
//		class CDeviceAbstraction* m_pDevAbs;	///< Device abstraction layer
	class CPPQManager *m_pAPreProcQ;		///< latest max coverage value in APPQs (MarkD)
	UCHAR m_DigCrdProcState;				///< Digital card process state
	LONGLONG m_LastSystemTick;				///< Last system tick that cards were scheduled on
	LONGLONG m_DigitalLastSyncedSystemTick;	///< System tick that digital I/O cards were last synced at
public:
	CCardList();
	BOOL InitialiseCardList(void);
	BOOL AnyDigitalsRqrService(void);
	BOOL AnyCardBeingProcessed(void);
	BOOL AllCardSchedule(void);
	BOOL CardSchedule(const USHORT slotNo);
	BOOL CheckCardSchedule(const USHORT cardNo);
	class CChanList* GetChanSchedule(const USHORT cardNo);
	BOOL AddCardToSchedule(const USHORT cardNo, class CCardSlot *const pCardInst);
	class CCardSlot* GetCardReference(const USHORT cardNo);
	BOOL SetGlobalChannelID(const USHORT cardNo, const USHORT channelNo, const USHORT glbChannelNo);
	BOOL GetCardScheduleTime(LONGLONG *pTimeCount, USHORT *const pBoardID);
	BOOL CheckScheduledService(LONGLONG thisSystemTick);
	BOOL ActivatePriorityService(void);
	BOOL ScheduleClearBatchedData(const USHORT cardNo);
	virtual ~CCardList();
	BOOL IsDigitalInStatusUpdateRqd(USHORT boardSlotID);
	BOOL AddAICardToSchedule(const USHORT cardNo, class CAICard *const pCard);
	BOOL AddAOCardToSchedule(const USHORT cardNo, CAOCard *const pCard);
	BOOL AddDigPulseCardToSchedule(const USHORT cardNo, class CDigPulseCard *const pCard);
	BOOL SetupConfigChangePreparation(void);
	IOCARDSTAT IOCardCommand(const USHORT cardNo, const USHORT newCmd);
	void CleanUpAllIOCards(void);
	BOOL SetSpecialTestMode(const USHORT cardNo, const BOOL state);
	BOOL InitialiseCardConfigHolder(const USHORT cardNo);
	BOOL IsCMMConfigValid(const USHORT cardNo);
	BOOL UploadCMMConfiguration(void);
//		BOOL CMMUpdateConfig( const USHORT cardNo );
	BOOL ATECalUpdateConfig(void);
	BOOL ATECalDownloadConfig(void);
	BOOL QueryBoardType(const USHORT cardNo);
	BOOL QueryChannelTypes(const USHORT cardNo);
	BOOL QueryBoardConfig(const USHORT cardNo);
	BOOL ScheduleConfigUpload(const USHORT cardNo);
	BOOL ScheduleHistoryUpload(const USHORT cardNo);
	BOOL ScheduleBoardInfoUpload(const USHORT cardNo);
	BOOL ScheduleATEBoardInfoUpload(void);
	BOOL ScheduleATECalStatsUpload(void);
	BOOL CardBoardHandlerFactory(const USHORT cardSlotNo);
	BOOL DefaultIOCardHolders(const USHORT cardNo);
	BOOL DefaultAllIOCardHolders(void);
private:
	BOOL CardFactory(void);
	BOOL CleanUpFactory(void);
protected:
	BOOL GetATESlotNo(USHORT *const pATECardSlotNo);
	void CleanUpIOCard(const USHORT cardNo);
};
#endif // !defined(AFX_CARDLIST_H__ADE513C3_9F85_442D_A2A6_6B8E312021EF__INCLUDED_)

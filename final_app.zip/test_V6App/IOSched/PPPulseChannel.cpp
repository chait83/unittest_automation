/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PulseChannel.cpp
/// @n implementation for the CPulseChannel class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 45	Stability Project 1.40.1.3	7/2/2011 4:59:46 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 44	Stability Project 1.40.1.2	7/1/2011 4:38:39 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 43	Stability Project 1.40.1.1	3/17/2011 3:20:35 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 42	Stability Project 1.40.1.0	2/15/2011 3:03:41 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "PPL.h"
#include "ATECal.h"
#include "PPQManager.h"
#include "V6IOErrorCodes.H"
#include "BaseProtocol.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "V6globals.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "PPIOService.h"
#include "PPPulseChannel.h"
#include "TraceDefines.h"
#include <math.h>
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define MAX_PULSE_RETURN_READINGS 256
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPPPulseChannel::CPPPulseChannel(const BOOL chanInput) : CPPIOService(chanInput) {
//	qDebug("Create new CPPPulseChannel\n");
}
CPPPulseChannel::~CPPPulseChannel() {
//	qDebug("Delete CPPPulseChannel class\n");
}
/////////////////////////////////////////////////////
/// Create the default definition of an AO channel
/// @param[in] pboardInfo - The board process info.
/// @param[in] pchanInfo - The channel process info.
/// @param[in] pCard - The I/O board class.
/// @param[in] chanNo - The board channel number.
///
/// @return TRUE if channel configured; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPPulseChannel::CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo,
		T_CHANPROCESSINFO *const pchanInfo, class CCardSlot *const pCard, const USHORT chanNo) {
	BOOL retValue = FALSE;
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	pSlotMapObj = CSlotMap::GetHandle();
	if (pSlotMapObj != NULL) {
		pboardInfo->input = TRUE;
		pboardInfo->pCard = pCard;
		pboardInfo->CardSlotNo = static_cast<UCHAR>(pCard->BoardSlotInstance());
		pchanInfo->PPService = PP_SERVICE_PULSE_CHAN;
		pchanInfo->channelNo = static_cast<UCHAR>(chanNo);
		// Is it a top slot or bottom slot card channel that is being allocated (as this changes the channel system ID)
		if (pSlotMapObj->IsCardInTopSlot(pboardInfo->CardSlotNo) == TRUE) {
			pchanInfo->glbchannelNo = pSlotMapObj->GetSysChannelFromDedicatedPulseChannel(pboardInfo->CardSlotNo,
					chanNo, ONE_BASED);
		} else {
			pchanInfo->glbchannelNo = pSlotMapObj->GetSysChannelFromDigIOPulseChannel(pboardInfo->CardSlotNo, chanNo,
					ONE_BASED);
		}
		retValue = TRUE;
	}
	return TRUE;
}
/////////////////////////////////////////////////////
/// Report PPQ stats back to the IO scheduler
/// @param[in] pChanInfo - Channel specific data processing parameters.
///
/////////////////////////////////////////////////////
void CPPPulseChannel::ReportPPQDiagnostics(T_CHANPROCESSINFO *const pChanInfo) {
#ifndef V6IOTEST
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	pBrdStatsObj = CBrdStats::GetHandle();	// get a handle to the brd object
	pPPQManager = CPPQManager::GetHandle();
	if (pChanInfo->hPPQ != PPQC_INVALID_REFERENCE) {
		pBrdStatsObj->SetIOLossingTimestamps(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo,
				pPPQManager->m_APPPQServices.GetDroppedReadingCount(pChanInfo->hPPQ));
		pBrdStatsObj->SetIOGainingTimestamp(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo,
				pPPQManager->m_APPPQServices.GetInsertedReadingCount(pChanInfo->hPPQ));
		pBrdStatsObj->SetUnprocessedCoverage(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo,
				pPPQManager->m_APPPQServices.GetUnprocessedCoverage(pChanInfo->hPPQ));
	}
#endif
}
//******************************************************
// ResetPulseCountAccumulation()
///
/// Reset top and bottom slot pulse reading accumulation holders to default state
/// @param[in] pChanInfo - The channel process info.
/// 
//******************************************************
void CPPPulseChannel::ResetPulseCountAccumulation(T_PCHANPROCESSINFO pChanInfo) {
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	class CDataItem *pDataItem = NULL;
	pSlotMapObj = CSlotMap::GetHandle();
	// Reset the accumulated pulse count value
	if (pSlotMapObj->IsCardInTopSlot(pChanInfo->pCommon->CardSlotNo) == TRUE)
		pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_HCOUNT, pChanInfo->glbchannelNo - 1);
	else
		pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_LCOUNT, pChanInfo->glbchannelNo - 1);
	if (NULL != pDataItem) {
		pDataItem->SetValue(0.0F);
		pDataItem->SetStatus(DISTAT_NORMAL);
	}
}
//******************************************************
// ProcessPulseChannelReadings()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
/// @param[in] pChanInfo - System channel data.
/// @param[in] pChanData - Channel message data.
/// @param[in] timestamp - Timestamp of the latest reading in buffer.
/// @param[in] noOfReadings - Number of readings in buffer to be processed.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
BOOL CPPPulseChannel::ProcessPulseChannelReadings(T_CHANPROCESSINFO *const pChanInfo, const UCHAR *pChanData,
		const USHORT timestamp, const USHORT noOfReadings) {
	BOOL retValue = TRUE;
	DataItem2bytes newvalue;
	USHORT ReadingsProcessed = 0;
	BOOL firstReading = TRUE;
	class CATECal *pATECal = NULL;
#ifndef V6IOTEST
	float accumPulseCount;
	class CDataItem *pDataItem = NULL;
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
#endif
	class CBrdStats *pBrdStats = NULL;
	pBrdStats = CBrdStats::GetHandle();
#ifndef V6IOTEST
	pPPQManager = CPPQManager::GetHandle();
	pSlotMapObj = CSlotMap::GetHandle();
#endif
	if (noOfReadings > MAX_PULSE_RETURN_READINGS) {
		LogInternalError("TOO MANY READINGS FROM PULSE BOARD");
//		noOfReadings = 0;
		retValue = FALSE;
	} else {
		pChanInfo->lastTimestamp = timestamp;
		pChanInfo->readingsCount = static_cast<UCHAR>(noOfReadings);
		/// Calculate first reading timstamp
		pChanInfo->firstTimestamp = timestamp - (pChanInfo->timestampInterval * (noOfReadings - 1));
		pBrdStats->SetIOLastBatchStatus(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo, pChanInfo->firstTimestamp,
				pChanInfo->lastTimestamp, pChanInfo->readingsCount);
		// @todo: Scale the I/O card ticks to match Pre-process queues
//		pCommonInfo->PPCTVtimeStamp = m_pICService->SyncIOToPreProcessTimeLine( firstTimestamp, static_cast<UCHAR> (pCommonInfo->PPQGearing) );
		while (ReadingsProcessed < noOfReadings) {
			newvalue.UCData[SWAP_BYTE_1] = pChanData[0];
			newvalue.UCData[SWAP_BYTE_0] = pChanData[1];
			if (IsRunningAsATEEquipment() == TRUE) {
				pATECal = CATECal::GetHandle();
				if ((pATECal != NULL) && (pATECal->QueryATECardNo() == pChanInfo->pCommon->CardSlotNo)) {
					pATECal->PulseInChanCount[pChanInfo->channelNo] = newvalue.USData;
				}
			}
#ifndef V6IOTEST
			else {
				if (firstReading == TRUE) {
					/// Store first timestamped conditioned reading in pre-process buffer
					pPPQManager->m_APPPQServices.AddTimeStampedReading(pChanInfo->hPPQ, newvalue.USData,
							pChanInfo->firstTimestamp);
					firstReading = FALSE;
				} else {
					/// Store subsequent conditioned reading in pre-process buffer
					pPPQManager->m_APPPQServices.AddReading(pChanInfo->hPPQ, newvalue.USData);
				}
			}
			// Add the current count to the total number of pulses in the DIT
			if (NULL != pDIT) {
				if (pSlotMapObj->IsCardInTopSlot(pChanInfo->pCommon->CardSlotNo) == TRUE)
					pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_HCOUNT, pChanInfo->glbchannelNo - 1);
				else
					pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_LCOUNT, pChanInfo->glbchannelNo - 1);
				if (NULL != pDataItem) {
					accumPulseCount = pDataItem->GetFPValue();
					accumPulseCount += static_cast<float>(newvalue.USData);
					pDataItem->SetValue(accumPulseCount);
					pDataItem->SetStatus(DISTAT_NORMAL);
				}
			}
#endif
			ReadingsProcessed++;
			pChanData += sizeof(USHORT);				// Point to next reading
		}
		/*
		 if( pChanInfo->pCommon->pCard->HasProcessDataBeenReturned() == FALSE )
		 {
		 QString   strMess( QString   ::fromWCharArray("") );
		 strMess = QString::asprintf("Some data returned for slot %d\n", pChanInfo->pCommon->CardSlotNo);
		 qDebug(strMess);
		 }
		 */
		pChanInfo->pCommon->pCard->ProcessDataReturned( TRUE);
	}
//	qDebug("Added %d pulse rdgs to card %d", noOfReadings, pChanInfo->channelNo );
#ifndef V6IOTEST
	ReportPPQDiagnostics(pChanInfo);
#endif
	return retValue;
}
/////////////////////////////////////////////////////
/// Synchronise a channel preprocess queue
/// @param[in] pChanInfo - Channel specific data processing parameters.
/// @param[in] IOCardTick - I/O card tick to sync to.
/// @param[in] systemTick - The global system time to sync to.
///
/// @return TRUE if resync succedded; otherwise FALSE.
/////////////////////////////////////////////////////
BOOL CPPPulseChannel::SyncChannelQueue(T_CHANPROCESSINFO *const pChanInfo, const USHORT IOCardTick,
		const LONGLONG systemTick) {
	BOOL retValue = FALSE;
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	pPPQManager = CPPQManager::GetHandle();
	if (pPPQManager->m_APPPQServices.SyncPPQ(pChanInfo->hPPQ, IOCardTick, systemTick) == APPPQ_OK)
		retValue = TRUE;
#endif
	return retValue;
}
//******************************************************
///
/// Connencts to the apporiate Pre-Process queue
/// @param[in] pChanInfo - I/O channel process information.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CPPPulseChannel::InitialiseChanService(T_CHANPROCESSINFO *const pChanInfo) {
	BOOL retValue = FALSE;
#ifndef V6IOTEST
	T_PPQSER_RETURN_VALUE PPQState = PPQSER_INVALID_PPQ_HANDLE;
	class CBrdStats *pBrdStatsObj = NULL;				///< Board stats holder
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	class CSlotMap *pSlotMap = NULL;
	USHORT queueNo = 0;
	pBrdStatsObj = CBrdStats::GetHandle();
	pPPQManager = CPPQManager::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	// Request and enable the relevant channel pre-process queue or data item (as required)
	if (pChanInfo->chanInfo.DigChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled == TRUE) {
		if ((IsRunningAsATEEquipment() == FALSE)
				&& (pBrdStatsObj->HasLimitedRunModeBeenOrderedOnCard(pChanInfo->pCommon->pCard->BoardSlotInstance())
						== FALSE)) {
			// Only need pre-process queues if running in the recorder (ATECal structure is used for test equipment)
			// Request and enable the relevant channel pre-process queue, for only channels that require servicing;
			// if we have a handle on the Pre-process queue manager
			if (pPPQManager != NULL) {
				// Check whether service needs to be connected to a pre-process queue
				PPQState = pPPQManager->m_APPPQServices.RequestPPQ(pChanInfo->hPPQ);
				if (PPQState == PPQSER_OK) {
//					if( pChanInfo->chanInfo.DigChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled == TRUE )
					{
						// Initialise both top and bottom slot pulse input channels
						if (pChanInfo->pCommon->pCard->GetBoardType() == BOARD_PI) {
							PPQState = pPPQManager->m_APPPQServices.EnablePPQ(pChanInfo->hPPQ, PPQC_HIPULSE,
									pChanInfo->glbchannelNo - 1,
									ConvertToPPQ(pChanInfo->PPService,
											pChanInfo->chanInfo.DigChanInfo.pChanCfgInfo->ChanCfgInfo.acqEnum),
									PPQC_APCARD_TICK_RATE_200HZ);
						} else {
							pSlotMap->GetPreProcessQueueFromBoardChannel(pChanInfo->pCommon->pCard->BoardSlotInstance(),
									pChanInfo->channelNo, &queueNo);
							PPQState = pPPQManager->m_APPPQServices.EnablePPQ(pChanInfo->hPPQ, PPQC_LOPULSE, queueNo,
									ConvertToPPQ(pChanInfo->PPService,
											pChanInfo->chanInfo.DigChanInfo.pChanCfgInfo->ChanCfgInfo.acqEnum),
									PPQC_APCARD_TICK_RATE_50HZ);
						}
						if (PPQState == PPQSER_OK)
							retValue = TRUE;
					}
//					else
//					{
//						retValue = TRUE;		///< Disabled channels are not connected
//					}
//					if( PPQState == PPQSER_OK )
//						(static_cast<class CIOCard *> (pChanInfo->pCommon->pCard))->ScheduleQueueSync();
				}
			}
		}
	}
#else
	retValue = TRUE;
#endif
	return retValue;
}
/////////////////////////////////////////////////////
/// Process a set of unavailable board channel readings according to the channel setup
/// @param[in] pCommonInfo - The channel process info.
/// @param[in] pChanInfo - The channel process info.
/// @param[in] lastProcTime - The system time currently processed.
/// @param[in] procTime - The system time to process upto.
///
/// @return TRUE if one or more 'missing' readings could be added; otherwise FALSE
/////////////////////////////////////////////////////
LONGLONG CPPPulseChannel::ProcessMissingChannelReadings(T_COMMONPROCESSINFO *const pCommonInfo,
		T_CHANPROCESSINFO *const pChanInfo, const LONGLONG lastProcTime, const LONGLONG procTime) {
	BOOL success = FALSE;
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	class CDataItem *pDataItem = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	T_DATAITEM_STATUS status = DISTAT_INVALID;
	LONGLONG processedTime = 0;
	USHORT readingNo = 0;
	USHORT ReadingsRqd = 0;
	USHORT slotNo = 0;
	USHORT cardChanNo = 0;
	float noReadingAvailable = 0.0F;
	QString strasprintf("");
	pBrdInfo = CBrdInfo::GetHandle();		// get a handle to the brd object
	pBrdStatsObj = CBrdStats::GetHandle();
	pPPQManager = CPPQManager::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	pSlotMapObj = CSlotMap::GetHandle();
	if (pServiceManagerObj != NULL) {
		pICService = pServiceManagerObj->GetICService();
	}
	if (pChanInfo->chanInfo.AIChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled == TRUE) {
		slotNo = pChanInfo->pCommon->CardSlotNo;
		cardChanNo = pChanInfo->channelNo;
		ReadingsRqd = static_cast<USHORT>(((procTime + ROUND_READING_TIME_UP) - lastProcTime)
				/ pChanInfo->timestampInterval);
		processedTime = (ReadingsRqd * pChanInfo->timestampInterval);
		if ((pICService != NULL)) {
			// Get the NAN error code for a non operational channel(s)
			pICService->CreateFloatingPointRepresentation( IO_SCHED_CHAN_US, &noReadingAvailable);
			// Set the status of the accumulated pulse counter to the 'appropriate' error type
			status = pICService->ConvertFloatErrorToDITStatus(noReadingAvailable);
			if (pSlotMapObj->IsCardInTopSlot(pChanInfo->pCommon->CardSlotNo) == TRUE)
				pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_HCOUNT, pChanInfo->glbchannelNo - 1);
			else
				pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_LCOUNT, pChanInfo->glbchannelNo - 1);
			if (pDataItem != NULL) {
				pDataItem->SetStatus(status);
			}
#ifndef V6IOTEST
			if (IsRunningAsATEEquipment() == FALSE) {
				if (pChanInfo->hPPQ != PPQC_INVALID_REFERENCE) {
					// Loop filling all missing readings
					for (readingNo = 0; readingNo < ReadingsRqd; readingNo++) {
						// If no readings have yet been added to the queue (i.e. after a configuration change),
						// then we must add a timestamped reading to the queue
						if (pPPQManager->m_APPPQServices.IsPPQOperational(pChanInfo->hPPQ) == FALSE) {
							// Store NAN error in pre-process buffer to indicate no reading available
							pPPQManager->m_APPPQServices.AddTimeStampedReading(pChanInfo->hPPQ, noReadingAvailable,
							NO_RESPONSE_IO_TICK_DEFAULT);
						} else {
							// Store NAN error in pre-process buffer to indicate no reading available
							pPPQManager->m_APPPQServices.AddReading(pChanInfo->hPPQ, noReadingAvailable);
						}
					}
					success = TRUE;
					ReportPPQDiagnostics(pChanInfo);
				}
			} else
#endif
			{
				success = TRUE;		// No need to connect to PPQ
			}
		}
	}
	return processedTime;
}

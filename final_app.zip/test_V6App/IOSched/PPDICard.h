/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PPDICard.h
/// @n Desc:	Interface of the Pre-process DI card class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 17	Stability Project 1.14.1.1	7/2/2011 4:59:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 16	Stability Project 1.14.1.0	7/1/2011 4:27:16 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 15	V6 Firmware 1.14		6/9/2006 1:12:01 PM	Graham Waterfield
//		Merged phase 2 development
// 14	V6 Firmware 1.13		10/4/2005 11:17:22 PM Graham Waterfield
//		Alarm board test equipment fixes
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PPDICARD_H
#define _PPDICARD_H
#include "Defines.h"
#include "PPIOService.h"
#if !defined(AFX_PPDICARD_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PPDICARD_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CPPDICard: public CPPIOService {
public:
	CPPDICard(BOOL isChanInput);
	virtual ~CPPDICard();
	BOOL InitialiseChanService(T_COMMONPROCESSINFO *const pBoardInfo);
	BOOL InitialiseBoardService(T_COMMONPROCESSINFO *pboardInfo, class CCardSlot *const pCard);
	BOOL SyncPPQueue(T_PCOMMONPROCESSINFO pBoardInfo, const USHORT IOCardTick, const LONGLONG systemTick);
	BOOL ResyncPPQueue(T_PCOMMONPROCESSINFO pBoardInfo, const USHORT IOCardTick, const LONGLONG systemTick);
	BOOL ProcessCardReadings(const USHORT state, const USHORT timeStamp);
	BOOL ProcessDigitalInReadings(T_PCOMMONPROCESSINFO pCardInfo, const UCHAR *pCardData,
			const USHORT noOfBytesToProcess);
	BOOL SetLastReadingCoverage(T_PCOMMONPROCESSINFO pCardInfo, const LONGLONG systemTick);
	BOOL CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
			class CCardSlot *pCard,
			USHORT chanNo);
private:
	T_PPQC_DIGITAL_PPQ_TYPE GetDigitalPPQReference(T_PCOMMONPROCESSINFO pBoardInfo);
	BOOL m_firstReadingAdded; ///< TRUE if the firts reading has been added to the queue
public:
	// Places were channel data needs to be placed (and form it should take?)
};
#endif // !defined(AFX_PPDICARD_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif // _PPDICARD_H

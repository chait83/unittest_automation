/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOScheduler.cpp
/// @n implementation of the IOScheduler class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 126 Stability Project 1.121.1.3	7/2/2011 4:58:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 125 Stability Project 1.121.1.2	7/1/2011 4:38:22 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 124 Stability Project 1.121.1.1	3/17/2011 3:20:26 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 123 Stability Project 1.121.1.0	2/15/2011 3:03:11 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
//#include "DevCaps.h"
#include "V6globals.h"
#include "BoardManager.h"
#include "BaseProtocol.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "CardList.h"
#include "ConfigManager.h"
#include "V6ActiveModule.h"
#include "IOScheduler.h"
#include "IOSchedulerThread.h"
#include "ModuleConstants.h"
#include "TraceDefines.h"
#include "IOMemManager.h"
#include "InputConditioning.h"
#include "ATECal.h"
#include "PPL.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//USHORT CIOScheduler::m_usForceIOResetSlot = 0;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CIOScheduler::CIOScheduler(T_MODULE_ID moduleId) : CV6ActiveModule(moduleId)
#ifdef DBG_FILE_LOG_IO_SCHED_ENABLE
									, m_debugFileLogger(L"\\SDMemory\\IOSchedulerLogFile.txt" )
#endif
{
//	qDebug("Create new CIOScheduler class\n");
// Get the handle on the abstraction layer, local board info, stats and config manager
	m_pBrdInfoObj = CBrdInfo::GetHandle();
	m_pBrdStatsObj = CBrdStats::GetHandle();
	m_pCardHldr = new class CCardList;			///< Card list holder creation
	m_pCIOConfigManagerObj = CIOConfigManager::GetHandle();
	m_pMsg = NULL;			// No command currently being processed
}
CIOScheduler::~CIOScheduler() {
//	qDebug("Delete CIOScheduler class\n");
	// Remove the cards
	delete m_pCardHldr;
}
//******************************************************
// QueryIOHardware()
///
/// Queries the I/O hardware to determine capabilities
///
/// @return TRUE if IO hardware is queried successfully; otherwise FALSE
/// 
/// @pre: require recorder type to be available
//******************************************************
BOOL CIOScheduler::QueryIOHardware(void) {
	BOOL retValue = TRUE;
	if (m_pCardHldr == NULL) {
		// Could not create card list holder
		retValue = FALSE;
	}
	if (m_pBrdInfoObj == NULL) {
		// Could not get handle/create board info
		retValue = FALSE;
	}
	if (m_pBrdStatsObj == NULL) {
		// Could not get handle/create board stats
		retValue = FALSE;
	}
	// Configuration manager is checked when checking/uploading CMM
	// On first run, so create concrete instances of all I/O classes
	if (retValue == TRUE) {
		if (m_pCardHldr->InitialiseCardList() == FALSE) {
			// Could not create board instances
			retValue = FALSE;
		}
	}
	return retValue;
}
//******************************************************
// UpdateBoardCapabilities()
///
/// Copies the board capabilities from the local holder into global device configuration
///
/// @return		TRUE if the device capability update is successful; otherwise FALSE
//******************************************************
BOOL CIOScheduler::UpdateBoardCapabilities(void) {
	USHORT slotNo;
	USHORT boardType;
	USHORT chanNo;
	USHORT channelCount = 0;
	UCHAR chanCap = 0;
	BOOL retValue = TRUE;
	// For each board fitted to a system, copy over to global board capabilities from the local stats
	DEVICE_INFO.SetIOCardInfo(MAXIOCARDS);
	for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
		boardType = DEVICE_INFO.GetSlotType(slotNo);
		// Only update the device capability if a board can be in the slot
		if (boardType != BOARD_IMPOSSIBLE) {
			channelCount = m_pBrdInfoObj->GetNoOfChannels(slotNo);
			DEVICE_INFO.SetSlotInfo(slotNo, m_pBrdInfoObj->WhatBoardType(slotNo), channelCount);
			for (chanNo = 0; chanNo < channelCount; chanNo++) {
				chanCap = m_pBrdInfoObj->WhatAvailableChannelType(slotNo, chanNo);
				DEVICE_INFO.SetChannelCaps(slotNo, chanNo, chanCap);
			}
			if ((BOARD_AR == m_pBrdInfoObj->WhatBoardType(slotNo)) && (HW_4_CHAN_RELAY_BOARD_CHANS == channelCount)) {
				// If it is a 4 channel Alarm board then there is a special input that can be used for internal use only
				m_pBrdInfoObj->SetAvailableChannelType(slotNo,
				HW_INPUT_NO_4_CHAN_EXTA, (CHANNEL_CAP_DI | CHANNEL_CAP_DO));
			}
			// the modified device capability table will be saved later during startup sequence
		}
	}
	return retValue;
}
//******************************************************
///
/// Copies the board capabilities from the local holder into global device configuration
///
/// @return		TRUE if the CMM upload is successful to at least one I/O board; otherwise FALSE
//******************************************************
BOOL CIOScheduler::UploadCMMConfiguration(void) {
//	USHORT slotNo;
	BOOL retValue = TRUE;			// It passes if there is no cards fitted to download configuartion to
//	CCardSlot *pSlot = NULL;
	CTV6Timer factoryTimer(TIMER_HIGH_RES);		// Total time in factory
	LONGLONG timetaken = (LONGLONG) 0L;
	// Transaction timer reset
	//qDebug("Starting Card Channel Factory timer\n");
	factoryTimer.ResetAllTimers();
	factoryTimer.StartTimer();
	if (m_pCIOConfigManagerObj != NULL) {
		// Inform system which configuration is being used
		retValue = m_pCIOConfigManagerObj->InitialiseConfigManager();
		retValue = m_pCardHldr->UploadCMMConfiguration();
	}
	// @todo: If the configuration creation and download takes too long then a reset and
	// resync of the queues can be done at this point
	// Calculate the time that the factory took
	factoryTimer.StopTimer();
	timetaken = factoryTimer.GetTimeInMilliSec(TIMER_SINGLE);
	//qDebug("Card Channel Factory took %dmS\n", static_cast<int> (timetaken));
	return retValue;
}
//******************************************************
// InitialiseScheduler()
///
/// Create the module thread - suspended
///
/// @pre: requires recorder structure to be created
//******************************************************
BOOL CIOScheduler::InitialiseScheduler(void) {
	BOOL Success = FALSE;
	// Register the with the MMM and then the control sequencer
	Success = RegisterForModeSelect();
	return Success;
}
//******************************************************
// ScheduleService()
///
/// Schedule the card slots to be polled
///
/// @return TRUE if schedule is succesfully set; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::ScheduleService(void) {
	m_pCardHldr->AllCardSchedule();
	return TRUE;
}
//******************************************************
// ActivatePriorityService()
///
/// Schedule the needy I/O operation
///
/// @return TRUE if schedule is succesfully executed; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::ActivatePriorityService(void) {
	BOOL retValue = FALSE;
	/*----------------------------------------
	 Code Changes to handle Secondary reset condition
	 *-------------------------------------------*/
	/*class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	 pBrdStatsObj = CBrdStats::GetHandle();
	 if( pBrdStatsObj->IsConfigChangeRequired() == TRUE )
	 {	
	 pBrdStatsObj->SetConfigChange(FALSE);
	 
	 T_MOD_CFG_CHG_MSGDATA msg;
	 msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
	 msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
	 msg.ConfigChangeAction=MOD_CFG_CHG_ACTION_UPDATE;
	 m_ModuleMsgManagerClient.MMMClientPostIntMsg(	INFINITE,
	 MODULE_CONTROL_SEQUENCER, 
	 MODULE_IO_SCHEDULER, 
	 MOD_CONFIG_CHANGE,
	 sizeof(T_MOD_CFG_CHG_MSGDATA),
	 (BYTE*)&msg );		
	 LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_INFORMATION, L"IO Communication failure detected. Recovered from the failure" );
	 
	 }*/
	/*----------------------------------------
	 Code Changes to handle Secondary reset condition ends
	 *-------------------------------------------*/
	// Schedule I/O card timeslice
	retValue = m_pCardHldr->ActivatePriorityService();
	return retValue;
}
//******************************************************
// GetScheduleTime()
///
/// Get the time that the card needs scheduling
///
/// @return Time at which card requires scheduling
/// 
//******************************************************
DWORD CIOScheduler::GetScheduleTime(void) {
	m_pCardHldr;
	return TRUE;
}
//******************************************************
///
/// Commits the CMM configuration for I/O scheduler use
///
/// @return TRUE if initialised succesfully; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::IOCommitCMM(void) {
	BOOL retValue = FALSE;
	m_pBrdStatsObj->ResetFirstPowerUp();
	retValue = UploadCMMConfiguration();
	return retValue;
}
//******************************************************
///
/// Primary Initialisation of the Module
///
/// @return V6ACTMOD_OK if intialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::PerformPrimaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CPPIOServiceManager *pServiceManagerObj = NULL;
	// Start execution in idle mode, so that queues data is not yet being produced
	pBrdStatsObj = CBrdStats::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pBrdStatsObj != NULL) {
		pBrdStatsObj->SetIdleMode();
		if (pServiceManagerObj != NULL) {
			// Load last stored non-volatile calibrations etc in the input conditioning
			if (pServiceManagerObj->InitialiseServiceManager() == TRUE) {
				// Copy over non-volatile calibration to CMM
				retValue = V6ACTMOD_OK;
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Secondary Initialisation of the Module
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::PerformSecondaryInitialisation(void) {
	m_pCardHldr->DefaultAllIOCardHolders();
	return V6ACTMOD_OK;
}
//******************************************************
///
/// Method called when Module goes into Normal Operation
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::NormalOperation(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	BOOL retValue = TRUE;
	// Cancel idle mode
	pBrdStatsObj = CBrdStats::GetHandle();
	pBrdStatsObj->CancelIdleMode();
	if (retValue == TRUE)
		return V6ACTMOD_OK;
	return V6ACTMOD_ACTION_NOT_PERFORMED;
}
//******************************************************
///
/// Method called when Module is to prepare for Setup Config Change 
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::SetupConfigChangePreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CPPIOServiceManager *pServiceManagerObj = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if ((pBrdStatsObj != NULL) && (pServiceManagerObj != NULL)) {
		// Put all boards into idle mode
		pBrdStatsObj->SetIdleMode();
		// Prepare all cards for a configuartion change
		m_pCardHldr->SetupConfigChangePreparation();
		// Reset all PPQ's including those enabled by demo channels
		pServiceManagerObj->ResetAllPPQsToDefault();
		// Remove the user linearisation tables
		retValue = V6ACTMOD_OK;
	}
	m_pCardHldr->DefaultAllIOCardHolders();
	return retValue;
}
//******************************************************
///
/// Method called when a Module is to prepare for Shutdown
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::ShutdownPreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CPPIOServiceManager *pServiceManagerObj = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	if (pBrdStatsObj != NULL) {
		pBrdStatsObj->SetIdleMode();
		retValue = V6ACTMOD_OK;
	}
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL) {
		pServiceManagerObj->ResetAllPPQsToDefault();		// Reset all PPQ's including those enabled by demo channels
	}
	return retValue;
}
//******************************************************
///
/// Method called when a Module is to Shutdown
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::Shutdown(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	pBrdStatsObj = CBrdStats::GetHandle();
	if (pBrdStatsObj != NULL) {
		pBrdStatsObj->ShutdownOrdered();
		retValue = V6ACTMOD_OK;
	}
	return retValue;
}
//******************************************************
///
/// Method called when Module is to carry out Setup Change Completion
/// (before Normal operation)
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::SetupConfigChangeComplete(void) {
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	if (IOCommitCMM() == TRUE) {
		pServiceManagerObj = CPPIOServiceManager::GetHandle();
		pICService = pServiceManagerObj->GetICService();
		if (pICService->IOBoardCalWrkCommit() == TRUE)
			retValue = V6ACTMOD_OK;
		m_pCardHldr->DefaultAllIOCardHolders();
	}
	if (pServiceManagerObj != NULL) {
		// Load new user linearisation tables in the input conditioning
		if (pServiceManagerObj->CommitServiceManager() == FALSE) {
			retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
		}
	}
	// Do not activate I/O scheduler again until NormalOperation
	return retValue;
}
//******************************************************
///
/// Method called when Module is informed to Carry out Query Hardware
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::ATEQueryHardware(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	// Setup query of calibration status for the ATE board
	if (m_pCardHldr->ScheduleATECalStatsUpload() == TRUE)
		retValue = V6ACTMOD_OK;
	pBrdStatsObj = CBrdStats::GetHandle();
	/// Activate I/O scheduler again
	if (pBrdStatsObj != NULL)
		pBrdStatsObj->CancelIdleMode();
	return retValue;
}
//******************************************************
///
/// Method called when Module is informed to perform ATE Calibration
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::ATECalibration(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	class CBrdStats *pBrdStatsObj = NULL;				///< Board stats holder
	class CATECal *pATECalStruct = NULL;
	pATECalStruct = CATECal::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if ((pATECalStruct != NULL) && (pBrdStatsObj != NULL)) {
		if (pATECalStruct->SetToCalibrateMode() == TRUE)
			retValue = V6ACTMOD_OK;
		/// Activate I/O scheduler again
		pBrdStatsObj->CancelIdleMode();
	}
	return retValue;
}
//******************************************************
///
/// Method called when Module is informed to perform ATE Test
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::ATETest(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED;
	class CBrdStats *pBrdStatsObj = NULL;				///< Board stats holder
	class CATECal *pATECalStruct = NULL;
	pATECalStruct = CATECal::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if ((pATECalStruct != NULL) && (pBrdStatsObj != NULL)) {
		if (pATECalStruct->RemoveCalibrateMode() == TRUE)
			retValue = V6ACTMOD_OK;
		/// Activate I/O scheduler again
		m_pBrdStatsObj->CancelIdleMode();
	}
	return retValue;
}
//******************************************************
///
/// Method called when the Calibration Info has been updated, and can be processed
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::ProcessCalibrationInfo(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CATECal *pATECalStruct = NULL;
	T_CAL_TEST_OP_MODE opMode;
	T_CAL_MODE calMode;
	BOOL success = TRUE;
	BOOL setupUpdated = FALSE;
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_INITIALISATION_FAILED;
	class CIOConfigManager *pConfigMngr = NULL;
	class CConfig *pConfig = NULL;
	class CAIConfig *pAIConfig = NULL;
	class CAOConfig *pAOConfig = NULL;
	class CDigConfig *pDigConfig = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	UCHAR boardType = BOARD_INVALID;
	pATECalStruct = CATECal::GetHandle();
	pBrdInfo = CBrdInfo::GetHandle();
	if ((pBrdInfo != NULL) && (pATECalStruct != NULL))
		boardType = pBrdInfo->WhatBoardType(pATECalStruct->QueryATECardNo());
	pConfigMngr = CIOConfigManager::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if ((pBrdStatsObj != NULL) && (pATECalStruct != NULL)) {
		/// Suspend the I/O scheduler whilst we update the configuration
		pBrdStatsObj->SetLimitedRunMode();
		// Can either be run-time or configuration info updated
		if (pATECalStruct->IsSetupUpdated() == TRUE) {
			// If cal update is required then commit the calibration structure to the local configuration
			setupUpdated = m_pCardHldr->ATECalUpdateConfig();
		} else {
			// It is just run-time info that requires updating
		}
	}
	if ((pConfigMngr != NULL) && (pBrdInfo != NULL) && (boardType != BOARD_INVALID)) {
		switch (boardType) {
		case BOARD_AI:
		case BOARD_EZ_AI:
//			retValue = CommitAIATECalStruct();
			// Get a handle on the relevant board's AI configuration
			pAIConfig = pConfigMngr->GetAILocalConfig(pATECalStruct->QueryATECardNo());
			pConfig = static_cast<CConfig*>(pAIConfig);
			break;
		case BOARD_AO:
//			retValue = CommitAOATECalStruct();
			pAOConfig = pConfigMngr->GetAOLocalConfig(pATECalStruct->QueryATECardNo());
			pConfig = static_cast<CConfig*>(pAOConfig);
			pAOConfig->ScheduleBoardProcess();
			break;
		case BOARD_DIO:
		case BOARD_PI:
		case BOARD_AR:
//			retValue = CommitDigPulseATECalStruct();
			pDigConfig = pConfigMngr->GetDigLocalConfig(pATECalStruct->QueryATECardNo());
			pConfig = static_cast<CConfig*>(pDigConfig);
			break;
		}
	}
	qDebug("Processing calibration info\n");
	/// @note: All other modules must previously be set to idle when calibrating inside recorder
	if ((pBrdStatsObj != NULL) && (pATECalStruct != NULL)) {
		/// Suspend the I/O scheduler whilst we update the configuration
//		pBrdStatsObj->SetIdleMode();
		// Can either be run-time or configuration info updated
		if (pATECalStruct->IsSetupUpdated() == TRUE) {
			/// Suspend the I/O scheduler whilst we update the configuration
			pBrdStatsObj->SetIdleMode();
			// If cal update is required then commit the calibration structure to the local configuration
			setupUpdated = m_pCardHldr->ATECalDownloadConfig();
		} else {
			// It is just run-time info that requires updating
			pBrdStatsObj->SetLimitedRunMode();
		}
//		if( success == TRUE )
		{
			opMode = pATECalStruct->GetOperationalMode();
			if (opMode == CTOM_ATE_CAL_RT_CHAN) {
				if ((boardType == BOARD_AI) || (boardType == BOARD_EZ_AI)) {
					success = pAIConfig->ScheduleRTChanCal();
				}
				// Do not change state
			} else if (opMode == CTOM_ATE_SET_BOARD_ID) {
				switch (boardType) {
				case BOARD_AI:
				case BOARD_EZ_AI:
					success = pAIConfig->ScheduleSerialNoUpdate();
					success = pAIConfig->ScheduleUpdateCardInfo();
					break;
				case BOARD_AO:
					success = pAOConfig->ScheduleSerialNoUpdate();
					success = pAOConfig->ScheduleUpdateCardInfo();
					break;
				case BOARD_DIO:
				case BOARD_PI:
				case BOARD_AR:
					success = pDigConfig->ScheduleSerialNoUpdate();
					success = pDigConfig->ScheduleUpdateCardInfo();
					break;
				}
				pATECalStruct->SetCalModeState(CTOM_ATE_READ);
			} else if (opMode == CTOM_ATE_SET_TEST_STAT) {
				switch (boardType) {
				case BOARD_AI:
				case BOARD_EZ_AI:
					success = pAIConfig->ScheduleTestStatusUpdate();
					break;
				case BOARD_AO:
					success = pAOConfig->ScheduleTestStatusUpdate();
					break;
				case BOARD_DIO:
				case BOARD_PI:
				case BOARD_AR:
					success = pDigConfig->ScheduleTestStatusUpdate();
					break;
				}
				pATECalStruct->SetCalModeState(CTOM_ATE_READ);
			} else if (opMode == CTOM_ATE_CAL_COMMIT_SET_POINTS) {
				// Command to set calibrate points should only be from an AI or AO card
				if ((boardType == BOARD_AI) || (boardType == BOARD_EZ_AI) || (boardType == BOARD_AO)) {
					// Schedule the calibration download
					calMode = pATECalStruct->GetCalMode();
					if ((calMode == CM_ATE_FACTORY_CAL) || (calMode == CM_ATE_FACTORY_RT_CHAN_CAL)) {
						if (((boardType == BOARD_AI) || (boardType == BOARD_EZ_AI)) && (pAIConfig != NULL)) {
							success = pAIConfig->ScheduleFactoryCalUpload();
							// If it is the RT channel calibration, then only the factory calibration should be saved
							if (calMode == CM_ATE_FACTORY_CAL)
								success = pAIConfig->ScheduleUserCalUpload();
						} else if ((boardType == BOARD_AO) && (pAOConfig != NULL)) {
							success = pAOConfig->ScheduleFactoryCalUpload();
						}
					} else if ((calMode == CM_ATE_USER_CAL) && (pAIConfig != NULL)) {
						success = pAIConfig->ScheduleUserCalUpload();
					}
				}
			} else if (opMode == CTOM_ATE_CAL_COMMIT_SET_RT_POINTS) {
				if (pAIConfig != NULL) {
					success = pAIConfig->ScheduleFactoryCalUpload();
				}
			}
		}
		if (pATECalStruct != NULL) {
			// Reset the fact that no readings have yet been taken
			pATECalStruct->NoAIChanRawReadingsTaken();
		}
//		if( success == TRUE )
		retValue = V6ACTMOD_OK;
		/// Activate I/O scheduler again, if in test equipment mode
		if (IsRunningAsATEEquipment() == TRUE) {
			pBrdStatsObj->CancelIdleMode();
			pBrdStatsObj->CancelLimitedRunMode();
		}
	}
	return retValue;
}
//******************************************************
///
/// Method called when the IO Scheduler is told to Process Card Readings in ATE mode
///
/// @return V6ACTMOD_OK if initialised succesfully; otherwise V6ACTMOD_ACTION_NOT_PERFORMED
/// 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::ProcessATECardChannels(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CATECal *pATECalStruct = NULL;
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_INITIALISATION_FAILED;
	pATECalStruct = CATECal::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if ((pATECalStruct != NULL) && (pBrdStatsObj != NULL)) {
		// Reset the queues (if required), and reading complete state on all card channels
		pATECalStruct->NoAIChanRawReadingsTaken();
		pATECalStruct->SetReadingCheckRqdState( TRUE);
		// Make reading on all channels
//		while( pATECalStruct->TestAIChanRawReadingsCompleted() != TRUE )
//			sleep(250);		///< Keep looping until all channels acquired
		// Set to idle mode
//		pBrdStatsObj->SetIdleMode();
		// Transfer the readings
//		pATECalStruct->AIStoreRawChannels(255);
		// Reschedule normal operation
//		pBrdStatsObj->CancelIdleMode();
	}
	// Tell main app that readings are waiting
//	PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_ALL_CHANNELS_READY, 0, 0);
	return retValue;
}
//******************************************************
// CheckATECardReadingsAvailable()
///
/// Checks whether the ATE readings have been completed.
/// If so then a readings are copied to safe area and a 
/// message is posted off to say that readings are available
///
/// @return TRUE if readings succusfully obtained; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::CheckATECardReadingsAvailable(void) {
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CATECal *pATECalStruct = NULL;
	BOOL retValue = FALSE;
	pATECalStruct = CATECal::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if ((pATECalStruct != NULL) && (pBrdStatsObj != NULL)) {
		// When readings completed on all channels
		if ((pATECalStruct->ReadingCheckRqd() == TRUE) && (pATECalStruct->TestAIChanRawReadingsCompleted() == TRUE)) {
			// Set to idle mode
			pBrdStatsObj->SetIdleMode();
			// Transfer the readings
//			pATECalStruct->AIStoreRawChannels(0xff);
			pATECalStruct->AIStoreRawChannels(pATECalStruct->GetChannelSelectionMask());
			// Reschedule normal operation
			pBrdStatsObj->CancelIdleMode();
			// Tell main app that readings are waiting
			//PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_ALL_CHANNELS_READY, 0, 0);
			// Tell main app that readings are waiting
			pATECalStruct->InformCalibrationReadingsAvailable();
			// Mark that readings are available (that IOSceduler is no longer busy waiting)
			pATECalStruct->SetReadingCheckRqdState( FALSE);
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
// RegisterForModeSelect()
///
/// Register an MMM client for the IO scheduler
/// @param[in] maxTime - The time to wait if no command message is received.
///
/// @return TRUE if registered succesfully; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::RegisterForModeSelect(void) {
	BOOL retValue = TRUE;
	// Register to the Module Message Manager to receive message using Events
	if (m_mmClient.MMMClientRegister(MODULE_IO_SCHEDULER, MODULE_USE_EVENT, CAMQ_QUEUE_WRAP_DISABLED)
			!= MMMCLIENT_REGISTRATION_SUCCESSFUL)
		retValue = FALSE;
	return retValue;
}
//******************************************************
// CommitLocalDeviceCapabilities()
///
/// Commits (copies) the local recorder board configuration to the recorder global configuration 
///
/// @return TRUE if the device capabilities have been successfully updated; otherwise FALSE 
/// 
//******************************************************
BOOL CIOScheduler::CommitLocalDeviceCapabilities(void) {
	USHORT slotNo;
	USHORT chanNo;
	USHORT chanCount;
	// Set maximum number of IO cards
	DEVICE_INFO.SetIOCardInfo(MAXIOCARDS);
	// Copy board obtained channel info over for each card channel
	for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
		chanCount = m_pBrdInfoObj->GetNoOfChannels(slotNo);
		DEVICE_INFO.SetSlotInfo(slotNo, m_pBrdInfoObj->WhatBoardType(slotNo), chanCount);
		for (chanNo = 0; chanNo < chanCount; chanNo++)
			DEVICE_INFO.SetChannelCaps(slotNo, chanNo, m_pBrdInfoObj->WhatAvailableChannelType(slotNo, chanNo));
	}
	return TRUE;
}
//******************************************************
// HasShutdownBeenOrdered()
///
/// Queries whether the I/O scheduler shutdown command has been processed.
///
/// @return TRUE if shutdown is ordered; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::HasShutdownBeenOrdered(void) {
	return m_pBrdStatsObj->HasShutdownBeenOrdered();
}
//******************************************************
// SystemInIdleMode()
///
/// Queries whether the I/O scheduler IDLE command has been processed.
///
/// @return TRUE if system is in idle mode; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::HasIdleModeBeenOrdered(void) const {
	return m_pBrdStatsObj->HasIdleModeBeenOrdered();
}
#include "StoragePaths.h"
#include "FileList.h"
#include <stdlib.h>
//******************************************************
// LoadRunTimeRanges()
///
/// Load the run-time ranges.
///
/// @return TRUE if system successfully loads range; otherwise FALSE
/// 
//******************************************************
BOOL CIOScheduler::LoadRunTimeRanges(void) {
	BOOL fileFound = FALSE;
	CFileList *pFileLst = NULL;
	WIN32_FIND_DATA *pFileFound = NULL;
	STORAGE_FILE RTRange;
	WCHAR fileName[_MAX_PATH];
	wcscpy_s(fileName, sizeof(fileName) / sizeof(WCHAR), L"*.RNG");	///< Run-time ranges File name
	RTRange.DeviceID = IDS_INTERNAL_SD;				///< Storage device ID
	RTRange.Location = IDS_CONFIG_DATA;				///< Storage location
	RTRange.FileName = fileName;				///< Run-time ranges File name
	pFileLst = new CFileList(&RTRange);
	do {
		pFileFound = pFileLst->Next();
		if (pFileFound != NULL) {
			// Save record of filename
			fileFound = TRUE;
		}
	} while (pFileFound != NULL);
	delete pFileLst;
	return fileFound;
}
//******************************************************
// Wait()
///
/// Wait for either a message or a board to require servicing - whichever comes first
/// @note: Allows others processes time to be executed
///
/// 
//******************************************************
void CIOScheduler::Wait(void) {
	LONGLONG maxTime;
	USHORT BoardID;
	/// Calculate maximum time before next board process from board list
	m_pCardHldr->GetCardScheduleTime(&maxTime, &BoardID);
	EventMessageHandler(static_cast<DWORD>(maxTime));
}
//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler( const CMsgQueueMessage *pMsg )
///
///
///
/// @param[in] 	const CMsgQueueMessage *pMsg - Pointer to the received message 
///
/// @return V6ACTMOD_OK					- Associated Action with Received Message Undertaken Sucessfully
///		@n V6ACTMOD_MESSAGE_NOT_HANDLED - Message Received is not being handled
///		
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CIOScheduler::ModuleMessageHandler(const CMsgQueueMessage *pMsg) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_OK;
	switch (pMsg->m_MessageType) {
	case MOD_CALIBRATION_FINISHED:
		CalibrationFinished();
		break;
	default:
		// not a specific method therefore pass on to the standard handler
	retValue = CV6ActiveModule::ModuleMessageHandlele

//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AICard.h
/// @n interface for the AI card class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 49	Stability Project 1.46.1.1	7/2/2011 4:56:47 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 48	Stability Project 1.46.1.0	7/1/2011 4:27:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 47	V6 Firmware 1.46		11/8/2006 3:01:23 PM	Graham Waterfield
//		Digital I/O setup commit improvements, first stage of hardware
//		counters and fix to milli-amp user defined range.
// 46	V6 Firmware 1.45		11/2/2006 6:27:33 PM	Graham Waterfield
//		Fix various digital problems
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _DIGPULSECARD_H
#define _DIGPULSECARD_H
#if !defined(AFX_DIGPULSECARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_DIGPULSECARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#include "DigConfig.h"
#include "IOCard.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define MAX_PULSE_BOARD_CHANNELS	4
#define MAX_DIG_BOARD_CHANNELS		16
class CDigPulseCard: public CIOCard {
	// Allow the protocol to query boards
	friend class CProtocol;
public:
	virtual BOOL RunProcess(void);
	BOOL ScheduleBoardProcess(void);
	BOOL SchedulePulseDownload(void);
	BOOL ScheduleNextChannelProcess(void);
	BOOL Initialise(void);
	virtual BOOL InitialiseCard(const USHORT cardNo);
	BOOL SetupConfigChangePreparation(void);
	virtual IOCARDSTAT IOCardCommand(const USHORT newCmd);
	virtual USHORT CalculateChannelReadRate(const UCHAR chanNo);
	virtual BOOL SetSpecialTestMode(const BOOL state);
	virtual USHORT GetChannelAcqRate(const UCHAR chanNo) const;
	virtual BOOL DoesBoardRqSched(void);
	virtual USHORT ChannelsToService(void);
	virtual BOOL CardBoardHandlerFactory(void);
	virtual BOOL InitialiseCardConfig(void);
	virtual BOOL CMMCreateLocalConfig(void);
	virtual void GetIOCardStrID(QString *pIDText) const;
	virtual void GetIOCardStrDescription(QString *IDText);
	virtual BOOL GetIOLifeHistory(class CProtocol *const pProtocol);
	BOOL SaveIOLifeHistory(class CProtocol *const pProtocol);
	BOOL UpdateLastDIReadService(LONGLONG thisSystemTick);
	BOOL UpdateLastDICoverageService(LONGLONG thisSystemTick, LONGLONG lastSystemTick,
			LONGLONG digitalLastSyncedSystemTick);
	void QueryReportSelectionMask( USHORT &chartReportMask,
	USHORT &msgReportMask) const;
	USHORT GetBoardCfgDigitalInputSelectionMask(void) const;
	BOOL HighestPIChannelEnabled( USHORT &ChanNo) const;
	BOOL HighestDIChannelEnabled( USHORT &ChanNo) const;
	BOOL ProcessOutputChannels( USHORT *pCardData);
	BOOL ResetDigPulseCardDataItems();
	void ResetDigitalDITValues(void);
	void ResetPulseDITValues(void);
	void LogDigitalState( USHORT sysDigitalNo, BOOL Activate);
	class CIOCardHandler* GetProcessHandle(void);
	BOOL GetChannelConfigRef(UCHAR ChanNo, T_DIGCFGCHANNEL **pChanCfgInfo);
//		USHORT GetPulseDigitalBlockTransChans( void );
//		BOOL ResyncPPQueue( class CProtocol *pProtocol );
	BOOL SetLastReadingCoverage(const LONGLONG systemTick);
//		USHORT AckChannelRecieved( USHORT chanNo );
	CDigPulseCard(USHORT CardSlotID);
	virtual ~CDigPulseCard();
protected:
	BOOL ResyncService(const USHORT IOCardTick, const LONGLONG systemTick);
	BOOL ProcessMissingPulseBlockTransfer(LONGLONG procTime);
	BOOL PerformSMModeChange(class CProtocol *const pProtocol);
	BOOL OperateTransactionSM(class CProtocol *const pProtocol);
	void PrioritizeSchedule(void);
private:
	class CIOConfigManager *m_pConfigMngrObj;	///< Configuration manager
	class CDigConfig *m_pDigConfigObj;	///< Digital configuration for I/O card
	class CIOHandler *m_pDIHandler;	///< Board handler class for all DI channels
//		USHORT m_chanAckMask;						///< Channel acknowledge mask
	BOOL m_OutputUpdateRqd;	///< Tracks whether output on this board is required
	USHORT m_lastValueWritten;	///< Tracks last value written as output (if any output is selected)
	BOOL m_ExtraInput;				///< Is extra undocumented input supported
	BOOL m_SetupHasBeenChanged;			///< TRUE if setup has just been changed
};
#endif // !defined(AFX_DIGPULSECARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#endif // _DIGPULSECARD_H

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n BrdStats.h
/// @n interface for the CBrdStats class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 35	Stability Project 1.32.1.1	7/2/2011 4:55:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 34	Stability Project 1.32.1.0	7/1/2011 4:27:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 33	V6 Firmware 1.32		4/24/2007 7:22:51 PM	Graham Waterfield
//		Added AO load status indication
// 32	V6 Firmware 1.31		10/10/2006 3:32:49 PM Graham Waterfield
//		Allow eZtrend to user calibrate channels and prevent startup RT &
//		ohms spikes using the third major method tried.
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_BRDSTATS_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)
#define AFX_BRDSTATS_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QMutex>
#include "Defines.h"
#include "BoardManager.h"
#include "V6IOConstraints.H"
#include "V6IOStats.H"
#include "Timer.h"
#include "IOCardStats.h"
#include "PassiveModule.h"
typedef enum {
	ERMT_NORMAL,					///< Enter normal run mode
	ERMT_PRE_MODE_ACQUIRE,					///< Acquire RT cal, RT comp and CJC before entering normal run mode
	ERMT_ATE_CONFIG	///< Do not enter run mode until configuration has been downloaded (ATE special)
} E_RUN_MODE_TYPE;
class CBrdStats: public CPassiveModule {
public: //Singleton
	// Mode selection
	void ShutdownOrdered(void);
	void ResetFirstPowerUp(void);
	void SetIdleMode(void);
	void CancelIdleMode(void);
	void CancelLimitedRunMode(void);
	void SetLimitedRunMode(void);
	void SetRunModeType(const E_RUN_MODE_TYPE mode);
	// Mode query
	BOOL HasShutdownBeenOrdered(void) const;
	BOOL QueryFirstPowerUp(void) const;
	BOOL HasIdleModeBeenOrdered(void) const;
	BOOL HasLimitedRunModeBeenOrdered(void) const;
	E_RUN_MODE_TYPE QueryRunModeType(void) const;
	BOOL CheckFailCount(const USHORT slotNo, const E_ERROR_TYPE errorType, const USHORT errorCode,
			UCHAR *pFailCount) const;
	void LogFailure(const USHORT slotNo, const E_ERROR_TYPE errorType, const USHORT errorCode);
	void LogMultipleFailures(const USHORT slotNo, const E_ERROR_TYPE errorType, const USHORT errorCode,
	USHORT failCount);
	E_ERROR_REPORT_STAT CheckReportStatus(const USHORT slotNo, const E_ERROR_TYPE errorType,
			const USHORT errorCode) const;
	void SetBoardPresent(const USHORT cardNo, const BOOL present);
	void SetBoardOpState(const USHORT cardNo, const BOOL operational);
	//Add to handle Secondary Reset Condition
	BOOL IsConfigChangeRequired(void);
	void SetConfigChange(BOOL);
	void SetChanTCWiringState(const USHORT cardNo, const USHORT chanNo, const BRNOUT_WIRING_STATUS ok);
	BRNOUT_WIRING_STATUS GetChanTCWiringState(const USHORT cardNo, const USHORT chanNo);
	// Thermocouple burnout status (note wiring state is only available when active burnout is selected)
	void SetChanTCBurnoutState(const USHORT cardNo, const USHORT chanNo,
			const CInputConditioning::IO_BURNOUT_STATUS State);
	CInputConditioning::IO_BURNOUT_STATUS GetChanTCBurnoutState(const USHORT cardNo, const USHORT chanNo);
	void SetChannelRTCompRqdState(const USHORT cardNo, const USHORT chanNo, const BOOL state);
	void SetChannelRTCalRqdState(const USHORT cardNo, const USHORT chanNo, const BOOL state);
	// I/O card general status
	void SetGenBoardSPIHistoryStats(const USHORT cardNo, const ULONG SPIMessagesRx, const ULONG SPIMessagesTx,
			const ULONG SPIErrors);
	void SetGenBoardHistoryStats(const USHORT cardNo, const ULONG ConfigChanges, const ULONG OperatingTime,
			const ULONG PowerCycles);
	void GetGenBoardSPIHistoryStats(const USHORT cardNo, ULONG &SPIMessagesRx, ULONG &SPIMessagesTx, ULONG &SPIErrors);
	void GetGenBoardHistoryStats(const USHORT cardNo, ULONG &ConfigChanges, ULONG &OperatingTime, ULONG &PowerCycles);
	// AI calibration date
	void SetUserCalDate(const USHORT cardNo, const USHORT chanNo, const ULONG Date);
	void SetFactoryCalDate(const USHORT cardNo, const ULONG Date, const UCHAR rigID);
	void GetUserCalDate(const USHORT cardNo, const USHORT chanNo, ULONG &Date);
	void GetFactoryCalDate(const USHORT cardNo, ULONG &Date, UCHAR &rigID);
	void SetCardBeingCalibrated(const USHORT slotNo);
	BOOL HasLimitedRunModeBeenOrderedOnCard(const USHORT slotNo) const;
	void ResetCardStats(const USHORT cardNo);
	BOOL IsBoardPresent(const USHORT cardNo) const;
	BOOL IsBoardOperational(const USHORT cardNo) const;
	BOOL IsChannelRTCompRqd(const USHORT cardNo, const USHORT chanNo) const;
	BOOL IsChannelRTCalRqd(const USHORT cardNo, USHORT chanNo) const;
	BOOL SetPPQStatus(const USHORT cardNo, const USHORT chanNo, const UCHAR Status);
	BOOL GetPPQStatus(const USHORT cardNo, const USHORT chanNo, UCHAR *pStatus);
	BOOL SetIOTimesync(const USHORT cardNo, const USHORT chanNo, const USHORT IOTicks, const LONGLONG sysTicks);
	BOOL GetIOTimesync(const USHORT cardNo, const USHORT chanNo,
	USHORT *pIOTicks, LONGLONG *pSysTicks);
	BOOL SetIOMissedTimestamps(const USHORT cardNo, const USHORT chanNo, const ULONG MissedReadings);
	BOOL SetIORepeatedTimestamps(const USHORT cardNo, const USHORT chanNo, const ULONG RepeatedReadings);
	BOOL SetIOLossingTimestamps(const USHORT cardNo, const USHORT chanNo, const ULONG Loss);
	BOOL SetIOGainingTimestamp(const USHORT cardNo, const USHORT chanNo, const ULONG Gain);
	BOOL GetIOTimestampStats(const USHORT cardNo, const USHORT chanNo, ULONG *pNoOfGain, ULONG *pNoOfLoss,
			ULONG *pMissedReadings, ULONG *pRepeatedReadings);
	BOOL SetIOLastBatchStatus(const USHORT cardNo, const USHORT chanNo, const USHORT firstTS, const USHORT lastTS,
			const USHORT noOfReadings);
	BOOL GetIOLastBatchStatus(const USHORT cardNo, const USHORT chanNo,
	USHORT *pFirstTS, USHORT *pLastTS, USHORT *pNoOfReadings);
	BOOL SetUnprocessedCoverage(const USHORT cardNo, const USHORT chanNo, const ULONG coverage);
	BOOL GetUnprocessedCoverage(const USHORT cardNo, const USHORT chanNo, ULONG *pCoverage);
	void SetAnaOutValue(const USHORT slotNo, const USHORT chanNo, const float mA);
	float GetAnaOutValue(const USHORT slotNo, const USHORT chanNo);
	BOOL SetAOChanOPState(const USHORT slotNo, const USHORT chanNo, const BOOL chanOC);
	BOOL GetAOChanOPState(const USHORT slotNo, const USHORT chanNo) const;
	void SaveHistoryFaultRecord(const USHORT cardNo, const USHORT faultNo, const BYTE FaultOnChannel,
			const USHORT FaultTimeStamp, const ULONG FaultOperatingTime);
	void SaveChanHistoryFaultRecord(const USHORT cardNo, const USHORT chanNo, const ULONG failureCount);
	ULONG GetSavedDIORelayOpsRecord(const USHORT cardNo, const USHORT chanNo);
	ULONG GetDIOPulseQueueOverRuns(const USHORT cardNo);
	ULONG GetDIOPulseOutInterrupts(const USHORT cardNo);
	UCHAR GetDIOPulseOverRunChans(const USHORT cardNo);
	USHORT GetDIOPulseOutIntChans(const USHORT cardNo);
	ULONG GetDIOInputQueueOverRuns(const USHORT cardNo);
	void SaveDIORelayOpsRecord(const USHORT cardNo, const USHORT chanNo, const ULONG numOfOps);
	void SaveDIOQueueHistoryRecord(const USHORT cardNo, const ULONG InputQueueOverRuns, const ULONG PulseOutInterrupts,
			const ULONG PulseQueueOverRuns, const UCHAR PulseOverRunChans, const USHORT PulseOutIntChans);
	ULONG GetSavedARRelayOpsRecord(const USHORT cardNo, const USHORT chanNo);
	void SaveARRelayOpsRecord(const USHORT cardNo, const USHORT chanNo, const ULONG numOfOps);
	void SaveARPulseOutInterrupts(const USHORT cardNo, const USHORT chanNo, const ULONG PulseOutInterrupts);
	void SaveARQueueOverRuns(const USHORT cardNo, const ULONG InputQueueOverRuns);
	ULONG GetARQueueOverRuns(const USHORT cardNo);
	ULONG GetARRelayOpsRecord(const USHORT cardNo, const USHORT chanNo);
	ULONG GetARPulseOutInterrupts(const USHORT cardNo, const USHORT chanNo);
	void SavePulseQueueOverRuns(const USHORT cardNo, const USHORT chanNo, const ULONG PulseQueueOverRuns);
	void SavePulseLastFaultTime(const USHORT cardNo, const USHORT chanNo, const ULONG LastFaultTime);
	ULONG GetPulseQueueOverRuns(const USHORT cardNo, const USHORT chanNo);
	ULONG GetPulseLastFaultTime(const USHORT cardNo, const USHORT chanNo);
	ULONG GetChanHistoryFaultRecord(const USHORT cardNo, const USHORT chanNo);
	void SaveAISpecificHistory(const USHORT cardNo, const float minCJTemp, const float maxCJTemp);
	BOOL SaveAIQueueOverrunHistory(const USHORT cardNo, const USHORT chanNo, const ULONG QueueOverruns);
	float GetAIMinCJTempHistory(const USHORT cardNo);
	float GetAIMaxCJTempHistory(const USHORT cardNo);
	ULONG GetAIQueueOverrunHistory(const USHORT cardNo, const USHORT chanNo);
	void MoveCardCapabilitiesToNewSlot(const USHORT OrigCardSlot, const USHORT newCardSlot);
	CTimer m_schedTimer;	// I/O card scheduler
	void ResetChanStatMonitor(const USHORT slotNo, int chanNo);
	static CBrdStats* GetHandle();
	void CleanUp();
private: // Singleton
	CBrdStats();
	CBrdStats(const CBrdStats&);
	CBrdStats& operator=(const CBrdStats&) {
		return *this;
	}
	;
	~CBrdStats();
	static CBrdStats *m_pInstance;
	static QMutex m_CreationMutex;
	USHORT m_SchdlrOverrunCnt;					///< Late scheduled board count
	struct BrdStatus m_BrdStat[MAX_SCHED_SERVICES];
	BOOL m_ShutdownOrdered;			///< Shutdown command has been instructed
	BOOL m_SetIdleMode;	///< Prepare for shutdown command has been instructed
	BOOL m_SetLimitedRunMode;	///< Operate in limited running mode (for calibration)
	BOOL m_FirstRunAfterPowerUp;			///< First execution after power up?
	BOOL m_isSecondaryReset;
	E_RUN_MODE_TYPE m_RunModeType;						///< Run mode ordered
	USHORT m_BoardBeingCalibrated;			///< The board is being calibrated
	T_IOTIMESYNC m_lastTimeSync[MAX_SCHED_SERVICES]; ///< Last time sync on board
};
#endif // !defined(AFX_BRDSTATS_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PPAIChannel.cpp
/// @n implementation for the CPPAIChannel class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  153  Stability Project 1.148.1.3  7/2/2011 4:59:44 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  152  Stability Project 1.148.1.2  7/1/2011 4:38:38 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  151  Stability Project 1.148.1.1  3/17/2011 3:20:34 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  150  Stability Project 1.148.1.0  2/15/2011 3:03:40 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "PPL.h"
#include "PPQManager.h"
#include "ATECal.h"
#include "DataItemManager.h"
#include "DataItemIO.h"
#include "V6IOErrorCodes.H"
#include "CardSlot.h"
#include "IOCard.h"
#include "AICard.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "IOChanHandler.h"
#include "AIRanges.h"
#include "PPIOServiceManager.h"
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#include "PPIOService.h"
#include "PPAIChannel.h"
#include "TraceDefines.h"
#include "BaseProtocol.h"
#include "PPQCommon.h"
#include "SysInfo.h"
#include "V6globals.h"
#include "EventManager.h"
#include "ErrorControl.h"
#include "V6IO_AI_InputRanges.H"
#include <math.h>
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
// #define READINGS_DOWNLOADED_REPORT	1
#define MAX_AI_RETURN_READINGS 256
#define AI_STARTUP_MAX_ERROR_READINGS	4
//#define AI_STARTUP_MAX_ERROR_READINGS	0
#define AI_READING_ROLLOVER_PREVENTION	50
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPPAIChannel::CPPAIChannel(BOOL chanInput) : CPPIOService(chanInput)
#if defined (DBG_FILE_LOG_PPAI_DBG_ENABLE) || defined (DBG_FILE_LOG_PPAI_TC_DBG_ENABLE)
, m_debugFileLogger(L"\\SDMemory\\PPAIChannelDbgLog.txt", FALSE, 15*1024*1024 )//DebugFile with huge size and with recycle
#endif
{
//	 qDebug("Create new CPPAIChannel\n");
	m_pAIRangeObj = CAIRanges::GetHandle();
	m_pServiceManagerObj = CPPIOServiceManager::GetHandle();
	m_pICService = m_pServiceManagerObj->GetICService();
}
CPPAIChannel::~CPPAIChannel() {
//	 qDebug("Delete CPPAIChannel class\n");
}
void CPPAIChannel::OpenChannelLog(void) {
#if 0
	 HANDLE hFile	 hFileMap;
	 PBYTE pFileMem;
//	 QFile FHandle = NULL;
//	 WCHAR Filename[50];
	 TCHAR Filename[MAX_PATH];
	 swprintf( Filename, L"\\Compact Flash2\\Channel%d.csv", this->m_glbchannelNo );
//	 FHandle.Open(Filename	  | QFile::WriteOnly | QFile::Append );
	 hFile = CreateFileForMapping(Filename, GENERIC_WRITE, FILE_SHARE_READ, NULL,
	 	 	 	 	 	 	 	 OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, 0);
	 if( hFile != INVALID_HANDLE_VALUE )
	 {
	 	 hFileMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, 0);
	 	 if(hFileMap)
	 	 {
	 	 	 pFileMem = (PBYTE) MapViewOfFile(hFileMap, FILE_MAP_WRITE, 0, 0, 0);
	 	 	 if(pFileMem)
	 	 	 {
	 	 	 	 // Use it
	 	 	 }
	 	 }
	 }
	 // Clean up
	 if(pFileMem)
	 	 UnmapViewOfFile(pFileMem);
	 if(hFileMap)
	 	 //No need to close the mutex in Qt
	 if( hFile != INVALID_HANDLE_VALUE )
	 	 //No need to close the mutex in Qt
#endif
}
void CPPAIChannel::CloseChannelLog(void) {
//	 FHandle.Close();
}
void CPPAIChannel::WriteChannelReading( T_RANGE_COUNTS Reading) {
	/*
	 QFile FHandle = NULL;
	 WCHAR Filename[50];
	 char Text[8];
	 swprintf( Filename, L"\\Compact Flash2\\Channel%d.csv", this->m_glbchannelNo );
	 FHandle.Open(Filename,  | QFile::WriteOnly | QFile::Append );
	 FHandle.SeekToEnd();
	 sprintf(Text	 "\r\n%d"	 Reading);
	 FHandle.Write( &Text	 strlen(Text) );
	 FHandle.Close();
	 */
}
void CPPAIChannel::WriteTimestamp(USHORT TimeStamp) {
	/*
	 QFile FHandle = NULL;
	 WCHAR Filename[50];
	 char Text[8];
	 swprintf( Filename	 L"\\Compact Flash2\\Channel%d.csv"	 this->m_glbchannelNo );
	 FHandle.Open(Filename	  | QFile::WriteOnly | QFile::Append );
	 FHandle.SeekToEnd();
	 sprintf(Text, ",%d", TimeStamp);
	 FHandle.Write( &Text, strlen(Text) );
	 FHandle.Close();
	 */
}
void CPPAIChannel::NoOfReadings(USHORT NoOfReadings) {
	/*
	 QFile FHandle = NULL;
	 WCHAR Filename[50];
	 char Text[8];
	 swprintf( Filename, L"\\Compact Flash2\\Channel%d.csv", this->m_glbchannelNo );
	 FHandle.Open(Filename,  | QFile::WriteOnly | QFile::Append );
	 FHandle.SeekToEnd();
	 sprintf(Text, ",%d", NoOfReadings);
	 FHandle.Write( &Text, strlen(Text) );
	 FHandle.Close();
	 */
}
/////////////////////////////////////////////////////
/// Create the default definition of an AI channel
/// @param[in] pboardInfo - The board process info.
/// @param[in] pchanInfo - The channel process info.
/// @param[in] pCard - The I/O board class.
/// @param[in] chanNo - The board channel number.
///
/// @return TRUE if channel configured; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPAIChannel::CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
		class CCardSlot *const pCard, const USHORT chanNo) {
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	BOOL retValue = FALSE;
	pSlotMapObj = CSlotMap::GetHandle();
	if (NULL != pSlotMapObj) {
		pboardInfo->input = TRUE;
		pboardInfo->pCard = pCard;
		pboardInfo->CardSlotNo = static_cast<UCHAR>(pCard->BoardSlotInstance());
		pchanInfo->PPService = PP_SERVICE_AI_CHAN;
		pchanInfo->channelNo = static_cast<UCHAR>(chanNo);
		pchanInfo->glbchannelNo = pSlotMapObj->GetSysChannelFromAnaInChannel(pboardInfo->CardSlotNo, chanNo, ONE_BASED);
		pchanInfo->m_DampLoaded = FALSE;
		pchanInfo->m_prevReading = 0;
		retValue = TRUE;
	}
	return retValue;
}
/////////////////////////////////////////////////////
/// Convert a single channel reading to the mV value
/// @param[in] reading - The reading to process.
///
/// @return The mV conversion of reading
/////////////////////////////////////////////////////
float CPPAIChannel::mVConvertAIChannelReading(T_RANGE_COUNTS reading) {
	float engValue = 0.0F;
	return engValue;
}
/////////////////////////////////////////////////////
/// Convert a single channel reading to the uA value
/// @param[in] reading - The reading to process.
///
/// @return The uA conversion of reading
/////////////////////////////////////////////////////
float CPPAIChannel::uAConvertAIChannelReading(T_RANGE_COUNTS reading) {
	return 0;
}
/////////////////////////////////////////////////////
/// Convert a single channel reading to the engineering value
/// @param[in] reading - The reading to process.
/// @param[in] pChanInfo - The channel process info.
///
/// @return The engineering conversion of reading
/////////////////////////////////////////////////////
float CPPAIChannel::EngConvertAIChannelReading( T_RANGE_COUNTS reading, class CFFConversionInfo *pEngScale) {
	return pEngScale->CalcSourceToDest(static_cast<float>(reading));
}
//******************************************************
// ResetRawVoltageReadings()
///
/// Reset raw reading holders to show no valid data
/// @param[in] pChanInfo - The channel process info.
/// 
//******************************************************
void CPPAIChannel::ResetRawVoltageReadings(T_PCHANPROCESSINFO pChanInfo) {
	class CDataItem *pDataItem = NULL;
	// Reset the raw values
	pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE_RAW, pChanInfo->glbchannelNo - 1);
	if (NULL != pDataItem) {
		pDataItem->SetStatus(DISTAT_INVALID);
	}
	// Reset the analogue values
	pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE, pChanInfo->glbchannelNo - 1);
	if (NULL != pDataItem) {
		pDataItem->SetStatus(DISTAT_INVALID);
		pDataItem->SetValue(-FLT_MAX);
	}
}
#define EZ_INPUT_REF_VOLTAGE			1220
#define EZ_INPUT_PULL_DOWN_RESISTOR		1000000
/////////////////////////////////////////////////////
/// Adjust the eZ RT and ohms reading to compensate for hardware inaccuracies
/// @param[in] pChanInfo - Channel specific data processing parameters.
/// @param[in] ResistorV - The V drop measured across the resistor.
///
/// @return TRUE if sync succedded; otherwise FALSE.
/////////////////////////////////////////////////////
float CPPAIChannel::AdjustEzResistanceReading(T_CHANPROCESSINFO *const pChanInfo, const float ResistorV,
		const float excitationA) {
	UCHAR boardType;
	float currentRes = 0.0;
	float retValue = ResistorV;
	boardType = pChanInfo->pCommon->pCard->WhatBoardType();
	if ( BOARD_EZ_AI == boardType) {
		currentRes = ResistorV / excitationA;
		retValue = ResistorV + (((ResistorV + EZ_INPUT_REF_VOLTAGE) / EZ_INPUT_PULL_DOWN_RESISTOR) * currentRes);
	}
	return retValue;
}
/////////////////////////////////////////////////////
/// Add either an error reading to the PPQ
/// @param[in] pChanInfo - The channel process info.
/// @param[in] reading - The reading to add.
/// @param[in] firstReading - TRUE if this is the first (or only) reading of this block downloaded.
///
/////////////////////////////////////////////////////
void CPPAIChannel::AddErrorReadingToQueue(T_PCHANPROCESSINFO pChanInfo, const float reading, const BOOL firstReading) {
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;						///< Pre-process queue manager
	pPPQManager = CPPQManager::GetHandle();
	if ( TRUE == pChanInfo->m_firstValueLoaded) {
		// Once we given the channel chance to start-up correctly, tell the pre-process queue
		// that a reading has been missed due to a auxiliary channel scheduled read
		pPPQManager->m_APPPQServices.AddMissedReading(pChanInfo->hPPQ);
	} else {
		// Before first value is loaded PPQ's cannot do anything sensible with a missing value, so load
		// actual error so that the processing module can decide whether or not to process duff values
		if (firstReading == TRUE) {
			/// Store first timestamped conditioned reading in pre-process buffer
			pPPQManager->m_APPPQServices.AddTimeStampedReading(pChanInfo->hPPQ, reading, pChanInfo->lastTimestamp);
		} else {
			/// Store subsequent conditioned readings in pre-process buffer
			pPPQManager->m_APPPQServices.AddReading(pChanInfo->hPPQ, reading);
		}
	}
#endif
}
/////////////////////////////////////////////////////
/// Add either an error reading to the PPQ
/// @param[in] pChanInfo - The channel process info.
/// @param[in] reading - The reading to add.
/// @param[in] firstReading - TRUE if this is the first (or only) reading of this block downloaded.
///
/////////////////////////////////////////////////////
void CPPAIChannel::AddReadingToQueue(T_PCHANPROCESSINFO pChanInfo, const float reading, const BOOL firstReading) {
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;						///< Pre-process queue manager
	pPPQManager = CPPQManager::GetHandle();
	/// After AI_STARTUP_MAX_ERROR_READINGS has been reached, all paths must provide a reading
	/// to add to the queue otherwise we have no data to process downstream
	/// and the system will appear to freeze.
	if (firstReading == TRUE) {
		/// Store first timestamped conditioned reading in pre-process buffer
		pPPQManager->m_APPPQServices.AddTimeStampedReading(pChanInfo->hPPQ, reading, pChanInfo->lastTimestamp);
	} else {
		/// Store subsequent conditioned readings in pre-process buffer
		pPPQManager->m_APPPQServices.AddReading(pChanInfo->hPPQ, reading);
	}
#endif
}
/////////////////////////////////////////////////////
/// Decode channel active burnout status
/// @param[in] pChanInfo - The channel process info.
/// @param[in] reading - The reading to add.
///
/// @return TRUE if channel is burntout i.e. reading not available; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPAIChannel::ApplyActiveBurnoutStatus(T_PCHANPROCESSINFO pChanInfo, float *const conditionedReading,
		const BOOL upscaleBurnOutSelected) {
	CInputConditioning::IO_BURNOUT_STATUS brnStat = CInputConditioning::BURNOUT_OK;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	class CDataItem *pDataItem = NULL;
	T_DATAITEM_STATUS status = DISTAT_INVALID;
	QString strasprintf("");
	BOOL problem = FALSE;
	pBrdStatsObj = CBrdStats::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (NULL != pServiceManagerObj)
		pICService = pServiceManagerObj->GetICService();
	brnStat = pBrdStatsObj->GetChanTCBurnoutState(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo);
	if (CInputConditioning::BURNOUT_TC_OC_DETECTED == brnStat) {
		// Create floating point error code for burnout
		pICService->ApplyTCPPQBurnout(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo, upscaleBurnOutSelected,
				conditionedReading);
		// Register problem with reading
		problem = TRUE;
		// Set the status to the 'appropriate' error type
		status = pICService->ConvertFloatErrorToDITStatus(*conditionedReading);
		pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE_RAW, pChanInfo->glbchannelNo - 1);
		if (NULL != pDataItem)
			pDataItem->SetStatus(status);
		if (CInputConditioning::BURNOUT_TC_OC_DETECTED != pChanInfo->m_burnOutReportPrfrmd) {
			ReportBurnOutDiagnostics(status, pChanInfo);
		}
		pChanInfo->m_burnOutReportPrfrmd = brnStat;
	} else if (CInputConditioning::BURNOUT_TC_DEGRADED == brnStat) {
		// No report as degraded can oscilate with a good status. We show the true status on the AI diagnostics
//		strasprintf = QString::asprintf( IDS_ACTIVE_BURNOUT_DEGRADED_LOG, pChanInfo->glbchannelNo );
//		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strasprintf.toLocal8Bit().data());
//		pChanInfo->m_burnOutReportPrfrmd = brnStat;
	} else if (CInputConditioning::BURNOUT_TC_FAILING == brnStat) {
		if (static_cast<USHORT>(pChanInfo->m_burnOutReportPrfrmd) < static_cast<USHORT>(brnStat)) {
			strasprintf = QString::asprintf(IDS_ACTIVE_BURNOUT_FAILING_LOG, pChanInfo->glbchannelNo);
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strasprintf.toLocal8Bit().data());
			// Report the TC health status to the event system
			pEVENTS->TCHealthMonitorEventTrigger(pChanInfo->glbchannelNo - 1, (USHORT) brnStat);
		}
		pChanInfo->m_burnOutReportPrfrmd = brnStat;
	} else if (CInputConditioning::BURNOUT_TC_ALMOST_FAILED == brnStat) {
		if (static_cast<USHORT>(pChanInfo->m_burnOutReportPrfrmd) < static_cast<USHORT>(brnStat)) {
			strasprintf = QString::asprintf(IDS_ACTIVE_BURNOUT_ALMOST_FAILED_LOG, pChanInfo->glbchannelNo);
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strasprintf.toLocal8Bit().data());
			// Report the TC health status to the event system
			pEVENTS->TCHealthMonitorEventTrigger(pChanInfo->glbchannelNo - 1, (USHORT) brnStat);
		}
		pChanInfo->m_burnOutReportPrfrmd = brnStat;
	} else if (CInputConditioning::BURNOUT_TC_SC_DETECTED == brnStat) {
		// No report for a S/C T/C
		//if( static_cast<USHORT> (pChanInfo->m_burnOutReportPrfrmd) < static_cast<USHORT> (brnStat) )
		//{
		//	strasprintf = QString::asprintf( IDS_ACTIVE_BURNOUT_SC_LOG, pChanInfo->glbchannelNo );
		//	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strasprintf.toLocal8Bit().data());
		//}
		//pChanInfo->m_burnOutReportPrfrmd = brnStat;
	} else if (CInputConditioning::BURNOUT_OK == brnStat) {
		if ((static_cast<USHORT>(pChanInfo->m_burnOutReportPrfrmd) != static_cast<USHORT>(brnStat))
				&& (CInputConditioning::BURNOUT_TC_DEGRADED != pChanInfo->m_burnOutReportPrfrmd)
				&& (CInputConditioning::BURNOUT_OK != pChanInfo->m_burnOutReportPrfrmd)
				&& (CInputConditioning::BURNOUT_TC_SC_DETECTED != pChanInfo->m_burnOutReportPrfrmd)) {
			// Total recovery is only reported to the user if change is not degraded or short circuit detection
			strasprintf = QString::asprintf(IDS_ACTIVE_BURNOUT_OK_LOG, pChanInfo->glbchannelNo);
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strasprintf.toLocal8Bit().data());
			// Report the TC health status to the event system
			pEVENTS->TCHealthMonitorEventTrigger(pChanInfo->glbchannelNo - 1, (USHORT) brnStat);
		}
		if (pChanInfo->m_burnOutReportPrfrmd != CInputConditioning::BURNOUT_OK) {
			// Report recovery to rest of system
			ReportBurnOutRecovery(pChanInfo);
		}
		pChanInfo->m_burnOutReportPrfrmd = brnStat;
	}
	return problem;
}
/////////////////////////////////////////////////////
/// Store the engineering value
/// @param[in] pChanInfo - The channel process info.
/// @param[in] measuredV - The enginering reading to store.
///
/// @return TRUE if channel is burntout i.e. reading not available; otherwise FALSE
/////////////////////////////////////////////////////
void CPPAIChannel::StoreEngineeringValue(T_PCHANPROCESSINFO pChanInfo, const float measuredV) {
	class CATECal *pATECal = NULL;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CDataItem *pDataItem = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	pATECal = CATECal::GetHandle();
	// Can an engineering value be calculated for this channel 
	if (NULL != pChanInfo->m_pRangeScale) {
		// If so calculate
		// Load the valid main channel engineering value into test equipment test area
		if ((IsRunningAsATEEquipment() == TRUE)
				|| (pBrdStatsObj->HasLimitedRunModeBeenOrderedOnCard(pChanInfo->pCommon->CardSlotNo) == TRUE)) {
			if (NULL != pATECal) {
				pATECal->StoreAIChanVoltageReadings(pChanInfo->channelNo, measuredV);
			}
		}
		// Load the first valid main channel engineering unit value into raw data item
		if (NULL != pDIT) {
			pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE_RAW, pChanInfo->glbchannelNo - 1);
			if (NULL != pDataItem) {
				pDataItem->SetValue(measuredV);
				pDataItem->SetStatus(DISTAT_NORMAL);
			}
		}
	}
}
/////////////////////////////////////////////////////
/// Calculate the ohms mesaured from a channel
/// @param[in] pAICard - Reference to the AI card.
/// @param[in] pAIConfig - Refernece to the AI card configuration.
/// @param[in] pChan - The channel information container.
/// @param[in] pChanInfo - The channel process info.
/// @param[in] measuredV - The measured voltage from the channel.
/// @param[in] leadV - The measured voltage from the channel.
/// @param[out] ohmsMeasurement - The ohms measured.
///
/// @return TRUE if one or more of the readings could be processed; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPAIChannel::CalculateOhmsReading(CAICard *const pAICard, CAIConfig *const pAIConfig,
		const CIOChanHandler *const pChan, T_PCHANPROCESSINFO pChanInfo, const float measuredV, float *const leadV,
		float *const ohmsMeasurement) {
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	float excitationA = 0.0F;
	float adjMeasuredV = measuredV;
	const T_AIBOARDCONFIG *pAIBrdConfig = NULL;
	T_DATAITEM_STATUS status = DISTAT_INVALID;
	class CDataItem *pDataItem = NULL;
	BOOL problem = FALSE;
	USHORT chanType = 0;
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (NULL != pServiceManagerObj)
		pICService = pServiceManagerObj->GetICService();
	if ((NULL != pChan) && (NULL != pAIConfig)) {
		pAIConfig->QueryAISlotChannelSelection(pChanInfo->channelNo, &chanType);
		// Get the excitation current
		if (pChan->GetLatestRTCal(&excitationA) == FALSE) {
			// Excitation current has not been measured correctly on this occassion, therefore missing reading must be added to queue
			pICService->LimitAnalogueChannel(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo,
			FALSE, pICService->GetErrorCodeForSlotType(pChanInfo->pCommon->CardSlotNo, IO_SCHED_MISSING_RT_CAL),
					ohmsMeasurement, chanType);
			problem = TRUE;
			// Set the status to the 'appropriate' error type
			status = pICService->ConvertFloatErrorToDITStatus(*ohmsMeasurement);
			pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE_RAW, pChanInfo->glbchannelNo - 1);
			if (NULL != pDataItem)
				pDataItem->SetStatus(status);
		} else {
			// Resistance measurement, at present, is never taken using three wire measurement
			if (pChan->GetLatestRTComp(leadV) == FALSE) {
				// Lead resistance has not been measured correctly since startup, therefore assume non
				*leadV = 0.0F;
				pICService->LimitAnalogueChannel(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo,
				FALSE, pICService->GetErrorCodeForSlotType(pChanInfo->pCommon->CardSlotNo, IO_SCHED_MISSING_RT_COMP),
						ohmsMeasurement, chanType);
			} else {
				// Mark that channel has been started successfully
				pAICard->RemoveChannelFromStartupList( AQUIRE_HOLDER, static_cast<UCHAR>(pChanInfo->channelNo));
			}
			pAIBrdConfig = pAIConfig->GetAIconfig();
			if (NULL != pICService) {
				// Return may have been an error, but does not matter (can assume no lead resistance)
				if (pICService->TestFloatError(*leadV) == TRUE) {
					*leadV = 0.0F;
				}
				adjMeasuredV = pICService->RescaleValue(measuredV,
						pAIBrdConfig->CfgChan[pChanInfo->channelNo].BaseRange.EngUnits, MILLI);
				if (pChanInfo->pCommon->pCard->WhatBoardType() == BOARD_EZ_AI) {
					// Fudge the measured voltage if an eZ AI board
					adjMeasuredV = AdjustEzResistanceReading(pChanInfo, adjMeasuredV, excitationA);
				}
				*ohmsMeasurement = pICService->PerformResistanceConvert(pChanInfo->pCommon->CardSlotNo, adjMeasuredV,
						*leadV, excitationA, pChanInfo->pCommon->pCard->WhatBoardSubType(), chanType);
				// Does not make sense to have negative ohms; so limit
				if (*ohmsMeasurement < 0.0F)
					*ohmsMeasurement = 0.0F;
			}
		}
	}
	return problem;
}
/////////////////////////////////////////////////////
/// Process an AI board reading according to the channel setup
/// @param[in] reading - The reading to process.
/// @param[in] firstReading - TRUE if this is the first (or only) reading of this block downloaded.
/// @param[in] lastReading - TRUE if this is the last (or only) reading of this block downloaded.
/// @param[in] pChanInfo - The channel process info.
///
/// @return TRUE if one or more of the readings could be processed; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPAIChannel::AIProcessChannelReading(T_RANGE_COUNTS reading, BOOL firstReading, BOOL lastReading,
		T_PCHANPROCESSINFO pChanInfo) {
#if defined ( DBG_FILE_LOG_PPAI_DBG_ENABLE ) || defined ( DBG_FILE_LOG_PPAI_TC_DBG_ENABLE )
	QString   strLogMessage;
	strLogMessage = QString::asprintf("CPPAIChannel::AIProcessChannelReading - begin Reading %d ChNo %d GTC:%d\r\n", reading, pChanInfo->channelNo, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	BOOL success = FALSE;
	UCHAR boardType;
	T_PRECPROFILE ptProfile = pSYSTEM_INFO->GetProfileConfig();
	class CPPIOServiceManager *pServiceManagerObj = NULL;		///< Service manager
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	class CDataItem *pDataItem = NULL;
	static BOOL engValueLoaded = FALSE;
	class CAICard *pAICard = NULL;
	class CAIConfig *pAIConfig = NULL;
	class CATECal *pATECal = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	float measuredV = 0.0F;
	float measuredmA = 0.0F;
	float leadV = 0.0F;
	float excitationA = 0.0F;
	T_DATAITEM_STATUS status = DISTAT_INVALID;
	BOOL activeBurnOutSelected = FALSE;
	BOOL upscaleBurnOutSelected = FALSE;
	class CChanList *pBoardChanLst = NULL;	 // Board channels for processing
	class CIOChanHandler *pChan = NULL;	 // General Channel reference
	UCHAR CJCompMethod = AIN_CJC_EXT_ZERO_DEG_C;
	USHORT CJChanNo = 0;
	USHORT slotNo = 0;
	USHORT chanType = 0;
	USHORT TCType = 0;
	USHORT RTType = 0;
	USHORT cardChanNo = 0;
	float CJTemp = 0;
	float conditionedReading = 0.0F;
	const T_AIBOARDCONFIG *pAIBrdConfig = NULL;
	BOOL problem = FALSE;
	BOOL readingOK = TRUE;
	BOOL userHWUnitsTableUsed = FALSE;
	QString strasprintf("");
	UCHAR ucBoardRev = V6AI_ISSUE_1;
	UCHAR ucAICardSubType = 0;
	UCHAR RangeComp = 0;
	UCHAR RangeGain = 0;
	UCHAR RangePair = 0;
	union Float {
		float m_float;
		ULONG m_uint32;
		UCHAR m_bytes[sizeof(float)];
	} uFloat;
	pBrdInfo = CBrdInfo::GetHandle();		// get a handle to the brd object
	pBrdStatsObj = CBrdStats::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (NULL != pServiceManagerObj)
		pICService = pServiceManagerObj->GetICService();
	// Only process channels that are enabled or have been overridden with a limited run mode
	if( (TRUE == pChanInfo->chanInfo.AIChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled) ||
			(pBrdStatsObj->HasLimitedRunModeBeenOrdered() == TRUE) )
	{
		pAICard = static_cast<class CAICard*>(pChanInfo->pCommon->pCard);
		slotNo = pChanInfo->pCommon->CardSlotNo;
		cardChanNo = pChanInfo->channelNo;
		boardType = pChanInfo->pCommon->pCard->WhatBoardType();
		pAIConfig = pAICard->GetLocalConfigHandle();
		if (NULL != pAIConfig) {
			pAIConfig->QueryAISlotChannelSelection(cardChanNo, &chanType);
			pAIBrdConfig = pAIConfig->GetAIconfig();
		}
		if (NULL != pBrdInfo) {
			pBrdInfo->GetBoardHardwareRevision(slotNo, &ucBoardRev);
			ucAICardSubType = CAICard::WhatBoardSubType(ucBoardRev);
		}
		pBoardChanLst = pAICard->GetChanSchedule();
		if (NULL != pBoardChanLst)
			pChan = pBoardChanLst->GetChannelRef(cardChanNo);
		if (firstReading == TRUE)
			engValueLoaded = FALSE;		///< Time to load the engineering data item again
		if (pChanInfo->m_noOfReadings < AI_READING_ROLLOVER_PREVENTION)
			++pChanInfo->m_noOfReadings;
		if ((pICService->IsValueAScheduledMissing(reading) == TRUE)
				&& (TRUE != pChanInfo->chanInfo.AIChanInfo.pChanCfgInfo->ChanCfgInfo.RawReadings)) {
			// If in calibrate mode then the value will not be missing;
			// however if the system is way out of cal then legal reading may be asigned missing value code
#ifndef V6IOTEST
			if (pAICard->IsStartupListEmpty() == TRUE) {
				// If it is the first three readings of a channel then these will be wrong if
				// RT or ohms channel is selected, because the board needs to measure
				// RT cal, RT comp and the main channel before a good reading can be returned.
				// Note the exact incorrect measurements depend upon the I/O card schedule - some card variants
				// can have upto 5 incorrect readings before correct ones are returned.
				// This error condition should really be handled better by the processing loop.
				if (pBrdStatsObj->HasLimitedRunModeBeenOrdered() == FALSE) {
					pICService->LimitAnalogueChannel(slotNo, cardChanNo, FALSE, reading, &conditionedReading, chanType);
					AddErrorReadingToQueue(pChanInfo, conditionedReading, firstReading);
				}
			}
#endif
		} else {
			success = TRUE;
			pATECal = CATECal::GetHandle();
			if ((NULL != pATECal) && (pATECal->QueryATECardNo() == slotNo)) {
				pATECal->StoreAIChanRawReadings(cardChanNo, reading);
			}
			pChanInfo->m_firstValueLoaded = TRUE;
		if( (NULL != pICService) )
		{
			// Convert the reading to it's NAN error code or float representation
			readingOK = pICService->LimitAnalogueChannel( slotNo, cardChanNo, pAIConfig->QueryCardRawScaleSetting(), reading, &conditionedReading, chanType );
#if defined ( DBG_FILE_LOG_PPAI_DBG_ENABLE )
			strLogMessage = QString::asprintf("CPPAIChannel::AIPCR- LimitAnalogueChannel Reading %d conditionedReading %f readingOK %d GTC:%d\r\n", reading, conditionedReading, readingOK, GetTickCount() );
			m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
			if( TRUE == readingOK )
			{
#if defined ( DBG_FILE_LOG_PPAI_DBG_ENABLE )
				strLogMessage = QString::asprintf("CPPAIChannel::AIPCR- SourceValue %d RangeScale:: %s GTC:%d\r\n", reading, pChanInfo->m_pRangeScale->GetConversionString(), GetTickCount() );
				m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
				// Current reading is not a NAN - Convert the reading to the mV representation
#if defined ( DBG_FILE_LOG_PPAI_DBG_ENABLE )
				strLogMessage = QString::asprintf("CPPAIChannel::AIPCR- GetWorkingChannelConfig() ucAICardSubType:%d cardChanNo:%d RangeComp:%d RangeGain:%d RangePair:%d GTC:%d\r\n", ucAICardSubType, cardChanNo, RangeComp, RangeGain, RangePair, GetTickCount() );
				m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
				//If new AI and channel is configured for Ohms/RTD then copy the float value directly otherwise convert readings
				if ( AI_CARD_TYPE_V7AI == ucAICardSubType )
				{
					pAIConfig->GetWorkingChannelConfig( cardChanNo, &RangeComp, &RangeGain, &RangePair );
					if ( PairA7A8 == RangePair )	//Channel Pair value for OHMS/RTD
					{
						uFloat.m_uint32 = reading;
						measuredV = uFloat.m_float;
						if (Gain1 == RangeGain)
						{
							measuredV = measuredV / 1000;
						}
					}
					else
					{
						measuredV = EngConvertAIChannelReading( reading, pChanInfo->m_pRangeScale );
					}
				}
				else
				{
					measuredV = EngConvertAIChannelReading( reading, pChanInfo->m_pRangeScale );
				}
#if defined ( DBG_FILE_LOG_PPAI_DBG_ENABLE )
				strLogMessage = QString::asprintf("CPPAIChannel::AIPCR- EngConvertAIChannelReading(RangeScale) Reading %d measuredV %f GTC:%d\r\n", reading, measuredV, GetTickCount() );
				m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
				if( AI_CHANNEL_TYPE_LINEAR_AMPS == chanType )
				{
					measuredmA = measuredV / 10.0F;
				}
				if( (FALSE == engValueLoaded) || (IsRunningAsATEEquipment() == TRUE) || (pBrdStatsObj->HasLimitedRunModeBeenOrderedOnCard(slotNo) == TRUE) )
				{
					StoreEngineeringValue( pChanInfo, measuredV );
					engValueLoaded = TRUE;
				} // end if( (engValueLoaded == FALSE) || (IsRunningAsATEEquipment() == TRUE) || (pBrdStatsObj->HasLimitedRunModeBeenOrderedOnCard(slotNo) == TRUE) )
				if( (IsRunningAsATEEquipment() == FALSE) &&
						(TRUE == pAIBrdConfig->CfgChan[cardChanNo].InputLinearisation) )
				{
					// Now compensate for any sensor voltage user linearisation table specified
					if( (NO_CHAN_LINEARISATION != pAIBrdConfig->CfgChan[cardChanNo].UserLinearisation) &&
							((AI_CHANNEL_TYPE_LINEAR_AMPS == chanType) ||
									(AI_CHANNEL_TYPE_LINEAR_VOLTS == chanType)) )
					{
						userHWUnitsTableUsed = TRUE;
						// Compensate when any user linearisation is specified and channel is a linear channel type
						if(AI_CHANNEL_TYPE_LINEAR_VOLTS == chanType)
						{
							conditionedReading = pICService->PerformUserLinerisation(pAIBrdConfig->CfgChan[cardChanNo].UserLinearisation-1, measuredV );
#if defined ( DBG_FILE_LOG_PPAI_DBG_ENABLE )
							strLogMessage = QString::asprintf("CPPAIChannel::AIPCR- PerformUserLinerisation Reading %d measuredV %f conditionedReading %f GTC:%d\r\n", reading, measuredV, conditionedReading, GetTickCount() );
							m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
						}
						else
						{
							conditionedReading = pICService->PerformUserLinerisation(pAIBrdConfig->CfgChan[cardChanNo].UserLinearisation-1, measuredmA );
						}
						/// Normally sensor compensation is specified in engineeering units
						/// @todo: Will need to offset any sensor specified unit, sensor compensation here.
					}
				}
				// If channel is a linear channel (but not ohms - they are done later)
				if( (AI_CHANNEL_TYPE_LINEAR_VOLTS == chanType) || (AI_CHANNEL_TYPE_LINEAR_AMPS == chanType) )
				{
					pAICard->RemoveChannelFlF

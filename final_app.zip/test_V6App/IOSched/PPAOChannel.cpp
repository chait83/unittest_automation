/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PPAOChannel.cpp
/// @n implementation for an AO Channel class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 36	Stability Project 1.31.1.3	7/2/2011 4:59:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 35	Stability Project 1.31.1.2	7/1/2011 4:38:38 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 34	Stability Project 1.31.1.1	3/17/2011 3:20:34 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 33	Stability Project 1.31.1.0	2/15/2011 3:03:41 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "PPL.h"
#include "DataItemManager.h"
#include "DataItemIO.h"
#include "V6globals.h"
#include "PPQManager.h"
#include "V6IOErrorCodes.H"
#include "AIConfig.h"
#include "IOHandler.h"
#include "PPIOService.h"
#include "PPAOChannel.h"
#include "TraceDefines.h"
#include "InputConditioning.h"
#include "ATECal.h"
#include <math.h>
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define MAX_AO_SEND_READINGS 256
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPPAOChannel::CPPAOChannel(BOOL chanInput) : CPPIOService(chanInput) {
//	qDebug("Create new CPPAOChannel\n");
	m_LastOPValue = 0;
}
CPPAOChannel::~CPPAOChannel() {
//	qDebug("Delete CPPAOChannel class\n");
}
/////////////////////////////////////////////////////
/// Create the default definition of an AO channel
/// @param[in] pboardInfo - The board process info.
/// @param[in] pchanInfo - The channel process info.
/// @param[in] pCard - The I/O board class.
/// @param[in] chanNo - The board channel number.
///
/// @return TRUE if channel configured; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPAOChannel::CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
		class CCardSlot *const pCard, const USHORT chanNo) {
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	BOOL retValue = FALSE;
	pSlotMapObj = CSlotMap::GetHandle();
	if (pSlotMapObj != NULL) {
		pboardInfo->input = FALSE;
		pboardInfo->pCard = pCard;
		pboardInfo->CardSlotNo = static_cast<UCHAR>(pCard->BoardSlotInstance());
		pboardInfo->PPService = PP_SERVICE_AO_CHAN;
		pchanInfo->channelNo = static_cast<UCHAR>(chanNo);
		pchanInfo->glbchannelNo = pSlotMapObj->GetSysChannelFromAnaOutChannel(pboardInfo->CardSlotNo, chanNo,
				ONE_BASED);
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
// OutputAnalogue()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
/// @param[in] pChanInfo - System channel data.
/// @param[out] pOutputVal - System channel 16-bit anslogue data.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CPPAOChannel::OutputAnalogue(T_PCHANPROCESSINFO pChanInfo,
USHORT *pOutputVal) {
	class CBrdStats *pBrdStats = NULL;
	class CDataItem *pDataItem = NULL;
	class CPPIOServiceManager *pServiceManagerObj = NULL;
	class CInputConditioning *pICService = NULL;			///< Input conditioning service
	float penValue = 0.0F;
	float fOutput = 0.0F;
	USHORT outputValue = 0;
	BOOL retValue = FALSE;
	pBrdStats = CBrdStats::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if ((pDIT != NULL) && (pICService != NULL)
			&& (pChanInfo->chanInfo.AOChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled == TRUE)) {
		pDataItem = pDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING,
				pChanInfo->chanInfo.AOChanInfo.pChanCfgInfo->RetransPenNo);
		if (pDataItem != NULL) {
			// Only retransmit valid pen data
			if (pDataItem->GetStatus() >= DISTAT_NORMAL) {
				penValue = pDataItem->GetFPValue();
//				if( pICService->TestFloatError(penValue) == FALSE )
				{
					fOutput = pChanInfo->chanInfo.AOChanInfo.pChanWrkInfo->pPen->CalcSourceToDest(penValue);
					if (fOutput > 0) {
						if (fOutput > static_cast<float>(AO_SELECT_24mA))
							outputValue = AO_SELECT_24mA;			// Prevent overrange values wrapping
						else
							outputValue = static_cast<USHORT>(fOutput);
					} else
						outputValue = 0;			// Prevent a negative output from being retransmitted
				}
			} else if ((pDataItem->GetStatus() == DISTAT_INPUT_OVERRANGE)
					|| (pDataItem->GetStatus() == DISTAT_INPUT_UPSCALE_BURNOUT)) {
				// Value to retransmit is overrange
				outputValue = AO_SELECT_24mA;
			} else {
				// Value to retransmit is in error
				outputValue = AO_SELECT_0mA;
			}
			// Cap AO output value according to configuration
			outputValue = pICService->LimitCurrentLoopmAOutput(pChanInfo->pCommon->CardSlotNo,
					pChanInfo->chanInfo.AOChanInfo.pChanCfgInfo->Limit,
					pChanInfo->chanInfo.AOChanInfo.pChanCfgInfo->Overrange, outputValue);
//			if( outputValue != m_LastOPValue)
			{
				// Output has changed therfore update I/O card
				m_LastOPValue = outputValue;
				*pOutputVal = outputValue;
				// Convert the output from counts to mA, and save
				pBrdStats->SetAnaOutValue(pChanInfo->pCommon->CardSlotNo, pChanInfo->channelNo,
						pICService->ConvertAOCountToDVMAmps(outputValue));
				retValue = TRUE;
			}
		}
	}
	return retValue;
}
//******************************************************
// IsAOUpdateRqd()
///
/// Is an AO channel update required.
/// @param[in] pChanInfo - System channel data.
///
/// @return TRUE if channel update is required; otherwise FALSE
/// 
//******************************************************
BOOL CPPAOChannel::IsAOUpdateRqd(T_PCHANPROCESSINFO pChanInfo) {
	BOOL retValue = FALSE;		//@todo: Always update at present
	return retValue;
}
//******************************************************
///
/// Connencts to the apporiate Pre-Process queue
/// @param[in] pChanInfo - I/O channel process information.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CPPAOChannel::InitialiseChanService(T_CHANPROCESSINFO *const pChanInfo) {
	BOOL retValue = FALSE;
	// Request and enable the relevant channel pre-process queue or data item (as required)
	if (pChanInfo->chanInfo.AOChanInfo.pChanCfgInfo->ChanCfgInfo.Enabled == TRUE) {
		if (IsRunningAsATEEquipment() == TRUE) {
			// Running as test equipment, so connect to relevent data item table(s)
		} else {
			// Running in recorder, so connect to relevent pen item table(s) update records
		}
	}
	retValue = TRUE;
	return retValue;
}

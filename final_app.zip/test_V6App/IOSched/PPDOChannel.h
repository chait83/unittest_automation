/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PPDOChannel.h
/// @n Desc:	Interface of the Pre-process DO channel class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 13	Stability Project 1.10.1.1	7/2/2011 4:59:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.10.1.0	7/1/2011 4:27:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	V6 Firmware 1.10		11/8/2006 3:01:24 PM	Graham Waterfield
//		Digital I/O setup commit improvements, first stage of hardware
//		counters and fix to milli-amp user defined range.
// 10	V6 Firmware 1.9		11/2/2006 6:27:34 PM	Graham Waterfield
//		Fix various digital problems
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PPDOCHANNEL_H
#define _PPDOCHANNEL_H
#if !defined(AFX_PPDOCHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PPDOCHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#include "Defines.h"
#include "PPIOService.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CPPDOChannel: public CPPIOService {
public:
	CPPDOChannel(const BOOL isChanInput);
	virtual ~CPPDOChannel();
	void ResetPulseValueHolder(T_PCHANPROCESSINFO pChanInfo);
	void ResetDigitalCounter(T_PCHANPROCESSINFO pChanInfo);
	BOOL UpdateOutputDigital(T_PCHANPROCESSINFO pChanInfo, const BOOL NewOPState);
	BOOL OutputDigital(T_CHANPROCESSINFO *const pChanInfo, BOOL *pNewState);
	BOOL CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
			class CCardSlot *const pCard, const USHORT chanNo);
private:
//		BOOL m_LastOPState;			///< Last output state to card (ignores failsafe setting)
};
#endif // !defined(AFX_PPDOCHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif // _PPDOCHANNEL_H

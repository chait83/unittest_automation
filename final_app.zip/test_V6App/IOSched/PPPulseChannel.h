/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PPPulseChannel.h
/// @n Desc:	Interface of the Pre-process Pulse Channel class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 14	Stability Project 1.11.1.1	7/2/2011 4:59:47 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 13	Stability Project 1.11.1.0	7/1/2011 4:27:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 12	V6 Firmware 1.11		1/5/2007 3:32:04 PM	Graham Waterfield
//		Changed to allow process time for each channel to be calculated for
//		missing readings
// 11	V6 Firmware 1.10		10/25/2006 3:03:21 PM Graham Waterfield
//		Prevented initial forced read of digital I/O card (digital inputs)
//		and initial check-in for pulse measurements
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PPPULSECHANNEL_H
#define _PPPULSECHANNEL_H
#if !defined(AFX_PPPULSECHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PPPULSECHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "PPQService.h"
#include "PPIOService.h"
class CPPPulseChannel: public CPPIOService {
public:
	CPPPulseChannel(BOOL isChanInput);
	virtual ~CPPPulseChannel();
	BOOL InitialiseChanService(T_CHANPROCESSINFO *const pChanInfo);
	BOOL SyncChannelQueue(T_CHANPROCESSINFO *const pChanInfo, const USHORT IOCardTick, const LONGLONG systemTick);
	void ReportPPQDiagnostics(T_CHANPROCESSINFO *const pChanInfo);
	BOOL ProcessPulseChannelReadings(T_CHANPROCESSINFO *const pChanInfo, const UCHAR *pChanData, const USHORT timestamp,
			const USHORT noOfReadings);
	LONGLONG ProcessMissingChannelReadings(T_COMMONPROCESSINFO *const pCommonInfo, T_CHANPROCESSINFO *const pChanInfo,
			const LONGLONG lastProcTime, const LONGLONG procTime);
	BOOL CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
			class CCardSlot *const pCard, const USHORT chanNo);
	void ResetPulseCountAccumulation(T_PCHANPROCESSINFO pChanInfo);
private:
};
#endif // !defined(AFX_PPPULSECHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif // _PPPULSECHANNEL_H

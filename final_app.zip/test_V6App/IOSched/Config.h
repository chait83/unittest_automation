/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n Config.h
/// @n interface of the CCardSlot class.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 31	Stability Project 1.28.1.1	7/2/2011 4:56:13 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 30	Stability Project 1.28.1.0	7/1/2011 4:27:09 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 29	V6 Firmware 1.28		9/18/2006 7:45:20 PM	Graham Waterfield
//		IO boards can now be placed into idle mode.
// 28	V6 Firmware 1.27		6/14/2006 2:12:00 PM	Graham Waterfield
//		Keep track of enabled channels
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_CONFIG_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_CONFIG_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#ifndef _CONFIG_H
#define _CONFIG_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
// Configuration types
#define CONFIG_UNKNOWN 			0		// Unknown configuration
#define CONFIG_AI				1		// AI configuration
#define CONFIG_AO				2		// AO configuration
#define CONFIG_DIG_PULSE		3		// Digital / pulse configuration
typedef struct _CommonProcessConfig_t {
//	ULONG		PPQmaxWrap;			///< The pre-process queue gearing ratio
	ULONG PPCTVtimeStamp;	///< The pre-process queue reading timestamp or first timstamp for all services except DI
	USHORT timestampfreq;	///< The frequency of the board timestamp (in Hz)
	USHORT PPQGearing;			///< The pre-process queue gearing ratio
//	USHORT		chanEnMask;			///< Channel enabled mask - if 1 then channel is enabled (only used for board service)
	USHORT acqRate;			///< The actual acqusition rate of the service
	USHORT readRate;		///< The actual read rate required of the service
	BOOL input;				///< TRUE if card or channel service is an input
} T_COMMONPROCESSCONFIG, *T_PCOMMONPROCESSCONFIG;
typedef struct _commoncfgchannelconfig {
	BOOL RawReadings;		///< Are raw readings required from channel
	BOOL Enabled;		///< Is channel currently enabled (or selected for calibration)
	UCHAR acqRate;			///< AI card acqusition rate
	UCHAR acqCardEnum;		///< AI card protocol acqusition rate (Enum)
	UCHAR acqEnum;			///< AI card setup acqusition rate (Enum)
} T_COMMONCFGCHANNEL, *T_PCOMMCFGCHANNEL;
//******************************************************
/// @brief Abstract class providing the configuration ability for 'cards' of all types.
/// 
/// Provides the configuration handing ability for 'cards' of all types
///
//******************************************************
class CConfig {
public:
	CConfig();
	virtual ~CConfig();
	BOOL ScheduleIOBoardRunMode(BOOL runMode);
	BOOL ScheduleRTChanCal(void);
	BOOL ScheduleSerialNoUpdate(void);
	BOOL ScheduleUpdateCardInfo(void);
	BOOL ScheduleTestStatusUpdate(void);
	BOOL SetAcquireModeActiveState(const BOOL activeState);
	virtual BOOL CMMCreateLocalConfig(void) = 0;
protected:
	BOOL InitialiseConfig(void);
	/// Data for card stats and info
	class CBrdInfo *m_pBrdInfoObj;			///< Board info holder
	class CBrdStats *m_pBrdStatsObj;		///< Board stats holder
	class CSlotMap *m_pSlotMapObj;		///< Board slot map holder
	class CIOConfigManager *m_pCIOConfigManagerObj;	/// < The associated I/O configuration manager
	USHORT m_chanEnabledMask;			///< I/O card enabled mask
//		USHORT m_Instance;					///< Board slot instance
	class CCardSlot *m_pIOCard;	///< Reference to IO card that config belongs to
private:
};
#endif // _CONFIG_H
#endif // !defined(AFX_CONFIG_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: ATECal.h
/// @n Desc:	Calibration class
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 101 Stability Project 1.98.1.1	7/2/2011 4:55:29 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 100 Stability Project 1.98.1.0	7/1/2011 4:27:28 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 99	V6 Firmware 1.98		1/19/2007 5:06:10 PM	Graham Waterfield
//		Provide improved diagnostic reporting for the ATE build
// 98	V6 Firmware 1.97		11/22/2006 4:09:22 PM Graham Waterfield
//		Ensure that user calibration works for disabled channels and always
//		saves success status even if recorder is reset.
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _ATECAL_H
#define _ATECAL_H
#if !defined(AFX_ATECAL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_ATECAL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "AIRanges.h"
#include "AIConfig.h"
#include "AOConfig.h"
#include "DigConfig.h"
#include "PassiveModule.h"
#include "ModuleMsgManagerClient.h"
// #define NON_ATE_REGISTER		1				///< Do not use ATE registering method
const float RAW_CAL_TOLERANCE = 0.03F;
const float REV_A_RAW_CAL_50V_TOLERANCE = 0.1F;
// eZtrend AI bank info
const UCHAR NO_OF_BANKS = 2;		///< Maximum number of AI channel banks
const UCHAR NO_OF_CHANS_IN_BANK = 3;	///< Number of AI channels in each bank
const UCHAR BANK_1_START_CHANNEL = 0;	///< Start board channel number for bank 1
const UCHAR BANK_2_START_CHANNEL = (BANK_1_START_CHANNEL + NO_OF_CHANS_IN_BANK);///< Start board channel number for bank 2
const UCHAR BANK_2_END_CHANNEL = (BANK_1_START_CHANNEL + (NO_OF_CHANS_IN_BANK * 2));///< End board channel number for bank 2
// Calibrator set voltages
const float SELECT_PLUS_VOLTS_50V = 50.0F;	///< Volts
const float SELECT_PLUS_VOLTS_25V = 25.0F;	///< Volts
const float SELECT_PLUS_VOLTS_12V = 12.0F;	///< Volts
const float SELECT_PLUS_VOLTS_6V = 6.0F;		///< Volts
const float SELECT_PLUS_VOLTS_3V = 3.0F;		///< Volts
const float SELECT_PLUS_VOLTS_1_5V = 1.5F;		///< Volts
const float SELECT_PLUS_VOLTS_0_6V = 0.6F;		///< Volts
const float SELECT_PLUS_VOLTS_0_3V = 0.3F;		///< Volts
const float SELECT_PLUS_VOLTS_1000mV = 1000.0F;	///< mV's
const float SELECT_PLUS_VOLTS_500mV = 500.0F;	///< mV's
const float SELECT_PLUS_VOLTS_250mV = 250.0F; 	///< mV's
const float SELECT_PLUS_VOLTS_100mV = 100.0F;	///< mV's
const float SELECT_PLUS_VOLTS_50mV = 50.0F;	///< mV's
const float SELECT_PLUS_VOLTS_25mV = 25.0F; 	///< mV's
const float SELECT_PLUS_VOLTS_10mV = 10.0F;	///< mV's
const float SELECT_PLUS_VOLTS_5mV = 5.0F; 	///< mV's
const float SELECT_NEG_VOLTS_50V = -50.0F;	///< Volts
const float SELECT_NEG_VOLTS_25V = -25.0F;	///< Volts
const float SELECT_NEG_VOLTS_12V = -12.0F;	///< Volts
const float SELECT_NEG_VOLTS_6V = -6.0F;	///< Volts
const float SELECT_NEG_VOLTS_3V = -3.0F;	///< Volts
const float SELECT_NEG_VOLTS_1_5V = -1.5F;	///< Volts
const float SELECT_NEG_VOLTS_0_6V = -0.6F;	///< Volts
const float SELECT_NEG_VOLTS_0_3V = -0.3F;	///< Volts
const float SELECT_NEG_VOLTS_1000mV = -1000.0F;	///< mV's
const float SELECT_NEG_VOLTS_500mV = -500.0F;	///< mV's
const float SELECT_NEG_VOLTS_250mV = -250.0F; 	///< mV's
const float SELECT_NEG_VOLTS_100mV = -100.0F;	///< mV's
const float SELECT_NEG_VOLTS_50mV = -50.0F;	///< mV's
const float SELECT_NEG_VOLTS_25mV = -25.0F; 	///< mV's 
const float SELECT_NEG_VOLTS_10mV = -10.0F;	///< mV's
const float SELECT_NEG_VOLTS_5mV = -5.0F; 	///< mV's
const float SELECT_VOLTS_0mV = 0.0F;		///< mV's
// Analogue output set currents
const USHORT AO_SELECT_0mA = 0;
const USHORT AO_SELECT_50uA = 150;
const USHORT AO_SELECT_4mA = 10922;
const USHORT AO_SELECT_9mA = 24576;
const USHORT AO_SELECT_12mA = 32768;
const USHORT AO_SELECT_15mA = 49152;
const USHORT AO_SELECT_18mA = 49152;
const USHORT AO_SELECT_20mA = 54613;
const USHORT AO_SELECT_21mA = 57344;
const USHORT AO_SELECT_24mA = 0xffff;
// Analogue output currents that ensure the minimum output is always met.
const USHORT AO_ENSURE_20mA = 54750;
const USHORT AO_ENSURE_21mA = 57488;		// Can only set on I/O boards after AK.007
const USHORT ILLEGAL_CARD_SELECTED = 0xff;		///< Illegal card number (ATE card number not found)
const USHORT ILLEGAL_PULSE_READING = 0xffff;		///< Pulse reading that cannot be physically measured
const float RT_8_CHAN_COMBINED_VOLTAGE_SOURCE_LO_I = 0.2F;
const float RT_8_CHAN_COMBINED_VOLTAGE_SOURCE_HI_I = 1.1F;
const float RT_6_CHAN_COMBINED_VOLTAGE_SOURCE_LO_I = 0.15F;
const float RT_6_CHAN_COMBINED_VOLTAGE_SOURCE_HI_I = 0.825F;
const float RT_4_CHAN_COMBINED_VOLTAGE_SOURCE_LO_I = 0.1F;
const float RT_4_CHAN_COMBINED_VOLTAGE_SOURCE_HI_I = 0.55F;
const USHORT RT_8_CHAN_COMBINED_VOLTAGE_LO = 59000;
const USHORT RT_8_CHAN_COMBINED_VOLTAGE_HI = 64000;
const USHORT RT_6_CHAN_COMBINED_VOLTAGE_LO = 52000;
const USHORT RT_6_CHAN_COMBINED_VOLTAGE_HI = 56000;
const USHORT RT_4_CHAN_COMBINED_VOLTAGE_LO = 45000;
const USHORT RT_4_CHAN_COMBINED_VOLTAGE_HI = 49000;
const USHORT EZ_RT_POS_25MV_UPPER_TOL = 53990;
const USHORT EZ_RT_POS_25MV_LOWER_TOL = 53490;
const USHORT EZ_RT_NEG_25MV_UPPER_TOL = 12040;
const USHORT EZ_RT_NEG_25MV_LOWER_TOL = 11540;
const USHORT EZ_NO_CURR_FLOW_UPPER_TOL = 32788;
const USHORT EZ_NO_CURR_FLOW_LOWER_TOL = 32748;
const USHORT EZ_CURR_FLOW_UPPER_TOL = 54990;
const USHORT EZ_CURR_FLOW_LOWER_TOL = 52490;
const USHORT EZ_CURR_FLOW_UPPER_PRECISE_TOL = 100;
const USHORT EZ_CURR_FLOW_LOWER_PRECISE_TOL = 100;
const float EZ_A3_A4_RT_CURR_RESCALE_FACTOR = 1.002462064F;
const float EZ_A1_A2_RT_CURR_RESCALE_FACTOR = 0.9951F;
const float EZ_RT_TEST_BOX_CORRECTION = 0.9985F;
#define CHANNEL_NOT_SELECTED		0
typedef struct s_Message {
	QString csDispMess;		//message for displaying
	QString csErrMess;		//error message
} T_MESSAGE_DETAILS;
/// AI channel zero and span calibration points
typedef struct _aichannelcal {
	T_RANGE_COUNTS zeroCount;					///< -ve raw value
	T_RANGE_COUNTS spanCount;					///< +ve raw value
} T_AICHANNELCAL, *T_PAICHANNELCAL;
/// AI channel zero and span floating point calibration points
typedef struct _aichannelfcal {
	float zeroCount;					///< -ve raw value
	float spanCount;					///< +ve raw value
} T_AICHANNELFCAL, *T_PAICHANNELFCAL;
// Ez RT calibration storage containers for testing and processing
#define EZ_A3_A4_25MV_STORE				0
#define EZ_A7_A8_25MV_INVERTED_STORE	1
#define EZ_A1_A2_NULL_STORE				2
#define EZ_A1_A2_RT_CURR				3
#define EZ_A3_A4_RT_CURR				4
#define EZ_A1_A2_RT_CURR_RESCALED		5
#define EZ_A7_A8_RESCALED				6
#define MAX_EZ_RT_CAL_REFS				EZ_A7_A8_RESCALED + 1
typedef struct _ezaichannelcal {
	T_AICHANNELCAL ezChanCal[MAX_EZ_RT_CAL_REFS];		///< Calculation holders
} T_EZAICHANNELCAL, *T_PEZAICHANNELCAL;
typedef struct _ezaibankcal {
	T_AICHANNELFCAL ezBankCal[MAX_EZ_RT_CAL_REFS];		///< Calculation holders
} T_EZAIBANKFCAL, *T_PEZAIBANKFCAL;
typedef struct _aicalinfo {
	USHORT chanMask;		///< Channel mask of those channels selected for calibration
	USHORT rangeEnum;	///< Range 50V, 25V etc or TC / RT type selection Info
	USHORT rtCalInfo[TOPSLOT_AICHAN_SIZE];	///< All RT Cal channels calibration information
	T_AICHANNELCAL calDownload[TOPSLOT_AICHAN_SIZE];	///< All channels calibration information to download to board
	T_AICHANNELCAL calInfo[TOPSLOT_AICHAN_SIZE];	///< All channels calibration information
	T_AICHANNELCAL savedCalInfo[TOPSLOT_AICHAN_SIZE];	///< All channels calibration information (saved)
	T_AICHANNELCAL savedEzRTCalInfo[TOPSLOT_AICHAN_SIZE];	///< All ez channels RTCal calibration information (saved)
	T_AICHANNELCAL savedEzRTInfo[TOPSLOT_AICHAN_SIZE];	///< All ez channels RT calibration information (saved)
	T_EZAICHANNELCAL eZRTCalInfo[TOPSLOT_AICHAN_SIZE];	///< All ez channels RT calibration information
	T_EZAIBANKFCAL bankAveCal[NO_OF_BANKS];			///< Ez AI bank calibration
	float calBankmidPoint[NO_OF_BANKS];	///< Ez bank mid-point calibration (can go slightly negative)
	float RTBankFactor[NO_OF_BANKS];				///< Ez bank RT factor
//	float			RTBankVoltCount[NO_OF_BANKS];			///< Ez bank RT Volt count
	float calmidPointA3A4[TOPSLOT_AICHAN_SIZE];	///< Ez channel mid-point calibration for A3A4 (can go slightly negative)
	float calmidPointA7A8[TOPSLOT_AICHAN_SIZE];	///< Ez channel mid-point calibration for A7A8 (can go slightly negative)
	float RTFactor[TOPSLOT_AICHAN_SIZE];			///< Ez channel RT factor
} T_AICALINFO, *T_PAICALINFO;
// Individual channel calibration
typedef struct _aochancalibration {
	UCHAR Offset;						///< Offset from ideal
	USHORT RawCount20mA;				///< Count being offset
} T_AOCHANCAL, *T_PAOCHANCAL;
// Selelct the IO scheduler operating mode
typedef enum {
	CM_ATE_TEST,						///< Operating in ATE test mode
	CM_ATE_FACTORY_CAL,			///< Operating in ATE factory calibration mode
	CM_ATE_USER_CAL,				///< Operating in ATE user calibration mode
	CM_RECORDER_USER_CAL,			///< Operating in recorder calibration mode
	CM_ATE_FACTORY_RT_CHAN_CAL	///< Operating in ATE RT cal calibration mode
} T_CAL_MODE;
// Selelct the IO scheduler test operating mode
typedef enum {
	CTOM_ATE_READ,							///< Normal read mode
	CTOM_ATE_CAL_COMMIT_SET_POINTS,		///< Mode to commit calibration points
	CTOM_ATE_CAL_COMMIT_SET_RT_POINTS,		///< Commit RT calibration points
	CTOM_ATE_CAL_SETPOINT_LOW,				///< Sets the zero calibration point
	CTOM_ATE_CAL_SETPOINT_HIGH,				///< Sets the span calibration point
	CTOM_ATE_SET_TEST_STAT,					///< Mode to set the test results
	CTOM_ATE_SET_BOARD_ID,					///< Mode to set the board ID
	CTOM_ATE_CAL_RT_CHAN,					///< Mode to RT cal a channel
	CTOM_ATE_CJC_READ		///< Mode to calibrate the CJC (not currently used)
} T_CAL_TEST_OP_MODE;
// Direct read override mode to allow different input pairs to be selected
// rather than standard mv's and Volt input pairs.
typedef enum {
	DRM_READ_INPUT_RTCAL,			///< AI RT cal (low current) calibration
	DRM_READ_INPUT_RTCOMP,			///< AI RT comp (low current) calibration
	DRM_READ_INPUT_RTCAL_HIGH,		///< AI RT cal (high current) calibration
	DRM_READ_INPUT_RTCOMP_HIGH,		///< AI RT comp (high current) calibration
	DRM_READ_INPUT_RT_CHAN,			///< AI RT channel calibration
	DRM_READ_EZ_INPUT_RTCAL,		///< Ez AI RT cal calibration
	DRM_READ_EZ_INPUT_RTCOMP,		///< Ez AI RT comp calibration
	DRM_READ_EZ_INPUT_RTCAL_FACT	///< Ez AI RT cal factory calibration
} T_DIRECT_READ_MODE;
typedef enum {
	CESS_NO_ERROR,					///< Failure summary - all OK
	CESS_WARNING,					///< Failure summary - user warning noted
	CESS_ERROR						///< Failure summary - critical failure
} T_COMMS_ERR_STATUS_SUMMARY;
// Ez trend analogue channel banks
typedef enum {
	BANK_1_ID,			///< Bank 1 channels (1-3)
	BANK_2_ID,			///< Bank 2 channels (4-6)
	BANK_NA				///< Bank is not applicable
} T_EZ_BANK_ID;
class CATECal: public CPassiveModule {
	// Allow the I/O card configuration classes to directly access calibration structure(s)
	// This is really a single class split
	// so that an isolated singleton can be accessed by programs performing I/O card calibration
	friend class CAIConfig;
	friend class CAOConfig;
	friend class CDigConfig;
	friend class CPPDICard;
	friend class CProtocol;
	friend class CBaseProtocol;
public:
	void CleanUp();
	static CATECal* GetHandle();
	// Query current cal structure state
	BOOL CommitIOATECalStruct(void);
	BOOL TimeToCommitCalPoints(void);
	T_CAL_TEST_OP_MODE GetOperationalMode(void) const;
	USHORT GetChannelSelectionMask(void) const;
	USHORT GetRTISrcChannelDisableMask(void) const;
	void ConfirmDownloadCompleted(void);
	BOOL SetAbortCalibrationState(const BOOL abort);
	void SetIOCardCommsErrorReported(UCHAR slotNo, T_COMMS_ERR_STATUS_SUMMARY errorLevel);
	T_COMMS_ERR_STATUS_SUMMARY QueryIOCardCommsErrorReported();
	USHORT CreateChanMaskFromAIBoardCalInfo(const USHORT range);
	BOOL EzAIHWRemoveDuffBankChannel(const T_EZ_BANK_ID bank);
	BOOL EzAICalculateBankChanCalUploadPoints(const T_EZ_BANK_ID bank);
	BOOL EzAICalculateBankAverages(const T_EZ_BANK_ID bank);
	BOOL EzAICalculateBankCalPoints(const T_EZ_BANK_ID bank);
	BOOL EzAICalculateBankCalUploadPoints(const T_EZ_BANK_ID bank);
	BOOL EzUploadAICalPoints(void);
	BOOL IsChannelStatusCheckScheduled(void);
	BOOL ScheduleChannelStatusCheck(void);
	BOOL SetTestDateTime(const LONG time) const;
	BOOL SetRigNo(const UCHAR rigNo);
	BOOL SetTestStatus(const UCHAR passState);
	UCHAR GetRigNo(void);
	BOOL SelectATECardNo(const UCHAR slotNo);
	UCHAR QueryATECardNo(void) const;
	UCHAR QueryATECardNoOfChannel(void) const;
	void SetChannelSelection(const USHORT chanMask);
	void SetRTISrcChannelDisableMask(const USHORT chanMask);
	BOOL IsSetupDownloadable(void) const;
	BOOL IsSetupUpdated(void) const;		///< Board setup has been updated
	BOOL IsOutputUpdated(void) const;
	BOOL IsRuntimeUpdated(void) const;		///< Runtime information in the ATECal structure has been updated
//		void ResetSetupUpdated( void ) {m_setupUpdated = FALSE;}
	BOOL AIFactoryCalRTCalPoints(const USHORT chanMask);
	BOOL AISaveCalcDownload(const USHORT chanNo, const T_RANGE_COUNTS calcSpanSet, const T_RANGE_COUNTS calcZeroSet);
	bool CheckUserCalibration();
	BOOL SetOutputUpdated(const BOOL state);
	BOOL SetCommitMode(const BOOL state);
	// AI board selection
	BOOL ResetAllAIChannelsToPrecise(void);
	// Analogue Input channel selection
	BOOL DefaultChannel(const USHORT ChanNo);
	BOOL SetRawReadingMode(const USHORT chanNo, const BOOL rawOn);
	BOOL SetChannelRange(const USHORT ChanNo, const USHORT ChanType, const USHORT RangeEnum);
	BOOL SelectAIChanAcqRate(const USHORT ChanNo, const USHORT Rate);
	BOOL SelectAIChanVoltageRange(const USHORT chanNo, const USHORT Range);
	BOOL SelectAIChanCurrentRange(const USHORT chanNo, const USHORT Range);
	BOOL SelectAIChanResistanceRange(const USHORT chanNo, const USHORT Range);
	BOOL SelectAIChanTCRange(const USHORT ChannelNo, const USHORT Range);
	BOOL SelectAIChanRTRange(const USHORT ChannelNo, const USHORT Range);
	BOOL GetAIChannelRange(const USHORT ChanNo, USHORT *pChanType,
	USHORT *pRangeEnum) const;
	BOOL CheckTolerenceLimits(const T_RANGE_COUNTS zeroPoint, const T_RANGE_COUNTS spanPoint,
			const T_RANGE_COUNTS zeroUpperLimit, const T_RANGE_COUNTS zeroLowerLimit,
			const T_RANGE_COUNTS spanUpperLimit, const T_RANGE_COUNTS spanLowerLimit, const USHORT usChan) const;
	BOOL CheckCalibrationTolerences(const T_RANGE_COUNTS zeroUpperLimit, const T_RANGE_COUNTS zeroLowerLimit,
			const T_RANGE_COUNTS spanUpperLimit, const T_RANGE_COUNTS spanLowerLimit, USHORT &usChan) const;
	BOOL GetRangeReadTolerence(const USHORT Range, const float tolerence,
	T_RANGE_COUNTS *const pzeroUpperLimit,
	T_RANGE_COUNTS *const pzeroLowerLimit,
	T_RANGE_COUNTS *const pspanUpperLimit,
	T_RANGE_COUNTS *const pspanLowerLimit) const;
	BOOL GetChannelCalPoints(const USHORT Range, T_RANGE *pUpperRange,
	T_RANGE *pLowerRange, IO_MEASURE_UNITS *pUnits) const;
	BOOL SetAIAuxDirectRead(const USHORT ChanNo, const T_DIRECT_READ_MODE DirectMode, const BOOL rawMode);
	BOOL SetAICalibPair(const USHORT chanNo, const T_DIRECT_READ_MODE DirectMode, const BOOL rawMode);
	BOOL ManualRangeCalibrate(const USHORT cardNo, const USHORT Range, const BOOL spanPoint, const USHORT chanMask,
			QString &Instruction);
	// Special mode commit
	BOOL SelectAICalcChanVoltageRange(const USHORT ChannelNo, const USHORT Range);
	BOOL AIAutoCalibrateCJC(float TempSetPoint);
	BOOL RegisterWithCalibrationHolder(CModuleMsgManagerClient &Cconsumer, const T_MODULE_ID moduleID,
			const T_MODULE_MSG_NOTIFICATION moduleNotification);
	BOOL RegisterClientWindow(HWND clientWnd);
	// Level 2 calibration routines
	BOOL SetLimitedRunMode(void);
	BOOL InitialiseBoardRangeCalMode(const USHORT range, const USHORT chanMask);
	BOOL PerformBoardRangeCal(const BOOL spanPoint, const USHORT chanMask);
	BOOL CommitBoardUserCal(const USHORT chanMask);
	BOOL NotifyCalOrSetupChange(void);
	void CalibrationFinishShutDown(void);
	void InformCalibrationReadingsAvailable(void);
	float GetRangeRawReadTolerence(const USHORT range, const BOOL factoryCal) const;
	BOOL GetChannelVoltages(const USHORT channel, T_RANGE_COUNTS *pReading);
	BOOL ReadAnalogueInChannelValues(const USHORT chanMask);
	BOOL TestCardRawCalibrationTolerences(const USHORT range, const BOOL factoryCal, const USHORT inChanMask,
	USHORT *pOutChanMask) const;
	T_IORANGECAL* GetLocalAIBoardCalInfo(const USHORT slotNo, const USHORT range);
	T_IORANGECAL* GetAIBoardCalInfo(const USHORT slotNo, const USHORT range);
	// Analogue Input get readings
	BOOL GetAIChanReadings(const USHORT ChanNo, T_RANGE_COUNTS *pRawReading, float *pRangeReading) const;
	BOOL GetAIChanRawReadings(const USHORT ChanNo,
	T_RANGE_COUNTS *pRawReading) const;
	BOOL GetAIChanVoltageReadings(const USHORT ChanNo, float *pRangeReading) const;
	float GetAICJReading(void) const;
	BOOL QueryIsCJCValid(const UCHAR slotNo) const;
	BOOL SaveUserCalStatToNV(const USHORT slotNo, const USHORT chanNo, const USHORT rangeNo,
			const CInputConditioning::IO_CAL_OPTIONS state);
	BOOL SetAIChannelCalPoints(const USHORT ChanNo, const T_RANGE_COUNTS zeroCount, const T_RANGE_COUNTS spanCount);
	BOOL SetAIChannelSavedCalPoints(const USHORT ChanNo, const T_RANGE_COUNTS zeroCount,
			const T_RANGE_COUNTS spanCount);
	const T_AICHANNELCAL* GetAIChanDownloadCal(const UCHAR chanNo) const;
	BOOL GetAIChannelCalPoints(const USHORT ChanNo, T_RANGE_COUNTS &zeroCount,
	T_RANGE_COUNTS &spanCount) const;
	BOOL GetAIChannelSavedCalPoints(const USHORT ChanNo,
	T_RANGE_COUNTS &zeroCount, T_RANGE_COUNTS &spanCount) const;
	BOOL GetAIRTChannelCalPoints(const USHORT chanNo, USHORT &Count) const;
	BOOL SetAIRTChannelCalPoints(const USHORT chanNo, const USHORT Count);
	BOOL TestModeAIVRead(const USHORT chanMask, const float desiredVoltage);
	BOOL TestModeAImVRead(const USHORT chanMask, const float desiredVoltage);
	BOOL ReadingCheckRqd(void) const;
	BOOL SetReadingCheckRqdState(const BOOL state);
	void CopyRTChanOffsetStatus(void);
	void ResetRTChanOffsetStatus(void);
	void StoreRTChanOffset(UCHAR chanNo, float CJdifference);
	void StoreCalcRTChanOffset(UCHAR chanNo, float CJdifference);
	BOOL GetRTChanOffset(UCHAR chanNo, float *pCJdifference);
	BOOL SetCalModeState(const T_CAL_TEST_OP_MODE calMode);
	BOOL SetCalMode(const T_CAL_MODE calMode);
	BOOL CalculateRTChanZero(const USHORT chanMask);
	BOOL CalculateRTCalChanZero(void);
	BOOL EzAICalculateBankChanCalPoints(const T_EZ_BANK_ID bank);
	BOOL CopyAIHolders(const USHORT chanNo, const UCHAR srcContainer, const UCHAR destContainer, const BOOL spanSet);
	void EzAIReScaleCalPoints(const USHORT chanNo, const BOOL spanSet, const UCHAR container, const float scaleFactor);
	BOOL EzAIStoreChannelCalPoints(const USHORT chanMask, const BOOL spanSet, const UCHAR container,
			const float *poffset);
	BOOL EzAICheckCalPoints(const USHORT chanNo, const BOOL spanSet, const UCHAR container, const T_RANGE_COUNTS upper,
			const T_RANGE_COUNTS lower, T_RANGE_COUNTS *pValue);
	BOOL EzAICheckRelativeCalPoints(const USHORT chanNo, const BOOL spanSet, const UCHAR checkContainer,
			const UCHAR refContainer, const T_RANGE_COUNTS upper, const T_RANGE_COUNTS lower,
			T_RANGE_COUNTS *pValue);
	BOOL AIStoreChannelCalPoints(const USHORT chanMask, const BOOL spanSet, const float *poffset);
	BOOL AIFactoryCalRTChannels(const BOOL spanSet, const float *poffset);
	BOOL CommitFactoryRTChanCalRange(const USHORT chanMask);
	BOOL CommitFactoryCalRange(const USHORT chanMask);
	BOOL CommitUserCalRange(const USHORT chanMask);
	T_CAL_MODE GetCalMode(void) const;
	// ATE configuration structure
	BOOL EnableAllCardChannels(void);
	BOOL SetToCalibrateMode(void);
	BOOL RemoveCalibrateMode(void);
	void AddString(const QString &csDispString) const;
	void WriteErrorFileString(const QString &csFileMess) const;
	void NoAIChanRawReadingsTaken(void);
	BOOL IllegalRawValueData(const USHORT chanNo, const T_RANGE_COUNTS data, float *const pErrorCode) const;
	// CJC calibration routines (note these are saved in the recorder not the I/O board)
	BOOL SetCJCCalValueUsage(USHORT slotNumber, REFERENCE cfgType);
	BOOL SetAIChannelCJCUserCalPoint(const USHORT cardNo, const USHORT chanNo, float userCJCOffset);
	BOOL GetAIChannelCJCUserCalPoint(const USHORT cardNo, const USHORT chanNo, float &userCJCOffset) const;
	BOOL GetAIChannelCJCCaledValue(const USHORT cardNo, const USHORT chanNo, float &factCJCValue) const;
	BOOL IsChannelATC(const USHORT cardNo, const USHORT chanNo) const;
	// Runtime working channel calibration
	const T_AICHANNELCAL* GetAIChanCal(const UCHAR chanNo) const;
	const T_AICHANNELCAL* GetAISavedChanCal(const UCHAR chanNo) const;
	BOOL SetAIChanCal(const UCHAR chanNo, const T_AICHANNELCAL cal);
	BOOL StoreAIChanRawReadings(const USHORT ChanNo, const T_RANGE_COUNTS RawReading);
	BOOL StoreAIChanVoltageReadings(const USHORT ChanNo, const float RangeReading);
	BOOL AIStoreRawChannels(const USHORT chanMask);
	BOOL AILoadRawChannel(const USHORT chanNo, const T_RANGE_COUNTS rawValue);
	BOOL TestAIChanReadingsCompleted(void) const;
	BOOL TestAIChanRawReadingsCompleted(void) const;
	BOOL RestoreAllChannelsToRTRead(void);
	BOOL SelectRTReadChannels(const BOOL highChannelsTest);
	// Digital selection
	BOOL SetBoardCfgOutputPulseDuration(const USHORT chanNo, const USHORT pulseDuration);
	BOOL SetDigBoardCfgOutputPulseDirection(const USHORT chanNo, const UCHAR pulseDirection);
	BOOL SetDigBoardCfgOutput(const USHORT chanNo, const BOOL failSafe);
	BOOL SetDigBoardCfgInput(const USHORT chanNo);
	// Digital state selection
	BOOL SetDigBoardOutputState(const USHORT chanNo, const BOOL force, const BOOL digState);
	BOOL GetDigBoardActiveState(const USHORT chanNo);
	USHORT GetDigitalInState(void) const;
	// Pulse selection
	BOOL SetPulseBoardCfgAcqRate(const USHORT chanNo, const UCHAR acqRate);
	BOOL ResetAllPulseChannelsReadings(void);
	// Analogue output selection
	BOOL SetAOChan(const USHORT chanNo, const USHORT reading);
	BOOL GetAOChan(const USHORT chanNo, USHORT *pSetting);
	BOOL SetAOChan(const USHORT chanNo, const float reading);
	BOOL GetAOChan(const USHORT chanNo, float *pSetting);
	BOOL SetAOChanState(const USHORT chanNo, const BOOL chanOC);
	BOOL GetAOChanState(const USHORT chanNo) const;
	const T_AOCHANCAL* GetAOChanCal(const UCHAR chanNo) const;
	BOOL SetAOChanCal(const UCHAR chanNo, const T_AOCHANCAL cal);
	BOOL GetNextATEAnalOut(UCHAR *pChanNo, USHORT *pAOOutput);
	// Data block for pulse readings
	USHORT PulseInChanCount[TOPSLOT_PULSECHAN_SIZE];		///< Pulse In channel count
	void SetDigitalInState(const USHORT digIn) {
		DigitalInChanState = digIn;
	}
	// Register the message maanger client
	void RegisterMMC();
protected:
	BOOL SetCalcChannelRange(const USHORT ChanNo, const USHORT ChanType, const USHORT RangeEnum);
	IO_MEASURE_UNITS SetChannelEngUnits(const USHORT ChanType, const USHORT RangeEnum) const;
	BOOL CommitAIATECalStruct(void);
	BOOL CommitDigPulseATECalStruct(void);
	BOOL CommitAOATECalStruct(void);
private:
	CATECal();
	CATECal(const CATECal&);
	CATECal& operator=(const CATECal&) {
		return *this;
	}
	;
	virtual ~CATECal();
	// Singleton handlers
	static CATECal *m_pInstance;
	static QMutex m_CreationMutex;
	// *************************************
	// ATE 'controlling' module
	// *************************************
	T_MODULE_ID m_ModuleID;					///< Module ID
	HWND m_hWnd;						///< pointer to the parent hwnd
	CModuleMsgManagerClient m_ModuleMsgManagerClient;	///< Message handler
	// *************************************
	// Calibration & test command generic info
	// *************************************
	BOOL m_ReadingCheckRqd;	///< Reading check reqired (ATE mode)
	T_CAL_MODE m_calMode;			///< Mode currently selected
	T_CAL_TEST_OP_MODE m_opMode;			///< Operation mode to be used on MOD_CAL_INFO_UPDATED
	USHORT m_chanMask;			///< Channel selection mask (bit x = 1; channel selected)
	UCHAR m_cardSlot;			///< The number of the card slot currently being tested/calibrated
	UCHAR m_rigNo;			///< Rig number that board is being calibrated on
	BOOL m_OPUpdated;		///< Board O/P value has been updated
	BOOL m_setupUpdated;		///< Board setup has been updated
	BOOL m_ComitSetup;		///< Board setup has been updated, but should not be downloaded
	BOOL m_runtimeUpdated;		///< Runtime information in the ATECal structure has been updated
	// *************************************
	// AI channel data repository
	// *************************************
	USHORT m_RTIOffChanMask;	///< RT source current selection mask (1 = current off; 0 = current on)
	USHORT m_RTIChanReadMask;	///< RT source current test mask (1 = read channel; 0 = current being sourced)
	BOOL m_directRTReadMode;	///< AI card is in direct RT read mode if TRUE (use working direct)
	T_AIBOARDCONFIG m_cfgAI;	///< Card channel range being tested/calibrated
	T_AICALINFO m_AICal;			///< AI calibration info
	float m_testCalOutput;			///< Test and calibration calibrator voltage output required
	UCHAR m_CalOPUnits;	///< Test and calibration calibrator voltage output units
	// Data block for AI readings
	float AIChanVoltageReading[TOPSLOT_AICHAN_SIZE];	///< AI Channel voltage readings
	BOOL AIChanVReadingAvailable[TOPSLOT_AICHAN_SIZE];	///< AI Channel voltage readings available
	T_RANGE_COUNTS AIChanRawReading[TOPSLOT_AICHAN_SIZE];	///< AI Channel raw readings
	T_RANGE_COUNTS AIChanStoredRawReading[TOPSLOT_AICHAN_SIZE];	///< AI Channel stored raw readings
	BOOL AIChanRawReadingAvailable[TOPSLOT_AICHAN_SIZE];	///< AI Channel raw readings available
	// Data block for CJC RT channel offset calibration data
	float AICJChanRTOffsets[TOPSLOT_AICHAN_SIZE];///< Offsets from the AI RT Channel CJC calibration as updated by card
	BOOL AICJValidChanRTOffset[TOPSLOT_AICHAN_SIZE];///< TRUE if a valid Offset stored from the AI RT Channel CJC calibration
	float AISavedCJChanRTOffsets[TOPSLOT_AICHAN_SIZE];	///< Saved AI RT Channel CJC calibration offsets
	BOOL AICJValidSavedChanRTOffset[TOPSLOT_AICHAN_SIZE];///< TRUE if a valid Offset saved from the AI RT Channel CJC calibration
	// *************************************
	// AO channel data repository
	// *************************************
	T_AOCFGBOARDCONFIG m_cfgAO;	///< Downloadable setup for all board channels
	BOOL m_DirectOP;			///< Use direct O/P if TRUE; otherwise use pens
	USHORT m_AODirectOP[TOPSLOT_AOCHAN_SIZE];	///< Direct O/P values
	UCHAR m_lastChanSet;	///< The last channel written to (or 0 if no channels written)
	T_AOCHANCAL m_AOCalInfo[TOPSLOT_AOCHAN_SIZE];	///< I/O card calibration info
	BOOL m_OP_OC[TOPSLOT_AOCHAN_SIZE];		///< AO O/P open circuit
	BOOL m_StatusCheckRqd;					///< AO status check required
	// *************************************
	// Digital/pulse channel data repository
	// *************************************
	T_DIGCFGBOARDCONFIG m_cfgDigPulse;	///< Downloadable setup for all board channels
	T_DIGWRKCFG m_wrkDigBoard;	///< Working downloadable board configuration
	// *********************************
	// System error status summary
	// *********************************
	T_COMMS_ERR_STATUS_SUMMARY m_slotCommsError[MAX_SCHED_SERVICES];///< What type of comms error been reported from module
	T_COMMS_ERR_STATUS_SUMMARY m_commsError;	///< What type of comms error been reported from module
	// *********************************
	// Cal control
	// *********************************
	BOOL m_calAbort;			///< TRUE if calibration is being aborted
	// Data block for digital readings
	USHORT DigitalInChanState;					///< Digital In channel state
};
#endif // !defined(AFX_ATECAL_BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif // _ATECAL_H

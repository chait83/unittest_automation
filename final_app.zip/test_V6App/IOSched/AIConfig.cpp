/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AIConfig.cpp
/// @n implementation of the CAIConfig class.
/// CAIConfig provides the ability to update the local configuration to
/// upload to the AI board for calibration in addition to converting
/// and uploading the CMM configuration itself.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 149 Stability Project 1.144.1.3	7/2/2011 4:55:16 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 148 Stability Project 1.144.1.2	7/1/2011 4:37:54 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 147 Stability Project 1.144.1.1	3/17/2011 3:20:07 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 146 Stability Project 1.144.1.0	2/15/2011 3:02:03 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include <math.h>
#include "PPL.h"
#include "StringDefinitions.h"
#include "V6globals.h"
#include "V6IOBoardTypes.H"
#include "V6IO_AI_InputRanges.H"
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#include "AICard.h"
#include "AIConfig.h"
#include "AIRanges.h"
#include "ATECal.h"
#include "SetupConfiguration.h"
#include "IOSetupConfig.h"
#include "PenSetupConfig.h"
#include "CMMDefines.h"
#include "V6defines.h"
#include "V6crc.h"
#include "TraceDefines.h"
#include "Conversion.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define MAX_AI_READ_RATE 10
const float SQRT_EXTRATION_ENG_ZERO = 0.0F;
const float SQRT_EXTRATION_ENG_SPAN = 1.0F;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAIConfig::CAIConfig()
#ifdef DBG_FILE_LOG_AI_CFG_DBG_ENABLE
: m_debugFileLogger(L"\\SDMemory\\AICfgDbgLog.txt", FALSE, 10*1024*1024 )//ErrorFile with huge size and with recycle
#endif
{
//	qDebug("Create new CAIConfig\n");
	m_Config.ConfigCRC = 0;
	m_calMask = 0;
	m_Config.Calibration = V6_AI_NO_CAL;
	for (UCHAR chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
		m_Config.CfgChan[chanNo].userLowerSubRange = 0.0F;
		m_Config.CfgChan[chanNo].userUpperSubRange = 0.0F;
	}
}
CAIConfig::~CAIConfig() {
//	qDebug("Deleting CAIConfig class\n");
}
//**********************************************************************
/// InitialiseCardConfigHolder()
///
/// Initialises the I/O board configuration from the CMM.
///
/// @param[in] pIOCard - The I/O card to which this configuration belongs.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::InitialiseCardConfigHolder(class CIOCard *const pIOCard) {
	BOOL retValue = TRUE;
	m_pAIBrdRangesObj = CAIRanges::GetHandle();
	retValue = InitialiseConfig();
	m_pIOCard = pIOCard;
	if (m_pAIBrdRangesObj == NULL) {
		// @todo: Unable to get handle/create board range info
		retValue = FALSE;
	}
	if (m_pBrdInfoObj == NULL) {
		// @todo: Unable to get handle/create board info
		retValue = FALSE;
	}
	if (m_pBrdStatsObj == NULL) {
		// @todo: Unable to get handle/create board stats
		retValue = FALSE;
	}
	// Populate local configuration with CMM version
	if (retValue != FALSE)
		retValue = m_pIOCard->CMMCreateLocalConfig();
	return retValue;
}
//******************************************************
///
/// Queries the current channel range for any voltage channel on any
/// card in the local configuration.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pSelection - Channel selction.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QueryAISlotChannelSelection(const USHORT chanNo,
USHORT *pSelection) const {
	BOOL retValue = FALSE;
	*pSelection = m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType;
	retValue = TRUE;
	return retValue;
}
//******************************************************
///
/// Queries whether user or factory calibration is selected for a given board channel
/// for the range currently selected in the configuration
/// @param[in] chanNo - The card channel number.
///
/// @return whether factory or user calibration is selected
/// 
//******************************************************
CInputConditioning::IO_CAL_OPTIONS CAIConfig::QueryIOBoardChanRangeCalInfo(const USHORT chanNo) const {
	class CInputConditioning *pICService = NULL; ///< Input conditioning service
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	return pICService->QueryIOBoardChanRangeCalInfo(m_pIOCard->BoardSlotInstance(), chanNo,
			m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum);
}
//******************************************************
///
/// Queries the current channel is enabled
/// @param[in] ChanNo - The card channel number.
/// @param[out] pEnabled - TRUE if the channel is enabled.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotChannelEnabled(const USHORT chanNo, BOOL *pEnabled) const {
	BOOL retValue = FALSE;
	// Ensure channel is legal
	if (chanNo < TOPSLOT_AICHAN_SIZE) {
		*pEnabled = m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
///
/// Queries whether any channel is enabled
///
/// @return The bit mask of the enabled channels
/// 
//******************************************************
USHORT CAIConfig::QueryAnySlotChannelEnabled(void) const {
	return m_chanEnabledMask;
}
//******************************************************
// ScheduleActBrnStatusDownload()
///
/// Schedule a block data download of all AI card active burnout states.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::ScheduleActBrnStatusDownload(void) {
	return (static_cast<class CAICard*>(m_pIOCard))->ScheduleActBrnStatusDownload();
}
//******************************************************
///
/// Schedule a upload of user Cal points for selected channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::ScheduleUserCalUpload(void) {
	return (static_cast<class CAICard*>(m_pIOCard))->ScheduleUserCalUpload();
}
//******************************************************
///
/// Schedule a upload of factory Cal points for selected channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::ScheduleFactoryCalUpload(void) {
	return (static_cast<class CAICard*>(m_pIOCard))->ScheduleFactoryCalUpload();
}
//**********************************************************************
/// GetWorkingChannelConfig
///
/// Obtains the channel range info of a given base range ID
///
/// @param[in] chanNo - The AI board channel number.
/// @param[out] pRangeComp - The AI boards range gain and setup.
/// @param[out] pRangeGain - The AI boards range gain.
/// @param[out] pRangePair - The AI boards range input pair.
///
/// @return		TRUE if range identified and available; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::GetWorkingChannelConfig(const UCHAR chanNo, UCHAR *pRangeComp, UCHAR *pRangeGain,
		UCHAR *pRangePair) const {
	*pRangeComp = m_Config.WrkChan[chanNo].RangeGain;
	*pRangeGain = GetInputRange(m_Config.WrkChan[chanNo].RangeGain);
	*pRangePair = GetHighInputPair(m_Config.WrkChan[chanNo].RangeGain);
	return TRUE;
}
//******************************************************
///
/// Queries the current board raw reading selection
///
/// @return TRUE if raw mode is set; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QueryCardRawScaleSetting(void) const {
	return (m_Config.RawMode);
}
//******************************************************
///
/// Queries the current channel acqsistion rate for any input channel
/// on any card in the local configuration.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Rate - The acquisition rate of the channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotAcqRate(const USHORT chanNo, USHORT *pRate) const {
	BOOL chanEnabled;
	BOOL retValue = FALSE;
	if (QuerySlotChannelEnabled(chanNo, &chanEnabled) == TRUE) {
		if ( TRUE == chanEnabled) {
			*pRate = m_Config.CfgChan[chanNo].ChanCfgInfo.acqRate;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the current channel range for any voltage channel on any card in the local configuration.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The voltage range of the channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotVoltageRange(const USHORT chanNo,
USHORT *pRange) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if (AI_CHANNEL_TYPE_LINEAR_VOLTS == chanType) {
			*pRange = m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the current channel range for any current channel on any card in the local configuration.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The current range of the channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotCurrentRange(const USHORT chanNo,
USHORT *pRange) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if (AI_CHANNEL_TYPE_LINEAR_AMPS == chanType) {
			*pRange = m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the current channel range for any resistance channel on
/// any card in the local configuration.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The rsistance range of the channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotResistanceRange(const USHORT chanNo,
USHORT *pRange) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if (AI_CHANNEL_TYPE_LINEAR_OHMS == chanType) {
			*pRange = m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the current channel range for any TC channel
/// any card in the local configuration.
/// @param[in] ChanNo - The TC card channel number.
/// @param[out] Range - The TC type selected by the channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotTCRange(const USHORT chanNo, USHORT *pRange) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if (AI_CHANNEL_TYPE_TC == chanType) {
			*pRange = m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the current external CJ channel number for any TC channel
/// @param[in] ChanNo - The TC card channel number.
/// @param[out] pCJChan - The TC CJ channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotTCCJChan(const USHORT chanNo, USHORT *pCJChan) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if (AI_CHANNEL_TYPE_TC == chanType) {
			*pCJChan = m_Config.CfgChan[chanNo].TCCfg.CJCompAI;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the current channels number for any TC channel
/// @param[in] ChanNo - The TC card channel number.
/// @param[out] pCJChan - The TC CJ channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QueryChanExternalSpecifiedCJ(const USHORT chanNo, float *pCJValue) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if ((AI_CHANNEL_TYPE_TC == chanType)
				&& (AIN_CJC_EXT_SPEC_TEMP == m_Config.CfgChan[chanNo].TCCfg.CJCompMethod)) {
			*pCJValue = m_Config.CfgChan[chanNo].TCCfg.ExtSpecifiedCJ;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries whether a channel is currently configured as a TC
/// @param[in] ChanNo - The card channel number.
///
/// @return TRUE if the channel is currently set as a TC; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QueryIsChanATC(const USHORT chanNo) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if (AI_CHANNEL_TYPE_TC == chanType) {
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the current channel range for any RT channel on any card
/// in the local configuration.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The RT type selected by the channel.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotRTRange(const USHORT chanNo, USHORT *pRange) const {
	USHORT chanType;
	BOOL retValue = FALSE;
	if (QueryAISlotChannelSelection(chanNo, &chanType) == TRUE) {
		if (AI_CHANNEL_TYPE_RT == chanType) {
			*pRange = m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			retValue = TRUE;
		}
	}
	return retValue;
}
//******************************************************
///
/// Queries the engineering values for any AI channel in the local configuration.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pEngZero - The lower enginering value.
/// @param[out] pEngSpan - The upper engineering value.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
/// @note: on reverse scales the upper value will be lower than the lower
//******************************************************
BOOL CAIConfig::QuerySlotEngValues(const USHORT chanNo, float *pEngZero, float *pEngSpan) const {
	BOOL retValue = FALSE;
	*pEngZero = m_Config.CfgChan[chanNo].mcEngZero;
	*pEngSpan = m_Config.CfgChan[chanNo].mcEngSpan;
	retValue = TRUE;
	return retValue;
}
//******************************************************
///
/// Queries whether burnout is selected.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pEngZero - The lower enginering value.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
/// @note: Only applies to active burnout - Passive burnout is always selected
//******************************************************
BOOL CAIConfig::QueryChanBurnOutSelected(const USHORT chanNo, BOOL *pBurnOutSelected) const {
	BOOL retValue = TRUE;
	*pBurnOutSelected = m_Config.CfgChan[chanNo].TCCfg.BurnOutSelect;
	return retValue;
}
//******************************************************
///
/// Queries whether active burnout is selected.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pActiveBurnOutSelected - Active burnout selected.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QueryChanActiveBurnout(const USHORT chanNo, BOOL *pActiveBurnOutSelected) const {
	BOOL retValue = TRUE;
	*pActiveBurnOutSelected = m_Config.CfgChan[chanNo].TCCfg.ActiveBurnout;
	return retValue;
}
//******************************************************
///
/// Queries the selected CJ compensation method.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pEngZero - CJ compensation method to use.
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QueryChanCJCompMethodSelect(const USHORT chanNo, UCHAR *pCJCompMethod) const {
	BOOL retValue = TRUE;
	*pCJCompMethod = m_Config.CfgChan[chanNo].TCCfg.CJCompMethod;
	return retValue;
}
//******************************************************
///
/// Queries whether upscale burnout is selected.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pBurnoutSelect - TRUE if upscale selected;
///								otherwise FALSE for downscale
///
/// @return TRUE if the query is successful; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QueryChanUpscaleBurnoutSelect(const USHORT chanNo, BOOL *pUpsaleBurnoutSelect) const {
	BOOL retValue = TRUE;
	*pUpsaleBurnoutSelect = m_Config.CfgChan[chanNo].TCCfg.UpScaleBurnOut;
	return retValue;
}
//******************************************************
///
/// Queries the state of SQRT extract in the local configuration.
/// @param[in] ChanNo - The card channel number.
///
/// @return TRUE if SQRT extract is selected; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::QuerySlotSQRTExtractState(const USHORT chanNo) const {
	BOOL retValue = FALSE;
	if (NO_CHAN_LINEARISATION == m_Config.CfgChan[chanNo].UserLinearisation)
		retValue = m_Config.CfgChan[chanNo].SqrtExtract;
	return retValue;
}
//**********************************************************************
/// CalculateChannelReadRate()
///
/// Calculates the channel read rate from the local configuration.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between reads on this channel
//**********************************************************************
USHORT CAIConfig::CalculateChannelReadRate(const UCHAR chanNo) {
	USHORT rate = 0;
	// Base the read rate on the acqusition rate
	rate = m_Config.CfgChan[chanNo].ChanCfgInfo.acqRate;
	// Cap maximum read rate
	if (rate > MAX_AI_READ_RATE)
		rate = MAX_AI_READ_RATE;
	return rate;
}
//**********************************************************************
/// GetChannelAcqRate()
///
/// Gets the channel acqusition rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between acqusitions on this channel
//**********************************************************************
USHORT CAIConfig::GetChannelAcqRate(const UCHAR chanNo) const {
	return m_Config.CfgChan[chanNo].ChanCfgInfo.acqRate;
}
//**********************************************************************
/// CMMSlotLoad()
///
/// Converts CMM configuration into a locally held I/O card downloadable configuration
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::CMMSlotLoad(void) {
	BOOL LoadOK = TRUE;
#ifndef ATE_BUILD
	T_PAICHANNEL pAICMMChan = NULL;
	USHORT chanNo = 0;
	WCHAR boardSlotStr[4];
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CIOSetupConfig *pIOSetupConfig = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	pIOSetupConfig = pSETUP->GetIOSetupConfig();
//	m_chanEnabledMask = 0;
	if (NULL != pIOSetupConfig) {
		// Load configuration for each AI channel
		chanNo = 0;
		// Check the number of avaialable channels on each board actually fitted
		do {
			// No other channel is currently legal on an AI board
			if (pSlotMap->GetHWChannelSelectedType(m_pIOCard->BoardSlotInstance(), chanNo) == CHANNEL_AI) {
				pAICMMChan = pIOSetupConfig->GetAnalogueInput(m_pIOCard->BoardSlotInstance(), chanNo, CONFIG_COMMITTED);
				if (NULL != pAICMMChan) {
					// Copy CMM config into local config
					LoadOK = CMMChannelTransfer(chanNo, pAICMMChan);
				} else {
					// Could not build local channel config from CMM
					LOG_ERR(TRACE_IO_SCHED, "CHANNNEL %d CONFIGURATION NOT FOUND", chanNo);
					LoadOK = FALSE;
				}
			} else {
				// Illegal channel found; this should never happen
				pSlotMap->GetSlotStrID(m_pIOCard->BoardSlotInstance(), boardSlotStr);
				LOG_ERR(TRACE_IO_SCHED, "ILLEGAL CHANNNEL %d CONFIGURATION FOUND ON AI BOARD %s", chanNo, boardSlotStr);
			}
			chanNo++;
		} while ((chanNo < pBrdInfo->GetNoOfChannels(m_pIOCard->BoardSlotInstance())) && (LoadOK == TRUE));
		// If each channel has been successfully configured, then commit the local AI configuration to the I/O card
		if ( TRUE == LoadOK) {
			IOCardLocalConfigCommit();
		}
	} else {
		LOG_ERR(TRACE_IO_SCHED, "NO CONFIGURATION FOUND FOR AI BOARD %d", m_pIOCard->BoardSlotInstance());
		LoadOK = FALSE;
	}
#endif
	return LoadOK;
}
//**********************************************************************
///
/// Get reference to channel local configuration as channel service data
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] pChanCfgInfo - Channel configuration info
/// @param[out] pChanWrkInfo - Channel working info
///
/// @return		TRUE if the cahannel has configuration data available; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::GetChannelConfigRef(const UCHAR ChanNo, T_AICFGCHANNEL **ppChanCfgInfo,
		T_AIWRKCHANNELCFG **ppChanWrkInfo) {
	BOOL retValue = FALSE;
	// Ensure channel is legal
	if (ChanNo < TOPSLOT_AICHAN_SIZE) {
		*ppChanCfgInfo = &m_Config.CfgChan[ChanNo];
		*ppChanWrkInfo = &m_Config.WrkChan[ChanNo];
		if ((*ppChanCfgInfo != NULL) && (*ppChanWrkInfo != NULL))
			retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
/// GetWrkChannelDetails()
///
/// Gets the channel range in the locally held configuration.
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] ChanSetupInfo - Channel protocol setup info
/// @param[out] pChanRangeInfo - Channel protocol range info
///
/// @return		TRUE if the range query is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::GetWrkChannelDetails(const UCHAR ChanNo, UCHAR *pChanSetupInfo, UCHAR *pChanRangeInfo) {
	BOOL retValue = FALSE;
	// Ensure channel is legal
	if (ChanNo < TOPSLOT_AICHAN_SIZE) {
		*pChanSetupInfo = m_Config.WrkChan[ChanNo].ChanSetup;
		*pChanRangeInfo = m_Config.WrkChan[ChanNo].RangeGain;
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
/// GetWrkSetupInfo()
///
/// Gets the channel range in the locally held configuration.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		Channel protocol setup info
//**********************************************************************
UCHAR CAIConfig::GetWrkSetupInfo(const UCHAR chanNo) const {
	return m_Config.WrkChan[chanNo].ChanSetup;
}
//**********************************************************************
/// GetWrkRangeInfo()
///
/// Gets the channel range in the locally held configuration.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		Channel protocol range info
//**********************************************************************
UCHAR CAIConfig::GetWrkRangeInfo(const UCHAR chanNo) const {
	return m_Config.WrkChan[chanNo].RangeGain;
}
//**********************************************************************
/// SetChannelRange()
///
/// Sets the channel type & range in the locally held configuration.
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[in] ChanType - Channel selected type (Linear	RT or TC)
/// @param[in] Range - Range 50V, 25V etc, TC or RT selection Info
///
/// @return		TRUE if the range selection is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::SetChannelRange(const USHORT ChanNo, const USHORT ChanType, const USHORT RangeEnum) {
	class CATECal *pATECal = NULL;
	BOOL ConfigChanged = TRUE;
	UCHAR RangeUnits;
	pATECal = CATECal::GetHandle();
	// Prevent config changes that are already committed from impacting on the system
	if ((m_Config.CfgChan[ChanNo].UserRange.RangeInfo.ChanType == ChanType)
			&& (m_Config.CfgChan[ChanNo].UserRange.RangeInfo.RangeEnum == RangeEnum)) {
		ConfigChanged = FALSE;
	}
	if (ConfigChanged == TRUE) {
		pATECal->SetCommitMode( TRUE);
		// Change the current channel configuration
		m_Config.CfgChan[ChanNo].UserRange.RangeInfo.ChanType = ChanType;
		m_Config.CfgChan[ChanNo].UserRange.RangeInfo.RangeEnum = RangeEnum;
		// Select the working range information from the user range selected
		m_pAIBrdRangesObj->GetRangeConfig(&m_Config.CfgChan[ChanNo].UserRange.RangeInfo, m_Config.RangeRevision,
				&m_Config.WrkChan[ChanNo].RangeGain, &RangeUnits);
	}
	/// Need to commit changes to the local configuration
	return ConfigChanged;
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Load the global configuration from the CMM and create the locally held one.
///
/// @return TRUE if successful created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CAIConfig::CMMCreateLocalConfig(void) {
	BOOL retValue = FALSE;
	retValue = CMMSlotLoad();
	if (FALSE != retValue) {
		// Calculate the current setup configuration CRC value and store
		CrcInsert(reinterpret_cast<UCHAR*>(&m_Config), sizeof(T_AIBOARDCONFIG));
		m_pBrdInfoObj->SetCalcConfigCRC(m_pIOCard->BoardSlotInstance(), m_Config.ConfigCRC);
	}
//	if(retValue != FALSE)
//		retValue = ConvertLocalConfig( );
	if (FALSE != retValue)
		retValue = IOCardLocalConfigCommit();
	return retValue;
}
//**********************************************************************
/// UploadConfig()
///
/// Uploads the local configuration to the board
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::UploadConfig(void) {
//	class CAICard *pAICard;
//	pAICard = (class CAICard *) m_pIOCard;
	// Loop for all channels producing downloadable config from CMM config
	for (UCHAR channel = 0; channel < TOPSLOT_AICHAN_SIZE; channel++) {
		if (m_Config.CfgChan[channel].ChanCfgInfo.Enabled == TRUE) {
			// Channel is enabled therefore needs range info loaded
			m_Config.WrkChan[channel].RangeGain;
			m_Config.WrkChan[channel].ChanSetup;
		} else {
			// Channel is currently disabled (or not present)
			m_Config.WrkChan[channel].RangeGain = 0;
			m_Config.WrkChan[channel].ChanSetup = 0;
		}
	}
	return TRUE;
}
//**********************************************************************
/// GetAIconfig()
///
/// Gets an instance of the local configuration
///
/// @return		Pointer to non-writable local AI configuration
//**********************************************************************
const T_AIBOARDCONFIG* CAIConfig::GetAIconfig(void) {
	return &m_Config;
}
//**********************************************************************
///
/// Converts CMM config enum into downloadable card channel enum
///
/// @param[in] acqRate - The systems enum.
///
/// @return		The boards acqusition enum
//**********************************************************************
USHORT CAIConfig::IOEnumConvert(const USHORT acqRate) const {
	switch (acqRate) {
	case AI_ACQ_RATE_2HZ:
		return ACQ_FREQ2;
	case AI_ACQ_RATE_5HZ:
		return ACQ_FREQ5;
	case AI_ACQ_RATE_10HZ:
		return ACQ_FREQ10;
	case AI_ACQ_RATE_50HZ:
		return ACQ_FREQ50;
	}
	return ACQ_FREQ2;
}
const UCHAR DEFAULT_LINEAR_RANGE = LINEAR_VOLTS_50V;
//**********************************************************************
/// CMMChannelTransfer()
///
/// Loads CMM config into card channel local downloadable configuration holder
///
/// @param[in] chanNo - The boards channel number.
/// @param[in] pAIChanCMMConfig - The AI CMM configuration from which to generate the channel.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::CMMChannelTransfer(const USHORT chanNo, const T_PAICHANNEL pAIChanCMMConfig) {
	BOOL retValue = TRUE;
#ifndef ATE_BUILD
	class CPenSetupConfig *pPenSetupConfig = NULL;
	class CAIRanges *pAIRange = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	T_AIRANGEDEF AIRange;
	T_PTCCHANITEM pTC = NULL;
	T_PRTCHANITEM pRT = NULL;
	T_PLINEARCHAN pLinear = NULL;
	USHORT sysChanNo = 0;
	USHORT CMMAIAcqRate;
	UCHAR RangeRev;
	float lowerRangeLimit = 0.0F;
	float upperRangeLimit = 0.0F;
	IO_MEASURE_UNITS Units;
	QString strErrorMsg;
	pBrdInfoObj = CBrdInfo::GetHandle();
	pAIRange = CAIRanges::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	pTC = &pAIChanCMMConfig->TC;
	pRT = &pAIChanCMMConfig->RT;
	pLinear = &pAIChanCMMConfig->Linear;
	pBrdInfoObj->GetBoardRangeRevision(m_pIOCard->BoardSlotInstance(), &RangeRev);
	// Automatically deselect active burnout, channel, fieldcal, raw readings and sqrt extract
	m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled = FALSE;
	m_Config.CfgChan[chanNo].ChanCfgInfo.RawReadings = 0;
	m_Config.CfgChan[chanNo].SqrtExtract = FALSE;
	TCConfigDefault(chanNo);
	m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled = static_cast<BOOL>(pAIChanCMMConfig->Enabled);
//	if( m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE )
//		SetBits( &m_chanEnabledMask, 1, chanNo, 1 );
	m_Config.CfgChan[chanNo].TiedTo = pAIChanCMMConfig->TiedTo;
	m_Config.CfgChan[chanNo].UserLinearisation = pAIChanCMMConfig->Linear.UserLinTable;
	m_Config.CfgChan[chanNo].DampLevel = pAIChanCMMConfig->DampLev;
//	m_Config.CfgChan[chanNo].ChanCfgInfo.acqEnum = static_cast<UCHAR> (pAIChanCMMConfig->AcqRate);
	pSETUP->GetIOSetupConfig()->QueryAIAcqRate(CONFIG_COMMITTED, m_pIOCard->BoardSlotInstance(), chanNo, &CMMAIAcqRate);
	m_Config.CfgChan[chanNo].ChanCfgInfo.acqEnum = static_cast<UCHAR>(CMMAIAcqRate);
	m_Config.CfgChan[chanNo].ChanCfgInfo.acqCardEnum = static_cast<UCHAR>(IOEnumConvert(
			m_Config.CfgChan[chanNo].ChanCfgInfo.acqEnum));
	m_Config.CfgChan[chanNo].ChanCfgInfo.acqRate =
			static_cast<UCHAR>(pSETUP->GetIOSetupConfig()->GetAIChannelRateFromConfiguration(
					m_Config.CfgChan[chanNo].ChanCfgInfo.acqEnum));
	// AI card currently reads all inputs as volts
	m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType = AI_CHANNEL_TYPE_LINEAR_VOLTS;
	m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum = 0;		///< Default the base range
	// Check that the configuration contains no user warnings - if so notify user
	if ((TRUE == m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled)
			&& (pBrdInfoObj->IsAIChannelLinear(pAIChanCMMConfig->Type) == TRUE)) {
		// Check user limits for problems, if linear channel
		if ( USE_USER_LIMITS == pAIChanCMMConfig->Linear.Mode) {
			if (pAIChanCMMConfig->Linear.UserHighLim == pAIChanCMMConfig->Linear.UserLowLim) {
				// Warn that the user limits are the same
				sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel(m_pIOCard->BoardSlotInstance(), chanNo, ONE_BASED);
				strErrorMsg = QString::asprintf(IDS_USER_HIGH_LOW_LIMITS_SAME, sysChanNo);
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg);
			}
		}
	}
	// Channel is enabled therefore needs setup converted
//	if( m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE )
	{
		if (pBrdInfoObj->IsAIChannelLinear(pAIChanCMMConfig->Type) == TRUE) {
			if ( USE_USER_LIMITS == pLinear->Mode) {
				m_Config.CfgChan[chanNo].UserRangeSelected = TRUE;
				// Keep a local record of the user entered sub-ranges
				m_Config.CfgChan[chanNo].userLowerSubRange = pAIChanCMMConfig->Linear.UserLowLim;
				m_Config.CfgChan[chanNo].userUpperSubRange = pAIChanCMMConfig->Linear.UserHighLim;
				if ((AI_CHANNEL_TYPE_LINEAR_VOLTS == pAIChanCMMConfig->Type)
						&& (pLinear->UserVoltUnits == vuMilliVolts)) {
					// User specified in milli-volts
					m_Config.CfgChan[chanNo].userSubRangeUnits = MILLI;
					m_Config.CfgChan[chanNo].UserRange.EngUnits = MILLI;
				} else if (AI_CHANNEL_TYPE_LINEAR_AMPS == pAIChanCMMConfig->Type) {
					// User specified in milli-volts
					m_Config.CfgChan[chanNo].userSubRangeUnits = MILLI;
					m_Config.CfgChan[chanNo].UserRange.EngUnits = MILLI;
				} else {
					// User specified in volts
					m_Config.CfgChan[chanNo].userSubRangeUnits = UNITS;
					m_Config.CfgChan[chanNo].UserRange.EngUnits = UNITS;
				}
				// The user has specified a self-ranging option
				if (pAIChanCMMConfig->Linear.UserLowLim < pAIChanCMMConfig->Linear.UserHighLim) {
					// The user has entered a conventional postive range
					upperRangeLimit = pAIChanCMMConfig->Linear.UserHighLim;
					lowerRangeLimit = pAIChanCMMConfig->Linear.UserLowLim;
				} else {
					// The user has entered a reverse range
					upperRangeLimit = pAIChanCMMConfig->Linear.UserLowLim;
					lowerRangeLimit = pAIChanCMMConfig->Linear.UserHighLim;
				}
				// If channel is a linear channel then user defined range can be set, if so then user & base range
				// must be set to the range that best meets the user requirements.
				m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType = pAIChanCMMConfig->Type;
				// Auto rescale small volts requests from volts to milli-volts
				if ((AI_CHANNEL_TYPE_LINEAR_VOLTS == pAIChanCMMConfig->Type) && (pLinear->UserVoltUnits == vuVolts)
						&& (upperRangeLimit <= 1.0) && (lowerRangeLimit >= -1.0)) {
					// User really wants milli-volts
					m_Config.CfgChan[chanNo].UserRange.EngUnits = MILLI;
					upperRangeLimit = upperRangeLimit * 1000.0F;
					lowerRangeLimit = lowerRangeLimit * 1000.0F;
				}
				// User specified in milli-volts
				m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum = m_pAIBrdRangesObj->GetRangeClosestMatch(
						RangeRev, static_cast<UCHAR>(m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType),
						upperRangeLimit, lowerRangeLimit, m_Config.CfgChan[chanNo].UserRange.EngUnits);
				if ((m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum == INVALID_RANGE)
						&& (m_Config.CfgChan[chanNo].UserRange.EngUnits == MILLI)) {
					// If the range is not found and we wanted millivolts then there will be a suitable voltage range available
					m_Config.CfgChan[chanNo].UserRange.EngUnits = UNITS;
					upperRangeLimit = upperRangeLimit / 1000.0F;
					lowerRangeLimit = lowerRangeLimit / 1000.0F;
					m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum = m_pAIBrdRangesObj->GetRangeClosestMatch(
							RangeRev, static_cast<UCHAR>(m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType),
							upperRangeLimit, lowerRangeLimit, m_Config.CfgChan[chanNo].UserRange.EngUnits);
				}
				if ( INVALID_RANGE == m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum) {
					// Big problems - autoranging has failed and the system will blow without a legal range
					// to allow engineering conversions, so set to default volts range
					m_Config.CfgChan[chanNo].UserRange.EngUnits = UNITS;
					m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum = DEFAULT_LINEAR_RANGE;
				}
			} else {
				m_Config.CfgChan[chanNo].UserRangeSelected = FALSE;
				// Copy CMM range configuration into local cfg copy (copy only is updated for calibration)
				m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType = pAIChanCMMConfig->Type;
				m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum = pLinear->RangePreset;
			}
			AIRange.RangeInfo.ChanType = m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType;
			AIRange.RangeInfo.RangeEnum = m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			T_AIRANGE AIRangeInfo;
			if (AI_CHANNEL_TYPE_LINEAR_AMPS == AIRange.RangeInfo.ChanType) {
				// If amps user range is selected then we need to use the amp limits
				AIRangeInfo.ChanType = AIRange.RangeInfo.ChanType;
				AIRangeInfo.RangeEnum = LINEAR_AMPS_0mA_20mA;
			} else {
				// Otherwise we can use the user selected range limits
				AIRangeInfo.ChanType = AIRange.RangeInfo.ChanType;
				AIRangeInfo.RangeEnum = AIRange.RangeInfo.RangeEnum;
			}
			// Get the main channel electrical limits
			pAIRange->GetChannelRange(&AIRange.RangeInfo, RangeRev, &(m_Config.CfgChan[chanNo].mcRangeAbsSpan),
					&(m_Config.CfgChan[chanNo].mcRangeAbsZero));
//			if( pAIRange->GetChannelCalPoints(&AIRange.RangeInfo, RangeRev, &(m_Config.CfgChan[chanNo].mcRangeNomSpan), &(m_Config.CfgChan[chanNo].mcRangeNomZero), &Units ) != NULL)
			if (pAIRange->GetChannelCalPoints(&AIRangeInfo, RangeRev, &(m_Config.CfgChan[chanNo].mcRangeNomSpan),
					&(m_Config.CfgChan[chanNo].mcRangeNomZero), &Units) != NULL) {
				// Set square root extract to correct state
				if (((AI_CHANNEL_TYPE_LINEAR_VOLTS == pAIChanCMMConfig->Type)
						|| (AI_CHANNEL_TYPE_LINEAR_AMPS == pAIChanCMMConfig->Type))
						&& (TRUE == pAIChanCMMConfig->SqrtExtract)) {
					// Only use sqrt extract option on voltage and current channels, no matter what the CMM instructs
					m_Config.CfgChan[chanNo].SqrtExtract = TRUE;
				}
				if (((pAIChanCMMConfig->Type == AI_CHANNEL_TYPE_LINEAR_VOLTS)
						|| (pAIChanCMMConfig->Type == AI_CHANNEL_TYPE_LINEAR_AMPS))
						&& (m_Config.CfgChan[chanNo].TiedTo == NO_TIED_TO_PEN)) {
					// If channel not tied to a pen scale we need to use channel engineering values
					m_Config.CfgChan[chanNo].mcEngZero = pAIChanCMMConfig->EngZero;
					m_Config.CfgChan[chanNo].mcEngSpan = pAIChanCMMConfig->EngSpan;
				} else {
					// If tied to a pen then use pen scales for engineering values
					pPenSetupConfig = pSETUP->GetPenSetupConfig();
					pPenSetupConfig->GetPenLimits(CONFIG_COMMITTED, m_Config.CfgChan[chanNo].TiedTo,
							&m_Config.CfgChan[chanNo].mcEngZero, &m_Config.CfgChan[chanNo].mcEngSpan);
				}
				// If user limits are set then these need to become the maximum range of the channel
				if (((pAIChanCMMConfig->Type == AI_CHANNEL_TYPE_LINEAR_VOLTS)
						|| (pAIChanCMMConfig->Type == AI_CHANNEL_TYPE_LINEAR_OHMS)
						|| (pAIChanCMMConfig->Type == AI_CHANNEL_TYPE_LINEAR_AMPS))
						&& (USE_USER_LIMITS == pLinear->Mode)) {
					// User sub-range selected; so use
					m_Config.CfgChan[chanNo].mcSubRangeZero = m_Config.CfgChan[chanNo].userLowerSubRange;
					m_Config.CfgChan[chanNo].mcSubRangeSpan = m_Config.CfgChan[chanNo].userUpperSubRange;
					// Need to scale the user subrange to match the chosen I/O board requirements
					if (AI_CHANNEL_TYPE_LINEAR_VOLTS == pAIChanCMMConfig->Type) {
						// Now rescale input units to match those required by selected base range
						pAIRange->ScaleToBaseRange(RangeRev, m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum,
								&(m_Config.CfgChan[chanNo].mcSubRangeZero), &(m_Config.CfgChan[chanNo].mcSubRangeSpan),
								m_Config.CfgChan[chanNo].userSubRangeUnits);
					}
				} else {
					// No user sub-range (or invalid range) is selected, so use full range
					if (AI_CHANNEL_TYPE_LINEAR_AMPS == pAIChanCMMConfig->Type) {
						// We need to automatically update the display sub-range if a preselected when one exists (mA measurement only)
						pAIRange->GetChannelDispRange(&AIRange.RangeInfo, RangeRev,
								&m_Config.CfgChan[chanNo].mcSubRangeSpan, &m_Config.CfgChan[chanNo].mcSubRangeZero);
					} else {
						// For all other types use the full range values
//						if( pAIRange->GetChannelRange(&AIRange.RangeInfo, RangeRev, &upperRangeLimit, &lowerRangeLimit) != NULL )
//						{
						// Copy the range limits
						m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum = pLinear->RangePreset;
						m_Config.CfgChan[chanNo].mcSubRangeZero = m_Config.CfgChan[chanNo].mcRangeNomZero;
						m_Config.CfgChan[chanNo].mcSubRangeSpan = m_Config.CfgChan[chanNo].mcRangeNomSpan;
//						}
					}
				}
			}
			if (AI_CHANNEL_TYPE_LINEAR_VOLTS == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType) {
				// If user range is a base range, then base range is the same as the user range
				m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum =
						m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			}
		} else if (AI_CHANNEL_TYPE_RT == pAIChanCMMConfig->Type) {
			/// Copy RT selection data
			m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType = pAIChanCMMConfig->Type;
			m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum = pRT->SelectedRT;
		} else if (AI_CHANNEL_TYPE_TC == pAIChanCMMConfig->Type) {
			/// Copy TC selection & option data
			m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType = pAIChanCMMConfig->Type;
			m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum = pTC->SelectedTC;
			m_Config.CfgChan[chanNo].TCCfg.BurnOutSelect = pTC->BurnOutSelect;
			m_Config.CfgChan[chanNo].TCCfg.ActiveBurnout = pTC->ActiveBurnout;
			m_Config.CfgChan[chanNo].TCCfg.CJCompMethod = pTC->CJCompMethod;
			m_Config.CfgChan[chanNo].TCCfg.UpScaleBurnOut = pTC->UpScaleBurnOut;
			m_Config.CfgChan[chanNo].TCCfg.ExtSpecifiedCJ = pTC->ExtSpecifiedCJ;
			m_Config.CfgChan[chanNo].TCCfg.CJCompAI = pTC->CJCompAI;
		} else {
			// Illegal channel type found
			LogInternalError("CMMChannelTransfer - Illegal channel type found");
			retValue = FALSE;
		}
		if (QueryIOBoardChanRangeCalInfo(chanNo) == CInputConditioning::V6_IO_USER_CALIBRATION) {
			m_Config.CfgChan[chanNo].FieldCal = 1;
		} else {
			m_Config.CfgChan[chanNo].FieldCal = 0;
		}
	}
#endif
	return retValue;
}
const UCHAR DEFAULT_RT_RANGE = LINEAR_VOLTS_100mV;
const UCHAR DEFAULT_TC_RANGE = LINEAR_VOLTS_100mV;
#define AI_CONFIG_ENABLED_BIT		0
#define AI_CONFIG_RAW_READINGS_BIT	1
#define AI_CONFIG_ACQ_SPEED_BIT		2
#define AI_CONFIG_FIELD_CAL_BIT		5
#define AI_CONFIG_ACT_BRONOUT_BIT	6
#define SET_1_BIT		1
#define SET_2_BITS		2
#define SET_3_BITS		3
//**********************************************************************
///
/// Converts CMM config into card channel local downloadable configuration holder
///
/// @return	 	 TRUE if the commit is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::IOCardLocalConfigCommit(void) {
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  QString  strLogMessage;
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - begin GTC:%d\r\n", GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	class CPPIOServiceManager *pServiceManager = NULL;		///< Service manager
	class CPenSetupConfig *pPenSetupConfig = NULL;
	class CInputConditioning *pInpConditioning = NULL;
	class CDeviceManager *pDevManager = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;
	T_PDEVICETABLEHDR pDeviceHdr = NULL;
	USHORT forBitManipulation = 0;
	USHORT chanNo;
	T_RANGE_COUNTS Intern0;
	T_RANGE_COUNTS Intern0V;
	T_RANGE_COUNTS Intern100;
	T_RANGE UpperRange;
	T_RANGE LowerRange;
	float engZero;
	float engSpan;
	float factor = 1.0F;
	BOOL baseRangeFound = FALSE;
	T_AIRANGEDEF locRange;
	BOOL retValue = TRUE;
	pServiceManager = CPPIOServiceManager::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if ((pServiceManager != NULL) && (pBrdInfoObj != NULL))
		pInpConditioning = pServiceManager->GetICService();
	else
		retValue = FALSE;
	if (pInpConditioning != NULL)
		pDevManager = pInpConditioning->GetDeviceManager();
	else
		retValue = FALSE;
	/// Get board range configuration issue
	pBrdInfoObj->GetBoardRangeRevision(m_pIOCard->BoardSlotInstance(), &m_Config.RangeRevision);
	m_Config.RawMode = FALSE;
	m_chanEnabledMask = 0;
	for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
		baseRangeFound = FALSE;
		forBitManipulation = 0;
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d forBitManipulation %d begin GTC:%d\r\n", chanNo, forBitManipulation, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
		// Channel enabled?
		SetBits(&forBitManipulation, m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled, AI_CONFIG_ENABLED_BIT, SET_1_BIT);
		if (m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE)
			SetBits(&m_chanEnabledMask, 1, chanNo, 1);
		// Currently input linearisation is specified in input units of mV, V, mA and ohms,
		// rather than engineering units.
		m_Config.CfgChan[chanNo].InputLinearisation = TRUE;
		// Set acqusition speed, active burnout status, raw and field cal selection
		SetBits(&forBitManipulation, m_Config.CfgChan[chanNo].ChanCfgInfo.acqCardEnum, AI_CONFIG_ACQ_SPEED_BIT,
				SET_3_BITS);
		SetBits(&forBitManipulation, m_Config.CfgChan[chanNo].FieldCal, AI_CONFIG_FIELD_CAL_BIT, SET_1_BIT);
		SetBits(&forBitManipulation, m_Config.CfgChan[chanNo].ChanCfgInfo.RawReadings, AI_CONFIG_RAW_READINGS_BIT,
				SET_1_BIT);
		m_Config.RawMode = static_cast<BOOL>(m_Config.CfgChan[chanNo].ChanCfgInfo.RawReadings);
		if ( TRUE == m_Config.CfgChan[chanNo].TCCfg.ActiveBurnout) {
			SetBits(&forBitManipulation, DEFAULT_ACTIVE_BURNOUT_TYPE, AI_CONFIG_ACT_BRONOUT_BIT, SET_2_BITS);
		}
		m_Config.WrkChan[chanNo].ChanSetup = static_cast<UCHAR>(forBitManipulation);
		if ((AI_CHANNEL_TYPE_LINEAR_AMPS == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType)
				|| (AI_CHANNEL_TYPE_LINEAR_OHMS == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType)
				|| (AI_CHANNEL_TYPE_RT == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType)) {
			m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType = AI_CHANNEL_TYPE_LINEAR_VOLTS;
			if (AI_CHANNEL_TYPE_RT == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType) {
				if (pDevManager != NULL) {
					pDeviceHdr = pDevManager->GetRTSensorDeviceHdr(
							m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum);
					if ( NULL != pDeviceHdr) {
						// Load the engineering units, with device limits
						m_Config.CfgChan[chanNo].mcEngZero = pSYSTEM_INFO->GetLocalTempFromDegC(pDeviceHdr->OPRangeLow);
						m_Config.CfgChan[chanNo].mcEngSpan = pSYSTEM_INFO->GetLocalTempFromDegC(
								pDeviceHdr->OPRangeHigh);
						m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType = AI_CHANNEL_TYPE_LINEAR_VOLTS;
						// For certain devices may need to take into account the maximum lead resistance which is
						// likely to occur, before finding the most approriate range to use.
						// indexOf the most approriate base range to use for RT required ohms range
						m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum =
								m_pAIBrdRangesObj->GetRangeClosestMatch(m_Config.RangeRevision,
										AI_CHANNEL_TYPE_LINEAR_OHMS, pDeviceHdr->IPRangeHigh, pDeviceHdr->IPRangeLow,
										pDeviceHdr->IPRangeUnits);
						// Check for no legal base range found
						if ( INVALID_RANGE != m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum) {
							m_pAIBrdRangesObj->GetBaseChannelRange(
									m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum, m_Config.RangeRevision,
									&UpperRange, &LowerRange, &m_Config.CfgChan[chanNo].BaseRange.EngUnits);
							baseRangeFound = TRUE;
						}
					}
				}
			} else {
				locRange.RangeInfo.ChanType = m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType;
				locRange.RangeInfo.RangeEnum = m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
				locRange.EngUnits = m_Config.CfgChan[chanNo].UserRange.EngUnits;
				if ( TRUE == m_Config.CfgChan[chanNo].UserRangeSelected) {
					// Correct base range already found, so use
					m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum =
							m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
				} else {
					// Need to find the base range to use from the user selection
					m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum = m_pAIBrdRangesObj->GetBaseChannelRange(
							&locRange.RangeInfo, m_Config.RangeRevision);
				}
				if ( INVALID_RANGE != m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum) {
					m_pAIBrdRangesObj->GetBaseChannelRange(m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum,
							m_Config.RangeRevision, &UpperRange, &LowerRange,
							&m_Config.CfgChan[chanNo].BaseRange.EngUnits);
					baseRangeFound = TRUE;
				}
			}
			if ( FALSE == baseRangeFound) {
				// Using default range so that recorder does not blow away
				m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType = AI_CHANNEL_TYPE_LINEAR_VOLTS;
				m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum = DEFAULT_RT_RANGE;
				m_Config.CfgChan[chanNo].BaseRange.EngUnits = MILLI;
			}
		} else if (AI_CHANNEL_TYPE_TC == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType) {
			// indexOf the required range from TC devices
			if (pDevManager != NULL) {
				// Get info for selected TC
				pDeviceHdr = pDevManager->GetTCSensorDeviceHdr(m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum);
				if ( NULL != pDeviceHdr) {
					// indexOf the most approriate base range to use for device
					m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType = AI_CHANNEL_TYPE_LINEAR_VOLTS;
					m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum = m_pAIBrdRangesObj->GetRangeClosestMatch(
							m_Config.RangeRevision,
							static_cast<UCHAR>(m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType),
							pDeviceHdr->IPRangeHigh, pDeviceHdr->IPRangeLow, pDeviceHdr->IPRangeUnits);
					// Load the engineering units, with the device limits
					m_Config.CfgChan[chanNo].mcEngZero = pSYSTEM_INFO->GetLocalTempFromDegC(pDeviceHdr->OPRangeLow);
					m_Config.CfgChan[chanNo].mcEngSpan = pSYSTEM_INFO->GetLocalTempFromDegC(pDeviceHdr->OPRangeHigh);
					// Check for no legal base range found
					if ( INVALID_RANGE != m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum) {
						m_pAIBrdRangesObj->GetBaseChannelRange(m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum,
								m_Config.RangeRevision, &UpperRange, &LowerRange,
								&m_Config.CfgChan[chanNo].BaseRange.EngUnits);
						baseRangeFound = TRUE;
					}
				} else
					retValue = FALSE;
			} else
				retValue = FALSE;
			if ( FALSE == baseRangeFound) {
				// Using default range so that recorder does not blow away
				m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType = AI_CHANNEL_TYPE_LINEAR_VOLTS;
				m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum = DEFAULT_TC_RANGE;
				m_Config.CfgChan[chanNo].BaseRange.EngUnits = MILLI;
				retValue = FALSE;
			}
		} else {
			// Base range is the same as the user range
			m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType =
					m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType;
			m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum =
					m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			m_Config.CfgChan[chanNo].BaseRange.EngUnits = m_Config.CfgChan[chanNo].UserRange.EngUnits;
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d ChanType %d RangeEnum %d EngUnits %d GTC:%d\r\n", chanNo, m_Config.CfgChan[chanNo].BaseRange.RangeInfo.ChanType, m_Config.CfgChan[chanNo].BaseRange.RangeInfo.RangeEnum, m_Config.CfgChan[chanNo].BaseRange.EngUnits, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
		}
		// We now have a valid base range, so define all the required engineering zero and span points for this channel
		m_pAIBrdRangesObj->GetInternValues(&m_Config.CfgChan[chanNo].BaseRange.RangeInfo, m_Config.RangeRevision,
				&Intern0, &Intern0V, &Intern100);
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - GetInternValues - ChanNo %d Intern0 %d Intern0V %d Intern100 %d GTC:%d\r\n", chanNo, Intern0, Intern0V, Intern100, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
		m_pAIBrdRangesObj->GetRangeConfig(&m_Config.CfgChan[chanNo].BaseRange.RangeInfo, m_Config.RangeRevision,
				&m_Config.WrkChan[chanNo].RangeGain, &m_Config.WrkChan[chanNo].RangeUnits);
		m_Config.CfgChan[chanNo].mcElecRangeZero = static_cast<float>(Intern0);
		m_Config.CfgChan[chanNo].mcElecRangeSpan = static_cast<float>(Intern100);
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d mcElecRangeZero %f mcElecRangeSpan %f GTC:%d\r\n", chanNo, m_Config.CfgChan[chanNo].mcElecRangeZero, m_Config.CfgChan[chanNo].mcElecRangeSpan, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d mcRangeNomZero %f mcRangeNomSpan %f GTC:%d\r\n", chanNo, m_Config.CfgChan[chanNo].mcRangeNomZero, m_Config.CfgChan[chanNo].mcRangeNomSpan, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d mcEngZero %f mcEngSpan %f GTC:%d\r\n", chanNo, m_Config.CfgChan[chanNo].mcEngZero, m_Config.CfgChan[chanNo].mcEngSpan, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d mcRangeAbsZero %f mcRangeAbsSpan %f GTC:%d\r\n", chanNo, m_Config.CfgChan[chanNo].mcRangeAbsZero, m_Config.CfgChan[chanNo].mcRangeAbsSpan, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d mcSubRangeZero %f mcSubRangeSpan %f GTC:%d\r\n", chanNo, m_Config.CfgChan[chanNo].mcSubRangeZero, m_Config.CfgChan[chanNo].mcSubRangeSpan, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
		factor = (m_Config.CfgChan[chanNo].mcElecRangeSpan - m_Config.CfgChan[chanNo].mcElecRangeZero)
				/ (m_Config.CfgChan[chanNo].mcRangeNomSpan - m_Config.CfgChan[chanNo].mcRangeNomZero);
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d factor %f GTC:%d\r\n", chanNo, factor, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
		// Now scale the values if only a proportion of the of the input range is being used
		if (m_Config.CfgChan[chanNo].mcSubRangeSpan != m_Config.CfgChan[chanNo].mcRangeNomSpan) {
			m_Config.CfgChan[chanNo].mcElecRangeSpan = m_Config.CfgChan[chanNo].mcElecRangeZero
					+ ((fabs(m_Config.CfgChan[chanNo].mcRangeNomZero) + m_Config.CfgChan[chanNo].mcSubRangeSpan)
							* factor);
		}
		if (m_Config.CfgChan[chanNo].mcSubRangeZero != m_Config.CfgChan[chanNo].mcRangeNomZero) {
			m_Config.CfgChan[chanNo].mcElecRangeZero = m_Config.CfgChan[chanNo].mcElecRangeZero
					+ ((fabs(m_Config.CfgChan[chanNo].mcRangeNomZero) + m_Config.CfgChan[chanNo].mcSubRangeZero)
							* factor);
		}
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::IOCardLocalConfigCommit - ChanNo %d mcElecRangeZero %f mcElecRangeSpan %f GTC:%d\r\n", chanNo, m_Config.CfgChan[chanNo].mcElecRangeZero, m_Config.CfgChan[chanNo].mcElecRangeSpan, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
		if ((AI_CHANNEL_TYPE_LINEAR_OHMS == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType)
				|| (AI_CHANNEL_TYPE_RT == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType)) {
			// If high current is required then set high current select; otherwise deselect
			if ((AI_CHANNEL_TYPE_RT == m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType)
					&& (AI_RT_RANGE_CU10 == m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum)) {
				m_Config.WrkChan[chanNo].highSource = TRUE;
			} else {
				m_Config.WrkChan[chanNo].highSource = FALSE;
			}
			forBitManipulation = m_Config.WrkChan[chanNo].RangeGain;
			SetBits(&forBitManipulation, m_Config.WrkChan[chanNo].highSource, 7, 1);
			SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
			m_Config.WrkChan[chanNo].RangeGain = static_cast<UCHAR>(forBitManipulation);
		}
		// Log the ranges with the dual point calibration information
		if (QuerySlotEngValues(chanNo, &engZero, &engSpan) == TRUE) {
			if (pInpConditioning != NULL) {
				pInpConditioning->IOBoardRangeCalCommit(m_pIOCard->BoardSlotInstance(), chanNo, engZero, engSpan);
			}
		}
		pBrdInfoObj->SetIOCardChannelSelection(m_pIOCard->BoardSlotInstance(), chanNo,
				m_Config.CfgChan[chanNo].BaseRange.RangeInfo);
#if defined ( DBG_FILE_LOG_AI_CFG_DBG_ENABLE )
  strLogMessage = QString::asprintf("CAIConfig::RangeInitialise - ChanNo %d end GTC:%d\r\n", chanNo, GetTickCount() );
  m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
  #endif
	}
	// Calculate the current setup configuration CRC value and store
	CrcInsert(reinterpret_cast<UCHAR*>(&m_Config), sizeof(T_AIBOARDCONFIG));
	m_pBrdInfoObj->SetCalcConfigCRC(m_pIOCard->BoardSlotInstance(), m_Config.ConfigCRC);
	if (TRUE == retValue) {
		static_cast<CAICard*>(m_pIOCard)->GenerateChannelStartupList();
//		if( static_cast<CAICard *> (m_pIOCard)->GenerateChannelStartupList() == FALSE )
//			retValue = FALSE;
	}
	// If successful place the I/O card into run mode
	if (TRUE == retValue)
		m_pIOCard->ScheduleIOBoardRunMode(TRUE);
	return retValue;
}
//**********************************************************************
/// QueryHighConstantCurrent()
///
/// Queries whether the high current constant current source is selected for a given channel
///
/// @param[in] chanNo - Card slot channel number.
///
/// @return	 	 TRUE if high current mode is selected; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::QueryHighConstantCurrent(const USHORT chanNo) const {
	return m_Config.WrkChan[chanNo].highSource;
}
//**********************************************************************
/// SetAICalibPair()
///
/// Places the configuration into special calibration mode
/// Sets the channel type & range directly in the working copys.
/// @note: (configuration is invalid for normal correct board operation)
///
/// @param[in] chanNo - Card slot channel number.
/// @param[in] DirectMode - Type of direct reading to take
///
/// @return	 	 TRUE if the range selection is successful; otherwise FALSE
/// @note	 	 Use of this routine must be limited to use on the test equipment
//**********************************************************************
BOOL CAIConfig::SetAICalibPair(const USHORT chanNo, const UCHAR mode) {
	USHORT forBitManipulation = 0;
	forBitManipulation = m_Config.WrkChan[chanNo].RangeGain;
	SetBits(&forBitManipulation, mode, 4, 2);
	m_Config.WrkChan[chanNo].RangeGain = static_cast<UCHAR>(forBitManipulation);
	return TRUE;
}
//**********************************************************************
///
/// Converts calibration structure config into card channel local downloadable
/// configuration holder, for all channels
///
/// @return	 	 TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::TCConfigDefault(const USHORT chanNo) {
	m_Config.CfgChan[chanNo].TCCfg.BurnOutSelect = TRUE;
	m_Config.CfgChan[chanNo].TCCfg.ActiveBurnout = FALSE;
	m_Config.CfgChan[chanNo].TCCfg.CJCompMethod = AIN_CJC_INTERNAL_AUTO;
	m_Config.CfgChan[chanNo].TCCfg.UpScaleBurnOut = TRUE;
	return TRUE;
}
//**********************************************************************
///
/// Converts calibration structure config into card channel local downloadable
/// configuration holder, for all channels
///
/// @param[in] pCalStruct - The calibration structure with details of the mode required.
///
/// @return	 	 TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::CalStructTransfer(const class CATECal *pCalStruct) {
	class CAIRanges *pAIRange = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	T_AIRANGEDEF AIRange;
	T_RANGE_DEVICE_TYPE DeviceType;
	UCHAR DeviceSubType;
	USHORT chanNo = 0;
	USHORT Intern0 = 0;
	USHORT Intern0V = 0;
	USHORT Intern100 = 0;
	UCHAR RangeRev;
	float lowerRangeLimit = 0.0F;
	float upperRangeLimit = 0.0F;
	pBrdInfoObj = CBrdInfo::GetHandle();
	pAIRange = CAIRanges::GetHandle();
	if (CM_ATE_FACTORY_CAL == pCalStruct->m_calMode)
		m_Config.Calibration = V6_AI_FACTORY_CAL;
	else if (CM_ATE_USER_CAL == pCalStruct->m_calMode)
		m_Config.Calibration = V6_AI_USER_CAL;
	else
		m_Config.Calibration = V6_AI_NO_CAL;
	m_Config.RawMode = FALSE;
	for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
		// Automatically deselect active burnout, channel, fieldcal, raw readings, sqrt extract,
		// user linearisation and input damping
		m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled =
				static_cast<BOOL>(pCalStruct->m_cfgAI.CfgChan[chanNo].ChanCfgInfo.Enabled);
//		if( m_Config.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE )
//			SetBits( &m_chanEnabledMask, 1, chanNo, 1 );
		m_Config.CfgChan[chanNo].FieldCal = 0;
		m_Config.CfgChan[chanNo].ChanCfgInfo.RawReadings =
				static_cast<BOOL>(pCalStruct->m_cfgAI.CfgChan[chanNo].ChanCfgInfo.RawReadings);
		// Remove Sqrt extrac, user linearisation and input damping
		m_Config.CfgChan[chanNo].SqrtExtract = FALSE;
		m_Config.CfgChan[chanNo].UserLinearisation = NO_CHAN_LINEARISATION;
		m_Config.CfgChan[chanNo].DampLevel = 0.0F;
		// If any raw readings set; then whole card takes this state
		m_Config.RawMode = static_cast<BOOL>(m_Config.CfgChan[chanNo].ChanCfgInfo.RawReadings);
		// Default thermocouples
		TCConfigDefault(chanNo);
		m_Config.CfgChan[chanNo].ChanCfgInfo.acqEnum =
				static_cast<UCHAR>(pCalStruct->m_cfgAI.CfgChan[chanNo].ChanCfgInfo.acqRate);
		m_Config.CfgChan[chanNo].ChanCfgInfo.acqCardEnum = static_cast<UCHAR>(IOEnumConvert(
				m_Config.CfgChan[chanNo].ChanCfgInfo.acqEnum));
		m_Config.CfgChan[chanNo].ChanCfgInfo.acqRate =
				static_cast<UCHAR>(pSETUP->GetIOSetupConfig()->GetAIChannelRateFromConfiguration(
						m_Config.CfgChan[chanNo].ChanCfgInfo.acqEnum));
		// Get the main channel electrical limits
		pBrdInfoObj->GetBoardRangeRevision(m_pIOCard->BoardSlotInstance(), &RangeRev);
		if (pAIRange->GetChannelRange(&AIRange.RangeInfo, RangeRev, &(m_Config.CfgChan[chanNo].mcRangeNomSpan),
				&(m_Config.CfgChan[chanNo].mcRangeNomZero)) != NULL) {
			m_Config.CfgChan[chanNo].mcSubRangeZero = m_Config.CfgChan[chanNo].mcRangeNomZero;
			m_Config.CfgChan[chanNo].mcSubRangeSpan = m_Config.CfgChan[chanNo].mcRangeNomSpan;
		}
		if (pAIRange->GetChannelDevice(&AIRange.RangeInfo, RangeRev, &DeviceType, &DeviceSubType) != NULL) {
			if (SHUNT_RESITOR_DEVICE == DeviceType) {
				// @todo: Load approriate shunt resistor value
//				m_Config.CfgChan[chanNo].shuntValue = DeviceSubType;
			}
		}
		if ((pBrdInfoObj->IsAIChannelLinear(pCalStruct->m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.ChanType) == TRUE)
				|| (AI_CHANNEL_TYPE_RT == pCalStruct->m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.ChanType)
				|| (AI_CHANNEL_TYPE_TC == pCalStruct->m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.ChanType)) {
			m_Config.CfgChan[chanNo].UserRange.RangeInfo.ChanType =
					pCalStruct->m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.ChanType;
			m_Config.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum =
					pCalStruct->m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.RangeEnum;
			if (AI_CHANNEL_TYPE_TC == pCalStruct->m_cfgAI.CfgChan[chanNo].UserRange.RangeInfo.ChanType) {
				m_Config.CfgChan[chanNo].TCCfg.BurnOutSelect = pCalStruct->m_cfgAI.CfgChan[chanNo].TCCfg.BurnOutSelect;
				m_Config.CfgChan[chanNo].TCCfg.ActiveBurnout = pCalStruct->m_cfgAI.CfgChan[chanNo].TCCfg.ActiveBurnout;
				m_Config.CfgChan[chanNo].TCCfg.CJCompMethod = pCalStruct->m_cfgAI.CfgChan[chanNo].TCCfg.CJCompMethod;
				m_Config.CfgChan[chanNo].TCCfg.UpScaleBurnOut =
						pCalStruct->m_cfgAI.CfgChan[chanNo].TCCfg.UpScaleBurnOut;
				m_Config.CfgChan[chanNo].TCCfg.ExtSpecifiedCJ =
						pCalStruct->m_cfgAI.CfgChan[chanNo].TCCfg.ExtSpecifiedCJ;
			}
		}
	}
	return TRUE;
}
//**********************************************************************
///
/// Loads calibration structure config into card channel local downloadable
/// configuration holder, for all channels
///
/// @param[in] pCalStruct - The calibration structure with details of the mode required.
///
/// @return	 	 TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CAIConfig::CalStructDirectTransfer(const class CATECal *pCalStruct) {
	USHORT chanNo = 0;
	for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
		m_Config.WrkChan[chanNo].ChanSetup = pCalStruct->m_cfgAI.WrkChan[chanNo].ChanSetup;
		m_Config.WrkChan[chanNo].RangeGain = pCalStruct->m_cfgAI.WrkChan[chanNo].RangeGain;
	}
	return TRUE;
}
//******************************************************
//  SelectAIChanRawMode()
///
/// Sets the local configuration whether the readings are in raw mode or not.
/// @param[in] ChannelNo - The system channel number.
/// @param[in] rawModeOn - TRUE if the channel is aquiring in raw mode; otherwise FALSE.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::SelectAIChanRawMode(const USHORT ChannelNo, const BOOL rawModeOn) {
	BOOL retValue = TRUE;
	// Make AI board channel configured for acquiring at the specified rate
	m_Config.CfgChan[ChannelNo].ChanCfgInfo.RawReadings = rawModeOn;
	return retValue;
}
//******************************************************
//  SelectAcqRate()
///
/// Sets the current channel acqsistion rate for any input channel on any card in the local configuration.
/// @param[in] ChannelNo - The system channel number.
/// @param[in] Rate - The acquisition rate of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::SelectAIChanAcqRate(const USHORT ChannelNo, const USHORT Rate) {
	BOOL retValue = TRUE;
	// Make AI board channel configured for acquiring at the specified rate
	m_Config.CfgChan[ChannelNo].ChanCfgInfo.acqRate = static_cast<UCHAR>(Rate);
	return retValue;
}
//******************************************************
//  SelectVoltageRange()
///
/// Sets the current channel range for any voltage channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The voltage range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::SelectAIChanVoltageRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_LINEAR_VOLTS, Range);
}
//******************************************************
//  SelectCurrentRange()
///
/// Sets the current channel range for any current channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The current range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::SelectAIChanCurrentRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_LINEAR_AMPS, Range);
}
//******************************************************
//  SelectResistanceRange()
///
/// Sets the current channel range for any resistance channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The rsistance range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::SelectAIChanResistanceRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_LINEAR_OHMS, Range);
}
//******************************************************
//  SelectTCRange()
///
/// Sets the current channel range for any voltage channel on any card in the local configuration.
/// @param[in] sysChannelNo - The TC channel number.
/// @param[in] Range - The TC range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::SelectAIChanTCRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_TC, Range);
}
//******************************************************
//  SelectRTRange()
///
/// Sets the current channel range for any RT channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The RT range of the channel.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::SelectAIChanRTRange(const USHORT ChannelNo, const USHORT Range) {
	return SetChannelRange(ChannelNo, AI_CHANNEL_TYPE_RT, Range);
}
//******************************************************
//  SetUploadedVersion()
///
/// Uploaded configuration only - Sets the configuration version number.
/// @param[in] version - The configuaration version info.
///
/// @return TRUE if the given range could be selected; otherwise FALSE
///
//******************************************************
void CAIConfig::SetUploadedVersion(const USHORT version) {
	m_Config.CfgVersion = version;
}
//******************************************************
//  SetUploadedCfg()
///
/// Uploaded configuration only - Sets a board channels range and setup info.
/// @param[in] chanNo - The board channel number.
/// @param[in] setupInfo - The range setup info of the channel.
/// @param[in] rangeInfo - The range info of the channel.
///
//******************************************************
void CAIConfig::SetUploadedCfg(const UCHAR chanNo, const UCHAR setupInfo, const UCHAR rangeInfo) {
	m_Config.UploadedCfg[chanNo].ChanSetup = setupInfo;
	m_Config.UploadedCfg[chanNo].RangeGain = rangeInfo;
}
//******************************************************
//  CompareUploadedDownloadedCfg()
///
/// Compares a board channels range and setup info from donloaded and uploaded configurations.
/// @param[in] chanNo - The board channel number.
///
/// @return TRUE if the range matches; otherwise FALSE
///
//******************************************************
BOOL CAIConfig::CompareUploadedDownloadedCfg(const UCHAR chanNo) {
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	BOOL retValue = TRUE;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj == NULL)
		retValue = FALSE;
	if ((retValue != FALSE) && (chanNo < pBrdInfoObj->GetNoOfChannels(m_pIOCard->BoardSlotInstance()))) {
		if (m_Config.UploadedCfg[chanNo].ChanSetup != m_Config.WrkChan[chanNo].ChanSetup)
			retValue = FALSE;
		if (m_Config.UploadedCfg[chanNo].RangeGain != m_Config.WrkChan[chanNo].RangeGain)
			retValue = FALSE;
	}
	return retValue;
}

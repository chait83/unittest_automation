//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AIRanges.h
/// @n interface for the AI card range class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 41	Stability Project 1.38.1.1	7/2/2011 4:55:17 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 40	Stability Project 1.38.1.0	7/1/2011 4:27:11 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 39	V6 Firmware 1.38		2/7/2007 6:18:10 PM	Graham Waterfield
//		Debugging code to investigate illegal SPI device
// 38	V6 Firmware 1.37		1/19/2007 8:26:07 PM	Graham Waterfield
//		Use range display units rather than hardware units
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _AIRANGES_H
#define _AIRANGES_H
#if !defined(AFX_AIRANGES_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_AIRANGES_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#include "PassiveModule.h"
#include "V6defines.h"
#include <QMutex>
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define INVALID_RANGE			0xFF	///< Invalid channel range
#define RAW_VALUES_MID_POINT		32768
#define RAW_VALUES_MID_POINT_FLOAT	32768.0F
#define ISSA_RAW_VALUES_MID_POINT		32768
#define ISSA_RAW_VALUES_MID_POINT_FLOAT	32768.0F
#define T_RANGE		float		///< Range type
////PSR TV new AI card (V7AI) range counts type definition begin ///////////
#define T_RANGE_COUNTS	unsigned long //Ensure to have 4 bytes to accommodate 24bit counts with spare
////PSR TV new AI card (V7AI) range counts type definition end ///////////
// Issue revision of board with different range capabilities
#define V6AI_ISSUE_0		0		///< Pre-release ranges (Beta models)
#define V6AI_ISSUE_1		1		///< 1st release production ranges
#define V6AI_ISSUE_2		2		///< 2nd release production ranges (This rev has No Change in AIRanges)
#define V7AI_ISSUE_0		4		/// V7AI (New AI) Card starts with rev 4 - 16Bit ADC compatible
#define V7AI_ISSUE_A		'A'		/// V7AI (New AI) Card starts with rev 5 - 24Bit ADC
// Channel devices to provide extended ranges
#define SHUNT_RESISTOR_100		0		///< 100 ohm shunt resistor (for current measurement)
#define SHUNT_RESISTOR_10		1		///< 10 ohm shunt resistor (for current measurement)
const float DEFAULT_CONSTANT_CURRENT_LOW_MA = 0.25F;
const float DEFAULT_CONSTANT_CURRENT_HIGH_MA = 1.39F;
const float DEFAULT_CONSTANT_CURRENT_LOW_A = (DEFAULT_CONSTANT_CURRENT_LOW_MA / 1000);
const float DEFAULT_CONSTANT_CURRENT_HIGH_A = (DEFAULT_CONSTANT_CURRENT_HIGH_MA / 1000);
// Types of ranges that are defined
typedef enum {
	RS_BASE_RANGE,				///< Base range as understood by card
	RS_EXTENDED_RANGE,			///< Extended range
	RS_VIRTUAL_BASE_RANGE,		///< A virtual base range
	RS_VIRTUAL_EXTENDED_RANGE	///< A virtual extended range
} T_RANGE_SELECTION;
// Types of devices that support ranges
typedef enum rangedevicetype {
	CONSTANT_CURRENT_DEVICE, SHUNT_RESITOR_DEVICE
} T_RANGE_DEVICE_TYPE;
// Values of shount resistors available
typedef enum shunttype {
	SHUNT_RESITOR_100_OHM = 0,			///< 100 ohm resitor
	SHUNT_RESITOR_10_OHM = 1,			///< 10 ohm resitor
	SHUNT_RESITOR_250_OHM = 2			///< 250 ohm resitor
} T_SHUNT_TYPE;
// List of current sources available on board
typedef enum constcurrenttype {
	CONSTANT_CURRENT_0_25MA = 3,	///< 0.25mA nominal constant current source
	CONSTANT_CURRENT_1_39MA = 4		///< 1.39mA nominal constant current source
} CONSTANT_CURRENT_TYPE;
// Range definition
typedef struct AIRange_t {
	USHORT ChanType;	///< Channel selected type (Volts, amps, ohms, RT or TC)
	USHORT RangeEnum;	///< Range 50V, 25V etc or TC / RT type selection Info
} T_AIRANGE, *T_PAIRANGE;
// Range definition
typedef struct AIRangeDef_t {
	T_AIRANGE RangeInfo;	///< Channel selected type & range (Volts 50V, 25V, amps, ohms, RT or TC)
	IO_MEASURE_UNITS EngUnits;		///< unit, milli, micro or nano (if linear)
} T_AIRANGEDEF, *T_PAIRANGEDEF;
// Structure to define the base range
typedef struct _basechannelrange {
	USHORT BoardVer;			///< Board version range supported on
	T_AIRANGEDEF RangeInfo;			///< Range Info
	UCHAR RangeGain;			///< Range selection/gain info
	IO_MEASURE_UNITS HWRangeUnits;		///< Hardware Range units
	IO_MEASURE_UNITS RangeUnits;			///< Range units
	T_RANGE LowerRange;			///< Range lower limit (absolute minimum)
	T_RANGE UpperRange;			///< Range upper limit (absolute maximum)
	T_RANGE LowerCal;			///< Lower calibration point (Intern0 point)
	T_RANGE UpperCal;			///< Upper calibration point (Intern100 point)
	T_RANGE_COUNTS Raw0;				///< Uncalibrated lower zero
	T_RANGE_COUNTS Raw100;				///< Uncalibrated upper span
	T_RANGE_COUNTS Intern0;			///< Lower I/P internal representation
	T_RANGE_COUNTS Intern100;			///< Upper I/P internal representation
} T_BASECHANNELRANGE, *T_PBASECHANNELRANGE;
// Optional device to provide extended channel range
typedef struct _device {
	T_RANGE_DEVICE_TYPE DeviceType;			///< Device type
	UCHAR DeviceSubType;		///< Device sub-type
	BOOL Removable;			///< TRUE if device is removable
	USHORT DeviceID;			///< Device text ID 
	USHORT ConnectID;			///< Connect Device text ID 
	USHORT RemoveID;			///< Remove Device text ID 
	float Value;				///< Device value of range type i.e. resistance
	UCHAR DeviceRange;		///< Device range type (ohms, volts etc.)
	IO_MEASURE_UNITS DeviceUnits;		///< Device units in (m, u, n, p)
} T_DEVICE, *T_PDEVICE;
// Extended channel ranges provide a new range that uses the base ranges
typedef struct _extendedchannelrange {
	USHORT BoardVer;			///< Board version range supported on
	T_AIRANGEDEF ExtendedRangeID;	///< New extended Range ID
	USHORT BaseRangeID;	///< Base Range ID to obtain base Range selection/gain info
	T_RANGE LowerRange;			///< Nominal range lower limit
	T_RANGE UpperRange;			///< Nominal range upper limit
	T_RANGE LowerCal;			///< Lower range calibration point
	T_RANGE UpperCal;			///< Upper range calibration point
	T_RANGE SubLowerRange;		///< Subrange lower limit (for user display)
	T_RANGE SubUpperRange;		///< Subrange upper limit (for user display)
	IO_MEASURE_UNITS RangeUnits;			///< Range units
	T_RANGE_DEVICE_TYPE DeviceType;	///< Device type required on channel to provide extended channel range
	UCHAR DeviceSubType;	///< Device sub-type required on channel to provide extended channel range
} T_EXTENDEDCHANNELRANGE, *T_PEXTENDEDCHANNELRANGE;
typedef union _virtualrangebase {
	T_PBASECHANNELRANGE BaseRange;		///< Pointer to base range; if base
	T_PEXTENDEDCHANNELRANGE ExtendedRange;		///< Pointer to base range; if extended
} U_VIRTUALRANGEBASE, *U_PVIRTUALRANGEBASE;
typedef struct _channelrangesettings {
	/// Whether range is virtual, extended or base
	T_RANGE_SELECTION BaseRange;				///< Selected range type
	U_VIRTUALRANGEBASE RangeInfo;				///< Pointer to base range
} T_CHANNELRANGESETTINGS, *T_PCHANNELRANGESETTINGS;
// Virtual channel ranges limit upper and lower ranges and use base or extended ranges
// The limits of the range are reduced
// The range ID and base range is not changed
typedef struct _virtualchannelrange {
	USHORT VirtualRangeID;				///< New virtual Range ID
	T_CHANNELRANGESETTINGS RangeInfo;			///< Pointer to base range
	T_RANGE LowerRange;	///< Range lower limit (must be inside base or extended range)
	T_RANGE UpperRange;	///< Range upper limit (must be inside base or extended range)
} T_VIRTUALCHANNELRANGE, *T_PVIRTUALCHANNELRANGE;
class CAIRanges: public CPassiveModule {
public:
	static CAIRanges* GetHandle();
	void CleanUp();
	// Get board revision range capabilities
	UCHAR GetUserRangeClosestMatch(const UCHAR RangeRev, const UCHAR RangeType, const T_RANGE UpperRange,
			const T_RANGE LowerRange, const USHORT engUnits) const;
	UCHAR GetRangeClosestMatch(const UCHAR RangeRev, const UCHAR RangeType, const T_RANGE UpperRange,
			const T_RANGE LowerRange, const USHORT engUnits) const;
	T_PAIRANGEDEF GetChannelRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev, T_RANGE *pUpperRange,
	T_RANGE *pLowerRange) const;
	USHORT GetBaseChannelRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev) const;
	BOOL GetRangeConfig(const T_PAIRANGE pRangeCode, const UCHAR RangeRev, UCHAR *pRangeGain, UCHAR *pRangeUnits) const;
	T_PAIRANGEDEF GetChannelCalPoints(const T_PAIRANGE pRangeCode, const UCHAR RangeRev, T_RANGE *pUpperRange,
	T_RANGE *pLowerRange, IO_MEASURE_UNITS *pUnits) const;
	BOOL GetInternValues(const T_PAIRANGE RangeID, const UCHAR RangeRev,
	T_RANGE_COUNTS *pIntern0, T_RANGE_COUNTS *pIntern0V,
	T_RANGE_COUNTS *pIntern100) const;
	BOOL CheckUserPointsWithinRange(const T_AIRANGE *const pRangeCode, const UCHAR RangeRev, T_RANGE UpperRange,
	T_RANGE LowerRange) const;
	UCHAR ScaleToBaseRange(const UCHAR RangeRev, USHORT RangeEnum,
	T_RANGE *pUpperRange, T_RANGE *pLowerRange, const USHORT engUnits) const;
	BOOL GetBaseInternValues(const USHORT RangeCode, const UCHAR RangeRev,
	T_RANGE_COUNTS *pIntern0, T_RANGE_COUNTS *pIntern0V,
	T_RANGE_COUNTS *pIntern100) const;
	BOOL GetBaseChannelRange(const USHORT RangeCode, const UCHAR RangeRev,
	T_RANGE *const pUpperRange, T_RANGE *const pLowerRange, IO_MEASURE_UNITS *const pUnits) const;
	BOOL GetBaseNominalChannelRange(const USHORT RangeCode, const UCHAR RangeRev, T_RANGE *pUpperRange,
	T_RANGE *pLowerRange) const;
	BOOL GetBaseChannelConfig(const USHORT RangeCode, const UCHAR RangeRev, UCHAR *pRangeComp, UCHAR *pRangeGain,
			UCHAR *pRangePair) const;
	BOOL GetRangeReadTolerence(const USHORT RangeCode, const UCHAR RangeRev, const float tolerence,
	T_RANGE_COUNTS *pzeroUpperLimit, T_RANGE_COUNTS *pzeroLowerLimit,
	T_RANGE_COUNTS *pspanUpperLimit,
	T_RANGE_COUNTS *pspanLowerLimit) const;
	BOOL GetBaseRangeChannelCalPoints(const USHORT RangeCode, const UCHAR RangeRev, T_RANGE *pUpperRange,
	T_RANGE *pLowerRange, IO_MEASURE_UNITS *pUnits) const;
	T_PAIRANGEDEF GetChannelDispRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev,
	T_RANGE *const pUpperRange, T_RANGE *const pLowerRange) const;
	T_PAIRANGEDEF GetChannelDevice(const T_AIRANGE *pRangeCode, const UCHAR RangeRev,
			T_RANGE_DEVICE_TYPE *const DeviceType, UCHAR *const DeviceSubType) const;
	UCHAR GetRangeRevision(const UCHAR boardType, const UCHAR BoardRev) const;
	IO_MEASURE_UNITS GetRangeUnits(const UCHAR RangeRev, const USHORT RangeEnum) const;
	IO_MEASURE_UNITS GetHWRangeUnits(const UCHAR RangeRev, const USHORT RangeEnum) const;
	static const int MAX_CJCS = 4;
	static const int MAX_V7AI_CJCS = 4;
protected:
private:	// Singleton
	CAIRanges();
	CAIRanges(const CAIRanges&);
	CAIRanges& operator=(const CAIRanges&) {
		return *this;
	}
	;
	~CAIRanges();
	BOOL IsRangeCloser(const T_RANGE newUpperRange, const T_RANGE newLowerRange, const USHORT newEngUnits,
			const T_RANGE foundUpperRange, const T_RANGE foundLowerRange, const USHORT foundEngUnits) const;
	// Singleton handlers
	static CAIRanges *m_pInstance;
	static QMutex m_CreationMutex;
	USHORT GetBaseTableSize(void) const;
	USHORT GetExtendedTableSize(void) const;
	USHORT GetDeviceTableSize(void) const;
	const T_BASECHANNELRANGE* MatchBaseRange(const USHORT RangeCode, const UCHAR RangeRev) const;
	const T_BASECHANNELRANGE* MatchBaseRange(const T_AIRANGE *const pRangeCode, const UCHAR RangeRev) const;
	const T_EXTENDEDCHANNELRANGE* MatchExtendedRange(const T_AIRANGE *const pRangeCode, const UCHAR RangeRev) const;
	BOOL DoesExtendedRangeMatch(const UCHAR elementNo, const T_AIRANGE *const pRangeCompare) const;
	BOOL DoesBaseRangeMatch(const UCHAR elementNo, const T_AIRANGE *const rangeCompare) const;
};
#endif // !defined(AFX_AIRANGES_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#endif // _AIRANGES_H

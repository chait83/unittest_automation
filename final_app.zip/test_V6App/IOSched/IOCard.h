//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOCard.h
/// @n interface of the CIOCard class to provide support for
/// boards using external protocols.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 50	Stability Project 1.46.1.2	7/5/2011 5:04:06 PM	Hemant(HAIL) 
//		Fixed provided for recorder getting hanged after data reset, if 96
//		Pens are enabled for logging.
// 49	Stability Project 1.46.1.1	7/2/2011 4:58:00 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 48	Stability Project 1.46.1.0	7/1/2011 4:27:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 47	V6 Firmware 1.46		2/2/2009 12:34:47 PM	Build Machine cr
//		3078 -- increased startup time for fixing slow recorder unit for
//		specific setup with 6 io cards
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_IOCARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)
#define AFX_IOCARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_
#ifndef _IOCARD_H
#define _IOCARD_H
#include "CardSlot.h"
#include "Protocol.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define NEXT_SYSTEM_COVERAGE_UPDATE		25		// Update 4 times every second
//#define NEXT_SYSTEM_COVERAGE_HOLDOFF	75		// Hold off for 3/4 second
#define NEXT_SYSTEM_COVERAGE_HOLDOFF	25		// Hold off for 1/4 second
#define MAX_STARTUP_RETRY_TIME		(WAIT_25sec / 10)		///< Maximum time that the queues can be left without data (on startup)
#define MAX_IO_STARTUP_RETRY_TIME	(WAIT_60sec / 10)		///< Maximum time that the queues can be left without data (on startup) //BPCODE
#define MAX_DATA_RETRY_TIME			(WAIT_2000ms / 10)		///< Maximum time that the queues can be left without data
#define REV_A_BOARD				0		///< Rev A I/O board - old AI i.e. V6AI
#define V7AI_REV_A_BOARD		5		///< Rev A I/O board - New AI i.e. V7AI (V7AI_ISSUE_A)
#if !defined(_TRUNCATE)
#define _TRUNCATE ((size_t)-1)
#endif
struct BoardActionPendingFlags_t {
	USHORT Sync :1;			// TRUE if timstamp synchonisation is required
	USHORT Timestamp :1;			// TRUE if timstamp is required
	USHORT CJC :1;			// TRUE if CJC read pending 
	USHORT RTCal :1;		// TRUE if RT cal reading on any channel pending 
	USHORT RTComp :1;		// TRUE if RT comp reading on any channel pending
	USHORT ChanRead2 :1;		// TRUE if channel readings type 2 are to be requested
	USHORT ChanRead :1;			// TRUE if channel readings are to be requested
	USHORT AckReadings :1;		// TRUE if channel readings can be acknowledged
	USHORT WriteAllow :1;			// TRUE if output is allowed
	USHORT TimeBase :1;			// TRUE if board timebase is required
	USHORT RxError :1;		// TRUE if error stats command requires scheduling
	USHORT DataReset :1;			// TRUE if data from card is to be discarded
	USHORT StatCheck :1;			// TRUE if card status check is required
	USHORT ActBrnStatusRqd :1;		// TRUE if active burnout check is required
	USHORT Unused :2;			// Unused for future use
};
struct BoardAction_t {
	// Pending commands and actions - priority is given to higher priority commands
//	struct BoardCmdPendingFlags_t m_BoardCmdPending;
	struct BoardActionPendingFlags_t m_BoardPending;
	long m_Interval;
	LONGLONG m_LastScheduledTime;
	LONGLONG m_NextScheduledTime;
	double m_timeToNextRun;
};
struct BoardPending_t {
	USHORT CommandModeToProc;		// Board mode selection / recovery command
	struct BoardActionPendingFlags_t Board;	// Board actions pending for state machine
};
//******************************************************
/// @brief Abstract class, providing the ability to process and query SPI/SCI driven cards.
/// 
/// Provides the ability to process and query SPI/SCI driven cards. 
///
//******************************************************
class CIOCard: public CCardSlot {
public:
	virtual void GetIOCardStrID(QString *pIDText) const = 0;
	virtual BOOL GetIOLifeHistory(class CProtocol *const pProtocol) = 0;
	BOOL RegisterTransManager(class CTransMangr *const pTransMangr);
	BOOL ResyncService(void);
	LONGLONG SetLastPPQSystemCoverage(const LONGLONG digitalLastCovSystemTick);
	LONGLONG GetLastPPQSystemCoverage(void) const;
	LONGLONG GetNextPPQSystemCoverageRqd(const ULONG difference) const;
	LONGLONG GetNextDISystemCoverageRqd(const ULONG difference) const;
	LONGLONG GetLastDISystemCoverage(void) const;
	LONGLONG SetLastDISystemCoverage(const LONGLONG digitalLastCovSystemTick);
	BOOL ScheduleDataBlockAck(void);
	BOOL ScheduleDataWriteAllowed(void);
	BOOL ScheduleStatusCheck(void);
	BOOL SetAcquireModeActiveState(const BOOL activeState);
	BOOL ScheduleQueueSync(void);
	BOOL ScheduleQueueReSync(void);
	BOOL ScheduleClearBatchedData(void);
	BOOL ScheduleSerialNoUpdate(void);
	BOOL ScheduleCardQueueSyncOperation(void);
	BOOL ScheduleUpdateCardInfo(void);
	BOOL ScheduleTestStatusUpdate(void);
	BOOL ScheduleErrorDownload(void);
	BOOL ScheduleRTChanCal(void);
	BOOL IOCardIPQueryAllowed(void);
	BOOL CheckRecorderCardSerialNoChanged( USHORT slotNo);
	CIOCard(const USHORT cardNo);
	virtual ~CIOCard();
	//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) begin
	virtual void PerformReset();
	//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) end
protected:
	void UpdateRecorderCardSerialNo( USHORT slotNo);
	void ResetStateMachine(void);
	BOOL SyncService(void);
	BOOL OperateTransactionSM(void);
	BOOL PerformSMModeChange(void);
	USHORT INTER_COMMAND_DELAY;			///< Intercommand delay
	BOOL m_CardQueryEnabled;			///< I/O card query is allowed
	BOOL m_initialDataReadForce;			///< I/O card intial interrupt force read required
	BOOL m_failureReportAdded;	///< Has failure of card been reported to user
	class CProtocol *m_pProtocol;	///< Send individual commands to I/O board
	BOOL m_SyncOpPending;					// Is sync operation pending
	BOOL m_ReSyncOpPending;					// Is resync operation pending
	BOOL m_DeviceFailed;					// TRUE if device has failed
	UCHAR m_CmdProcessed;		// Number of commands processed this power cycle
	class CIOConfigManager *m_pConfigMngrObj;	///< Configuration manager
	struct BoardPending_t m_NormOpPending;	///< Board state machine pending action run time variables
	class CTransMangr *m_pTransMngr;	///< The transaction manager, through which all transaction requests must go.
	LONGLONG m_DigitalLastCovSystemTick;	///< System tick that digital I/O cards were last told coverage at
	LONGLONG m_DigitalLastReadSystemTick;	///< System tick that digital I/O cards were last read at
	LONGLONG m_LastSuccesfulReadSystemTick;	///< System tick that I/O cards were last successfully read at
	LONGLONG m_LastPPQSystemUpdateTick;	///< System tick that PPQ I/O readings were updated
};
#endif // _IOCARD_H
#endif // !defined(AFX_IOCARD_H__595A4292_0D9C_42EA_B8B9_222E3512DE20__INCLUDED_)

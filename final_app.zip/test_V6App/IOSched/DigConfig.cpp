/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n DigConfig.cpp
/// @n implementation of the CDigConfig class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 82	Stability Project 1.77.1.3	7/2/2011 4:56:46 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 81	Stability Project 1.77.1.2	7/1/2011 4:38:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 80	Stability Project 1.77.1.1	3/17/2011 3:20:22 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 79	Stability Project 1.77.1.0	2/15/2011 3:02:57 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "V6IOBoardTypes.H"
#include "CardSlot.h"
#include "IOCard.h"
#include "ATECal.h"
#include "PPL.h"
#include "DigPulseCard.h"
#include "DigConfig.h"
#include "SetupConfiguration.h"
#include "V6globals.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "V6defines.h"
#include "V6crc.h"
#include "TraceDefines.h"
#include "V6IO_AI_InputRanges.H"
#include "Conversion.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDigConfig::CDigConfig() {
//	qDebug("Create new CDigConfig\n");
	ClearLocalConfig();
}
CDigConfig::~CDigConfig() {
//	qDebug("Deleting CDigConfig class\n");
}
//**********************************************************************
///
/// Default/deselect local config
///
//**********************************************************************
void CDigConfig::ClearLocalConfig(void) {
	memset(&m_Config, 0, sizeof(m_Config));
}
//**********************************************************************
/// QueryIsChanOPFailSafe()
///
/// Queries the local configuration whether output and failsafe is selected.
///
/// @param[in] chanNo - Board channel number.
///
/// @return	TRUE if the channel output is configured to failsafe
//**********************************************************************
BOOL CDigConfig::QueryIsChanOPFailSafe(const UCHAR chanNo) const {
	return (m_Config.Cfg.CfgChan[chanNo].FailSafe & m_Config.Cfg.CfgChan[chanNo].DigOut);
}
//**********************************************************************
/// DecodeChannelAcqRate()
///
/// Decodes the channel acqusition rate for the local configuration.
///
/// @param[in] CMMSetting - CMM representation of the acqusition rates.
///
/// @return		The acquisitions on this channel
//**********************************************************************
USHORT CDigConfig::CalculateCMMChannelReadRate(const UCHAR CMMSetting) const {
	USHORT DigAcqRate = 0;
	switch (CMMSetting) {
	case PULSE_ACQ_RATE_1HZ:
		DigAcqRate = 1;
		break;
	case PULSE_ACQ_RATE_2HZ:
		DigAcqRate = 2;
		break;
	case PULSE_ACQ_RATE_5HZ:
		DigAcqRate = 5;
		break;
	case PULSE_ACQ_RATE_10HZ:
		DigAcqRate = 10;
		break;
	};
	return DigAcqRate;
}
//**********************************************************************
///
/// Load the top slot pulse channel configuration
/// @param[in] chanNo - The I/O card channel number.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::CMMTopSlotPulseLoad(const UCHAR chanNo) {
	BOOL LoadOK = TRUE;
#ifndef ATE_BUILD
	T_PPULSECHANNEL pPulseCMMConfig = NULL;
	USHORT channelType;
	class CSlotMap *pSlotMap = NULL;
	class CIOSetupConfig *m_pIOSetupConfig = NULL;
	pSlotMap = CSlotMap::GetHandle();
	m_pIOSetupConfig = pSETUP->GetIOSetupConfig();
	if (m_pIOSetupConfig != NULL) {
		if (chanNo < TOPSLOT_PULSECHAN_SIZE) {
			channelType = pSlotMap->GetHWChannelSelectedType(m_pIOCard->BoardSlotInstance(), chanNo);
			// Channel can either be digital in/out or under certain conditions a pulse channel
			if (channelType == CHANNEL_PULSE) {
				// Load configuration for each Pulse channel
				pPulseCMMConfig = m_pIOSetupConfig->GetPulseInput(m_pIOCard->BoardSlotInstance(), chanNo,
						CONFIG_COMMITTED);
				if (pPulseCMMConfig != NULL) {
					LoadOK = PulseSlotLoad(chanNo, pPulseCMMConfig);
				}
			}
		}
	}
#endif
	return LoadOK;
}
//**********************************************************************
///
/// Load the top slot pulse channel configuration
/// @param[in] chanNo - The I/O card channel number.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::CMMBottomSlotPulseLoad(const UCHAR chanNo) {
	BOOL LoadOK = FALSE;
#ifndef ATE_BUILD
	class CSlotMap *pSlotMap = NULL;
	T_PDIGCHANNEL pDigCMMConfig = NULL;
	USHORT channelType;
	class CIOSetupConfig *m_pIOSetupConfig = NULL;
	pSlotMap = CSlotMap::GetHandle();
	m_pIOSetupConfig = pSETUP->GetIOSetupConfig();
	if (m_pIOSetupConfig != NULL) {
		if (chanNo < HW_BOTTOMSLOT_PULSECHAN_SIZE) {
			m_Config.Cfg.CfgChan[chanNo].PulseIn = FALSE;
			m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled = FALSE;
			channelType = pSlotMap->GetHWChannelSelectedType(m_pIOCard->BoardSlotInstance(), chanNo);
			// Channel can either be digital in/out or under certain conditions a pulse channel
			if (channelType == CHANNEL_DIG_PULSE) {
				pDigCMMConfig = m_pIOSetupConfig->GetDigital(m_pIOCard->BoardSlotInstance(), chanNo, CONFIG_COMMITTED);
				if (pDigCMMConfig != NULL) {
					// Convert CMM config to board config
					m_Config.Cfg.CfgChan[chanNo].PulseIn = static_cast<BOOL>(pDigCMMConfig->Type == dtPulseInput);
					m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled = pDigCMMConfig->Enabled;
					m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqEnum = PULSE_ACQ_RATE_1HZ;
					LoadOK = TRUE;
				}
			}
		}
	}
#endif
	return LoadOK;
}
//**********************************************************************
///
/// Load the top slot pulse channel configuration
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] pPulseCMMConfig - The CMM puls channel configuration.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::PulseSlotLoad(const UCHAR chanNo, T_PPULSECHANNEL pPulseCMMConfig) {
	BOOL LoadOK = FALSE;
	if (pPulseCMMConfig != NULL) {
		// Convert CMM config to board config
		m_Config.Cfg.CfgChan[chanNo].PulseIn = pPulseCMMConfig->Enabled;
		m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled = pPulseCMMConfig->Enabled;
		if (pPulseCMMConfig->FreqMeasure == TRUE)
			m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqEnum = PULSE_ACQ_RATE_FREQ_MEASURE;
		else
			m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqEnum = PULSE_ACQ_RATE_NON_FREQ_MEASURE;
		LoadOK = IOCardLocalConfigCommit();
	}
	return LoadOK;
}
//**********************************************************************
///
/// Commit the local configuration to a the working structures and I/O board
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::IOCardLocalConfigCommit(void) {
	UCHAR chanNo;
	USHORT tempBitMask = 0;
	BOOL LoadOK = FALSE;
	m_Config.CfgBoard.PulseSelectionMask = 0;
	m_Config.CfgBoard.InputSelectionMask = 0;
	m_Config.CfgBoard.DigInputSelectionMask = 0;
	m_Config.CfgBoard.IODigitalEnabledMask = 0;
	m_Config.CfgBoard.OutputPulseMask = 0;
	m_Config.CfgBoard.OutputFailSafe = 0;
	for (chanNo = 0; chanNo < HW_BOTTOMSLOT_PULSECHAN_SIZE; chanNo++) {
		// Only configure channel if enabled
		if (m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE) {
			m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqCardEnum = static_cast<UCHAR>(IOEnumConvert(
					m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqEnum));
			m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqRate = static_cast<UCHAR>(CalculateCMMChannelReadRate(
					m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqEnum));
			SetBits(&m_Config.CfgBoard.DigInputSelectionMask, m_Config.Cfg.CfgChan[chanNo].PulseIn, chanNo, 1);
			SetBits(&m_Config.CfgBoard.InputSelectionMask, m_Config.Cfg.CfgChan[chanNo].PulseIn, chanNo, 1);
			SetBits(&m_Config.CfgBoard.IODigitalEnabledMask, m_Config.Cfg.CfgChan[chanNo].PulseIn, chanNo, 1);
			SetBits(&m_Config.CfgBoard.PulseSelectionMask, m_Config.Cfg.CfgChan[chanNo].PulseIn, chanNo, 1);
			if (m_Config.Cfg.CfgChan[chanNo].PulseIn == TRUE)
				m_pBrdInfoObj->SetSelectedChannelType(m_pIOCard->BoardSlotInstance(), chanNo, CHANNEL_PULSE);
		}
	}
	for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
		// Only configure channel if enabled
		if (m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled == TRUE) {
			// Setup were to log the activation/deactivation status for each channel
			SetBits(&m_Config.CfgBoard.chartReportMask, (m_Config.Cfg.CfgChan[chanNo].PersistEvent == 2), chanNo, 1);
			SetBits(&m_Config.CfgBoard.msgReportMask, (m_Config.Cfg.CfgChan[chanNo].PersistEvent == 1), chanNo, 1);
			// Setup which channels are selected as a digital input
			SetBits(&(m_Config.CfgBoard.DigInputSelectionMask), m_Config.Cfg.CfgChan[chanNo].DigIn, chanNo, 1);
			// Setup which channels are selected to any type of input (used by I/O card)
			tempBitMask = 0;
			SetBits(&tempBitMask, m_Config.Cfg.CfgChan[chanNo].DigIn, chanNo, 1);
			m_Config.CfgBoard.IODigitalEnabledMask |= tempBitMask;
			m_Config.CfgBoard.InputSelectionMask |= tempBitMask;
			// Setup which channels are selected as either any input or output (used by I/O card)
			tempBitMask = 0;
			SetBits(&tempBitMask, m_Config.Cfg.CfgChan[chanNo].DigOut, chanNo, 1);
			m_Config.CfgBoard.IODigitalEnabledMask |= tempBitMask;
			if (m_Config.Cfg.CfgChan[chanNo].DigIn == TRUE) {
				m_pBrdInfoObj->SetSelectedChannelType(m_pIOCard->BoardSlotInstance(), chanNo, CHANNEL_DI);
			} else if (m_Config.Cfg.CfgChan[chanNo].DigOut == TRUE) {
				m_pBrdInfoObj->SetSelectedChannelType(m_pIOCard->BoardSlotInstance(), chanNo, CHANNEL_DO);
				SetBits(&m_Config.CfgBoard.OutputFailSafe, m_Config.Cfg.CfgChan[chanNo].FailSafe, chanNo, 1);
				SetBits(&m_Config.CfgBoard.OutputPulseMask, !m_Config.Cfg.CfgChan[chanNo].OutputLatched, chanNo, 1);
			}
		}
	}
	LoadOK = TRUE;
	// If successful place the I/O card into run mode
	if (TRUE == LoadOK)
		m_pIOCard->ScheduleIOBoardRunMode(TRUE);
	return LoadOK;
}
//**********************************************************************
/// GetChannelAcqRate()
///
/// Gets the channel acqusition rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between acqusitions on this channel
//**********************************************************************
USHORT CDigConfig::GetChannelAcqRate(const UCHAR chanNo) const {
	return m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqRate;
}
//**********************************************************************
///
/// Converts CMM config enum into downloadable card channel enum
///
/// @param[in] acqRate - The systems enum.
///
/// @return		The boards acqusition enum
//**********************************************************************
USHORT CDigConfig::IOEnumConvert(const USHORT acqRate) const {
	switch (acqRate) {
	case PULSE_ACQ_RATE_1HZ:
		return ACQ_FREQ1;
	case PULSE_ACQ_RATE_2HZ:
		return ACQ_FREQ2;
	case PULSE_ACQ_RATE_5HZ:
		return ACQ_FREQ5;
	case PULSE_ACQ_RATE_10HZ:
		return ACQ_FREQ10;
	}
	return ACQ_FREQ1;
}
//**********************************************************************
///
/// Get reference to channel local configuration as channel service data
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] pChanCfgInfo - Channel configuration info
///
/// @return		TRUE if the cahannel has configuration data available; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::GetChannelConfigRef(const UCHAR ChanNo, T_DIGCFGCHANNEL **ppChanCfgInfo) {
	BOOL retValue = FALSE;
	// Ensure channel is legal
	if (ChanNo < BOTTOMSLOT_DIGCHAN_SIZE) {
		*ppChanCfgInfo = &m_Config.Cfg.CfgChan[ChanNo];
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Query whether channel is enabled.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		TRUE if channel is enabled; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::QueryChannelEnabled(const UCHAR chanNo) const {
	return m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled;
}
//**********************************************************************
/// CMMSlotLoad()
///
/// Converts CMM config into card downloadable configuration
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::CMMSlotLoad(void) {
	T_PDIGCHANNEL pDigCMMConfig = NULL;
	T_PPULSECHANNEL pPulseCMMConfig = NULL;
	USHORT chanNo = 0;
	USHORT channelType;
	UCHAR channelCap;
	BOOL LoadOK = TRUE;
	WCHAR boardSlotStr[4];
	class CIOSetupConfig *pIOSetupConfig = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMapObj = NULL;		///< Board slot map holder
	pBrdInfo = CBrdInfo::GetHandle();
	pSlotMapObj = CSlotMap::GetHandle();
	pIOSetupConfig = pSETUP->GetIOSetupConfig();
	if (pIOSetupConfig != NULL) {
		chanNo = 0;
		m_Config.CfgBoard.InputSelectionMask = 0;
		m_Config.CfgBoard.PulseSelectionMask = 0;
		m_Config.CfgBoard.IODigitalEnabledMask = 0;
		/// Check whether slot being loaded is top slot or bottom slot
		if (pSlotMapObj->IsCardInTopSlot(m_pIOCard->BoardSlotInstance()) == TRUE) {
			do {
				channelType = pSlotMapObj->GetHWChannelSelectedType(m_pIOCard->BoardSlotInstance(), chanNo);
				channelCap = pBrdInfo->WhatAvailableChannelType(m_pIOCard->BoardSlotInstance(), chanNo);
				// The board types can only hold upper slot pulse channels only
				if (channelCap == CHANNEL_CAP_UNKNOWN) {
					// Channel does not exist, so we can except any setup
				} else if (channelType == CHANNEL_PULSE) {
					LoadOK = CMMTopSlotPulseLoad(static_cast<UCHAR>(chanNo));
				}
				chanNo++;
			} while ((chanNo < TOPSLOT_PULSECHAN_SIZE) && (LoadOK == TRUE));
		} else {
			do {
				m_Config.Cfg.CfgChan[chanNo].DigIn = FALSE;
				m_Config.Cfg.CfgChan[chanNo].DigOut = FALSE;
				m_Config.Cfg.CfgChan[chanNo].PulseIn = FALSE;
				channelType = pSlotMapObj->GetHWChannelSelectedType(m_pIOCard->BoardSlotInstance(), chanNo);
				channelCap = pBrdInfo->WhatAvailableChannelType(m_pIOCard->BoardSlotInstance(), chanNo);
				pDigCMMConfig = pIOSetupConfig->GetDigital(m_pIOCard->BoardSlotInstance(), chanNo, CONFIG_COMMITTED);
				// CR: Recorder Lockup Issue on Importing Layout
				if (pDigCMMConfig != NULL) {
					/// TODO :
					wcsncpy(m_Config.Cfg.CfgChan[chanNo].Label, pDigCMMConfig->Label, _TRUNCATE);
					wcsncpy(m_Config.Cfg.CfgChan[chanNo].Active, pDigCMMConfig->Active,
					_TRUNCATE);
					wcsncpy(m_Config.Cfg.CfgChan[chanNo].InActive, pDigCMMConfig->InActive,
					_TRUNCATE);
					m_Config.Cfg.CfgChan[chanNo].PersistEvent = pDigCMMConfig->PersistEvent;
				}
				if ((channelType == CHANNEL_DIG_PULSE) && (channelCap & CHANNEL_CAP_PULSE)) {
					// All bottom slot channel types are possible depending upon card type and channel number
					LoadOK = CMMBottomSlotPulseLoad(static_cast<UCHAR>(chanNo));
				} else if ((channelType == CHANNEL_DI) && (channelCap & CHANNEL_CAP_DI)) {
					pDigCMMConfig = pIOSetupConfig->GetDigital(m_pIOCard->BoardSlotInstance(), chanNo,
							CONFIG_COMMITTED);
					if (pDigCMMConfig != NULL) {
						m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled = pDigCMMConfig->Enabled;
						SetBits(&m_Config.CfgBoard.InputSelectionMask, 1, chanNo, 1);
						m_Config.Cfg.CfgChan[chanNo].DigIn = TRUE;
						SetBits(&m_Config.CfgBoard.IODigitalEnabledMask, m_Config.Cfg.CfgChan[chanNo].DigIn, chanNo, 1);
					} else {
						LoadOK = FALSE;
					}
				} else if ((channelType == CHANNEL_DO) && (channelCap & CHANNEL_CAP_DO)) {
					if (pDigCMMConfig != NULL) {
						m_Config.Cfg.CfgChan[chanNo].DigOut = TRUE;
						m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled = pDigCMMConfig->Enabled;
						SetBits(&m_Config.CfgBoard.IODigitalEnabledMask, m_Config.Cfg.CfgChan[chanNo].DigOut, chanNo,
								1);
						m_Config.Cfg.CfgChan[chanNo].FailSafe = pDigCMMConfig->DigO.FailSafe;
						m_Config.Cfg.CfgChan[chanNo].OutputLatched = pDigCMMConfig->DigO.OPLatched;
						if (m_Config.Cfg.CfgChan[chanNo].DigOut == TRUE) {
							// If the digital is an output
							if (m_Config.Cfg.CfgChan[chanNo].OutputLatched == FALSE) {
								// Only load the pulse duration if a non-latched output
								m_Config.Cfg.CfgChan[chanNo].PulseDuration =
										static_cast<USHORT>(pDigCMMConfig->DigO.Duration * 10.0);
							}
						}
					} else {
						LoadOK = FALSE;
					}
				} else if (channelCap == CHANNEL_CAP_UNKNOWN) {
					// Channel does not exist, so we can except any setup
				} else {
					// An illegal channel is specified
					pSlotMapObj->GetSlotStrID(m_pIOCard->BoardSlotInstance(), QString::fromWCharArray(boardSlotStr));
					LOG_ERR(TRACE_IO_SCHED, "ILLEGAL CHANNNEL %d CONFIGURATION FOUND ON PULSE/DIGITAL BOARD %s", chanNo, boardSlotStr);
					LoadOK = FALSE;
				}
				chanNo++;
			} while ((chanNo < BOTTOMSLOT_DIGCHAN_SIZE) && (LoadOK == TRUE));
		}
	} else
		LoadOK = FALSE;
	// If each channel has been successfully configured, then commit the local AI configuration to the I/O card
	if (LoadOK == TRUE) {
		LoadOK = IOCardLocalConfigCommit();
	}
	return LoadOK;
}
//**********************************************************************
/// InitialiseCardConfigHolder()
///
/// Initialises the I/O board configuration from the CMM.
///
/// @param[in] pIOCard - The I/O card to which this configuration belongs.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::InitialiseCardConfigHolder(class CIOCard *const pIOCard) {
	BOOL retValue = TRUE;
	retValue = InitialiseConfig();
	m_pIOCard = pIOCard;
	if (m_pBrdInfoObj == NULL) {
		// @todo: Unable to get handle/create board info
		retValue = FALSE;
	}
	if (m_pBrdStatsObj == NULL) {
		// @todo: Unable to get handle/create board stats
		retValue = FALSE;
	}
	if (retValue != FALSE)
		retValue = m_pIOCard->CMMCreateLocalConfig();
	return retValue;
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Load the global configuration from the CMM and create the locally held one.
///
/// @return TRUE if successful created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CDigConfig::CMMCreateLocalConfig(void) {
	BOOL retValue = FALSE;
	retValue = CMMSlotLoad();
	if (retValue != FALSE) {
		// Calculate the current setup configuration CRC value and store
		CrcInsert(reinterpret_cast<UCHAR*>(&m_Config), sizeof(T_DIGBOARDCONFIG));
		m_pBrdInfoObj->SetCalcConfigCRC(m_pIOCard->BoardSlotInstance(), m_Config.Cfg.ConfigCRC);
	}
	if (retValue != FALSE)
		retValue = IOCardLocalConfigCommit();
	return retValue;
}
//******************************************************
// SetupConfigChangePreparation()
///
/// Sets all digital/pulse services on a setup commit change preperation
///
/// @return TRUE on success; otherwise FALSE
/// 
//******************************************************
BOOL CDigConfig::SetupConfigChangePreparation(void) {
	if (IsRunningAsATEEquipment() == FALSE) {
#ifndef V6IOTEST
		USHORT chanNo = 0;
		USHORT channelType = CHANNEL_UNKNOWN;
		USHORT sysChan = 0;
		UCHAR channelCap = CHANNEL_CAP_UNKNOWN;
		BOOL digChanConfigChanged = FALSE;
		T_PDIGCHANNEL pDigCMMConfig = NULL;
		class CSlotMap *pSlotMapObj = NULL;		///< Board slot map holder
		class CBrdInfo *pBrdInfo = NULL;
		class CIOSetupConfig *m_pIOSetupConfig = NULL;
		class CDataItem *pDigHolder = NULL;
		pSlotMapObj = CSlotMap::GetHandle();
		pBrdInfo = CBrdInfo::GetHandle();
		m_pIOSetupConfig = pSETUP->GetIOSetupConfig();
		if (m_pIOSetupConfig != NULL) {
			for (chanNo = 0; chanNo < HW_DIG_IO_CHAN_PER_BOARD; chanNo++) {
				channelType = pSlotMapObj->GetHWChannelSelectedType(m_pIOCard->BoardSlotInstance(), chanNo);
				channelCap = pBrdInfo->WhatAvailableChannelType(m_pIOCard->BoardSlotInstance(), chanNo);
				sysChan = pSlotMapObj->GetSysChannelFromDigIOChannel(m_pIOCard->BoardSlotInstance(), chanNo,
						ZERO_BASED);
				pDigCMMConfig = m_pIOSetupConfig->GetDigital(m_pIOCard->BoardSlotInstance(), chanNo, CONFIG_MODIFIABLE);
				// Need to compare the new CMM settings with the previous to see if any current
				// digital inputs have been reconfigured or disabled
				if ((FALSE == pDigCMMConfig->Enabled)
						|| ((TRUE == m_Config.Cfg.CfgChan[chanNo].DigIn) && (CHANNEL_DI == channelType)
								&& (channelCap & CHANNEL_CAP_DI) && (dtInput != pDigCMMConfig->Type))) {
					// The channel was previously a digital input, and is not now;
					// so Digital DIT entry must be reset to default state
					digChanConfigChanged = TRUE;
					pDigHolder = pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, sysChan);
					if (pDigHolder != NULL) {
						pDigHolder->SetValue(0.0F);
					}
				}
				// Need to compare the new CMM settings with the previous to see if any current
				// digital outputs have been reconfigured or disabled
				if ((FALSE == pDigCMMConfig->Enabled)
						|| ((TRUE == m_Config.Cfg.CfgChan[chanNo].DigOut) && (CHANNEL_DO == channelType)
								&& (channelCap & CHANNEL_CAP_DO) && (dtOutput != pDigCMMConfig->Type))) {
					digChanConfigChanged = TRUE;
				}
				// Need to compare the new CMM settings with the previous to see if any current
				// pulse inputs have been reconfigured or disabled
				if ((FALSE == pDigCMMConfig->Enabled)
						|| ((TRUE == m_Config.Cfg.CfgChan[chanNo].PulseIn) && (CHANNEL_PULSE == channelType)
								&& (channelCap & CHANNEL_CAP_PULSE) && (dtPulseInput != pDigCMMConfig->Type))) {
					class CDataItem *pDataItem = NULL;
					// Pulse channel type has changed, so reset pulse counter
					pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_LCOUNT, sysChan);
					if (NULL != pDataItem) {
						pDataItem->SetValue(0.0F);
						pDataItem->SetStatus(DISTAT_NORMAL);
					}
				}
				if ( TRUE == digChanConfigChanged) {
					class CDataItem *pDataItem = NULL;
					// Digital channel type has changed, so reset digital counter
					pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_IO, sysChan);
					if (NULL != pDataItem) {
						pDataItem->SetValue(0.0F);
						pDataItem->SetStatus(DISTAT_NORMAL);
					}
				}
			}
		}
#endif
	}
	return TRUE;		// No handler to remove
}
//******************************************************
///
/// Query the whether the channel is a digital input
/// @param[in] chanNo - The I/O card channel number.
///
/// @return TRUE if board channel is configured as an enabled digital input
/// 
//******************************************************
BOOL CDigConfig::IsChanEnabledDigIn(const UCHAR chanNo) const {
	return (m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled && m_Config.Cfg.CfgChan[chanNo].DigIn);
}
//******************************************************
///
/// Query the whether the channel is a digital output
/// @param[in] chanNo - The I/O card channel number.
///
/// @return TRUE if board channel is configured as an enabled digital input
/// 
//******************************************************
BOOL CDigConfig::IsChanEnabledDigOut(const UCHAR chanNo) const {
	return (m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled && m_Config.Cfg.CfgChan[chanNo].DigOut);
}
//******************************************************
///
/// Query the whether the channel is a digital pulse input
/// @param[in] chanNo - The I/O card channel number.
///
/// @return TRUE if board channel is configured as an enabled digital input
/// 
//******************************************************
BOOL CDigConfig::IsChanEnabledPulseIn(const UCHAR chanNo) const {
	return (m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.Enabled && m_Config.Cfg.CfgChan[chanNo].PulseIn);
}
//******************************************************
///
/// Query the board Report Selection Mask
/// @param[out] chartReportMask - TRUE if channel activation is to be reported to the chart & 'digital' message list.
/// @param[out] msgReportMask - TRUE if channel activation is only to be reported to the 'digital' message list.
///
/// 
//******************************************************
void CDigConfig::QueryReportSelectionMask( USHORT &chartReportMask,
USHORT &msgReportMask) const {
	chartReportMask = m_Config.CfgBoard.chartReportMask;
	msgReportMask = m_Config.CfgBoard.msgReportMask;
}
//******************************************************
///
/// Query the board configuration Digital Input Selection Mask
///
/// @return The Digital Input Selection Mask
/// 
//******************************************************
USHORT CDigConfig::GetBoardCfgDigitalInputSelectionMask(void) const {
	return m_Config.CfgBoard.DigInputSelectionMask;
}
//******************************************************
///
/// Query the board configuration Input Selection Mask
///
/// @return The Input Selection Mask
/// 
//******************************************************
USHORT CDigConfig::GetBoardCfgInputSelectionMask(void) const {
	return m_Config.CfgBoard.InputSelectionMask;
}
//******************************************************
///
/// Query the board configuration I/O Digital Enabled Mask
///
/// @return The I/O Digital Enabled Mask
/// 
//******************************************************
USHORT CDigConfig::GetBoardCfgIODigitalEnabledMask(void) const {
	return m_Config.CfgBoard.IODigitalEnabledMask;
}
//******************************************************
///
/// Query the board configuration Output Fail Safe mask
///
/// @return The Output Fail Safe mask
/// 
//******************************************************
USHORT CDigConfig::GetBoardCfgOutputFailSafe(void) const {
	return m_Config.CfgBoard.OutputFailSafe;
}
//******************************************************
///
/// Query the board configuration Output Pulse Mask
///
/// @return The Output Pulse Mask
/// 
//******************************************************
USHORT CDigConfig::GetBoardCfgOutputPulseMask(void) const {
	return m_Config.CfgBoard.OutputPulseMask;
}
//******************************************************
///
/// Query the board configuration Pulse input selection Mask
///
/// @return The Pulse input selection Mask
/// 
//******************************************************
UCHAR CDigConfig::GetBoardCfgPulseInSelectionMask(void) const {
	return static_cast<UCHAR>(m_Config.CfgBoard.PulseSelectionMask);
}
//******************************************************
///
/// Query the board configuration Output pulse duration
/// @param[in] chanNo - The I/O card channel number.
///
/// @return The Output pukse duration
/// 
//******************************************************
USHORT CDigConfig::GetBoardCfgOutputPulseDuration(const USHORT chanNo) const {
	return m_Config.Cfg.CfgChan[chanNo].PulseDuration;
}
//******************************************************
///
/// Query the board configuration input acqusition rate (enum)
/// @param[in] chanNo - The I/O card channel number.
///
/// @return The input acqusition rate (enum)
/// 
//******************************************************
UCHAR CDigConfig::GetBoardCfgPulseAcqRate(const USHORT chanNo) const {
	if (m_Config.Cfg.CfgChan[chanNo].PulseIn == TRUE)
		return m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqCardEnum;
	return 0;
}
//**********************************************************************
///
/// Converts calibration structure config into card channel local downloadable
/// configuration holder, for all channels
///
/// @param[in] pCalStruct - The calibration structure with details of the mode required.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::DigCalStructTransfer(class CATECal *const pCalStruct) {
	UCHAR chanNo;
	BOOL retValue = FALSE;
	for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
		// Load configuration for each digital or pulse channel
		m_Config.Cfg.CfgChan[chanNo] = pCalStruct->m_cfgDigPulse.CfgChan[chanNo];
	}
	return retValue;
}
//**********************************************************************
/// Post the digital activation notfication message, dependant upon CMM requirements
///
/// @param[in]	messNumber - message identifier in string table
/// @param[in]	Activate - TRUE if digital is activated; otherwise FALSE
///
/// @return		nothing
/// 
//**********************************************************************
void CDigConfig::LogDigitalState( USHORT sysDigitalNo, BOOL Activate) {
	T_MSGLISTSER_USER_MSG_TYPE msgType;			///< Type of user message 
	WCHAR messageText[MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE];
	WCHAR *strMessage1;
	WCHAR *strMessage2;
	float pulseDuration = 0.0F;
	BOOL logMessage = FALSE;
	USHORT slotNo;
	USHORT chanNo;
	class CSlotMap *pSlotMap = NULL;
	if (Activate == TRUE)
		msgType = MSGLISTSER_DIGITAL_ACTIVATE;
	else
		msgType = MSGLISTSER_DIGITAL_DEACTIVATE;
	pSlotMap = CSlotMap::GetHandle();
	pSlotMap->GetSlotAndChannelFromDigitalSysChan(sysDigitalNo, slotNo, chanNo, ONE_BASED);
	if (m_Config.Cfg.CfgChan[chanNo].OutputLatched == TRUE) {
		swprintf(messageText, MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE, L"%s %s", m_Config.Cfg.CfgChan[chanNo].Label,
				(Activate == TRUE) ? m_Config.Cfg.CfgChan[chanNo].Active : m_Config.Cfg.CfgChan[chanNo].InActive);
		logMessage = TRUE;
	} else if (Activate == TRUE) {
		pulseDuration = static_cast<float>(m_Config.Cfg.CfgChan[chanNo].PulseDuration) / 10.0F;
		QWidget::tr("Pulsed").toWCharArray(strMessage1);
		QWidget::tr("Secs").toWCharArray(strMessage2);
		swprintf(messageText, MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE, L"%s %s %s (for %.1f %s)",
				m_Config.Cfg.CfgChan[chanNo].Label, strMessage1, m_Config.Cfg.CfgChan[chanNo].Active, pulseDuration,
				strMessage2);
		logMessage = TRUE;
	}
	if (logMessage == TRUE) {
		if (m_Config.Cfg.CfgChan[chanNo].PersistEvent == 2)
			LOG_DIGITAL_CHART_MESSAGE(msgType, QString::fromWCharArray(messageText));
		else if (m_Config.Cfg.CfgChan[chanNo].PersistEvent == 1)
			LOG_DIGITAL_MESSAGE(msgType, QString::fromWCharArray(messageText));
	}
}
//**********************************************************************
///
/// Converts calibration structure config into card channel local downloadable
/// configuration holder, for all channels
///
/// @param[in] pCalStruct - The calibration structure with details of the mode required.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CDigConfig::PulseCalStructTransfer(class CATECal *const pCalStruct) {
	UCHAR chanNo;
	BOOL retValue = FALSE;
	if (pCalStruct != NULL) {
		for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
			// Load configuration for each digital or pulse channel
			m_Config.Cfg.CfgChan[chanNo] = pCalStruct->m_cfgDigPulse.CfgChan[chanNo];
			m_Config.Cfg.CfgChan[chanNo].OutputLatched = TRUE;
		}
		retValue = TRUE;
	}
#if 0
	// Is the pulse card in the upper or lower slots
	if( m_pSlotMapObj->IsCardInTopSlot(m_pIOCard->BoardSlotInstance()) == TRUE )
	{
		for(chanNo = 0; chanNo < TOPSLOT_PULSECHAN_SIZE; chanNo++ )
		{
			if( pCalStruct->m_cfgDigPulse.CfgChan[chanNo].PulseIn == TRUE )
			{
				// Load configuration for each Pulse channel
				m_Config.Cfg.CfgChan[chanNo].PulseIn = pCalStruct->m_cfgDigPulse.CfgChan[chanNo].PulseIn;
				m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqEnum = pCalStruct->m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.acqEnum;
			}
		}
	}
	else
	{
		for(chanNo = 0; chanNo < HW_BOTTOMSLOT_PULSECHAN_SIZE; chanNo++ )
		{
			if( pCalStruct->m_cfgDigPulse.CfgChan[chanNo].PulseIn == TRUE )
			{
				// Load configuration for each Pulse channel
				m_Config.Cfg.CfgChan[chanNo].PulseIn = pCalStruct->m_cfgDigPulse.CfgChan[chanNo].PulseIn;
				m_Config.Cfg.CfgChan[chanNo].ChanCfgInfo.acqEnum = pCalStruct->m_cfgDigPulse.CfgChan[chanNo].ChanCfgInfo.acqEnum;
			}
		}
	}
#endif
	return retValue;
}

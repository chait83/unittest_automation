/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: IOHandler.h
/// @n Desc:	interface for the abstract I/O channel
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 37	Stability Project 1.34.1.1	7/2/2011 4:58:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 36	Stability Project 1.34.1.0	7/1/2011 4:27:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 35	V6 Firmware 1.34		1/19/2007 5:12:52 PM	Graham Waterfield
//		Low risk optimisation
// 34	V6 Firmware 1.33		9/11/2006 8:04:46 PM	Graham Waterfield
//		Prevent RT & ohms expected errors from being placed in the PPQ's to
//		prevent incorrect point being logged and drawn on the chart.
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _IOHANDLER_H
#define _IOHANDLER_H
#if !defined(AFX_IOHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_IOHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "FFConversionInfo.h"
#include "AIConfig.h"
#include "AOConfig.h"
#include "DigConfig.h"
#define DEFAULT_DIGITAL_IO_STATE	FALSE
#define PP_SERVICE_UNKNOWN				0		///< Pre-process service undefined
#define PP_SERVICE_DI_CARD				1		///< Pre-process Digital input service
#define PP_SERVICE_DO_CHAN				2		///< Pre-process Digital output service
#define PP_SERVICE_AO_CHAN				3		///< Pre-process Analogue output service
#define PP_SERVICE_AI_CHAN				4		///< Pre-process Analogue Input service
#define PP_SERVICE_PULSE_CHAN			5		///< Pre-process Pulse input service
#define PP_SERVICE_DI_CHAN				6		///< Digital input channel service
#define INVALID_PPQ_HANDLE	0xffff		///< PPQ handle is invalid
typedef struct _CommonProcessInfo_t {
//	ULONG		PPQmaxWrap;			///< The pre-process queue gearing ratio
//	ULONG		PPCTVtimeStamp;		///< The pre-process queue reading timestamp or first timstamp for all services except DI
	USHORT readingsProcessed;	///< Number of readings processed this batch
	USHORT timestampfreq;	///< The frequency of the board timestamp (in Hz)
	USHORT PPQGearing;			///< The pre-process queue gearing ratio
	USHORT chanEnMask;			///< Channel enabled mask - if 1 then channel is enabled (only used for board service)
//	USHORT		acqRate;			///< The actual acqusition rate of the service
	USHORT readRate;		///< The actual read rate required of the service
	BOOL input;				///< TRUE if card or channel service is an input
	UCHAR PPService;			///< The pre-process service to run
	UCHAR CardSlotNo;			///< The card slot number
	USHORT hPPQ;				///< Handle to pre-process queue
	class CCardSlot *pCard;			///< I/O board data
//	class CConfig *pBoardConfig;	///< Board configuaration
} T_COMMONPROCESSINFO, *T_PCOMMONPROCESSINFO;
typedef struct _AIChanSpecificProcessInfo_t {
	T_PAICFGCHANNEL pChanCfgInfo;		///< Channel configuration
	T_PAIWRKCHANNELCFG pChanWrkInfo;		///< Channel working configuration
} T_AICHANPROCESS, *T_PAICHANPROCESS;
typedef struct _DigChanSpecificProcessInfo_t {
	T_PDIGCFGCHANNEL pChanCfgInfo;		///< Channel configuration
} T_DIGCHANPROCESS, *T_PDIGCHANPROCESS;
typedef struct _AOChanSpecificProcessInfo_t {
	T_PAOCFGCHANNEL pChanCfgInfo;		///< Channel configuration
	T_PAOWRKCHANNELCFG pChanWrkInfo;		///< Channel working configuration
} T_AOCHANPROCESS, *T_PAOCHANPROCESS;
typedef union _UChanInfo_t {
	T_AICHANPROCESS AIChanInfo;			///< AI channel configuration data
	T_DIGCHANPROCESS DigChanInfo;			///< Digital/pulse channel configuration data
	T_AOCHANPROCESS AOChanInfo;			///< AO channel configuration data
} UT_CHANINFO, *UT_PCHANINFO;
typedef struct _ValidFloat_t {
	float Value;
	BOOL ValidValue;
} T_VALIDFLOAT, *T_PVALIDFLOAT;
//////////////*********** Changing USHORT to T_RANGE_COUNTS for RTCOmp and RT CAL ***** //
//@ToDo: Analyse the impact on all tools if there be any dependencies on Size of this struct and 
//Mem layout of the struct
typedef struct _ChanProcessInfo_t {
	T_COMMONPROCESSINFO *pCommon;			///< Common service info
	UT_CHANINFO chanInfo;			///< Channel configuration information
	UCHAR channelNo;			///< Channel number on card
	UCHAR readingsCount;		///< Number of readings obtained this time
	USHORT glbchannelNo;	///< Number of channel (globally known to system)
	USHORT hPPQ;				///< Handle to pre-process queue
	CInputConditioning::IO_BURNOUT_STATUS m_burnOutReportPrfrmd;	///< Burnout error report level required
	T_RANGE_COUNTS m_chanRawRTComp;	///< Channel raw RT compensation readings
	T_RANGE_COUNTS m_chanRawRTCal;	///< Channel raw RT excitation current readings
	USHORT lastTimestamp;		///< The last readings timestamp
	USHORT firstTimestamp;		///< The first readings timestamp
	USHORT timestampInterval;		///< Interval between each board timestamp (in acqsition ticks)
	T_VALIDFLOAT m_chanRTComp;		///< Channel scaled RT compensation readings
	T_VALIDFLOAT m_chanRTCal;		///< Channel scaled RT excitation current readings
	class CFFConversionInfo EngScale;		///< Pen engineering scales conversion info structure
	class CFFConversionInfo *m_pRangeScale;		///< Voltage range scale
	UCHAR PPService;			///< The pre-process service to run
	BOOL m_firstValueLoaded;			///< Has the first channel reading been loaded yet
	BOOL LastOPState;			///< Last output state to card (ignores failsafe setting)
	ULONG m_noOfReadings;		///< Number of readings taken on the channel
	float m_prevReading;		// Previous reading measured
	BOOL m_DampLoaded;		// Whether damping has been preloaded
} T_CHANPROCESSINFO, *T_PCHANPROCESSINFO;
class CIOHandler {
public:
	CIOHandler();
	virtual ~CIOHandler();
	BOOL InitialiseIOHandler(void);
	BOOL InitialiseChanService(T_COMMONPROCESSINFO *const pBoardInfo);
	BOOL IsServiceAnInput(void);
	void SetServiceReadRate(const USHORT readRate);
	void ScheduleNextServiceRead(void);
	void SetServiceAcqRate(const USHORT acqRate);
	USHORT GetServiceReadRate(void) const;
	USHORT GetServiceAcqRate(void);
	T_COMMONPROCESSINFO* GetBoardProcessInfo(void);
	class CPPIOServiceManager* GetServiceManager(void);
	LONGLONG GetTimeServiceRqd(void);
protected:
	T_COMMONPROCESSINFO m_CSInfo;	///< Common Service info
//		BOOL m_input;						///< TRUE if channel is an input
//		USHORT m_acqRate;					///< The actual acqusition rate of the channel
//		USHORT m_readRate;					///< The rate at which the readings are acquired from the card
	/// Data for channel stats and info
//		class CBrdInfo *m_pBrdInfoObj;		///< Board info holder
//		class CBrdStats *m_pBrdStatsObj;	///< Board stats holder
//		class CPPQManager *m_pPPQManager;	///< Pre-process queue manager
	class CInputConditioning *m_pICService;		///< Input conditioning module
private:
	class CPPIOServiceManager *m_pSM;		///< Service manager for board/channel specific handling
	LONGLONG m_nextRunTime;				///< Time till next run
};
#endif // !defined(AFX_IOHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _IOHANDLER_H

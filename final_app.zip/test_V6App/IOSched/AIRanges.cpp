/// @file
/// *******************************************
/// ? Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AIRanges.cpp
/// @n implement the AI Card range class.
/// @author GKW
/// @date 28/07/2004
///
//
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 65	Stability Project 1.60.1.3	7/2/2011 4:55:17 PM	Hemant(HAIL)
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 64	Stability Project 1.60.1.2	7/1/2011 4:37:55 PM	Hemant(HAIL)
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware.
// 63	Stability Project 1.60.1.1	3/17/2011 3:20:07 PM	Hemant(HAIL)
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 62	Stability Project 1.60.1.0	2/15/2011 3:02:03 PM	Hemant(HAIL)
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "CMMDefines.h"
#include "V6Config.h"
#include "TraceDefines.h"
#include "ConfigurationManager.h"
#include "V6IO_AI_InputRanges.H"
#include "V6IOProtocol.h"
#include "V6defines.h"
#include "IOCard.h"
#include "AIRanges.h"
#include "V6globals.h"
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
// Rev 0 board specific
const USHORT EXPECTED_RAW_COUNT_50V_SPAN = 62404;
const USHORT EXPECTED_RAW_COUNT_50V_ZERO = 3133;
const USHORT EXPECTED_RAW_COUNT_25V_SPAN = 62391;
const USHORT EXPECTED_RAW_COUNT_25V_ZERO = 3147;
const USHORT EXPECTED_RAW_COUNT_12V_SPAN = 61201;
const USHORT EXPECTED_RAW_COUNT_12V_ZERO = 4366;
const USHORT EXPECTED_RAW_COUNT_6V_SPAN = 61201;
const USHORT EXPECTED_RAW_COUNT_6V_ZERO = 4337;
const USHORT EXPECTED_RAW_COUNT_3V_SPAN = 61202;
const USHORT EXPECTED_RAW_COUNT_3V_ZERO = 4339;
const USHORT EXPECTED_RAW_COUNT_1_5V_SPAN = 61205;
const USHORT EXPECTED_RAW_COUNT_1_5V_ZERO = 4340;
const USHORT EXPECTED_RAW_COUNT_0_6V_SPAN = 55523;
const USHORT EXPECTED_RAW_COUNT_0_6V_ZERO = 10031;
const USHORT EXPECTED_RAW_COUNT_0_3V_SPAN = 55532;
const USHORT EXPECTED_RAW_COUNT_0_3V_ZERO = 10040;
// Start of common to Rev 0 & 1 boards
const USHORT EXPECTED_RAW_COUNT_1V_SPAN = 58989;
const USHORT EXPECTED_RAW_COUNT_1V_ZERO = 6548;
const USHORT EXPECTED_RAW_COUNT_500mV_SPAN = 58990;
const USHORT EXPECTED_RAW_COUNT_500mV_ZERO = 6547;
const USHORT EXPECTED_RAW_COUNT_250mV_SPAN = 58990;
const USHORT EXPECTED_RAW_COUNT_250mV_ZERO = 6547;
const USHORT EXPECTED_RAW_COUNT_100mV_SPAN = 53747;
const USHORT EXPECTED_RAW_COUNT_100mV_ZERO = 11791;
const USHORT EXPECTED_RAW_COUNT_50mV_SPAN = 53748;
const USHORT EXPECTED_RAW_COUNT_50mV_ZERO = 11789;
const USHORT EXPECTED_RAW_COUNT_25mV_SPAN = 53751;
const USHORT EXPECTED_RAW_COUNT_25mV_ZERO = 11788;
const USHORT EXPECTED_RAW_COUNT_10mV_SPAN = 49560;
const USHORT EXPECTED_RAW_COUNT_10mV_ZERO = 15980;
const USHORT EXPECTED_RAW_COUNT_5mV_SPAN = 49573;
const USHORT EXPECTED_RAW_COUNT_5mV_ZERO = 15973;
// Rev 1 or higher specific
const USHORT ISS1_EXPECTED_RAW_COUNT_50V_SPAN = 57954;
const USHORT ISS1_EXPECTED_RAW_COUNT_50V_ZERO = 7582;
const USHORT ISS1_EXPECTED_RAW_COUNT_25V_SPAN = 57940;
const USHORT ISS1_EXPECTED_RAW_COUNT_25V_ZERO = 7596;
const USHORT ISS1_EXPECTED_RAW_COUNT_12V_SPAN = 56929;
const USHORT ISS1_EXPECTED_RAW_COUNT_12V_ZERO = 8608;
const USHORT ISS1_EXPECTED_RAW_COUNT_6V_SPAN = 56929;
const USHORT ISS1_EXPECTED_RAW_COUNT_6V_ZERO = 8609;
const USHORT ISS1_EXPECTED_RAW_COUNT_3V_SPAN = 56932;
const USHORT ISS1_EXPECTED_RAW_COUNT_3V_ZERO = 8607;
const USHORT ISS1_EXPECTED_RAW_COUNT_1_5V_SPAN = 56933;
const USHORT ISS1_EXPECTED_RAW_COUNT_1_5V_ZERO = 8609;
const USHORT ISS1_EXPECTED_RAW_COUNT_0_6V_SPAN = 52104;
const USHORT ISS1_EXPECTED_RAW_COUNT_0_6V_ZERO = 13445;
const USHORT ISS1_EXPECTED_RAW_COUNT_0_3V_SPAN = 52110;
const USHORT ISS1_EXPECTED_RAW_COUNT_0_3V_ZERO = 13451;
/////////PSR - New AI card (V7AI) ///////////////////////
// Start of Rev A boards
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_1V_SPAN = 45875;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_1V_ZERO = 19680;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_500mV_SPAN = 45834;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_500mV_ZERO = 19710;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_250mV_SPAN = 45830;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_250mV_ZERO = 19702;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_100mV_SPAN = 43219;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_100mV_ZERO = 22320;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_50mV_SPAN = 43217;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_50mV_ZERO = 22307;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_25mV_SPAN = 43226;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_25mV_ZERO = 22314;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_10mV_SPAN = 41150;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_10mV_ZERO = 24428;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_5mV_SPAN = 41175;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_5mV_ZERO = 24459;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_50V_SPAN = 57954;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_50V_ZERO = 7582;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_25V_SPAN = 57940;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_25V_ZERO = 7596;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_12V_SPAN = 56929;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_12V_ZERO = 8608;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_6V_SPAN = 56929;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_6V_ZERO = 8609;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_3V_SPAN = 56932;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_3V_ZERO = 8607;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_1_5V_SPAN = 56933;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_1_5V_ZERO = 8609;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_0_6V_SPAN = 52104;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_0_6V_ZERO = 13445;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_0_3V_SPAN = 52110;
const T_RANGE_COUNTS V7AI_ISSA_EXPECTED_RAW_COUNT_0_3V_ZERO = 13451;
// Range table must be entered lowest range first
static T_BASECHANNELRANGE AIBaseRanges[] = {
// V6AI Voltage ranges for rev A boards (pre-production batch with 50V issues)
		{ V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_50V }, UNITS }, INPUT_50V, UNITS, UNITS, -52.0F,
				52.0F, -50.0F, 50.0F, EXPECTED_RAW_COUNT_50V_ZERO, EXPECTED_RAW_COUNT_50V_SPAN, INTERN50V_0,
				INTERN50V_100 }, { V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_25V }, UNITS },
				INPUT_25V, UNITS, UNITS, -26.0F, 26.0F, -25.0F, 25.0F, EXPECTED_RAW_COUNT_25V_ZERO,
				EXPECTED_RAW_COUNT_25V_SPAN, INTERN25V_0, INTERN25V_100 }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_12V }, UNITS }, INPUT_12V, UNITS, UNITS, -13.0F, 13.0F,
				-12.0F, 12.0F, EXPECTED_RAW_COUNT_12V_ZERO, EXPECTED_RAW_COUNT_12V_SPAN, INTERN12V_0, INTERN12V_100 }, {
				V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_6V }, UNITS }, INPUT_6V, UNITS, UNITS,
				-6.5F, 6.5F, -6.0F, 6.0F, EXPECTED_RAW_COUNT_6V_ZERO, EXPECTED_RAW_COUNT_6V_SPAN, INTERN6V_0,
				INTERN6V_100 }, { V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_3V }, UNITS }, INPUT_3V,
				UNITS, UNITS, -3.25F, 3.25F, -3.0F, 3.0F, EXPECTED_RAW_COUNT_3V_ZERO, EXPECTED_RAW_COUNT_3V_SPAN,
				INTERN3V_0, INTERN3V_100 }, { V6AI_ISSUE_0,
				{ { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_1_5V }, UNITS }, INPUT_1_5V, UNITS, UNITS, -1.6F, 1.6F,
				-1.5F, 1.5F, EXPECTED_RAW_COUNT_1_5V_ZERO, EXPECTED_RAW_COUNT_1_5V_SPAN, INTERN1_5_0, INTERN1_5_100 },
//	{ V6AI_ISSUE_0, { {AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_1000mV}, UNITS },
//					INPUT_1000mV, MILLI, UNITS, -1100.0F, 1100.0F, -1000.0F, 1000.0F,
//					EXPECTED_RAW_COUNT_1V_ZERO, EXPECTED_RAW_COUNT_1V_SPAN,
//					INTERN1000mV_0, INTERN1000mV_100 }, { V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_1000mV }, MILLI }, INPUT_1000mV, MILLI, UNITS, -1.1F, 1.1F, -1.0F, 1.0F, EXPECTED_RAW_COUNT_1V_ZERO, EXPECTED_RAW_COUNT_1V_SPAN, INTERN1000mV_0, INTERN1000mV_100 },
		{ V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_0_6V }, UNITS }, INPUT_0_6V, UNITS, MILLI,
				-800.0F, 800.0F, -600.0F, 600.0F, EXPECTED_RAW_COUNT_0_6V_ZERO, EXPECTED_RAW_COUNT_0_6V_SPAN,
				INTERN0_6_0, INTERN0_6_100 }, { V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_0_3V },
				UNITS }, INPUT_0_3V, UNITS, MILLI, -400.0F, 400.0F, -300.0F, 300.0F, EXPECTED_RAW_COUNT_0_3V_ZERO,
				EXPECTED_RAW_COUNT_0_3V_SPAN, INTERN0_3_0, INTERN0_3_100 }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_500mV }, MILLI }, INPUT_500mV, MILLI, MILLI, -600.0F, 600.0F,
				-500.0F, 500.0F, EXPECTED_RAW_COUNT_500mV_ZERO, EXPECTED_RAW_COUNT_500mV_SPAN, INTERN500mV_0,
				INTERN500mV_100 }, { V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_250mV }, MILLI },
				INPUT_250mV, MILLI, MILLI, -300.0F, 300.0F, -250.0F, 250.0F, EXPECTED_RAW_COUNT_250mV_ZERO,
				EXPECTED_RAW_COUNT_250mV_SPAN, INTERN250mV_0, INTERN250mV_100 }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_100mV }, MILLI }, INPUT_100mV, MILLI, MILLI, -150.0F, 150.0F,
				-100.0F, 100.0F, EXPECTED_RAW_COUNT_100mV_ZERO, EXPECTED_RAW_COUNT_100mV_SPAN, INTERN100mV_0,
				INTERN100mV_100 }, { V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_50mV }, MILLI },
				INPUT_50mV, MILLI, MILLI, -75.0F, 75.0F, -50.0F, 50.0F, EXPECTED_RAW_COUNT_50mV_ZERO,
				EXPECTED_RAW_COUNT_50mV_SPAN, INTERN50mV_0, INTERN50mV_100 },
		{ V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_25mV }, MILLI }, INPUT_25mV, MILLI, MILLI,
				-36.0F, 36.0F, -25.0F, 25.0F, EXPECTED_RAW_COUNT_25mV_ZERO, EXPECTED_RAW_COUNT_25mV_SPAN, INTERN25mV_0,
				INTERN25mV_100 }, { V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_10mV }, MILLI },
				INPUT_10mV, MILLI, MILLI, -18.0F, 18.0F, -10.0F, 10.0F, EXPECTED_RAW_COUNT_10mV_ZERO,
				EXPECTED_RAW_COUNT_10mV_SPAN, INTERN10mV_0, INTERN10mV_100 }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_5mV }, MILLI }, INPUT_5mV, MILLI, MILLI, -9.0F, 9.0F, -5.0F,
				5.0F, EXPECTED_RAW_COUNT_5mV_ZERO, EXPECTED_RAW_COUNT_5mV_SPAN, INTERN5mV_0, INTERN5mV_100 },
		// V6AI Voltage ranges for Rev B and higher boards (1st production batch)
		{ V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_50V }, UNITS }, INPUT_50V, UNITS, UNITS, -52.0F,
				52.0F, -50.0F, 50.0F, ISS1_EXPECTED_RAW_COUNT_50V_ZERO, ISS1_EXPECTED_RAW_COUNT_50V_SPAN, INTERN50V_0,
				INTERN50V_100 }, { V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_25V }, UNITS },
				INPUT_25V, UNITS, UNITS, -26.0F, 26.0F, -25.0F, 25.0F, ISS1_EXPECTED_RAW_COUNT_25V_ZERO,
				ISS1_EXPECTED_RAW_COUNT_25V_SPAN, INTERN25V_0, INTERN25V_100 }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_12V }, UNITS }, INPUT_12V, UNITS, UNITS, -13.0F, 13.0F,
				-12.0F, 12.0F, ISS1_EXPECTED_RAW_COUNT_12V_ZERO, ISS1_EXPECTED_RAW_COUNT_12V_SPAN, INTERN12V_0,
				INTERN12V_100 }, { V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_6V }, UNITS }, INPUT_6V,
				UNITS, UNITS, -6.5F, 6.5F, -6.0F, 6.0F, ISS1_EXPECTED_RAW_COUNT_6V_ZERO,
				ISS1_EXPECTED_RAW_COUNT_6V_SPAN, INTERN6V_0, INTERN6V_100 }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_3V }, UNITS }, INPUT_3V, UNITS, UNITS, -3.25F, 3.25F, -3.0F,
				3.0F, ISS1_EXPECTED_RAW_COUNT_3V_ZERO, ISS1_EXPECTED_RAW_COUNT_3V_SPAN, INTERN3V_0, INTERN3V_100 }, {
				V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_1_5V }, UNITS }, INPUT_1_5V, UNITS, UNITS,
				-1.6F, 1.6F, -1.5F, 1.5F, ISS1_EXPECTED_RAW_COUNT_1_5V_ZERO, ISS1_EXPECTED_RAW_COUNT_1_5V_SPAN,
				INTERN1_5_0, INTERN1_5_100 },
//	{ V6AI_ISSUE_1, { {AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_1000mV}, UNITS },
//					INPUT_1000mV, MILLI, UNITS, -1100.0F, 1100.0F, -1000.0F, 1000.0F,
//					EXPECTED_RAW_COUNT_1V_ZERO, EXPECTED_RAW_COUNT_1V_SPAN,
//					INTERN1000mV_0, INTERN1000mV_100 }, { V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_1000mV }, MILLI }, INPUT_1000mV, MILLI, UNITS, -1.1F, 1.1F, -1.0F, 1.0F, EXPECTED_RAW_COUNT_1V_ZERO, EXPECTED_RAW_COUNT_1V_SPAN, INTERN1000mV_0, INTERN1000mV_100 },
		{ V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_0_6V }, UNITS }, INPUT_0_6V, UNITS, MILLI,
				-800.0F, 800.0F, -600.0F, 600.0F, ISS1_EXPECTED_RAW_COUNT_0_6V_ZERO, ISS1_EXPECTED_RAW_COUNT_0_6V_SPAN,
				INTERN0_6_0, INTERN0_6_100 }, { V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_0_3V },
				UNITS }, INPUT_0_3V, UNITS, MILLI, -400.0F, 400.0F, -300.0F, 300.0F, ISS1_EXPECTED_RAW_COUNT_0_3V_ZERO,
				ISS1_EXPECTED_RAW_COUNT_0_3V_SPAN, INTERN0_3_0, INTERN0_3_100 }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_500mV }, MILLI }, INPUT_500mV, MILLI, MILLI, -600.0F, 600.0F,
				-500.0F, 500.0F, EXPECTED_RAW_COUNT_500mV_ZERO, EXPECTED_RAW_COUNT_500mV_SPAN, INTERN500mV_0,
				INTERN500mV_100 }, { V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_250mV }, MILLI },
				INPUT_250mV, MILLI, MILLI, -300.0F, 300.0F, -250.0F, 250.0F, EXPECTED_RAW_COUNT_250mV_ZERO,
				EXPECTED_RAW_COUNT_250mV_SPAN, INTERN250mV_0, INTERN250mV_100 }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_100mV }, MILLI }, INPUT_100mV, MILLI, MILLI, -150.0F, 150.0F,
				-100.0F, 100.0F, EXPECTED_RAW_COUNT_100mV_ZERO, EXPECTED_RAW_COUNT_100mV_SPAN, INTERN100mV_0,
				INTERN100mV_100 }, { V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_50mV }, MILLI },
				INPUT_50mV, MILLI, MILLI, -75.0F, 75.0F, -50.0F, 50.0F, EXPECTED_RAW_COUNT_50mV_ZERO,
				EXPECTED_RAW_COUNT_50mV_SPAN, INTERN50mV_0, INTERN50mV_100 },
		{ V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_25mV }, MILLI }, INPUT_25mV, MILLI, MILLI,
				-36.0F, 36.0F, -25.0F, 25.0F, EXPECTED_RAW_COUNT_25mV_ZERO, EXPECTED_RAW_COUNT_25mV_SPAN, INTERN25mV_0,
				INTERN25mV_100 }, { V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_10mV }, MILLI },
				INPUT_10mV, MILLI, MILLI, -18.0F, 18.0F, -10.0F, 10.0F, EXPECTED_RAW_COUNT_10mV_ZERO,
				EXPECTED_RAW_COUNT_10mV_SPAN, INTERN10mV_0, INTERN10mV_100 }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_5mV }, MILLI }, INPUT_5mV, MILLI, MILLI, -9.0F, 9.0F, -5.0F,
				5.0F, EXPECTED_RAW_COUNT_5mV_ZERO, EXPECTED_RAW_COUNT_5mV_SPAN, INTERN5mV_0, INTERN5mV_100 },
		// V7AI board Voltage ranges for Rev A and higher boards (1st production batch)
		{ V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_50V }, UNITS }, INPUT_50V, UNITS, UNITS, -52.0F,
				52.0F, -50.0F, 50.0F, V7AI_ISSA_EXPECTED_RAW_COUNT_50V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_50V_SPAN,
				V7AI_ISSA_INTERN50V_0, V7AI_ISSA_INTERN50V_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_25V }, UNITS }, INPUT_25V, UNITS, UNITS, -26.0F, 26.0F, -25.0F, 25.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_25V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_25V_SPAN, V7AI_ISSA_INTERN25V_0,
				V7AI_ISSA_INTERN25V_100 }, { V7AI_ISSUE_A,
				{ { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_12V }, UNITS }, INPUT_12V, UNITS, UNITS, -13.0F, 13.0F,
				-12.0F, 12.0F, V7AI_ISSA_EXPECTED_RAW_COUNT_12V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_12V_SPAN,
				V7AI_ISSA_INTERN12V_0, V7AI_ISSA_INTERN12V_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_6V }, UNITS }, INPUT_6V, UNITS, UNITS, -6.5F, 6.5F, -6.0F, 6.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_6V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_6V_SPAN, V7AI_ISSA_INTERN6V_0,
				V7AI_ISSA_INTERN6V_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_3V }, UNITS },
				INPUT_3V, UNITS, UNITS, -3.25F, 3.25F, -3.0F, 3.0F, V7AI_ISSA_EXPECTED_RAW_COUNT_3V_ZERO,
				V7AI_ISSA_EXPECTED_RAW_COUNT_3V_SPAN, V7AI_ISSA_INTERN3V_0, V7AI_ISSA_INTERN3V_100 }, { V7AI_ISSUE_A, {
				{ AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_1_5V }, UNITS }, INPUT_1_5V, UNITS, UNITS, -1.6F, 1.6F,
				-1.5F, 1.5F, V7AI_ISSA_EXPECTED_RAW_COUNT_1_5V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_1_5V_SPAN,
				V7AI_ISSA_INTERN1_5_0, V7AI_ISSA_INTERN1_5_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_1000mV }, MILLI }, INPUT_1000mV, MILLI, UNITS, -1.1F, 1.1F, -1.0F, 1.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_1V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_1V_SPAN, V7AI_ISSA_INTERN1000mV_0,
				V7AI_ISSA_INTERN1000mV_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_0_6V },
				UNITS }, INPUT_0_6V, UNITS, MILLI, -800.0F, 800.0F, -600.0F, 600.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_0_6V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_0_6V_SPAN, V7AI_ISSA_INTERN0_6_0,
				V7AI_ISSA_INTERN0_6_100 }, { V7AI_ISSUE_A,
				{ { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_0_3V }, UNITS }, INPUT_0_3V, UNITS, MILLI, -400.0F,
				400.0F, -300.0F, 300.0F, V7AI_ISSA_EXPECTED_RAW_COUNT_0_3V_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_0_3V_SPAN,
				V7AI_ISSA_INTERN0_3_0, V7AI_ISSA_INTERN0_3_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_500mV }, MILLI }, INPUT_500mV, MILLI, MILLI, -600.0F, 600.0F, -500.0F, 500.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_500mV_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_500mV_SPAN,
				V7AI_ISSA_INTERN500mV_0, V7AI_ISSA_INTERN500mV_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_250mV }, MILLI }, INPUT_250mV, MILLI, MILLI, -300.0F, 300.0F, -250.0F, 250.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_250mV_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_250mV_SPAN,
				V7AI_ISSA_INTERN250mV_0, V7AI_ISSA_INTERN250mV_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_100mV }, MILLI }, INPUT_100mV, MILLI, MILLI, -150.0F, 150.0F, -100.0F, 100.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_100mV_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_100mV_SPAN,
				V7AI_ISSA_INTERN100mV_0, V7AI_ISSA_INTERN100mV_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_50mV }, MILLI }, INPUT_50mV, MILLI, MILLI, -75.0F, 75.0F, -50.0F, 50.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_50mV_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_50mV_SPAN, V7AI_ISSA_INTERN50mV_0,
				V7AI_ISSA_INTERN50mV_100 }, { V7AI_ISSUE_A,
				{ { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_25mV }, MILLI }, INPUT_25mV, MILLI, MILLI, -36.0F, 36.0F,
				-25.0F, 25.0F, V7AI_ISSA_EXPECTED_RAW_COUNT_25mV_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_25mV_SPAN,
				V7AI_ISSA_INTERN25mV_0, V7AI_ISSA_INTERN25mV_100 }, { V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_VOLTS,
				LINEAR_VOLTS_10mV }, MILLI }, INPUT_10mV, MILLI, MILLI, -18.0F, 18.0F, -10.0F, 10.0F,
				V7AI_ISSA_EXPECTED_RAW_COUNT_10mV_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_10mV_SPAN, V7AI_ISSA_INTERN10mV_0,
				V7AI_ISSA_INTERN10mV_100 }, { V7AI_ISSUE_A,
				{ { AI_CHANNEL_TYPE_LINEAR_VOLTS, LINEAR_VOLTS_5mV }, MILLI }, INPUT_5mV, MILLI, MILLI, -9.0F, 9.0F,
				-5.0F, 5.0F, V7AI_ISSA_EXPECTED_RAW_COUNT_5mV_ZERO, V7AI_ISSA_EXPECTED_RAW_COUNT_5mV_SPAN,
				V7AI_ISSA_INTERN5mV_0, V7AI_ISSA_INTERN5mV_100 }, };
static T_DEVICE ChanDevice[] = {
///< 100 ohm shunt resistor (for current measurement)
		{ SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_100_OHM, TRUE, 0, 0, 0, 100.0F, AI_CHANNEL_TYPE_LINEAR_OHMS, UNITS }, ///< 10 ohm shunt resistor (for current measurement)
		{ SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_10_OHM, TRUE, 0, 0, 0, 10.0F, AI_CHANNEL_TYPE_LINEAR_OHMS, UNITS }, ///< 250 ohm shunt resistor (for current measurement)
		{ SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_250_OHM, TRUE, 0, 0, 0, 100.0F, AI_CHANNEL_TYPE_LINEAR_OHMS, UNITS }, ///< Low output constant current generator
		{ CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA, FALSE, 0, 0, 0, DEFAULT_CONSTANT_CURRENT_LOW_MA,
				AI_CHANNEL_TYPE_LINEAR_AMPS, MILLI }, ///< High output constant current generator
		{ CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_1_39MA, FALSE, 0, 0, 0, DEFAULT_CONSTANT_CURRENT_HIGH_MA,
				AI_CHANNEL_TYPE_LINEAR_AMPS, MILLI } };
static T_EXTENDEDCHANNELRANGE ExAIRanges[] = {
// For 20mA range, using a 10 ohm shunt, use the 250mV range 0-200mV
// For 10 ohms use 25mV range 12mV-26.1mV (assumming current source = 1.39mA)
// For 200 ohms use 150mV range 0-75mV (assumming current source = 0.25mA, actual was measured @ 0.24mA)
// For 500 ohms use 150mV range 0-125mV (assumming current source = 0.25mA, actual was measured @ 0.24mA)
// For 1000 ohms use 300mV range 0-250mV (assumming current source = 0.25mA)
// For 2000 ohms use 600mV range 0-500mV (assumming current source = 0.25mA)
// For 4000 ohms use 1000mV range 0-1000mV (assumming current source = 0.25mA)
// Built-in Resistance ranges
// The maximum resistance range available are calculated with an maximum excitation current tolerence of 4.5%
// Note: most RTD ranges allow the nominal range plus 100 ohm single lead resistance.
// The CU10 only allows 15 ohms single lead resistance
		{ V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_10_OHM }, UNITS }, LINEAR_VOLTS_50mV, 0.0F, 50.0F, 0.0F,
				50.0F, 0.0F, 10.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_1_39MA }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_200_OHM }, UNITS }, LINEAR_VOLTS_50mV, 0.0F, 296.0F, 0.0F, 296.0F,
				0.0F, 200.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_500_OHM }, UNITS }, LINEAR_VOLTS_100mV, 0.0F, 592.0F, 0.0F, 592.0F,
				0.0F, 500.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_1_KOHM }, UNITS }, LINEAR_VOLTS_250mV, 0.0F, 1184.0F, 0.0F, 1184.0F,
				0.0F, 1000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_2_KOHM }, UNITS }, LINEAR_VOLTS_500mV, 0.0F, 2368.0F, 0.0F, 2368.0F,
				0.0F, 2000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_0, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_4_KOHM }, UNITS }, LINEAR_VOLTS_1000mV, 0.0F, 4349.0F, 0.0F,
				4349.0F, 0.0F, 4000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA },
		{ V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_10_OHM }, UNITS }, LINEAR_VOLTS_50mV, 0.0F, 50.0F, 0.0F,
				50.0F, 0.0F, 10.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_1_39MA }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_200_OHM }, UNITS }, LINEAR_VOLTS_50mV, 0.0F, 296.0F, 0.0F, 296.0F,
				0.0F, 200.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_500_OHM }, UNITS }, LINEAR_VOLTS_100mV, 0.0F, 592.0F, 0.0F, 592.0F,
				0.0F, 500.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_1_KOHM }, UNITS }, LINEAR_VOLTS_250mV, 0.0F, 1184.0F, 0.0F, 1184.0F,
				0.0F, 1000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_2_KOHM }, UNITS }, LINEAR_VOLTS_500mV, 0.0F, 2368.0F, 0.0F, 2368.0F,
				0.0F, 2000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V6AI_ISSUE_1, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_4_KOHM }, UNITS }, LINEAR_VOLTS_1000mV, 0.0F, 4349.0F, 0.0F,
				4349.0F, 0.0F, 4000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA },
		{ V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_10_OHM }, UNITS }, LINEAR_VOLTS_50mV, 0.0F, 50.0F, 0.0F,
				50.0F, 0.0F, 10.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_1_39MA }, { V7AI_ISSUE_A, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_200_OHM }, UNITS }, LINEAR_VOLTS_50mV, 0.0F, 296.0F, 0.0F, 296.0F,
				0.0F, 200.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V7AI_ISSUE_A, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_500_OHM }, UNITS }, LINEAR_VOLTS_100mV, 0.0F, 592.0F, 0.0F, 592.0F,
				0.0F, 500.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V7AI_ISSUE_A, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_1_KOHM }, UNITS }, LINEAR_VOLTS_250mV, 0.0F, 1184.0F, 0.0F, 1184.0F,
				0.0F, 1000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V7AI_ISSUE_A, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_2_KOHM }, UNITS }, LINEAR_VOLTS_500mV, 0.0F, 2368.0F, 0.0F, 2368.0F,
				0.0F, 2000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA }, { V7AI_ISSUE_A, { {
				AI_CHANNEL_TYPE_LINEAR_OHMS, LINEAR_4_KOHM }, UNITS }, LINEAR_VOLTS_1000mV, 0.0F, 4349.0F, 0.0F,
				4349.0F, 0.0F, 4000.0F, UNITS, CONSTANT_CURRENT_DEVICE, CONSTANT_CURRENT_0_25MA },
		// Built-in Current ranges
		{ V6AI_ISSUE_0, { { AI_CHANNEL_TYPE_LINEAR_AMPS, LINEAR_AMPS_0mA_20mA }, MILLI }, LINEAR_VOLTS_250mV, -25.0F,
				25.0F, -25.0F, 25.0F, 0.0F, 20.0F, MILLI, SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_10_OHM }, { V6AI_ISSUE_0,
				{ { AI_CHANNEL_TYPE_LINEAR_AMPS, LINEAR_AMPS_4mA_20mA }, MILLI }, LINEAR_VOLTS_250mV, -25.0F, 25.0F,
				-25.0F, 25.0F, 4.0F, 20.0F, MILLI, SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_10_OHM },
		{ V6AI_ISSUE_1, { { AI_CHANNEL_TYPE_LINEAR_AMPS, LINEAR_AMPS_0mA_20mA }, MILLI }, LINEAR_VOLTS_250mV, -25.0F,
				25.0F, -25.0F, 25.0F, 0.0F, 20.0F, MILLI, SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_10_OHM }, { V6AI_ISSUE_1,
				{ { AI_CHANNEL_TYPE_LINEAR_AMPS, LINEAR_AMPS_4mA_20mA }, MILLI }, LINEAR_VOLTS_250mV, -25.0F, 25.0F,
				-25.0F, 25.0F, 4.0F, 20.0F, MILLI, SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_10_OHM },
		{ V7AI_ISSUE_A, { { AI_CHANNEL_TYPE_LINEAR_AMPS, LINEAR_AMPS_0mA_20mA }, MILLI }, LINEAR_VOLTS_250mV, -25.0F,
				25.0F, -25.0F, 25.0F, 0.0F, 20.0F, MILLI, SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_10_OHM }, { V7AI_ISSUE_A,
				{ { AI_CHANNEL_TYPE_LINEAR_AMPS, LINEAR_AMPS_4mA_20mA }, MILLI }, LINEAR_VOLTS_250mV, -25.0F, 25.0F,
				-25.0F, 25.0F, 4.0F, 20.0F, MILLI, SHUNT_RESITOR_DEVICE, SHUNT_RESITOR_10_OHM } };
CAIRanges *CAIRanges::m_pInstance = NULL;
QMutex CAIRanges::m_CreationMutex;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAIRanges::CAIRanges() {
//	qDebug("Create new CAIRanges\n");
}
CAIRanges::~CAIRanges() {
//	qDebug("Delete CAIRanges\n");
}
//**********************************************************************
///
/// Instance creation of CAIConfig singleton
///
/// @return		pointer to single instance of CAIConfig
///
//**********************************************************************
CAIRanges* CAIRanges::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) { // An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CAIRanges;
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			/// Handle Error
			LogInternalError("Could not create AIRanges");
			V6WarningMessageBox(NULL, "AIRanges WaitForSingleObject Error", "AI Ranges Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
/// @return		nothing
//**********************************************************************
void CAIRanges::CleanUp() {
	// Delete the range singleton
	if (NULL != m_pInstance) {
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//**********************************************************************
/// GetRangeRevision
///
/// Obtain the range capabilities revision from the board revision
///
/// @param[in] boardType - The I/O board type.
/// @param[in] HWRev - The AI board revision identified.
///
/// @return		The AI range revision ID
//**********************************************************************
UCHAR CAIRanges::GetRangeRevision(const UCHAR boardType, const UCHAR HWRev) const {
	UCHAR rangeIssue = V6AI_ISSUE_1; //Ensure to have the backward compatibility with old boards and old revisions
	if ( BOARD_AI == boardType) {
		if ( V7AI_REV_A_BOARD <= HWRev) {
			rangeIssue = V7AI_ISSUE_A;
		} else if ( REV_A_BOARD == HWRev) {
			rangeIssue = V6AI_ISSUE_0; //Ensure to have the backward compatibility
		}
	}
	return rangeIssue;
}
//**********************************************************************
/// GetRangeReadTolerence
///
/// indexOfs the read voltage tolerance for a range
///
/// @param[in] rangeNo - Range number to use.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[in] tolerence - The AI boards range tolerence desired.
/// @param[out] pzeroUpperLimit - The AI boards zero upper limit allowed.
/// @param[out] pzeroLowerLimit - The AI boards zero lower limit allowed.
/// @param[out] pspanUpperLimit - The AI boards span upper limit allowed.
/// @param[out] pspanLowerLimit - The AI boards span lower limit allowed.
///
/// @return		TRUE if the range limits were calculated; otherwise FALSE
//**********************************************************************
BOOL CAIRanges::GetRangeReadTolerence(const USHORT RangeCode, const UCHAR RangeRev, const float tolerence,
T_RANGE_COUNTS *const pzeroUpperLimit,
T_RANGE_COUNTS *const pzeroLowerLimit,
T_RANGE_COUNTS *const pspanUpperLimit,
T_RANGE_COUNTS *const pspanLowerLimit) const {
	const T_BASECHANNELRANGE *pBaseRange = NULL;
	const T_EXTENDEDCHANNELRANGE *pExtRange = NULL;
	const T_RANGE_COUNTS rawmidPoint = RAW_VALUES_MID_POINT;
	T_RANGE_COUNTS normRaw100;
	T_RANGE_COUNTS normRaw0;
	BOOL rangeMatched = FALSE;
	// If range is linear voltage then find apporiate core board range
	{ // Ignore if the RangeCode or RangeRev does not match
		pBaseRange = MatchBaseRange(RangeCode, RangeRev);
		if (pBaseRange != NULL) {
			normRaw100 = pBaseRange->Raw100 - rawmidPoint;
			normRaw0 = rawmidPoint - pBaseRange->Raw0;
			*pzeroLowerLimit = static_cast<T_RANGE_COUNTS>(static_cast<float>(rawmidPoint)
					- (static_cast<float>(normRaw0) * static_cast<float>(1 + tolerence)));
			*pzeroUpperLimit = static_cast<T_RANGE_COUNTS>(static_cast<float>(rawmidPoint)
					- (static_cast<float>(normRaw0) * static_cast<float>(1 - tolerence)));
			*pspanLowerLimit = static_cast<T_RANGE_COUNTS>(static_cast<float>(rawmidPoint)
					+ (static_cast<float>(normRaw100) * static_cast<float>(1 - tolerence)));
			*pspanUpperLimit = static_cast<T_RANGE_COUNTS>(static_cast<float>(rawmidPoint)
					+ (static_cast<float>(normRaw100) * static_cast<float>(1 + tolerence)));
			rangeMatched = TRUE;
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// CheckUserPointsWithinRange
///
/// Checks whether the the upper and lower points are within the capabilities of the range
///
/// @param[in] rangeNo - Range ID to check.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[in] tolerence - The AI boards range tolerence desired.
/// @param[in] UpperLimit - The AI boards range upper limit desired.
/// @param[in] LowerLimit - The AI boards range lower limit desired.
///
/// @return		TRUE if the range limits were calculated; otherwise FALSE
//**********************************************************************
BOOL CAIRanges::CheckUserPointsWithinRange(const T_AIRANGE *const pRangeCode, const UCHAR RangeRev, T_RANGE UpperRange,
T_RANGE LowerRange) const {
	float lowerRangeLimit = 0.0F;
	float upperRangeLimit = 0.0F;
	BOOL retValue = FALSE;
	if (GetChannelRange(pRangeCode, RangeRev, &upperRangeLimit, &lowerRangeLimit) != NULL) { // indexOf the range of the preset range selected and check that user limits are within
		if ((LowerRange >= lowerRangeLimit) && (UpperRange <= upperRangeLimit)) {
			retValue = TRUE;
		}
	}
	return retValue;
}
//**********************************************************************
/// GetBaseRangeChannelCalPoints
///
/// indexOfs the base range calibration points
///
/// @param[in] rangeNo - Range number to use.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[in] tolerence - The AI boards range tolerence desired.
/// @param[out] pUpperLimit - The AI boards range upper limit desired.
/// @param[out] pLowerLimit - The AI boards range lower limit desired.
///
/// @return		TRUE if the range limits were calculated; otherwise FALSE
//**********************************************************************
BOOL CAIRanges::GetBaseRangeChannelCalPoints(const USHORT RangeCode, const UCHAR RangeRev, T_RANGE *pUpperRange,
T_RANGE *pLowerRange, IO_MEASURE_UNITS *pUnits) const {
	const T_BASECHANNELRANGE *pBaseRange = NULL;
	BOOL rangeMatched = FALSE;
	// If range is linear voltage then find apporiate core board range
	{ // Ignore if the RangeCode or RangeRev does not match
		pBaseRange = MatchBaseRange(RangeCode, RangeRev);
		if (pBaseRange != NULL) {
			*pLowerRange = pBaseRange->LowerCal;
			*pUpperRange = pBaseRange->UpperCal;
			*pUnits = pBaseRange->RangeUnits;
			rangeMatched = TRUE;
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// MatchBaseRange
///
/// indexOfs a base range match
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
///
/// @return		The channel range if found; otherwise NULL
//**********************************************************************
const T_BASECHANNELRANGE* CAIRanges::MatchBaseRange(const USHORT RangeCode, const UCHAR RangeRev) const {
	UCHAR rangeNo;
	T_BASECHANNELRANGE *pRangeMatched = NULL;
	USHORT RangeCount = GetBaseTableSize();
	// Loop for all base ranges in the version/range available table
	for (rangeNo = 0; rangeNo < RangeCount; rangeNo++) { // Ignore if the RangeCode or RangeRev does not match
		if ((AIBaseRanges[rangeNo].BoardVer == RangeRev)
				&& (AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum == RangeCode)) {
			pRangeMatched = &AIBaseRanges[rangeNo];
			break;
		}
	}
	return pRangeMatched;
}
//**********************************************************************
/// MatchBaseRange
///
/// indexOfs a base range match
///
/// @param[in] pRangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
///
/// @return		The channel range if found; otherwise NULL
//**********************************************************************
const T_BASECHANNELRANGE* CAIRanges::MatchBaseRange(const T_AIRANGE *const pRangeCode, const UCHAR RangeRev) const {
	UCHAR rangeNo;
	T_BASECHANNELRANGE *pRangeMatched = NULL;
	USHORT RangeCount = GetBaseTableSize();
	// Loop for all base ranges in the version/range available table
	for (rangeNo = 0; rangeNo < RangeCount; rangeNo++) { // Ignore if the RangeCode or RangeRev does not match
		if ((AIBaseRanges[rangeNo].BoardVer == RangeRev) && (DoesBaseRangeMatch(rangeNo, pRangeCode) == TRUE)) {
			pRangeMatched = &AIBaseRanges[rangeNo];
			break;
		}
	}
	return pRangeMatched;
}
//**********************************************************************
/// MatchExtendedRange
///
/// indexOfs an extended range match
///
/// @param[in] pRangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
///
/// @return		The channel range if found; otherwise NULL
//**********************************************************************
const T_EXTENDEDCHANNELRANGE* CAIRanges::MatchExtendedRange(const T_AIRANGE *const pRangeCode,
		const UCHAR RangeRev) const {
	UCHAR rangeNo;
	T_EXTENDEDCHANNELRANGE *pRangeMatched = NULL;
	USHORT RangeCount = GetExtendedTableSize();
	// Loop for all base ranges in the version/range available table
	for (rangeNo = 0; rangeNo < RangeCount; rangeNo++) { // Ignore if the RangeCode or RangeRev does not match
		if ((ExAIRanges[rangeNo].BoardVer == RangeRev) && (DoesBaseRangeMatch(rangeNo, pRangeCode) == TRUE)) {
			pRangeMatched = &ExAIRanges[rangeNo];
		}
	}
	return pRangeMatched;
}
//**********************************************************************
/// GetHWRangeUnits
///
/// indexOfs the voltage range of the requested range, for a given board revision
///
/// @param[in] RangeRev - The AI range revision to be found (assumes a valid range number and revision).
/// @param[in] RangeEnum - The AI range number to be found (assumes a valid range number and revision).
///
/// @return		The range channels hardware units
//**********************************************************************
IO_MEASURE_UNITS CAIRanges::GetHWRangeUnits(const UCHAR RangeRev, const USHORT RangeEnum) const {
	IO_MEASURE_UNITS HWUnits = MILLI;
	const T_BASECHANNELRANGE *pRange = NULL;
	pRange = MatchBaseRange(RangeEnum, RangeRev);
	if (pRange != NULL)
		HWUnits = pRange->HWRangeUnits;
	return HWUnits;
}
//**********************************************************************
/// GetRangeUnits
///
/// indexOfs the display units of the requested range, for a given board revision
///
/// @param[in] RangeRev - The AI range revision to be found (assumes a valid range number and revision).
/// @param[in] RangeEnum - The AI range number to be found (assumes a valid range number and revision).
///
/// @return		The range display units
//**********************************************************************
IO_MEASURE_UNITS CAIRanges::GetRangeUnits(const UCHAR RangeRev, const USHORT RangeEnum) const {
	IO_MEASURE_UNITS Units = MILLI;
	const T_BASECHANNELRANGE *pRange = NULL;
	pRange = MatchBaseRange(RangeEnum, RangeRev);
	if (pRange != NULL)
		Units = pRange->RangeUnits;
	return Units;
}
//**********************************************************************
/// GetUserRangeClosestMatch
///
/// indexOfs the voltage range that supports the whole of the requested range, for a given board revision
///
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[in] RangeType - The AI boards Range type desired.
/// @param[in] UpperRange - The AI boards upper range limit desired.
/// @param[in] LowerRange - The AI boards lower range limit desired.
/// @param[in] engUnits - The AI boards range limit desired - units.
///
/// @return		The range ID code if a suitable one is found; otherwise INVALID_RANGE
/// @note: 4% under and overrange is always guarenteed by the hardware
//**********************************************************************
UCHAR CAIRanges::GetUserRangeClosestMatch(const UCHAR RangeRev, const UCHAR RangeType, const T_RANGE UpperRange,
		const T_RANGE LowerRange, const USHORT engUnits) const {
	short rangeCount = static_cast<short>(GetBaseTableSize());
	short rangeNo;
	T_RANGE CompUpperRange = UpperRange;
	T_RANGE CompLowerRange = LowerRange;
	USHORT compEngUnits = engUnits;
	USHORT rangeNoMatched = INVALID_RANGE;
	UCHAR rangeMatched = INVALID_RANGE;
	// If range is linear voltage then find apporiate core board range
	if (RangeType == AI_CHANNEL_TYPE_LINEAR_VOLTS) { // Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if RangeRev does not match
			if (AIBaseRanges[rangeNo].BoardVer == RangeRev) {
				if (AIBaseRanges[rangeNo].RangeUnits != AIBaseRanges[rangeNo].HWRangeUnits) { // Convert depending upon direction required
					if (AIBaseRanges[rangeNo].HWRangeUnits == MILLI) {
						CompUpperRange = UpperRange / 1000;
						CompLowerRange = LowerRange / 1000;
						compEngUnits = MILLI;
					} else {
						CompUpperRange = UpperRange * 1000;
						CompLowerRange = LowerRange * 1000;
						compEngUnits = UNITS;
					}
				} else {
					CompUpperRange = UpperRange;
					CompLowerRange = LowerRange;
					compEngUnits = engUnits;
				}
				// Check desired range is within range capabilities then range is the lowest available range that statisfies requirement
				if (((AIBaseRanges[rangeNo].LowerCal <= CompLowerRange)
						&& (AIBaseRanges[rangeNo].UpperCal >= CompUpperRange)
						&& (AIBaseRanges[rangeNo].HWRangeUnits == compEngUnits))
						&& ((rangeMatched == INVALID_RANGE)
								|| (AIBaseRanges[rangeNo].LowerCal > AIBaseRanges[rangeNoMatched].LowerRange)
								|| (AIBaseRanges[rangeNo].UpperCal < AIBaseRanges[rangeNoMatched].UpperRange))) {
					rangeNoMatched = rangeNo;
					rangeMatched = static_cast<UCHAR>(AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum);
				}
			}
		}
	} else if ((RangeType == AI_CHANNEL_TYPE_LINEAR_AMPS) || (RangeType == AI_CHANNEL_TYPE_LINEAR_OHMS)) { // Check the extended ranges
		rangeCount = GetExtendedTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if chsnnel type or RangeRev does not match
			if ((ExAIRanges[rangeNo].ExtendedRangeID.RangeInfo.ChanType == RangeType)
					&& (ExAIRanges[rangeNo].BoardVer == RangeRev)) { // Check desired range is within range capabilities then range is the lowest available range that statisfies requirement
				if (((ExAIRanges[rangeNo].LowerCal <= LowerRange) && (ExAIRanges[rangeNo].UpperCal >= UpperRange)
						&& (ExAIRanges[rangeNo].ExtendedRangeID.EngUnits == engUnits))
						&& ((rangeMatched == INVALID_RANGE)
								|| (ExAIRanges[rangeNo].LowerCal > ExAIRanges[rangeNoMatched].LowerRange)
								|| (ExAIRanges[rangeNo].UpperCal < ExAIRanges[rangeNoMatched].UpperRange))) {
					rangeNoMatched = rangeNo;
					rangeMatched = static_cast<UCHAR>(ExAIRanges[rangeNo].BaseRangeID);
				}
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetRangeClosestMatch
///
/// indexOfs the voltage range that supports the whole of the requested range, for a given board revision
///
/// @param[in] newUpperRange - The AI boards latest upper range limit found.
/// @param[in] newLowerRange - The AI boards latest lower range limit found.
/// @param[in] newEngUnits - The AI boards range latest limit units found.
/// @param[in] foundUpperRange - The AI boards previous upper range limit found.
/// @param[in] foundLowerRange - The AI boards previous lower range limit found.
/// @param[in] foundEngUnits - The AI boards range previous limit units found.
///
/// @return		The range ID code if a suitable one is found; otherwise INVALID_RANGE
//**********************************************************************
BOOL CAIRanges::IsRangeCloser(const T_RANGE newUpperRange, const T_RANGE newLowerRange, const USHORT newEngUnits,
		const T_RANGE foundUpperRange, const T_RANGE foundLowerRange, const USHORT foundEngUnits) const {
	BOOL newFound = FALSE;
	T_RANGE CompUpperRange = foundUpperRange;
	T_RANGE CompLowerRange = foundUpperRange;
	if (newEngUnits != foundEngUnits) {
		if (foundEngUnits == MILLI) {
			CompUpperRange = foundUpperRange / 1000.0F;
			CompLowerRange = foundLowerRange / 1000.0F;
		} else {
			CompUpperRange = foundUpperRange * 1000.0F;
			CompLowerRange = foundLowerRange * 1000.0F;
		}
	}
	if ((newEngUnits == UNITS) && (foundEngUnits == MILLI)) { // Use millivolt range in preferrence to volts - do nothing
	} else {
		if ((newLowerRange > CompLowerRange) || (newUpperRange < CompUpperRange))
			newFound = TRUE;
	}
	return newFound;
}
//**********************************************************************
/// GetRangeClosestMatch
///
/// indexOfs the voltage range that supports the whole of the requested range, for a given board revision
///
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[in] RangeType - The AI boards Range type desired.
/// @param[in] UpperRange - The AI boards upper range limit desired.
/// @param[in] LowerRange - The AI boards lower range limit desired.
/// @param[in] engUnits - The AI boards range limit desired - units.
///
/// @return		The range ID code if a suitable one is found; otherwise INVALID_RANGE
//**********************************************************************
UCHAR CAIRanges::GetRangeClosestMatch(const UCHAR RangeRev, const UCHAR RangeType, const T_RANGE UpperRange,
		const T_RANGE LowerRange, const USHORT engUnits) const {
	short rangeNo;
	T_RANGE CompUpperRange = UpperRange;
	T_RANGE CompLowerRange = LowerRange;
	USHORT compEngUnits = engUnits;
	USHORT rangeNoMatched = INVALID_RANGE;
	UCHAR rangeMatched = INVALID_RANGE;
	short rangeCount = static_cast<short>(GetBaseTableSize());
	// If range is linear voltage then find apporiate core board range
	if (RangeType == AI_CHANNEL_TYPE_LINEAR_VOLTS) { // Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if RangeRev does not match
			if (AIBaseRanges[rangeNo].BoardVer == RangeRev) { // Calculate 4% overrange and underrrange
				if (UpperRange >= 0.0)
					CompUpperRange = UpperRange * 1.04F;
				else
					CompUpperRange = UpperRange / 1.04F;
				if (LowerRange > 0.0)
					CompLowerRange = LowerRange / 1.04F;
				else
					CompLowerRange = LowerRange * 1.04F;
				if (AIBaseRanges[rangeNo].RangeUnits != engUnits) { // Convert depending upon direction required and allowing that 4%
					// overrange and underrange must always be available
					if (AIBaseRanges[rangeNo].HWRangeUnits == MILLI) {
						CompUpperRange = CompUpperRange / 1000.0F;
						CompLowerRange = CompLowerRange / 1000.0F;
						compEngUnits = UNITS;
					} else if (engUnits == UNITS) { 		// If not already in mV then convert
						CompUpperRange = CompUpperRange * 1000.0F;
						CompLowerRange = CompLowerRange * 1000.0F;
						compEngUnits = MILLI;
					} else {
						compEngUnits = engUnits;
					}
				} else {
					compEngUnits = engUnits;
				}
				// Check desired range is within range capabilities then range is the lowest available range that statisfies requirement
				if (((AIBaseRanges[rangeNo].LowerRange <= CompLowerRange)
						&& (AIBaseRanges[rangeNo].UpperRange >= CompUpperRange)
						&& (AIBaseRanges[rangeNo].RangeUnits == compEngUnits))
						&& ((rangeMatched == INVALID_RANGE)
								|| IsRangeCloser(AIBaseRanges[rangeNo].UpperRange, AIBaseRanges[rangeNo].LowerRange,
										AIBaseRanges[rangeNo].RangeUnits, AIBaseRanges[rangeNoMatched].UpperRange,
										AIBaseRanges[rangeNoMatched].LowerRange,
										AIBaseRanges[rangeNoMatched].RangeUnits))) {
					rangeNoMatched = rangeNo;
					rangeMatched = static_cast<UCHAR>(AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum);
				}
			}
		}
	} else if ((RangeType == AI_CHANNEL_TYPE_LINEAR_AMPS) || (RangeType == AI_CHANNEL_TYPE_LINEAR_OHMS)) { // Calculate 4% overrange and underrrange
		if (UpperRange >= 0.0)
			CompUpperRange = UpperRange * 1.04F;
		else
			CompUpperRange = UpperRange / 1.04F;
		if (LowerRange > 0.0)
			CompLowerRange = LowerRange / 1.04F;
		else
			CompLowerRange = LowerRange * 1.04F;
		// Check the extended ranges
		rangeCount = GetExtendedTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if chsnnel type or RangeRev does not match
			if ((ExAIRanges[rangeNo].ExtendedRangeID.RangeInfo.ChanType == RangeType)
					&& (ExAIRanges[rangeNo].BoardVer == RangeRev)) { // Check desired range is within range capabilities then range is the lowest available range that statisfies requirement
				if (((ExAIRanges[rangeNo].LowerRange <= CompLowerRange)
						&& (ExAIRanges[rangeNo].UpperRange >= CompUpperRange)
						&& (ExAIRanges[rangeNo].ExtendedRangeID.EngUnits == engUnits))
						&& ((rangeMatched == INVALID_RANGE)
								|| (ExAIRanges[rangeNo].LowerRange > ExAIRanges[rangeNoMatched].LowerRange)
								|| (ExAIRanges[rangeNo].UpperRange < ExAIRanges[rangeNoMatched].UpperRange))) {
					rangeNoMatched = rangeNo;
					rangeMatched = static_cast<UCHAR>(ExAIRanges[rangeNo].BaseRangeID);
				}
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetRangeClosestMatch
///
/// indexOfs the voltage range that supports the whole of the requested range, for a given board revision
///
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[in/out] UpperRange - The AI boards upper range limit desired.
/// @param[in/out] LowerRange - The AI boards lower range limit desired.
/// @param[in] engUnits - The AI boards range limit desired - units.
///
/// @return		The range ID code if a suitable one is found; otherwise INVALID_RANGE
//**********************************************************************
UCHAR CAIRanges::ScaleToBaseRange(const UCHAR RangeRev, USHORT RangeEnum,
T_RANGE *pUpperRange, T_RANGE *pLowerRange, const USHORT engUnits) const {
	short rangeNo;
	T_RANGE CompUpperRange = *pUpperRange;
	T_RANGE CompLowerRange = *pLowerRange;
	USHORT compEngUnits = engUnits;
	UCHAR rangeMatched = INVALID_RANGE;
	short rangeCount = static_cast<short>(GetBaseTableSize());
	// Loop for all ranges in the version/range available table
	for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { // Ignore if RangeRev does not match
		if (AIBaseRanges[rangeNo].BoardVer == RangeRev) {
			if (AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum == RangeEnum) {
				if (AIBaseRanges[rangeNo].RangeUnits != engUnits) { // Convert depending upon direction required and allowing that 4%
					// overrange and underrange must always be available
					if (AIBaseRanges[rangeNo].RangeUnits == UNITS) {
						*pUpperRange = CompUpperRange / 1000.0F;
						*pLowerRange = CompLowerRange / 1000.0F;
						compEngUnits = UNITS;
					} else if (AIBaseRanges[rangeNo].RangeUnits == MILLI) { 		// If not already in mV then convert
						*pUpperRange = CompUpperRange * 1000.0F;
						*pLowerRange = CompLowerRange * 1000.0F;
						compEngUnits = MILLI;
					}
				}
				rangeMatched = static_cast<UCHAR>(AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum);
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// DoesBaseRangeMatch()
///
/// Compares whether the range passed in matches the base range element suggested
///
/// @param[in] elementNo - Array element number to test.
/// @param[in] rangeCompare - Range to compare
///
/// @return		TRUE if the range selection is successful; otherwise FALSE
//**********************************************************************
BOOL CAIRanges::DoesBaseRangeMatch(const UCHAR elementNo, const T_AIRANGE *const pRangeCompare) const {
	BOOL cfgMatched = FALSE;
	if ((AIBaseRanges[elementNo].RangeInfo.RangeInfo.ChanType == pRangeCompare->ChanType)
			&& (AIBaseRanges[elementNo].RangeInfo.RangeInfo.RangeEnum == pRangeCompare->RangeEnum)) {
		cfgMatched = TRUE;
	}
	return cfgMatched;
}
//**********************************************************************
/// DoesExtendedRangeMatch()
///
/// Sets the channel range .
///
/// @param[in] elementNo - Array element number to test.
/// @param[in] rangeCompare - Range to compare
///
/// @return		TRUE if the range selection is successful; otherwise FALSE
//**********************************************************************
BOOL CAIRanges::DoesExtendedRangeMatch(const UCHAR elementNo, const T_AIRANGE *const pRangeCompare) const {
	BOOL cfgMatched = FALSE;
	if ((ExAIRanges[elementNo].ExtendedRangeID.RangeInfo.ChanType == pRangeCompare->ChanType)
			&& (ExAIRanges[elementNo].ExtendedRangeID.RangeInfo.RangeEnum == pRangeCompare->RangeEnum)) {
		cfgMatched = TRUE;
	}
	return cfgMatched;
}
//**********************************************************************
/// GetChannelRange
///
/// Obtains the channel range of a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pUpperRange - The AI boards upper range limit.
/// @param[out] pLowerRange - The AI boards lower range limit.
///
/// @return		The same range ID code if confirmed; otherwise NULL
//**********************************************************************
T_PAIRANGEDEF CAIRanges::GetChannelRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev,
T_RANGE *const pUpperRange, T_RANGE *const pLowerRange) const {
	UCHAR rangeNo;
	T_PAIRANGEDEF rangeMatched = NULL;
	USHORT rangeCount = 0;
	// If range is linear voltage then find apporiate core board range
	if (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) {
		rangeCount = GetBaseTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((AIBaseRanges[rangeNo].BoardVer == RangeRev) && (DoesBaseRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				*pUpperRange = AIBaseRanges[rangeNo].UpperRange;
				*pLowerRange = AIBaseRanges[rangeNo].LowerRange;
				rangeMatched = &AIBaseRanges[rangeNo].RangeInfo;
			}
		}
	} else if ((pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_AMPS)
			|| (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_OHMS) || (pRangeCode->ChanType == AI_CHANNEL_TYPE_RT)) { // Check the extended ranges
		rangeCount = GetExtendedTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((ExAIRanges[rangeNo].BoardVer == RangeRev) && (DoesExtendedRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				*pUpperRange = ExAIRanges[rangeNo].UpperRange;
				*pLowerRange = ExAIRanges[rangeNo].LowerRange;
				rangeMatched = &ExAIRanges[rangeNo].ExtendedRangeID;
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetChannelDispRange
///
/// Obtains the display channel range of a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pUpperRange - The AI boards upper range limit.
/// @param[out] pLowerRange - The AI boards lower range limit.
///
/// @return		The same range ID code if confirmed; otherwise NULL
//**********************************************************************
T_PAIRANGEDEF CAIRanges::GetChannelDispRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev,
T_RANGE *const pUpperRange, T_RANGE *const pLowerRange) const {
	UCHAR rangeNo;
	T_PAIRANGEDEF rangeMatched = NULL;
	USHORT rangeCount = 0;
	// If range is linear voltage then find apporiate core board range
	if (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) { // There are no sub-ranges for the base range so use the nominal range
		rangeCount = GetBaseTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((AIBaseRanges[rangeNo].BoardVer == RangeRev) && (DoesBaseRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				*pUpperRange = AIBaseRanges[rangeNo].UpperRange;
				*pLowerRange = AIBaseRanges[rangeNo].LowerRange;
				rangeMatched = &AIBaseRanges[rangeNo].RangeInfo;
			}
		}
	} else if ((pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_AMPS)
			|| (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_OHMS) || (pRangeCode->ChanType == AI_CHANNEL_TYPE_RT)) { // Check the extended ranges
		rangeCount = GetExtendedTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((ExAIRanges[rangeNo].BoardVer == RangeRev) && (DoesExtendedRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				*pUpperRange = ExAIRanges[rangeNo].SubUpperRange;
				*pLowerRange = ExAIRanges[rangeNo].SubLowerRange;
				rangeMatched = &ExAIRanges[rangeNo].ExtendedRangeID;
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetChannelDevice
///
/// Obtains any device needed for a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] DeviceType - Overall device type.
/// @param[out] DeviceSubType - The deice identification.
///
/// @return		The same range ID code if confirmed; otherwise NULL
//**********************************************************************
T_PAIRANGEDEF CAIRanges::GetChannelDevice(const T_AIRANGE *pRangeCode, const UCHAR RangeRev,
		T_RANGE_DEVICE_TYPE *const DeviceType, UCHAR *const DeviceSubType) const {
	UCHAR rangeNo;
	T_PAIRANGEDEF rangeMatched = NULL;
	USHORT rangeCount = 0;
	// Devices are only approriate for the extended ranges, base ranges do not have
	if ((AI_CHANNEL_TYPE_LINEAR_AMPS == pRangeCode->ChanType) || (AI_CHANNEL_TYPE_LINEAR_OHMS == pRangeCode->ChanType)
			|| (AI_CHANNEL_TYPE_RT == pRangeCode->ChanType)) { // Check the extended ranges
		rangeCount = GetExtendedTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((ExAIRanges[rangeNo].BoardVer == RangeRev) && (DoesExtendedRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				*DeviceType = ExAIRanges[rangeNo].DeviceType;
				*DeviceSubType = ExAIRanges[rangeNo].DeviceSubType;
				rangeMatched = &ExAIRanges[rangeNo].ExtendedRangeID;
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetChannelDevice
///
/// Obtains any device needed for a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] DeviceType - Overall device type.
/// @param[out] DeviceSubType - The deice identification.
///
/// @return		The same range ID code if confirmed; otherwise NULL
//**********************************************************************
/*
 T_PAIRANGEDEF CAIRanges::GetDeviceInfo(const T_AIRANGE *pRangeCode, const UCHAR RangeRev,
 T_RANGE_DEVICE_TYPE * const DeviceType, UCHAR * const DeviceSubType) const
 {
 UCHAR deviceNo;
 T_PAIRANGEDEF rangeMatched = NULL;
 USHORT deviceCount = 0;
 deviceCount = GetExtendedTableSize();
 // Loop for all devices in the table
 for( deviceNo = 0; deviceNo < deviceCount; deviceNo++ )
 {
 // Ignore if the RangeCode or RangeRev does not match
 if( (ExAIRanges[rangeNo].BoardVer == RangeRev) &&
 (DoesExtendedRangeMatch(rangeNo, pRangeCode) == TRUE) )
 {
 *DeviceType = ChanDevice[deviceNo].DeviceType;
 *DeviceSubType = ExAIRanges[rangeNo].DeviceSubType;
 rangeMatched = &ExAIRanges[rangeNo].ExtendedRangeID;
 }
 }
 return rangeMatched;
 }
 */
//**********************************************************************
/// GetBaseChannelRange
///
/// Obtains the base channel range of a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
///
/// @return		The range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
USHORT CAIRanges::GetBaseChannelRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev) const {
	UCHAR rangeNo;
	USHORT rangeMatched = INVALID_RANGE;
	USHORT rangeCount = 0;
	if (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) {
		rangeMatched = pRangeCode->RangeEnum;
	} else if ((pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_AMPS)
			|| (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_OHMS) || (pRangeCode->ChanType == AI_CHANNEL_TYPE_RT)) { // Check the extended ranges
		rangeCount = GetExtendedTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((ExAIRanges[rangeNo].BoardVer == RangeRev) && (DoesExtendedRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				rangeMatched = ExAIRanges[rangeNo].BaseRangeID;
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
///GetChannelCalPoints
///
/// Obtains the channel range cal points of a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pUpperRange - The AI boards upper range limit.
/// @param[out] pLowerRange - The AI boards lower range limit.
///
/// @return		The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
T_PAIRANGEDEF CAIRanges::GetChannelCalPoints(T_PAIRANGE pRangeCode, const UCHAR RangeRev, T_RANGE *pUpperRange,
T_RANGE *pLowerRange, IO_MEASURE_UNITS *pUnits) const {
	UCHAR rangeNo;
	T_PAIRANGEDEF rangeMatched = NULL;
	USHORT rangeCount = 0;
	// If range is linear voltage then find apporiate core board range
	if (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) {
		rangeCount = GetBaseTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((AIBaseRanges[rangeNo].BoardVer == RangeRev) && (DoesBaseRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				*pUpperRange = AIBaseRanges[rangeNo].UpperCal;
				*pLowerRange = AIBaseRanges[rangeNo].LowerCal;
				*pUnits = AIBaseRanges[rangeNo].RangeUnits;
				rangeMatched = &AIBaseRanges[rangeNo].RangeInfo;
			}
		}
	} else if ((pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_AMPS)
			|| (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_OHMS) || (pRangeCode->ChanType == AI_CHANNEL_TYPE_RT)) { // Check the extended ranges
		rangeCount = GetExtendedTableSize();
		// Loop for all ranges in the version/range available table
		for (rangeNo = 0; rangeNo < rangeCount; rangeNo++) { 	// Ignore if the RangeCode or RangeRev does not match
			if ((ExAIRanges[rangeNo].BoardVer == RangeRev) && (DoesExtendedRangeMatch(rangeNo, pRangeCode) == TRUE)) {
				*pUpperRange = ExAIRanges[rangeNo].UpperCal;
				*pLowerRange = ExAIRanges[rangeNo].LowerCal;
				*pUnits = ExAIRanges[rangeNo].RangeUnits;
				rangeMatched = &ExAIRanges[rangeNo].ExtendedRangeID;
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetRangeConfig
///
/// Obtains the channel range configuration and units types
///
/// @param[in] pRangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pRange - The AI boards range setup.
/// @param[out] pRangeUnits - The AI boards range units.
///
/// @return		The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
BOOL CAIRanges::GetRangeConfig(T_PAIRANGE pRangeCode, const UCHAR RangeRev, UCHAR *pRangeGain,
		UCHAR *pRangeUnits) const {
	const T_BASECHANNELRANGE *pBaseRange = NULL;
	const T_EXTENDEDCHANNELRANGE *pExtRange = NULL;
	BOOL rangeMatched = FALSE;
	USHORT BaseRangeCode;
	USHORT baseRangeCount = GetBaseTableSize();
	// If range is linear voltage then find apporiate core board range
	if (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) { // Ignore if the RangeCode or RangeRev does not match
		pBaseRange = MatchBaseRange(pRangeCode, RangeRev);
		if (pBaseRange != NULL) {
			*pRangeGain = pBaseRange->RangeGain;
			*pRangeUnits = pBaseRange->RangeUnits;
			rangeMatched = TRUE;
		}
	} else if ((pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_AMPS)
			|| (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_OHMS) || (pRangeCode->ChanType == AI_CHANNEL_TYPE_RT)) { // If range is an entended range then find the base range configuration
		pExtRange = MatchExtendedRange(pRangeCode, RangeRev);
		{
			BaseRangeCode = pExtRange->BaseRangeID;
			pBaseRange = MatchBaseRange(BaseRangeCode, RangeRev);
			if (pBaseRange != NULL) {
				*pRangeGain = pBaseRange->RangeGain;
				*pRangeUnits = pBaseRange->RangeUnits;
				rangeMatched = TRUE;
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetInternValues
///
/// Obtains the channel range Intern values
///
/// @param[in] RangeID - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pIntern0 - -V max internal value.
/// @param[out] pIntern0V - 0V internal value.
/// @param[out] pIntern100 - +V max internal value.
///
/// @return		The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
BOOL CAIRanges::GetInternValues(T_PAIRANGE pRangeCode, const UCHAR RangeRev,
T_RANGE_COUNTS *pIntern0,
T_RANGE_COUNTS *pIntern0V, T_RANGE_COUNTS *pIntern100) const {
	const T_BASECHANNELRANGE *pBaseRange = NULL;
	const T_EXTENDEDCHANNELRANGE *pExtRange = NULL;
	BOOL rangeMatched = FALSE;
	USHORT BaseRangeCode;
	USHORT baseRangeCount = GetBaseTableSize();
	// If range is linear voltage then find apporiate core board range
	if (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) { // Ignore if the RangeCode or RangeRev does not match
		pBaseRange = MatchBaseRange(pRangeCode, RangeRev);
		if (pBaseRange != NULL) {
			*pIntern0 = pBaseRange->Intern0;
			*pIntern100 = pBaseRange->Intern100;
			*pIntern0V = INTERN_CENTRE;
			rangeMatched = TRUE;
		}
	} else if ((pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_AMPS)
			|| (pRangeCode->ChanType == AI_CHANNEL_TYPE_LINEAR_OHMS) || (pRangeCode->ChanType == AI_CHANNEL_TYPE_RT)) { // If range is an entended range then find the base range configuration
		pExtRange = MatchExtendedRange(pRangeCode, RangeRev);
		{
			BaseRangeCode = pExtRange->BaseRangeID;
			pBaseRange = MatchBaseRange(BaseRangeCode, RangeRev);
			if (pBaseRange != NULL) {
				*pIntern0 = pBaseRange->Intern0;
				*pIntern100 = pBaseRange->Intern100;
				*pIntern0V = INTERN_CENTRE;
				rangeMatched = TRUE;
			}
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetInternValues
///
/// Obtains the channel range Intern values
///
/// @param[in] RangeID - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pIntern0 - -V max internal value.
/// @param[out] pIntern0V - 0V internal value.
/// @param[out] pIntern100 - +V max internal value.
///
/// @return	TRUE if found; otherwise FALSE
//**********************************************************************
BOOL CAIRanges::GetBaseInternValues(const USHORT RangeCode, const UCHAR RangeRev,
T_RANGE_COUNTS *pIntern0, T_RANGE_COUNTS *pIntern0V,
T_RANGE_COUNTS *pIntern100) const {
	UCHAR rangeNo;
	BOOL rangeMatched = FALSE;
	USHORT baseRangeCount = GetBaseTableSize();
	// Loop for all base ranges in the version/range available table
	for (rangeNo = 0; rangeNo < baseRangeCount; rangeNo++) { // Ignore if the RangeCode or RangeRev does not match
		if ((AIBaseRanges[rangeNo].BoardVer == RangeRev)
				&& (AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum == RangeCode)) {
			*pIntern0 = AIBaseRanges[rangeNo].Intern0;
			*pIntern100 = AIBaseRanges[rangeNo].Intern100;
			*pIntern0V = INTERN_CENTRE;
			rangeMatched = TRUE;
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetBaseChannelRange
///
/// Obtains the channel range of a given base range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pUpperRange - The AI boards upper range limit.
/// @param[out] pLowerRange - The AI boards lower range limit.
/// @param[out] pUnits - The AI boards range for display.
///
/// @return		The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
BOOL CAIRanges::GetBaseChannelRange(const USHORT RangeCode, UCHAR RangeRev,
T_RANGE *const pUpperRange,
T_RANGE *const pLowerRange, IO_MEASURE_UNITS *const pUnits) const {
	UCHAR rangeNo;
	BOOL rangeMatched = FALSE;
	USHORT baseRangeCount = GetBaseTableSize();
	// Loop for all base ranges in the version/range available table
	for (rangeNo = 0; rangeNo < baseRangeCount; rangeNo++) { // Ignore if the RangeCode or RangeRev does not match
		if ((AIBaseRanges[rangeNo].BoardVer == RangeRev)
				&& (AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum == RangeCode)) {
			*pLowerRange = AIBaseRanges[rangeNo].LowerRange;
			*pUpperRange = AIBaseRanges[rangeNo].UpperRange;
			*pUnits = AIBaseRanges[rangeNo].RangeUnits;
			rangeMatched = TRUE;
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetBaseTableSize
///
/// Calculates the size of the base table range option table
///
/// @return		Size in number of entries of the base range selection table
//**********************************************************************
USHORT CAIRanges::GetBaseTableSize(void) const {
	return static_cast<USHORT>(sizeof(AIBaseRanges) / sizeof(T_BASECHANNELRANGE));
}
//**********************************************************************
/// GetExtendedTableSize
///
/// Calculates the size of the extended table range option table
///
/// @return		Size in number of entries of the extended range selection table
//**********************************************************************
USHORT CAIRanges::GetExtendedTableSize(void) const {
	return static_cast<USHORT>(sizeof(ExAIRanges) / sizeof(T_EXTENDEDCHANNELRANGE));
}
//**********************************************************************
/// GetDeviceTableSize
///
/// Calculates the size of the extended device table
///
/// @return		Size in number of entries of the extended device selection table
//**********************************************************************
USHORT CAIRanges::GetDeviceTableSize(void) const {
	return static_cast<USHORT>(sizeof(ChanDevice) / sizeof(T_DEVICE));
}
//**********************************************************************
/// GetBaseChannelConfig
///
/// Obtains the channel range info of a given base range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pRangeComp - The AI boards range gain and setup.
/// @param[out] pRangeGain - The AI boards range gain.
/// @param[out] pRangePair - The AI boards range input pair.
///
/// @return		TRUE if range identified and available; otherwise FALSE
//**********************************************************************
BOOL CAIRanges::GetBaseChannelConfig(const USHORT RangeCode, UCHAR RangeRev, UCHAR *pRangeComp, UCHAR *pRangeGain,
		UCHAR *pRangePair) const {
	UCHAR rangeNo;
	BOOL rangeMatched = FALSE;
	USHORT baseRangeCount = GetBaseTableSize();
	// Loop for all base ranges in the version/range available table
	for (rangeNo = 0; rangeNo < baseRangeCount; rangeNo++) { // Ignore if the RangeCode or RangeRev does not match
		if ((AIBaseRanges[rangeNo].BoardVer == RangeRev)
				&& (AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum == RangeCode)) {
			*pRangeComp = AIBaseRanges[rangeNo].RangeGain;
			*pRangeGain = GetInputRange(AIBaseRanges[rangeNo].RangeGain);
			*pRangePair = GetHighInputPair(AIBaseRanges[rangeNo].RangeGain);
			rangeMatched = TRUE;
		}
	}
	return rangeMatched;
}
//**********************************************************************
/// GetChannelRange
///
/// Obtains the channel range of a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pUpperRange - The AI boards upper range limit.
/// @param[out] pLowerRange - The AI boards lower range limit.
///
/// @return		The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
BOOL CAIRanges::GetBaseNominalChannelRange(const USHORT RangeCode, const UCHAR RangeRev,
T_RANGE *pUpperRange, T_RANGE *pLowerRange) const {
	UCHAR rangeNo;
	BOOL rangeMatched = FALSE;
	USHORT baseRangeCount = GetBaseTableSize();
	// Loop for all base ranges in the version/range available table
	for (rangeNo = 0; rangeNo < baseRangeCount; rangeNo++) { // Ignore if the RangeCode or RangeRev does not match
		if ((AIBaseRanges[rangeNo].BoardVer == RangeRev)
				&& (AIBaseRanges[rangeNo].RangeInfo.RangeInfo.RangeEnum == RangeCode)) {
			*pLowerRange = AIBaseRanges[rangeNo].LowerCal;
			*pUpperRange = AIBaseRanges[rangeNo].UpperCal;
			rangeMatched = TRUE;
		}
	}
	return rangeMatched;
}

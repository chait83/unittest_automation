/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PPIOServiceManager.cpp
/// @n implementation for the IO Service manager class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//
//////////////////////////////////////////////////////////////////////
#include "V6IOErrorCodes.H"
#include "TraceDefines.h"
#include <math.h>
#include "PPQManager.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "PPIOService.h"
#include "PPAIChannel.h"
#include "PPAOChannel.h"
#include "PPDICard.h"
#include "PPDOChannel.h"
#include "PPPulseChannel.h"
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#include "PPIOServiceManager.h"
#include "V6globals.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPPIOServiceManager::CPPIOServiceManager() {
//	qDebug("Create new CPPIOServiceManager\n");
	m_pAIChanHandler = NULL;
	m_pAOChanHandler = NULL;
	m_pDOChanHandler = NULL;
	m_pPulseChanHandler = NULL;
	m_pDICardHandler = NULL;
	m_pInputConditioning = NULL;
}
CPPIOServiceManager::~CPPIOServiceManager() {
//	qDebug("Delete CPPIOServiceManager class\n");
}
CPPIOServiceManager *CPPIOServiceManager::m_pInstance = NULL;
QMutex CPPIOServiceManager::m_CreationMutex;
//**********************************************************************
///
/// Instance creation of CPPIOServiceManager singleton
/// Initialises all channel types to connect to the approriate Data Item table
/// or data queue for data extraction/processing.
///
/// @return, , pointer to single instance of CPPIOServiceManager
/// 
//**********************************************************************
CPPIOServiceManager* CPPIOServiceManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CPPIOServiceManager;
				m_pInstance->Initialise();
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"PPIOServiceManager WaitForSingleObject Error", L"CPPIOServiceManager Error",
			MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
//**********************************************************************
void CPPIOServiceManager::CleanUp() {
	if (NULL != m_pInstance) {
		// Destroy all the helper classes
		if (m_pAIChanHandler != NULL) {
			delete m_pAIChanHandler;
			m_pAIChanHandler = NULL;
		}
		if (m_pAOChanHandler != NULL) {
			delete m_pAOChanHandler;
			m_pAOChanHandler = NULL;
		}
		if (m_pDOChanHandler != NULL) {
			delete m_pDOChanHandler;
			m_pDOChanHandler = NULL;
		}
		if (m_pPulseChanHandler != NULL) {
			delete m_pPulseChanHandler;
			m_pPulseChanHandler = NULL;
		}
		if (m_pDICardHandler != NULL) {
			delete m_pDICardHandler;
			m_pDICardHandler = NULL;
		}
		if (m_pInputConditioning != NULL) {
			delete m_pInputConditioning;
			m_pInputConditioning = NULL;
		}
		// Delete the service manager
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//**********************************************************************
/// Initialise the singleton
///
//**********************************************************************
void CPPIOServiceManager::Initialise(void) {
	// Initialise all the helper classes
	m_pInputConditioning = new class CInputConditioning();
	m_pAOChanHandler = new class CPPAOChannel(FALSE);
	m_pDOChanHandler = new class CPPDOChannel(FALSE);
	m_pPulseChanHandler = new class CPPPulseChannel(TRUE);
	m_pDICardHandler = new class CPPDICard(TRUE);
	m_pAIChanHandler = new class CPPAIChannel(TRUE);
}
//**********************************************************************
/// Initialise the device tables and single and daul point cals in the recorder
///
//**********************************************************************
BOOL CPPIOServiceManager::InitialiseServiceManager(void) {
	BOOL retValue = FALSE;
	if (m_pInputConditioning != NULL)
		retValue = m_pInputConditioning->IOConditionerInitialise();
	return retValue;
}
//**********************************************************************
/// Re-initialise the user linearisation tables on the recorder
///
//**********************************************************************
BOOL CPPIOServiceManager::CommitServiceManager(void) {
	BOOL retValue = FALSE;
	if (m_pInputConditioning != NULL)
		retValue = m_pInputConditioning->IOConditionerCommit();
	return retValue;
}
//******************************************************
/// Obtains the handle of a DI card service
///
/// @return DI service handle if successful; otherwise NULL
/// 
//******************************************************
class CPPDICard* CPPIOServiceManager::GetDIService(void) const {
	if ((m_pAIChanHandler != NULL) && (m_pAOChanHandler != NULL) && (m_pDOChanHandler != NULL)
			&& (m_pPulseChanHandler != NULL) && (m_pDICardHandler != NULL))
		return m_pDICardHandler;
	return NULL;
}
//******************************************************
/// Obtains the handle of a Pulse channel service
///
/// @return Pulse service handle if successful; otherwise NULL
/// 
//******************************************************
class CPPPulseChannel* CPPIOServiceManager::GetPulseService(void) const {
	if ((m_pAIChanHandler != NULL) && (m_pAOChanHandler != NULL) && (m_pDOChanHandler != NULL)
			&& (m_pPulseChanHandler != NULL) && (m_pDICardHandler != NULL))
		return m_pPulseChanHandler;
	return NULL;
}
//******************************************************
/// Obtains the handle of a DO channel service
///
/// @return DO service handle if successful; otherwise NULL
/// 
//******************************************************
class CPPDOChannel* CPPIOServiceManager::GetDOService(void) const {
	if ((m_pAIChanHandler != NULL) && (m_pAOChanHandler != NULL) && (m_pDOChanHandler != NULL)
			&& (m_pPulseChanHandler != NULL) && (m_pDICardHandler != NULL))
		return m_pDOChanHandler;
	return NULL;
}
//******************************************************
/// Obtains the handle of a AO channel service
///
/// @return AO service handle if successful; otherwise NULL
/// 
//******************************************************
class CPPAOChannel* CPPIOServiceManager::GetAOService(void) const {
	if ((m_pAIChanHandler != NULL) && (m_pAOChanHandler != NULL) && (m_pDOChanHandler != NULL)
			&& (m_pPulseChanHandler != NULL) && (m_pDICardHandler != NULL))
		return m_pAOChanHandler;
	return NULL;
}
//******************************************************
/// Obtains the handle of a AI channel service
///
/// @return AI service handle if successful; otherwise NULL
/// 
//******************************************************
class CPPAIChannel* CPPIOServiceManager::GetAIService(void) const {
	if ((m_pAIChanHandler != NULL) && (m_pAOChanHandler != NULL) && (m_pDOChanHandler != NULL)
			&& (m_pPulseChanHandler != NULL) && (m_pDICardHandler != NULL))
		return m_pAIChanHandler;
	return NULL;
}
//******************************************************
/// Obtains the handle of the input conditioner service
///
/// @return Input Conditioner service handle if successful; otherwise NULL
/// 
//******************************************************
class CInputConditioning* CPPIOServiceManager::GetICService(void) const {
	if (m_pInputConditioning != NULL)
		return m_pInputConditioning;
	return NULL;
}
//******************************************************
/// Resets all PPQ's to default state
///
/// @return TRUE if PPQ reset succesful; otherwise FALSE
/// 
//******************************************************
BOOL CPPIOServiceManager::ResetAllPPQsToDefault(void) {
	BOOL retValue = TRUE;
	class CPPQManager *pPPQManager = NULL;
	pPPQManager = CPPQManager::GetHandle();
	if (pPPQManager != NULL) {
		pPPQManager->ResetAllPPQsToDefault();		// Reset all PPQ's
	}
	return retValue;
}

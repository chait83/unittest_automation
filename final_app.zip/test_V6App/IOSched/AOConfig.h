/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AIConfig.h
/// @n interface for the CAIConfig class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 26	Stability Project 1.23.1.1	7/2/2011 4:55:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 25	Stability Project 1.23.1.0	7/1/2011 4:27:11 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 24	V6 Firmware 1.23		7/20/2005 7:45:52 PM	Graham Waterfield
//		Debugging of CMM issues for digitals/pulse
//		(Still not fully resolved)
// 23	V6 Firmware 1.22		7/11/2005 7:17:42 PM	Graham Waterfield
//		Debugging pre-process queues, staged checkin
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_AOCONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)
#define AFX_AOCONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "IOCard.h"
#include "CMMDefines.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "V6defines.h"
#include "V6Config.h"
#include "IOSetupConfig.h"
#include "PenSetupConfig.h"
#include "Config.h"
#include "V6Config.h"
#include "AIRanges.h"
#include "DataItemPen.h"
const UCHAR AO_NO_CAL = 0;		///< No AO calibration being performed
const UCHAR AO_FACTORY_CAL = 1;		///< AO Factory calibration being performed
const UCHAR AO_USER_CAL = 2;		///< AO User calibration being performed
typedef struct _aocfgchannelconfig {
	T_COMMONCFGCHANNEL ChanCfgInfo;		///< Universal channel configuration
	float mcEngZero;			///< Main channel engineering Zero
	float mcEngSpan;			///< Main channel engineering Span
	USHORT AOChanEngZero;		///< AO channel engineering Zero
	USHORT AOChanEngSpan;		///< AO channel engineering Span
	USHORT RetransPenNo;		///< Pen number to retransmit
	BOOL Limit;				///< Is limit selected i.e. 4mA minimum
	BOOL Overrange;			///< Is overrange selected i.e. > 20mA
} T_AOCFGCHANNEL, *T_PAOCFGCHANNEL;
typedef struct _aowrkchannelconfig {
	class CDataItemPen *pPenDataItem;			///< Pen data item reference to retransmit
	class CFFConversionInfo *pPen;					///< Pen engineering scales
} T_AOWRKCHANNELCFG, *T_PAOWRKCHANNELCFG;
// Overall board configuration holder
typedef struct _aocfgboardconfig {
	T_AOCFGCHANNEL CfgChan[TOPSLOT_AOCHAN_SIZE];					///< Downloadable setup for all board channels
	USHORT ConfigCRC;		/// Board configuration CRC
} T_AOCFGBOARDCONFIG, *T_PAOCFGBOARDCONFIG;
// Overall board configuration holder, including working
typedef struct _aoboardconfig {
	BOOL Calibration;					///< TRUE if board is being calibrated
	T_AOCFGBOARDCONFIG AOCfg;	///< Downloadable setup for all board channels
	T_AOWRKCHANNELCFG WrkChan[TOPSLOT_AOCHAN_SIZE];	///< Working downloadable setup for all board channels
} T_AOBOARDCONFIG, *T_PAOBOARDCONFIG;
// Individual channel calibration
/*
 typedef struct _aochancalibration
 {
 UCHAR	Offset;
 USHORT	RawCount20mA;
 } T_AOCHANCAL, *T_PAOCHANCAL;
 */
class CAOConfig: public CConfig {
	// Allow the Card manager class only to create new instances of the AI configuration
	friend class CIOConfigManager;
public:		//Singleton 
	virtual BOOL CMMCreateLocalConfig(void);
	USHORT CalculateChannelReadRate(const UCHAR ChanNo);
	float CalcChanScaledValue(const UCHAR chanNo);
	BOOL QueryChannelOverrangeCapability(const UCHAR chanNo);
	BOOL QueryChannelLimitSelected(const UCHAR chanNo);
	BOOL QueryChannelRawSelected(const UCHAR chanNo);
	BOOL QueryChannelEnabled(const UCHAR chanNo);
	BOOL GetChannelConfigRef(const UCHAR ChanNo, T_AOCFGCHANNEL **pChanCfgInfo, T_AOWRKCHANNELCFG **pChanWrkInfo);
	BOOL ScheduleBoardProcess(void);
//	BOOL SetChannelRange(UCHAR ChanNo, USHORT ChanType, USHORT SubChanType, USHORT Range);
	BOOL UploadConfig(void);
	BOOL ScheduleFactoryCalUpload(void);
//	BOOL ConvertLocalConfig( void );
	BOOL CMMSlotLoad(void);
	BOOL CMMTransfer(T_PTOPSLOT pAICMMConfig);
	BOOL CalStructTransfer(class CATECal *const pCalStruct);
	BOOL InitialiseCardConfigHolder(CIOCard *const pIOCard);
	BOOL IOCardLocalConfigCommit(void);
	void CleanUp();
private:
	CAOConfig();
	CAOConfig(const CAOConfig&);
	CAOConfig& operator=(const CAOConfig&) {
		return *this;
	}
	;
	~CAOConfig();
	T_AOBOARDCONFIG m_Config;			///< Downloadable AO board configuration
//	T_AOCHANCAL		m_CalInfo[TOPSLOT_AOCHAN_SIZE];		///< I/O card calibration info
	// Singleton handlers
//	static CAIConfig* m_pInstance;
	static QMutex m_CreationMutex;
	T_PTOPSLOT *m_pAOCMMConfig;	///< Short cut to the boards CMM configuration
//	USHORT CRC;					///< Identifies board downloaded configuration
//	ULONG GUID;					///< Identifies configuration and board position
//	unsigned long BoardID;
};
#endif // !defined(AFX_AOCONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)

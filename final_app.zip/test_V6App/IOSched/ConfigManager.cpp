/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n ConfigManager.cpp
/// @n implementation of the CConfigManager class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 34	Stability Project 1.29.1.3	7/2/2011 4:56:16 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 33	Stability Project 1.29.1.2	7/1/2011 4:38:07 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 32	Stability Project 1.29.1.1	3/17/2011 3:20:17 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 31	Stability Project 1.29.1.0	2/15/2011 3:02:39 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "ConfigManager.h"
#include "AIConfig.h"
#include "AOConfig.h"
#include "DigConfig.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "PPL.h"
#include "V6globals.h"
QMutex CIOConfigManager::m_CreationMutex;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CIOConfigManager::CIOConfigManager() {
//	qDebug("Create new CIOConfigManager\n");
// No board configuration's loaded yet
	m_NoOfAICards = 0;
	m_NoOfDigPulseCards = 0;
	m_NoOfAOCards = 0;
	m_pBrdInfoObj = NULL;
	m_pBrdStatsObj = NULL;
	m_pSlotMapObj = NULL;
	// Ensure there is no associated configuration until requested
	for (USHORT cardNo = 0; cardNo < MAX_SCHED_SERVICES; cardNo++) {
		m_pCardConfig[cardNo] = NULL;
		m_pAIConfig[cardNo] = NULL;
		m_pAOConfig[cardNo] = NULL;
		m_pDigConfig[cardNo] = NULL;
		m_Config[cardNo].ConfigType = CONFIG_UNKNOWN;
	}
}
CIOConfigManager::~CIOConfigManager() {
//	qDebug("Deleting new CIOConfigManager class\n");
}
CIOConfigManager *CIOConfigManager::m_pInstance = NULL;
QMutex m_CreationMutex;
//**********************************************************************
///
/// Initialises the configuration manager
///
/// @return		TRUE if sucessfully initilised; otherwise FALSE
//**********************************************************************
BOOL CIOConfigManager::InitialiseConfigManager(void) {
	// Get a handle on board info, stats and slot mapping
	m_pBrdInfoObj = CBrdInfo::GetHandle();
	m_pBrdStatsObj = CBrdStats::GetHandle();
	m_pSlotMapObj = CSlotMap::GetHandle();
	if ((m_pBrdInfoObj = NULL) || (m_pBrdStatsObj = NULL) || (m_pSlotMapObj = NULL))
		return FALSE;
	return TRUE;
}
//**********************************************************************
/// InitialiseCardConfig()
///
/// Initialises the configuration manager to connect to the relvent CMM class
/// @param[in] pCard - The board to create the local configuration.
///
/// @return		TRUE if the relevant configuration is created; otherwise FALSE
//**********************************************************************
BOOL CIOConfigManager::InitialiseCardConfig(class CCardSlot *const pCard) {
	BOOL retValue = FALSE;
	// Only create the correct configuration for the valid board type
	if (m_pBrdInfoObj->WhatBoardType(pCard->BoardSlotInstance()) <= BOARD_NOT_YET15)
		retValue = pCard->InitialiseCardConfig();
	else
		LogInternalError("Could not find requested I/O card");
	return retValue;
}
//**********************************************************************
///
/// Instance creation of CIOConfigManager singleton
///
/// @return		pointer to single instance of CIOConfigManager
/// 
//**********************************************************************
CIOConfigManager* CIOConfigManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CIOConfigManager;
			}
			if ( FALSE == m_CreationMutex.unlock()) {
				/// Handle Error
				LogInternalError("Could not create ConfigManager");
				V6WarningMessageBox(NULL, L"Failed to release ConfigManager mutex", L"CIOConfigManager Error", MB_OK);
			}
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			/// Handle Error
			LogInternalError("Could not create ConfigManager");
			V6WarningMessageBox(NULL, L"ConfigManager WaitForSingleObject Error", L"CIOConfigManager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
/// @return		nothing
//**********************************************************************
void CIOConfigManager::CleanUp() {
	// Delete the manager
	if (NULL != m_pInstance) {
		// Remove the individual card configurations, only if the manager has been created
		for (USHORT slotNo = 0; slotNo < MAX_SCHED_SERVICES; slotNo++) {
			if (m_pCardConfig[slotNo] != NULL) {
				delete m_pCardConfig[slotNo];
				m_pCardConfig[slotNo] = NULL;
				m_pAIConfig[slotNo] = NULL;
				m_pAOConfig[slotNo] = NULL;
				m_pDigConfig[slotNo] = NULL;
				m_Config[slotNo].ConfigType = CONFIG_UNKNOWN;
			}
		}
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Load the global configuration from the CMM and create the locally held one.
/// @param[in] SlotNo - The board's slot number.
///
/// @return TRUE if successful created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CIOConfigManager::CMMCreateLocalConfig(const USHORT slotNo) {
	BOOL retValue = FALSE;
	if (m_pCardConfig[slotNo] != NULL)
		retValue = m_pCardConfig[slotNo]->CMMCreateLocalConfig();
	return retValue;
}
//**********************************************************************
/// CreateAILocalConfigHolder()
///
/// Creates a new local CAIConfig Instance and allocate it to the apporiate board
/// @note Ensure that config creation is thread safe
/// @param[in] SlotNo - The board's slot number.
///
/// @return		pointer to instance of CAIConfig
/// 
//**********************************************************************
class CAIConfig* CIOConfigManager::CreateAILocalConfigHolder(const USHORT slotNo) {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	// Only create a configuration if one has not already been allocated for this board,
	// otherwise return the current configuration reference
	if (m_pCardConfig[slotNo] == NULL) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,		// No security descriptor
				FALSE,					// Mutex object not owned
				TEXT("AIConfig"));	// Object name
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (m_pCardConfig[slotNo] == NULL) {
				m_pAIConfig[m_NoOfAICards] = new class CAIConfig();
				m_Config[slotNo].ConfigType = CONFIG_AI;
				m_Config[slotNo].SlotPosition = m_NoOfAICards;
				m_pCardConfig[slotNo] = m_pAIConfig[m_NoOfAICards];
				m_NoOfAICards++;
			}
			if (m_CreationMutex.unlock() == FALSE) {
				V6WarningMessageBox(NULL, L"Failed to release AIConfig mutex", L"CAIConfig Error", MB_OK);
			}
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"AIConfig WaitForSingleObject Error", L"CAIConfig Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (static_cast<class CAIConfig*>(m_pCardConfig[slotNo]));
}
//**********************************************************************
/// CreateDigLocalConfig()
///
/// Creates a new local CDigConfig Instance and allocate it to the apporiate board
/// @note Ensure that config creation is thread safe
/// @param[in] SlotNo - The board's slot number.
///
/// @return		pointer to instance of CDigConfig
/// 
//**********************************************************************
class CDigConfig* CIOConfigManager::CreateDigLocalConfig(const USHORT slotNo) {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	// Only create a configuration if one has not already been allocated for this board,
	// otherwise return the current configuration reference
	if (m_pCardConfig[slotNo] == NULL) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (m_pCardConfig[slotNo] == NULL) {
				m_pDigConfig[m_NoOfDigPulseCards] = new class CDigConfig();
				m_Config[slotNo].ConfigType = CONFIG_DIG_PULSE;
				m_Config[slotNo].SlotPosition = m_NoOfDigPulseCards;
				m_pCardConfig[slotNo] = m_pDigConfig[m_NoOfDigPulseCards];
				m_NoOfDigPulseCards++;
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"DigConfig WaitForSingleObject Error", L"CDigConfig Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (static_cast<class CDigConfig*>(m_pCardConfig[slotNo]));
}
//**********************************************************************
/// CreateAOLocalConfig()
///
/// Creates a new local CAOConfig Instance and allocate it to the apporiate board
/// @note Ensure that config creation is thread safe
/// @param[in] SlotNo - The board's slot number.
///
/// @return		pointer to instance of CAOConfig
/// 
//**********************************************************************
class CAOConfig* CIOConfigManager::CreateAOLocalConfig(const USHORT slotNo) {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	// Only create a configuration if one has not already been allocated for this board,
	// otherwise return the current configuration reference
	if (m_pCardConfig[slotNo] == NULL) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (m_pCardConfig[slotNo] == NULL) {
				m_pAOConfig[m_NoOfAOCards] = new class CAOConfig();
				m_Config[slotNo].ConfigType = CONFIG_AO;
				m_Config[slotNo].SlotPosition = m_NoOfAOCards;
				m_pCardConfig[slotNo] = m_pAOConfig[m_NoOfAOCards];
				m_NoOfAOCards++;
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"AOConfig WaitForSingleObject Error", L"CAOConfig Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (static_cast<class CAOConfig*>(m_pCardConfig[slotNo]));
}
//**********************************************************************
/// GetAILocalConfig()
///
/// Gets the local CAIConfig Instance
/// @param[in] SlotNo - The board's slot number.
///
/// @return		pointer to instance of CAIConfig
/// 
//**********************************************************************
class CAIConfig* CIOConfigManager::GetAILocalConfig(const USHORT slotNo) const {
	if (m_Config[slotNo].ConfigType != CONFIG_AI)
		return NULL;
	return m_pAIConfig[m_Config[slotNo].SlotPosition];
}
//**********************************************************************
/// GetAILocalConfig()
///
/// Gets the local CAIConfig Instance
/// @param[in] SlotNo - The board's slot number.
///
/// @return		pointer to instance of CAIConfig
/// 
//**********************************************************************
class CConfig* CIOConfigManager::GetCommonLocalConfig(const USHORT slotNo) const {
	return m_pCardConfig[slotNo];
}
//**********************************************************************
/// GetAOLocalConfig()
///
/// Gets the local CAOConfig Instance
/// @param[in] SlotNo - The board's slot number.
///
/// @return		pointer to instance of CAOConfig
/// 
//**********************************************************************
class CAOConfig* CIOConfigManager::GetAOLocalConfig(const USHORT slotNo) const {
	if (m_Config[slotNo].ConfigType != CONFIG_AO)
		return NULL;
	return m_pAOConfig[m_Config[slotNo].SlotPosition];
}
//**********************************************************************
/// GetDigLocalConfig()
///
/// Gets the local CDigConfig Instance
/// @param[in] SlotNo - The board's slot number.
///
/// @return		pointer to instance of CDigConfig
/// 
//**********************************************************************
class CDigConfig* CIOConfigManager::GetDigLocalConfig(const USHORT slotNo) const {
	if (m_Config[slotNo].ConfigType != CONFIG_DIG_PULSE)
		return NULL;
	return m_pDigConfig[m_Config[slotNo].SlotPosition];
}
//******************************************************
// SelectAIChanAcqRate()
///
/// Sets the current channel acqsistion rate for any input channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Rate - The acquisition rate of the channel.
///
/// @return Whether the given rate could be selected
/// 
//******************************************************
BOOL CIOConfigManager::SelectAIChanAcqRate(const USHORT sysChannelNo, const USHORT Rate) {
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	slotNo = m_pSlotMapObj->GetAnaInChannelSlotNo(sysChannelNo, ONE_BASED);
	chanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel(sysChannelNo, ONE_BASED);
	if ((slotNo != SMAP_ILLEGAL_INDEX) && (chanNo != SMAP_ILLEGAL_INDEX)) {
		pAIConfig = GetAILocalConfig(slotNo);
		pAIConfig->SelectAIChanAcqRate(chanNo, Rate);
		return TRUE;
	}
	return FALSE;
}
//******************************************************
// SelectAIChanVoltageRange()
///
/// Sets the current channel range for any voltage channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The voltage range of the channel.
///
/// @return Whether the given range could be selected
/// 
//******************************************************
BOOL CIOConfigManager::SelectAIChanVoltageRange(const USHORT sysChannelNo, const USHORT Range) {
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	slotNo = m_pSlotMapObj->GetAnaInChannelSlotNo(sysChannelNo, ONE_BASED);
	chanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel(sysChannelNo, ONE_BASED);
	if ((slotNo != SMAP_ILLEGAL_INDEX) && (chanNo != SMAP_ILLEGAL_INDEX)) {
		pAIConfig = GetAILocalConfig(slotNo);
		pAIConfig->SelectAIChanVoltageRange(chanNo, Range);
		return TRUE;
	}
	return FALSE;
}
//******************************************************
// SelectAIChanCurrentRange()
///
/// Sets the current channel range for any current channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The current range of the channel.
///
/// @return Whether the given range could be selected
/// 
//******************************************************
BOOL CIOConfigManager::SelectAIChanCurrentRange(const USHORT sysChannelNo, const USHORT Range) {
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	slotNo = m_pSlotMapObj->GetAnaInChannelSlotNo(sysChannelNo, ONE_BASED);
	chanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel(sysChannelNo, ONE_BASED);
	if ((slotNo != SMAP_ILLEGAL_INDEX) && (chanNo != SMAP_ILLEGAL_INDEX)) {
		pAIConfig = GetAILocalConfig(slotNo);
		pAIConfig->SelectAIChanCurrentRange(chanNo, Range);
		return TRUE;
	}
	return FALSE;
}
//******************************************************
// SelectAIChanResistanceRange()
///
/// Sets the current channel range for any resistance channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The rsistance range of the channel.
///
/// @return Whether the given range could be selected
/// 
//******************************************************
BOOL CIOConfigManager::SelectAIChanResistanceRange(const USHORT sysChannelNo, const USHORT Range) {
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	slotNo = m_pSlotMapObj->GetAnaInChannelSlotNo(sysChannelNo, ONE_BASED);
	chanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel(sysChannelNo, ONE_BASED);
	if ((slotNo != SMAP_ILLEGAL_INDEX) && (chanNo != SMAP_ILLEGAL_INDEX)) {
		pAIConfig = GetAILocalConfig(slotNo);
		pAIConfig->SelectAIChanResistanceRange(chanNo, Range);
		return TRUE;
	}
	return FALSE;
}
//******************************************************
// SelectAIChanTCRange()
///
/// Sets the current channel range for any voltage channel on any card in the local configuration.
/// @param[in] sysChannelNo - The TC channel number.
/// @param[in] Range - The TC range of the channel.
///
/// @return Whether the given range could be selected
/// 
//******************************************************
BOOL CIOConfigManager::SelectAIChanTCRange(const USHORT sysChannelNo, const USHORT Range) {
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	slotNo = m_pSlotMapObj->GetAnaInChannelSlotNo(sysChannelNo, ONE_BASED);
	chanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel(sysChannelNo, ONE_BASED);
	if ((slotNo != SMAP_ILLEGAL_INDEX) && (chanNo != SMAP_ILLEGAL_INDEX)) {
		pAIConfig = GetAILocalConfig(slotNo);
		pAIConfig->SelectAIChanTCRange(chanNo, Range);
		return TRUE;
	}
	return FALSE;
}
//******************************************************
// SelectAIChanRTRange()
///
/// Sets the current channel range for any RT channel on any card in the local configuration.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The RT range of the channel.
///
/// @return Whether the given range could be selected
/// 
//******************************************************
BOOL CIOConfigManager::SelectAIChanRTRange(const USHORT sysChannelNo, const USHORT Range) {
	USHORT slotNo = 0;
	USHORT chanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	slotNo = m_pSlotMapObj->GetAnaInChannelSlotNo(sysChannelNo, ONE_BASED);
	chanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel(sysChannelNo, ONE_BASED);
	if ((slotNo != SMAP_ILLEGAL_INDEX) && (chanNo != SMAP_ILLEGAL_INDEX)) {
		pAIConfig = GetAILocalConfig(slotNo);
		pAIConfig->SelectAIChanRTRange(chanNo, Range);
		return TRUE;
	}
	return FALSE;
}

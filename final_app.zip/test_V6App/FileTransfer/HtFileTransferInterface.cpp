/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 File Transfer
/// @n Filename: CHtFileTransferInterface.cpp
/// @n Desc:	Implementation of CHtFileTransferClient
///
// ****************************************************************
// Revision History
// ****************************************************************
#include "HtFileTransferInterface.h"
//****************************************************************************
/// CHtFileTransferInterface - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CHtFileTransferInterface::CHtFileTransferInterface() {
} //end CHtFileTransferClient()
//****************************************************************************
/// ~CHtFileTransferInterface - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CHtFileTransferInterface::~CHtFileTransferInterface() {
} //end ~CHtFileTransferClient() 

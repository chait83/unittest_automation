//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		RTDataServer
/// @n Filename:  RTDataSocket.h
/// @n Description: Declaration of the CHTDataSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
#if !defined(AFX_HTDATA_QAbstractSocket_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_)
#define AFX_HTDATA_QAbstractSocket_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_
#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#include "SecureSocket.h"
#include "CStorage.h"
//#include "HTDataLink.h"
class CHTDataLink;
//Constant Declarations
const int SET_REALTIME_CONFIGURATION = 0x00;
const int READ_REQUEST = 0x01;
const int WRITE_REQUEST = 0x02;
const int ACK_ALARM = 0x03;
const int ACKNOWLEDGE = 0x0C;
const int SAMPLE = 0xE1;
const int MAXMIN = 0xE2;
const int AVERAGE = 0xE3;
//Error Codes
const int ERR_SENDMESSAGE = 0x00F1;
const int ERR_READMESSAGE = 0x00F2;
const int ERR_MAXCLIENTSCONN = 0x00F3;
const int ERR_INVALIDCLIENTID = 0x00F4;
const int ERR_INVALIDCOMMAND = 0x00F5;
const int ERR_INVALIDDATALENGTH = 0x00F6;
const int ERR_INVALIDLENGTH = 0x00F7;
const int ERR_INVALIDCRC = 0x00F8;
class CHTDataLink;
class CHTDataSocket: public CSecureSocket {
public:
	//Constructor
	CHTDataSocket(CHTDataLink *pHTDataLink);
	//Destructor
	virtual ~CHTDataSocket(void);
	//Reads the data from the socket
	virtual void OnReceive(int clientId, int buffLength, QAbstractSocket socket, struct _SecHandle hCtxt);
	//Accepts a new connection on the socket
	BOOL Accept();
	//Decides the action to be taken on accepting a new connection
	virtual bool OnAccept(QAbstractSocket serviceSocket);
	//Resumes the accept thread
	bool ResumeAcceptThread();
	//Resumes the read thread
	bool ResumeReadThread();
	//Sends the data to the client over secure socket connection
	virtual const bool SendData(int clientId, PBYTE data, int len);
private:
#ifdef DFL_HTD_SOCK_DBG_ENABLE
	static void LogDebugMessage(QString   strDebugMessage);
#endif
private:
	CHTDataLink *m_pHTDataLink;
#ifdef DFL_HTD_SOCK_DBG_ENABLE
	static CDebugFileLogger m_debugFileLogger;
#endif
};
#endif //HT DATA QAbstractSocket decleration

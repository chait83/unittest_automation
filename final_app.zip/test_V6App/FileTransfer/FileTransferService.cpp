/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilties
/// @n Filename: CFileTransferService.cpp
/// @n Desc:	Implementation of CFileTransferService
///
// ****************************************************************
// Revision History
// ****************************************************************
#ifdef HTDT_SERVER
#include "HtDtServer.h"
#else
#ifdef V6APP_NOT_INCLUDED
#include "HtDataServer.h"
#endif
#endif
#include "FileTransferService.h"
#include "HtDataTransferEngine.h"
//****************************************************************************
/// CFileTransferService - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CFileTransferService::CFileTransferService()
//: m_pHTDataLink(NULL)
{
} //end CFileTransferService()
//****************************************************************************
/// ~CFileTransferService - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CFileTransferService::~CFileTransferService() {
	//if( NULL != m_pHTDataLink )
	//{
	//	//m_pHTDataLink->Disconnect();
	//	delete m_pHTDataLink;
	//	m_pHTDataLink = NULL;
	//}
}	//end ~CFileTransferService() 
//****************************************************************************
/// Start - Starts the DTE
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
BOOL CFileTransferService::Start() {
	BOOL bRet = FALSE;
#ifdef V6APP_NOT_INCLUDED
	QString   strDebugMsg;
	strDebugMsg = QString::asprintf(_T("FTS::Start - BEGIN "));
	theApp.LogDebugMessage(strDebugMsg);
#endif
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if (pHtDTE != NULL) {
#ifdef V6APP_NOT_INCLUDED
		strDebugMsg = QString::asprintf(_T("FTS::Start - HTDTE instantiated"));
		theApp.LogDebugMessage(strDebugMsg);
#endif
		if ( FALSE == pHtDTE->IsInitialized()) {
#ifdef V6APP_NOT_INCLUDED
			strDebugMsg = QString::asprintf(_T("FTS::Start - HTDTE Initializing"));
			theApp.LogDebugMessage(strDebugMsg);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			pHtDTE->SetDebugLogger(theApp.GetDebugFileLogger());
#endif
#endif
			T_HTDTE_INIT_RETURN eHtDTEReturn = pHtDTE->InitHTDTEngine(CHtDataTransferEngine::HTD_MODE_SERVER,
					CCESecureSocket::ST_MODE_SECURE);
			if (HTDTE_INIT_OK == eHtDTEReturn) {
#ifdef V6APP_NOT_INCLUDED
				strDebugMsg = QString::asprintf(_T("FTS::Start - HTDTE Start"));
				theApp.LogDebugMessage(strDebugMsg);	
#endif
				bRet = pHtDTE->Start();
			} else {
#ifdef V6APP_NOT_INCLUDED
				strDebugMsg = QString::asprintf(_T("FTS::Start - Faield to InitHTDTEngine ret id %d"), eHtDTEReturn);
				theApp.LogDebugMessage(strDebugMsg);
#endif
			}
		} else {
#ifdef V6APP_NOT_INCLUDED
			strDebugMsg = QString::asprintf(_T("FTS::Start - InitHTDTEngine Already inited"));
			theApp.LogDebugMessage(strDebugMsg);
#endif
		}
	}
	/*if( NULL == m_pHTDataLink )
	 {
	 m_pHTDataLink = new CHTDataLink();
	 m_pHTDataLink->Start();
	 bRet = true;
	 }*/
#ifdef V6APP_NOT_INCLUDED
	strDebugMsg = QString::asprintf(_T("FTS::Start - END ret %d"), bRet);
	theApp.LogDebugMessage(strDebugMsg);
#endif
	return bRet;
}	//end ProductionInterfaceFunc()
//****************************************************************************
/// Stop - Stop the HtDTE/HtDataLink
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
BOOL CFileTransferService::Stop() {
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	return pHtDTE->Stop();
}	//end ProductionInterfaceFunc()

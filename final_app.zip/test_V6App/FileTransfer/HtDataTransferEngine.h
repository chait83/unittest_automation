/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CEProductionSocket 
/// @n Filename:  CEProductionSocket.h
/// @n Description: This class is responsible for communication of recorder and
/// Production Interface tool
///
// **************************************************************************
// Revision History
//	Swathi 07/23/2014 Fix for the par 1-3GM1NP1: Do not set the date when 
//					 requested for Recorder Model Number alone. This can
//				 be possible for Remote Display Tool
// Swathi 07/30/2014 Install Device Certificate when requested via Production Tool
// **************************************************************************
#if !defined(AFX_FILETRANSFER_ENGINE_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_)
#define AFX_FILETRANSFER_ENGINE_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "CStorage.h"
#include "HtDataCommand.h"
#include "CEFileTransferSocket.h"
#include "HtDataTransceiveThread.h"
typedef enum htdte_init_return {
	HTDTE_INIT_OK,
	HTDTE_INIT_WINSOCK_ERR,
	HTDTE_INIT_INSTANCE_EXISTS,
	HTDTE_INIT_TCP_LISTEN_FAILED,
	HTDTE_INIT_NO_INSTANCE,
	HTDTE_NETWORK_UNAVAILABLE,
	HTDTE_ALREADY_INITED,
	HTDTE_INIT_TCP_CONN_FAILED,
} T_HTDTE_INIT_RETURN;
typedef enum {
	HTD_SHUTDOWN,		 // -
	HTD_TCP_CONN_CLOSE,
	//HTD_TCP_ACCEPT_CONN, //  - must stay in this order
	//HTD_TCP_ACCEPT_CLOSE,  //  |  handles after HtDTE Shuttdown closed by cleanup		
	//HTD_TCP_SERV_FAIL,
	HTD_NUM_EVENTS
} T_HTD_EVENT_LIST;
typedef enum {
	HTD_EX_SHUTDOWN,		 // -
	HTD_EX_TCP_CONN_CLOSE,
	HTD_TCP_ACCEPT_CONN, //  - must stay in this order
	HTD_TCP_ACCEPT_CLOSE,  //  |  handles after HtDTE Shuttdown closed by cleanup		
	HTD_TCP_SERV_FAIL,
	HTD_NUM_EX_EVENTS
} T_HTD_EX_EVENT_LIST;
class CHtDataTransferEngine : public QObject {
    Q_OBJECT
public:
	enum EHtdMode {
		HTD_MODE_NOT_SET = 0, HTD_MODE_CLIENT, HTD_MODE_SERVER
	};
private:
	CHtDataTransferEngine();
	virtual ~CHtDataTransferEngine();
public:
	// Get pointer to the Peer Services engine singleton.
	static CHtDataTransferEngine* GetHandle();
	//Initialize the engine
	T_HTDTE_INIT_RETURN InitHTDTEngine(EHtdMode eHtdMode, CCESecureSocket::ESocketTransMode eSTMode);
	//Start the Engine
	BOOL Start(QString strIPAddr = QString(""));
	//Stop the Engine
	BOOL Stop();
	EHtdMode GetHtdMode() const {
		return m_eHtdMode;
	}
	BOOL IsInitialized() const {
		return m_bInitialised;
	}
	HANDLE GetCmdRespEvHandle() {
		return m_hCmdRespEv;
	}
	BOOL PostHtdTransceiveMsg(UINT msgID, WPARAM wParam, LPARAM lParam);
	CCESecureSocket* GetHtDataSock() {
		return m_pHtDataSocket;
	}
	CCmdRespDataEx::UHtdCmdRespDataEx* GetHtdCmdRespDataEx();
	static QString A ConvertUnicodeStrToMBCSStr(const QString W &strUnicode, int nFieldLength);
	//Methods required fo initiate the request i.e. in client mode
	BOOL GetFileListFromRemoteSender(QString remotefName, QString &fileList);
	BOOL GetFileFromRemoteSender(QString remotefName, QString localfName, bool bOverWrite);
	BOOL SendFileToRemoteRecipient(QString localfName, QString remoteinterfName, QString remoteactualfName);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif
private:
	BOOL CleanUp(void);
	static DWORD WINAPI HtDtListenThread(LPVOID pParam);
	void ProcessNewConn();
	bool AddEvent(HANDLE hEv);
	bool CleanExcessEvents();
	bool DeleteEvent(HANDLE hEv);
	void PurgeConnList();
	BOOL ProcessIncomingData();
	void ResetCmd();
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	void LogDebugMessage(QString   strDebugMessage);
#endif
private:
	EHtdMode m_eHtdMode;
	CCESecureSocket::ESocketTransMode m_eHtdSTMode;
	// TRUE if HtDTE has been initialised. FALSE otherwise.
	BOOL m_bInitialised;
	const USHORT m_usTcpPort;
	// Mutex for ensuring only a single instance of HtDT Engine is used.
	static QMutex m_CreationMutex;
	// Mutex for ensuring that an instance of HtDT Engine is initalised
	// at most one time.
	HANDLE m_hHtDTEInit;
	CEFileTransferSocket *m_pHtdListenSock;
	// Critical section for safe access to m_connList.
	QMutex m_csConnList;
	CEFileTransferSocket *m_pHtDataSocket;
	int m_nContinuousTimeOutCnt; //Timeout count on the data sock
	HANDLE m_hHtDtListenerThread;
	HANDLE m_hHtCmdProcessThread;
	HANDLE m_hCmdProcEvent;
	CHtDataTransceiveThread *m_pHtDtThread;
	// Set up in InitHtDtEngine, these are events always there regardless of what 
	// connections there are.
	HANDLE m_hEvents[HTD_NUM_EVENTS];
	// Critical section for accessing m_pEvents.
	QMutex m_csEvents;
	// Stores dynamically sized array for holding all the standard event plus
	// an event for every TCP connection.
	HANDLE *m_pEvents;
	// Current count of event handles of interest, including TCP connections.
	int m_iEventCount;
	// Event handle for accepting new connections.
	HANDLE m_hAcceptedEv;
	CHtDataCmd *m_pCurHtdCmd; //Current Cmd under execution is pulled out from queue for processing
	HANDLE m_hCmdRespEv; //The event handle to trigger data resp completed
	QMutex m_csRespDataEx;
	CCmdRespDataEx::UHtdCmdRespDataEx m_uHtdCmdRespDataEx; //Make it pool when needed
	// Singleton instance of the HtDT(Historical Data Transfer) services engine.
	static CHtDataTransferEngine *m_pInstance;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	static CDebugFileLogger m_debugFileLogger;
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif //HTDT_ENGINE_H

//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		HTDataServer
/// @n Filename:  HTDataLink.cpp
/// @n Description: Implementation of the CHTDataLink class
///
// **************************************************************************
// Revision History
// **************************************************************************
#include "HTDataSocket.h"
#include "HTDataLink.h"
#include "comutil.h"
#define SEND_BUFFER_SIZE 8192
#ifdef DFL_HTD_LINK_DBG_ENABLE
CDebugFileLogger CHTDataLink::m_debugFileLogger(L"\\SDMemory\\HtdLinkDbgLogFile.txt", FALSE, (10*1024*1024));
#endif
// Constructor
CHTDataLink::CHTDataLink() : m_ClientId(0), m_pHTDataSocket(NULL), m_ePrevFTCmd(CHTDataLink::CMD_NONE), m_eCurFTCmd(
		CHTDataLink::CMD_NONE), m_eCmdState(CHTDataLink::CMD_ST_IDLE), m_strUploadFilePathInterim(_T("")), m_strUploadFilePathFinal(
		_T("")), m_pUploadFile(NULL), m_ulFileLen(0L), m_ulFileBytesRcvd(0L) {
} //end CHTDataLink()
//Destructor
CHTDataLink::~CHTDataLink() {
	//Delete the RTDataSocket
	if (m_pHTDataSocket != NULL) {
		delete m_pHTDataSocket;
		m_pHTDataSocket = NULL;
	}
	if (NULL != m_pUploadFile) {
		m_pUploadFile->Close();
		m_pUploadFile = NULL;
	}
} //end ~CHTDataLink()
//Starts the Data Link
void CHTDataLink::Start() {
	if (NULL == m_pHTDataSocket) {
		m_pHTDataSocket = new CHTDataSocket(this);
		m_pHTDataSocket->Accept();
	}
}
//****************************************************************************
/// CHTDataLink::ResetCmd
/// 
/// This function is used to reset the cmd state
///
/// @param[in] - NONE
///
/// @return	  - DWORD - returns the client id
///
//****************************************************************************
void CHTDataLink::ResetCmd() {
	m_ePrevFTCmd = m_eCurFTCmd;
	m_eCurFTCmd = CMD_NONE;
	m_eCmdState = CMD_ST_IDLE;
	m_strUploadFilePathFinal.Empty();
	m_strUploadFilePathInterim.Empty();
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf("::ResetCmd m_ePrevFTCmd %d m_eCurFTCmd %d m_eCmdState %d", m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
}
bool CHTDataLink::OnReceive(int clientId, BYTE *buf, int bytesRead) {
	bool retVal = false;
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf("\n::OnReceive BEGIN bytesRead %d m_ePrevFTCmd %d m_eCurFTCmd %d m_eCmdState %d", bytesRead, m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	size_t szNumCharsRet = 0;
	WCHAR wcBuf[1024];
	QString strBuf;
	wmemset(wcBuf, L'\0', 1024);
	mbstowcs_s(&szNumCharsRet, wcBuf, sizeof(wcBuf) / sizeof(WCHAR), (char*) buf, bytesRead);
	strBuf = QString::asprintf(_T("%s"), wcBuf);
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::OnReceive strBuf %s", strBuf);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	m_ClientId = clientId;
	if (m_eCurFTCmd == CMD_NONE) {
		QString Array
		saCmdArgs;
		BOOL bCmdRet = ParseCommandPacket((char*) buf, bytesRead, saCmdArgs);
		//Store the previous command for future purpose
		m_ePrevFTCmd = m_eCurFTCmd;
		if ((bCmdRet == TRUE) && (saCmdArgs.size())) {
			QString strCmd = saCmdArgs.at(0);
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("::OnReceive CMD %s recieved", strCmd);
			CHTDataLink::LogDebugMessage(strDbgMsg);
			#endif
			//CStringUtils 
			if (strCmd.CompareNoCase(_T("UPLOADFILE")) == 0) {
				m_eCurFTCmd = CMD_UPLOAD_FILE;
				m_eCmdState = CMD_ST_IDLE;
				retVal = ProcessUploadFileRequest(saCmdArgs);
			} else if (strCmd.CompareNoCase(_T("GETFILE")) == 0) {
				m_eCurFTCmd = CMD_GET_FILE;
				m_eCmdState = CMD_ST_IDLE;
				retVal = ProcessGetFileRequest(saCmdArgs);
			} else if (strCmd.CompareNoCase(_T("GETFILELIST")) == 0) {
				m_eCurFTCmd = CMD_GET_FILE_LIST;
				m_eCmdState = CMD_ST_IDLE;
				retVal = ProcessGetFileListRequest(saCmdArgs);
			} else {
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::OnReceive UNKNOWN CMD %s recieved, so ResetCmd Mode", strCmd);
				CHTDataLink::LogDebugMessage(strDbgMsg);
				#endif
				ResetCmd();
			}
		} else {
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("::OnReceive INVALID CMD recieved so ResetCmd Mode");
			CHTDataLink::LogDebugMessage(strDbgMsg);
			#endif
			ResetCmd();
		}
	} else {
		if ((m_eCmdState == CMD_ST_REJECTED) || (m_eCmdState == CMD_ST_END)) {
			retVal = true; //Done with this packet .. no buffering
		} else {
			retVal = ExecuteCmd((char*) buf, bytesRead);
		}
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::OnReceive END retVal %d m_ePrevFTCmd %d m_eCurFTCmd %d m_eCmdState %d", retVal, m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	//m_ClientId = 0;
	return retVal;
} //end OnReceive()
BOOL CHTDataLink::ParseCommandPacket(char *buf, int nBufLen, QString Array &saCommandParams) {
	BOOL bRet = TRUE;
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf("::ParseCommandPacket BEGIN bytesRead %d", nBufLen);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	char *pCmdPacket = NULL;
	if (nBufLen <= 1024) {
		pCmdPacket = new char[nBufLen + 1];
		memset(pCmdPacket, '\0', nBufLen);
		errno_t nErr = 0;
		size_t szNumCharsRet = 0;
		if (NULL != pCmdPacket) {
			strcpy_s(pCmdPacket, nBufLen, buf);
			WCHAR wcTmpBuf[1024];
			QString strTmpBuf;
			wmemset(wcTmpBuf, L'\0', 1024);
			mbstowcs_s(&szNumCharsRet, wcTmpBuf, sizeof(wcTmpBuf) / sizeof(WCHAR), pCmdPacket, nBufLen);
			strTmpBuf = QString::asprintf(_T("%s"), wcTmpBuf);
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("::PCP strBuf %s nErr %d szNumCharsRet %d", strTmpBuf, nErr, szNumCharsRet);
			CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		}
		char *chTempBuf = buf;
		char *chToken = NULL;
		chToken = strtok(chTempBuf, "$");
		int nTokenCnt = 0;
		char sCommand[24] = {0};
		char sInterimFilePath[256] = {0};
		char sFinalFilePath[256] = {0};
		char sFileLength[32] = {0};
		QString strCommand;
		QString strIntFilePath;
		QString strFinalPath;
		QString strFileLen;
		WCHAR wcTemp[256];
		while (chToken != NULL) {
			++nTokenCnt;
			switch (nTokenCnt) {
				case 1: {
					strcpy(sCommand, chToken);
					wmemset(wcTemp, L'\0', 256);
					mbstowcs_s(&szNumCharsRet, wcTemp, sizeof(wcTemp) / sizeof(WCHAR), sCommand, 256);
					strCommand = QString::asprintf(_T("%s"), wcTemp);
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::PCP Command %s", strCommand);
					CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
					saCommandParams.Add(strCommand);
				}
				break;
				case 2:
				strcpy(sInterimFilePath, chToken);
				wmemset(wcTemp, L'\0', 256);
				mbstowcs_s(&szNumCharsRet, wcTemp, sizeof(wcTemp) / sizeof(WCHAR), sInterimFilePath, 256);
				strIntFilePath = QString::asprintf(_T("%s"), wcTemp);
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::PCP sIntFilePath %s", strIntFilePath);
				CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
				saCommandParams.Add(strIntFilePath);
				break;
				case 3:
				strcpy(sFinalFilePath, chToken);
				wmemset(wcTemp, L'\0', 256);
				mbstowcs_s(&szNumCharsRet, wcTemp, sizeof(wcTemp) / sizeof(WCHAR), sFinalFilePath, 256);
				strFinalPath = QString::asprintf(_T("%s"), wcTemp);
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::PCP sFinalPath %s", strFinalPath);
				CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
				saCommandParams.Add(strFinalPath);
				break;
				case 4:
				strcpy(sFileLength, chToken);
				wmemset(wcTemp, L'\0', 256);
				mbstowcs_s(&szNumCharsRet, wcTemp, sizeof(wcTemp) / sizeof(WCHAR), sFileLength, 32);
				strFileLen = QString::asprintf(_T("%s"), wcTemp);
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::PCP strFileLen %s", strFileLen);
				CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
				saCommandParams.Add(strFileLen);
				break;
				default:
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("PCP Default %s", strFileLen);
				CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
				break;
			}
			chToken = strtok(NULL, "$");
		}
		delete[] pCmdPacket;
		pCmdPacket = NULL;
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::ParseCommandPacket END bRet %d", bRet);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
BOOL CHTDataLink::ExecuteCmd(char *buf, int bytesRead) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf("::ExecuteCmd BEGIN bytesRead %d m_ePrevFTCmd %d m_eCurFTCmd %d m_eCmdState %d", bytesRead, m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = TRUE;
	switch (m_eCurFTCmd) {
	case CMD_UPLOAD_FILE: {
		bRet = UploadStateMachine(buf, bytesRead);
		if (m_eCmdState == CMD_ST_END) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::ExecuteCmd CMD_UPLOAD_FILE m_eCmdState %d is CMD_ST_END so RESET CMD for next command", bRet, m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
				CHTDataLink::LogDebugMessage(strDbgMsg);
				#endif
			ResetCmd();
		}
	}
		break;
	case CMD_GET_FILE: {
		//bRet = ::SendFileToClient(
	}
		break;
	case CMD_GET_FILE_LIST: {
	}
		break;
	default:
		break;
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::ExecuteCmd END bRet %d m_ePrevFTCmd %d m_eCurFTCmd %d m_eCmdState %d", bRet, m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
BOOL CHTDataLink::UploadStateMachine(char *buf, int bytesRead) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf("::USM BEGIN bytesRead %d m_ePrevFTCmd %d m_eCurFTCmd %d m_eCmdState %d", bytesRead, m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = TRUE;
	DWORD dwRet = 0;
	switch (m_eCmdState) {
	case CMD_ST_ACCEPTED: {
		//Attmept to create Folder if its not present
		CreateDirectory(L"\\AutoOps", NULL);
		m_pUploadFile = new CStorage();
		QFileDevice::FileError fe;
		BOOL bFileIsOpen = FALSE;
		if (NULL != m_pUploadFile) {
		bFileIsOpen = m_pUploadFile->Open(m_strUploadFilePathInterim,
				QFile::ReadWrite | | QFile::typeBinary | QFile::shareDenyNone, &fe);
	}
	if (bFileIsOpen) {
		dwRet = m_pUploadFile->Write(buf, bytesRead);
		if (dwRet == ERROR_SUCCESS) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD_ST_ACCEPTED Write Succeeded dwRet %d m_ulFileBytesRcvd %lu out of %lu ErrCode %d", dwRet, m_ulFileBytesRcvd, m_ulFileLen, GetLastError());
					CHTDataLink::LogDebugMessage(strDbgMsg);
					#endif			
		} else {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD_ST_ACCEPTED Write Failed dwRet %d m_ulFileBytesRcvd %lu out of %lu ErrCode %d", dwRet, m_ulFileBytesRcvd, m_ulFileLen, GetLastError());
					CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		}
		m_eCmdState = CMD_ST_BEGIN;
		m_ulFileBytesRcvd += bytesRead;
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::USM CMD_ST_ACCEPTED DONE dwRet %d m_ulFileBytesRcvd %lu out of %lu ErrCode %d", dwRet, m_ulFileBytesRcvd, m_ulFileLen, GetLastError());
				CHTDataLink::LogDebugMessage(strDbgMsg);
				#endif
	} else {
		//Log it
		m_eCmdState = CMD_ST_END;
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::USM CMD_ST_BEGIN Something wrong no file present");
				CHTDataLink::LogDebugMessage(strDbgMsg);
				#endif
	}
}
	break;
case CMD_ST_BEGIN: {
	if (NULL != m_pUploadFile) {
		dwRet = m_pUploadFile->Write(buf, bytesRead);
		if (dwRet == ERROR_SUCCESS) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD_ST_BEGIN Write Succeeded dwRet %d m_ulFileBytesRcvd %lu out of %lu ErrCode %d", dwRet, m_ulFileBytesRcvd, m_ulFileLen, GetLastError());
					CHTDataLink::LogDebugMessage(strDbgMsg);
					#endif			
		} else {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD_ST_BEGIN Write Failed dwRet %d m_ulFileBytesRcvd %lu out of %lu", dwRet, m_ulFileBytesRcvd, m_ulFileLen);
					CHTDataLink::LogDebugMessage(strDbgMsg);
#endif	
		}
		m_ulFileBytesRcvd += bytesRead;
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::USM CMD_ST_BEGIN DONE dwRet %d m_ulFileBytesRcvd %lu out of %lu", dwRet, m_ulFileBytesRcvd, m_ulFileLen);
				CHTDataLink::LogDebugMessage(strDbgMsg);
				#endif				
	} else {
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("::USM CMD_ST_BEGIN Something wrong no file present");
				CHTDataLink::LogDebugMessage(strDbgMsg);
				#endif
	}
}
	break;
default: {
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("::USM unhandled state %d", m_eCmdState);
			CHTDataLink::LogDebugMessage(strDbgMsg);
			#endif
}
	break;
	}
	//End the state machine if all bytes are received
	if (m_ulFileBytesRcvd == m_ulFileLen) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("::USM CMD ST %d close and rename file dwRet %lu m_ulFileBytesRcvd %lu out of %lu", m_eCmdState, dwRet, m_ulFileBytesRcvd, m_ulFileLen);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
		if (m_pUploadFile != NULL) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("::USM CMD ST %d Close file dwRet %lu m_ulFileBytesRcvd %lu out of %lu", m_eCmdState, dwRet, m_ulFileBytesRcvd, m_ulFileLen);
			CHTDataLink::LogDebugMessage(strDbgMsg);
			#endif
			m_pUploadFile->Flush();
			m_pUploadFile->Close();
			delete m_pUploadFile;
			//Rename the file
			int nRenameRetry = 3;
			bool bRenamed = false;
			while (nRenameRetry > 0) {
				nRenameRetry--;
				//Rename the File to th final path
				try {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD ST %d rename file dwRet %lu m_ulFileBytesRcvd %lu out of %lu", m_eCmdState, dwRet, m_ulFileBytesRcvd, m_ulFileLen);
					CHTDataLink::LogDebugMessage(strDbgMsg);
					#endif
					CStorage::Rename(m_strUploadFilePathInterim, m_strUploadFilePathFinal);
					bRenamed = true;
					break;
				} catch (QFileDevice::FileError *pEx) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD ST %d rename Failed nRenameRetry %d file %s new name %s cause = %d", m_eCmdState, nRenameRetry, m_strUploadFilePathInterim, m_strUploadFilePathFinal, pEx->m_cause);
					CHTDataLink::LogDebugMessage(strDbgMsg);
					#endif
					qDebug(_T("File %20s not found, cause = %d\n"), m_strUploadFilePathInterim, pEx->m_cause);
					pEx->Delete();
					sleep(20);
				}
			}
			if (bRenamed == false) {
				BOOL bDeleted = false;
				//Still not ablel to rename the file ..so delete it
				try {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD ST %d Delete file dwRet %lu m_ulFileBytesRcvd %lu out of %lu", m_eCmdState, dwRet, m_ulFileBytesRcvd, m_ulFileLen);
					CHTDataLink::LogDebugMessage(strDbgMsg);
					#endif
					bDeleted = ::DeleteFile(/*(QString   )(LPCTSTR)*/m_strUploadFilePathInterim);
				} catch (QFileDevice::FileError *pEx) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("::USM CMD ST %d Delete Failed file %s cause = %d", m_eCmdState, m_strUploadFilePathInterim, pEx->m_cause);
					CHTDataLink::LogDebugMessage(strDbgMsg);
					#endif
					qDebug(_T("File %20s not found, cause = %d\n"), m_strUploadFilePathInterim, pEx->m_cause);
					pEx->Delete();
					sleep(20);
				}
			}
		}
		//Set the CMD state to END
		m_eCmdState = CMD_ST_END;
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("::USM CMD ST %d file.closed move END state", m_eCmdState);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::USM END bRet %d m_ePrevFTCmd %d m_eCurFTCmd %d m_eCmdState %d", bRet, m_ePrevFTCmd, m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
bool CHTDataLink::ProcessUploadFileRequest(const QString Array &saCmdArgs) {
	bool bRet = true;
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf("::ProcessUploadFileRequest BEGIN Args %d", saCmdArgs.size());
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	m_ulFileLen = 0; //Reset first
	if (4 == saCmdArgs.size())//process the connand only if input params are valid
	{
		//Set the current Command
		m_eCurFTCmd = CMD_UPLOAD_FILE;
		m_eCmdState = CMD_ST_ACCEPTED;
		m_strUploadFilePathInterim = QString::asprintf(_T("%s"), saCmdArgs.at(1));
		m_strUploadFilePathFinal = QString::asprintf(_T("%s"), saCmdArgs.at(2));
		m_ulFileLen = _ttoi(saCmdArgs.at(3));
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::PUFR CMD ACCEPTED m_eCurFTCmd %d m_eCmdState %d IntFilePath %s sFinalFilePath %s ulFileLen %lu", m_eCurFTCmd, m_eCmdState, m_strUploadFilePathInterim, m_strUploadFilePathFinal, m_ulFileLen);
		CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		if (m_pHTDataSocket != NULL) {
			int nRet = m_pHTDataSocket->SendData(m_ClientId, (PBYTE) "OK", 2);
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::PUFR Sent OK nRet %d", nRet);
			CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		}
		m_ulFileBytesRcvd = 0; //Reset the received file bytes
	} else {
		//Reset the command to None
		m_eCurFTCmd = CMD_NONE;
		m_eCmdState = CMD_ST_REJECTED;//Reject the Command
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::PUFR CMD REJECTED m_eCurFTCmd %d m_eCmdState %d", m_eCurFTCmd, m_eCmdState);
		CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::ProcessUploadFileRequest END m_eCurFTCmd %d m_eCmdState %d", m_eCurFTCmd, m_eCmdState);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
BOOL CHTDataLink::SendFile(QString fName) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf("::SendFile ClientId = %ld BEGIN fName %s", m_ClientId, fName);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = TRUE;				// return value
	LONG fileLength = 0;
	LONG cbleftToSend = 0;	// used to monitor the progress of a sending operation
	BYTE *sendData = NULL;			// pointer to buffer for sending data (memory is allocated after sending file size)
	QFile sourceFile;
	QFileDevice::FileError fe;
	BOOL bFileIsOpen = FALSE;
	if (!(bFileIsOpen = sourceFile.Open(fName, QFile::ReadOnly | QFile::typeBinary, &fe))) {
		TCHAR strCause[256];
		strCause = CStorage::GetErrorMessage(fe);
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SF encountered an error while opening the local file File name = %s Cause = %s m_cause = %d m_IOsError = %d", fe.m_strFileName, strCause, fe.m_cause, fe.m_lOsError);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif	
		if (m_pHTDataSocket != NULL) {
			/* you should handle the error here */
			int nRetKO = m_pHTDataSocket->SendData(m_ClientId, (PBYTE) "KO", 2);
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SF SendKO = %ld", nRetKO);
			CHTDataLink::LogDebugMessage(strDbgMsg);
			#endif	
		}
		bRet = FALSE;
		goto PreReturnCleanup;
	}
	// first send length of file
	if (m_pHTDataSocket != NULL) {
		int nRetOK = m_pHTDataSocket->SendData(m_ClientId, (PBYTE) "OK", 2);
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SF SendOK = %ld", nRetOK);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif	
	}
	fileLength = sourceFile.size();
	cbleftToSend = sizeof(fileLength);
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("\t::SF fileLength(local format) = %ld, cbleftToSend = %ld", fileLength ,cbleftToSend);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	LONG lNwFileLength = htonl(fileLength);
	do {
		LONG cbBytesSent = 0;
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SF Sending FileLength(nw format) = %ld, cbleftToSend = %ld", lNwFileLength ,cbleftToSend);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
		BYTE *bp = (BYTE*) (&lNwFileLength) + sizeof(lNwFileLength) - cbleftToSend;
		if (m_pHTDataSocket != NULL) {
			cbBytesSent = m_pHTDataSocket->SendData(m_ClientId, bp, cbleftToSend);
		}
		// test for errors and get out if they occurred
		if (cbBytesSent == QAbstractSocket_ERROR) {
			int iErr = ::GetLastError();
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SF test for errors %d and get out if they occurred", iErr);
			CHTDataLink::LogDebugMessage(strDbgMsg);
			#endif
			/* qDebug("::SendFile returned a socket error while sending file length\n"
			 "\tNumber of Bytes sent = %d\n"
			 "\tGetLastError = %d\n", cbBytesSent, iErr );
			 
			 you should handle the error here */
			bRet = FALSE;
			goto PreReturnCleanup;
		}
		// data was successfully sent, so account for it with already-sent data
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SF Filelength was successfully sent cbleftToSend = %ld cbBytesSent = %ld", cbleftToSend, cbBytesSent);
			CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
		cbleftToSend -= cbBytesSent;
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SF Filelength to be sent in next itr cbleftToSend = %ld out of cbBytesSent = %ld", cbleftToSend, cbBytesSent);
			CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
	} while (cbleftToSend > 0);
	// now send the file's data
	sleep(2);
	if (fileLength != 0) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SF Start Sending the file cbleftToSend = %ld", cbleftToSend);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
		sendData = new BYTE[SEND_BUFFER_SIZE];
		cbleftToSend = fileLength;
		LONG lTotalBytesSent = 0;
		do {
			// read next chunk of SEND_BUFFER_SIZE bytes from file
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SF FileData - read next chunk cbleftToSend = %ld", cbleftToSend);
			CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
			LONG sendThisTime = 0;
			LONG doneSoFar = 0;
			LONG buffOffset = 0;
			sendThisTime = sourceFile.Read(sendData, SEND_BUFFER_SIZE);
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SF FileData - read next chunk sendThisTime = %ld", sendThisTime);
			CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
			buffOffset = 0;
			do {
				if (m_pHTDataSocket != NULL) {
					doneSoFar = m_pHTDataSocket->SendData(m_ClientId, (sendData + buffOffset), sendThisTime);
					lTotalBytesSent += doneSoFar;
				}
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("\t::SF FileData - itr doneSoFar = %ld lTotalBytesSent so far %ld",doneSoFar , lTotalBytesSent, GetTickCount());
				CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
				// test for errors and get out if they occurred
				if (doneSoFar == QAbstractSocket_ERROR) {
					int iErr = ::GetLastError();
#ifdef DFL_HTD_LINK_DBG_ENABLE
					strDbgMsg = QString::asprintf("\t::SF returned a socket error while sending chunked file data\tNumber of Bytes sent = %ld\tGetLastError = %d", doneSoFar, iErr);
					CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
					/*qDebug("::SendFile returned a socket error while sending chunked file data\n"
					 "\tNumber of Bytes sent = %d\n"
					 "\tGetLastError = %d\n", doneSoFar, iErr );
					 you should handle the error here */
					bRet = FALSE;
					goto PreReturnCleanup;
				}
				/***************************
				 //un-comment this code and put a breakpoint here to prove to yourself that sockets can send fewer bytes than requested
				 if ( doneSoFar != sendThisTime )
				 {
				 int ii = 0;
				 }
				 ****************************/
				// data was successfully sent, so account for it with already-sent data			
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("\t::SF FileData - doneSoFar = %ld, buffOffset = %ld, sendThisTime = %ld, cbleftToSend = %ld", doneSoFar, buffOffset, sendThisTime, cbleftToSend);
				CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
				buffOffset += doneSoFar;
				sendThisTime -= doneSoFar;
				cbleftToSend -= doneSoFar;
#ifdef DFL_HTD_LINK_DBG_ENABLE
				strDbgMsg = QString::asprintf("\t::SF FileData - for next itr doneSoFar = %ld, buffOffset = %ld, sendThisTime = %ld, cbleftToSend = %ld", doneSoFar, buffOffset, sendThisTime, cbleftToSend);
				CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
			} while (sendThisTime > 0); //End of data chunk iteration
		} while (cbleftToSend > 0); //End of File Transfer
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SF end of sending file cbleftToSend = %ld lTotalBytesSent = %ld fileLength %ld", cbleftToSend, lTotalBytesSent, fileLength);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
	} //End of File length condition
	else {
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SF Zero length file cbleftToSend = %ld", cbleftToSend);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
	}
	PreReturnCleanup:		// labelled goto destination
	// free allocated memory
	// if we got here from a goto that skipped allocation, delete of NULL pointer
	// is permissible under C++ standard and is harmless
	delete[] sendData;
	if (bFileIsOpen) {
		sourceFile.Close();		// only close file if it's open (open might have failed above)
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::SendFile ClientId = %lu filename %s END", m_ClientId, fName);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
bool CHTDataLink::ProcessGetFileRequest(const QString Array &saCmdArgs) {
	bool bRet = true;
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf("::ProcessGetFileRequest BEGIN Args %d", saCmdArgs.size());
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	int nParams = saCmdArgs.size();
	BOOL bSendRet = FALSE;
	if (nParams >= 2) //process the connand only if input params are valid
	{
		//Set the current Command
		m_eCurFTCmd = CMD_GET_FILE;
		m_eCmdState = CMD_ST_ACCEPTED;
		QString strCommand = saCmdArgs.at(0);
		QString strReqFilePath = saCmdArgs.at(1);
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::PGFR CMD ACCEPTED m_eCurFTCmd %d m_eCmdState %d ReqFilePath %s", m_eCurFTCmd, m_eCmdState, strReqFilePath);
		CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		bSendRet = SendFile(strReqFilePath);
		m_eCurFTCmd = CMD_NONE;
		m_eCmdState = CMD_ST_END;
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::ProcessGetFileRequest END m_eCurFTCmd %d m_eCmdState %d bSendRet %d", m_eCurFTCmd, m_eCmdState, bSendRet);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
bool CHTDataLink::ProcessGetFileListRequest(const QString Array &saCmdArgs) {
	bool bRet = true;
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString strDbgMsg;
	strDbgMsg = QString::asprintf("::ProcessGetFileListRequest BEGIN Args %d", saCmdArgs.size());
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	int nParams = saCmdArgs.size();
	BOOL bSendRet = FALSE;
	if (nParams >= 2) //process the connand only if input params are valid
	{
		//Set the current Command
		m_eCurFTCmd = CMD_GET_FILE_LIST;
		m_eCmdState = CMD_ST_ACCEPTED;
		QString strCommand = saCmdArgs.at(0);
		QString strFolderPath = saCmdArgs.at(1);
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::PGFLR CMD ACCEPTED m_eCurFTCmd %d m_eCmdState %d strFolderPath %s", m_eCurFTCmd, m_eCmdState, strFolderPath);
		CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		bSendRet = SendFileList(strFolderPath);
		m_eCurFTCmd = CMD_NONE;
		m_eCmdState = CMD_ST_END;
	}
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("::ProcessGetFileListRequest END m_eCurFTCmd %d m_eCmdState %d bSendRet %d", m_eCurFTCmd, m_eCmdState, bSendRet);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
BOOL CHTDataLink::SendFileList(QString strFolderPath) {
#ifdef DFL_HTD_LINK_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf("::SendFileList ClientId = %lu BEGIN FolderPath %s", m_ClientId, strFolderPath);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = TRUE;				// return value
	QString strFileList;
	GetFileList(strFolderPath, strFileList);
	//strFileList.Trimright();
	LONG lFileListLength = strFileList.size();
	LONG cbleftToSend = 0;	// used to monitor the progress of a sending operation
	char *sendData = NULL;			// pointer to buffer for sending data (memory is allocated after sending file size)
	if (m_pHTDataSocket != NULL) {
		int nRetOK = m_pHTDataSocket->SendData(m_ClientId, (PBYTE) "OK", 2);
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SFL strFileList %s SendOK = %ld", strFileList, nRetOK);
		CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif	
	}
	cbleftToSend = sizeof(lFileListLength);
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("\t::SFL fileListLength = %ld, cbleftToSend = %ld", lFileListLength, cbleftToSend);
	CHTDataLink::LogDebugMessage(strDbgMsg);
	#endif
	LONG lNwFileLength = htonl(lFileListLength);
	do {
		ULONG cbBytesSent;
		BYTE *bp = (BYTE*) (&lNwFileLength) + sizeof(lNwFileLength) - cbleftToSend;
		if (m_pHTDataSocket != NULL) {
			cbBytesSent = m_pHTDataSocket->SendData(m_ClientId, bp, cbleftToSend);
		}
		// test for errors and get out if they occurred
		if (cbBytesSent == QAbstractSocket_ERROR) {
			int iErr = ::GetLastError();
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SFL test for errors %d and get out if they occurred", iErr);
			CHTDataLink::LogDebugMessage(strDbgMsg);
			#endif
			/* qDebug("::SendFile returned a socket error while sending file length\n"
			 "\tNumber of Bytes sent = %d\n"
			 "\tGetLastError = %d\n", cbBytesSent, iErr );
			 
			 you should handle the error here */
			bRet = FALSE;
			goto PreReturnCleanup;
		}
		// data was successfully sent, so account for it with already-sent data
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SFL FileListLength was successfully sent cbleftToSend = %lu cbBytesSent = %lu", cbleftToSend, cbBytesSent);
			CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
		cbleftToSend -= cbBytesSent;
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SFL FileListLength to be sent in next itr cbleftToSend = %lu out of cbBytesSent = %lu", cbleftToSend, cbBytesSent);
			CHTDataLink::LogDebugMessage(strDbgMsg);
		#endif
	} while (cbleftToSend > 0);
if( lFileListLength != 0 ) //Prepare to send data ..check length
{
	// now send the fileList data	
	sendData = new char[lFileListLength+1];
	memset(sendData, '\0', lFileListLength+1);
	LONG sendThisTime = 0;
	LONG doneSoFar = 0;
	LONG buffOffset = 0;
	cbleftToSend = lFileListLength;
	sendThisTime = cbleftToSend;
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("\t::SFL FileListLength cbleftToSend %ld sendThisTime = %ld", cbleftToSend, sendThisTime);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	size_t szNumCharConverted = 0;
	wcstombs_s(&szNumCharConverted, sendData, sendThisTime, strFileList, lFileListLength);
#ifdef DFL_HTD_LINK_DBG_ENABLE
	strDbgMsg = QString::asprintf("\t::SFL Converted to mbs szNumCharConverted = %d", szNumCharConverted);
	CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
	do
	{
		if( m_pHTDataSocket != NULL )
		{
			doneSoFar = m_pHTDataSocket->SendData( m_ClientId, (PBYTE)(sendData + buffOffset), sendThisTime );
		}
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SFL sending FileList Data doneSoFar = %ld", doneSoFar , GetTickCount());
		CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		// test for errors and get out if they occurred
		if ( doneSoFar == QAbstractSocket_ERROR )
		{
			int iErr = ::GetLastError();
#ifdef DFL_HTD_LINK_DBG_ENABLE
			strDbgMsg = QString::asprintf("\t::SFL returned a socket error while sending chunked file data\tNumber of Bytes sent = %ld\tGetLastError = %d", doneSoFar, iErr);
			CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
			/*qDebug("::SendFile returned a socket error while sending chunked file data\n"
			 "\tNumber of Bytes sent = %d\n"
			 "\tGetLastError = %d\n", doneSoFar, iErr );
			 you should handle the error here */
			bRet = FALSE;
			goto PreReturnCleanup;
		}
		/***************************
		 //un-comment this code and put a breakpoint here to prove to yourself that sockets can send fewer bytes than requested
		 if ( doneSoFar != sendThisTime )
		 {
		 int ii = 0;
		 }
		 ****************************/
		// data was successfully sent, so account for it with already-sent data			
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SFL doneSoFar = %ld, buffOffset = %ld, sendThisTime = %ld, cbleftToSend = %ld", doneSoFar, buffOffset, sendThisTime, cbleftToSend);
		CHTDataLink::LogDebugMessage(strDbgMsg);
#endif
		buffOffset += doneSoFar;
		sendThisTime -= doneSoFar;
		cbleftToSend -= doneSoFar;
#ifdef DFL_HTD_LINK_DBG_ENABLE
		strDbgMsg = QString::asprintf("\t::SFL for next itr doneSoFar = %ld, buffOffset = % %
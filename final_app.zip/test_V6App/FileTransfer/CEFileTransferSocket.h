/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CEProductionSocket 
/// @n Filename:  CEProductionSocket.h
/// @n Description: This class is responsible for communication of recorder and
/// Production Interface tool
///
// **************************************************************************
// Revision History
//	Swathi 07/23/2014 Fix for the par 1-3GM1NP1: Do not set the date when 
//					 requested for Recorder Model Number alone. This can
//				 be possible for Remote Display Tool
// Swathi 07/30/2014 Install Device Certificate when requested via Production Tool
// **************************************************************************
#if !defined(AFX_FILETRANSFER_QAbstractSocket_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_)
#define AFX_FILETRANSFER_QAbstractSocket_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V7SecureSocket.h"
#include "CStorage.h"
#include "HtDataCommand.h"
#ifndef DBG_FILE_LOG_SSL_DBG_ENABLE
#undef DBG_FILE_LOG_FTS_DBG_ENABLE
#endif
typedef CTList<CHtDataCmd*> CHtdCmdPtrList;
class CEFileTransferSocket: public CV7SecureSocket {
public:
	CEFileTransferSocket(ESocketTransMode eSTMode = ST_MODE_NON_SECURE);
	CEFileTransferSocket(QAbstractSocket skt, ESocketRoleType role, CredHandle *hServerCreds, CtxtHandle *hContext);
	virtual ~CEFileTransferSocket();
	bool OnReceive(char *buf, int len, E_ON_RECV_BUF_ACTION &eOrbAction);
	bool Accept(UINT localPort, int maxConn = SOMAXCONN);
	virtual bool OnAccept(QAbstractSocket serviceSocket);
	virtual void OnClose(int closeEvent);
	bool Create();
	HRESULT Disconnect();
	bool Connect(QString &addr, UINT remotePort, HANDLE hCloseEv = NULL);
	void AcceptServiceSocket(QAbstractSocket serviceSock, HANDLE hCloseEv);
	QAbstractSocket GetServiceSocket() {
		return m_sServSock;
	}
	;
	HANDLE GetAcceptEvHandle() {
		return m_hAcceptEv;
	}
	;
	HANDLE GetAcceptedEvHandle() {
		return m_hAcceptedEv;
	}
	;
	HANDLE GetCloseEvHandle() {
		return m_hCloseEv;
	}
	;
	HANDLE GetRecvEvHandle() {
		return m_hRecvEv;
	}
	;
	void SetFailedServEvent(HANDLE hEv) {
		m_hServFailed = hEv;
	}
	;
	HANDLE GetCmdRespEvHandle() {
		return m_hCmdRespEv;
	}
	bool ResumeAcceptThread();
	bool ResumeReadThread();
	CHtDataCmd* GetHtdCmdFromQueue();
protected:
	bool OnConnect(QString &addr);QString A ConvertUnicodeStrToMBCSStr(const QString W &strUnicode, int nFieldLength);
	BOOL AddHtdCmdToQueue(char *buf, int bytesRead);
	void CleanHtdCmds();
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	virtual void LogDebugMessage(QString   strDebugMsg);
	#endif
private:
	QAbstractSocket m_sServSock; //Service Socket that is accepted just now
	//Set of events that are required by connection/cmd listner
	HANDLE m_hAcceptEv; //Event to notify the Manager
	HANDLE m_hAcceptedEv;
	HANDLE m_hRecvEv; //Received data from the raw socket
	HANDLE m_hCloseEv; //Connection is closed
	HANDLE m_hServFailed; //Server failed
	HANDLE m_hConnEv;
	HANDLE m_hCmdRespEv;
	CHtdCmdPtrList m_listHtdCmd; //Htd Cmd Lists
	QMutex m_csHtdCmdList;	//!< Controls Cmd List access.
};
#endif //FILETRANSFER_QAbstractSocket_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  FileTransfer 
/// @n Filename:  HtDataTransceiveThread.cpp
/// @n Description: This class is responsible for communication of recorder and
/// Production Interface tool
///
// **************************************************************************
// Revision History
// Shankar Rao P 16-Sep-2019	Initial Draft - Framework
// **************************************************************************
#include "HtDataTransceiveThread.h"
#include "HtDataCommand.h"
#include "HtDataTransferEngine.h"
// IMPLEMENT_DYNCREATE(CHtDataTransceiveThread, QThread)
//****************************************************************************
// CHtDataTransceiveThread( )
///
/// Constructor
///
//****************************************************************************
CHtDataTransceiveThread::CHtDataTransceiveThread()
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
: m_pDebugFileLogger(NULL)
#endif
{
}
//****************************************************************************
// ~CHtDataTransceiveThread( )
///
/// Destructor
///
//****************************************************************************
CHtDataTransceiveThread::~CHtDataTransceiveThread() {
}
//****************************************************************************
// BOOL InitInstance()
///
/// InitInstance method
///
//****************************************************************************
BOOL CHtDataTransceiveThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
//****************************************************************************
// int ExitInstance()
///
/// ExitInstance method
///
//****************************************************************************
int CHtDataTransceiveThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	QThread::exit();
	return 0;
}
////PreTranslateMessage to handle the messages before dispatch and forward to the default winproc is needed
BOOL CHtDataTransceiveThread::PreTranslateMessage(MSG *pMsg) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::PreTranslateMessage BEGIN msg ID %d") , pMsg->message);
	LogDebugMessage(strDbgMsg);
#endif
	// Is it the Message you want?  
	switch (pMsg->message) {
	case WM_HTD_SEND_FILE: {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("GFLR::PreTranslateMessage WM_HTD_SEND_FILE msg ID %d"), pMsg->message );
			LogDebugMessage(strDbgMsg);
#endif
		OnHtdSendFile(pMsg->wParam, pMsg->lParam);
		break;
	}
	case WM_HTD_SEND_FILE_LIST: {
		OnHtdSendFileList(pMsg->wParam, pMsg->lParam);
		break;
	}
	case WM_HTD_RECEIVE_FILE: {
		OnHtdReceiveFile(pMsg->wParam, pMsg->lParam);
		break;
	}
	default: {
		// Call MFC to have it continue processing the message
		return QThread::PreTranslateMessage(pMsg);
	}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::PreTranslateMessage End msg ID %d"), pMsg->message );
	LogDebugMessage(strDbgMsg);
#endif
	return TRUE;
}
/****************************************************************************
 Description - Posted from FT ENgine when requested to send a file
 Parameters - SendFileCmd
 Returns - 0
 ****************************************************************************/
void CHtDataTransceiveThread::OnHtdSendFile(WPARAM wParam, LPARAM lParam) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::OnHtdSendFile BEGIN ") );
	LogDebugMessage(strDbgMsg);
	#endif
	CHtDataCmd *pHtdCmd = (CHtDataCmd*) wParam;
	CHtDataTransferEngine *pHtDTE = (CHtDataTransferEngine*) lParam;
	if ((NULL != pHtdCmd) && (NULL != pHtDTE)) {
		if ( TRUE /*== pHtdCmd->Process() */) {
			pHtdCmd->End();
		} else {
			pHtdCmd->Abort();
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::OnHtdSendFile END ") );
	LogDebugMessage(strDbgMsg);
	#endif
}
/****************************************************************************
 Description - Posted from FT Engine when requested to send file list in a given folder
 Parameters - SendFileListCmd
 Returns - 0
 ****************************************************************************/
void CHtDataTransceiveThread::OnHtdSendFileList(WPARAM wParam, LPARAM lParam) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::OnHtdSendFile BEGIN ") );
	LogDebugMessage(strDbgMsg);
	#endif
	CHtDataCmd *pHtdCmd = (CHtDataCmd*) wParam;
	CHtDataTransferEngine *pHtDTE = (CHtDataTransferEngine*) lParam;
	if ((NULL != pHtdCmd) && (NULL != pHtDTE)) {
		if ( TRUE /*== pHtdCmd->Process()*/) {
			pHtdCmd->End();
		} else {
			pHtdCmd->Abort();
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::OnHtdSendFile END ") );
	LogDebugMessage(strDbgMsg);
	#endif
}
/****************************************************************************
 Description - Posted from FT Engine when requested to Receive file
 Parameters - ReceiveFile Cmd
 Returns - 0
 ****************************************************************************/
void CHtDataTransceiveThread::OnHtdReceiveFile(WPARAM wParam, LPARAM lParam) {
	CHtDataCmd *pHtdCmd = (CHtDataCmd*) wParam;
	CHtDataTransferEngine *pHtDTE = (CHtDataTransferEngine*) lParam;
	if ((NULL != pHtdCmd) && (NULL != pHtDTE)) {
		if ( TRUE /*== pHtdCmd->Process()*/) {
			pHtdCmd->End();
		} else {
			pHtdCmd->Abort();
		}
	}
}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
void CHtDataTransceiveThread::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
}
void CHtDataTransceiveThread::LogDebugMessage(QString   strDebugMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString   strDiagMsg;
		strDiagMsg = QString::asprintf(_T("HtDTT - %s at GTC:%u\r\n"), strDebugMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

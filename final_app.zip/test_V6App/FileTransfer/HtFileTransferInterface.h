/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  FileTransfer 
/// @n Filename:  HtFileTransferInterface.h
/// @n Description: Provides File Transfer function(s) for historical data
///
// **************************************************************************
// Revision History
// **************************************************************************
#if !defined(AFX_HT_FILETRANSFER_INTERFACE_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_)
#define AFX_HT_FILETRANSFER_INTERFACE_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CHtFileTransferInterface {
public:
	CHtFileTransferInterface();
	virtual ~CHtFileTransferInterface();
	virtual CHtFileTransferInterface* GetHtDataConnection() = 0;
public:
	virtual BOOL Start(QString &strServerIpAddr) = 0;
	virtual BOOL Shutdown() = 0;
	virtual BOOL GetFileListFromRemoteSender(QString remotefName, QString &fileList) = 0;
	virtual BOOL GetFileFromRemoteSender(QString remotefName, QString localfName, bool bOverWrite) = 0;
	virtual BOOL SendFileToRemoteRecipient(QString localfName, QString remoteinterfName, QString remoteactualfName) = 0;
};
#endif //HT_FILETRANSFER_INTERFACE_H

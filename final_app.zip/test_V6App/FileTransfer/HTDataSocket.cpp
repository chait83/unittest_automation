//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		RTDataServer
/// @n Filename:  RTDataSocket.cpp
/// @n Description: Implementation of the CHTDataSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
#include "SecureSocket.h"
#include "HTDataSocket.h"
#include "HTDataLink.h"
#ifdef DFL_HTD_SOCK_DBG_ENABLE
CDebugFileLogger CHTDataSocket::m_debugFileLogger(L"\\SDMemory\\HtdSockDbgLogFile.txt", FALSE, (10*1024*1024));
#endif
//////////////////////////////////////////////////////////////////////
// Constructor
//////////////////////////////////////////////////////////////////////
CHTDataSocket::CHTDataSocket(CHTDataLink *pHTDataLink) : m_pHTDataLink(pHTDataLink) {
} //end CHTDataSocket()
//////////////////////////////////////////////////////////////////////
//Destructor
//////////////////////////////////////////////////////////////////////
CHTDataSocket::~CHTDataSocket() {
	//Close the thread
	if (m_readThread != NULL) {
		//No need to close the mutex in Qt
		m_readThread = NULL;
	}
} //end ~CHTDataSocket()
//****************************************************************************
/// OnAccept - Override to handle accept notifications
///
/// @param[in]	serviceSocket - QAbstractSocket to attach to new class instance
///
/// @return		false if new socket not handled by handler thread
///
//****************************************************************************
bool CHTDataSocket::OnAccept(QAbstractSocket serviceSocket) {
	bool ret = true;
	CSecureSocket::StartReadThread();
	return ret;
} //end OnAccept()
//****************************************************************************
/// Accept - Start socket listening routine
///
///
/// @return		true - accept successful
///
//****************************************************************************
BOOL CHTDataSocket::Accept() {
	BOOL bRet = TRUE;
	//Authenticate the secure socket connection
	bRet = CSecureSocket::AcceptAuthSocket(5360, 6);
	return bRet;
} //end Accept()
//*********************************************************************************************
/// OnReceive - Override to handle Receive notifications
///
/// @param[in]	n/a
///
/// @return		n/a
///
//**********************************************************************************************
void CHTDataSocket::OnReceive(int clientId, int buffLength, QAbstractSocket socket, struct _SecHandle hCtxt) {
	const int FIRST_POS = 0;
	PBYTE buff = NULL;
	int cmdIdOffset = 4;
	if (buffLength == 0)
		return;
	//Read the decrypted buffer
	ReadBuffer(clientId, buff);
	BYTE *pData = NULL;
	pData = new BYTE[buffLength];
	memcpy(pData, buff, buffLength);
	if (m_pHTDataLink != NULL) {
		m_pHTDataLink->OnReceive(clientId, pData, buffLength);
	}
	if (pData != NULL) {
		delete[] pData;
		pData = NULL;
	}
	//Clear the data buffer
	ClearBuffer(clientId);
} //end OnReceive()
//****************************************************************************
/// ResumeReadThread - resumes the read thread once the parent is ready
///
/// @param n/a
///
/// @return		true if resumed sucessfully
///
//****************************************************************************
bool CHTDataSocket::ResumeReadThread() {
	//once events set up, start thread
	if (-1 != start(m_readThread))
		return true;
	else
		return false;
} //end ResumeReadThread()
//****************************************************************************
/// ResumeAcceptThread - resumes the accept thread once the parent is ready
///
/// @param n/a
///
/// @return		true if resumed sucessfully
///
//****************************************************************************
bool CHTDataSocket::ResumeAcceptThread() {
	//once events set up, start thread
	if (-1 != start(m_acceptThread))
		return true;
	else
		return false;
} //end ResumeAcceptThread()
//****************************************************************************
// const bool SendData( int clientId, PBYTE data, int len )
///
/// Method that sends the data
///
/// @returns	True if the send message completed okay even though it may not 
///				have actually completed sending the message yet
///
//****************************************************************************
const bool CHTDataSocket::SendData(int clientId, PBYTE data, int len) {
	bool bSuccess = true;
	CLIENT_INFO_MAP clientInfoMap = CSecureSocket::GetClientInfo();
	CLIENT_INFO_MAP::iterator clientInfoItr;
	//Search for the corresponding client id
	clientInfoItr = clientInfoMap.find(clientId);
	if (clientInfoItr != clientInfoMap.end()) {
		QAbstractSocket_INFO_MAP::iterator sockInfoItr = clientInfoItr->second;
		//Send the encrypted data to the client
		if ((QAbstractSocket_ERROR == SendEncrypt(data, len, sockInfoItr->first, sockInfoItr->second))) {
			if (GetLastError() != WSAEWOULDBLOCK) {
				bSuccess = false;
			}
		}
	}
	return bSuccess;
} //end SendData()
#ifdef DFL_HTD_SOCK_DBG_ENABLE
void CHTDataSocket::LogDebugMessage(QString   strDebugMsg)
{
	QString   strDiagMsg;
	strDiagMsg = QString::asprintf("HTD_SOCK-LDM() - %s at GTC:%u\r\n", strDebugMsg, GetTickCount());
	m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
}
#endif

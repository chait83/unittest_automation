/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  FileTransfer 
/// @n Filename:  HtDataTransferThread.h
/// @n Description: This Thread class is responsible for Sending or Recieving Historical Data		
///
// **************************************************************************
// Revision History
//	Shankar Rao P 16/Sep/2019 Initial Draft
// **************************************************************************
#if !defined(AFX_HTD_TRANSCIEVE_THRREAD_H__)
#define AFX_HTD_TRANSCIEVE_THRREAD_H__
const int WM_HTD_RECEIVE_FILE = WM_APP + 49;
const int WM_HTD_SEND_FILE = WM_HTD_RECEIVE_FILE + 1;
const int WM_HTD_SEND_FILE_LIST = WM_HTD_SEND_FILE + 1; //mostly not required
#include "CStorage.h"
#include "V7DbgLogDefines.h"
//**CHtDataTransceiveThread***********************************************************
///
/// @brief Thread Class used to carry out the file transfer/receive and data tranfter for FTEngine
/// 
///
//**********************************************************************
class CHtDataTransceiveThread: public QThread {
	// DECLARE_DYNCREATE (CHtDataTransceiveThread)
protected:
	CHtDataTransceiveThread();  // protected constructor used by dynamic creation
// Attributes
public:
	virtual ~CHtDataTransceiveThread();
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHtDataTransceiveThread)
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual BOOL PreTranslateMessage(MSG *pMsg);
	//}}AFX_VIRTUAL
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
#endif
// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CHtDataTransceiveThread)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	void OnHtdSendFile(WPARAM wParam, LPARAM lParam);
	void OnHtdSendFileList(WPARAM wParam, LPARAM lParam);
	void OnHtdReceiveFile(WPARAM wParam, LPARAM lParam);
	()
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	void LogDebugMessage(QString strDebugMessage);
#endif
private:
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif //AFX_HTD_TRANSCIEVE_THRREAD_H__

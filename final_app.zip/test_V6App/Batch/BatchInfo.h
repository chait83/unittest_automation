/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Batch
/// @n Filename: BatchInfo.h
/// @n Desc:	 Definition of the CBatchInfo class
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:55:39 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:25:21 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 4/24/2007 5:29:25 PM  Roger Dawson  
//  Added code that lets the user know if the last batch was aborted.
//  4 V6 Firmware 1.3 3/12/2007 3:56:45 PM  Roger Dawson  
//  Added code that resets the batch information when the user selects a
//  reset all or reset setup. Also added code to prompt the user that all
//  batches will be stopped prior to them doing a reset all, reset setup
//  OR a reset data.
// $
//
// ****************************************************************
#if !defined(AFX_BATCHINFO_H__8B7B860E_B63D_4C93_9623_E710D99890A1__INCLUDED_)
#define AFX_BATCHINFO_H__8B7B860E_B63D_4C93_9623_E710D99890A1__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V6Config.h"
extern const QString g_wcaBATCH_LOTNO_DIR;
extern const QString g_wcaBATCH_REG_LOT_NO_KEY;
/// Enum used to indicate the current batch state	
typedef enum {
	bsBATCH_RUNNING = 1, bsBATCH_STOPPED = 2, bsBATCH_PAUSED = 3
} T_BATCH_STATE;
/// Structure used to store the current batch infmoration internally
typedef struct {
	LONGLONG llStartTime;
	LONGLONG llFinishTime;
	QString strName;
	ULONG ulNameListIndex;	// index of the name item if chosen from a list - 1 based
	QString strUserID;
	ULONG ulUserIDListIndex;	// index of the user ID item if chosen from a list - 1 based
	QString strLotNo;
	ULONG ulLotNoListIndex;	// index of the lot no item if chosen from a list - 1 based
	QString strDescription;
	ULONG ulDescListIndex;	// index of the description item if chosen from a list - 1 based
	QString strComment;
	ULONG ulCommListIndex;	// index of the comment item if chosen from a list - 1 based
	bool bLastBatchAborted;
} T_BATCH_INFO;
#include <QMutex>
//**CBatchInfo*********************************************************************
///
/// @brief Class used to retrieve and store batch information
/// 
/// Class used to retrieve and store batch information
///
//****************************************************************************
class CBatchInfo {
public:
	// Constructor
	CBatchInfo();
	// Destructor
	virtual ~CBatchInfo();
	// Method that initliases the internal variables and ensures the batch registry fields
	// exist
	const bool Initialise();
	// Method used to set the batch information when a new batch is started
	void InitNewBatch(const USHORT usGROUP_NO, const QString &rstrNAME, const ULONG ulNAME_LIST_ITEM_INDEX,
			const QString &rstrUSER_ID, const ULONG ulUSER_ID_LIST_ITEM_INDEX, const QString &rstrLOT_NO,
			const ULONG ulLOT_NO_LIST_ITEM_INDEX, const QString &rstrDESCRIPTION = "",
			const ULONG ulDESC_LIST_ITEM_INDEX = 0, const QString &rstrCOMMENT = "",
			const ULONG ulCOMM_LIST_ITEM_INDEX = 0);
	// Accessors for the batch information
	const QString GetBatchName(const USHORT usGROUP_NO);
	const ULONG GetBatchNameListIndex(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].ulNameListIndex;
	}
	const QString GetBatchUserID(const USHORT usGROUP_NO);
	const ULONG GetBatchUserIDListIndex(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].ulUserIDListIndex;
	}
	const QString GetBatchLotNo(const USHORT usGROUP_NO);
	const ULONG GetBatchLotNoListIndex(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].ulLotNoListIndex;
	}
	const QString GetBatchDescription(const USHORT usGROUP_NO);
	const ULONG GetBatchDescListIndex(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].ulDescListIndex;
	}
	const QString GetBatchComment(const USHORT usGROUP_NO);
	const ULONG GetBatchCommListIndex(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].ulCommListIndex;
	}
	const LONGLONG GetBatchStart(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].llStartTime;
	}
	const LONGLONG GetBatchFinish(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].llFinishTime;
	}
	const bool LastBatchAborted(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO].bLastBatchAborted;
	}
	// Method used to set the finish time for the passed in batch/group number
	void SetBatchFinish(const USHORT usGROUP_NO, const bool bABORTED = false);
	// Accessor method that gets the selected batch information
	const T_BATCH_INFO& GetBatchInfo(const USHORT usGROUP_NO) const {
		return m_tBatchInfo[usGROUP_NO];
	}
	// Method that sets the current comment index when using predefined lists
	void SetCommentIndex(const USHORT usGROUP_NO, const USHORT usINDEX);
	// Method used to reset the batch information
	void ResetBatchInfo(const USHORT usGROUP_NO);
	// Method used to get the keys associated string value e.g. check it 
	// exists and create it if necessary and read the its current value
	const bool GetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, QString &rstrValue);
	// Method used to set the keys associated string value e.g. check it 
	// exists and create it if necessary and write the current value
	const bool SetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, const QString &rstrVALUE);
private:
	/// Critical section used when obtaining strinngs and data that can't be obtained in a single instruction
    static QMutex m_kCritSection;
	// Store for the batch information for all the groups
	T_BATCH_INFO m_tBatchInfo[ GENERALCONFIG_GROUPNAME_SIZE];
	// Method used to get the keys associated time value e.g. check it 
	// exists and create it if necessary and read the its current value
	const bool GetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, LONGLONG &rllTime);
	// Method used to get the keys associated ULONG value (and whatever that represents)
	const bool GetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, ULONG &rulValue);
	// Method used to set the keys associated time value e.g. check it 
	// exists and create it if necessary and write its current value
	const bool SetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, const LONGLONG llTIME);
	// Method used to set the keys associated ULONG value e.g. check it 
	// exists and create it if necessary and write its current value
	const bool SetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, const ULONG ulVALUE);
	// Method used to validate the batch key e.g. check it exists and create it if necessary
	const bool ValidateBatchKey(const QString &rstrKEY);
};
#endif // !defined(AFX_BATCHINFO_H__8B7B860E_B63D_4C93_9623_E710D99890A1__INCLUDED_)

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Batch
/// @n Filename: BatchInfo.cpp
/// @n Desc:	 Implementation of the CBatchInfo class
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  9 Stability Project 1.4.1.3 7/2/2011 4:55:39 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  8 Stability Project 1.4.1.2 7/1/2011 4:37:59 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  7 Stability Project 1.4.1.1 3/17/2011 3:20:11 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  6 Stability Project 1.4.1.0 2/15/2011 3:02:16 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "BatchInfo.h"
#include "Registry.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
/// Const's used to define the registry structure which is used to store the Batch information
const QString g_wcaBATCH_REG_DIR = "SOFTWARE/Honeywell/TVV6/Batch";
const QString g_wcaBATCH_GROUP_DIR = "SOFTWARE/Honeywell/TVV6/Batch/Group%u";
const QString g_wcaBATCH_REG_NAME_KEY = "Name";
const QString g_wcaBATCH_REG_NAME_INDEX_KEY = "NameIndex";
const QString g_wcaBATCH_REG_USER_ID_KEY = "UserID";
const QString g_wcaBATCH_REG_USER_ID_INDEX_KEY = "UserIDIndex";
const QString g_wcaBATCH_REG_DESC_KEY = "Desc";
const QString g_wcaBATCH_REG_DESC_INDEX_KEY = "DescIndex";
const QString g_wcaBATCH_REG_LOT_NO_KEY = "LotNo";
const QString g_wcaBATCH_REG_LOT_NO_INDEX_KEY = "LotNoIndex";
const QString g_wcaBATCH_REG_COMMENT_KEY = "Comment";
const QString g_wcaBATCH_REG_COMMENT_INDEX_KEY = "CommentIndex";
const QString g_wcaBATCH_REG_START_KEY = "Start";
const QString g_wcaBATCH_REG_FINISH_KEY = "Finish";
const LONGLONG g_llABORTED_BATCH = 0x8000000000000000;
const QString g_wcaBATCH_LOTNO_DIR = "SOFTWARE/Honeywell/TVV6/Batch/LotNo";
QMutex CBatchInfo::m_kCritSection;
//****************************************************************************
//	CBatchInfo
///
/// Constructor
///
//****************************************************************************
CBatchInfo::CBatchInfo() {

	// clear all the batch structures
	for (USHORT usGroupNo = 0; usGroupNo < GENERALCONFIG_GROUPNAME_SIZE; usGroupNo++) {
		m_tBatchInfo[usGroupNo].llStartTime = 0;
		m_tBatchInfo[usGroupNo].llFinishTime = 0;
		m_tBatchInfo[usGroupNo].bLastBatchAborted = false;
		m_tBatchInfo[usGroupNo].strName = "";
		m_tBatchInfo[usGroupNo].ulNameListIndex = 0;
		m_tBatchInfo[usGroupNo].strUserID = "";
		m_tBatchInfo[usGroupNo].ulUserIDListIndex = 0;
		m_tBatchInfo[usGroupNo].strLotNo = "";
		m_tBatchInfo[usGroupNo].ulLotNoListIndex = 0;
		m_tBatchInfo[usGroupNo].strDescription = "";
		m_tBatchInfo[usGroupNo].ulDescListIndex = 0;
		m_tBatchInfo[usGroupNo].strComment = "";
		m_tBatchInfo[usGroupNo].ulCommListIndex = 0;
	}
}
//****************************************************************************
//	~CBatchInfo
///
/// Destructor
///
//****************************************************************************
CBatchInfo::~CBatchInfo() {
	//deletion of mutex not required
}
//****************************************************************************
//	const bool Initialise()
///
/// Method that initialised the batch information and the registry
///
/// @return		True if the batch information was created successfully
///
//****************************************************************************
const bool CBatchInfo::Initialise() {
	bool bSuccess = false;
	QString strGroupKey("");
	QString strFieldKey("");
	CRegistryKey kRegKey;
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	int iPathLen = 256;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"BatchInfo_Init.txt", (256 - wcslen( InitLogFileName )) );
	
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Batch Infi Init started-------\n");		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		wcscpy(InitLogString,L"ValidateBatchKey\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// check the main batch directory exists first
	if (ValidateBatchKey(g_wcaBATCH_REG_DIR)) {
		// if still okay then check for and/or update the individual group registry information
		for (USHORT usGroupNo = 0; usGroupNo < GENERALCONFIG_GROUPNAME_SIZE; usGroupNo++) {
#ifdef STARTUP_LOGGING
			wcscpy(InitLogString,L"strGroupKey = QString::asprintf\n");
			if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
			{
				kLogFile.SeekToEnd();		
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
            strGroupKey = QString::asprintf(g_wcaBATCH_GROUP_DIR.toLocal8Bit().data(), usGroupNo);
#ifdef STARTUP_LOGGING
			wcscpy(InitLogString,L"ValidateBatchKey(strGroupKey)\n");
			if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
			{
				kLogFile.SeekToEnd();		
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
			// check the group batch directory exists
			if (ValidateBatchKey(strGroupKey)) {
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_START_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				// get the times first
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_START_KEY, m_tBatchInfo[usGroupNo].llStartTime);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_FINISH_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_FINISH_KEY, m_tBatchInfo[usGroupNo].llFinishTime);
				// check the MSB of the finish time - if set then this implies the previous batch was aborted
				if ((m_tBatchInfo[usGroupNo].llFinishTime & g_llABORTED_BATCH) == g_llABORTED_BATCH) {
					// mask the flag out of the time
					m_tBatchInfo[usGroupNo].llFinishTime |= ~g_llABORTED_BATCH;
					m_tBatchInfo[usGroupNo].bLastBatchAborted = true;
				}
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_NAME_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				// now get the strings
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_NAME_KEY, m_tBatchInfo[usGroupNo].strName);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_USER_ID_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_USER_ID_KEY, m_tBatchInfo[usGroupNo].strUserID);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_DESC_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_DESC_KEY, m_tBatchInfo[usGroupNo].strDescription);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_LOT_NO_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_LOT_NO_KEY, m_tBatchInfo[usGroupNo].strLotNo);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_COMMENT_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_COMMENT_KEY, m_tBatchInfo[usGroupNo].strComment);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_NAME_INDEX_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				// now get the list indexes
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_NAME_INDEX_KEY, m_tBatchInfo[usGroupNo].ulNameListIndex);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_USER_ID_INDEX_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_USER_ID_INDEX_KEY, m_tBatchInfo[usGroupNo].ulUserIDListIndex);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_LOT_NO_INDEX_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_LOT_NO_INDEX_KEY, m_tBatchInfo[usGroupNo].ulLotNoListIndex);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_DESC_INDEX_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_DESC_INDEX_KEY, m_tBatchInfo[usGroupNo].ulDescListIndex);
#ifdef STARTUP_LOGGING
				wcscpy(InitLogString,L"GetBatchValue(g_wcaBATCH_REG_COMMENT_INDEX_KEY)\n");
				if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
				{
					kLogFile.SeekToEnd();		
					kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
					kLogFile.Close();
				}
#endif
				GetBatchValue(strGroupKey, g_wcaBATCH_REG_COMMENT_INDEX_KEY, m_tBatchInfo[usGroupNo].ulCommListIndex);
			} else {
				// there was a problem so we will have to skip this group
			}
		}
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"kRegKey.Flush()\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();		
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		// flush the registry just in case something was created or changed
		// kRegKey.Flush();
	} else {
		// couldn't create the main batch key - very serious
		bSuccess = false;
	}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"----------------END------------------\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return bSuccess;
}
//****************************************************************************
//	const bool GetBatchValue(	const QString  strKEY, 
//								const QString pwcVALUE_NAME
//								LONGLONG &rllTime )
///
/// Method used to get the keys associated time value e.g. check it 
/// exists and create it if necessary and read the its current value
///
/// @param[in]		const Cstring strKEY - The key we wish to check
///	@param[in]		const QString  const pwcVALUE_NAME - The value name
/// @param[out]		LONGLONG &rllTime - The time value associated with this key
///
/// @return			Returns true is the value was obtained
///
//****************************************************************************
const bool CBatchInfo::GetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, LONGLONG &rllTime) {
	bool bFoundValue = false;
	// check the key exists - if yes then get the value - no need to do the error checking again 
	// though
	if (ValidateBatchKey(rstrKEY)) {
		CRegistryKey kRegKey;
		// open the relevant registry key and read out the binary value
		kRegKey.OpenKey(rstrKEY);
		DWORD dwSize = sizeof(LONGLONG);
		DWORD dwType = REG_BINARY;
		if (kRegKey.ReadValue(pwcVALUE_NAME, &dwType, reinterpret_cast<BYTE*>(&rllTime), &dwSize)) {
			// the operation was successful
			bFoundValue = true;
		} else {
			// failed to read the value - this may be because it hasn't been created yet
			// which is not a problem
			bFoundValue = false;
		}
	} else {
		// couldn't validate the group key - very serious
		bFoundValue = false;
	}
	return bFoundValue;
}
//****************************************************************************
//	const bool GetBatchValue(	const QString  strKEY, 
//								const QString  const pwcVALUE_NAME
//								QString  &rstrValue )
///
/// Method used to get the keys associated string value e.g. check it 
/// exists and create it if necessary and read the its current value
///
/// @param[in]		const Cstring strKEY - The key we wish to check
///	@param[in]		const QString  const pwcVALUE_NAME - The value name
/// @param[out]		QString  &rstrValue - The string value associated with this key
/// @return			Returns true is the value was obtained
///
//****************************************************************************
const bool CBatchInfo::GetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, QString &rstrValue) {
	bool bFoundValue = false;
	// check the key exists - if yes then get the value - no need to do the error checking again 
	// though
	if (ValidateBatchKey(rstrKEY)) {
		CRegistryKey kRegKey;
		// open the relevant registry key and read out the string value
		kRegKey.OpenKey(rstrKEY);
		DWORD dwSize = 100;
		if (kRegKey.ReadValue(pwcVALUE_NAME, rstrValue, &dwSize, REG_SZ)) {
			// the operation was successful
			bFoundValue = true;
		} else {
			// make sure the data is clear as nothing was read
			rstrValue = "";
			// failed to read the value - this may be because it hasn't been created yet
			// which is not a problem
			bFoundValue = false;
		}
	} else {
		// couldn't validate the group key - very serious
		bFoundValue = false;
	}
	return bFoundValue;
}
//****************************************************************************
//	const bool GetBatchValue(	const QString  strKEY, 
//								const QString pwcVALUE_NAME
//								ULONG &rulValue )
///
/// Method used to get the keys associated ULONG value (and whatever that represents)
///
/// @param[in]		const Cstring strKEY - The key we wish to check
///	@param[in]		const QString  const pwcVALUE_NAME - The value name
/// @param[out]		ULONG &rulValue - The ULONG value associated with this key
///
/// @return			Returns true is the value was obtained
///
//****************************************************************************
const bool CBatchInfo::GetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, ULONG &rulValue) {
	bool bFoundValue = false;
	// check the key exists - if yes then get the value - no need to do the error checking again 
	// though
	if (ValidateBatchKey(rstrKEY)) {
		CRegistryKey kRegKey;
		// open the relevant registry key and read out the binary value
		kRegKey.OpenKey(rstrKEY);
		DWORD dwSize = sizeof(ULONG);
		DWORD dwType = REG_BINARY;
		if (kRegKey.ReadValue(pwcVALUE_NAME, &dwType, reinterpret_cast<BYTE*>(&rulValue), &dwSize)) {
			// the operation was successful
			bFoundValue = true;
		} else {
			// failed to read the value - this may be because it hasn't been created yet
			// which is not a problem
			bFoundValue = false;
		}
	} else {
		// couldn't validate the group key - very serious
		bFoundValue = false;
	}
	return bFoundValue;
}
//****************************************************************************
//	const bool ValidateBatchKey( const QString  strKEY )
///
/// Method used to validate the batch key e.g. check it exists and create it if necessary
///
/// @param[in]		const Cstring strKEY - The key we wish to check
///
/// @return			Returns true is the key was found and/or created successfully
///
//****************************************************************************
const bool CBatchInfo::ValidateBatchKey(const QString &rstrKEY) {
	bool bKeyValid = false;
	CRegistryKey kRegKey;
	if (!kRegKey.OpenKey(rstrKEY)) {
		// created the key
		if (kRegKey.CreateKey(rstrKEY) == FALSE) {
			// couldn't create the key - this should never happen
			QString strError("");
            strError = QString::asprintf("Batch Error - couldn't create %s key!!!", rstrKEY.toLocal8Bit().data());
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			bKeyValid = false;
		} else {
			// the key was created okay
			bKeyValid = true;
			kRegKey.Close();
			kRegKey.Flush();
		}
	} else {
		// the key already exists
		bKeyValid = true;
		kRegKey.Close();
	}
	return bKeyValid;
}
//****************************************************************************
//	const bool SetBatchValue(	const QString  strKEY, 
//								const QString pwcVALUE_NAME
//								const LONGLONG llTIME )
///
/// Method used to set the keys associated time value e.g. check it 
/// exists and create it if necessary and write its current value
///
/// @param[in]		const Cstring strKEY - The key we wish to check
///	@param[in]		const QString  pwcVALUE_NAME - The value name
/// @param[out]		const LONGLONG llTIME - The time value associated with this key
///
/// @return			Returns true if the value was set
///
//****************************************************************************
const bool CBatchInfo::SetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, const LONGLONG llTIME) {
	bool bWroteValue = false;
	// check the key exists - if yes then get the value - no need to do the error checking again 
	// though
	if (ValidateBatchKey(rstrKEY)) {
		CRegistryKey kRegKey;
		kRegKey.OpenKey(rstrKEY);
		DWORD dwSize = sizeof(LONGLONG);
		// write the new binary value
		if (kRegKey.WriteValue(pwcVALUE_NAME, reinterpret_cast<const BYTE*>(&llTIME), dwSize)) {
			// the operation was successful
			bWroteValue = true;
		} else {
			// failed to write the value - very serious
			bWroteValue = false;
		}
	} else {
		// couldn't validate the group key - very serious
		bWroteValue = false;
	}
	return bWroteValue;
}
//****************************************************************************
//	const bool SetBatchValue(	const QString  strKEY, 
//								const QString  pwcVALUE_NAME
//								const QString  &rstrVALUE )
///
/// Method used to set the keys associated string value e.g. check it 
/// exists and create it if necessary and write the current value
///
/// @param[in]		const Cstring strKEY - The key we wish to check
///	@param[in]		const QString  pwcVALUE_NAME - The value name
/// @param[out]		const QString  &rstrVALUE - The string value associated with this key
/// @return			Returns true is the key was found and/or created successfully
///
//****************************************************************************
const bool CBatchInfo::SetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, const QString &rstrVALUE) {
	bool bWroteValue = false;
	// check the key exists - if yes then get the value - no need to do the error checking again 
	// though
	if (ValidateBatchKey(rstrKEY)) {
		CRegistryKey kRegKey;
		kRegKey.OpenKey(rstrKEY);
        // write the new string value
		if (kRegKey.WriteValue(pwcVALUE_NAME, rstrVALUE)) {
			// the operation was successful
			bWroteValue = true;
		} else {
			// failed to write the value - very serious
			bWroteValue = false;
		}
	} else {
		// couldn't validate the group key - very serious
		bWroteValue = false;
	}
	return bWroteValue;
}
//****************************************************************************
//	const bool SetBatchValue(	const QString  strKEY, 
//								const QString pwcVALUE_NAME
//								const ULONG ulVALUE )
///
/// Method used to set the keys associated ULONG value e.g. check it 
/// exists and create it if necessary and write its current value
///
/// @param[in]		const Cstring strKEY - The key we wish to check
///	@param[in]		const QString  pwcVALUE_NAME - The value name
/// @param[out]		const ULONG ulVALUE - The ULONG value associated with this key
///
/// @return			Returns true if the value was set
///
//****************************************************************************
const bool CBatchInfo::SetBatchValue(const QString &rstrKEY, const QString pwcVALUE_NAME, const ULONG ulVALUE) {
	bool bWroteValue = false;
	// check the key exists - if yes then get the value - no need to do the error checking again 
	// though
	if (ValidateBatchKey(rstrKEY)) {
		CRegistryKey kRegKey;
		kRegKey.OpenKey(rstrKEY);
		DWORD dwSize = sizeof(ULONG);
		// write the new binary value
		if (kRegKey.WriteValue(pwcVALUE_NAME, reinterpret_cast<const BYTE*>(&ulVALUE), dwSize)) {
			// the operation was successful
			bWroteValue = true;
		} else {
			// failed to write the value - very serious
			bWroteValue = false;
		}
	} else {
		// couldn't validate the group key - very serious
		bWroteValue = false;
	}
	return bWroteValue;
}
//****************************************************************************
//	void InitNewBatch(	const USHORT usGROUP_NO,
//						const QString  &rstrNAME,
//						const QString  &rstrUSER_ID,
//						const QString  &rstrLOT_NO,
//						const QString  &rstrDESCRIPTION = QString   ::fromWCharArray(""),
//						const QString  &rstrCOMMENT = QString   ::fromWCharArray("") )
///
/// Method used to set the batch information when a new batch is started
///
/// @param[in]		const USHORT usGROUP_NO - The zero based group number
/// @param[in]		const QString  &rstrNAME - The new batch name
/// @param[in]		const ULONG ulNAME_LIST_ITEM_INDEX - The one based index of the name if picked
///					from one of the predefined lists
/// @param[in]		const QString  &rstrUSER_ID - The user ID
/// @param[in]		const ULONG ulUSER_ID_LIST_ITEM_INDEX - The one based index of the user ID if picked
///					from one of the predefined lists
/// @param[in]		const QString  &rstrLOT_NO - The lot no
/// @param[in]		const ULONG ulLOT_NO_LIST_ITEM_INDEX - The one based index of the lot no if picked
///					from one of the predefined lists
/// @param[in]		const QString  &rstrDESCRIPTION - The batch description
/// @param[in]		const ULONG ulDESC_LIST_ITEM_INDEX - The one based index of the description if picked
///					from one of the predefined lists
/// @param[in]		const QString  &rstrCOMMENT - The description
/// @param[in]		const ULONG ulCOMM_LIST_ITEM_INDEX - The one based index of the comment if picked
///					from one of the predefined lists
///
/// @return			Returns true is the batch was successfully updated and the
///					state change was okay (e.g. not starting a batch that is already started)
///
//****************************************************************************
void CBatchInfo::InitNewBatch(const USHORT usGROUP_NO, const QString &rstrNAME, const ULONG ulNAME_LIST_ITEM_INDEX,
		const QString &rstrUSER_ID, const ULONG ulUSER_ID_LIST_ITEM_INDEX, const QString &rstrLOT_NO,
		const ULONG ulLOT_NO_LIST_ITEM_INDEX, const QString &rstrDESCRIPTION /* = QString   ::fromWCharArray("") */,
		const ULONG ulDESC_LIST_ITEM_INDEX /* = 0 */, const QString &rstrCOMMENT /* = QString   ::fromWCharArray("") */,
		const ULONG ulCOMM_LIST_ITEM_INDEX /* = 0 */) {
	m_kCritSection.lock();
	QString strGroupKey("");
    strGroupKey = QString::asprintf(g_wcaBATCH_GROUP_DIR.toLocal8Bit().data(), usGROUP_NO);
	// set the times first
	m_tBatchInfo[usGROUP_NO].llStartTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_START_KEY, m_tBatchInfo[usGROUP_NO].llStartTime);
	// simply set the finish time to 0 for now
	m_tBatchInfo[usGROUP_NO].llFinishTime = 0;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_FINISH_KEY, static_cast<LONGLONG>(0));
	m_tBatchInfo[usGROUP_NO].bLastBatchAborted = false;
	// now set the strings
	m_tBatchInfo[usGROUP_NO].strName = rstrNAME;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_NAME_KEY, m_tBatchInfo[usGROUP_NO].strName);
	m_tBatchInfo[usGROUP_NO].strUserID = rstrUSER_ID;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_USER_ID_KEY, m_tBatchInfo[usGROUP_NO].strUserID);
	m_tBatchInfo[usGROUP_NO].strDescription = rstrDESCRIPTION;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_DESC_KEY, m_tBatchInfo[usGROUP_NO].strDescription);
	m_tBatchInfo[usGROUP_NO].strLotNo = rstrLOT_NO;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_LOT_NO_KEY, m_tBatchInfo[usGROUP_NO].strLotNo);
	m_tBatchInfo[usGROUP_NO].strComment = rstrCOMMENT;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_COMMENT_KEY, m_tBatchInfo[usGROUP_NO].strComment);
	// now the list indexes
	m_tBatchInfo[usGROUP_NO].ulNameListIndex = ulNAME_LIST_ITEM_INDEX;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_NAME_INDEX_KEY, m_tBatchInfo[usGROUP_NO].ulNameListIndex);
	m_tBatchInfo[usGROUP_NO].ulUserIDListIndex = ulUSER_ID_LIST_ITEM_INDEX;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_USER_ID_INDEX_KEY, m_tBatchInfo[usGROUP_NO].ulUserIDListIndex);
	m_tBatchInfo[usGROUP_NO].ulLotNoListIndex = ulLOT_NO_LIST_ITEM_INDEX;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_LOT_NO_INDEX_KEY, m_tBatchInfo[usGROUP_NO].ulLotNoListIndex);
	m_tBatchInfo[usGROUP_NO].ulDescListIndex = ulDESC_LIST_ITEM_INDEX;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_DESC_INDEX_KEY, m_tBatchInfo[usGROUP_NO].ulDescListIndex);
	m_tBatchInfo[usGROUP_NO].ulCommListIndex = ulCOMM_LIST_ITEM_INDEX;
	SetBatchValue(strGroupKey, g_wcaBATCH_REG_COMMENT_INDEX_KEY, m_tBatchInfo[usGROUP_NO].ulCommListIndex);
	//Write the Lot No to the registry
	QString strLotNoKey("");
    strLotNoKey = g_wcaBATCH_LOTNO_DIR;
	SetBatchValue(strLotNoKey, g_wcaBATCH_REG_LOT_NO_KEY, m_tBatchInfo[usGROUP_NO].strLotNo);
	// flush the data
	CRegistryKey kRegKey;
	kRegKey.Flush();
	m_kCritSection.lock();
}
//****************************************************************************
//	void SetBatchFinish( const USHORT usGROUP_NO, const bool bABORTED /* = false */ )
///
/// Method used to set the finish time for the passed in batch/group number
///
/// @param[in]		const USHORT usGROUP_NO - The zero based group number
/// @param[in]		const bool bABORTED - Flag indicating if the batch was aborted
///
//****************************************************************************
void CBatchInfo::SetBatchFinish(const USHORT usGROUP_NO, const bool bABORTED /* = false */) {
	m_kCritSection.lock();
	QString strGroupKey("");
    strGroupKey = QString::asprintf(g_wcaBATCH_GROUP_DIR.toLocal8Bit().data(), usGROUP_NO);
	// set the finish time to the time now
	m_tBatchInfo[usGROUP_NO].llFinishTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
	if (bABORTED) {
		// set the flags indicating the last batch was aborted
		m_tBatchInfo[usGROUP_NO].bLastBatchAborted = true;
		SetBatchValue(strGroupKey, g_wcaBATCH_REG_FINISH_KEY,
				m_tBatchInfo[usGROUP_NO].llFinishTime | g_llABORTED_BATCH);
	} else {
		m_tBatchInfo[usGROUP_NO].bLastBatchAborted = false;
		SetBatchValue(strGroupKey, g_wcaBATCH_REG_FINISH_KEY, m_tBatchInfo[usGROUP_NO].llFinishTime);
	}
	// flush the data
	CRegistryKey kRegKey;
	kRegKey.Flush();
	m_kCritSection.lock();
}
//****************************************************************************
//	const QString  GetBatchName(	const USHORT usGROUP_NO )
///
/// Accessor for the batch name
///
/// @param[in]		const USHORT usGROUP_NO - The zero based group number
///
/// @return		A string containing the batch name
///
//****************************************************************************
const QString CBatchInfo::GetBatchName(const USHORT usGROUP_NO) {
	QString strName("");
	m_kCritSection.lock();
	strName = m_tBatchInfo[usGROUP_NO].strName;
	m_kCritSection.lock();
	return strName;
}
//****************************************************************************
//	const QString  GetBatchUserID(	const USHORT usGROUP_NO )
///
/// Accessor for the user ID
///
/// @param[in]		const USHORT usGROUP_NO - The zero based group number
///
/// @return		A string containing the user ID
///
//****************************************************************************
const QString CBatchInfo::GetBatchUserID(const USHORT usGROUP_NO) {
	QString strID("");
	m_kCritSection.lock();
	strID = m_tBatchInfo[usGROUP_NO].strUserID;
	m_kCritSection.lock();
	return strID;
}
//****************************************************************************
//	const QString  GetBatchLotNo(	const USHORT usGROUP_NO )
///
/// Accessor for the batch lot number
///
/// @param[in]		const USHORT usGROUP_NO - The zero baba
